"""Resolución dinámica del dispositivo de montaje (letras pueden cambiar)."""
from __future__ import annotations

import os

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

import pytest

from backend.shares.providers.share_disk_mount_provider import ShareDiskMountProvider
from backend.shares.services import disk_guard


class TestResolveDevice:
    def test_prefers_by_uuid(self, monkeypatch):
        monkeypatch.setattr(os.path, "exists", lambda p: p == "/dev/disk/by-uuid/U")
        monkeypatch.setattr(disk_guard, "is_system_disk", lambda d: False)
        p = ShareDiskMountProvider()
        assert p.resolve_device(uuid="U") == "/dev/disk/by-uuid/U"

    def test_falls_back_to_device_path(self, monkeypatch):
        monkeypatch.setattr(os.path, "exists", lambda p: p == "/dev/sdb2")
        monkeypatch.setattr(disk_guard, "is_system_disk", lambda d: False)
        p = ShareDiskMountProvider()
        assert p.resolve_device(uuid="STALE", device_path="/dev/sdb2") == "/dev/sdb2"

    def test_never_returns_system_disk(self, monkeypatch):
        monkeypatch.setattr(os.path, "exists", lambda p: True)
        monkeypatch.setattr(disk_guard, "is_system_disk", lambda d: True)
        p = ShareDiskMountProvider()
        assert p.resolve_device(uuid="U", device_path="/dev/sda2") is None

    def test_scan_lsblk_by_uuid_when_symlink_lags(self, monkeypatch):
        monkeypatch.setattr(os.path, "exists", lambda p: False)
        monkeypatch.setattr(disk_guard, "is_system_disk", lambda d: False)
        p = ShareDiskMountProvider()
        monkeypatch.setattr(
            p, "_run", lambda cmd: "/dev/sdb2 914415f4-XXXX\n/dev/sdb1 OTHER\n"
        )
        assert p.resolve_device(uuid="914415f4-XXXX") == "/dev/sdb2"

    def test_none_when_not_found(self, monkeypatch):
        monkeypatch.setattr(os.path, "exists", lambda p: False)
        monkeypatch.setattr(disk_guard, "is_system_disk", lambda d: False)
        p = ShareDiskMountProvider()
        monkeypatch.setattr(p, "_run", lambda cmd: "")
        assert p.resolve_device(uuid="NOPE", device_path="/dev/nope") is None