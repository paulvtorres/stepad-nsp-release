import { useEffect, useState } from "react";

import {
    getRegisteredInterfaces,
    rescanInterfaces,
    assignInterfaceRole,
    unassignInterfaceRole,
    deleteRegisteredInterface,
    testInterfaceConnectivity,
    compareWan,
    getDhcpConfig,
    setLanSegment,
    setDhcpExclusions
} from "../../../services/api";

import NetworkDiagnosis from "../../../components/network/NetworkDiagnosis";

import WriteGuard from "../../../components/WriteGuard";

import "./interfaces.css";


function LinkStatus({ up, labelUp, labelDown }) {

    return (
        <span className={`iface-link-status ${up ? "up" : "down"}`}>
            <span className="iface-link-dot" />
            {up ? labelUp : labelDown}
        </span>
    );

}


function DetailChip({ label, value, mono }) {

    return (
        <span className={`iface-chip ${mono ? "mono" : ""}`}>
            <span className="iface-chip-label">{label}</span>
            <span className="iface-chip-value">{value}</span>
        </span>
    );

}


function InterfaceCard({ item, busyId, testResults, onTest, onUnassign, onPriorityChange }) {

    const name = item.current_name || item.last_seen_name || "-";
    const role = (item.role || "").toLowerCase();
    const test = testResults[item.id];

    return (

        <div className={`registry-card role-${role} ${item.link_detected ? "live" : "offline"}`}>

            <div className="registry-card-main">

                <div className="registry-card-title-row">
                    <span className={`iface-role-badge ${role}`}>{item.role}</span>
                    <div className="registry-card-name">
                        {name}
                        {item.display_name && (
                            <span className="registry-card-label"> · {item.display_name}</span>
                        )}
                    </div>
                </div>

                <div className="registry-card-details">
                    <LinkStatus
                        up={item.link_detected}
                        labelUp="Enlace activo"
                        labelDown="Sin cable"
                    />
                    <DetailChip label="MAC" value={item.mac_address} mono />
                    <DetailChip label="IP" value={item.ip_address || "sin IP"} mono />
                </div>

            </div>

            <div className="registry-card-priority">
                <span className="priority-label">Prioridad</span>
                <div className="priority-stepper">
                    <WriteGuard>
                        <button
                            type="button"
                            disabled={busyId === item.id}
                            title="Subir prioridad (preferir esta tarjeta primero)"
                            onClick={() => onPriorityChange(item.id, item.priority - 10)}
                        >
                            ▲
                        </button>
                    </WriteGuard>
                    <span className="priority-value">{item.priority}</span>
                    <WriteGuard>
                        <button
                            type="button"
                            disabled={busyId === item.id}
                            title="Bajar prioridad"
                            onClick={() => onPriorityChange(item.id, item.priority + 10)}
                        >
                            ▼
                        </button>
                    </WriteGuard>
                </div>
            </div>

            <div className="registry-card-actions">

                {
                    item.role === "WAN" && (
                        <WriteGuard>
                            <button
                                type="button"
                                className="iface-action-btn"
                                disabled={busyId === item.id}
                                onClick={() => onTest(item.id)}
                            >
                                {busyId === item.id ? "Probando..." : "Probar internet"}
                            </button>
                        </WriteGuard>
                    )
                }

                <WriteGuard>
                    <button
                        type="button"
                        className="iface-action-btn ghost"
                        disabled={busyId === item.id}
                        onClick={() => onUnassign(item.id)}
                    >
                        Quitar rol
                    </button>
                </WriteGuard>

                {
                    test && (
                        <div
                            className={
                                test.has_internet
                                    ? "registry-test-result-ok"
                                    : "registry-test-result-no"
                            }
                        >
                            {test.message}
                        </div>
                    )
                }

            </div>

        </div>

    );

}


function UnassignedCard({ item, busyId, testResults, onTest, onAssign, onDelete }) {

    const [selectedRole, setSelectedRole] = useState("");


    function handleRoleChange(value) {

        if (!value) return;

        onAssign(item.id, value);

        setSelectedRole("");

    }


    return (

        <div className={`registry-card registry-card-unassigned ${item.status === "missing" ? "missing" : ""}`}>

            <div className="registry-card-main">

                <div className="registry-card-title-row">
                    <span className={`iface-role-badge ${item.status === "missing" ? "missing" : "none"}`}>
                        {item.status === "missing" ? "Ausente" : "Sin rol"}
                    </span>
                    <div className="registry-card-name">
                        {item.current_name || item.last_seen_name || "-"}
                    </div>
                </div>

                <div className="registry-card-details">
                    <LinkStatus
                        up={item.link_detected}
                        labelUp="Enlace activo"
                        labelDown="Sin cable"
                    />
                    <DetailChip label="MAC" value={item.mac_address} mono />
                    <DetailChip label="IP" value={item.ip_address || "sin IP"} mono />
                </div>

                {
                    item.status === "missing" && (
                        <div className="registry-missing-tag">
                            No detectada -- esta tarjeta tenía un rol asignado y ya no aparece.
                        </div>
                    )
                }

                {
                    item.suggested_replacement && (

                        <div className="registry-suggestion">

                            ¿Reemplazaste la tarjeta{" "}
                            {item.suggested_replacement.suggested_role}
                            {" "}(antes{" "}
                            {item.suggested_replacement.replaces_last_seen_name}
                            {")? "}

                            <WriteGuard>
                                <button
                                    disabled={busyId === item.id}
                                    onClick={() =>
                                        onAssign(
                                            item.id,
                                            item.suggested_replacement.suggested_role,
                                            item.suggested_replacement.suggested_display_name
                                        )
                                    }
                                >
                                    Sí, asignar el mismo rol
                                </button>
                            </WriteGuard>

                        </div>

                    )
                }

            </div>

            <div className="registry-card-actions">

                {
                    item.link_detected && (
                        <WriteGuard>
                            <button
                                type="button"
                                className="iface-action-btn"
                                disabled={busyId === item.id}
                                onClick={() => onTest(item.id)}
                            >
                                {busyId === item.id ? "Probando..." : "Probar internet"}
                            </button>
                        </WriteGuard>
                    )
                }

                <WriteGuard>
                    <div className="registry-assign-row">

                        {
                            item.status !== "missing" && (
                                <select
                                    value={selectedRole}
                                    onChange={(e) => handleRoleChange(e.target.value)}
                                >
                                    <option value="">Elegir rol...</option>
                                    <option value="WAN">WAN (internet)</option>
                                    <option value="LAN">LAN (red interna)</option>
                                </select>
                            )
                        }

                        {
                            item.status === "missing" && (
                                <button
                                    type="button"
                                    className="iface-action-btn danger"
                                    disabled={busyId === item.id}
                                    onClick={() => onDelete(item.id)}
                                    title="Eliminar del registro -- ya no está conectada"
                                >
                                    Eliminar
                                </button>
                            )
                        }

                    </div>
                </WriteGuard>

                {
                    testResults[item.id] && (
                        <div
                            className={
                                testResults[item.id].has_internet
                                    ? "registry-test-result-ok"
                                    : "registry-test-result-no"
                            }
                        >
                            {testResults[item.id].message}
                        </div>
                    )
                }

            </div>

        </div>

    );

}


function InterfaceRegistryPanel({ onRegistryChange }) {

    const [registered, setRegistered] = useState([]);

    const [busyId, setBusyId] = useState(null);

    const [testResults, setTestResults] = useState({});

    const [compareResults, setCompareResults] = useState([]);

    const [compareBusy, setCompareBusy] = useState(false);


    async function handleCompareWan() {

        setCompareBusy(true);

        try {

            const res = await compareWan();

            setCompareResults(res || []);

        } catch (error) {

            console.error(error);

        } finally {

            setCompareBusy(false);

        }

    }


    useEffect(() => {

        loadRegistered();

    }, []);


    async function loadRegistered() {

        try {

            const data = await getRegisteredInterfaces();

            setRegistered(data || []);

        } catch (error) {

            console.error(error);

        }

    }


    const [rescanBusy, setRescanBusy] = useState(false);

    async function handleRescan() {

        setRescanBusy(true);

        try {

            const data = await rescanInterfaces();

            setRegistered(data || []);

        } catch (error) {

            console.error(error);

        } finally {

            setRescanBusy(false);

        }

    }


    async function handleTestConnectivity(id) {

        setBusyId(id);

        try {

            const result = await testInterfaceConnectivity(id);

            setTestResults((previous) => ({
                ...previous,
                [id]: result
            }));

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handleAssign(id, role, displayName) {

        setBusyId(id);

        try {

            const payload = displayName
                ? { role, display_name: displayName }
                : { role };

            await assignInterfaceRole(id, payload);

            await loadRegistered();

            onRegistryChange?.();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handlePriorityChange(id, newPriority) {

        setBusyId(id);

        try {

            const item = registered.find((entry) => entry.id === id);

            await assignInterfaceRole(id, { role: item.role, priority: newPriority });

            await loadRegistered();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handleUnassign(id) {

        setBusyId(id);

        try {

            await unassignInterfaceRole(id);

            await loadRegistered();

            onRegistryChange?.();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handleDelete(id) {

        setBusyId(id);

        try {

            await deleteRegisteredInterface(id);

            await loadRegistered();

            onRegistryChange?.();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    const wanCards = registered
        .filter((item) => item.role === "WAN")
        .sort((a, b) => a.priority - b.priority);

    const lanCards = registered
        .filter((item) => item.role === "LAN")
        .sort((a, b) => a.priority - b.priority);

    const unassignedCards = registered.filter(
        (item) => item.status === "pending_assignment" || item.status === "missing"
    );


    return (

        <div className="registry-panel">

            <div className="registry-panel-head">
                <div>
                    <h3>Tarjetas de red</h3>
                    <p className="registry-hint">
                        Cada tarjeta se identifica por su MAC, no por el nombre
                        que le da Linux — así el rol sobrevive a un cambio de
                        máquina o un reinicio. La prioridad decide cuál se usa primero.
                    </p>
                </div>
                <div className="confirm-actions">
                    <button className="secondary-button" onClick={handleRescan} disabled={rescanBusy}>
                        {rescanBusy ? "Rescaneando..." : "Rescanear"}
                    </button>
                    <button className="secondary-button" onClick={handleCompareWan} disabled={compareBusy}>
                        {compareBusy ? "Midiendo..." : "Comparar internet"}
                    </button>
                </div>
            </div>

            <div className="iface-summary">
                <span className="iface-summary-chip wan">
                    <strong>{wanCards.length}</strong> WAN
                </span>
                <span className="iface-summary-chip lan">
                    <strong>{lanCards.length}</strong> LAN
                </span>
                <span className="iface-summary-chip none">
                    <strong>{unassignedCards.length}</strong> sin asignar
                </span>
            </div>

            {
                compareResults.length > 0 && (
                    <div className="registry-compare">
                        <h4>Comparación de proveedores (mejor primero)</h4>
                        {
                            compareResults.map((r, i) => (
                                <div
                                    key={r.mac_address || r.name}
                                    className={
                                        i === 0 && r.has_internet
                                            ? "registry-compare-item best"
                                            : "registry-compare-item"
                                    }
                                >
                                    <strong>{r.name}</strong>
                                    <span>
                                        {
                                            r.has_internet
                                                ? `Internet OK · ${r.latency_ms ? r.latency_ms.toFixed(0) : "—"} ms · pérdida ${r.packet_loss}%`
                                                : "Sin internet"
                                        }
                                        {i === 0 && r.has_internet && " · Recomendada"}
                                    </span>
                                </div>
                            ))
                        }
                    </div>
                )
            }

            <div className="registry-section">

                <h4 className="registry-section-title wan">
                    <span className="iface-role-badge wan">WAN</span>
                    Internet
                    {wanCards.length > 0 && <em>{wanCards.length}</em>}
                </h4>

                {
                    wanCards.length === 0 ? (
                        <p className="registry-empty">Ninguna tarjeta asignada como WAN todavía.</p>
                    ) : (
                        wanCards.map((item) => (
                            <InterfaceCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onUnassign={handleUnassign}
                                onPriorityChange={handlePriorityChange}
                            />
                        ))
                    )
                }

            </div>

            <div className="registry-section">

                <h4 className="registry-section-title lan">
                    <span className="iface-role-badge lan">LAN</span>
                    Red interna
                    {lanCards.length > 0 && <em>{lanCards.length}</em>}
                </h4>

                {
                    lanCards.length === 0 ? (
                        <p className="registry-empty">Ninguna tarjeta asignada como LAN todavía.</p>
                    ) : (
                        lanCards.map((item) => (
                            <InterfaceCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onUnassign={handleUnassign}
                                onPriorityChange={handlePriorityChange}
                            />
                        ))
                    )
                }

            </div>

            <div className="registry-section">

                <h4 className="registry-section-title none">
                    <span className="iface-role-badge none">Libre</span>
                    Sin asignar
                    {unassignedCards.length > 0 && <em>{unassignedCards.length}</em>}
                </h4>

                {
                    unassignedCards.length === 0 ? (
                        <p className="registry-empty">No hay tarjetas pendientes de asignar.</p>
                    ) : (
                        unassignedCards.map((item) => (
                            <UnassignedCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onAssign={handleAssign}
                                onDelete={handleDelete}
                            />
                        ))
                    )
                }

            </div>

        </div>

    );

}


function LanSegmentPanel() {

    const [config, setConfig] = useState(null);

    const [network, setNetwork] = useState("");

    const [groupIpStart, setGroupIpStart] = useState("");

    const [groupIpEnd, setGroupIpEnd] = useState("");

    const [poolStart, setPoolStart] = useState("");

    const [poolEnd, setPoolEnd] = useState("");

    const [exclusions, setExclusions] = useState("");

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpConfig();

            setConfig(data);

            setNetwork(`${data.network}/${data.netmask}`);
            setGroupIpStart(data.group_ip_start || "");
            setGroupIpEnd(data.group_ip_end || "");
            setPoolStart(data.pool_start);
            setPoolEnd(data.pool_end);
            setExclusions((data.excluded_ips || []).join(", "));

        } catch (e) {

            setError("No se pudo leer la configuración DHCP.");

        }

    }


    useEffect(() => {

        load();

    }, []);


    function parseExclusions() {

        return exclusions
            .split(",")
            .map((x) => x.trim())
            .filter(Boolean);

    }

    function groupIpCount() {
        if (!groupIpStart || !groupIpEnd) {
            return config?.group_ip_count || 0;
        }
        try {
            const a = groupIpStart.split(".").map(Number);
            const b = groupIpEnd.split(".").map(Number);
            const start = ((a[0] << 24) >>> 0) + (a[1] << 16) + (a[2] << 8) + a[3];
            const end = ((b[0] << 24) >>> 0) + (b[1] << 16) + (b[2] << 8) + b[3];
            return Math.max(0, end - start + 1);
        } catch {
            return config?.group_ip_count || 0;
        }
    }


    async function handleApplySegment() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setLanSegment({
                network,
                pool_start: poolStart,
                pool_end: poolEnd,
                excluded_ips: parseExclusions(),
                group_ip_start: groupIpStart || undefined,
                group_ip_end: groupIpEnd || undefined,
            });

            if (result?.success === false) {
                setError(result.message || "No se pudo aplicar el segmento.");
            } else {
                setMessage(result?.message || "Segmento aplicado.");
            }

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudo aplicar el segmento."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveExclusions() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setDhcpExclusions(parseExclusions());

            setMessage(
                result?.success
                    ? "Exclusiones guardadas y DHCP reaplicado."
                    : "Exclusiones guardadas."
            );

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudieron guardar las exclusiones."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel">

            <h3>Segmento LAN y DHCP</h3>

            <p className="registry-hint">
                El segmento se divide en tres zonas: gateway (.1),
                <strong> IPs de grupos</strong> (DNS/filtrado, una por grupo)
                y <strong>pool DHCP de equipos</strong>. Si no reservás IPs
                para grupos, el NSP no podrá crear más grupos cuando se
                agoten. Por defecto se reservan 10 IPs (.10–.19).
            </p>

            {
                config && (
                    <div className="lan-stat-row">
                        <span className="lan-stat">
                            <span>Segmento</span>
                            <strong>{config.network}/{config.netmask}</strong>
                        </span>
                        <span className="lan-stat">
                            <span>Gateway</span>
                            <strong>{config.gateway}</strong>
                        </span>
                        <span className="lan-stat">
                            <span>IPs grupos</span>
                            <strong>
                                {config.group_ip_start && config.group_ip_end
                                    ? `${config.group_ip_start}–${config.group_ip_end}`
                                    : "—"}
                                {config.group_ip_count
                                    ? ` (${config.group_ip_count})`
                                    : ""}
                            </strong>
                        </span>
                        <span className="lan-stat">
                            <span>Pool equipos</span>
                            <strong>{config.pool_start}–{config.pool_end}</strong>
                        </span>
                        {
                            config.excluded_ips?.length > 0 && (
                                <span className="lan-stat">
                                    <span>Excluidas</span>
                                    <strong>{config.excluded_ips.join(", ")}</strong>
                                </span>
                            )
                        }
                    </div>
                )
            }

            <WriteGuard>

                <div className="registry-form-panel">

                    <div className="registry-form-grid">

                        <label className="registry-form-full">
                            Red (CIDR)
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.0/24"
                                value={network}
                                onChange={(e) => setNetwork(e.target.value)}
                            />
                        </label>

                    </div>

                    <p className="registry-section-label">
                        Reservado para grupos (DNS) — {groupIpCount() || "?"} grupos máx.
                    </p>

                    <div className="registry-form-grid">

                        <label>
                            Grupos desde
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.10"
                                value={groupIpStart}
                                onChange={(e) => setGroupIpStart(e.target.value)}
                            />
                        </label>

                        <label>
                            Grupos hasta
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.19"
                                value={groupIpEnd}
                                onChange={(e) => setGroupIpEnd(e.target.value)}
                            />
                        </label>

                    </div>

                    <p className="registry-section-label">
                        Pool DHCP de equipos (PCs, impresoras, etc.)
                    </p>

                    <div className="registry-form-grid">

                        <label>
                            Pool DHCP desde
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.20"
                                value={poolStart}
                                onChange={(e) => setPoolStart(e.target.value)}
                            />
                        </label>

                        <label>
                            Pool DHCP hasta
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.150"
                                value={poolEnd}
                                onChange={(e) => setPoolEnd(e.target.value)}
                            />
                        </label>

                    </div>

                    <label className="registry-form-full">
                        IPs excluidas extra (IP o rango, separadas por coma)
                        <input
                            type="text"
                            placeholder="ej. 192.168.1.200-192.168.1.210"
                            value={exclusions}
                            onChange={(e) => setExclusions(e.target.value)}
                        />
                    </label>

                    <div className="confirm-actions registry-form-actions">

                        <button
                            className="primary-button"
                            onClick={handleApplySegment}
                            disabled={busy}
                        >
                            {busy ? "Aplicando..." : "Cambiar segmento"}
                        </button>

                        <button
                            className="secondary-button"
                            onClick={handleSaveExclusions}
                            disabled={busy}
                        >
                            {busy ? "Guardando..." : "Guardar exclusiones"}
                        </button>

                    </div>

                </div>

            </WriteGuard>

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


function Interfaces() {

    const [diagKey, setDiagKey] = useState(0);


    return (

        <div className="interfaces-page">

            <header className="interfaces-header">
                <h2>Interfaces de red</h2>
                <p>
                    Asigna roles WAN/LAN por tarjeta (identificada por MAC) y
                    configura el segmento DHCP de la red interna.
                </p>
            </header>

            <NetworkDiagnosis refreshKey={diagKey} />

            <InterfaceRegistryPanel onRegistryChange={() => setDiagKey((k) => k + 1)} />

            <LanSegmentPanel />

        </div>

    );

}


export default Interfaces;