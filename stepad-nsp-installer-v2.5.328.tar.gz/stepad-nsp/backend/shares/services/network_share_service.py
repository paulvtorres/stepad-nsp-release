"""
Network disk shares: one share root (disk/folder) + named folders whose
access is granted by device groups (same groups used for web filter /
bandwidth). Samba enforces access by client IP (hosts allow).
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.core.config.paths import SHARE_DISK_MOUNT, SHARE_VOLUMES_ROOT
from backend.core.database.session import SessionLocal
from backend.groups.models.device_group import DeviceGroup, GroupDevice
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.interfaces.services.interface_service import (
    InterfaceService,
)
from backend.shares.models.network_share_folder import (
    GroupFolderAccess,
    NetworkShareFolder,
)
from backend.shares.models.network_share_settings import NetworkShareSettings
from backend.shares.models.network_share_volume import (
    GroupVolumeAccess,
    NetworkShareVolume,
)
from backend.shares.providers.samba_share_provider import SambaShareProvider
from backend.shares.providers.share_disk_mount_provider import (
    ShareDiskMountProvider,
)
from backend.shares.services.share_backup_service import ShareBackupService
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


_FOLDER_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_SHARE_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_SIZE_RE = re.compile(r"^([0-9]+(?:\.[0-9]+)?)\s*([KMGTPE]?)B?$", re.IGNORECASE)

# Nombres reservados de la bóveda de respaldo: NUNCA deben publicarse por
# Samba. Una unidad puede ser a la vez compartida y fuente/destino de
# respaldo; su carpeta privada «Respaldo» (y su config/repo) queda vetada.
_BACKUP_RESERVED_NAMES = {"Respaldo", ".respaldo.json", ".backups", ".stepad-restic"}


def _parse_size_bytes(value) -> int | None:
    """
    Convert lsblk human sizes ('698.6G', '512B', '3.9T') to bytes.
    Returns None when the value cannot be parsed.
    """

    if value is None:
        return None

    if isinstance(value, int):
        return value

    text = str(value).strip()
    if not text:
        return None

    try:
        return int(text)
    except (TypeError, ValueError):
        pass

    match = _SIZE_RE.match(text)
    if not match:
        return None

    factor = {
        "": 1,
        "K": 1024,
        "M": 1024 ** 2,
        "G": 1024 ** 3,
        "T": 1024 ** 4,
        "P": 1024 ** 5,
        "E": 1024 ** 6,
    }[match.group(2).upper()]

    return int(float(match.group(1)) * factor)


# System mountpoints that must never be used as the share root.
_FORBIDDEN_TARGETS = {
    "/",
    "/boot",
    "/boot/efi",
    "/etc",
    "/usr",
    "/var",
    "/home",
    "/root",
    "/tmp",
    "/opt",
}


class NetworkShareService:

    def __init__(self):
        self.provider = SambaShareProvider()
        self.disk_mount = ShareDiskMountProvider()
        self.interface_service = InterfaceService()
        self.backup_service = ShareBackupService()
        self._last_reconcile_at = 0.0

    def reconcile_volumes_if_due(self, db: Session) -> None:
        """Limpia automáticamente directorios fantasma vacíos (rastros de
        configs eliminadas) y detecta volúmenes huérfanos, como máximo cada
        10 minutos. Nunca borra volúmenes ni un disco vivo."""
        import time as _time

        now = _time.monotonic()
        if now - self._last_reconcile_at < 600:
            return
        self._last_reconcile_at = now
        try:
            self.reconcile_storage_state(db)
        except Exception as error:
            logger.warning("Auto-reconcile de almacenamiento falló: %s", error)

    def _sync_folder_backup_job(
        self,
        db: Session,
        folder: NetworkShareFolder,
    ) -> None:
        """
        La política de respaldo de una carpeta se traduce a un job en el
        archivo de configuración de la bóveda (fuente de verdad); ya no se
        crean filas en la base de datos. «off» elimina el job.
        """
        folder_path = self._folder_path(db, folder)
        self.backup_service.ensure_folder_job(
            db,
            folder,
            folder_path or "",
        )

    def _settings(self, db: Session) -> NetworkShareSettings:
        row = db.get(NetworkShareSettings, 1)

        if row is None:
            row = NetworkShareSettings(
                id=1,
                enabled=False,
                share_root=None,
                device_path=None,
                device_uuid=None,
                disk_locked=False,
                workgroup="WORKGROUP",
                integrity_watch_enabled=True,
                integrity_locked=False,
                integrity_change_threshold=80,
            )
            db.add(row)
            db.commit()
            db.refresh(row)

        return row

    def _lan_ip(self) -> str | None:
        lan = self.interface_service.get_primary_lan()
        if not lan:
            return None

        ip = getattr(lan, "ip", None) or getattr(
            lan,
            "ipv4_address",
            None,
        )

        return (
            ip.strip()
            if isinstance(ip, str) and ip.strip()
            else None
        )

    def _run(
        self,
        command: list[str],
        timeout: int = 5,
    ) -> str:
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout,
                env={
                    **os.environ,
                    "LC_ALL": "C",
                    "LANG": "C",
                },
            )

            if result.returncode != 0:
                return ""

            return (result.stdout or "").strip()

        except Exception:
            return ""

    def _parent_disk_name(
        self,
        device: str | None,
    ) -> str | None:
        """
        /dev/sda2 -> sda
        /dev/nvme0n1p3 -> nvme0n1
        /dev/sdb -> sdb
        """

        if not device:
            return None

        device = device.strip()

        if not device.startswith("/dev/"):
            return None

        pkname = self._run(
            ["lsblk", "-no", "PKNAME", device]
        )

        if pkname:
            return pkname.splitlines()[0].strip() or None

        name = self._run(
            ["lsblk", "-no", "NAME", device]
        )

        if name:
            return name.splitlines()[0].strip() or None

        return Path(device).name or None

    def _os_disk_names(self) -> set[str]:
        """
        Physical disks that hold any piece of the Debian installation:
        the root filesystem plus a separate /boot or EFI partition.

        The network-share feature must never list, partition, format or
        share any of these disks.
        """

        names: set[str] = set()

        for target in ("/", "/boot", "/boot/efi"):
            source = self._run(
                ["findmnt", "-n", "-o", "SOURCE", target]
            )

            if source:
                source_path = source.splitlines()[0].strip()
                parent = self._parent_disk_name(source_path)

                if parent:
                    names.add(parent)
                else:
                    names.add(Path(source_path).name or "")

        names.discard("")
        return names

    def _os_disk_name(self) -> str | None:
        """Disk holding the OS root filesystem (for messages/reporting)."""

        source = self._run(
            ["findmnt", "-n", "-o", "SOURCE", "/"]
        )

        if not source:
            os_disks = self._os_disk_names()
            return (
                Path(next(iter(os_disks))).name
                if os_disks
                else None
            )

        source_path = source.splitlines()[0].strip()

        parent = self._parent_disk_name(source_path)

        if parent:
            return parent

        return Path(source_path).name or None

    def _transport_of(
        self,
        disk_name: str | None,
    ) -> str | None:
        if not disk_name:
            return None

        tran = self._run(
            ["lsblk", "-no", "TRAN", f"/dev/{disk_name}"]
        )

        if not tran:
            return None

        return tran.splitlines()[0].strip().lower() or None

    def _model_of(
        self,
        disk_name: str | None,
    ) -> str | None:
        if not disk_name:
            return None

        model = self._run(
            ["lsblk", "-no", "MODEL", f"/dev/{disk_name}"]
        )

        if not model:
            return None

        return model.splitlines()[0].strip() or None

    def _path_backing_disk(
        self,
        path: str,
    ) -> str | None:
        """Parent disk name for whatever device currently backs `path`."""

        source = self._run(
            ["findmnt", "-n", "-o", "SOURCE", "-T", path]
        )

        if not source:
            return None

        return self._parent_disk_name(
            source.splitlines()[0].strip()
        )

    def _is_os_disk_path(
        self,
        path: str,
    ) -> bool:
        os_disks = self._os_disk_names()

        if not os_disks:
            target = self._run(
                ["findmnt", "-n", "-o", "TARGET", "-T", path]
            )

            return (
                target.splitlines()[0].strip()
                if target
                else "/"
            ) == "/"

        backing = self._path_backing_disk(path)
        return backing in os_disks

    def _validate_share_root(
        self,
        root: str,
    ) -> Path:
        """
        Share root must be an absolute path on a secondary disk
        (extra SATA/NVMe/USB), never the OS disk.
        """

        root = (root or "").strip()

        if not root:
            raise HTTPException(
                400,
                "Indica el punto de montaje del disco compartido "
                "(USB o disco adicional, no el del sistema).",
            )

        if ".." in root or not root.startswith("/"):
            raise HTTPException(
                400,
                "La ruta debe ser absoluta.",
            )

        path = Path(root)

        if path.exists() and not path.is_dir():
            raise HTTPException(
                400,
                "La ruta debe ser un directorio.",
            )

        resolved = str(
            path.resolve()
            if path.exists()
            else path
        )

        if (
            resolved.rstrip("/") in _FORBIDDEN_TARGETS
            or resolved == "/"
        ):
            raise HTTPException(
                400,
                "No se puede usar una ruta del sistema operativo "
                "como disco compartido.",
            )

        if not path.exists():
            parent = path.parent

            if not parent.exists():
                raise HTTPException(
                    400,
                    "Monta primero el disco adicional (USB/SATA) y "
                    "elige su punto de montaje. No uses el disco "
                    "del sistema.",
                )

            if self._is_os_disk_path(str(parent)):
                raise HTTPException(
                    400,
                    "Esa ruta está en el disco del sistema operativo. "
                    "Conecta un disco USB o un disco adicional a la "
                    "placa y selecciona su montaje.",
                )

            path.mkdir(
                parents=True,
                exist_ok=True,
            )

        if self._is_os_disk_path(str(path)):
            raise HTTPException(
                400,
                "El disco compartido no puede ser el mismo donde "
                "está el SO. Usa un disco USB o un disco adicional "
                "conectado a la placa.",
            )

        return path

    def list_units(self) -> list[dict]:
        """
        Secondary disk units (partitions with a filesystem) that can
        become managed storage. Excludes the OS disk.
        """

        os_disks = self._os_disk_names()
        units: list[dict] = []

        try:
            result = subprocess.run(
                [
                    "lsblk",
                    "-nbpo",
                    "NAME,TYPE,SIZE,MOUNTPOINT,FSTYPE,UUID,"
                    "PKNAME,TRAN,MODEL,LABEL",
                ],
                capture_output=True,
                text=True,
                timeout=5,
                env={
                    **os.environ,
                    "LC_ALL": "C",
                    "LANG": "C",
                },
            )
        except Exception:
            return units

        if result.returncode != 0:
            return units

        try:
            import json

            js = subprocess.run(
                [
                    "lsblk",
                    "-J",
                    "-b",
                    "-o",
                    "NAME,PATH,TYPE,SIZE,MOUNTPOINT,FSTYPE,UUID,"
                    "PKNAME,TRAN,MODEL,LABEL",
                ],
                capture_output=True,
                text=True,
                timeout=5,
                env={
                    **os.environ,
                    "LC_ALL": "C",
                    "LANG": "C",
                },
            )

            if js.returncode == 0 and js.stdout:
                tree = json.loads(js.stdout)

                return self._units_from_lsblk_tree(
                    tree.get("blockdevices") or [],
                    os_disks,
                    top=True,
                )

        except Exception:
            pass

        return units

    def _units_from_lsblk_tree(
        self,
        devices: list[dict],
        os_disks: set[str] | None,
        parent_disk: str | None = None,
        parent_tran: str | None = None,
        parent_model: str | None = None,
        top: bool = False,
    ) -> list[dict]:

        units: list[dict] = []

        for device in devices:
            name = device.get("name") or ""
            typ = (device.get("type") or "").lower()
            path = device.get("path") or (
                f"/dev/{name}" if name else None
            )
            children = device.get("children") or []

            if top and typ != "disk":
                continue

            if typ == "disk":
                disk_name = name

                if os_disks and disk_name in os_disks:
                    continue

                tran = (
                    device.get("tran")
                    or parent_tran
                    or ""
                ).lower() or None

                model = (
                    device.get("model")
                    or parent_model
                )

                child_units = self._units_from_lsblk_tree(
                    children,
                    os_disks,
                    parent_disk=disk_name,
                    parent_tran=tran,
                    parent_model=model,
                )

                units.extend(child_units)

                if path:
                    part_children = [
                        c
                        for c in children
                        if (c.get("type") or "").lower() == "part"
                    ]

                    part_count = len(part_children)

                    bus = (
                        "USB"
                        if (tran or "") == "usb"
                        else (tran or "disk").upper()
                    )

                    title = f"{bus} · {path}"

                    if model:
                        title = (
                            f"{bus} · {model} · {path}"
                        )

                    if part_count == 0:
                        hint = (
                            "Disco sin particiones. Formatear creará "
                            "una partición ext4."
                        )
                        action_label = "Particionar y usar"
                        suffix = " (sin particiones)"
                    else:
                        hint = (
                            f"Tiene {part_count} partición(es). "
                            "Puedes borrarlas todas y dejar una sola "
                            "partición ext4."
                        )
                        action_label = (
                            "Unificar particiones y usar"
                        )
                        suffix = f" ({part_count} particiones)"

                    units.append({
                        "device": path,
                        "disk": disk_name,
                        "uuid": None,
                        "fstype": None,
                        "size": device.get("size"),
                        "mountpoint": None,
                        "transport": tran or "internal",
                        "model": model,
                        "label": None,
                        "title": title + suffix,
                        "assigned": False,
                        "locked": False,
                        "selectable": False,
                        "formattable": True,
                        "deletable": False,
                        "whole_disk": True,
                        "partition_count": part_count,
                        "action_label": action_label,
                        "hint": hint,
                    })

                continue

            if typ != "part":
                units.extend(
                    self._units_from_lsblk_tree(
                        children,
                        os_disks,
                        parent_disk=parent_disk,
                        parent_tran=parent_tran,
                        parent_model=parent_model,
                    )
                )
                continue

            disk_name = (
                parent_disk
                or device.get("pkname")
            )

            if os_disks and disk_name in os_disks:
                continue

            if not path:
                continue

            fstype = device.get("fstype")
            uuid = device.get("uuid")
            tran = (
                parent_tran
                or device.get("tran")
                or ""
            ).lower() or "internal"

            model = (
                parent_model
                or device.get("model")
            )

            mountpoint = (
                device.get("mountpoint")
                or None
            )

            size = device.get("size")
            label = device.get("label")

            bus = (
                "USB"
                if tran == "usb"
                else (tran or "disk").upper()
            )

            title = f"{bus} · {path}"

            if model:
                title = (
                    f"{bus} · {model} · {path}"
                )

            if label:
                title += f" ({label})"

            has_fs = bool(fstype and uuid)

            units.append({
                "device": path,
                "disk": disk_name,
                "uuid": uuid,
                "fstype": fstype,
                "size": size,
                "mountpoint": mountpoint,
                "transport": tran,
                "model": model,
                "label": label,
                "title": (
                    title
                    if has_fs
                    else f"{title} (sin formato)"
                ),
                "assigned": False,
                "locked": False,
                "selectable": has_fs,
                "formattable": not bool(mountpoint),
                "deletable": True,
                "whole_disk": False,
                "hint": (
                    None
                    if has_fs
                    else (
                        "Formatea en ext4 desde el NSP "
                        "para usar esta partición."
                    )
                ),
            })

        return units

    def format_disk(
        self,
        db: Session,
        device: str,
        *,
        confirm: str,
        assign: bool = True,
        whole_disk: bool = False,
    ) -> dict:
        """
        Format a secondary unit as ext4.
        Requires confirm == 'FORMATEAR'.
        """

        # Doble candado: NUNCA formatear el disco del SO.
        from backend.shares.services.disk_guard import ensure_not_system_disk
        ensure_not_system_disk(device, "formatear")

        if (confirm or "").strip().upper() != "FORMATEAR":
            raise HTTPException(
                400,
                "Para confirmar el borrado escribe FORMATEAR.",
            )

        device = (device or "").strip()

        if not device.startswith("/dev/"):
            device = f"/dev/{device}"

        if not device.startswith("/dev/"):
            raise HTTPException(
                400,
                "Indica una unidad /dev/...",
            )

        os_disks = self._os_disk_names()

        parent = (
            self._parent_disk_name(device)
            or Path(device).name
        )

        disk_name = (
            Path(device).name
            if whole_disk
            else parent
        )

        if os_disks and (
            disk_name in os_disks
            or Path(device).name in os_disks
        ):
            raise HTTPException(
                400,
                "No se puede formatear el disco del sistema operativo.",
            )

        row = self._settings(db)

        if row.disk_locked and row.device_path:
            locked_disk = (
                self._parent_disk_name(row.device_path)
                or Path(row.device_path).name
            )

            target_disk = (
                Path(device).name
                if whole_disk
                else (
                    self._parent_disk_name(device)
                    or Path(device).name
                )
            )

            if (
                row.device_path == device
                or locked_disk == target_disk
                or (
                    row.device_uuid
                    and device.endswith(
                        Path(row.device_path).name
                    )
                )
            ):
                raise HTTPException(
                    400,
                    "Libera el disco compartido antes de "
                    "formatearlo de nuevo.",
                )

        shared = (
            db.query(NetworkShareVolume)
            .filter(
                NetworkShareVolume.device_path == device
            )
            .first()
        )

        if shared:
            raise HTTPException(
                400,
                f"Deja de compartir «{shared.name}» "
                "antes de formatear.",
            )

        if whole_disk:
            parent_name = Path(device).name

            for vol in db.query(
                NetworkShareVolume
            ).all():
                vol_parent = self._parent_disk_name(
                    vol.device_path
                )

                if (
                    vol_parent == parent_name
                    or Path(vol.device_path).name.startswith(
                        parent_name
                    )
                ):
                    raise HTTPException(
                        400,
                        f"Deja de compartir «{vol.name}» "
                        "antes de unificar/formatear el disco.",
                    )

        units = {
            u["device"]: u
            for u in self.list_units()
        }

        unit = units.get(device)

        if not unit or not unit.get("formattable"):
            raise HTTPException(
                400,
                "Esa unidad no se puede formatear "
                "(¿es del SO o está montada?).",
            )

        if unit.get("whole_disk") or whole_disk:
            result = self.disk_mount.prepare_whole_disk(
                device
            )
        else:
            result = self.disk_mount.format_ext4(
                device
            )

        if not result.get("success"):
            raise HTTPException(
                500,
                result.get("message")
                or "Formateo falló.",
            )

        target = result.get("device") or device

        if assign:
            if row.disk_locked and row.device_uuid:
                raise HTTPException(
                    400,
                    "Ya hay un disco compartido. "
                    "Libéralo antes de asignar el nuevo.",
                )

            return self.assign_disk(
                db,
                target,
            )

        status = self.get_status(db)
        status["message"] = result.get("message")
        status["formatted_device"] = target

        return status

    def delete_partition(
        self,
        db: Session,
        device: str,
        *,
        confirm: str,
    ) -> dict:
        """
        Remove a secondary partition.
        Requires confirm == 'ELIMINAR'.
        """

        # Doble candado: NUNCA eliminar una partición del disco del SO.
        from backend.shares.services.disk_guard import ensure_not_system_disk
        ensure_not_system_disk(device, "eliminar la partición")

        if (confirm or "").strip().upper() != "ELIMINAR":
            raise HTTPException(
                400,
                "Para confirmar el borrado escribe ELIMINAR. "
                "Al eliminar la partición se pierde TODO su contenido y "
                "el historial de respaldos ligado a ella (no se puede "
                "recuperar).",
            )

        device = (device or "").strip()

        if not device.startswith("/dev/"):
            device = f"/dev/{device}"

        if not device.startswith("/dev/"):
            raise HTTPException(
                400,
                "Indica una partición /dev/...",
            )

        os_disks = self._os_disk_names()

        parent = self._parent_disk_name(device)

        if os_disks and (
            parent in os_disks
            or Path(device).name in os_disks
        ):
            raise HTTPException(
                400,
                "No se puede eliminar una partición "
                "del disco del sistema.",
            )

        shared = (
            db.query(NetworkShareVolume)
            .filter(
                NetworkShareVolume.device_path == device
            )
            .first()
        )

        if shared:
            # Si la partición está compartida por Samba, se descomparte
            # automáticamente al eliminarla (un solo paso, sin forzar al
            # usuario a hacer dos intentos).
            if shared.sharing:
                try:
                    self.unshare_volume(db, shared.id)
                except HTTPException:
                    pass
                shared = db.get(
                    NetworkShareVolume,
                    shared.id,
                )
            # Desmontar si está montada (por si quedó activa).
            try:
                if (
                    shared
                    and shared.mountpoint
                    and self.disk_mount.is_mounted_at(
                        shared.mountpoint
                    )
                ):
                    unit_name = self.disk_mount.unit_name_for_mount(
                        shared.mountpoint
                    )
                    self.disk_mount.deactivate_unit(
                        unit_name,
                        shared.mountpoint,
                    )
            except Exception as error:
                logger.warning(
                    "delete_partition: no pude desmontar %s: %s",
                    device,
                    error,
                )
            # Eliminar el registro de la partición.
            if shared:
                db.delete(shared)
                db.commit()

        units = {
            u["device"]: u
            for u in self.list_units()
        }

        unit = units.get(device)

        if (
            not unit
            or unit.get("whole_disk")
            or not unit.get("deletable")
        ):
            raise HTTPException(
                400,
                "Esa partición no se puede eliminar "
                "(¿es del SO?).",
            )

        # La programación de respaldo vive ligada a la partición: al
        # eliminar la partición el usuario asume el riesgo, así que se
        # elimina TODO rastro (programación + repo restic) que cargara
        # esta partición como origen o como bóveda de respaldo.
        backup_removed = {"removed_jobs": [], "removed_repos": 0}
        unit_mountpoint = (
            unit.get("mountpoint")
            or (shared.mountpoint if shared else None)
        )

        # No permitir eliminar una partición que está EN USO por un respaldo
        # o una restauración en curso: borrar la partición mientras se
        # escribe/corre sobre ella corrompería el proceso y los datos.
        if unit_mountpoint:
            in_use = self._partition_in_use(unit_mountpoint)
            if in_use:
                raise HTTPException(
                    400,
                    (
                        f"No se puede eliminar la partición {device}: está "
                        f"en uso por {in_use}. Esperá a que termine el "
                        "proceso o detenelo antes de eliminar."
                    ),
                )

        if unit_mountpoint:
            try:
                backup_removed = self.backup_service.delete_jobs_for_mountpoint(unit_mountpoint)
            except Exception as error:
                logger.warning(
                    "delete_partition: no pude limpiar respaldos de %s: %s",
                    device,
                    error,
                )
            # Sin rastros: eliminar también la entrada de la caché de
            # programaciones de la bóveda de esta partición (si quedara, la
            # programación de una partición eliminada podría reaparecer).
            try:
                from backend.shares.services.share_backup_service import VOLUME_RESERVED_NAME
                self.backup_service.remove_schedule_cache_entry(
                    Path(unit_mountpoint.rstrip("/")) / VOLUME_RESERVED_NAME
                )
            except Exception as error:
                logger.warning(
                    "delete_partition: no pude limpiar caché de %s: %s",
                    unit_mountpoint, error,
                )

        result = self.disk_mount.delete_partition(
            device
        )

        if not result.get("success"):
            raise HTTPException(
                500,
                result.get("message")
                or "No se pudo eliminar.",
            )
        if backup_removed.get("removed_jobs"):
            result["message"] = (
                result.get("message") or ""
            ) + f" Se eliminaron {len(backup_removed['removed_jobs'])} programación(es) de respaldo de esta partición ({backup_removed['removed_repos']} repositorio(s) con su historial borrado(s))."
        elif result.get("message") and not backup_removed.get("removed_jobs"):
            # Aunque no hubiera respaldos activos, el contenido se perdió.
            result["message"] = (
                result.get("message") or ""
            ) + " Todo el contenido y el historial de respaldos de esta partición se ha perdido de forma permanente."
        elif not result.get("message"):
            result["message"] = (
                "Partición eliminada. Todo su contenido e historial de respaldos se ha perdido permanentemente."
            )

        # Limpiar el directorio residual que el mountpoint dejó en el root
        # (p. ej. /mnt/stepad-share/sda1): si no se elimina, `_vaults()` lo
        # veía como bóveda fantasma y seguía mostrando la programación aunque
        # la partición ya no exista. Solo se borra si quedó sin bóveda
        # legítima (sin config/repo) o si ya no es una unidad registrada.
        if unit_mountpoint and Path(unit_mountpoint).exists():
            try:
                self._prune_orphan_vault_dir(db, Path(unit_mountpoint))
            except Exception as error:
                logger.warning(
                    "delete_partition: no pude limpiar el dir residual %s: %s",
                    unit_mountpoint,
                    error,
                )

        status = self.get_status(db)
        status["message"] = result.get("message")
        status["deleted_device"] = device

        return status

    def _partition_in_use(self, mountpoint: str) -> str | None:
        """Devuelve un texto si la partición está en uso por un respaldo o
        una restauración en curso (para bloquear su eliminación). None = libre."""
        if not mountpoint:
            return None
        mp = str(mountpoint).rstrip("/")
        # Respaldos corriendo
        try:
            for job_id in (self.backup_service._running_jobs or set()):
                job = self.backup_service._find_job(job_id)
                if job is None:
                    continue
                src = str(job.get("source_path") or "").rstrip("/")
                vault = str(getattr(job, "vault", "") or "").rstrip("/")
                if (src and (src == mp or src.startswith(mp + "/"))) or (
                    vault and (vault == mp or vault.startswith(mp + "/"))
                ):
                    return f"el respaldo «{job.get('name')}»"
        except Exception:
            pass
        # Restauraciones en curso (hacia este mountpoint)
        try:
            for job_id, st in (getattr(self.backup_service, "_restore_status", {}) or {}).items():
                if not (st or {}).get("running"):
                    continue
                job = self.backup_service._find_job(job_id)
                if job is None:
                    continue
                dst = str((st.get("result") or {}).get("restore_to") or "").rstrip("/")
                if dst and (dst == mp or dst.startswith(mp + "/")):
                    return "una restauración de respaldo"
        except Exception:
            pass
        return None

    def _backups_blocking_path(self, mountpoint: str) -> list[str]:
        """Nombres de respaldos cuyo ORIGEN vive dentro de `mountpoint`.

        Impide eliminar una partición cuyas carpetas se están respaldando:
        sin esto, borrar la partición deja la copia huérfana y pierde datos.
        """
        try:
            root = Path(mountpoint).resolve()
        except OSError:
            return []
        blocked: list[str] = []
        try:
            for job in self.backup_service._all_jobs():
                source = str(job.get("source_path") or "")
                if not source:
                    continue
                try:
                    s = Path(source).resolve()
                except OSError:
                    continue
                if s == root or root in s.parents:
                    name = job.get("name") or source
                    if name not in blocked:
                        blocked.append(name)
        except Exception:
            pass
        return blocked

    def _prune_orphan_vault_dir(self, db, mountpoint: Path) -> None:
        """Elimina un directorio residual de unidad en SHARE_ROOT (root).

        Al quitar/desmontar una partición, /mnt/stepad-share/<volumen> puede
        quedar en el filesystem del sistema. `_vaults()` lo seguía viendo
        como bóveda (con su .respaldo.json viejo) y mostraba programaciones
        fantasma. Aquí se borra si ya no es un montaje real ni una unidad
        registrada: al invocarse tras `delete_jobs_for_mountpoint` (que ya
        eliminó programación y repos de la partición), cualquier config/repo
        residual que quede es huérfano y puede borrarse.
        """
        try:
            from backend.shares.services.share_backup_service import (
                is_mountpoint_in_mountinfo,
            )
        except ImportError:
            is_mountpoint_in_mountinfo = None
        root = mountpoint.resolve()
        if root.exists() is False:
            return
        # Nunca borrar algo que sigue montado o que es una unidad activa.
        if is_mountpoint_in_mountinfo is not None and is_mountpoint_in_mountinfo(str(root)):
            return
        still_registered = (
            db.query(NetworkShareVolume)
            .filter(NetworkShareVolume.mountpoint == str(root))
            .first()
        )
        if still_registered:
            return
        try:
            shutil.rmtree(root)
            logger.info("delete_partition: limpiado dir residual %s", root)
        except Exception as error:
            logger.warning("delete_partition: no pude borrar %s: %s", root, error)

    def list_candidate_roots(self) -> list[dict]:
        """Backward-compatible alias: mounted secondary volumes only."""

        return [
            {
                "path": unit["mountpoint"],
                "label": unit["title"],
                "kind": "mount",
                "device": unit["device"],
                "disk": unit["disk"],
                "transport": unit["transport"],
                "model": unit["model"],
                "fstype": unit["fstype"],
                "mounted": True,
                "exists": True,
                "usable": True,
            }
            for unit in self.list_units()
            if unit.get("mountpoint")
            and unit.get("selectable")
        ]

    def assign_disk(
        self,
        db: Session,
        device: str,
    ) -> dict:
        """
        Legacy dedicated share disk:
        mount at SHARE_DISK_MOUNT, persist via systemd, lock it.
        """

        device = (device or "").strip()

        if not device.startswith("/dev/"):
            device = f"/dev/{device}"

        if not device.startswith("/dev/"):
            raise HTTPException(
                400,
                "Indica una unidad /dev/...",
            )

        units = {
            u["device"]: u
            for u in self.list_units()
        }

        unit = units.get(device)

        if not unit:
            raise HTTPException(
                400,
                "Esa unidad no es válida "
                "(¿es el disco del SO o no tiene "
                "sistema de archivos?).",
            )

        uuid = unit["uuid"]
        fstype = unit["fstype"]
        mountpoint = unit.get("mountpoint")

        if (
            mountpoint
            and Path(mountpoint).resolve()
            != SHARE_DISK_MOUNT.resolve()
        ):
            if mountpoint.rstrip("/") in _FORBIDDEN_TARGETS:
                raise HTTPException(
                    400,
                    "No se puede usar una ruta del sistema.",
                )

            raise HTTPException(
                400,
                f"La unidad está montada en {mountpoint}. "
                f"Desmóntala primero o elige otra; el NSP "
                f"la montará en {SHARE_DISK_MOUNT} y la "
                f"dejará protegida.",
            )

        row = self._settings(db)

        if (
            row.disk_locked
            and row.device_uuid
            and row.device_uuid != uuid
        ):
            raise HTTPException(
                400,
                "Ya hay un disco compartido protegido. "
                "Libéralo antes de asignar otra unidad.",
            )

        self.disk_mount.write_mount_unit(
            uuid=uuid,
            fstype=fstype,
        )

        result = self.disk_mount.activate()

        if not result.get("success"):
            raise HTTPException(
                500,
                result.get("message")
                or "No se pudo montar el disco.",
            )

        row.device_path = device
        row.device_uuid = uuid
        row.share_root = str(SHARE_DISK_MOUNT)
        row.disk_locked = True
        row.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(row)

        self.apply(db)

        status = self.get_status(db)
        status["message"] = (
            "Disco asignado como compartido. Queda montado "
            "de forma persistente y no debe desmontarse a mano."
        )

        return status

    def release_disk(
        self,
        db: Session,
    ) -> dict:
        """
        Explicit admin action to unlock/unmount the legacy share disk.
        """

        row = self._settings(db)

        if not row.device_uuid and not row.disk_locked:
            raise HTTPException(
                400,
                "No hay disco compartido asignado.",
            )

        was_enabled = bool(row.enabled)

        row.enabled = False
        db.commit()

        try:
            self.provider.apply(enabled=False)
        except Exception as error:
            logger.warning(
                "Could not stop Samba before release: %s",
                error,
            )

        result = self.disk_mount.deactivate()

        row.device_path = None
        row.device_uuid = None
        row.share_root = None
        row.disk_locked = False
        row.enabled = False
        row.updated_at = datetime.utcnow()

        db.commit()

        status = self.get_status(db)
        status["message"] = (
            result.get("message")
            or "Disco liberado."
        )
        status["release_ok"] = bool(
            result.get("success")
        )
        status["was_enabled"] = was_enabled

        return status

    def list_volumes(
        self,
        db: Session,
    ) -> list[dict]:
        """
        Managed physical volumes.

        A volume is independent from Samba publication:
        - mounted: physical filesystem is available to NSP
        - sharing: volume is published through Samba
        - mount_on_boot: NSP recreates its mount after reboot
        """

        lan_ip = self._lan_ip()

        volumes = (
            db.query(NetworkShareVolume)
            .order_by(NetworkShareVolume.name)
            .all()
        )

        # Descubrimiento en vivo de discos conectados (aunque no haya
        # volúmenes registrados): se construye siempre.
        live = self.list_units()
        live_by_uuid = {
            u.get("uuid"): u
            for u in live
            if u.get("uuid")
        }
        live_by_device = {
            u.get("device"): u
            for u in live
            if u.get("device")
        }

        result = []

        for volume in volumes:
            present = False

            if volume.device_uuid:
                present = (
                    volume.device_uuid
                    in live_by_uuid
                )

            if not present and volume.device_path:
                present = (
                    volume.device_path
                    in live_by_device
                )

            if not present:
                continue

            mounted = self.disk_mount.is_mounted_at(
                volume.mountpoint
            )

            result.append({
                "id": volume.id,
                "name": volume.name,
                "device_path": volume.device_path,
                "device_uuid": volume.device_uuid,
                "mountpoint": volume.mountpoint,
                "sharing": bool(volume.sharing),
                "mounted": mounted,
                "purpose": getattr(
                    volume,
                    "purpose",
                    "shared",
                ) or "shared",
                "mount_on_boot": bool(
                    getattr(
                        volume,
                        "mount_on_boot",
                        True,
                    )
                ),
                "unc_path": (
                    f"\\\\{lan_ip}\\{volume.name}"
                    if lan_ip
                    and volume.sharing
                    else None
                ),
            })

        # El NSP es dinámico: cualquier disco/usb de datos conectado y
        # montado en el explorador (aunque todavía no tenga un registro
        # en network_share_volumes) se ofrece como unidad local para
        # respaldos. Sin esto, un disco recién conectado (o un registro
        # viejo con device erróneo) no aparecería como origen/destino.
        seen_devices = {v["device_path"] for v in result if v.get("device_path")}
        for unit in live:
            device = unit.get("device")
            mountpoint = unit.get("mountpoint")
            if not device or not mountpoint:
                continue
            if device in seen_devices:
                continue
            result.append({
                "id": None,
                "name": (
                    unit.get("label")
                    or Path(device).name
                    or device
                ),
                "device_path": device,
                "device_uuid": unit.get("uuid"),
                "mountpoint": mountpoint,
                "sharing": False,
                "mounted": True,
                "mount_on_boot": False,
                "unc_path": None,
            })

        return result

    def _normalize_share_name(
        self,
        name: str,
    ) -> str:
        name = (name or "").strip()

        if not name:
            raise HTTPException(
                400,
                "Indica un nombre para identificar el compartido.",
            )

        if not _SHARE_NAME_RE.match(name):
            raise HTTPException(
                400,
                "El nombre solo puede usar letras, números, "
                "punto, guion y guion bajo (máx. 64 caracteres).",
            )

        return name

    def _volume_mountpoint(
        self,
        name: str,
    ) -> Path:
        slug = re.sub(
            r"[^A-Za-z0-9._-]+",
            "_",
            name,
        ).strip("._-").lower() or "share"

        SHARE_VOLUMES_ROOT.mkdir(
            parents=True,
            exist_ok=True,
        )

        return SHARE_VOLUMES_ROOT / slug

    def _lan_hosts_allow(self) -> list[str]:
        """LAN CIDRs for Samba when a volume has no group grants yet."""

        import ipaddress

        hosts: list[str] = []

        for lan in self.interface_service.get_lan_interfaces():
            ip = (
                getattr(lan, "ip", None)
                or getattr(
                    lan,
                    "ipv4_address",
                    None,
                )
            )

            mask = getattr(
                lan,
                "subnet_mask",
                None,
            )

            if not ip or not mask:
                continue

            try:
                network = ipaddress.IPv4Network(
                    f"{ip}/{mask}",
                    strict=False,
                )
                hosts.append(str(network))
            except Exception:
                continue

        return hosts

    # ------------------------------------------------------------------
    # Volume lifecycle
    # ------------------------------------------------------------------

    def _ensure_default_backup_job(self, vault_path: str):
        """
        Crea el job de respaldo POR DEFECTO ligado a una partición de
        respaldo recién registrada (la programación va unida a la
        partición). Si la bóveda «Respaldo» ya tiene jobs, no duplica.
        Devuelve un dict con info si creó, o None si no aplica.
        """
        try:
            from backend.shares.services.share_backup_service import (
                VOLUME_RESERVED_NAME,
                BACKUP_SUBDIR,
                CONFIG_FILENAME,
                Job,
                next_global_job_id,
            )

            vault = Path(vault_path)
            vault.mkdir(parents=True, exist_ok=True)
            (vault / BACKUP_SUBDIR).mkdir(parents=True, exist_ok=True)

            config = {}
            config_path = vault / CONFIG_FILENAME
            if config_path.exists():
                import json
                try:
                    config = json.loads(config_path.read_text(encoding="utf-8"))
                except Exception:
                    config = {}

            jobs = config.get("jobs") or []
            if jobs:
                return None

            # Id ÚNICO global (no el next_job_id local de la bóveda): dos
            # particiones backup podían generar el mismo id=1 y el scheduler
            # ejecutaba el job equivocado en loop.
            idx = next_global_job_id()
            record = {
                "id": idx,
                "name": "Respaldo de esta partición",
                "source_path": "",
                "smb_user": "",
                "smb_password": "",
                "enabled": True,
                "schedule_mode": "daily",
                "schedule_hour": 2,
                "schedule_minute": 0,
                "schedule_times": None,
                "interval_minutes": None,
                "retention_count": 7,
                "prune_free_pct": 15,
                "folder_id": None,
                "change_hash": None,
                "tree_hash": None,
                "last_backup_at": None,
                "last_result": None,
                "last_snapshot_id": None,
                "last_bytes": 0,
                "source_missing_alerted": False,
                "consecutive_failures": 0,
                "last_attempt_at": None,
                "failure_alert_active": False,
                "skip_until": None,
                "history": [],
            }

            config["jobs"] = [record]
            config["next_job_id"] = idx + 1
            config["schema"] = config.get("schema", 1)

            import json
            config_path.write_text(
                json.dumps(config, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            logger.info(
                "Auto-creado job por defecto id=%s en bóveda %s",
                idx,
                vault,
            )
            return {"job_id": idx, "vault": str(vault)}
        except Exception as error:
            logger.warning(
                "No se pudo auto-crear la programación de respaldo: %s",
                error,
            )
            return None

    def mount_volume(
        self,
        db: Session,
        *,
        device: str,
        name: str,
        purpose: str = "shared",
    ) -> dict:
        """
        Register and mount a secondary filesystem.

        IMPORTANT:
        Mounting does NOT publish the volume through Samba.

        purpose: "shared" (Samba, queda montada), "backup" (solo se
        monta durante respaldos) o "private" (web-only, se desmonta
        tras inactividad). Las no-shared se registran con
        mount_on_boot=False y NO se montan ahora si están desmontadas:
        su montaje es por demanda.

        Lifecycle:
            physical partition
                -> mounted volume
                -> optionally shared through Samba
        """

        name = self._normalize_share_name(name)

        if purpose not in ("shared", "backup", "private"):
            purpose = "shared"

        device = (device or "").strip()

        if not device.startswith("/dev/"):
            device = f"/dev/{device}"

        if not device.startswith("/dev/"):
            raise HTTPException(
                400,
                "Indica una partición /dev/...",
            )

        os_disks = self._os_disk_names()

        parent = self._parent_disk_name(device)

        if os_disks and (
            parent in os_disks
            or Path(device).name in os_disks
        ):
            raise HTTPException(
                400,
                "No se puede montar una partición "
                "del disco del sistema.",
            )

        uuid = self.disk_mount.blkid_field(
            device,
            "UUID",
        )

        fstype = self.disk_mount.blkid_field(
            device,
            "TYPE",
        )

        if not uuid or not fstype:
            raise HTTPException(
                400,
                "Esa partición no tiene sistema de archivos. "
                "Formateala primero.",
            )

        existing_uuid = (
            db.query(NetworkShareVolume)
            .filter(
                NetworkShareVolume.device_uuid == uuid
            )
            .first()
        )

        if existing_uuid:
            mountpoint = Path(
                existing_uuid.mountpoint
            )

            existing_uuid.device_path = device
            existing_uuid.updated_at = datetime.utcnow()

            # Respetar el rol solicitado al registrar (p. ej. al crear una
            # partición marcada como backup) en lugar de conservar el old
            # del registro previo.
            if purpose != getattr(existing_uuid, "purpose", "shared"):
                existing_uuid.purpose = purpose
                existing_uuid.sharing = False

            purpose = getattr(existing_uuid, "purpose", "shared") or "shared"

            if purpose in ("backup", "private"):
                # No-shared: se registra pero NO se monta ahora; lo hará
                # el respaldo/la web por demanda.
                existing_uuid.mount_on_boot = False
                if purpose == "backup":
                    # Asegurar la programación por defecto ligada a la
                    # partición (si el registro existía sin su job).
                    try:
                        self._ensure_default_backup_job(
                            str(mountpoint / "Respaldo")
                        )
                    except Exception as error:
                        logger.warning(
                            "mount_volume: no pude crear job por defecto de %s: %s",
                            device,
                            error,
                        )
                db.commit()
                db.refresh(existing_uuid)
                status = self.get_status(db)
                status["message"] = (
                    f"«{existing_uuid.name}» registrado como {purpose} "
                    "(no se monta solo; se monta por demanda)."
                )
                return status

            existing_uuid.mount_on_boot = True

            if self.disk_mount.is_mounted_at(
                mountpoint
            ):
                db.commit()
                db.refresh(existing_uuid)

                status = self.get_status(db)
                status["message"] = (
                    f"«{existing_uuid.name}» ya estaba montado."
                )

                return status

            unit = self.disk_mount.write_volume_mount_unit(
                uuid=uuid,
                fstype=fstype,
                mountpoint=mountpoint,
            )

            activated = self.disk_mount.activate_unit(
                unit,
                mountpoint,
            )

            if not activated.get("success"):
                db.rollback()

                raise HTTPException(
                    500,
                    activated.get("message")
                    or "No se pudo montar la partición.",
                )

            try:
                os.chmod(
                    mountpoint,
                    0o775,
                )
                shutil.chown(
                    mountpoint,
                    user="nobody",
                    group="nogroup",
                )
            except Exception as error:
                logger.warning(
                    "Could not set permissions on volume "
                    "mount %s: %s",
                    mountpoint,
                    error,
                )

            db.commit()
            db.refresh(existing_uuid)

            status = self.get_status(db)
            status["message"] = (
                f"«{existing_uuid.name}» fue montado nuevamente."
            )

            return status

        existing_name = (
            db.query(NetworkShareVolume)
            .filter(
                NetworkShareVolume.name == name
            )
            .first()
        )

        if existing_name:
            raise HTTPException(
                400,
                f"Ya existe un volumen llamado «{name}». "
                "Elige otro nombre.",
            )

        mountpoint = self._volume_mountpoint(name)

        if (
            mountpoint.exists()
            and any(mountpoint.iterdir())
            and not self.disk_mount.is_mounted_at(
                mountpoint
            )
        ):
            # Directorio residual de un registro/unidad previo que ya no está
            # montado ni activo (p. ej. quedó tras eliminar/desmontar la
            # partición, con su carpeta «Respaldo» y .respaldo.json viejo).
            # En vez de rechazar la creación, se limpia el residuo si no es
            # un montaje real ni un volumen registrado: así recrear una
            # partición con el mismo nombre funciona sin fricción.
            try:
                from backend.shares.services.share_backup_service import (
                    is_mountpoint_in_mountinfo,
                )
                is_real_mount = is_mountpoint_in_mountinfo(str(mountpoint))
            except Exception:
                is_real_mount = False
            still_registered = (
                db.query(NetworkShareVolume)
                .filter(NetworkShareVolume.mountpoint == str(mountpoint))
                .first()
            )
            if is_real_mount or still_registered:
                raise HTTPException(
                    400,
                    f"El directorio {mountpoint} ya existe "
                    "y no está vacío. Usa otro nombre.",
                )
            logger.info(
                "mount_volume: limpiando dir residual %s para registrar la unidad.",
                mountpoint,
            )
            try:
                shutil.rmtree(mountpoint)
            except Exception as error:
                raise HTTPException(
                    400,
                    f"El directorio {mountpoint} ya existe, no está vacío "
                    f"y no pude limpiarlo automáticamente: {error}",
                )

        on_demand = purpose in ("backup", "private")

        if on_demand:
            # No-shared: solo se registra (el mountpoint se crea al
            # montar). NO se monta ahora: lo hará el respaldo o la web.
            mountpoint.parent.mkdir(parents=True, exist_ok=True)
            mountpoint.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(mountpoint, 0o750)
            except Exception:
                pass
            volume = NetworkShareVolume(
                name=name,
                device_path=device,
                device_uuid=uuid,
                mountpoint=str(mountpoint),
                sharing=False,
                mount_on_boot=False,
                purpose=purpose,
                updated_at=datetime.utcnow(),
            )
            db.add(volume)
            db.commit()
            db.refresh(volume)

            # La programación va ligada a la partición: al crear una
            # partición de respaldo se crea AUTOMÁTICAMENTE su job por
            # defecto en la bóveda «Respaldo». Solo falta elegir el
            # origen; el destino ya es esta misma partición.
            #
            # IMPORTANTE: el job debe quedar DENTRO de la partición (no en
            # el directorio del mountpoint en el root). Si se escribe en el
            # root y la partición es de montaje por demanda, al montarla el
            # config creado queda oculto por el mount y el scheduler ya no
            # ve la programación (se "perdía"). Por eso se monta la
            # partición aquí, se crea el config dentro, y luego se desmonta
            # (quedará montada por demanda cuando corra el respaldo).
            auto_job = None
            mounted_here = False
            if purpose == "backup":
                try:
                    from backend.shares.providers.share_disk_mount_provider import (
                        ShareDiskMountProvider,
                    )
                    provider_mount = ShareDiskMountProvider()
                    if not provider_mount.is_mounted_at(str(mountpoint)):
                        mounted = provider_mount.mount_now(
                            uuid=uuid,
                            mountpoint=str(mountpoint),
                        )
                        if mounted.get("success"):
                            mounted_here = True
                    auto_job = self._ensure_default_backup_job(
                        str(mountpoint / "Respaldo")
                    )
                except Exception as error:
                    logger.warning(
                        "mount_volume backup: no pude crear job dentro de %s: %s",
                        mountpoint,
                        error,
                    )
                finally:
                    if mounted_here:
                        try:
                            provider_mount.unmount_now(str(mountpoint))
                        except Exception:
                            pass

            status = self.get_status(db)
            status["message"] = (
                f"«{name}» registrado como {purpose} y queda desmontado. "
                "Se monta solo cuando se respalda (backup) o se accede "
                "por la web (private)."
            )
            if auto_job:
                status["message"] += (
                    " Se creó la programación de respaldo por defecto; "
                    "elige el origen en Respaldos de datos."
                )
            return status

        mountpoint.mkdir(parents=True, exist_ok=True)

        unit = self.disk_mount.write_volume_mount_unit(
            uuid=uuid,
            fstype=fstype,
            mountpoint=mountpoint,
        )

        activated = self.disk_mount.activate_unit(
            unit,
            mountpoint,
        )

        if not activated.get("success"):
            raise HTTPException(
                500,
                activated.get("message")
                or "No se pudo montar la partición.",
            )

        try:
            os.chmod(
                mountpoint,
                0o775,
            )
            shutil.chown(
                mountpoint,
                user="nobody",
                group="nogroup",
            )
        except Exception as error:
            logger.warning(
                "Could not set permissions on volume "
                "mount %s: %s",
                mountpoint,
                error,
            )

        volume = NetworkShareVolume(
            name=name,
            device_path=device,
            device_uuid=uuid,
            mountpoint=str(mountpoint),
            sharing=False,
            mount_on_boot=True,
            purpose=purpose,
            updated_at=datetime.utcnow(),
        )

        db.add(volume)
        db.commit()
        db.refresh(volume)

        status = self.get_status(db)
        status["message"] = (
            f"«{name}» montado correctamente. "
            "Todavía no está publicado por Samba."
        )

        return status

    def unmount_volume(
        self,
        db: Session,
        volume_id: int,
    ) -> dict:
        """
        Unmount a managed volume.

        The DB record is preserved because the volume still belongs
        to NSP and can be mounted again later.

        A shared volume must be unshared first.
        """

        volume = db.get(
            NetworkShareVolume,
            volume_id,
        )

        if not volume:
            raise HTTPException(
                404,
                "Volumen no encontrado.",
            )

        if volume.sharing:
            raise HTTPException(
                400,
                f"Primero deja de compartir «{volume.name}» "
                "y luego desmonta la unidad.",
            )

        name = volume.name
        mountpoint = volume.mountpoint
        unit = self.disk_mount.unit_name_for_mount(
            mountpoint
        )

        result = self.disk_mount.deactivate_unit(
            unit,
            mountpoint,
        )

        if not result.get("success"):
            raise HTTPException(
                500,
                result.get("message")
                or f"No se pudo desmontar «{name}».",
            )

        volume.mount_on_boot = False
        volume.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(volume)

        status = self.get_status(db)
        status["message"] = (
            f"«{name}» fue desmontado."
        )
        status["unmount_ok"] = True

        return status

    def update_volume_purpose(
        self,
        db: Session,
        volume_id: int,
        purpose: str,
    ) -> dict:
        """
        Cambia la finalidad (shared|backup|private) de una partición ya
        registrada. No requiere recrear ni formatear la partición.

        - "shared": queda montada y publicable por Samba.
        - "backup": se desmonta (si estaba montada) y solo se monta
          durante respaldos/restauraciones.
        - "private": se desmonta (si estaba) y solo se monta al usar la
          web privada; se desmonta sola tras inactividad.
        """
        purpose = (purpose or "").strip().lower()
        if purpose not in ("shared", "backup", "private"):
            raise HTTPException(400, "Finalidad debe ser shared, backup o private.")

        volume = db.get(NetworkShareVolume, volume_id)
        if not volume:
            raise HTTPException(404, "Volumen no encontrado.")

        # Si pasa a no-compartir ni compartir, y estaba compartida... Solo
        # se permite si está descompartida (o se descomparte aquí).
        old = getattr(volume, "purpose", "shared") or "shared"

        if purpose != "shared" and volume.sharing:
            raise HTTPException(
                400,
                f"Primero deja de compartir «{volume.name}» (es finalidad "
                "shared) para poder marcarla como backup/private.",
            )

        volume.purpose = purpose
        volume.updated_at = datetime.utcnow()

        if purpose == "shared":
            volume.mount_on_boot = True
            # Si no está montada, se monta ahora (queda persistente).
            if not self.disk_mount.is_mounted_at(volume.mountpoint):
                unit = self.disk_mount.write_volume_mount_unit(
                    uuid=volume.device_uuid,
                    fstype=self.disk_mount.blkid_field(volume.device_path, "TYPE") or "ext4",
                    mountpoint=volume.mountpoint,
                )
                activated = self.disk_mount.activate_unit(unit, volume.mountpoint)
                if not activated.get("success"):
                    db.rollback()
                    raise HTTPException(
                        500,
                        activated.get("message") or "No se pudo montar.",
                    )
        else:
            volume.mount_on_boot = False
            # No-shared: desmontar ahora si está montada (por demanda).
            if self.disk_mount.is_mounted_at(volume.mountpoint):
                try:
                    unit = self.disk_mount.unit_name_for_mount(volume.mountpoint)
                    self.disk_mount.deactivate_unit(unit, volume.mountpoint)
                except Exception as error:
                    logger.warning(
                        "update_volume_purpose: no pude desmontar %s: %s",
                        volume.name,
                        error,
                    )

        db.commit()
        db.refresh(volume)

        status = self.get_status(db)
        status["message"] = (
            f"«{volume.name}» ahora es una partición "
            f"{purpose}."
        )
        return status

    def share_volume(
        self,
        db: Session,
        *,
        volume_id: int,
    ) -> dict:
        """
        Publish an already-mounted managed volume through Samba.

        IMPORTANT:
        This method does NOT mount the device.
        """

        volume = db.get(
            NetworkShareVolume,
            volume_id,
        )

        if not volume:
            raise HTTPException(
                404,
                "Volumen no encontrado.",
            )

        if not volume.mountpoint:
            raise HTTPException(
                400,
                "El volumen no tiene punto de montaje.",
            )

        if not self.disk_mount.is_mounted_at(
            volume.mountpoint
        ):
            raise HTTPException(
                400,
                f"«{volume.name}» no está montado. "
                "Móntalo primero.",
            )

        if volume.sharing:
            raise HTTPException(
                400,
                f"«{volume.name}» ya está compartido.",
            )

        purpose = getattr(volume, "purpose", "shared") or "shared"
        if purpose in ("backup", "private"):
            raise HTTPException(
                400,
                f"«{volume.name}» es una partición de rol «{purpose}»; "
                "no se puede publicar por Samba. Solo las particiones "
                "«Compartidas» se comparten por red.",
            )

        volume.sharing = True
        volume.mount_on_boot = True
        volume.updated_at = datetime.utcnow()

        row = self._settings(db)
        row.enabled = True
        row.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(volume)

        self.apply(db)

        lan_ip = self._lan_ip()

        status = self.get_status(db)

        status["message"] = (
            f"«{volume.name}» compartido. "
            f"En Windows: "
            f"\\\\{lan_ip or 'IP'}\\{volume.name}"
            if lan_ip
            else f"«{volume.name}» compartido."
        )

        return status

    def unshare_volume(
        self,
        db: Session,
        volume_id: int,
    ) -> dict:
        """
        Withdraw a volume from Samba.

        IMPORTANT:
        Unsharing does NOT unmount the filesystem.

        The volume remains:
            - registered in DB
            - mounted
            - available to the NSP explorer
            - available for private folders
            - available for backup operations

        Only its Samba publication is removed.
        """

        volume = db.get(
            NetworkShareVolume,
            volume_id,
        )

        if not volume:
            raise HTTPException(
                404,
                "Volumen no encontrado.",
            )

        name = volume.name

        if not volume.sharing:
            raise HTTPException(
                400,
                f"«{name}» no está compartido.",
            )

        volume.sharing = False
        volume.updated_at = datetime.utcnow()

        remaining = (
            db.query(NetworkShareVolume)
            .filter(
                NetworkShareVolume.sharing.is_(True)
            )
            .filter(
                NetworkShareVolume.id != volume_id
            )
            .count()
        )

        row = self._settings(db)

        if remaining == 0:
            row.enabled = False

        row.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(volume)

        self.apply(db)

        status = self.get_status(db)
        status["message"] = (
            f"Se dejó de compartir «{name}». "
            "La unidad permanece montada para el NSP."
        )
        status["unshare_ok"] = True

        return status

    def reconcile_storage_state(self, db: Session) -> dict:
        """Auto-repara registros y limpia rastros de forma SEGURA:
        - elimina directorios FANTASMA (vacíos, no montados, sin volumen
          registrado ni dispositivo vivo) que quedan de configs eliminadas;
        - no borra volúmenes: los huérfanos se listan para purga explícita.
        Nunca toca un montaje real ni el disco del sistema."""
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        provider = ShareDiskMountProvider()
        live_names = set()
        out = provider._run(["lsblk", "-n", "-o", "NAME"])
        text = (
            out.stdout
            if isinstance(out, subprocess.CompletedProcess)
            else (out or "")
        )
        for line in text.splitlines():
            name = line.strip()
            if name:
                live_names.add(name)

        volumes = db.query(NetworkShareVolume).all()
        mp_by_vol = {
            str(getattr(v, "mountpoint", "") or "").rstrip("/") for v in volumes
        }

        removed = []
        root = SHARE_VOLUMES_ROOT
        if root.is_dir():
            for entry in root.iterdir():
                if not entry.is_dir():
                    continue
                if provider.is_mounted_at(entry):
                    continue
                entry_str = str(entry).rstrip("/")
                if entry_str in mp_by_vol:
                    continue
                if entry.name in live_names:
                    continue
                if not any(entry.iterdir()):
                    try:
                        shutil.rmtree(entry)
                        removed.append(entry_str)
                        logger.info("Director fantasma eliminado: %s", entry)
                    except OSError as err:
                        logger.warning("No se pudo eliminar %s: %s", entry, err)

        orphans = []
        healed = []
        for volume in volumes:
            real = provider.resolve_device(
                uuid=volume.device_uuid,
                device_path=volume.device_path,
            )
            mp = str(getattr(volume, "mountpoint", "") or "").rstrip("/")
            mounted = bool(mp and provider.is_mounted_at(mp))
            if real is not None:
                # SELF-HEAL de identidad: el dispositivo se resolvió VERIFICADO
                # (by-uuid o identidad coincidió). Si el UUID/letra cambió
                # (reformateo/renumeración), el registro se corrige SOLO ->
                # nunca queda un descriptor con UUID/ruta viejos.
                try:
                    cur_uuid = provider.blkid_field(real, "UUID")
                    plain = real
                    try:
                        plain = os.path.realpath(real)
                    except Exception:
                        pass
                    changed_uuid = bool(
                        cur_uuid and cur_uuid != volume.device_uuid
                    )
                    changed_path = bool(
                        plain and plain != volume.device_path
                    )
                    if changed_uuid or changed_path:
                        new_uuid = cur_uuid or volume.device_uuid
                        new_path = plain or volume.device_path
                        volume.device_uuid = new_uuid
                        volume.device_path = new_path
                        volume.updated_at = datetime.utcnow()
                        db.commit()
                        healed.append({
                            "id": volume.id,
                            "name": volume.name,
                            "old_uuid": (
                                None if not changed_uuid else volume.device_uuid
                            ),
                            "new_uuid": new_uuid if changed_uuid else None,
                            "path": new_path if changed_path else None,
                        })
                        logger.info(
                            "Self-heal identidad volumen %s: %s -> %s (uuid %s)",
                            volume.name, volume.device_path, new_path, new_uuid,
                        )
                except Exception as error:
                    logger.warning("Self-heal de %s falló: %s", volume.name, error)
                continue
            if not mounted:
                orphans.append({
                    "id": volume.id,
                    "name": volume.name,
                    "purpose": volume.purpose,
                    "mountpoint": mp,
                    "device_uuid": volume.device_uuid,
                })

        return {
            "reconciled": True,
            "ghost_dirs_removed": removed,
            "self_healed": healed,
            "orphan_volumes": orphans,
        }

    def purge_orphan_volume(self, db: Session, volume_id: int) -> dict:
        """Elimina SIN RASTROS un volumen huérfano (su disco ya no existe):
        descomparte, borra carpetas, purga la caché de respaldos y quita su
        directorio de montaje si quedó vacío. Si el volumen aún tiene DISCO
        vivo o está montado, se niega por seguridad."""
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        volume = db.get(NetworkShareVolume, volume_id)
        if volume is None:
            raise HTTPException(404, "Volumen no encontrado.")

        provider = ShareDiskMountProvider()
        mp = str(getattr(volume, "mountpoint", "") or "").rstrip("/")
        if provider.is_mounted_at(mp):
            raise HTTPException(400, f"«{volume.name}» está montado; no se purga.")
        real = provider.resolve_device(
            uuid=volume.device_uuid,
            device_path=volume.device_path,
        )
        if real is not None:
            raise HTTPException(
                400,
                f"«{volume.name}» tiene dispositivo vivo ({real}); "
                "no es huérfana. Usá el flujo normal de eliminación.",
            )

        name = volume.name
        try:
            if volume.sharing:
                self.unshare_volume(db, volume_id)
        except Exception as error:
            logger.warning("purge: no pude descompartir %s: %s", name, error)

        folders = (
            db.query(NetworkShareFolder)
            .filter(NetworkShareFolder.volume_id == volume.id)
            .all()
        )
        for folder in folders:
            try:
                self.delete_folder(db, folder.id)
            except Exception as error:
                logger.warning("purge: no pude borrar carpeta %s: %s", folder.name, error)

        if mp:
            try:
                from backend.shares.services.share_backup_service import (
                    VOLUME_RESERVED_NAME,
                )
                self.backup_service.remove_schedule_cache_entry(
                    Path(mp.rstrip("/")) / VOLUME_RESERVED_NAME
                )
            except Exception as error:
                logger.warning("purge: no pude purgar caché de %s: %s", mp, error)

        db.delete(volume)
        db.commit()

        if mp:
            candidate = Path(mp)
            if candidate.is_dir() and not any(candidate.iterdir()):
                try:
                    candidate.rmdir()
                except OSError as error:
                    logger.warning("purge: no pude quitar dir %s: %s", mp, error)

        return {
            "success": True,
            "deleted_name": name,
            "mountpoint": mp or None,
            "message": f"Volumen huérfano «{name}» eliminado sin rastros.",
        }

    def get_status(
        self,
        db: Session,
    ) -> dict:
        self.reconcile_volumes_if_due(db)
        row = self._settings(db)
        runtime = self.provider.status()
        folders = self.list_folders(db)
        volumes = self.list_volumes(db)
        lan_ip = self._lan_ip()
        os_disk = self._os_disk_name()

        root_ok = False
        root_error = None

        if row.share_root:
            try:
                self._validate_share_root(
                    row.share_root
                )
                root_ok = True
            except HTTPException as error:
                root_error = error.detail

        by_uuid = {
            v["device_uuid"]: v
            for v in volumes
        }

        by_device = {
            v["device_path"]: v
            for v in volumes
        }

        units = self.list_units()

        for unit in units:
            vol = None

            if (
                unit.get("uuid")
                and unit["uuid"] in by_uuid
            ):
                vol = by_uuid[unit["uuid"]]

            elif (
                unit.get("device")
                and unit["device"] in by_device
            ):
                vol = by_device[unit["device"]]

            if vol:
                unit["sharing"] = bool(
                    vol["sharing"]
                )
                unit["share_name"] = vol["name"]
                unit["volume_id"] = vol["id"]
                unit["unc_path"] = vol["unc_path"]
                unit["mounted"] = bool(
                    vol["mounted"]
                )
                unit["mount_on_boot"] = bool(
                    vol["mount_on_boot"]
                )
                unit["assigned"] = True
                unit["locked"] = False

            else:
                unit["sharing"] = False
                unit["share_name"] = None
                unit["volume_id"] = None
                unit["unc_path"] = None
                unit["mount_on_boot"] = False

                if (
                    row.device_uuid
                    and unit.get("uuid")
                    == row.device_uuid
                ):
                    unit["assigned"] = True
                    unit["locked"] = bool(
                        row.disk_locked
                    )

                elif (
                    row.device_path
                    and unit.get("device")
                    == row.device_path
                ):
                    unit["assigned"] = True
                    unit["locked"] = bool(
                        row.disk_locked
                    )

        mounted = self.disk_mount.is_mounted_at(
            SHARE_DISK_MOUNT
        )

        any_volume = any(
            v.get("sharing")
            for v in volumes
        )

        return {
            "enabled": (
                bool(row.enabled)
                or any_volume
            ),
            "share_root": row.share_root,
            "share_root_ok": root_ok,
            "share_root_error": root_error,
            "device_path": row.device_path,
            "device_uuid": row.device_uuid,
            "disk_locked": bool(
                row.disk_locked
            ),
            "mountpoint": str(
                SHARE_DISK_MOUNT
            ),
            "mounted": mounted,
            "os_disk": (
                f"/dev/{os_disk}"
                if os_disk
                else None
            ),
            "workgroup": row.workgroup,
            "server_name": row.server_name,
            "updated_at": (
                to_iso_utc(row.updated_at)
                if row.updated_at
                else None
            ),
            "lan_ip": lan_ip,
            "unc_base": (
                f"\\\\{lan_ip}"
                if lan_ip
                else None
            ),
            "samba": runtime,
            "folders": folders,
            "volumes": volumes,
            "units": units,
            "candidates": self.list_candidate_roots(),
            "integrity": {
                "watch_enabled": bool(
                    getattr(
                        row,
                        "integrity_watch_enabled",
                        True,
                    )
                ),
                "locked": bool(
                    getattr(
                        row,
                        "integrity_locked",
                        False,
                    )
                ),
                "locked_at": (
                    to_iso_utc(
                        row.integrity_locked_at
                    )
                    if getattr(
                        row,
                        "integrity_locked_at",
                        None,
                    )
                    else None
                ),
                "detail": getattr(
                    row,
                    "integrity_lock_detail",
                    None,
                ),
                "change_threshold": int(
                    getattr(
                        row,
                        "integrity_change_threshold",
                        None,
                    )
                    or 80
                ),
                "paused": self.is_integrity_paused(
                    db,
                    row=row,
                ),
                "paused_until": (
                    to_iso_utc(
                        row.integrity_paused_until
                    )
                    if getattr(
                        row,
                        "integrity_paused_until",
                        None,
                    )
                    and self.is_integrity_paused(
                        db,
                        row=row,
                    )
                    else None
                ),
            },
            "disk_health": self._disk_health_status(
                db
            ),
            "disks": self.list_disk_layout(db),
            "ready": bool(
                any_volume
                and runtime.get("installed")
                and runtime.get("smbd_active")
            )
            or bool(
                row.enabled
                and root_ok
                and row.disk_locked
                and mounted
                and runtime.get("installed")
                and runtime.get("smbd_active")
            ),
        }

    def list_disk_layout(
        self,
        db: Session,
    ) -> list[dict]:
        """
        Windows-setup style disk map: secondary disks with partitions,
        sizes and free space (never the OS disk).
        """

        os_disks = self._os_disk_names()
        units = self.list_units()
        volumes = self.list_volumes(db)

        by_uuid = {
            v["device_uuid"]: v
            for v in volumes
        }

        by_device = {
            v["device_path"]: v
            for v in volumes
        }

        disks_map: dict[str, dict] = {}

        for unit in units:
            if unit.get("whole_disk"):
                disk_name = (
                    unit.get("disk")
                    or Path(
                        unit["device"]
                    ).name
                )

                path = unit["device"]

                if (
                    os_disks
                    and disk_name in os_disks
                ):
                    continue

                key = disk_name

                if key not in disks_map:
                    size_b = _parse_size_bytes(
                        unit.get("size")
                    )

                    if size_b is None:
                        size_b = (
                            self.disk_mount.disk_size_bytes(
                                path
                            )
                        )

                    disks_map[key] = {
                        "device": path,
                        "disk": disk_name,
                        "model": unit.get("model"),
                        "transport": (
                            unit.get("transport")
                            or "internal"
                        ),
                        "size": size_b,
                        "partitions": [],
                        "empty": True,
                    }

                continue

            disk_name = unit.get("disk")

            if not disk_name:
                continue

            if (
                os_disks
                and disk_name in os_disks
            ):
                continue

            path = f"/dev/{disk_name}"

            if disk_name not in disks_map:
                size_b = (
                    self.disk_mount.disk_size_bytes(
                        path
                    )
                )

                disks_map[disk_name] = {
                    "device": path,
                    "disk": disk_name,
                    "model": unit.get("model"),
                    "transport": (
                        unit.get("transport")
                        or "internal"
                    ),
                    "size": size_b,
                    "partitions": [],
                    "empty": False,
                }

            vol = None

            if (
                unit.get("uuid")
                and unit["uuid"] in by_uuid
            ):
                vol = by_uuid[
                    unit["uuid"]
                ]

            elif (
                unit.get("device")
                and unit["device"] in by_device
            ):
                vol = by_device[
                    unit["device"]
                ]

            part_size = _parse_size_bytes(
                unit.get("size")
            )

            disks_map[disk_name][
                "partitions"
            ].append({
                "device": unit.get("device"),
                "size": part_size,
                "fstype": unit.get("fstype"),
                "uuid": unit.get("uuid"),
                "label": unit.get("label"),
                "mountpoint": (
                    vol["mountpoint"]
                    if vol
                    else unit.get("mountpoint")
                ),
                "mounted": (
                    bool(vol["mounted"])
                    if vol
                    else bool(
                        unit.get("mountpoint")
                    )
                ),
                "mount_on_boot": (
                    bool(vol["mount_on_boot"])
                    if vol
                    else False
                ),
                "selectable": bool(
                    unit.get("selectable")
                ),
                "formattable": bool(
                    unit.get("formattable")
                ),
                "deletable": bool(
                    unit.get(
                        "deletable",
                        True,
                    )
                ),
                "sharing": bool(
                    vol and vol["sharing"]
                ),
                "share_name": (
                    vol["name"]
                    if vol
                    else None
                ),
                "volume_id": (
                    vol["id"]
                    if vol
                    else None
                ),
                "purpose": (
                    vol.get("purpose") or "shared"
                    if vol
                    else None
                ),
                "unc_path": (
                    vol["unc_path"]
                    if vol
                    else None
                ),
            })
            # Espacio usado/total/libre real de la partición (df). Aplica a
            # TODAS las unidades (compartida, privada, de respaldo, USB y
            # remotas montadas): si la partición registrada está DESMONTADA
            # se monta por demanda sólo para medir y luego se devuelve a su
            # estado.
            part_mountpoint = (
                vol["mountpoint"]
                if vol
                else unit.get("mountpoint")
            )
            mount_now_here = None
            if part_mountpoint:
                try:
                    real_mount = is_mountpoint_in_mountinfo(str(part_mountpoint))
                except Exception:
                    real_mount = False
                if not real_mount and vol:
                    try:
                        from backend.shares.providers.share_disk_mount_provider import (
                            ShareDiskMountProvider,
                        )
                        p = ShareDiskMountProvider()
                        if not p.is_mounted_at(part_mountpoint):
                            r = p.mount_now(
                                uuid=vol["device_uuid"],
                                mountpoint=part_mountpoint,
                            )
                            if r.get("success"):
                                mount_now_here = part_mountpoint
                    except Exception as m_error:
                        logger.warning(
                            "list_disk_layout: no pude montar para medir %s: %s",
                            part_mountpoint, m_error,
                        )
            if part_mountpoint and Path(part_mountpoint).exists():
                try:
                    usage = shutil.disk_usage(part_mountpoint)
                    disks_map[disk_name]["partitions"][-1]["total_bytes"] = usage.total
                    disks_map[disk_name]["partitions"][-1]["used_bytes"] = usage.used
                    disks_map[disk_name]["partitions"][-1]["free_bytes"] = usage.free
                except OSError:
                    pass
            if mount_now_here:
                try:
                    from backend.shares.providers.share_disk_mount_provider import (
                        ShareDiskMountProvider,
                    )
                    ShareDiskMountProvider().unmount_now(mount_now_here)
                except Exception:
                    pass

            disks_map[disk_name][
                "empty"
            ] = False

        result = []

        for disk in disks_map.values():
            used = sum(
                p["size"] or 0
                for p in disk["partitions"]
            )

            size = disk.get("size") or 0

            free = (
                max(
                    0,
                    size - used,
                )
                if size
                else 0
            )

            try:
                regions = (
                    self.disk_mount.free_regions_mib(
                        disk["device"]
                    )
                )

                if regions:
                    free = int(
                        sum(
                            r["size_mib"]
                            for r in regions
                        )
                        * 1024
                        * 1024
                    )

            except Exception:
                pass

            bus = (
                "USB"
                if (
                    disk.get("transport")
                    or ""
                ).lower()
                == "usb"
                else (
                    disk.get("transport")
                    or "disk"
                ).upper()
            )

            result.append({
                **disk,
                "bus": bus,
                "used": used,
                "free": free,
                "partition_count": len(
                    disk["partitions"]
                ),
                "can_create_partition": (
                    free >= 64 * 1024 * 1024
                    or disk.get("empty")
                ),
            })

        result.sort(
            key=lambda d: d.get("device") or ""
        )

        return result

    def create_partition(
        self,
        db: Session,
        disk: str,
        *,
        size_gb: float | None = None,
        use_remaining: bool = False,
        role: str = "share",
        label: str | None = None,
    ) -> dict:
        """
        Create a formatted partition in free space on a secondary disk.

        role: share | backup
        """

        disk = (disk or "").strip()

        if not disk.startswith("/dev/"):
            raise HTTPException(
                400,
                "Indica un disco /dev/...",
            )

        # Doble candado: NUNCA particionar el disco del SO.
        from backend.shares.services.disk_guard import ensure_not_system_disk
        ensure_not_system_disk(disk, "crear particiones en")

        os_disks = self._os_disk_names()
        name = Path(disk).name

        if os_disks and name in os_disks:
            raise HTTPException(
                400,
                "No se puede particionar el disco del sistema.",
            )

        layout = {
            d["device"]: d
            for d in self.list_disk_layout(db)
        }

        if disk not in layout:
            layout = {
                d["disk"]: d
                for d in self.list_disk_layout(db)
            }

            info = layout.get(name)

            if not info:
                raise HTTPException(
                    400,
                    "Ese disco no está disponible para particionar.",
                )

            disk = info["device"]

        else:
            info = layout[disk]

        role = (
            (role or "share")
            .strip()
            .lower()
        )

        if role not in (
            "share",
            "backup",
            "private",
        ):
            raise HTTPException(
                400,
                "role debe ser share, backup o private.",
            )

        if label:
            safe = label.strip()[:16]

        elif role == "backup":
            safe = "STEPAD-BACKUP"

        elif role == "private":
            safe = "STEPAD-PRIVATE"

        else:
            safe = "STEPAD-SHARE"

        result = self.disk_mount.create_partition(
            disk,
            size_gb=(
                None
                if use_remaining
                else size_gb
            ),
            use_remaining=(
                bool(use_remaining)
                or size_gb is None
            ),
            label=safe,
        )

        if not result.get("success"):
            raise HTTPException(
                500,
                result.get("message")
                or "No se pudo crear la partición.",
            )

        # La partición recién creada queda SIN filesystem (create_partition
        # del provider explícitamente no formatea): si el usuario la elimina
        # y la vuelve a crear sobre el mismo rango, el FS anterior (y sus
        # carpetas) reaparecería. Se formatea siempre aquí para que la nueva
        # partición esté limpia y lista para usar.
        created_device = result.get("device")
        mounted_now = False
        if created_device:
            formatted = self.disk_mount.format_ext4(
                created_device,
                label=safe,
            )
            if formatted.get("success"):
                result["message"] = (
                    f"{result.get('message') or 'Partición creada'}"
                    f" y formateada (ext4)."
                )
            else:
                logger.warning(
                    "create_partition: no pudo formatear %s: %s",
                    created_device,
                    formatted.get("message"),
                )

            # Montar la partición automáticamente: la unidad debe quedar
            # disponible de inmediato (y persistente tras reinicios) para
            # poder usarla como origen/destino de respaldo o para explorar.
            # Sin esto, un disco recién creado aparece conectado pero
            # "desmontado" y no se listaría como unidad utilizable.
            # El nombre del VOLUMEN se deriva de la partición física (p. ej.
            # sda1, sda2) y debe ser ÚNICO: el label genérico (STEPAD-BACKUP)
            # es igual para todas las particiones de respaldo, así que nunca
            # se usa como nombre de volumen (si no, la 2ª de respaldo choca
            # "Ya existe un volumen llamado..."). Si el derivado ya está
            # registrado, se agrega un sufijo numérico.
            try:
                candidate = (
                    label.strip()[:32]
                    if label and label.strip()
                    else Path(created_device).name
                )
                base_candidate = candidate
                suffix = 1
                while True:
                    existing_name = (
                        db.query(NetworkShareVolume)
                        .filter(NetworkShareVolume.name == candidate)
                        .first()
                    )
                    if existing_name is None:
                        break
                    suffix += 1
                    candidate = f"{base_candidate}-{suffix}"
                volume_name = candidate
                mounted = self.mount_volume(
                    db,
                    device=created_device,
                    name=volume_name,
                    purpose=role,
                )
                if isinstance(mounted, dict) and mounted.get("success", True):
                    mounted_now = False if role in ("backup", "private") else True
            except HTTPException as mount_error:
                # No tragar el error: la partición se creó físicamente pero
                # no se registró como unidad (p. ej. directorio residual del
                # mismo nombre, o el volumen ya está registrado). Sin
                # registrar el rol, una partición "backup" queda sin su
                # bóveda/job y la UI sin el badge.
                logger.warning(
                    "create_partition: no pudo montar %s: %s",
                    created_device,
                    getattr(mount_error, "detail", mount_error),
                )
                result["message"] = (
                    (result.get("message") or "Partición creada")
                    + " (formateada), PERO no se registró como unidad "
                    + f"«{volume_name}»: "
                    + str(getattr(mount_error, "detail", mount_error))
                    + ". Elegí otro nombre para la unidad o "
                    "eliminá el directorio residual del mismo nombre."
                )
            except Exception as mount_error:
                logger.warning(
                    "create_partition: error montando %s: %s",
                    created_device,
                    mount_error,
                )
                result["message"] = (
                    (result.get("message") or "Partición creada")
                    + " (formateada), pero ocurrió un error al registrarla "
                    f"como unidad: {mount_error}"
                )

        status = self.get_status(db)

        status["message"] = result.get(
            "message"
        )
        status["created_device"] = result.get(
            "device"
        )
        status["created_role"] = role
        status["mounted_now"] = mounted_now

        return status

    def resize_partition(
        self,
        db: Session,
        device: str,
        *,
        new_size_gb: float | None = None,
        confirm: str = "",
    ) -> dict:
        """
        Redimensiona una partición (agrandar o reducir).

        - Agrandar: seguro, en caliente, extiende partición y luego el FS.
        - Reducir: solo ext4 y desmontada (se encoge el FS y luego la
          partición). El usuario asume el riesgo (confirm libre, no solo
          ELIMINAR).
        """
        device = (device or "").strip()
        if not device.startswith("/dev/"):
            device = f"/dev/{device}"
        if not device.startswith("/dev/"):
            raise HTTPException(400, "Indica una partición /dev/...")

        # Doble candado: NUNCA redimensionar una partición del disco del SO.
        from backend.shares.services.disk_guard import ensure_not_system_disk
        ensure_not_system_disk(device, "redimensionar")

        # Nunca tocar el disco del sistema ni sus particiones.
        os_disks = self._os_disk_names()
        parent = self._parent_disk_name(device)
        if os_disks and (
            parent in os_disks
            or Path(device).name in os_disks
        ):
            raise HTTPException(
                400,
                "No se puede redimensionar el disco del sistema.",
            )

        if (confirm or "").strip().upper() != "ELIMINAR":
            raise HTTPException(
                400,
                "Para confirmar el redimensionado escribe ELIMINAR. "
                "Si reducís la partición asumís el riesgo de pérdida "
                "de datos por espacio insuficiente.",
            )

        # Si la partición está registrada como volumen activo, verificamos
        # el propósito y desmontamos para shrink (el provider también lo
        # valida, pero acá damos un error claro antes).
        volume = (
            db.query(NetworkShareVolume)
            .filter(NetworkShareVolume.device_path == device)
            .first()
        )

        info = self.disk_mount.partition_info(device)
        if not info.get("success"):
            raise HTTPException(500, info.get("message"))

        current_gb = round((info.get("size_bytes") or 0) / 1024 / 1024 / 1024, 2)
        requested_gb = new_size_gb

        if requested_gb is not None:
            try:
                new_gb = float(requested_gb)
            except (TypeError, ValueError):
                raise HTTPException(400, "Tamaño inválido.")
            if new_gb <= 0 or new_gb > 1024 * 1024:
                raise HTTPException(400, "Tamaño inválido.")
            if new_gb < current_gb and info.get("mounted"):
                # Se intenta reducir una partición montada: desmontar.
                if volume and volume.mountpoint:
                    try:
                        self.disk_mount.deactivate_unit(
                            self.disk_mount.unit_name_for_mount(volume.mountpoint),
                            volume.mountpoint,
                        )
                    except Exception as error:
                        logger.warning("resize: no pude desmontar %s: %s", device, error)
                still = self.disk_mount.partition_info(device)
                if still.get("mounted"):
                    raise HTTPException(
                        400,
                        "Reducir una partición montada no está soportado: "
                        "desmontala desde la UI y reintentá.",
                    )

        if new_size_gb is None:
            result = self.disk_mount.resize_partition(device)
        else:
            result = self.disk_mount.resize_partition(
                device,
                new_size_gb=float(new_size_gb),
            )

        if not result.get("success"):
            raise HTTPException(500, result.get("message") or "No se pudo redimensionar.")

        # Recalcular y refrescar el volumen registrado si existe.
        if volume:
            volume.updated_at = datetime.utcnow()
            db.commit()

        status = self.get_status(db)
        status["message"] = result.get("message")
        status["resized_device"] = device
        status["new_size_gb"] = result.get("new_size_gb")
        return status

    def _disk_health_status(
        self,
        db: Session,
    ) -> dict:
        try:
            from backend.shares.services.share_disk_health_service import (
                share_disk_health_service,
            )

            return share_disk_health_service.get_report(
                db
            )

        except Exception as error:
            logger.warning(
                "Disk health status failed: %s",
                error,
            )

            return {
                "smartctl_installed": False,
                "disks": [],
                "worst": "unavailable",
                "message": str(error),
            }

    def list_integrity_roots(
        self,
        db: Session,
    ) -> list[str]:
        """
        Mounted managed paths that integrity watch should scan.

        Integrity is independent from Samba publication. A mounted
        managed volume can contain private folders or backup data
        even when the volume itself is not currently shared.

        EXCLUYE las particiones de propósito "backup": se montan y
        desmontan SOLO para respaldar/restaurar del propio sistema, nunca
        se las expone vía SMB, y escribir ahí (respaldo/restauración de
        200+ GB) es actividad 100% legítima. Escanearlas dispara falsos
        positivos de ransomware ("muchos archivos modificados de golpe")
        contra el propio sistema. La protección antiransomware debe
        vigilar las unidades compartidas/privadas, no el repositorio.
        """

        roots: list[str] = []

        volumes = (
            db.query(NetworkShareVolume)
            .all()
        )

        for volume in volumes:
            purpose = (
                getattr(volume, "purpose", None) or "shared"
            ).lower()
            if purpose == "backup":
                continue
            path = Path(
                volume.mountpoint
            )

            if (
                path.is_dir()
                and self.disk_mount.is_mounted_at(
                    volume.mountpoint
                )
            ):
                roots.append(str(path))

        row = self._settings(db)

        if row.share_root:
            path = Path(
                row.share_root
            )

            if (
                path.is_dir()
                and self.disk_mount.is_mounted_at(
                    row.share_root
                )
                and str(path) not in roots
            ):
                roots.append(str(path))

        return roots

    def list_share_parent_disks(
        self,
        db: Session,
    ) -> list[str]:
        """
        Whole-disk devices (/dev/sdb, /dev/nvme0n1) behind managed
        volumes or the legacy assigned share disk — never the OS disk.
        """

        os_disks = self._os_disk_names()

        disks: list[str] = []
        seen: set[str] = set()

        def add_from_device(
            device: str | None,
        ) -> None:
            if (
                not device
                or not device.startswith("/dev/")
            ):
                return

            parent = (
                self._parent_disk_name(device)
                or Path(device).name
            )

            if not parent:
                return

            if (
                os_disks
                and parent in os_disks
            ):
                return

            path = f"/dev/{parent}"

            if not Path(path).exists():
                return

            if path in seen:
                return

            seen.add(path)
            disks.append(path)

        volumes = (
            db.query(NetworkShareVolume)
            .all()
        )

        for volume in volumes:
            add_from_device(
                volume.device_path
            )

        row = self._settings(db)

        if row.device_path:
            add_from_device(
                row.device_path
            )

        # Also include secondary disks that appear in the units list
        # so health is visible before a volume is managed.
        for unit in self.list_units():
            if unit.get("whole_disk"):
                add_from_device(
                    unit.get("device")
                )

            else:
                disk_name = unit.get("disk")

                if disk_name:
                    add_from_device(
                        f"/dev/{disk_name}"
                    )

        return disks

    def trip_integrity_lock(
        self,
        db: Session,
        *,
        detail: str,
    ) -> dict:
        """
        Emergency: freeze writes on all Samba shares after mass-change
        detection.
        """

        row = self._settings(db)

        if row.integrity_locked:
            return self.get_status(db)

        row.integrity_locked = True
        row.integrity_locked_at = datetime.utcnow()
        row.integrity_lock_detail = (
            (detail or "")[:512] or None
        )
        row.updated_at = datetime.utcnow()

        db.commit()

        logger.warning(
            "Share integrity lock tripped: %s",
            detail,
        )

        try:
            from backend.alerts.services.alert_service import (
                AlertService,
            )

            AlertService().create(
                db,
                alert_type="SHARE_MASS_CHANGE",
                severity="critical",
                title=(
                    "Disco de red bloqueado "
                    "(cambios masivos)"
                ),
                message=detail[:500],
            )

        except Exception as error:
            logger.warning(
                "Could not create share integrity alert: %s",
                error,
            )

        try:
            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            CriticalAlertEmailService().send(
                db,
                "Disco de red bloqueado (cambios masivos)",
                (
                    "Se detectaron muchos cambios de archivos "
                    "en el disco compartido (posible ransomware). "
                    "Los compartidos quedaron en SOLO LECTURA. "
                    "Revisa los equipos de la LAN y desbloquea "
                    "desde Disco de red cuando sea seguro.\n\n"
                    f"Detalle: {detail}"
                ),
            )

        except Exception as error:
            logger.warning(
                "Could not email share integrity alert: %s",
                error,
            )

        self.apply(db)

        return self.get_status(db)

    def is_integrity_paused(
        self,
        db: Session,
        *,
        row=None,
    ) -> bool:
        row = row or self._settings(db)

        until = getattr(
            row,
            "integrity_paused_until",
            None,
        )

        if not until:
            return False

        if until <= datetime.utcnow():
            if row.integrity_paused_until is not None:
                row.integrity_paused_until = None
                db.commit()

            return False

        return True

    def pause_integrity_watch(
        self,
        db: Session,
        *,
        hours: float = 2,
    ) -> dict:
        """
        Temporarily disable mass-change detection for bulk uploads.
        Allowed: 1, 2, 4 or 8 hours.
        """

        try:
            hours = float(hours)
        except (
            TypeError,
            ValueError,
        ):
            hours = 2

        if hours not in (
            1,
            2,
            4,
            8,
        ):
            hours = min(
                (1, 2, 4, 8),
                key=lambda h: abs(h - hours),
            )

        from datetime import timedelta

        row = self._settings(db)

        row.integrity_paused_until = (
            datetime.utcnow()
            + timedelta(hours=hours)
        )
        row.updated_at = datetime.utcnow()

        db.commit()

        status = self.get_status(db)

        status["message"] = (
            f"Protección antiransomware pausada por "
            f"{int(hours)} h. Vuelve a activarla cuando "
            "termines de cargar archivos."
        )

        return status

    def resume_integrity_watch(
        self,
        db: Session,
    ) -> dict:
        row = self._settings(db)

        row.integrity_paused_until = None
        row.updated_at = datetime.utcnow()

        db.commit()

        status = self.get_status(db)
        status["message"] = (
            "Protección antiransomware reactivada."
        )

        return status

    def clear_integrity_lock(
        self,
        db: Session,
    ) -> dict:
        row = self._settings(db)

        row.integrity_locked = False
        row.integrity_locked_at = None
        row.integrity_lock_detail = None
        row.updated_at = datetime.utcnow()

        db.commit()

        self.apply(db)

        status = self.get_status(db)

        status["message"] = (
            "Protección reactivada: escritura en el disco "
            "de red habilitada de nuevo."
        )

        return status

    def set_integrity_watch(
        self,
        db: Session,
        *,
        enabled: bool | None = None,
        change_threshold: int | None = None,
    ) -> dict:
        row = self._settings(db)

        if enabled is not None:
            row.integrity_watch_enabled = bool(
                enabled
            )

        if change_threshold is not None:
            row.integrity_change_threshold = max(
                20,
                min(
                    5000,
                    int(change_threshold),
                ),
            )

        row.updated_at = datetime.utcnow()

        db.commit()

        return self.get_status(db)

    def update_settings(
        self,
        db: Session,
        *,
        enabled: bool | None = None,
        share_root: str | None = None,
        workgroup: str | None = None,
        server_name: str | None = None,
    ) -> dict:
        row = self._settings(db)

        if share_root is not None:
            path = self._validate_share_root(
                share_root
            )
            row.share_root = str(path)

        if workgroup is not None:
            row.workgroup = (
                workgroup.strip()
                or "WORKGROUP"
            )[:64]

        if server_name is not None:
            value = server_name.strip()
            row.server_name = (
                value[:64]
                if value
                else None
            )

        if enabled is not None:
            if enabled:
                root = (
                    share_root
                    if share_root is not None
                    else row.share_root
                )

                if (
                    not row.disk_locked
                    or not row.device_uuid
                ):
                    raise HTTPException(
                        400,
                        "Primero asigna una unidad como "
                        "disco compartido (USB o disco adicional).",
                    )

                if not root:
                    raise HTTPException(
                        400,
                        "Antes de activar, elige un disco USB "
                        "o adicional (no el disco del sistema).",
                    )

                self._validate_share_root(root)

            row.enabled = bool(enabled)

        row.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(row)

        self.apply(db)

        return self.get_status(db)

    def _require_share_root(
        self,
        db: Session,
    ) -> Path:
        row = self._settings(db)

        if not row.share_root:
            raise HTTPException(
                400,
                "Configura primero el disco compartido "
                "(USB o disco adicional).",
            )

        return self._validate_share_root(
            row.share_root
        )

    def list_folders(
        self,
        db: Session,
        volume_id: int | None = None,
    ) -> list[dict]:
        query = db.query(
            NetworkShareFolder
        )

        if volume_id is not None:
            query = query.filter(
                NetworkShareFolder.volume_id
                == volume_id
            )

        folders = (
            query
            .order_by(NetworkShareFolder.name)
            .all()
        )

        all_jobs = (
            self.backup_service._all_jobs()
        )

        lan_ip = self._lan_ip()

        return [
            self._folder_dict(
                db,
                folder,
                all_jobs,
                lan_ip,
            )
            for folder in folders
        ]

    def _folder_path(
        self,
        db: Session,
        folder: NetworkShareFolder,
    ) -> str | None:
        root = None

        if folder.volume_id:
            volume = db.get(
                NetworkShareVolume,
                folder.volume_id,
            )

            if volume:
                root = Path(
                    volume.mountpoint
                )

        if root is None:
            row = self._settings(db)

            root = (
                Path(row.share_root)
                if row.share_root
                else None
            )

        if root is None:
            return None

        return str(
            root / folder.folder_name
        )

    def _folder_dict(
        self,
        db: Session,
        folder: NetworkShareFolder,
        all_jobs=None,
        lan_ip=None,
    ) -> dict:
        path = self._folder_path(
            db,
            folder,
        )

        accesses = (
            db.query(
                GroupFolderAccess,
                DeviceGroup,
            )
            .join(
                DeviceGroup,
                DeviceGroup.id
                == GroupFolderAccess.group_id,
            )
            .filter(
                GroupFolderAccess.folder_id
                == folder.id
            )
            .all()
        )

        groups = [
            {
                "group_id": group.id,
                "group_name": group.name,
                "access_mode": access.access_mode,
            }
            for access, group in accesses
        ]

        if lan_ip is None:
            lan_ip = self._lan_ip()

        folder_path = self._folder_path(
            db,
            folder,
        )

        job = None

        if folder_path:
            jobs = (
                all_jobs
                if all_jobs is not None
                else self.backup_service._all_jobs()
            )

            for j in jobs:
                if j.get("source_path") == folder_path:
                    job = j
                    break

        return {
            "id": folder.id,
            "name": folder.name,
            "folder_name": folder.folder_name,
            "volume_id": folder.volume_id,
            "description": folder.description,
            "enabled": folder.enabled,
            "path": path,
            "exists": bool(
                path
                and Path(path).is_dir()
            ),
            "unc_path": (
                f"\\\\{lan_ip}\\{folder.name}"
                if lan_ip
                and folder.shared
                else None
            ),
            "groups": groups,
            "shared": bool(
                folder.shared
            ),
            "public": (
                bool(folder.shared)
                and not bool(groups)
            ),
            "backup": {
                "mode": folder.backup_mode,
                "times_per_day": (
                    folder.backup_times_per_day
                ),
                "retention": (
                    folder.backup_retention
                ),
                "enabled": bool(
                    folder.backup_mode != "off"
                ),
                "job_id": (
                    job.get("id")
                    if job
                    else None
                ),
                "last_backup_at": (
                    job.get("last_backup_at")
                    if job
                    else None
                ),
                "last_result": (
                    job.get("last_result")
                    if job
                    else None
                ),
                "next_run": (
                    job.get("enabled")
                    if job
                    else False
                ),
            },
            "created_at": (
                to_iso_utc(
                    folder.created_at
                )
                if folder.created_at
                else None
            ),
        }

    def create_folder(
        self,
        db: Session,
        *,
        name: str,
        volume_id: int,
        folder_name: str | None = None,
        description: str | None = None,
    ) -> dict:
        volume = db.get(
            NetworkShareVolume,
            volume_id,
        )

        if (
            not volume
            or not volume.mountpoint
            or not Path(
                volume.mountpoint
            ).is_dir()
        ):
            raise HTTPException(
                400,
                "La unidad no está montada. "
                "Actívala primero para crear carpetas.",
            )

        name = (name or "").strip()

        if not name:
            raise HTTPException(
                400,
                "El nombre de la carpeta es obligatorio.",
            )

        slug = (
            folder_name or name
        ).strip().replace(
            " ",
            "_",
        )

        if not _FOLDER_NAME_RE.match(slug):
            raise HTTPException(
                400,
                "Nombre de carpeta inválido "
                "(usa letras, números, . _ -).",
            )

        if db.query(
            NetworkShareFolder
        ).filter(
            NetworkShareFolder.name == name
        ).first():
            raise HTTPException(
                400,
                "Ya existe un compartido con ese nombre.",
            )

        if db.query(
            NetworkShareFolder
        ).filter(
            NetworkShareFolder.volume_id
            == volume_id,
            NetworkShareFolder.folder_name
            == slug,
        ).first():
            raise HTTPException(
                400,
                "Ya existe una carpeta con ese nombre "
                "en esta unidad.",
            )

        if name == volume.name:
            raise HTTPException(
                400,
                f"«{name}» ya es el nombre de la unidad. "
                "Elige otro para la carpeta.",
            )

        folder = NetworkShareFolder(
            name=name,
            folder_name=slug,
            volume_id=volume_id,
            description=(
                (description or "").strip()
                or None
            ),
            enabled=True,
            shared=False,
        )

        db.add(folder)
        db.commit()
        db.refresh(folder)

        self._ensure_folder_dir(
            db,
            folder,
        )

        self.apply(db)

        return self._folder_dict(
            db,
            folder,
        )

    def delete_folder(
        self,
        db: Session,
        folder_id: int,
    ) -> dict:
        folder = db.get(
            NetworkShareFolder,
            folder_id,
        )

        if not folder:
            raise HTTPException(
                404,
                "Carpeta no encontrada.",
            )

        folder_path = self._folder_path(
            db,
            folder,
        )

        self.backup_service.delete_jobs_for_folder(
            folder_id
        )

        if folder_path:
            self.backup_service.delete_jobs_for_source(
                folder_path
            )

        db.query(
            GroupFolderAccess
        ).filter(
            GroupFolderAccess.folder_id
            == folder_id
        ).delete()

        db.delete(folder)
        db.commit()

        self.apply(db)

        return {
            "success": True
        }

    def set_folder_groups(
        self,
        db: Session,
        folder_id: int,
        grants: list[dict],
    ) -> dict:
        """
        grants: [{group_id, access_mode: read|write}, ...]
        Replaces all access rows for the folder.
        """

        folder = db.get(
            NetworkShareFolder,
            folder_id,
        )

        if not folder:
            raise HTTPException(
                404,
                "Carpeta no encontrada.",
            )

        db.query(
            GroupFolderAccess
        ).filter(
            GroupFolderAccess.folder_id
            == folder_id
        ).delete()

        for grant in grants or []:
            group_id = int(
                grant["group_id"]
            )

            mode = (
                grant.get("access_mode")
                or "read"
            ).strip().lower()

            if mode not in (
                "read",
                "write",
            ):
                raise HTTPException(
                    400,
                    "access_mode debe ser read o write.",
                )

            if not db.get(
                DeviceGroup,
                group_id,
            ):
                raise HTTPException(
                    400,
                    f"Grupo {group_id} no existe.",
                )

            db.add(
                GroupFolderAccess(
                    group_id=group_id,
                    folder_id=folder_id,
                    access_mode=mode,
                )
            )

        db.commit()

        self.apply(db)

        return self._folder_dict(
            db,
            folder,
        )

    def set_folder_shared(
        self,
        db: Session,
        folder_id: int,
        *,
        shared: bool,
    ) -> dict:
        """Publish/withdraw a folder as a Samba share."""

        folder = db.get(
            NetworkShareFolder,
            folder_id,
        )

        if not folder:
            raise HTTPException(
                404,
                "Carpeta no encontrada.",
            )

        if shared and not folder.shared:
            self._ensure_folder_dir(
                db,
                folder,
            )

        folder.shared = bool(
            shared
        )

        db.commit()
        db.refresh(folder)

        self.apply(db)

        return self._folder_dict(
            db,
            folder,
        )

    def set_folder_backup_policy(
        self,
        db: Session,
        folder_id: int,
        *,
        mode: str,
        times_per_day: int,
        retention: int,
    ) -> dict:
        """Set the scheduled backup policy for a folder."""

        folder = db.get(
            NetworkShareFolder,
            folder_id,
        )

        if not folder:
            raise HTTPException(
                404,
                "Carpeta no encontrada.",
            )

        if mode not in (
            "off",
            "times",
            "on_change",
        ):
            raise HTTPException(
                400,
                "mode debe ser off, times u on_change.",
            )

        folder.backup_mode = mode
        folder.backup_times_per_day = max(
            1,
            min(
                24,
                int(times_per_day),
            ),
        )
        folder.backup_retention = max(
            1,
            min(
                365,
                int(retention),
            ),
        )

        db.commit()
        db.refresh(folder)

        self._sync_folder_backup_job(
            db,
            folder,
        )

        db.refresh(folder)

        return self._folder_dict(
            db,
            folder,
        )

    def list_group_folders(
        self,
        db: Session,
        group_id: int,
    ) -> list[dict]:
        rows = (
            db.query(
                GroupFolderAccess,
                NetworkShareFolder,
            )
            .join(
                NetworkShareFolder,
                NetworkShareFolder.id
                == GroupFolderAccess.folder_id,
            )
            .filter(
                GroupFolderAccess.group_id
                == group_id
            )
            .all()
        )

        return [
            {
                "folder_id": folder.id,
                "name": folder.name,
                "folder_name": folder.folder_name,
                "access_mode": access.access_mode,
                "enabled": folder.enabled,
            }
            for access, folder in rows
        ]

    def set_group_folders(
        self,
        db: Session,
        group_id: int,
        grants: list[dict],
    ) -> list[dict]:
        if not db.get(
            DeviceGroup,
            group_id,
        ):
            raise HTTPException(
                404,
                "Grupo no encontrado.",
            )

        db.query(
            GroupFolderAccess
        ).filter(
            GroupFolderAccess.group_id
            == group_id
        ).delete()

        for grant in grants or []:
            folder_id = int(
                grant["folder_id"]
            )

            mode = (
                grant.get("access_mode")
                or "read"
            ).strip().lower()

            if mode not in (
                "read",
                "write",
            ):
                raise HTTPException(
                    400,
                    "access_mode debe ser read o write.",
                )

            if not db.get(
                NetworkShareFolder,
                folder_id,
            ):
                raise HTTPException(
                    400,
                    f"Carpeta {folder_id} no existe.",
                )

            db.add(
                GroupFolderAccess(
                    group_id=group_id,
                    folder_id=folder_id,
                    access_mode=mode,
                )
            )

        db.commit()

        self.apply(db)

        return self.list_group_folders(
            db,
            group_id,
        )

    def _ensure_folder_dir(
        self,
        db: Session,
        folder: NetworkShareFolder,
    ) -> Path:
        if folder.volume_id:
            volume = db.get(
                NetworkShareVolume,
                folder.volume_id,
            )

            if not volume:
                raise HTTPException(
                    400,
                    "La unidad de esta carpeta ya no existe.",
                )

            root = Path(
                volume.mountpoint
            )

            if not root.is_dir():
                raise HTTPException(
                    400,
                    f"La unidad «{volume.name}» "
                    "no está montada.",
                )

        else:
            root = self._require_share_root(
                db
            )

        path = root / folder.folder_name

        path.mkdir(
            parents=True,
            exist_ok=True,
        )

        try:
            shutil.chown(
                path,
                user="nobody",
                group="nogroup",
            )

            os.chmod(
                path,
                0o775,
            )

        except Exception as error:
            logger.warning(
                "Could not chown share folder %s: %s",
                path,
                error,
            )

        return path

    def _ips_for_groups(
        self,
        db: Session,
        group_ids: list[int],
    ) -> list[str]:
        if not group_ids:
            return []

        rows = (
            db.query(
                NetworkDevice.ip_address
            )
            .join(
                GroupDevice,
                GroupDevice.device_id
                == NetworkDevice.id,
            )
            .filter(
                GroupDevice.group_id.in_(
                    group_ids
                )
            )
            .filter(
                NetworkDevice.ip_address.isnot(
                    None
                )
            )
            .all()
        )

        ips = sorted({
            (ip or "").strip()
            for (ip,) in rows
            if ip
            and ip.strip()
            and ip.strip()
            != "0.0.0.0"
        })

        return ips

    def list_group_volumes(
        self,
        db: Session,
        group_id: int,
    ) -> list[dict]:
        if not db.get(
            DeviceGroup,
            group_id,
        ):
            raise HTTPException(
                404,
                "Grupo no encontrado.",
            )

        rows = (
            db.query(
                GroupVolumeAccess,
                NetworkShareVolume,
            )
            .join(
                NetworkShareVolume,
                NetworkShareVolume.id
                == GroupVolumeAccess.volume_id,
            )
            .filter(
                GroupVolumeAccess.group_id
                == group_id
            )
            .all()
        )

        return [
            {
                "volume_id": volume.id,
                "name": volume.name,
                "access_mode": access.access_mode,
            }
            for access, volume in rows
        ]

    def set_group_volumes(
        self,
        db: Session,
        group_id: int,
        grants: list[dict],
    ) -> list[dict]:
        if not db.get(
            DeviceGroup,
            group_id,
        ):
            raise HTTPException(
                404,
                "Grupo no encontrado.",
            )

        db.query(
            GroupVolumeAccess
        ).filter(
            GroupVolumeAccess.group_id
            == group_id
        ).delete()

        for grant in grants or []:
            volume_id = int(
                grant["volume_id"]
            )

            mode = (
                grant.get("access_mode")
                or "read"
            ).strip().lower()

            if mode not in (
                "read",
                "write",
            ):
                raise HTTPException(
                    400,
                    "access_mode debe ser read o write.",
                )

            if not db.get(
                NetworkShareVolume,
                volume_id,
            ):
                raise HTTPException(
                    400,
                    f"Compartido {volume_id} no existe.",
                )

            db.add(
                GroupVolumeAccess(
                    group_id=group_id,
                    volume_id=volume_id,
                    access_mode=mode,
                )
            )

        db.commit()

        self.apply(db)

        return self.list_group_volumes(
            db,
            group_id,
        )

    def _share_path_allowed(
        self,
        path,
    ) -> bool:
        """True si el path se puede publicar por Samba.

        Nunca se publican rutas que toquen la bóveda de respaldo (Respaldo,
        .respaldo.json, .backups, .stepad-restic): una unidad puede ser a la
        vez compartida y fuente/destino de respaldos, y su repositorio cifrado
        debe quedar fuera del alcance de los clientes SMB."""
        try:
            text = str(path or "")
        except Exception:
            return False
        parts = text.replace("\\", "/").split("/")
        return not any(
            part in _BACKUP_RESERVED_NAMES
            for part in parts
        )

    def build_samba_shares(
        self,
        db: Session,
    ) -> list[dict]:
        """
        Build only the Samba publication layer.

        Mounting is deliberately NOT performed here.
        """

        shares: list[dict] = []

        lan_hosts = self._lan_hosts_allow()
        row = self._settings(db)

        force_ro = bool(
            getattr(
                row,
                "integrity_locked",
                False,
            )
        )

        volumes = (
            db.query(NetworkShareVolume)
            .filter(
                NetworkShareVolume.sharing.is_(True)
            )
            .all()
        )

        for volume in volumes:
            path = Path(
                volume.mountpoint
            )

            if not path.is_dir():
                continue

            folders = (
                db.query(NetworkShareFolder)
                .filter(
                    NetworkShareFolder.volume_id
                    == volume.id,
                    NetworkShareFolder.enabled.is_(True),
                    NetworkShareFolder.shared.is_(True),
                )
                .all()
            )

            if folders:
                for folder in folders:
                    folder_path = (
                        self._ensure_folder_dir(
                            db,
                            folder,
                        )
                    )

                    accesses = (
                        db.query(
                            GroupFolderAccess
                        )
                        .filter(
                            GroupFolderAccess.folder_id
                            == folder.id
                        )
                        .all()
                    )

                    group_ids = [
                        a.group_id
                        for a in accesses
                    ]

                    if not accesses:
                        hosts = lan_hosts
                        write = True
                    else:
                        ips = self._ips_for_groups(
                            db,
                            group_ids,
                        )
                        hosts = ips
                        write = any(
                            a.access_mode
                            == "write"
                            for a in accesses
                        )

                    if not self._share_path_allowed(folder_path):
                        continue

                    shares.append({
                        "name": folder.name,
                        "path": str(
                            folder_path
                        ),
                        "comment": (
                            folder.description
                            or folder.name
                        ),
                        "read_only": (
                            force_ro
                            or not write
                        ),
                        "hosts_allow": hosts,
                    })

                continue

            accesses = (
                db.query(
                    GroupVolumeAccess
                )
                .filter(
                    GroupVolumeAccess.volume_id
                    == volume.id
                )
                .all()
            )

            if accesses:
                group_ids = [
                    a.group_id
                    for a in accesses
                ]

                hosts = self._ips_for_groups(
                    db,
                    group_ids,
                )

                write = any(
                    a.access_mode == "write"
                    for a in accesses
                )

            else:
                hosts = lan_hosts
                write = True

            if not self._share_path_allowed(path):
                continue

            shares.append({
                "name": volume.name,
                "path": str(path),
                "comment": volume.name,
                "read_only": (
                    force_ro
                    or not write
                ),
                "hosts_allow": hosts,
            })

        # Legacy folder shares (single-disk model, no volume_id).
        if row.share_root:
            try:
                self._validate_share_root(
                    row.share_root
                )

            except HTTPException:
                logger.warning(
                    "Share root %s is on the OS disk "
                    "or invalid; skipping folder shares.",
                    row.share_root,
                )

            else:
                folders = (
                    db.query(
                        NetworkShareFolder
                    )
                    .filter(
                        NetworkShareFolder.enabled.is_(True),
                        NetworkShareFolder.volume_id.is_(None),
                        NetworkShareFolder.shared.is_(True),
                    )
                    .all()
                )

                for folder in folders:
                    folder_path = (
                        self._ensure_folder_dir(
                            db,
                            folder,
                        )
                    )

                    accesses = (
                        db.query(
                            GroupFolderAccess
                        )
                        .filter(
                            GroupFolderAccess.folder_id
                            == folder.id
                        )
                        .all()
                    )

                    group_ids = [
                        a.group_id
                        for a in accesses
                    ]

                    if not accesses:
                        hosts = lan_hosts
                        write = True
                    else:
                        hosts = self._ips_for_groups(
                            db,
                            group_ids,
                        )

                        write = any(
                            a.access_mode
                            == "write"
                            for a in accesses
                        )

                    if not self._share_path_allowed(folder_path):
                        continue

                    shares.append({
                        "name": folder.name,
                        "path": str(
                            folder_path
                        ),
                        "comment": (
                            folder.description
                            or folder.name
                        ),
                        "read_only": (
                            force_ro
                            or not write
                        ),
                        "hosts_allow": hosts,
                    })

        return shares

    def apply(
        self,
        db: Session | None = None,
    ) -> dict:
        owns = db is None

        if owns:
            db = SessionLocal()

        try:
            row = self._settings(db)

            volumes_on = (
                db.query(NetworkShareVolume)
                .filter(
                    NetworkShareVolume.sharing.is_(True)
                )
                .count()
            )

            shares = self.build_samba_shares(
                db
            )

            enabled = (
                bool(volumes_on)
                or (
                    bool(row.enabled)
                    and bool(row.share_root)
                )
            )

            if not shares:
                self.provider.write_config(
                    workgroup=(
                        row.workgroup
                        or "WORKGROUP"
                    ),
                    server_name=row.server_name,
                    shares=[],
                )

                return self.provider.apply(
                    enabled=False
                )

            self.provider.write_config(
                workgroup=(
                    row.workgroup
                    or "WORKGROUP"
                ),
                server_name=row.server_name,
                shares=shares,
            )

            return self.provider.apply(
                enabled=bool(enabled)
            )

        finally:
            if owns:
                db.close()

    def sync_access(self) -> None:
        """Called when group membership changes."""

        try:
            self.apply()

        except Exception as error:
            logger.exception(
                "Network share sync failed: %s",
                error,
            )

    def ensure_boot(self) -> None:
        """
        Restore managed storage mounts after boot.

        Mount lifecycle is independent from Samba:
        mount_on_boot=True is enough to restore a volume.
        sharing=True only controls Samba publication.
        """

        try:
            db = SessionLocal()

            try:
                row = self._settings(db)

                # Legacy dedicated share disk.
                if (
                    row.device_uuid
                    and row.disk_locked
                ):
                    fstype = (
                        self.disk_mount.blkid_field(
                            f"/dev/disk/by-uuid/"
                            f"{row.device_uuid}",
                            "TYPE",
                        )
                    )

                    self.disk_mount.ensure_boot(
                        row.device_uuid,
                        fstype,
                    )

                    if not row.share_root:
                        row.share_root = str(
                            SHARE_DISK_MOUNT
                        )
                        db.commit()

                # Managed volumes.
                volumes = (
                    db.query(
                        NetworkShareVolume
                    )
                    .filter(
                        NetworkShareVolume.mount_on_boot.is_(True)
                    )
                    .all()
                )

                for volume in volumes:
                    fstype = (
                        self.disk_mount.blkid_field(
                            f"/dev/disk/by-uuid/"
                            f"{volume.device_uuid}",
                            "TYPE",
                        )
                        or "auto"
                    )

                    try:
                        unit = (
                            self.disk_mount.write_volume_mount_unit(
                                uuid=volume.device_uuid,
                                fstype=fstype,
                                mountpoint=volume.mountpoint,
                            )
                        )

                        result = (
                            self.disk_mount.activate_unit(
                                unit,
                                volume.mountpoint,
                            )
                        )

                        if not result.get("success"):
                            logger.error(
                                "Volume boot mount failed "
                                "for %s: %s",
                                volume.name,
                                result.get(
                                    "message"
                                ),
                            )

                    except Exception as error:
                        logger.error(
                            "Volume boot mount failed "
                            "for %s: %s",
                            volume.name,
                            error,
                        )

            finally:
                db.close()

            self.apply()

        except Exception as error:
            logger.error(
                "Network share boot error: %s",
                error,
            )