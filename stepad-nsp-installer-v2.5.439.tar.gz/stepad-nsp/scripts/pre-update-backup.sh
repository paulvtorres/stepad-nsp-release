#!/bin/bash
#
# Pre-update backup: encrypted backup of the database + /etc/stepad before
# the installer touches anything. Non-blocking: if it fails, the update
# continues (the scheduled backup remains the fallback).
#
set -uo pipefail

APP_DIR="${STEPAD_APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
PYTHON="${APP_DIR}/.venv/bin/python3"

echo "==> Pre-update backup..."

if [ ! -x "$PYTHON" ]; then
    echo "    AVISO: no se encontró el intérprete del NSP; se omite."
    exit 0
fi

if [ -r /etc/stepad/stepad.env ]; then
    set -a
    # shellcheck disable=SC1091
    . /etc/stepad/stepad.env
    set +a
fi

cd "$APP_DIR" || exit 0

"$PYTHON" - <<'PY' || echo "    AVISO: el backup pre-actualización falló; se continúa."
from backend.core.database.session import SessionLocal
from backend.backups.services.backup_service import BackupService

db = SessionLocal()
try:
    result = BackupService().create_backup(db)
    if result.get("success"):
        print("    Backup pre-update OK:", result.get("filename"))
    else:
        print("    AVISO:", result.get("message"))
finally:
    db.close()
PY

echo "    Backup pre-actualización finalizado."
