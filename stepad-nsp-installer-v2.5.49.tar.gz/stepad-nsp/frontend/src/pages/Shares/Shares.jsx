import { useEffect, useMemo, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getShareStatus,
    shareVolume,
    unshareVolume,
    formatShareDisk,
    deleteSharePartition,
    unlockShareIntegrity,
    pauseShareIntegrity,
    resumeShareIntegrity,
    createShareFolder,
    deleteShareFolder,
    setShareFolderGroups,
    getGroups,
} from "../../services/api";

import "./shares.css";


function formatSize(bytes) {
    const n = Number(bytes);
    if (!Number.isFinite(n) || n <= 0) return "";
    const units = ["B", "KB", "MB", "GB", "TB"];
    let value = n;
    let i = 0;
    while (value >= 1024 && i < units.length - 1) {
        value /= 1024;
        i += 1;
    }
    return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}


function Shares() {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);
    const [groups, setGroups] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);
    const [names, setNames] = useState({});
    const [selectedDevice, setSelectedDevice] = useState(null);
    const [folderName, setFolderName] = useState("");

    function load() {
        Promise.all([getShareStatus(), getGroups().catch(() => [])])
            .then(([s, g]) => {
                setStatus(s);
                setGroups(g || []);
            })
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(load, 20000);
        return () => clearInterval(timer);
    }, []);

    const partitions = useMemo(() => {
        return (status?.units || []).filter((u) => !u.whole_disk);
    }, [status]);

    const disks = useMemo(() => {
        const map = new Map();
        for (const part of partitions) {
            const key = part.disk || "otros";
            if (!map.has(key)) {
                map.set(key, {
                    disk: key,
                    transport: part.transport,
                    model: part.model,
                    parts: [],
                });
            }
            map.get(key).parts.push(part);
        }
        return Array.from(map.values());
    }, [partitions]);

    const selected = useMemo(() => {
        if (!selectedDevice) return null;
        return partitions.find((p) => p.device === selectedDevice) || null;
    }, [partitions, selectedDevice]);

    useEffect(() => {
        if (!selectedDevice && partitions.length) {
            const shared = partitions.find((p) => p.sharing);
            setSelectedDevice((shared || partitions[0]).device);
        } else if (
            selectedDevice
            && partitions.length
            && !partitions.some((p) => p.device === selectedDevice)
        ) {
            setSelectedDevice(partitions[0]?.device || null);
        }
    }, [partitions, selectedDevice]);

    const selectedFolders = useMemo(() => {
        if (!selected?.volume_id) return [];
        return (status?.folders || []).filter(
            (f) => f.volume_id === selected.volume_id
        );
    }, [status, selected]);

    function setName(device, value) {
        setNames((prev) => ({ ...prev, [device]: value }));
    }

    async function handleShare(unit, event) {
        event?.stopPropagation();
        const device = unit?.device;
        if (!device) return;

        const name = (names[device] || unit.share_name || "").trim();
        if (!name) {
            setError("Escribe un nombre para identificar este compartido.");
            return;
        }

        if (!confirm(
            `¿Compartir ${device} como «${name}»?\n\n`
            + "Quedará montado y visible en la red.\n"
            + `Ruta: \\\\${status?.lan_ip || "IP"}\\${name}`
        )) return;

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await shareVolume({ device, name });
            setStatus(next);
            setSelectedDevice(device);
            setNotice(next?.message || `«${name}» compartido.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleUnshare(unit, event) {
        event?.stopPropagation();
        const volumeId = unit?.volume_id;
        const name = unit?.share_name || unit?.device;
        if (!volumeId) return;

        if (!confirm(
            `¿Dejar de compartir «${name}»?\n\n`
            + "Se desmontará la partición y se quitarán sus carpetas de la red."
        )) return;

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await unshareVolume(volumeId);
            setStatus(next);
            setNotice(next?.message || `Se dejó de compartir «${name}».`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleFormat(unit, event) {
        event?.stopPropagation();
        const device = unit?.device;
        if (!device) return;

        const typed = prompt(
            `Se borrarán todos los datos de ${device}.\n`
            + "Escribe FORMATEAR para continuar:"
        );
        if ((typed || "").trim().toUpperCase() !== "FORMATEAR") {
            if (typed !== null) setError("Formateo cancelado (debes escribir FORMATEAR).");
            return;
        }

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await formatShareDisk({
                device,
                confirm: "FORMATEAR",
                assign: false,
                whole_disk: false,
            });
            setStatus(next);
            setNotice(next?.message || `${device} formateado.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDeletePartition(unit, event) {
        event?.stopPropagation();
        const device = unit?.device;
        if (!device) return;

        if (unit.sharing) {
            setError("Deja de compartir la partición antes de eliminarla.");
            return;
        }

        const typed = prompt(
            `Se eliminará la partición ${device} del disco.\n`
            + "Se perderán todos sus datos.\n\n"
            + "Escribe ELIMINAR para continuar:"
        );
        if ((typed || "").trim().toUpperCase() !== "ELIMINAR") {
            if (typed !== null) setError("Eliminación cancelada (debes escribir ELIMINAR).");
            return;
        }

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await deleteSharePartition({
                device,
                confirm: "ELIMINAR",
            });
            setStatus(next);
            if (selectedDevice === device) {
                setSelectedDevice(null);
            }
            setNotice(next?.message || `Partición ${device} eliminada.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleUnlockIntegrity() {
        if (!confirm(
            "¿Reactivar escritura en el disco de red?\n\n"
            + "Solo hazlo si ya revisaste que no hay ransomware activo en la LAN."
        )) return;

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await unlockShareIntegrity();
            setStatus(next);
            setNotice(next?.message || "Escritura reactivada.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handlePauseIntegrity(hours) {
        if (!confirm(
            `¿Pausar la protección antiransomware por ${hours} hora(s)?\n\n`
            + "Úsalo solo para cargar muchos archivos. "
            + "Mientras esté pausada, un ransomware no se cortará automáticamente."
        )) return;

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await pauseShareIntegrity(hours);
            setStatus(next);
            setNotice(next?.message || `Protección pausada ${hours} h.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleResumeIntegrity() {
        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await resumeShareIntegrity();
            setStatus(next);
            setNotice(next?.message || "Protección reactivada.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleCreateFolder() {
        if (!selected?.volume_id) return;
        const name = folderName.trim();
        if (!name) {
            setError("Indica el nombre de la carpeta.");
            return;
        }

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            await createShareFolder({
                name,
                volume_id: selected.volume_id,
            });
            setFolderName("");
            const next = await getShareStatus();
            setStatus(next);
            setNotice(`Carpeta «${name}» creada.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDeleteFolder(folder) {
        if (!confirm(`¿Eliminar la carpeta «${folder.name}» de la red?`)) return;

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            await deleteShareFolder(folder.id);
            const next = await getShareStatus();
            setStatus(next);
            setNotice(`Carpeta «${folder.name}» eliminada.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function toggleFolderGroup(folder, groupId, mode) {
        const current = folder.groups || [];
        const existing = current.find((g) => g.group_id === groupId);
        let next;

        if (existing && existing.access_mode === mode) {
            next = current.filter((g) => g.group_id !== groupId);
        } else if (existing) {
            next = current.map((g) =>
                g.group_id === groupId ? { ...g, access_mode: mode } : g
            );
        } else {
            next = [...current, { group_id: groupId, access_mode: mode }];
        }

        setBusy(true);
        setError(null);
        try {
            await setShareFolderGroups(folder.id, {
                groups: next.map((g) => ({
                    group_id: g.group_id,
                    access_mode: g.access_mode,
                })),
            });
            const refreshed = await getShareStatus();
            setStatus(refreshed);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    if (loading && !status) {
        return <div className="sh-page"><p className="sh-loading">Cargando…</p></div>;
    }

    const sambaOk = Boolean(status?.samba?.installed);
    const lanIp = status?.lan_ip;
    const integrity = status?.integrity || {};
    const integrityLocked = Boolean(integrity.locked);
    const integrityPaused = Boolean(integrity.paused);
    const diskHealth = status?.disk_health || null;
    const diskHealthProblems = (diskHealth?.disks || []).filter(
        (d) => d.level === "warning" || d.level === "critical"
    );

    return (
        <div className="sh-page sh-split-page">
            <header className="sh-hero">
                <div>
                    <p className="sh-eyebrow">Red</p>
                    <h1>Disco de red</h1>
                    <p className="sh-lede">
                        Izquierda: unidades y particiones. Derecha: carpetas y permisos
                        {lanIp ? <> · <code className="sh-inline-code">\\{lanIp}\Carpeta</code></> : null}.
                    </p>
                </div>
            </header>

            {!sambaOk && (
                <div className="sh-banner warn">
                    Samba no está instalado. En el servidor: <code>sudo apt-get install -y samba</code>
                </div>
            )}

            {integrityPaused && !integrityLocked && (
                <div className="sh-banner warn sh-integrity-banner">
                    <div>
                        <strong>Protección antiransomware pausada</strong>
                        <p>
                            Puedes cargar muchos archivos sin que se bloquee el disco.
                            {integrity.paused_until
                                ? ` Se reactivará automáticamente: ${new Date(integrity.paused_until).toLocaleString()}.`
                                : ""}
                        </p>
                    </div>
                    {isAdmin && (
                        <button
                            type="button"
                            className="sh-btn primary"
                            disabled={busy}
                            onClick={handleResumeIntegrity}
                        >
                            Reactivar ahora
                        </button>
                    )}
                </div>
            )}

            {!integrityPaused && !integrityLocked && isAdmin && (
                <div className="sh-pause-bar">
                    <span>Carga masiva:</span>
                    <button
                        type="button"
                        className="sh-btn"
                        disabled={busy}
                        onClick={() => handlePauseIntegrity(1)}
                    >
                        Pausar 1 h
                    </button>
                    <button
                        type="button"
                        className="sh-btn"
                        disabled={busy}
                        onClick={() => handlePauseIntegrity(2)}
                    >
                        Pausar 2 h
                    </button>
                    <button
                        type="button"
                        className="sh-btn"
                        disabled={busy}
                        onClick={() => handlePauseIntegrity(4)}
                    >
                        Pausar 4 h
                    </button>
                    <button
                        type="button"
                        className="sh-btn"
                        disabled={busy}
                        onClick={() => handlePauseIntegrity(8)}
                    >
                        Pausar 8 h
                    </button>
                </div>
            )}

            {integrityLocked && (
                <div className="sh-banner error sh-integrity-banner">
                    <div>
                        <strong>Escritura bloqueada por protección antiransomware.</strong>
                        <p>
                            {integrity.detail
                                || "Se detectaron muchos cambios de archivos a la vez."}
                        </p>
                        <p>
                            Los compartidos están en solo lectura. Revisa los PCs de la LAN
                            antes de reactivar la escritura.
                        </p>
                    </div>
                    {isAdmin && (
                        <button
                            type="button"
                            className="sh-btn danger"
                            disabled={busy}
                            onClick={handleUnlockIntegrity}
                        >
                            Reactivar escritura
                        </button>
                    )}
                </div>
            )}

            {diskHealth && diskHealth.smartctl_installed === false && (
                <div className="sh-banner warn">
                    Vigilancia SMART no disponible. Instala: <code>sudo apt-get install -y smartmontools</code>
                </div>
            )}

            {diskHealthProblems.length > 0 && (
                <div className={`sh-banner ${diskHealth?.worst === "critical" ? "error" : "warn"}`}>
                    <strong>Salud del disco:</strong>
                    <ul className="sh-health-list">
                        {diskHealthProblems.map((d) => (
                            <li key={d.device}>
                                <code>{d.device}</code>
                                {d.model ? ` (${d.model})` : ""} — {d.message}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {error && <div className="sh-banner error">{error}</div>}
            {notice && <div className="sh-banner ok">{notice}</div>}

            <div className="sh-split">
                <section className="sh-pane sh-pane-left">
                    <h2>Unidades</h2>
                    {disks.length === 0 ? (
                        <p className="sh-empty">
                            No hay discos adicionales. Conecta un USB o un disco aparte del sistema.
                        </p>
                    ) : (
                        disks.map((disk) => {
                            const bus = (disk.transport || "").toLowerCase() === "usb"
                                ? "USB"
                                : (disk.transport || "disco").toUpperCase();
                            return (
                                <div key={disk.disk} className="sh-disk-block">
                                    <div className="sh-disk-head">
                                        <strong>{bus}</strong>
                                        <span>/dev/{disk.disk}</span>
                                        {disk.model ? <span>{disk.model}</span> : null}
                                    </div>
                                    <ul className="sh-part-list">
                                        {disk.parts.map((unit) => {
                                            const sharing = Boolean(unit.sharing);
                                            const canShare = Boolean(unit.selectable) && !sharing;
                                            const needsFormat = !unit.fstype || !unit.uuid;
                                            const size = formatSize(unit.size);
                                            const nameValue = names[unit.device] ?? (unit.share_name || "");
                                            const active = selectedDevice === unit.device;

                                            return (
                                                <li
                                                    key={unit.device}
                                                    className={[
                                                        "sh-part-row",
                                                        sharing ? "sharing" : "",
                                                        active ? "selected" : "",
                                                    ].filter(Boolean).join(" ")}
                                                    onClick={() => setSelectedDevice(unit.device)}
                                                >
                                                    <div className="sh-part-main">
                                                        <div className="sh-part-title">
                                                            <strong>{unit.device}</strong>
                                                            {size ? <span className="sh-part-meta">{size}</span> : null}
                                                            {unit.fstype ? (
                                                                <span className="sh-part-meta">{unit.fstype}</span>
                                                            ) : (
                                                                <span className="sh-part-meta warn">sin formato</span>
                                                            )}
                                                        </div>
                                                        {sharing ? (
                                                            <div className="sh-part-share-info">
                                                                <strong>{unit.share_name}</strong>
                                                            </div>
                                                        ) : needsFormat ? (
                                                            <p className="sh-part-hint">Formatea para compartir</p>
                                                        ) : (
                                                            <label
                                                                className="sh-name-field"
                                                                onClick={(e) => e.stopPropagation()}
                                                            >
                                                                <span>Nombre</span>
                                                                <input
                                                                    type="text"
                                                                    value={nameValue}
                                                                    disabled={!isAdmin || busy}
                                                                    placeholder="ej. Produccion"
                                                                    maxLength={64}
                                                                    onChange={(e) => setName(unit.device, e.target.value)}
                                                                />
                                                            </label>
                                                        )}
                                                    </div>
                                                    <div
                                                        className="sh-part-actions"
                                                        onClick={(e) => e.stopPropagation()}
                                                    >
                                                        {sharing ? (
                                                            <button
                                                                type="button"
                                                                className="sh-btn danger"
                                                                disabled={!isAdmin || busy}
                                                                onClick={(e) => handleUnshare(unit, e)}
                                                            >
                                                                Dejar de compartir
                                                            </button>
                                                        ) : needsFormat ? (
                                                            <>
                                                                <button
                                                                    type="button"
                                                                    className="sh-btn"
                                                                    disabled={!isAdmin || busy || !unit.formattable}
                                                                    onClick={(e) => handleFormat(unit, e)}
                                                                >
                                                                    Formatear
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    className="sh-btn danger"
                                                                    disabled={!isAdmin || busy}
                                                                    onClick={(e) => handleDeletePartition(unit, e)}
                                                                >
                                                                    Eliminar partición
                                                                </button>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <button
                                                                    type="button"
                                                                    className="sh-btn primary"
                                                                    disabled={!isAdmin || busy || !canShare}
                                                                    onClick={(e) => handleShare(unit, e)}
                                                                >
                                                                    Compartir
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    className="sh-btn danger"
                                                                    disabled={!isAdmin || busy}
                                                                    onClick={(e) => handleDeletePartition(unit, e)}
                                                                >
                                                                    Eliminar partición
                                                                </button>
                                                            </>
                                                        )}
                                                    </div>
                                                </li>
                                            );
                                        })}
                                    </ul>
                                </div>
                            );
                        })
                    )}
                </section>

                <section className="sh-pane sh-pane-right">
                    <h2>Contenido</h2>
                    {!selected ? (
                        <p className="sh-empty">Selecciona una partición a la izquierda.</p>
                    ) : !selected.sharing ? (
                        <div className="sh-empty-block">
                            <p className="sh-empty">
                                <strong>{selected.device}</strong> no está compartida.
                            </p>
                            <p className="sh-empty">
                                Comparte la partición (con un nombre) para crear carpetas y asignar permisos.
                            </p>
                        </div>
                    ) : (
                        <>
                            <div className="sh-content-head">
                                <div>
                                    <strong>{selected.share_name}</strong>
                                    <span className="sh-part-meta">{selected.device}</span>
                                </div>
                                {selected.unc_path ? (
                                    <code className="sh-inline-code">{selected.unc_path}</code>
                                ) : null}
                            </div>

                            {isAdmin && (
                                <form
                                    className="sh-folder-create"
                                    onSubmit={(e) => {
                                        e.preventDefault();
                                        handleCreateFolder();
                                    }}
                                >
                                    <input
                                        type="text"
                                        value={folderName}
                                        disabled={busy}
                                        placeholder="Nueva carpeta (ej. Documentos)"
                                        maxLength={64}
                                        onChange={(e) => setFolderName(e.target.value)}
                                    />
                                    <button
                                        type="submit"
                                        className="sh-btn primary"
                                        disabled={busy || !folderName.trim()}
                                    >
                                        Crear carpeta
                                    </button>
                                </form>
                            )}

                            {selectedFolders.length === 0 ? (
                                <p className="sh-empty">
                                    Sin carpetas. Crea una y asígnale permisos por grupo.
                                    Mientras no haya carpetas, la unidad se publica entera en la LAN.
                                </p>
                            ) : (
                                <ul className="sh-folder-list">
                                    {selectedFolders.map((folder) => (
                                        <li key={folder.id} className="sh-folder-card">
                                            <div className="sh-folder-top">
                                                <div>
                                                    <strong>{folder.name}</strong>
                                                    {folder.unc_path ? (
                                                        <code className="sh-inline-code">{folder.unc_path}</code>
                                                    ) : null}
                                                </div>
                                                {isAdmin && (
                                                    <button
                                                        type="button"
                                                        className="sh-btn danger sh-btn-sm"
                                                        disabled={busy}
                                                        onClick={() => handleDeleteFolder(folder)}
                                                    >
                                                        Eliminar
                                                    </button>
                                                )}
                                            </div>

                                            <p className="sh-folder-perm-label">Permisos por grupo</p>
                                            {groups.length === 0 ? (
                                                <p className="sh-part-hint">
                                                    No hay grupos. Créalos en Grupos de dispositivos.
                                                </p>
                                            ) : (
                                                <ul className="sh-perm-list">
                                                    {groups.map((group) => {
                                                        const grant = (folder.groups || []).find(
                                                            (g) => g.group_id === group.id
                                                        );
                                                        return (
                                                            <li key={group.id} className="sh-perm-row">
                                                                <span>{group.name}</span>
                                                                {isAdmin ? (
                                                                    <span className="sh-perm-actions">
                                                                        <button
                                                                            type="button"
                                                                            className={grant?.access_mode === "read" ? "active" : ""}
                                                                            disabled={busy}
                                                                            onClick={() =>
                                                                                toggleFolderGroup(folder, group.id, "read")
                                                                            }
                                                                        >
                                                                            Lectura
                                                                        </button>
                                                                        <button
                                                                            type="button"
                                                                            className={grant?.access_mode === "write" ? "active" : ""}
                                                                            disabled={busy}
                                                                            onClick={() =>
                                                                                toggleFolderGroup(folder, group.id, "write")
                                                                            }
                                                                        >
                                                                            Escritura
                                                                        </button>
                                                                    </span>
                                                                ) : (
                                                                    <span className="sh-part-meta">
                                                                        {grant
                                                                            ? (grant.access_mode === "write" ? "Escritura" : "Lectura")
                                                                            : "Sin acceso"}
                                                                    </span>
                                                                )}
                                                            </li>
                                                        );
                                                    })}
                                                </ul>
                                            )}
                                            {(folder.groups || []).length === 0 && (
                                                <p className="sh-part-hint warn">
                                                    Sin permisos: esta carpeta no se publica en la red.
                                                </p>
                                            )}
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </>
                    )}
                </section>
            </div>
        </div>
    );
}


export default Shares;
