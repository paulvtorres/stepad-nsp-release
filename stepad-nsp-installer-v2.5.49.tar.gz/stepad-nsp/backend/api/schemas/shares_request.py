from pydantic import BaseModel, Field


class UpdateShareSettingsRequest(BaseModel):

    enabled: bool | None = None

    share_root: str | None = None

    workgroup: str | None = None

    server_name: str | None = None


class AssignShareDiskRequest(BaseModel):

    device: str


class FormatShareDiskRequest(BaseModel):

    device: str

    # Must be exactly FORMATEAR to proceed.
    confirm: str

    assign: bool = False

    whole_disk: bool = False


class DeletePartitionRequest(BaseModel):

    device: str

    # Must be exactly ELIMINAR to proceed.
    confirm: str


class PauseIntegrityRequest(BaseModel):

    hours: float = 2


class ShareVolumeRequest(BaseModel):

    device: str

    name: str


class CreateShareFolderRequest(BaseModel):

    name: str

    volume_id: int

    folder_name: str | None = None

    description: str | None = None


class FolderGroupGrant(BaseModel):

    group_id: int

    access_mode: str = Field(default="read")


class SetFolderGroupsRequest(BaseModel):

    groups: list[FolderGroupGrant] = Field(default_factory=list)


class GroupFolderGrant(BaseModel):

    folder_id: int

    access_mode: str = Field(default="read")


class SetGroupFoldersRequest(BaseModel):

    folders: list[GroupFolderGrant] = Field(default_factory=list)


class GroupVolumeGrant(BaseModel):

    volume_id: int

    access_mode: str = Field(default="read")


class SetGroupVolumesRequest(BaseModel):

    volumes: list[GroupVolumeGrant] = Field(default_factory=list)
