"""
Mount / protect the dedicated STEPAD network-share disk.

The share disk is always mounted at SHARE_DISK_MOUNT via a systemd
.mount unit keyed by filesystem UUID. While assigned (disk_locked),
it is not meant to be unmounted by hand — only released from the NSP UI.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from backend.core.config.paths import (
    SHARE_DISK_MOUNT,
    SHARE_DISK_MOUNT_UNIT,
)
from backend.shared.logging.logger import logger


class ShareDiskMountProvider:

    UNIT_PATH = Path(f"/etc/systemd/system/{SHARE_DISK_MOUNT_UNIT}")

    def _run(self, command: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
        return subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    def blkid_field(self, device: str, field: str) -> str | None:
        result = self._run(["blkid", "-s", field, "-o", "value", device])
        if result.returncode != 0:
            return None
        value = (result.stdout or "").strip()
        return value or None

    def is_mounted_at(self, mountpoint: Path | str) -> bool:
        result = self._run(["findmnt", "-n", str(mountpoint)])
        return result.returncode == 0 and bool(result.stdout.strip())

    def current_source(self, mountpoint: Path | str) -> str | None:
        result = self._run(["findmnt", "-n", "-o", "SOURCE", str(mountpoint)])
        if result.returncode != 0:
            return None
        return (result.stdout or "").strip() or None

    @staticmethod
    def unit_name_for_mount(mountpoint: Path | str) -> str:
        """
        /mnt/stepad-share/datos -> mnt-stepad-share-datos.mount
        """

        raw = str(mountpoint).strip("/")
        escaped = raw.replace("-", "\\x2d").replace("/", "-")
        return f"{escaped}.mount"

    def write_volume_mount_unit(
        self,
        *,
        uuid: str,
        fstype: str,
        mountpoint: Path | str,
    ) -> str:
        mountpoint = Path(mountpoint)
        mountpoint.mkdir(parents=True, exist_ok=True)
        unit = self.unit_name_for_mount(mountpoint)
        unit_path = Path("/etc/systemd/system") / unit

        content = "\n".join([
            "[Unit]",
            f"Description=STEPAD share volume {mountpoint} (do not unmount manually)",
            "Before=smbd.service nmbd.service",
            "Conflicts=umount.target",
            "",
            "[Mount]",
            f"What=/dev/disk/by-uuid/{uuid}",
            f"Where={mountpoint}",
            f"Type={fstype}",
            "Options=defaults,nofail,x-systemd.device-timeout=10s",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ])
        unit_path.write_text(content, encoding="utf-8")
        self._run(["systemctl", "daemon-reload"])
        return unit

    def activate_unit(self, unit: str, mountpoint: Path | str) -> dict:
        self._run(["systemctl", "enable", unit])
        start = self._run(["systemctl", "start", unit])
        active = self._run(["systemctl", "is-active", unit])
        ok = active.stdout.strip() == "active" or self.is_mounted_at(mountpoint)
        if not ok:
            detail = (start.stderr or active.stderr or "").strip()
            return {"success": False, "message": detail or "No se pudo montar."}
        return {"success": True, "mountpoint": str(mountpoint), "unit": unit}

    def deactivate_unit(self, unit: str, mountpoint: Path | str) -> dict:
        self._run(["systemctl", "stop", unit])
        self._run(["systemctl", "disable", unit])
        unit_path = Path("/etc/systemd/system") / unit
        if unit_path.exists():
            try:
                unit_path.unlink()
            except Exception as error:
                logger.warning("Could not remove unit %s: %s", unit, error)
        self._run(["systemctl", "daemon-reload"])
        if self.is_mounted_at(mountpoint):
            umount = self._run(["umount", str(mountpoint)])
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        "Se dejó de compartir, pero el volumen sigue montado "
                        f"(ocupado): {(umount.stderr or '').strip()}"
                    ),
                }
        return {"success": True, "message": "Volumen liberado."}

    def write_mount_unit(self, *, uuid: str, fstype: str) -> None:
        SHARE_DISK_MOUNT.mkdir(parents=True, exist_ok=True)

        # Keep the volume busy-friendly for Samba and remount on boot.
        content = "\n".join([
            "[Unit]",
            "Description=STEPAD network share disk (do not unmount manually)",
            "Documentation=https://stepad.local/shares",
            "Before=smbd.service nmbd.service",
            "Conflicts=umount.target",
            "",
            "[Mount]",
            f"What=/dev/disk/by-uuid/{uuid}",
            f"Where={SHARE_DISK_MOUNT}",
            f"Type={fstype}",
            "Options=defaults,nofail,x-systemd.device-timeout=10s",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ])

        self.UNIT_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.UNIT_PATH.write_text(content, encoding="utf-8")

        self._run(["systemctl", "daemon-reload"])

    def activate(self) -> dict:
        enable = self._run(["systemctl", "enable", SHARE_DISK_MOUNT_UNIT])
        start = self._run(["systemctl", "start", SHARE_DISK_MOUNT_UNIT])
        active = self._run(["systemctl", "is-active", SHARE_DISK_MOUNT_UNIT])

        ok = active.stdout.strip() == "active" or self.is_mounted_at(SHARE_DISK_MOUNT)

        if not ok:
            detail = (start.stderr or enable.stderr or active.stderr or "").strip()
            logger.error("Failed to activate share disk mount: %s", detail)
            return {"success": False, "message": detail or "No se pudo montar el disco."}

        return {
            "success": True,
            "mountpoint": str(SHARE_DISK_MOUNT),
            "message": "Disco montado y protegido.",
        }

    def deactivate(self) -> dict:
        self._run(["systemctl", "stop", SHARE_DISK_MOUNT_UNIT])
        self._run(["systemctl", "disable", SHARE_DISK_MOUNT_UNIT])

        if self.UNIT_PATH.exists():
            try:
                self.UNIT_PATH.unlink()
            except Exception as error:
                logger.warning("Could not remove mount unit: %s", error)

        self._run(["systemctl", "daemon-reload"])

        # Best-effort manual umount if still mounted.
        if self.is_mounted_at(SHARE_DISK_MOUNT):
            umount = self._run(["umount", str(SHARE_DISK_MOUNT)])
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        "Disco liberado en configuración, pero sigue montado "
                        f"(ocupado): {(umount.stderr or '').strip()}"
                    ),
                }

        return {"success": True, "message": "Disco liberado."}

    def format_ext4(
        self,
        device: str,
        *,
        label: str = "STEPAD-SHARE",
    ) -> dict:
        """
        Destructive: create ext4 on an existing partition.
        Windows clients access via Samba; ext4 is the NSP-side FS.
        """

        if not device.startswith("/dev/"):
            return {"success": False, "message": "Dispositivo inválido."}

        # Refuse if mounted anywhere.
        findmnt = self._run(["findmnt", "-n", "-S", device])
        if findmnt.returncode == 0 and findmnt.stdout.strip():
            return {
                "success": False,
                "message": (
                    f"{device} está montado. Desmóntalo o libéralo "
                    "antes de formatear."
                ),
            }

        mkfs = self._run(
            [
                "mkfs.ext4",
                "-F",
                "-L", label[:16],
                device,
            ],
            timeout=600,
        )

        if mkfs.returncode != 0:
            return {
                "success": False,
                "message": (mkfs.stderr or mkfs.stdout or "mkfs.ext4 falló").strip(),
            }

        # Refresh kernel partition table / udev.
        self._run(["udevadm", "settle"], timeout=30)
        uuid = self.blkid_field(device, "UUID")
        fstype = self.blkid_field(device, "TYPE") or "ext4"

        return {
            "success": True,
            "device": device,
            "uuid": uuid,
            "fstype": fstype,
            "message": f"Formateado {device} como ext4 (listo para Windows vía Samba).",
        }

    def prepare_whole_disk(
        self,
        disk: str,
        *,
        label: str = "STEPAD-SHARE",
    ) -> dict:
        """
        Wipe the entire secondary disk (any existing partitions), create
        a single GPT partition, and format ext4 for Samba sharing.
        """

        if not disk.startswith("/dev/"):
            return {"success": False, "message": "Disco inválido."}

        # Unmount every mounted child partition on this disk.
        lsblk = self._run(["lsblk", "-lnpo", "NAME,MOUNTPOINT", disk])
        for line in (lsblk.stdout or "").splitlines():
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            name, mountpoint = parts[0].strip(), parts[1].strip()
            if not mountpoint:
                continue
            if mountpoint.rstrip("/") in ("/", "/boot", "/boot/efi", "/home", "/var"):
                return {
                    "success": False,
                    "message": (
                        f"No se puede borrar {disk}: tiene montado "
                        f"{mountpoint} (ruta de sistema)."
                    ),
                }
            umount = self._run(["umount", mountpoint], timeout=60)
            if umount.returncode != 0:
                # Lazy unmount as fallback when busy.
                umount = self._run(["umount", "-l", mountpoint], timeout=60)
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        f"No se pudo desmontar {name} ({mountpoint}). "
                        "Libera el disco compartido o cierra usos del volumen."
                    ),
                }

        # Wipe partition signatures then the disk itself.
        children = self._run(["lsblk", "-lnpo", "NAME,TYPE", disk])
        for line in (children.stdout or "").splitlines():
            bits = line.split()
            if len(bits) >= 2 and bits[1] == "part":
                self._run(["wipefs", "-a", bits[0]], timeout=60)

        self._run(["wipefs", "-a", disk], timeout=60)

        parted = self._run(
            [
                "parted", "-s", disk,
                "mklabel", "gpt",
                "mkpart", "primary", "ext4", "1MiB", "100%",
            ],
            timeout=120,
        )
        if parted.returncode != 0:
            return {
                "success": False,
                "message": (parted.stderr or parted.stdout or "parted falló").strip(),
            }

        self._run(["partprobe", disk], timeout=30)
        self._run(["udevadm", "settle"], timeout=30)

        part = None
        for candidate in (f"{disk}1", f"{disk}p1"):
            if Path(candidate).exists():
                part = candidate
                break

        if not part:
            import time
            for _ in range(15):
                time.sleep(0.4)
                for candidate in (f"{disk}1", f"{disk}p1"):
                    if Path(candidate).exists():
                        part = candidate
                        break
                if part:
                    break

        if not part:
            return {
                "success": False,
                "message": "Se creó la partición pero no aparece el dispositivo.",
            }

        formatted = self.format_ext4(part, label=label)
        if formatted.get("success"):
            formatted["message"] = (
                f"Disco {disk} unificado en una sola partición ext4 "
                f"({part}). Listo para compartir con Windows vía Samba."
            )
        return formatted

    def delete_partition(self, device: str) -> dict:
        """
        Destructive: remove one partition from a secondary disk.
        Does not touch the OS disk.
        """

        if not device.startswith("/dev/"):
            return {"success": False, "message": "Partición inválida."}

        typ = self._run(["lsblk", "-no", "TYPE", device])
        if (typ.stdout or "").strip().lower() != "part":
            return {"success": False, "message": "Solo se pueden eliminar particiones."}

        pkname = (self._run(["lsblk", "-no", "PKNAME", device]).stdout or "").strip()
        if not pkname:
            return {"success": False, "message": "No se pudo determinar el disco padre."}
        disk = f"/dev/{pkname}"

        partn = (self._run(["lsblk", "-no", "PARTN", device]).stdout or "").strip()
        if not partn.isdigit():
            # Fallback: sdb1 -> 1, nvme0n1p3 -> 3
            name = Path(device).name
            digits = ""
            for ch in reversed(name):
                if ch.isdigit():
                    digits = ch + digits
                else:
                    break
            partn = digits
        if not partn.isdigit():
            return {"success": False, "message": "No se pudo determinar el número de partición."}

        mountpoint = (self._run(["lsblk", "-no", "MOUNTPOINT", device]).stdout or "").strip()
        if mountpoint:
            if mountpoint.rstrip("/") in ("/", "/boot", "/boot/efi", "/home", "/var"):
                return {
                    "success": False,
                    "message": f"No se puede eliminar {device}: montada en {mountpoint}.",
                }
            umount = self._run(["umount", mountpoint], timeout=60)
            if umount.returncode != 0:
                umount = self._run(["umount", "-l", mountpoint], timeout=60)
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        f"No se pudo desmontar {device} ({mountpoint}). "
                        "Déjala de compartir o cierra usos del volumen."
                    ),
                }

        self._run(["wipefs", "-a", device], timeout=60)

        parted = self._run(
            ["parted", "-s", disk, "rm", partn],
            timeout=120,
        )
        if parted.returncode != 0:
            return {
                "success": False,
                "message": (parted.stderr or parted.stdout or "parted rm falló").strip(),
            }

        self._run(["partprobe", disk], timeout=30)
        self._run(["udevadm", "settle"], timeout=30)

        return {
            "success": True,
            "device": device,
            "disk": disk,
            "message": f"Partición {device} eliminada del disco {disk}.",
        }

    def ensure_boot(self, uuid: str | None, fstype: str | None = None) -> None:
        if not uuid:
            return
        fstype = fstype or self.blkid_field(f"/dev/disk/by-uuid/{uuid}", "TYPE") or "auto"
        try:
            self.write_mount_unit(uuid=uuid, fstype=fstype)
            self.activate()
        except Exception as error:
            logger.error("Share disk boot mount failed: %s", error)

