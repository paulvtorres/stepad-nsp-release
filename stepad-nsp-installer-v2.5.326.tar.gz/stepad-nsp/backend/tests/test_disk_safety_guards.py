"""Salvaguardas de disco: nunca tocar el disco del sistema."""
from __future__ import annotations

import pytest
from fastapi import HTTPException

from backend.shares.services import disk_guard


class TestWholeDiskFor:
    def test_partition_to_parent(self, monkeypatch):
        monkeypatch.setattr(
            disk_guard, "_run", lambda cmd: "sdb" if "PKNAME" in cmd else ""
        )
        assert disk_guard.whole_disk_for("/dev/sdb2") == "sdb"

    def test_whole_disk_itself_returns_none(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "_run", lambda cmd: "")
        assert disk_guard.whole_disk_for("/dev/sdb") is None

    def test_empty_device(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "_run", lambda cmd: "sdb")
        assert disk_guard.whole_disk_for("") is None


class TestSystemDiskNames:
    def test_root_and_swap_form_the_system_set(self, monkeypatch):
        def fake_run(cmd):
            if "PKNAME" in cmd:
                return "sdb"
            if "findmnt" in cmd:
                return "/dev/sdb2"
            return ""

        monkeypatch.setattr(disk_guard, "_run", fake_run)
        names = disk_guard.system_disk_names()
        assert "sdb" in names


class TestEnsureNotSystemDisk:
    def test_rejects_system_device(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "whole_disk_for", lambda dev: "sdb")
        monkeypatch.setattr(disk_guard, "system_disk_names", lambda: {"sdb"})
        with pytest.raises(HTTPException):
            disk_guard.ensure_not_system_disk("/dev/sdb2", "montar")

    def test_allows_data_device(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "whole_disk_for", lambda dev: "sdc")
        monkeypatch.setattr(disk_guard, "system_disk_names", lambda: {"sdb"})
        disk_guard.ensure_not_system_disk("/dev/sdc1", "montar")


class TestRestoreDestinationGuard:
    def test_rejects_directory_on_system_disk(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "mount_source_for", lambda p: "/dev/sdb2")
        monkeypatch.setattr(disk_guard, "is_system_disk", lambda dev: True)
        with pytest.raises(HTTPException):
            disk_guard.ensure_restore_destination_safe("/mnt/stepad-share/sda2")

    def test_rejects_tmpfs(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "mount_source_for", lambda p: "tmpfs")
        with pytest.raises(HTTPException):
            disk_guard.ensure_restore_destination_safe("/tmp/algo")

    def test_rejects_unknown_source(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "mount_source_for", lambda p: None)
        with pytest.raises(HTTPException):
            disk_guard.ensure_restore_destination_safe("/mnt/foo")

    def test_allows_network_mount(self, monkeypatch):
        monkeypatch.setattr(
            disk_guard, "mount_source_for", lambda p: "//192.168.1.41/share"
        )
        disk_guard.ensure_restore_destination_safe("/mnt/stepad-network/M")

    def test_allows_data_device(self, monkeypatch):
        monkeypatch.setattr(disk_guard, "mount_source_for", lambda p: "/dev/sda2")
        monkeypatch.setattr(disk_guard, "is_system_disk", lambda dev: False)
        disk_guard.ensure_restore_destination_safe("/mnt/stepad-share/sda2")