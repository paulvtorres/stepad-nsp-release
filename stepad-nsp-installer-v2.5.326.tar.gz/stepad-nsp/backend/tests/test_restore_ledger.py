"""Bitácora persistente de restauraciones: interrupción/reintentar/limpiar."""
from __future__ import annotations

import json
import os
from pathlib import Path

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

import pytest
from fastapi import HTTPException

from backend.shares.services.share_backup_service import ShareBackupService


def _service(tmp_path, monkeypatch) -> ShareBackupService:
    monkeypatch.setenv("RESTORE_STATE_PATH", str(tmp_path / "restore_state.json"))
    return ShareBackupService()


def _ledger(service) -> dict:
    return json.loads(service._restore_ledger_path().read_text("utf-8"))


def test_upsert_persists_entry(tmp_path, monkeypatch):
    service = _service(tmp_path, monkeypatch)
    service._upsert_restore_ledger(7, status="running", snapshot_id="abc", destination="/mnt/x")
    entry = _ledger(service)["restores"]["7"]
    assert entry["status"] == "running"
    assert entry["job_id"] == 7
    assert entry["snapshot_id"] == "abc"


def test_reconcile_marks_dangling_running_as_interrupted(tmp_path, monkeypatch):
    service = _service(tmp_path, monkeypatch)
    service._upsert_restore_ledger(7, status="running", pid=9999999, destination="/mnt/x")
    # Proceso nuevo: no hay estado en memoria -> la corrida quedó huérfana.
    rows = service.reconcile_restores()
    entry = next(r for r in rows if int(r["job_id"]) == 7)
    assert entry["status"] == "interrupted"


def test_running_with_alive_heartbeat_not_reconciled(tmp_path, monkeypatch):
    service = _service(tmp_path, monkeypatch)
    # Estado en memoria activo → no se toca aunque el pid no esté.
    service._restore_status[7] = {"running": True, "error": None, "result": None}
    service._upsert_restore_ledger(7, status="running", pid=9999999, destination="/mnt/x")
    service.reconcile_restores()
    assert _ledger(service)["restores"]["7"]["status"] == "running"


def test_restore_status_merges_ledger(tmp_path, monkeypatch):
    service = _service(tmp_path, monkeypatch)
    service._upsert_restore_ledger(7, status="interrupted", snapshot_id="abc", destination="/mnt/x", error="Corte")
    st = service.restore_status(7)
    assert st.get("status") == "interrupted"
    assert st.get("interrupted") is True
    assert st.get("snapshot_id") == "abc"
    assert st.get("running") is False


def test_cleanup_removes_staging(tmp_path, monkeypatch):
    service = _service(tmp_path, monkeypatch)
    dest = tmp_path / "destino"
    staging = dest / ".stepad-restore.tmp"
    staging.mkdir(parents=True)
    (staging / "a.txt").write_text("x")
    service._upsert_restore_ledger(7, status="interrupted", destination=str(dest))
    res = service.cleanup_restore(7)
    assert res["cleaned"] is True
    assert not staging.exists()


def test_retry_requires_snapshot(tmp_path, monkeypatch):
    service = _service(tmp_path, monkeypatch)
    service._upsert_restore_ledger(7, status="interrupted", destination="/mnt/x")
    with pytest.raises(HTTPException):
        service.retry_restore(7)


def test_cancel_when_nothing_running(tmp_path, monkeypatch):
    service = _service(tmp_path, monkeypatch)
    res = service.cancel_restore(7)
    assert res["success"] is True
    assert res["was_running"] is False


def test_list_restores_sorted(tmp_path, monkeypatch):
    from backend.shares.services.share_backup_service import ShareBackupService as S
    service = _service(tmp_path, monkeypatch)
    service._upsert_restore_ledger(1, status="completed", started_at="2026-10-09T10:00:00")
    service._upsert_restore_ledger(2, status="interrupted", started_at="2026-10-09T11:00:00")
    rows = service.list_restores()
    assert [int(r["job_id"]) for r in rows] == [2, 1]