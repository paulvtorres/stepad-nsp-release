"""Resolución dinámica y VERIFICADA del dispositivo de montaje."""
from __future__ import annotations

import os

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

import pytest

from backend.shares.providers.share_disk_mount_provider import ShareDiskMountProvider
from backend.shares.services import disk_guard


def _provider(monkeypatch, *, exists=None, system=False):
    monkeypatch.setattr(disk_guard, "is_system_disk", lambda d: system)
    if exists is not None:
        monkeypatch.setattr(os.path, "exists", exists)
    return ShareDiskMountProvider()


class TestResolveDevice:
    def test_prefers_by_uuid(self, monkeypatch):
        p = _provider(monkeypatch, exists=lambda x: x == "/dev/disk/by-uuid/U")
        assert p.resolve_device(uuid="U") == "/dev/disk/by-uuid/U"

    def test_device_path_only_if_identity_matches(self, monkeypatch):
        p = _provider(monkeypatch, exists=lambda x: x == "/dev/sdb2")
        monkeypatch.setattr(p, "blkid_field", lambda dev, field: "REAL-UUID" if field == "UUID" else None)
        assert p.resolve_device(uuid="REAL-UUID", device_path="/dev/sdb2") == "/dev/sdb2"

    def test_device_path_rejected_on_identity_mismatch(self, monkeypatch):
        # El device_path (letra) apunta a otra partición: NO se debe usar.
        p = _provider(monkeypatch, exists=lambda x: x == "/dev/sdb1")
        monkeypatch.setattr(p, "blkid_field", lambda dev, field: "OTRA-UUID" if field == "UUID" else None)
        monkeypatch.setattr(p, "_run", lambda cmd: "")
        assert p.resolve_device(uuid="ESPERADO", device_path="/dev/sdb1") is None

    def test_never_returns_system_disk(self, monkeypatch):
        p = _provider(monkeypatch, exists=lambda x: True, system=True)
        monkeypatch.setattr(p, "_run", lambda cmd: "")
        assert p.resolve_device(uuid="U", device_path="/dev/sda2") is None

    def test_scan_lsblk_by_uuid_when_symlink_lags(self, monkeypatch):
        p = _provider(monkeypatch, exists=lambda x: False)
        monkeypatch.setattr(
            p,
            "_run",
            lambda cmd: (
                'PATH="/dev/sdb2" PARTUUID="pp-2222" UUID="914415f4" LABEL="STEPAD-PRIVATE"\n'
                'PATH="/dev/sdb1" PARTUUID="pp-1111" UUID="OTHER" LABEL="STEPAD-BACKUP"\n'
            ),
        )
        assert p.resolve_device(uuid="914415f4") == "/dev/sdb2"

    def test_resolve_by_partuuid_stable_across_reformat(self, monkeypatch):
        # PARTUUID no cambia al reformatear: aunque el UUID haya cambiado,
        # se resuelve la MISMA partición (clave canónica).
        p = _provider(monkeypatch, exists=lambda x: False)
        monkeypatch.setattr(
            p,
            "_run",
            lambda cmd: (
                'PATH="/dev/sdb2" PARTUUID="pp-2222" UUID="NUEVO-UUID" LABEL="STEPAD-PRIVATE"\n'
            ),
        )
        assert p.resolve_device(partuuid="pp-2222") == "/dev/sdb2"

    def test_none_when_partuuid_missing(self, monkeypatch):
        p = _provider(monkeypatch, exists=lambda x: False)
        monkeypatch.setattr(
            p,
            "_run",
            lambda cmd: 'PATH="/dev/sdb1" PARTUUID="pp-1111" UUID="OTHER" LABEL=""\n',
        )
        assert p.resolve_device(partuuid="pp-9999") is None

    def test_none_when_not_found(self, monkeypatch):
        p = _provider(monkeypatch, exists=lambda x: False)
        monkeypatch.setattr(p, "_run", lambda cmd: "")
        assert p.resolve_device(uuid="NOPE", device_path="/dev/nope") is None