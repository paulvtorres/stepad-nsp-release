"""net_rate_shaper.py — limite de ancho de banda del trafico de red de los respaldos.

restic lee el origen (share SMB) a velocidad plena del enlace y puede saturar
la conectividad de los usuarios. Este modulo aplica QoS (tc HTB + ifb) para
acotar el trafico hacia el IP del origen a un limite configurable por job o,
por defecto, al 50% del enlace fisico.

Garantias (por diseno):
  - GENERICO: sirve para cualquier maquina/origen (deriva el IP de la unidad
    de red y la interfaz en runtime).
  - BEST-EFFORT: si algo falla (sin tc, sin ifb, permisos, IP no resuelto) se
    loguea y el respaldo corre SIN limite; nunca rompe el respaldo.
  - LIMPIEZA garantizada: al terminar la corrida se quita el shaper.
  - SIEMPRE deja aire de red: jamas aplica mas del 80% del enlace.
"""

from __future__ import annotations

import logging
import re
import shutil
import socket
import subprocess

_logger = logging.getLogger("STEPAD NSP:net_rate_shaper")

DEFAULT_SAFETY_FRACTION = 0.5  # por defecto no usar mas del 50% del enlace
HARD_MAX_FRACTION = 0.8        # nunca mas del 80% (ni siquiera si se configura mas)


def source_ip_for_mount(mountpoint: str, mounts_text: str | None = None) -> str | None:
    """IP del servidor de un mount SMB (campo addr= en /proc/mounts)."""
    text = mounts_text if mounts_text is not None else _read_proc_mounts()
    mp = mountpoint.rstrip("/")
    for line in text.splitlines():
        if " " + mp + " " in line and " cifs " in line:
            m = re.search(r"addr=([0-9.]+)", line)
            if m:
                return m.group(1)
    return None


def source_ip_for_host(host: str) -> str | None:
    """Resuelve el hostname de la unidad de red a una IP (fallback)."""
    if not host:
        return None
    if re.match(r"^[0-9.]+$", host):
        return host
    try:
        return socket.gethostbyname(host)
    except Exception:
        return None


def interface_for(dst_ip: str) -> str | None:
    """Interfaz del NSP por la que sale hacia el origen."""
    try:
        r = subprocess.run(
            ["ip", "route", "get", dst_ip],
            capture_output=True, text=True, timeout=10,
        )
        for part in r.stdout.split():
            if part.startswith("dev"):
                continue
            if part == "dev":
                continue
        m = re.search(r"\bdev\s+(\S+)", r.stdout)
        return m.group(1) if m else None
    except Exception:
        return None


def link_speed_mbps(iface: str) -> int:
    """Velocidad del enlace (ethtool); fallback 1000 Mbps."""
    try:
        r = subprocess.run(["ethtool", iface], capture_output=True, text=True, timeout=10)
        m = re.search(r"Speed:\s*(\d+)Mb/s", r.stdout)
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return 1000


def effective_limit_mbps(configured: int | None, link_mbps: int) -> int:
    """Limite efectivo a aplicar (Mbps). 0 = sin limite."""
    if not link_mbps or link_mbps <= 0:
        return int(configured or 0)
    if configured and configured > 0:
        return max(1, min(int(configured), int(link_mbps * HARD_MAX_FRACTION)))
    if configured == 0:
        return 0
    return max(1, int(link_mbps * DEFAULT_SAFETY_FRACTION))


def _read_proc_mounts() -> str:
    try:
        with open("/proc/mounts") as f:
            return f.read()
    except Exception:
        return ""


def _run_cmds(cmds: list[str]) -> bool:
    """Ejecuta comandos tc/ip; si CUALQUIERA falla se aborta devolviendo False."""
    for cmd in cmds:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            if r.returncode != 0:
                stderr = (r.stderr or "").strip()[:200]
                _logger.warning("net_rate_shaper: %s -> %s", " ".join(cmd), stderr or r.returncode)
                return False
        except Exception as error:
            _logger.warning("net_rate_shaper: cmd error %s: %s", " ".join(cmd), error)
            return False
    return True


def _tc_available() -> bool:
    return bool(shutil.which("tc")) and bool(shutil.which("ip"))


def apply(iface: str, dst_ip: str, mbps: int, link_mbps: int | None = None) -> dict | None:
    """Aplica el limite de Mbps para el trafico con el origen. Devuelve handle
    (para remove) o None si no aplico (mejor no limitar que romper)."""
    if not _tc_available():
        _logger.warning("net_rate_shaper: tc/ip no disponible; respaldo sin limite.")
        return None
    if not iface or not dst_ip or not mbps or mbps <= 0:
        return None
    link = link_mbps or link_speed_mbps(iface)
    kblink = int(link) * 1000
    kmbps = int(mbps) * 1000

    egress = [
        ["tc", "qdisc", "replace", "dev", iface, "root", "handle", "1:", "htb", "default", "10"],
        ["tc", "class", "replace", "dev", iface, "parent", "1:", "classid", "1:1", "htb", "rate", "%dkbit" % kblink],
        ["tc", "class", "replace", "dev", iface, "parent", "1:1", "classid", "1:10", "htb", "rate", "%dkbit" % kblink, "ceil", "%dkbit" % kblink],
        ["tc", "class", "replace", "dev", iface, "parent", "1:1", "classid", "1:11", "htb", "rate", "%dkbit" % kmbps, "ceil", "%dkbit" % kmbps],
        ["tc", "filter", "replace", "dev", iface, "parent", "1:", "protocol", "ip", "prio", "1", "u32",
         "match", "ip", "dst", dst_ip + "/32", "flowid", "1:11"],
    ]

    ifb = "ifb0"
    ingress = [
        ["ip", "link", "set", ifb, "up"],
        ["tc", "qdisc", "replace", "dev", iface, "ingress", "handle", "ffff:"],
        ["tc", "filter", "replace", "dev", iface, "parent", "ffff:", "protocol", "ip", "prio", "10", "u32",
         "match", "u32", "0", "0", "action", "mirred", "egress", "redirect", "dev", ifb],
        ["tc", "qdisc", "replace", "dev", ifb, "root", "handle", "1:", "htb", "default", "10"],
        ["tc", "class", "replace", "dev", ifb, "parent", "1:", "classid", "1:1", "htb", "rate", "%dkbit" % kblink],
        ["tc", "class", "replace", "dev", ifb, "parent", "1:1", "classid", "1:10", "htb", "rate", "%dkbit" % kblink, "ceil", "%dkbit" % kblink],
        ["tc", "class", "replace", "dev", ifb, "parent", "1:1", "classid", "1:11", "htb", "rate", "%dkbit" % kmbps, "ceil", "%dkbit" % kmbps],
        ["tc", "filter", "replace", "dev", ifb, "parent", "1:", "protocol", "ip", "prio", "1", "u32",
         "match", "ip", "src", dst_ip + "/32", "flowid", "1:11"],
    ]

    if not _run_cmds(egress) or not _run_cmds(ingress):
        # Intento de limpieza parcila; el respaldo sigue sin limite.
        remove(iface, dst_ip)
        return None

    _logger.info(
        "net_rate_shaper: respaldo limitado a %d Mbps por %s hacia %s (enlace %d Mbps).",
        mbps, iface, dst_ip, link,
    )
    return {"iface": iface, "ip": dst_ip}


def remove(iface: str, dst_ip: str) -> None:
    """Quita el shaper: elimina los qdisc agregados (el kernel restaura el
    default pfifo_fast al borrar root)."""
    if not _tc_available():
        return
    _run_cmds([
        ["tc", "qdisc", "del", "dev", "ifb0", "root"],
        ["tc", "filter", "del", "dev", iface, "parent", "ffff:", "prio", "10"],
        ["tc", "qdisc", "del", "dev", iface, "ingress"],
        ["tc", "qdisc", "del", "dev", iface, "root"],
    ])
    _logger.info("net_rate_shaper: limite removido para %s (%s).", iface, dst_ip)

def _interfaces_with_ip() -> list[str]:
    """Interfaces del NSP con IPv4 (excluye loopback/virtuales)."""
    out = []
    try:
        r = subprocess.run(["ip", "-o", "-4", "addr", "show"], capture_output=True, text=True, timeout=10)
        for line in r.stdout.splitlines():
            parts = line.split()
            if len(parts) >= 2 and parts[0] not in ("lo",) and not parts[0].startswith(("ifb", "tailscale", "wg", "docker", "veth")):
                out.append(parts[0])
    except Exception:
        pass
    return out


def _tc_show(*args: str) -> str:
    try:
        r = subprocess.run(["tc", "qdisc", "show", *args], capture_output=True, text=True, timeout=10)
        return r.stdout or ""
    except Exception:
        return ""


def cleanup_stale() -> None:
    """Quita shapers residuales (p. ej. dejados por un respaldo cortado a la
    fuerza o un reinicio): se invoca al arrancar el servicio. Solo borra lo
    que coincide con NUESTRA firma (htb 1: default 0x10), así nunca toca
    configuraciones ajenas."""
    if not _tc_available():
        return
    # ifb0 de ingress.
    _run_cmds([["tc", "qdisc", "del", "dev", "ifb0", "root"]])
    for iface in _interfaces_with_ip():
        show = _tc_show("dev", iface)
        if "htb 1:" in show and "default 0x10" in show:
            _run_cmds([["tc", "qdisc", "del", "dev", iface, "root"]])
            _logger.info("net_rate_shaper: limpiado shaper residual en %s.", iface)
        ingress = _tc_show("dev", iface, "ingress")
        if "ffff:" in ingress:
            _run_cmds([
                ["tc", "filter", "del", "dev", iface, "parent", "ffff:", "prio", "10"],
                ["tc", "qdisc", "del", "dev", iface, "ingress"],
            ])
