import { useEffect, useMemo, useState } from "react";

import {
    getDhcpConfig,
    setLanSegment,
    setDhcpExclusions,
    getTemporaryLanIpStatus,
    startTemporaryLanIp,
    revertTemporaryLanIp,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function netmaskToPrefix(mask) {
    // Convierte "255.255.255.0" -> 24 (o devuelve el valor si no es máscara).
    try {
        const parts = String(mask || "").split(".");
        if (parts.length !== 4) { return mask; }
        let ones = 0;
        for (const p of parts) {
            const v = Number(p);
            if (Number.isNaN(v) || v < 0 || v > 255) { return mask; }
            for (let b = 0; b < 8; b += 1) {
                if ((v >> b) & 1) { ones += 1; }
            }
        }
        return ones;
    } catch {
        return mask;
    }
}


function cidrGateway(cidr) {
    // Devuelve la IP del primer host (.1) de un CIDR "a.b.c.d/prefix".
    try {
        const idx = String(cidr).indexOf("/");
        const ip = (idx >= 0 ? String(cidr).slice(0, idx) : String(cidr)).trim();
        let prefix = idx >= 0 ? String(cidr).slice(idx + 1).trim() : "";
        const parts = ip.split(".").map(Number);
        if (parts.length !== 4 || parts.some((p) => Number.isNaN(p) || p < 0 || p > 255)) {
            return null;
        }
        if (prefix !== "" && Number.isNaN(Number(prefix))) {
            // Permitir máscara completa también.
            const pfx = netmaskToPrefix(prefix);
            if (typeof pfx !== "number") { return null; }
            prefix = pfx;
        }
        const addr = ((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0;
        const p = prefix === "" ? 24 : Number(prefix);
        if (p < 1 || p > 32) { return null; }
        const mask = p === 32 ? 0xFFFFFFFF : (~((1 << (32 - p)) - 1)) >>> 0;
        const net = (addr & mask) >>> 0;
        const gw = (net + 1) >>> 0;
        return [(gw >>> 24) & 255, (gw >>> 16) & 255, (gw >>> 8) & 255, gw & 255].join(".");
    } catch {
        return null;
    }
}


function cidrPrefix(cidr) {
    try {
        const idx = String(cidr).indexOf("/");
        const p = idx >= 0 ? String(cidr).slice(idx + 1).trim() : "";
        const n = p === "" ? 24 : Number(p);
        if (Number.isNaN(n) || n < 1 || n > 32) {
            const m = netmaskToPrefix(p);
            return typeof m === "number" ? m : null;
        }
        return n;
    } catch {
        return null;
    }
}


function LanSegmentPanel() {

    const [config, setConfig] = useState(null);

    const [network, setNetwork] = useState("");

    const [groupIpStart, setGroupIpStart] = useState("");

    const [groupIpEnd, setGroupIpEnd] = useState("");

    const [poolStart, setPoolStart] = useState("");

    const [poolEnd, setPoolEnd] = useState("");

    const [exclusions, setExclusions] = useState("");

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");

    const [loading, setLoading] = useState(true);


    const gatewayPreview = useMemo(() => cidrGateway(network), [network]);

    const cidrOk = gatewayPreview !== null;


    const [tempStatus, setTempStatus] = useState(null);

    const [tempBusy, setTempBusy] = useState(false);


    async function load() {

        try {

            const data = await getDhcpConfig();

            setConfig(data);

            if (data) {

                setNetwork(`${data.network}/${netmaskToPrefix(data.netmask)}`);
                setGroupIpStart(data.group_ip_start || "");
                setGroupIpEnd(data.group_ip_end || "");
                setPoolStart(data.pool_start);
                setPoolEnd(data.pool_end);
                setExclusions((data.excluded_ips || []).join(", "));

            }
            else {

                // Sin LAN primaria configurada: el backend devuelve null.
                // Se muestra un estado vacío claro, nunca un error de lectura.
                setNetwork("");
                setGroupIpStart("");
                setGroupIpEnd("");
                setPoolStart("");
                setPoolEnd("");
                setExclusions("");

            }

        } catch {

            setError("No se pudo leer la configuración DHCP.");

        }
        finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        load();

        loadTempStatus();

    }, []);


    function parseExclusions() {

        return exclusions
            .split(",")
            .map((x) => x.trim())
            .filter(Boolean);

    }

    function groupIpCount() {
        if (!groupIpStart || !groupIpEnd) {
            return config?.group_ip_count || 0;
        }
        try {
            const a = groupIpStart.split(".").map(Number);
            const b = groupIpEnd.split(".").map(Number);
            const start = ((a[0] << 24) >>> 0) + (a[1] << 16) + (a[2] << 8) + a[3];
            const end = ((b[0] << 24) >>> 0) + (b[1] << 16) + (b[2] << 8) + b[3];
            return Math.max(0, end - start + 1);
        } catch {
            return config?.group_ip_count || 0;
        }
    }


    async function handleChangeSegment() {

        // Cambio de segmento SOLO por red: el backend reubica el grupo y el
        // pool automáticamente y deja el NSP en la IP .1 del nuevo segmento.
        const cidr = String(network || "").trim();
        const gw = cidrGateway(cidr);
        if (gw === null) {
            setError("CIDR inválido. Usá el formato red/prefijo, ej. 192.168.10.0/24");
            return;
        }
        if (!window.confirm(
            `¿Cambiar el segmento LAN a ${cidr}?\n\n`
            + `La IP del NSP (gateway) quedará en ${gw} (la .1 del segmento).\n`
            + "Los reservas de grupos y el pool DHCP se recalculan solos.\n"
            + "La conexión LAN puede cortarse un instante mientras se "
            + "reconfigura la interfaz."
        )) {
            return;
        }
        setBusy(true);
        setMessage("");
        setError("");
        try {
            const result = await setLanSegment({ network: cidr });
            if (result?.success === false) {
                setError(result.message || "No se pudo cambiar el segmento.");
            } else {
                setMessage(`Segmento cambiado. El NSP quedó en ${gw} (.1).`);
            }
            await load();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudo cambiar el segmento."
            );
        } finally {
            setBusy(false);
        }
    }


    async function loadTempStatus() {

        try {

            const st = await getTemporaryLanIpStatus();

            setTempStatus(st && st.active ? st : null);

        } catch {

            setTempStatus(null);

        }

    }


    async function handleTestSegment() {

        const cidr = String(network || "").trim();
        const gw = cidrGateway(cidr);
        const pfx = cidrPrefix(cidr);
        if (gw === null || pfx === null) {
            setError("CIDR inválido: usá red/prefijo (ej. 192.168.10.0/24)");
            return;
        }
        if (!window.confirm(
            `¿Probar la IP temporal ${gw}/${pfx}?\n\n`
            + "Tu conexión actual a la UI se cortará. Entrá a "
            + `https://${gw}:8443 para validar. Si no confirmás, se revierte `
            + "solo en pocos minutos."
        )) {
            return;
        }
        setTempBusy(true);
        setError("");
        setMessage("");
        try {
            const res = await startTemporaryLanIp({
                temporary_ip: gw,
                temporary_prefix: pfx,
                duration_minutes: 10,
            });
            if (res?.success === false) {
                setError(res.message || "No se pudo probar la IP temporal.");
            }
            await loadTempStatus();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.message
                || "No se pudo probar la IP temporal."
            );
        } finally {
            setTempBusy(false);
        }
    }


    async function handleConfirmPermanent() {

        const cidr = String(network || "").trim();
        const gw = cidrGateway(cidr);
        if (!window.confirm(
            `¿Confirmar el cambio permanente a ${cidr}?\n\n`
            + `El NSP quedará en ${gw} (.1). Conectate ahora a `
            + `https://${gw}:8443.`
        )) {
            return;
        }
        setTempBusy(true);
        setError("");
        setMessage("");
        try {
            const res = await setLanSegment({ network: cidr });
            if (res?.success === false) {
                setError(res.message || "No se pudo confirmar el segmento.");
            } else {
                await revertTemporaryLanIp().catch(() => {});
                await load();
            }
            await loadTempStatus();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.message
                || "No se pudo confirmar el segmento."
            );
        } finally {
            setTempBusy(false);
        }
    }


    async function handleRevertTemporary() {

        setTempBusy(true);
        setError("");
        setMessage("");
        try {
            await revertTemporaryLanIp();
            await loadTempStatus();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.message
                || "No se pudo revertir la IP temporal."
            );
        } finally {
            setTempBusy(false);
        }
    }


    async function handleApplySegment() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setLanSegment({
                network,
                pool_start: poolStart,
                pool_end: poolEnd,
                excluded_ips: parseExclusions(),
                group_ip_start: groupIpStart || undefined,
                group_ip_end: groupIpEnd || undefined,
            });

            if (result?.success === false) {
                setError(result.message || "No se pudo aplicar el segmento.");
            } else {
                setMessage(result?.message || "Segmento aplicado.");
            }

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudo aplicar el segmento."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveExclusions() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setDhcpExclusions(parseExclusions(), poolStart, poolEnd);

            setMessage(
                result?.success
                    ? "Exclusiones guardadas y DHCP reaplicado."
                    : "Exclusiones guardadas."
            );

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudieron guardar las exclusiones."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel">

            <h3>Segmento LAN y DHCP</h3>

            <p className="registry-hint">
                El segmento se divide en tres zonas: gateway (.1),
                <strong> IPs de grupos</strong> (DNS/filtrado, una por grupo)
                y <strong>pool DHCP de equipos</strong>. Si no reservás IPs
                para grupos, el NSP no podrá crear más grupos cuando se
                agoten. Por defecto se reservan 10 IPs (.10–.19).
            </p>

            {
                config && (
                    <div className="lan-stat-row">
                        <span className="lan-stat">
                            <span>Segmento</span>
                            <strong>{config.network}/{config.netmask}</strong>
                        </span>
                        <span className="lan-stat">
                            <span>Gateway</span>
                            <strong>{config.gateway}</strong>
                        </span>
                        <span className="lan-stat">
                            <span>IPs grupos</span>
                            <strong>
                                {config.group_ip_start && config.group_ip_end
                                    ? `${config.group_ip_start}–${config.group_ip_end}`
                                    : "—"}
                                {config.group_ip_count
                                    ? ` (${config.group_ip_count})`
                                    : ""}
                            </strong>
                        </span>
                        <span className="lan-stat">
                            <span>Pool equipos</span>
                            <strong>{config.pool_start}–{config.pool_end}</strong>
                        </span>
                        {
                            config.excluded_ips?.length > 0 && (
                                <span className="lan-stat">
                                    <span>Excluidas</span>
                                    <strong>{config.excluded_ips.join(", ")}</strong>
                                </span>
                            )
                        }
                    </div>
                )
            }

            {
                loading ? (
                    <p className="registry-hint">Cargando configuración...</p>
                ) : config ? (
                    <WriteGuard>

                <div className="registry-form-panel">

                    <div className="registry-form-grid">

                        <label className="registry-form-full">
                            Red (CIDR)
                            <input
                                type="text"
                                placeholder="ej. 192.168.10.0/24"
                                value={network}
                                onChange={(e) => setNetwork(e.target.value)}
                            />
                            {
                                cidrOk ? (
                                    <span className="registry-hint">
                                        ▶ IP del NSP en este segmento:{" "}
                                        <strong>{gatewayPreview}</strong>{" "}
                                        (siempre la .1 del segmento)
                                    </span>
                                ) : (
                                    <span className="registry-hint" style={{ color: "var(--danger)" }}>
                                        CIDR inválido: usá red/prefijo (ej. 192.168.10.0/24)
                                    </span>
                                )
                            }
                        </label>

                    </div>

                    <div className="confirm-actions registry-form-actions" style={{ marginTop: 8 }}>

                        <button
                            type="button"
                            className="primary-button"
                            disabled={busy || !cidrOk}
                            onClick={handleChangeSegment}
                        >
                            Cambiar segmento (NSP → .1)
                        </button>

                        {
                            tempStatus ? (
                                <button
                                    type="button"
                                    className="secondary-button"
                                    disabled={tempBusy}
                                    onClick={handleRevertTemporary}
                                >
                                    Descartar (revertir temporal)
                                </button>
                            ) : (
                                <button
                                    type="button"
                                    className="secondary-button"
                                    disabled={busy || tempBusy || !cidrOk}
                                    onClick={handleTestSegment}
                                >
                                    Probar antes (IP temporal)
                                </button>
                            )
                        }

                    </div>

                    {
                        tempStatus && (
                            <div className="registry-form-panel" style={{ marginTop: 10 }}>
                                <p className="registry-hint">
                                    ⚠ IP temporal activa:{" "}
                                    <strong>{tempStatus.temporary_ip || "—"}</strong>
                                    {
                                        tempStatus.expires_at
                                            ? ` · revierte a las ${new Date(tempStatus.expires_at).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}.`
                                            : ""
                                    }
                                </p>
                                <div className="confirm-actions">
                                    <button
                                        type="button"
                                        className="primary-button"
                                        disabled={tempBusy}
                                        onClick={handleConfirmPermanent}
                                    >
                                        Confirmar y hacer permanente
                                    </button>
                                </div>
                            </div>
                        )
                    }

                    <p className="registry-section-label">
                        Reservado para grupos (DNS) — {groupIpCount() || "?"} grupos máx.
                    </p>

                    <div className="registry-form-grid">

                        <label>
                            Grupos desde
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.10"
                                value={groupIpStart}
                                onChange={(e) => setGroupIpStart(e.target.value)}
                            />
                        </label>

                        <label>
                            Grupos hasta
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.19"
                                value={groupIpEnd}
                                onChange={(e) => setGroupIpEnd(e.target.value)}
                            />
                        </label>

                    </div>

                    <p className="registry-section-label">
                        Pool DHCP de equipos (PCs, impresoras, etc.)
                    </p>

                    <div className="registry-form-grid">

                        <label>
                            Pool DHCP desde
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.20"
                                value={poolStart}
                                onChange={(e) => setPoolStart(e.target.value)}
                            />
                        </label>

                        <label>
                            Pool DHCP hasta
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.150"
                                value={poolEnd}
                                onChange={(e) => setPoolEnd(e.target.value)}
                            />
                        </label>

                    </div>

                    <label className="registry-form-full">
                        IPs excluidas extra (IP o rango, separadas por coma)
                        <input
                            type="text"
                            placeholder="ej. 192.168.1.200-192.168.1.210"
                            value={exclusions}
                            onChange={(e) => setExclusions(e.target.value)}
                        />
                    </label>

                    <div className="confirm-actions registry-form-actions">

                        <button
                            className={`primary-button${busy ? " btn-busy" : ""}`}
                            onClick={handleApplySegment}
                            disabled={busy}
                        >
                            Aplicar grupos y pool
                        </button>

                        <button
                            className={`secondary-button${busy ? " btn-busy" : ""}`}
                            onClick={handleSaveExclusions}
                            disabled={busy}
                        >
                            Guardar exclusiones
                        </button>

                    </div>

                </div>

            </WriteGuard>
                ) : (
                    <div className="dhcp-empty">
                        Todavía no hay un segmento de DHCP configurado en esta
                        máquina. Asigná la tarjeta LAN y su zona (en{" "}
                        <a href="/network/zones">Zonas</a> / Interfaces) para
                        que el DHCP tenga segmento, pool y reservas.
                    </div>
                )
            }

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}

export default LanSegmentPanel;
