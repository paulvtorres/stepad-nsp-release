import { useState } from "react";

import { Link } from "react-router-dom";

import { useNetworkSegment } from "../../../network/useNetworkSegment";

import DhcpStatusPanel from "./DhcpStatusPanel";
import DhcpPoolStatsPanel from "./DhcpPoolStatsPanel";
import LanSegmentPanel from "./LanSegmentPanel";
import DhcpAlertPanel from "./DhcpAlertPanel";
import DhcpCleanupPanel from "./DhcpCleanupPanel";
import DhcpLogPanel from "./DhcpLogPanel";

import "../Interfaces/interfaces.css";
import "./dhcp.css";


const TABS = [
    { id: "resumen", label: "Resumen y control" },
    { id: "segment", label: "Segmento LAN" },
    { id: "alertas", label: "Alertas y limpieza" },
    { id: "registro", label: "Registro DHCP" }
];


function Dhcp() {

    const [tab, setTab] = useState("resumen");

    const {
        lanCards,
        selectedLan,
        selectedZones,
    } = useNetworkSegment();

    const lanLabel = selectedLan
        ? (selectedLan.display_name
            || selectedLan.current_name
            || selectedLan.last_seen_name
            || "LAN")
        : null;

    return (

        <div className="interfaces-page dhcp-page">

            <header className="interfaces-header">
                <h2>DHCP</h2>
                <p>
                    Control del servidor DHCP, uso de IPs del segmento y
                    actividad. Toda la información en una vista, sin
                    duplicados.
                </p>

                {
                    lanCards.length > 1 && lanLabel && (
                        <div className="dhcp-context">
                            Contexto: <strong>{lanLabel}</strong>
                            {
                                selectedZones.length > 0
                                    ? (
                                        selectedZones.map((zone) => (
                                            <span key={zone.id}>
                                                {" · "}{zone.name}{" "}
                                                ({zone.network_cidr})
                                            </span>
                                        ))
                                    )
                                    : null
                            }
                        </div>
                    )
                }

                {
                    lanCards.length > 1 && selectedZones.length === 0 && (
                        <div className="dhcp-segment-banner warn">
                            Esta tarjeta LAN aún no tiene zona. Creá una en{" "}
                            <Link
                                to={
                                    `/network/zones?mac=${encodeURIComponent(selectedLan?.mac_address || "")}`
                                    + `&iface=${encodeURIComponent(selectedLan?.current_name || selectedLan?.last_seen_name || "")}`
                                }
                            >
                                Zonas
                            </Link>
                            {" "}con el CIDR y el pool DHCP de ese segmento.
                        </div>
                    )
                }
            </header>

            <div className="dhcp-tabs" role="tablist">

                {
                    TABS.map(item => (
                        <button
                            key={item.id}
                            type="button"
                            role="tab"
                            aria-selected={tab === item.id}
                            className={`dhcp-tab ${tab === item.id ? "active" : ""}`}
                            onClick={() => setTab(item.id)}
                        >
                            {item.label}
                        </button>
                    ))
                }

            </div>

            <div className="dhcp-tab-body">

                {
                    tab === "resumen" && (
                        <div className="dhcp-col-grid">
                            <div className="dhcp-col">
                                <DhcpStatusPanel />
                            </div>
                            <div className="dhcp-col">
                                <DhcpPoolStatsPanel />
                            </div>
                        </div>
                    )
                }

                {
                    tab === "segment" && <LanSegmentPanel />
                }

                {
                    tab === "alertas" && (
                        <div className="dhcp-col-grid">
                            <div className="dhcp-col">
                                <DhcpAlertPanel />
                            </div>
                            <div className="dhcp-col">
                                <DhcpCleanupPanel />
                            </div>
                        </div>
                    )
                }

                {
                    tab === "registro" && <DhcpLogPanel />
                }

            </div>

        </div>

    );
}

export default Dhcp;