import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import { getSystemStatus, getNavigationStatus, getZoneIsolationStatus, getMalwareEvents, getSniConnections } from "../../services/systemService";

import {
    getComponentDiagnosis,
    hasDiagnosis
} from "../../services/diagnosisService";

import {
    getEncryptedDnsStatus,
    getSecurityRules,
    getAlerts,
    markAlertRead,
    markAllAlertsRead,
    quarantineAlert,
    getSystemMonitoring,
    getContentCategories
} from "../../services/api";

import Dialog from "./components/Dialog";

import "./dashboard.css";


const COMPONENT_LABELS = {

    core: "Núcleo",

    interface_registry: "Interfaces",

    network: "Red",

    api: "API",

    dns: "Servidor DNS",

    firewall: "Firewall",

    dhcp: "Servidor DHCP",

    zones: "Zonas",

    rules: "Reglas",

    schedule_enforcement: "Programación",

    nat: "NAT",

    system: "Sistema"

};


export default function Dashboard() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";


    const [system, setSystem] = useState(null);

    const [encryptedDns, setEncryptedDns] = useState(null);

    const [navStatus, setNavStatus] = useState(null);

    const [domainRules, setDomainRules] = useState([]);

    const [malwareInfo, setMalwareInfo] = useState(null);

    const [isolation, setIsolation] = useState(null);

    const [malwareEvents, setMalwareEvents] = useState([]);

    const [liveBrowsing, setLiveBrowsing] = useState(null);

    const [selected, setSelected] = useState(null);

    const [loadingDiagnosis, setLoadingDiagnosis] = useState(false);

    const [open, setOpen] = useState(false);

    const [alerts, setAlerts] = useState([]);

    const [unread, setUnread] = useState(0);

    const [monitoring, setMonitoring] = useState(null);


    useEffect(() => {

        getSystemStatus()

            .then(setSystem)

            .catch(error => console.error(error));


        getEncryptedDnsStatus()

            .then(setEncryptedDns)

            .catch(error => console.error(error));


        getNavigationStatus()

            .then(setNavStatus)

            .catch(() => setNavStatus(null));


        getSecurityRules()

            .then(data => setDomainRules(data || []))

            .catch(error => console.error(error));


        getContentCategories()

            .then((cats) => {

                const mal = (cats || []).find((c) => c.key === "malware");

                setMalwareInfo(mal || null);

            })

            .catch(() => setMalwareInfo(null));

        getZoneIsolationStatus()

            .then(setIsolation)

            .catch(() => setIsolation(null));

    }, []);


    useEffect(() => {

        function load() {

            getAlerts(30, false)

                .then(data => {
                    setAlerts(data.alerts || []);
                    setUnread(data.unread || 0);
                })

                .catch(error => console.error(error));

            getSystemMonitoring()

                .then(setMonitoring)

                .catch(error => console.error(error));

            getMalwareEvents(5)

                .then(data => setMalwareEvents(data?.events || []))

                .catch(error => console.error(error));

            getSniConnections(2)

                .then((data) => {
                    const connections = data?.connections || [];
                    const byDevice = {};
                    connections.forEach((conn) => {
                        if (!byDevice[conn.ip]) {
                            byDevice[conn.ip] = {
                                device_name: conn.device_name,
                                ip: conn.ip,
                                domains: []
                            };
                        }
                        byDevice[conn.ip].domains.push(conn.domain);
                    });
                    setLiveBrowsing({
                        active_count: Object.keys(byDevice).length,
                        active: Object.values(byDevice)
                    });
                })

                .catch(() => setLiveBrowsing(null));

        }

        load();

        const interval = setInterval(load, 15000);

        return () => clearInterval(interval);

    }, []);


    async function handleMarkRead(id) {

        await markAlertRead(id);

        const data = await getAlerts(30, false);

        setAlerts(data.alerts || []);

        setUnread(data.unread || 0);

    }


    async function handleMarkAllRead() {

        await markAllAlertsRead();

        setAlerts((previous) =>
            previous.map((a) => ({ ...a, read: true }))
        );

        setUnread(0);

    }


    async function handleQuarantine(alert) {

        const ok = window.confirm(
            "¿Aislar el equipo que originó esta alerta?\n\n" +
            alert.title + "\n\n" +
            "Se bloqueará su acceso a la red hasta que lo desbloquees."
        );

        if (!ok) return;

        try {

            await quarantineAlert(alert.id);

            window.alert("Equipo aislado.");

        } catch (error) {

            window.alert(
                "No se pudo aislar: " + (error.message || "error")
            );

        }

    }


    function formatUptime(seconds) {

        const days = Math.floor(seconds / 86400);

        const hours = Math.floor((seconds % 86400) / 3600);

        const minutes = Math.floor((seconds % 3600) / 60);

        if (days > 0) return `${days}d ${hours}h`;

        if (hours > 0) return `${hours}h ${minutes}m`;

        return `${minutes}m`;

    }



    async function showDetails(component) {

        setLoadingDiagnosis(true);

        setSelected({ ...component, diagnosis: null });

        setOpen(true);

        try {

            const diagnosis = await getComponentDiagnosis(component.name);

            setSelected({ ...component, diagnosis });

        } catch (error) {

            setSelected({ ...component, diagnosis: { error: error.message } });

        } finally {

            setLoadingDiagnosis(false);

        }

    }



    function formatDate(value) {

        if (!value) return "nunca";

        return new Date(value).toLocaleString();

    }



    if (!system) {

        return <p>Cargando...</p>;

    }



    const dnsRunning = system.components?.dns?.status === "running";

    const activeDomains = domainRules.filter(r => r.enabled).length;

    const dotEnabled = Boolean(encryptedDns?.enabled);

    const serviceEnabled = Boolean(encryptedDns?.service_block_enabled);

    const wan = encryptedDns?.wan_interface || "no detectada";



    const layers = [

        {

            icon: "🌐",

            title: "Bloqueo de dominios",

            ok: dnsRunning && activeDomains > 0,

            detail: dnsRunning

                ? `${activeDomains} dominios bloqueados en el resolver`

                : "Resolver DNS inactivo"

        },

        {

            icon: "🔒",

            title: "Bloqueo DoT/DoH",

            ok: dotEnabled,

            detail: dotEnabled

                ? `${encryptedDns.blocklist_ips} resolutores bloqueados · WAN ${wan} · ${formatDate(encryptedDns.last_refreshed)}`

                : "Inactivo — los dispositivos pueden evadir el bloqueo con DNS cifrado"

        },

        {

            icon: "🚫",

            title: "Bloqueo por IP de servicios",

            ok: serviceEnabled,

            detail: serviceEnabled

                ? `${encryptedDns.service_ipv4_ranges} rangos IPv4 · ${encryptedDns.service_ipv6_ranges} rangos IPv6 (Meta/Facebook)`

                : "Inactivo — apps con DNS en caché pueden alcanzar los servicios por IP"

        },

        {

            icon: "🦠",

            title: "Protección Malware",

            ok: Boolean(malwareInfo?.enabled && malwareInfo?.domains > 0),

            detail: malwareInfo?.enabled && malwareInfo?.domains > 0

                ? `${malwareInfo.domains} dominios maliciosos bloqueados (feed diario URLhaus + OpenPhish)`

                : "Feed de malware inactivo"

        },

        {

            icon: "🧱",

            title: "Aislamiento entre zonas",

            ok: Boolean(isolation?.enabled),

            detail: isolation?.enabled

                ? `${isolation.drop_rules} reglas de bloqueo activas — los dispositivos de distintas zonas no pueden comunicarse (frena la propagación)`

                : "Inactivo — un equipo comprometido podría moverse lateralmente. Configura zonas para aislarlo"

        }

    ];



    const missingLayers = layers.filter(layer => !layer.ok);

    const allProtected = missingLayers.length === 0;



    const components = Object.entries(system.components).map(

        ([name, state]) => ({

            name,

            status: state?.status,

            error: state?.error

        })

    );



    return (

        <div className="dashboard-container">


            <div>

                <h2>Panel de control</h2>

                {
                    navStatus && (
                        <div
                            className={`layer-banner ${navStatus.ok ? "ok" : "warn"}`}
                            style={{ marginBottom: 14 }}
                        >
                            <span style={{ fontSize: 22 }}>
                                {navStatus.ok ? "✔️" : "⚠️"}
                            </span>

                            <div className="layer-banner-message">
                                <strong>
                                    {navStatus.ok
                                        ? "Navegación OK"
                                        : "Navegación con problemas"}
                                </strong>

                                <div className="layer-banner-sub">
                                    {
                                        navStatus.ok
                                            ? "Internet, DHCP, DNS y reenvío operando normalmente."
                                            : Object.entries(navStatus.checks || {})
                                                .filter(([, c]) => !c.ok)
                                                .map(([name, c]) => (
                                                    <span key={name}> {c.detail} ·</span>
                                                ))
                                    }
                                </div>
                            </div>
                        </div>
                    )
                }


                <div className={`layer-banner ${allProtected ? "ok" : "warn"}`}>

                    <span style={{ fontSize: 22 }}>

                        {allProtected ? "🛡️" : "⚠️"}

                    </span>


                    <div className="layer-banner-message">

                        {
                            allProtected
                                ? "Protección completa — todas las capas de bloqueo están activas."
                                : "Protección incompleta — hay capas de bloqueo apagadas."
                        }


                        <div className="layer-banner-sub">

                            {
                                allProtected
                                    ? "Bloqueo de dominios, DoT/DoH y bloqueo por IP de servicios operando."
                                    : `Revisa: ${missingLayers.map(l => l.title.toLowerCase()).join(", ")}.`
                            }

                        </div>

                    </div>

                </div>

            </div>



            <div className="dashboard-section">

                <h3 className="section-title">Protección activa</h3>

                <p className="section-subtitle">

                    Cada capa por separado — si alguna está apagada, los dispositivos pueden evadir el bloqueo por esa vía.

                </p>


                <div className="layers-grid">

                    {
                        layers.map(layer => (

                            <div
                                key={layer.title}
                                className={`layer-card ${layer.ok ? "ok" : "off"}`}
                            >

                                <div className="layer-card-header">

                                    <span className="layer-card-title">

                                        <span className="layer-icon">{layer.icon}</span>

                                        {layer.title}

                                    </span>


                                    <span className={`layer-badge ${layer.ok ? "ok" : "off"}`}>

                                        {layer.ok ? "ACTIVA" : "INACTIVA"}

                                    </span>

                                </div>


                                <p className="layer-card-detail">

                                    {layer.detail}

                                </p>

                            </div>

                        ))
                    }

                </div>

            </div>



            <div className="dashboard-section">

                <h3 className="section-title">Navegando ahora</h3>

                <p className="section-subtitle">

                    Equipos navegando en este momento (se actualiza solo cada 15s).

                </p>

                {
                    !liveBrowsing || liveBrowsing.active_count === 0 ? (

                        <div className="layer-banner ok" style={{ marginTop: 12 }}>

                            <span style={{ fontSize: 22 }}>💤</span>

                            <div className="layer-banner-message">

                                <strong>Sin navegación activa</strong>

                                <div className="layer-banner-sub">

                                    Ningún equipo con consultas DNS en los últimos 10 minutos.

                                </div>

                            </div>

                        </div>

                    ) : (

                        <div className="live-browsing-box">

                            <div className="live-browsing-count">

                                <span className="live-dot"></span>

                                <strong>{liveBrowsing.active_count}</strong>

                                <span>
                                    {liveBrowsing.active_count === 1
                                        ? "equipo navegando ahora"
                                        : "equipos navegando ahora"}
                                </span>

                            </div>

                        </div>

                    )
                }

            </div>



            <div className="dashboard-section">

                <h3 className="section-title">Eventos de malware</h3>

                <p className="section-subtitle">

                    Detecciones del IPS clasificadas como malware/C2 y la respuesta automática aplicada.

                </p>

                {
                    malwareEvents.length === 0 ? (

                        <div className="layer-banner ok" style={{ marginTop: 12 }}>

                            <span style={{ fontSize: 22 }}>✔️</span>

                            <div className="layer-banner-message">

                                <strong>Sin detecciones de malware</strong>

                                <div className="layer-banner-sub">

                                    Ninguna firma de malware/C2 en el tráfico reciente.

                                </div>

                            </div>

                        </div>

                    ) : (

                        <div className="malware-events-list">

                            {
                                malwareEvents.map(event => (

                                    <div key={event.id} className="malware-event-item">

                                        <div className="malware-event-main">

                                            <span className="malware-event-signature">

                                                {event.signature}

                                            </span>

                                            <span className="malware-event-device">

                                                {event.device_name || event.src_ip} → {event.dst_ip}{event.dst_port ? `:${event.dst_port}` : ""}

                                            </span>

                                        </div>

                                        <div className="malware-event-meta">

                                            <span className={`malware-sev ${event.severity}`}>

                                                {event.severity}

                                            </span>

                                            {
                                                event.quarantined && (

                                                    <span className="malware-badge quarantined">CUARENTENA</span>

                                                )
                                            }

                                            {
                                                event.c2_blocked && (

                                                    <span className="malware-badge blocked">C2 BLOQUEADO</span>

                                                )
                                            }

                                            <span className="malware-event-time">

                                                {formatDate(event.created_at)}

                                            </span>

                                        </div>

                                    </div>

                                ))
                            }

                        </div>

                    )
                }

            </div>



            <div className="dashboard-section">

                <h3 className="section-title">Estado del sistema</h3>

                <p className="section-subtitle">

                    Servicios que mantienen la red protegida y operativa.

                </p>


                <div className="grid">

                    {

                        components.map(component => (

                            <div key={component.name} className="card">

                                <h4 className="card-name">

                                    <span className={`status-dot ${component.status}`} />

                                    {COMPONENT_LABELS[component.name] || component.name}

                                </h4>


                                <p className="card-status">

                                    {
                                        component.status === "running"
                                            ? "Operativo"
                                            : component.status === "failed"
                                                ? "Con error"
                                                : component.status === "stopped"
                                                    ? "Detenido"
                                                    : "Iniciando..."
                                    }

                                </p>


                                {
                                    (component.error || hasDiagnosis(component.name)) && (

                                        <button
                                            className="details-button"
                                            onClick={() => showDetails(component)}
                                        >

                                            Ver detalles

                                        </button>

                                    )
                                }

                            </div>

                        ))
                    }

                </div>

            </div>



            <Dialog

                title={selected?.name?.toUpperCase()}

                open={open}

                onClose={() => setOpen(false)}

            >


                <p>

                    <strong>Componente:</strong>{" "}

                    {selected?.name}

                </p>


                <p>

                    <strong>Estado:</strong>{" "}

                    {selected?.status}

                </p>


                {
                    selected?.error && (

                        <div className="diagnosis-error">

                            <strong>Causa del error:</strong>

                            <pre>{selected.error}</pre>

                        </div>

                    )
                }


                <hr />


                {
                    loadingDiagnosis && <p>Cargando diagnóstico...</p>
                }


                {
                    selected?.diagnosis && (

                        <pre>

                            {JSON.stringify(selected.diagnosis, null, 2)}

                        </pre>

                    )
                }


            </Dialog>


            <div className="dashboard-section">

                <h3>Estado del equipo</h3>

                {
                    !monitoring ? (
                        <p className="dashboard-muted">Cargando...</p>
                    ) : (
                        <div className="monitoring-grid">

                            <div className={`monitor-card ${monitoring.cpu_percent > 90 ? "warn" : ""}`}>
                                <span className="monitor-value">{monitoring.cpu_percent}%</span>
                                <span className="monitor-label">CPU</span>
                            </div>

                            <div className={`monitor-card ${monitoring.ram_percent > 90 ? "warn" : ""}`}>
                                <span className="monitor-value">{monitoring.ram_percent}%</span>
                                <span className="monitor-label">Memoria</span>
                            </div>

                            <div className={`monitor-card ${monitoring.disk_percent > 90 ? "warn" : ""}`}>
                                <span className="monitor-value">{monitoring.disk_percent}%</span>
                                <span className="monitor-label">Disco</span>
                            </div>

                            <div className="monitor-card">
                                <span className="monitor-value">{formatUptime(monitoring.uptime_seconds)}</span>
                                <span className="monitor-label">Encendido</span>
                            </div>

                            {
                                monitoring.temperature_c != null && (
                                    <div className={`monitor-card ${monitoring.temperature_c > 75 ? "warn" : ""}`}>
                                        <span className="monitor-value">{monitoring.temperature_c}°C</span>
                                        <span className="monitor-label">Temperatura</span>
                                    </div>
                                )
                            }

                        </div>
                    )
                }

            </div>


            <div className="dashboard-section">

                <div className="alerts-header">

                    <h3>Alertas</h3>

                    {
                        unread > 0 && (
                            <button
                                className="details-button"
                                onClick={handleMarkAllRead}
                            >
                                Marcar todas como leídas
                            </button>
                        )
                    }

                </div>

                {
                    alerts.length === 0 ? (
                        <p className="dashboard-muted">Sin alertas.</p>
                    ) : (
                        <ul className="alerts-list">

                            {
                                alerts.map((alert) => (
                                    <li
                                        key={alert.id}
                                        className={`alert-item ${alert.read ? "read" : ""} severity-${alert.severity}`}
                                    >
                                        <span className="alert-severity">{alert.severity}</span>

                                        <div className="alert-body">
                                            <div className="alert-title">{alert.title}</div>
                                            <div className="alert-meta">
                                                {new Date(alert.created_at).toLocaleString("es-ES")}
                                            </div>
                                            {
                                                alert.message && alert.message !== alert.title && (
                                                    <div className="alert-message">
                                                        {alert.message}
                                                    </div>
                                                )
                                            }
                                        </div>

                                        {
                                            alert.type === "suricata" && isAdmin && (
                                                <button
                                                    className="alert-quarantine-button"
                                                    onClick={() => handleQuarantine(alert)}
                                                    title="Aislar el equipo que originó esta alerta"
                                                >
                                                    Aislar equipo
                                                </button>
                                            )
                                        }

                                        {
                                            !alert.read && (
                                                <button
                                                    className="alert-read-button"
                                                    onClick={() => handleMarkRead(alert.id)}
                                                    title="Marcar como leída"
                                                >
                                                    ✓
                                                </button>
                                            )
                                        }

                                    </li>
                                ))
                            }

                        </ul>
                    )
                }

            </div>


        </div>

    );

}
