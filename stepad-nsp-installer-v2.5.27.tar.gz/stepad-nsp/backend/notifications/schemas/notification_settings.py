from pydantic import BaseModel


class NotificationSettingsRequest(BaseModel):

    enabled: bool | None = None

    to_emails: str | None = None

    bcc_emails: str | None = None

    report_subject: str | None = None

    alert_subject: str | None = None

    frequency: str | None = None

    send_hour: int | None = None

    send_minute: int | None = None
