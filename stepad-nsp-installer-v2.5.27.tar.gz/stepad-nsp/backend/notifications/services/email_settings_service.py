from dataclasses import dataclass

from sqlalchemy.orm import Session

from backend.notifications.constants.email_providers import (
    EMAIL_PROVIDERS,
    detect_provider,
    provider_preset,
)
from backend.notifications.repositories.email_settings_repository import (
    EmailSettingsRepository,
)
from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository,
)
from backend.notifications.services.email_subject_service import (
    build_test_subject,
)
from backend.notifications.services.email_service import EmailService


@dataclass
class EmailDeliveryContext:

    smtp_host: str

    smtp_port: int

    smtp_user: str | None

    smtp_password: str | None

    from_email: str

    to_emails: str

    bcc_emails: str = ""


def build_delivery_context(
    db: Session,
    to_emails: str | None = None,
    bcc_emails: str | None = None,
) -> EmailDeliveryContext | None:

    email = EmailSettingsRepository().get(db)

    if not (email.smtp_host or "").strip():

        return None

    notification = NotificationSettingsRepository().get(db)

    if to_emails is None:

        to_emails = notification.to_emails or ""

    if bcc_emails is None:

        bcc_emails = notification.bcc_emails or ""

    return EmailDeliveryContext(
        smtp_host=email.smtp_host,
        smtp_port=email.smtp_port or 587,
        smtp_user=email.smtp_user,
        smtp_password=email.smtp_password,
        from_email=email.from_email or email.smtp_user or "",
        to_emails=to_emails,
        bcc_emails=bcc_emails,
    )


class EmailSettingsService:

    def __init__(self):

        self.repository = EmailSettingsRepository()

        self.email_service = EmailService()

    def _ready_issues(
        self,
        settings,
    ) -> list[str]:

        issues = []

        if not (settings.smtp_host or "").strip():

            issues.append("Servidor SMTP")

        account = (settings.smtp_user or settings.from_email or "").strip()

        if not account:

            issues.append("Cuenta de correo")

        if not (settings.from_email or "").strip():

            issues.append("Correo remitente")

        if account and not settings.smtp_password:

            issues.append("Contraseña")

        return issues

    def list_providers(self) -> list[dict]:

        return [
            {
                "key": key,
                "label": preset["label"],
                "smtp_host": preset["smtp_host"],
                "smtp_port": preset["smtp_port"],
                "hint": preset.get("hint", ""),
            }
            for key, preset in EMAIL_PROVIDERS.items()
        ]

    def get_settings(
        self,
        db: Session,
    ) -> dict:

        settings = self.repository.get(db)

        provider = settings.provider or detect_provider(settings.smtp_host)

        preset = provider_preset(provider)

        ready_issues = self._ready_issues(settings)

        return {
            "provider": provider,
            "provider_label": preset["label"],
            "provider_hint": preset.get("hint", ""),
            "smtp_host": (
                preset["smtp_host"]
                if provider != "custom"
                else settings.smtp_host
            ),
            "smtp_port": (
                int(preset["smtp_port"])
                if provider != "custom"
                else settings.smtp_port
            ),
            "account_email": settings.smtp_user or settings.from_email or "",
            "from_email": settings.from_email,
            "has_password": bool(settings.smtp_password),
            "config_ready": len(ready_issues) == 0,
            "config_issues": ready_issues,
            "updated_at": (
                settings.updated_at.isoformat()
                if settings.updated_at else None
            ),
        }

    def save_settings(
        self,
        db: Session,
        data,
    ) -> dict:

        settings = self.repository.get(db)

        provider = (data.provider or settings.provider or "custom").strip()

        preset = provider_preset(provider)

        settings.provider = provider

        if provider == "custom":

            if data.smtp_host is not None:
                settings.smtp_host = str(data.smtp_host).strip()

            if data.smtp_port is not None:
                settings.smtp_port = int(data.smtp_port)

        else:

            settings.smtp_host = preset["smtp_host"]

            settings.smtp_port = int(preset["smtp_port"])

        if data.account_email is not None:

            account = str(data.account_email).strip()

            settings.smtp_user = account

            settings.from_email = account

        elif data.from_email is not None:

            settings.from_email = str(data.from_email).strip()

        if data.smtp_password:

            settings.smtp_password = str(data.smtp_password)

        self.repository.save(db, settings)

        return self.get_settings(db)

    def send_test(
        self,
        db: Session,
        to_email: str | None = None,
    ) -> dict:

        settings = self.repository.get(db)

        issues = self._ready_issues(settings)

        if issues:

            return {
                "success": False,
                "message": f"Complete: {', '.join(issues)}.",
            }

        notification = NotificationSettingsRepository().get(db)

        recipient = (to_email or notification.to_emails or "").split(",")[0].strip()

        if not recipient:

            recipient = settings.from_email or settings.smtp_user or ""

        if not recipient:

            return {
                "success": False,
                "message": "Indique un destinatario para la prueba.",
            }

        context = build_delivery_context(db, to_emails=recipient)

        html_body = (
            "<h2>Prueba de correo STEPAD NSP</h2>"
            "<p>Si recibe este mensaje, la cuenta de correo general "
            "está configurada correctamente.</p>"
            f"<p>Proveedor: <strong>{settings.provider}</strong></p>"
            f"<p>Destinatario de prueba: <strong>{recipient}</strong></p>"
        )

        return self.email_service.send_html(
            context,
            build_test_subject(db),
            html_body,
        )
