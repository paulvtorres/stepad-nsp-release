import threading
import time

from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.notifications.models.notification_settings import (
    NotificationSettings
)
from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.email_settings_service import (
    EmailSettingsService,
    build_delivery_context,
)
from backend.notifications.services.report_service import (
    EMAIL_REPORT_BODY,
    ReportService,
)
from backend.notifications.services.email_subject_service import (
    ALERT_VARIABLES,
    DEFAULT_ALERT_SUBJECT,
    DEFAULT_REPORT_SUBJECT,
    REPORT_VARIABLES,
    build_alert_subject,
    build_report_subject,
)

from backend.core.database.session import SessionLocal

from backend.shared.logging.logger import logger


FREQUENCY_LABELS = {
    "daily": "Diaria",
    "weekly": "Semanal",
    "monthly": "Mensual",
}

REPORT_PERIOD_LABELS = {
    "daily": "últimas 24 horas",
    "weekly": "últimos 7 días",
    "monthly": "últimos 30 días",
}


class NotificationService:

    def __init__(self):

        self.repository = NotificationSettingsRepository()

        self.email_service = EmailService()

        self.email_settings_service = EmailSettingsService()

        self.report_service = ReportService()

        self._scheduler_thread = None

        self._stop = False

    def _period(
        self,
        frequency: str
    ) -> tuple[datetime, datetime]:

        end = datetime.utcnow()

        days = {
            "daily": 1,
            "weekly": 7,
            "monthly": 30,
        }.get(frequency, 1)

        start = end - timedelta(days=days)

        return start, end

    def _smtp_ready(
        self,
        db: Session,
        settings: NotificationSettings,
    ) -> tuple[bool, list[str]]:

        email = self.email_settings_service.repository.get(db)

        issues = self.email_settings_service._ready_issues(email)

        if not self.email_service._recipients(settings):

            issues.append("Destinatarios")

        return len(issues) == 0, issues

    def _next_send_hint(
        self,
        db: Session,
        settings: NotificationSettings,
        now: datetime | None = None,
    ) -> str:

        now = now or datetime.now()

        if not settings.enabled:

            return "Las notificaciones están desactivadas."

        ready, issues = self._smtp_ready(db, settings)

        if not ready:

            return f"Complete: {', '.join(issues)}."

        if self.is_due(settings, now):

            return "Envío programado pendiente (próximos minutos)."

        target = now.replace(
            hour=settings.send_hour,
            minute=settings.send_minute,
            second=0,
            microsecond=0,
        )

        freq = settings.frequency or "daily"
        last = settings.last_sent_at

        if last is not None and last.tzinfo is None:

            last = last.replace(tzinfo=None)

        if freq == "daily":

            if now < target:

                return f"Hoy a las {settings.send_hour:02d}:{settings.send_minute:02d}"

            return (
                f"Mañana a las {settings.send_hour:02d}:"
                f"{settings.send_minute:02d}"
            )

        if freq == "weekly":

            if last is None:

                if now < target:

                    return (
                        f"Hoy a las {settings.send_hour:02d}:"
                        f"{settings.send_minute:02d} (primer envío)"
                    )

                return "Próximo envío en 7 días desde el primero."

            days_left = max(
                0,
                7 - (now.date() - last.date()).days,
            )

            if days_left == 0 and now >= target:

                return "Hoy (ciclo semanal)"

            return f"En {days_left or 7} día(s), a las {settings.send_hour:02d}:{settings.send_minute:02d}"

        if freq == "monthly":

            if last is None:

                if now < target:

                    return (
                        f"Hoy a las {settings.send_hour:02d}:"
                        f"{settings.send_minute:02d} (primer envío)"
                    )

                return "Próximo mes (primer envío)."

            if last.month == now.month and last.year == now.year:

                return (
                    f"Próximo mes, a las {settings.send_hour:02d}:"
                    f"{settings.send_minute:02d}"
                )

            if now < target:

                return f"Hoy a las {settings.send_hour:02d}:{settings.send_minute:02d}"

            return (
                f"Próximo mes, a las {settings.send_hour:02d}:"
                f"{settings.send_minute:02d}"
            )

        return f"A las {settings.send_hour:02d}:{settings.send_minute:02d}"

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        email_status = self.email_settings_service.get_settings(db)

        ready, issues = self._smtp_ready(db, settings)

        frequency = settings.frequency or "daily"

        return {
            "id": settings.id,
            "enabled": settings.enabled,
            "to_emails": settings.to_emails,
            "bcc_emails": settings.bcc_emails,
            "report_subject": settings.report_subject or "",
            "report_subject_default": DEFAULT_REPORT_SUBJECT,
            "report_subject_variables": list(REPORT_VARIABLES),
            "alert_subject": settings.alert_subject or "",
            "alert_subject_default": DEFAULT_ALERT_SUBJECT,
            "alert_subject_variables": list(ALERT_VARIABLES),
            "frequency": frequency,
            "frequency_label": FREQUENCY_LABELS.get(frequency, frequency),
            "report_period": REPORT_PERIOD_LABELS.get(frequency, ""),
            "send_hour": settings.send_hour,
            "send_minute": settings.send_minute,
            "schedule_label": (
                f"{FREQUENCY_LABELS.get(frequency, frequency)} a las "
                f"{settings.send_hour:02d}:{settings.send_minute:02d}"
            ),
            "last_sent_at": (
                settings.last_sent_at.isoformat()
                if settings.last_sent_at else None
            ),
            "config_ready": ready,
            "config_issues": issues,
            "email_config_ready": email_status["config_ready"],
            "email_provider": email_status["provider"],
            "email_provider_label": email_status["provider_label"],
            "email_account": email_status["account_email"],
            "next_send_hint": self._next_send_hint(db, settings),
            "scheduler_running": (
                self._scheduler_thread is not None
                and self._scheduler_thread.is_alive()
            ),
        }

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.repository.get(db)

        if data.enabled is not None:
            settings.enabled = data.enabled

        if data.to_emails is not None:
            settings.to_emails = data.to_emails

        if data.bcc_emails is not None:
            settings.bcc_emails = data.bcc_emails

        if data.report_subject is not None:
            settings.report_subject = (data.report_subject or "").strip()

        if data.alert_subject is not None:
            settings.alert_subject = (data.alert_subject or "").strip()

        if data.frequency is not None:
            settings.frequency = data.frequency

        if data.send_hour is not None:
            settings.send_hour = data.send_hour

        if data.send_minute is not None:
            settings.send_minute = data.send_minute

        self.repository.save(db, settings)

        return self.get_settings(db)

    def send_report(
        self,
        db: Session,
        settings: NotificationSettings = None
    ) -> dict:

        settings = settings or self.repository.get(db)

        delivery = build_delivery_context(
            db,
            to_emails=settings.to_emails,
            bcc_emails=settings.bcc_emails,
        )

        if delivery is None:

            return {
                "success": False,
                "message": "Configure la cuenta de correo en Ajustes → Correo.",
            }

        start, end = self._period(settings.frequency)

        html_body = EMAIL_REPORT_BODY

        excel_buffer = self.report_service.build_excel(
            db,
            start,
            end,
        )

        attachment_name = (
            f"historial-dns_{start.strftime('%Y%m%d')}-"
            f"{end.strftime('%Y%m%d')}.xlsx"
        )

        period_label = REPORT_PERIOD_LABELS.get(
            settings.frequency or "daily",
            "período seleccionado",
        )

        subject = build_report_subject(
            db,
            settings.report_subject,
            frequency=settings.frequency or "daily",
            start=start,
            end=end,
        )

        result = self.email_service.send_html_with_attachment(
            delivery,
            subject,
            html_body,
            excel_buffer.getvalue(),
            attachment_name,
        )

        if result["success"]:

            settings.last_sent_at = datetime.now()

            self.repository.save(db, settings)

            result["message"] = (
                f"Reporte enviado ({period_label}) con Excel adjunto."
            )

        return result

    def send_test(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        delivery = build_delivery_context(
            db,
            to_emails=settings.to_emails,
            bcc_emails=settings.bcc_emails,
        )

        if delivery is None:

            return {
                "success": False,
                "message": "Configure la cuenta de correo en Ajustes → Correo.",
            }

        html_body = (
            "<h2>Prueba de notificación</h2>"
            "<p>Este es un correo de prueba de STEPAD NSP. "
            "Si lo estás viendo, la configuración de correo es correcta.</p>"
        )

        subject = build_report_subject(
            db,
            settings.report_subject,
            frequency=settings.frequency or "daily",
            start=datetime.now() - timedelta(days=1),
            end=datetime.now(),
        )

        return self.email_service.send_html(
            delivery,
            subject,
            html_body
        )

    def is_due(
        self,
        settings: NotificationSettings,
        now: datetime
    ) -> bool:

        if not settings.enabled:

            return False

        if (
            now.hour < settings.send_hour
            or (
                now.hour == settings.send_hour
                and now.minute < settings.send_minute
            )
        ):

            return False

        last = settings.last_sent_at

        if last is None:

            return True

        if settings.frequency == "daily":

            return last.date() < now.date()

        if settings.frequency == "weekly":

            return (now.date() - last.date()).days >= 7

        if settings.frequency == "monthly":

            return (
                last.year != now.year
                or last.month != now.month
            )

        return False

    def _scheduler_loop(
        self
    ):

        logger.info("Notification scheduler started.")

        while not self._stop:

            try:

                db = SessionLocal()

                try:

                    settings = self.repository.get(db)

                    if self.is_due(settings, datetime.now()):

                        result = self.send_report(db, settings)

                        logger.info(
                            f"Notification report: {result}"
                        )

                    try:

                        from backend.siem.services.compliance_service import (
                            ComplianceService
                        )

                        ComplianceService().check_logs_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Logs review check failed: {error}"
                        )

                    try:

                        from backend.firewall.services.firewall_hardening_service import (
                            FirewallHardeningService
                        )

                        FirewallHardeningService().check_access_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Access review check failed: {error}"
                        )

                finally:

                    db.close()

            except Exception as error:

                logger.exception(
                    f"Notification scheduler error: {error}"
                )

            time.sleep(30)

    def start_scheduler(
        self
    ):

        if self._scheduler_thread is not None:

            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="notification-scheduler"
        )

        self._scheduler_thread.start()
