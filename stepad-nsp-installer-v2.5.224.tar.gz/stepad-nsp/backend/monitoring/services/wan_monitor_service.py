import re
import subprocess
import threading
import time
import urllib.request

from datetime import datetime, timedelta

from pathlib import Path

from sqlalchemy import func
from sqlalchemy import delete as sa_delete
from sqlalchemy.orm import Session

from backend.monitoring.models.wan_monitor import (
    WanMonitorSettings,
    WanMonitorSample,
)
from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc

PING_BIN = "/bin/ping"
ETHTOOL_BIN = "/usr/sbin/ethtool"
NET_DEV = Path("/proc/net/dev")


class WanMonitorService:

    def __init__(self):

        self._scheduler_thread = None
        self._stop = False
        self._prev_counters: dict[str, tuple[int, int]] = {}
        self._fail_counts: dict[str, int] = {}
        self._alerted_down: set[str] = set()


    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self._get_or_create(db)

        return {
            "enabled": settings.enabled,
            "interval_seconds": settings.interval_seconds,
            "ping_targets": settings.ping_targets,
            "http_enabled": settings.http_enabled,
            "http_url": settings.http_url,
            "alert_threshold": settings.alert_threshold,
            "retention_days": settings.retention_days,
        }


    def save_settings(
        self,
        db: Session,
        request
    ) -> dict:

        settings = self._get_or_create(db)

        if request.enabled is not None:
            settings.enabled = request.enabled
        if request.interval_seconds is not None:
            settings.interval_seconds = max(
                15, min(3600, request.interval_seconds)
            )
        if request.ping_targets is not None:
            settings.ping_targets = request.ping_targets.strip()
        if request.http_enabled is not None:
            settings.http_enabled = request.http_enabled
        if request.http_url is not None:
            settings.http_url = request.http_url.strip()
        if request.alert_threshold is not None:
            settings.alert_threshold = max(
                1, min(60, request.alert_threshold)
            )
        if request.retention_days is not None:
            settings.retention_days = max(
                1, min(365, request.retention_days)
            )

        db.add(settings)
        db.commit()
        db.refresh(settings)

        return self.get_settings(db)


    # ------------------------------------------------------------------
    # Probes
    # ------------------------------------------------------------------

    def _get_wan_interfaces(self, db: Session) -> list[str]:

        try:

            from backend.network.interfaces.registry.models.managed_interface import (
                ManagedInterface,
            )

            rows = (
                db.query(ManagedInterface)
                .filter(
                    func.lower(ManagedInterface.role) == "wan"
                )
                .all()
            )

            names = []
            for row in rows:
                name = (row.last_seen_name or "").strip()
                if name:
                    names.append(name)

            return names

        except Exception as error:

            logger.warning(f"No se pudo leer interfaces WAN: {error}")
            return []


    def _probe_ping(self, target: str) -> dict:

        result = subprocess.run(
            [
                PING_BIN, "-c", "2", "-W", "1", target,
            ],
            capture_output=True,
            text=True,
            timeout=6
        )

        out = result.stdout

        loss = 100.0
        latency = None

        m = re.search(r"(\d+(?:\.\d+)?)% packet loss", out)
        if m:
            loss = float(m.group(1))

        m = re.search(
            r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)/",
            out,
        )
        if m:
            latency = float(m.group(1))

        ok = (loss < 100.0) and result.returncode == 0

        return {
            "ok": ok,
            "latency_ms": latency,
            "packet_loss": loss,
        }


    def _probe_http(self, url: str) -> bool:

        try:

            request = urllib.request.Request(
                url,
                headers={"User-Agent": "STEPAD-NSP/1.0"},
                method="GET",
            )

            with urllib.request.urlopen(request, timeout=6) as response:

                return response.status < 400

        except Exception:

            return False


    def _link_status(self, ifname: str) -> dict:

        speed = None
        up = False

        try:

            result = subprocess.run(
                [ETHTOOL_BIN, ifname],
                capture_output=True,
                text=True,
                timeout=6,
            )

            out = result.stdout

            m = re.search(r"Link detected:\s*(yes|no)", out)
            if m:
                up = m.group(1) == "yes"

            m = re.search(r"Speed:\s*(\d+)Mb/s", out)
            if m:
                speed = int(m.group(1))

        except Exception:

            pass

        if not up:

            # fallback: a real NIC reports "UP" from the kernel even
            # when ethtool is unavailable or misreports the carrier.
            try:

                result = subprocess.run(
                    ["ip", "-br", "link", "show", ifname],
                    capture_output=True,
                    text=True,
                    timeout=6,
                )

                out = result.stdout

                m = re.search(r"\s+(UP|DOWN)\s+", out)
                if m:
                    up = m.group(1) == "UP"

            except Exception:
                pass

        return {"up": up, "speed_mbps": speed}


    def _gateway_for_iface(self, ifname: str) -> str | None:

        try:

            result = subprocess.run(
                [
                    "ip", "-4", "route", "show", "default",
                    "dev", ifname,
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )

            match = re.search(
                r"default via (\S+)",
                result.stdout,
            )

            if match:

                return match.group(1)

        except Exception:

            pass

        return None


    def _probe_dns(self, hostname: str = "www.google.com") -> bool:

        import socket

        try:

            socket.getaddrinfo(
                hostname,
                443,
                type=socket.SOCK_STREAM,
            )

            return True

        except OSError:

            return False


    def _compute_quality(self, data: dict) -> dict:

        link_up = data.get("link_up")

        ping_ok = data.get("ping_ok")

        http_ok = data.get("http_ok")

        latency = data.get("latency_ms")

        loss = data.get("packet_loss") or 0.0

        gateway_ok = data.get("gateway_ok")

        dns_ok = data.get("dns_ok")

        online = bool(
            link_up
            and ping_ok
            and http_ok is not False
            and gateway_ok is not False
            and dns_ok is not False
        )

        if not online:

            return {
                "label": "sin_conexion",
                "label_es": "Sin conexión",
                "score": 0,
                "online": False,
            }

        if loss >= 5 or (latency is not None and latency >= 150):

            return {
                "label": "poor",
                "label_es": "Mala",
                "score": 1,
                "online": True,
            }

        if loss >= 2 or (latency is not None and latency >= 100):

            return {
                "label": "fair",
                "label_es": "Regular",
                "score": 2,
                "online": True,
            }

        if loss >= 0.5 or (latency is not None and latency >= 60):

            return {
                "label": "good",
                "label_es": "Buena",
                "score": 3,
                "online": True,
            }

        if latency is not None and latency >= 35:

            return {
                "label": "very_good",
                "label_es": "Muy buena",
                "score": 4,
                "online": True,
            }

        return {
            "label": "excellent",
            "label_es": "Excelente",
            "score": 5,
            "online": True,
        }


    def _history_summary(
        self,
        rows: list[WanMonitorSample],
    ) -> dict:

        if not rows:

            return {
                "samples": 0,
                "uptime_pct": None,
                "avg_latency_ms": None,
                "max_latency_ms": None,
                "avg_packet_loss": None,
            }

        up_count = sum(
            1 for row in rows
            if row.link_up and row.ping_ok
        )

        latencies = [
            row.latency_ms for row in rows
            if row.latency_ms is not None
        ]

        losses = [row.packet_loss or 0.0 for row in rows]

        return {
            "samples": len(rows),
            "uptime_pct": round(up_count / len(rows) * 100, 1),
            "avg_latency_ms": (
                round(sum(latencies) / len(latencies), 1)
                if latencies else None
            ),
            "max_latency_ms": (
                round(max(latencies), 1) if latencies else None
            ),
            "avg_packet_loss": round(sum(losses) / len(losses), 2),
        }


    def _enrich_status(
        self,
        ifname: str,
        data: dict,
    ) -> dict:

        link = self._link_status(ifname)

        data["link_up"] = link["up"]

        if not data.get("link_speed_mbps"):

            data["link_speed_mbps"] = link["speed_mbps"]

        gateway = self._gateway_for_iface(ifname)

        data["gateway_ip"] = gateway

        if gateway:

            data["gateway_ok"] = self._probe_ping(gateway)["ok"]

        else:

            data["gateway_ok"] = None

        data["dns_ok"] = self._probe_dns()

        data["quality"] = self._compute_quality(data)

        return data


    def _read_counters(self, ifname: str) -> tuple[int, int]:

        try:

            for line in NET_DEV.read_text().splitlines():

                if not line.strip().startswith(ifname + ":"):
                    continue

                parts = line.split(":")
                fields = parts[1].split()

                rx = int(fields[0])
                tx = int(fields[8])

                return rx, tx

        except Exception:
            pass

        return 0, 0


    # ------------------------------------------------------------------
    # Snapshot
    # ------------------------------------------------------------------

    def snapshot(self, db: Session) -> list[dict]:

        settings = self._get_or_create(db)

        targets = [
            t.strip()
            for t in settings.ping_targets.split(",")
            if t.strip()
        ]

        results = []

        for ifname in self._get_wan_interfaces(db):

            link = self._link_status(ifname)

            best_ping = {
                "ok": False,
                "latency_ms": None,
                "packet_loss": 100.0,
            }

            for target in targets:

                probe = self._probe_ping(target)

                if probe["ok"] and (
                    best_ping["latency_ms"] is None
                    or (
                        probe["latency_ms"] is not None
                        and probe["latency_ms"] < best_ping["latency_ms"]
                    )
                ):
                    best_ping = probe

                if probe["ok"] and not best_ping["ok"]:
                    best_ping = probe

            if not best_ping["ok"] and targets:
                best_ping["packet_loss"] = 100.0

            http_ok = (
                self._probe_http(settings.http_url)
                if settings.http_enabled
                else None
            )

            rx, tx = self._read_counters(ifname)

            prev = self._prev_counters.get(ifname)

            if prev is not None:

                if rx < prev[0]:
                    prev = (0, 0)
                if tx < prev[1]:
                    prev = (0, 0)

                interval = max(1, settings.interval_seconds)

                rx_rate = (rx - prev[0]) * 8 / interval
                tx_rate = (tx - prev[1]) * 8 / interval

            else:

                rx_rate = 0.0
                tx_rate = 0.0

            self._prev_counters[ifname] = (rx, tx)

            sample = WanMonitorSample(
                interface=ifname,
                timestamp=datetime.utcnow(),
                link_up=link["up"],
                link_speed_mbps=link["speed_mbps"],
                ping_ok=best_ping["ok"],
                latency_ms=best_ping["latency_ms"],
                packet_loss=best_ping["packet_loss"],
                http_ok=http_ok,
                rx_bps=rx_rate,
                tx_bps=tx_rate,
            )

            db.add(sample)
            db.commit()

            self._evaluate(sample, db)

            results.append(self._serialize(sample))

        self._prune(db, settings.retention_days)

        return results


    def _evaluate(self, sample: WanMonitorSample, db: Session):

        up = sample.link_up and sample.ping_ok and (
            sample.http_ok is not False
        )

        key = sample.interface

        if up:

            self._fail_counts[key] = 0

            if key in self._alerted_down:

                self._alerted_down.discard(key)

                logger.info(
                    "INTERNET RESTABLECIDO en %s: %s",
                    key,
                    sample.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                )

            return

        self._fail_counts[key] = self._fail_counts.get(key, 0) + 1

        settings = self._get_or_create(db)

        if self._fail_counts[key] == 1:

            logger.warning(
                "Internet no responde en %s (%s): enlace=%s, ping=%s, http=%s",
                key,
                sample.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "OK" if sample.link_up else "CAIDO",
                "OK" if sample.ping_ok else "fallando",
                sample.http_ok,
            )

        if self._fail_counts[key] == settings.alert_threshold:

            logger.warning(
                "CORTE DE INTERNET DETECTADO en %s a las %s "
                "(enlace=%s, ping=%s, http=%s)",
                key,
                sample.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "OK" if sample.link_up else "CAIDO",
                "OK" if sample.ping_ok else "fallando",
                sample.http_ok,
            )

        if (
            key not in self._alerted_down
            and self._fail_counts[key] >= settings.alert_threshold
        ):

            self._alerted_down.add(key)

            self._notify(
                "FALLO de internet (WAN)",
                f"Se perdió el servicio de internet en la interfaz "
                f"{key}. "
                f"Enlace: {'OK' if sample.link_up else 'CAÍDO'}, "
                f"ping: {'OK' if sample.ping_ok else 'fallando'}, "
                f"http: {sample.http_ok}."
            )


    def _notify(self, subject: str, body: str):

        try:

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            db = SessionLocal()

            try:

                CriticalAlertEmailService().send(
                    db,
                    subject,
                    body,
                    html_body=f"<p>{body}</p>",
                )

            finally:

                db.close()

        except Exception as error:

            logger.error(f"No se pudo notificar monitoreo WAN: {error}")


    # ------------------------------------------------------------------
    # Queries for the dashboard
    # ------------------------------------------------------------------

    def get_status(self, db: Session) -> dict:

        interfaces = self._get_wan_interfaces(db)

        latest = {}

        for ifname in interfaces:

            sample = (
                db.query(WanMonitorSample)
                .filter(WanMonitorSample.interface == ifname)
                .order_by(WanMonitorSample.timestamp.desc())
                .first()
            )

            if sample:

                data = self._serialize(sample)

            else:

                data = {
                    "interface": ifname,
                    "timestamp": None,
                    "link_up": False,
                    "link_speed_mbps": None,
                    "ping_ok": False,
                    "latency_ms": None,
                    "packet_loss": None,
                    "http_ok": None,
                    "rx_bps": 0,
                    "tx_bps": 0,
                }

            latest[ifname] = self._enrich_status(ifname, data)

        return {
            "interfaces": latest,
            "settings": self.get_settings(db),
        }


    def get_history(
        self,
        db: Session,
        hours: int = 24,
    ) -> dict:

        start = datetime.utcnow() - timedelta(hours=hours)

        interfaces = self._get_wan_interfaces(db)

        series = {}

        summary = {}

        for ifname in interfaces:

            rows = (
                db.query(WanMonitorSample)
                .filter(
                    WanMonitorSample.interface == ifname,
                    WanMonitorSample.timestamp >= start,
                )
                .order_by(WanMonitorSample.timestamp)
                .all()
            )

            series[ifname] = [
                {
                    "t": to_iso_utc(row.timestamp),
                    "latency_ms": row.latency_ms,
                    "packet_loss": row.packet_loss,
                    "rx_bps": row.rx_bps,
                    "tx_bps": row.tx_bps,
                    "up": row.link_up and row.ping_ok,
                }
                for row in rows
            ]

            summary[ifname] = self._history_summary(rows)

        return {
            "series": series,
            "summary": summary,
        }


    def _serialize(self, sample: WanMonitorSample) -> dict:

        return {
            "interface": sample.interface,
            "timestamp": to_iso_utc(sample.timestamp),
            "link_up": sample.link_up,
            "link_speed_mbps": sample.link_speed_mbps,
            "ping_ok": sample.ping_ok,
            "latency_ms": sample.latency_ms,
            "packet_loss": sample.packet_loss,
            "http_ok": sample.http_ok,
            "rx_bps": sample.rx_bps,
            "tx_bps": sample.tx_bps,
        }


    def _fmt_latency(self, sample: WanMonitorSample) -> str:

        if sample.latency_ms is None:
            return "latencia no disponible"

        return f"latencia {sample.latency_ms:.0f} ms"


    def _prune(self, db: Session, retention_days: int):

        cutoff = datetime.utcnow() - timedelta(days=retention_days)

        db.execute(
            sa_delete(WanMonitorSample).where(
                WanMonitorSample.timestamp < cutoff
            )
        )

        db.commit()


    # ------------------------------------------------------------------
    # Scheduler
    # ------------------------------------------------------------------

    def _scheduler_loop(self):

        logger.info("WAN monitor scheduler started.")

        while not self._stop:

            db = SessionLocal()

            try:

                settings = self._get_or_create(db)

                if settings.enabled:

                    self.snapshot(db)

            except Exception as error:

                logger.exception(f"WAN monitor error: {error}")

            finally:

                db.close()

            interval = self._safe_interval()

            for _ in range(interval):
                if self._stop:
                    break
                time.sleep(1)


    def _safe_interval(self) -> int:

        db = SessionLocal()

        try:

            settings = self._get_or_create(db)

            return max(15, settings.interval_seconds)

        finally:

            db.close()


    def start_scheduler(self):

        if self._scheduler_thread is not None:
            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="wan-monitor-scheduler",
        )

        self._scheduler_thread.start()


    def stop(self):

        self._stop = True


    def _get_or_create(self, db: Session) -> WanMonitorSettings:

        settings = db.query(WanMonitorSettings).first()

        if settings is None:

            settings = WanMonitorSettings()
            db.add(settings)
            db.commit()
            db.refresh(settings)

        return settings

