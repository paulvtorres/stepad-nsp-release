# STEPAD NSP

**Network Security Platform** — Appliance de red desarrollado sobre Debian.

Backend **Python / FastAPI** + Frontend **React (Vite)** + **PostgreSQL/Alembic**,
con dnsmasq (DHCP+DNS), pdns-recursor (filtrado), Suricata (IPS), Samba
(archivos), restic (respaldos versionados), Tailscale (acceso remoto) y
WireGuard (VPN).

> Este README es el mapa para **tomar las riendas del software**: estructura,
> flujo de trabajo, y dónde mirar cada cosa. Léelo junto con `AGENTS.md`
> (guía de contexto y reglas del proyecto).

---

## 1. Arquitectura en una línea

```
[ Browser / API clients ]  →  FastAPI (backend)  →  PostgreSQL
                                    │ componentes (threads/daemons)
                                    ├ dnsmasq / pdns / Suricata / Samba / restic / tailscale / wg
                                    └ particiones (shared / backup / private) montadas por demanda
```

- Backend y frontend viven en **un solo deploy** (una máquina = un NSP).
- La **fuente de verdad** de config/backend está en el repo `backend/`; el
  frontend compilado (`frontend/dist`) se sirve junto a la API.
- Cada máquina guarda sus secretos en `/etc/stepad/stepad.env` (0600); nada de
  passwords en el repo.

---

## 2. Estructura del repositorio

```
stepad-nsp/
├── backend/
│   ├── main.py                      # punto de entrada (bootstrap + single_instance)
│   └── core/
│   │   ├── bootstrap.py             # arranca componentes en orden
│   │   ├── component_manager.py     # lifecycle de componentes
│   │   └── config/settings.py, secret_manager.py   # config + secretos
│   ├── api/
│   │   ├── app.py                   # crea la app FastAPI e incluye routers
│   │   └── v1/routes/*.py           # endpoints REST (uno por dominio)
│   ├── <dominio>/                   # cada dominio con su layering:
│   │   ├── routes/   schemas/   models/
│   │   ├── services/  repositories/  providers/
│   │   └── components/             # background threads/daemons del dominio
│   ├── migrations/                  # migraciones Alembic (versión SQL)
│   ├── scripts/                     # utilidades (migrar, configurar suricata…)
│   ├── shared/                      # config, logging, utils
│   └── tests/                       # pytest (conftest fuerza modo dev)
├── frontend/
│   ├── src/pages/                   # pantallas (Security, Protection, Shares…)
│   ├── src/services/api.js          # cliente de la API (por dominio)
│   └── vite.config.js, package.json
├── scripts/
│   ├── publish-release.sh           # publica una versión a stepad-nsp-release
│   └── configure_suricata.py, pre-update-backup.sh, restore-backup.sh
├── install.sh / uninstall.sh / update.sh / make-installer.sh / get-stepad.sh
├── AGENTS.md                        # guía de contexto y reglas de trabajo
└── VERSION
```

---

## 3. Backend: los dominios

Cada dominio tiene el mismo patrón (`routes + schemas + models + services +
repositories + providers`). Los principales:

| Dominio | Qué hace |
|---|---|
| `auth`, `users` | Login JWT, roles (OPERATOR/ADMIN), usuarios, MFA |
| `network` (+ `devices`, `interfaces`, `zones`, `configuration`) | Tarjetas WAN/LAN, dispositivos, zonas/segmentos, DHCP (dnsmasq) |
| `dhcp` | Reservas de IP, pools, diagnóstico, alertas |
| `dns` (+ `content`, `groups`) | Filtrado de dominios, categorías, grupos, RPZ |
| `firewall` (+ `rules`, `ips`) | Reglas, Suricata (IPS), respuesta ante amenazas |
| `shares` | Particiones y carpetas compartidas, respaldo (restic), web files |
| `storage` | Discos/particiones (shared/backup/private), montaje por demanda |
| `backups` | Respaldo del sistema (config + DB + secretos) a USB/cloud |
| `monitoring`, `notifications`, `reports` | Monitoreo WAN, alertas por email, reportes |
| `vpn`, `rustdesk`, `bandwidth`, `audit`, `organization` | VPN/WG, escritorio remoto, uso de ancho, auditoría, datos de la empresa |

**Componentes**: los procesos de fondo (scheduler de respaldos, capturas de
logs, monitoreo…) son componentes que el `component_manager` arranca/detiene
con el ciclo de vida de la app.

---

## 4. Cómo funciona el respaldo (restic) — clave

- Cada **partición de respaldo** crea su **programación** al crearse; al
  eliminar la partición se elimina la programación.
- Cada job tiene su **repo restic**: `<particion>/Respaldo/.backups/job-<id>`.
- **Solo corre en su ventana de horario** (una vez por horario; sin
  "ponerse al día" horas después del horario perdido).
- **Solo versiona si hubo cambios**:
  - Origen local: firma de árbol (ruta/mtime/tamaño); sin cambios → no corre.
  - Origen de red: corre restic `--json`; si `+0 B` → descarta el snapshot
    vacío y registra "Sin cambios… No se creó versión".
- **No satura la red**: el respaldo de red se limita por QoS
  (`rate_limit_mbps`; default **50% del enlace**; nunca >80%).
- **Mantenimiento por job**: `restic check` (integridad) y test-restore,
  con intervalos configurables.
- **Watchdog** de "ventana perdida": alerta si un job no corrió su horario.
- IDs de job **únicos globales**; retención `keep-last N` + prune por espacio;
  restic es **resumible** (una corrida cortada se retoma en la siguiente).

Las programaciones quedan visibles aunque la partición esté desmontada:
**caché multi-bóveda** (`/etc/stepad/backup_schedule.json`, mirror completo)
+ bóvedas registradas siempre listadas.

---

## 5. Modelo de particiones

- **compartir** (shared): expuesta por SMB a la red.
- **respaldar** (backup): privada, **desmontada por defecto** (solo se monta
  durante la corrida) → anti-ransomware; no expuesta por SMB; montada con
  `noexec,nodev,nosuid`.
- **privada** (private): guarda información elegida; también montada por demanda.

---

## 6. Release / publicación

```
DEV (<DEV_LAN_IP>)  →  tag + bash scripts/publish-release.sh vX.Y.Z
       └─► stepad-nsp-release (GitHub) ──► usuarios: curl ... get-stepad.sh | sudo bash
```

1. Se desarrolla y prueba **solo en DEV**.
2. Se versiona **solo con aprobación**: bump `VERSION`, commit, `git tag`, push.
3. `publish-release.sh` → `make-installer.sh` (valida shell+python+heredocs,
   compila el frontend, **excluye credenciales/AGENTS/.env**) y sube el
   instalador + `get-stepad.sh` + `VERSION` al repo release.
4. Actualización en cada máquina: `get-stepad.sh` (preserva secretos en
   `/etc/stepad/stepad.env`, respalda env por cada update). Al terminar,
   el instalador imprime un **resumen de estado** (servicios, web,
   base de datos y disco) y **sale con error** si el NSP no quedó
   operativo, para que un fallo silencioso no pase inadvertido.
5. **Unidades desconectadas**: la reconciliación periódica (cada 10 min)
   marca un volumen como ausente (por UUID o ruta) y lo purga
   automáticamente solo tras **30 días** sin aparecer. Un desenchufe
   temporal no borra la configuración. Ajustable con
   `STEPAD_STALE_VOLUME_DAYS` (`0` desactiva la purga). El disco del SO
   nunca entra en esta ruta: solo se consideran volúmenes no montados
   cuyo dispositivo ya no existe.
6. Antes de tocar nada, el update guarda un **punto de retorno** en
   `/var/lib/stepad/rollback/`: código actual + `pg_dump` plano (se
   conservan los 3 últimos). Si una versión falla:

   ```bash
   curl -fsSL "https://raw.githubusercontent.com/paulvtorres/stepad-nsp-release/main/get-stepad.sh?x=$(date +%s)" | sudo bash -s -- --rollback
   ```

   `--rollback vX.Y.Z` elige un punto concreto y `--rollback-list` los
   lista. Restaura código y base, reinicia y espera `/healthz` hasta
   180 s; si la base no está en el punto, se niega salvo
   `STEPAD_ROLLBACK_ALLOW_NO_DB=1`. El equipo marcado como desarrollo
   sigue bloqueado (se actualiza con git).

> El instalador **no** incluye `AGENTS.md`, `.env*` ni credenciales (ver
> `make-installer.sh`).

---

## 7. Máquinas (sin credenciales en el repo)

> **Equipo de desarrollo**: debe existir `/etc/stepad/development`. El
> instalador (`get-stepad.sh`/`install.sh`) se niega a correr si ese
> archivo existe, porque borra el repo (`.git`) y el venv. Dev se
> actualiza con `git -C ~/stepad-nsp pull && sudo systemctl restart
> stepad-nsp`. Override de emergencia: `STEPAD_ALLOW_INSTALL=1`.

| Rol | LAN | Tailscale | Uso |
|---|---|---|---|
| **Dev** | <DEV_LAN_IP> | <DEV_TAILSCALE_IP> | fuente del código, pruebas, releases |
| **Prod (respaldos/discos)** | <PROD_LAN_IP> | <PROD_TAILSCALE_IP> | producción, particiones y respaldos |
| **Router de sitio** | <ROUTER_LAN_IP> | <ROUTER_TAILSCALE_IP> | gateway LAN usuarios + NSP |

Credenciales de acceso/UI → en cada máquina (`/etc/stepad/stepad.env` y
usuarios de la UI); **no se versionan**.

---

## 8. Para tomar las riendas (guía de arranque)

1. Lee **`AGENTS.md`** (reglas: todo se hace en DEV, no versionar sin
   aprobación, decisiones de diseño ya tomadas).
2. Seguí el **ciclo de un endpoint**: `api/v1/routes/<dominio>.py` →
   `services/<dominio>.py` → `models/` (SQLAlchemy) → `migrations/`.
3. Entendé el **respaldo** leyendo `backend/shares/services/share_backup_service.py`
   (es el módulo más grande) y `backend/shares/services/net_rate_shaper.py`.
4. Frontend: `frontend/src/pages/` por pantalla; `services/api.js` es el
   cliente usado por todas.
5. Testing: `backend/tests/` (pytest); los tests corren en modo dev sin DB real.
6. Publicación: `bash scripts/publish-release.sh v2.5.301 "nota"` (ver §6).

---

## 9. Estado actual

Versión en curso: **v2.5.511** (retención configurable por tipo, panel de
tareas programadas, respaldo de datos/configuración a la nube con kit de
recuperación, cifrado de credenciales en reposo, revocación de sesiones,
bloqueo P2P inline para toda la red y división incremental del servicio de
respaldos).

---

## 10. Convenciones de desarrollo

### Idioma
- **Código interno en inglés**: comentarios, docstrings, mensajes de log,
  nombres de pruebas y **mensajes de commit**.
- **Interfaz y documentos para el usuario en español**: textos del panel,
  botones, correos, reportes y documentos como el kit de recuperación.
- Al modificar un módulo que tenga comentarios en español, se traducen a
  inglés como parte del cambio (sin tocar los textos de UI).

### Commits y versionado
- Formato: `tipo(alcance): descripción corta`, en inglés (p. ej.
  `fix(dhcp): keep the last known IP for offline devices`).
- Cada versión publicada es una etiqueta `vX.Y.Z`; `VERSION` y `README`
  deben coincidir antes de publicar.
- Antes de publicar: `pytest` completo, `ruff check --select E9,F63,F7,F82`
  y `npm run lint` + `npm run build`.
- El instalador se firma (Ed25519) y `get-stepad.sh` verifica la firma
  antes de instalar (fail-closed).

### Documentación
- El **README no se actualiza automáticamente**: viaja tal cual dentro de
  cada release. Si cambia una función, un flujo o la versión, se edita
  aquí en el mismo commit.
- El `CHANGELOG` del repositorio de release resume las versiones
  publicadas.

### Seguridad del host (SSH)
- `sshd` escucha **solo** en las direcciones que no son la WAN (LAN,
  Tailscale y WireGuard); la WAN queda cerrada para SSH.
- El servicio `stepad-sshd-listen` regenera la configuración en cada
  arranque y un timer la refresca cada 10 minutos (si cambian las IP),
  validando con `sshd -t` antes de recargar.
- Si Tailscale todavía no asignó su IP, se **conserva la configuración
  anterior** (con la IP estable de Tailscale) en lugar de reescribirla,
  para no perder el acceso remoto.
- La autenticación por contraseña sigue habilitada: se recomienda migrar
  a claves SSH y agregar `fail2ban`.
- El monitoreo genera una **alerta crítica** si SSH vuelve a quedar
  expuesto en la WAN (o escuchando en `0.0.0.0`) y también si la
  autenticación por contraseña sigue habilitada (revisión semanal).

### Correo
- Una **sola cuenta SMTP** (Ajustes → Correo) para todos los envíos.
- Cada sección que envía correo configura su **destinatario** y **copia
  oculta (CCO)**:
  - **Reportes de navegación**: Para + CCO + horario (diario).
  - **Respaldo por correo**: Para + CCO + hora del respaldo.
  - **Inmediatas (sin horario)**: alertas críticas, alertas DNS/malware y
    cuarentena; requieren intervención pronta y se envían al ocurrir el
    evento.

### Reemplazo de equipo (migrar a otra máquina)
- **Respaldo del sistema → Reemplazo de equipo**: genera un paquete cifrado
  (AES-256 + PBKDF2) con la base de datos, `/etc/stepad/stepad.env` y
  `config.yaml`. Contiene secretos: guárdalo de forma segura.
- En la máquina nueva (STEPAD ya instalado):
  ```bash
  sudo bash /home/paulan/stepad-nsp/scripts/import-replacement.sh --dry-run /ruta/paquete.enc
  sudo bash /home/paulan/stepad-nsp/scripts/import-replacement.sh /ruta/paquete.enc
  ```
  Valida el manifest, guarda el estado actual en
  `/var/lib/stepad/rollback/pre-replacement-*`, restaura secretos/config/BD,
  aplica migraciones, reinicia y espera `/healthz`.
- Tras importar: revisar **Interfaces** (MAC de la máquina nueva), usuarios
  y MFA; el paquete puede borrarse.

### Auditoría a prueba de manipulación
- Cada registro de auditoría guarda `prev_hash` + `entry_hash` (SHA-256 de
  sus campos y del anterior): editar o borrar una fila rompe la cadena.
- `GET /api/v1/audit/verify` (ADMIN) la recalcula y devuelve el primer
  registro roto; la página **Auditoría** tiene el botón “Verificar
  integridad”.
- Los registros anteriores a la cadena (0042) se informan como “antiguos
  sin cadena”.

### Errores y soporte
- `HTTPException` mantiene respuestas 4xx/409 con mensajes concretos.
- Errores inesperados se registran con traza y se devuelven como JSON
  (`{"detail": "...", "request_id": "..."}`), con `X-Request-ID`, en lugar
  de un 500 opaco.
- Solo el explorador de archivos traduce `PermissionError` → 403 y
  `FileNotFoundError` → 404. En el resto es **500 con referencia**: que
  falte un binario (`parted`) es un problema del servidor, no del cliente.
- `TimeoutError` → 504 en cualquier ruta.

### Observabilidad
- `GET /healthz` (público, mínimo): estado, versión, uptime y base de datos.
- `GET /metrics` (solo red interna/LAN/Tailscale): formato Prometheus
  (`# TYPE` una vez por métrica). Incluye `stepad_up`, disco, tamaño de BD,
  alertas sin leer, leases DHCP, estado de servicios, último respaldo y,
  **por cada trabajo de carpeta**, `stepad_backup_job_age_seconds` y
  `stepad_backup_job_ok{vault,job}`.
- Detrás de un proxy inverso define `STEPAD_METRICS_TOKEN` (o
  `/etc/stepad/metrics_token`): el token pasa a ser obligatorio
  (`X-Metrics-Token`, `Authorization: Bearer` o `?token=`).
- **Verificación mensual de respaldo**: restaura el último backup cifrado
  en una base temporal (`stepad_restore_check`), cuenta tablas/equipos y
  la elimina. Si falla, genera una alerta **crítica**. Se ve en
  Ajustes → Tareas programadas y en `GET /backups/verify`.

### Migración a usuario dedicado + helper privilegiado (pendiente)

Hoy el servicio corre como **root**; es el riesgo estructural de mayor
impacto (quien escriba en `/home/<user>/stepad-nsp` obtiene root, y una
API web con root tiene un radio de daño enorme). El cambio **no se hace en
caliente**: requiere que todas las operaciones privilegiadas pasen por un
helper validado o por capabilities.

Inventario aproximado (llamadas privilegiadas, sin tests):
`mount` 104, `tc` 52, `nft` 50, `systemctl` 45, `dnsmasq` 22, `parted` 15,
`wg` 7, `pdns_recursor` 7, `ip` 4 (75 archivos usan `subprocess`).

Plan por fases:
1. **Helper** `/usr/local/sbin/stepad-priv-helper` (root, autocontenido, sin
   importar código del repo): acciones validadas para `parted rm`, `mount`,
   `umount`, `wipefs`, `partprobe`, `udevadm settle` y una lista blanca de
   `systemctl`/`nft`/`tc`/`ip`. Validación estricta de `/dev/*`, montajes
   bajo `/mnt/stepad-*`, tipos de FS y opciones; nunca el disco del SO.
2. **Cliente** en el backend que use el helper solo si el proceso **no** es
   root (hoy, como root, sigue igual) y pruebas en Dev.
3. **Ventana**: crear el usuario `stepad-nsp`, `chown` de `/etc/stepad` y de
   los repos de restic, `User=` en systemd, `sudoers` solo para el helper,
   arranque y verificación; con **rollback** (volver a root) si algo falla.

Antes de la fase 3: probar en Dev un ciclo completo (DHCP/DNS/firewall,
montajes, respaldos, restauración) con el servicio como no-root.