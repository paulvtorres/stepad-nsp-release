import { useState, useEffect, useCallback } from "react";
import {
    getSystemBackupStatus,
    getSystemBackupConfig,
    saveSystemBackupConfig,
    createSystemBackup,
    listSystemBackupSnapshots,
    restoreSystemBackup,
    detectSystemBackupUsb,
} from "../../services/api";
import "./system-backup.css";

function formatWhen(iso) {
    if (!iso) return "Nunca";
    const d = new Date(iso);
    return d.toLocaleString("es-EC", {
        dateStyle: "medium",
        timeStyle: "short",
    });
}

function elapsedSince(iso) {
    if (!iso) return "";
    const ms = Date.now() - new Date(iso).getTime();
    const mins = Math.round(ms / 60000);
    if (mins < 60) return `hace ${mins}m`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `hace ${hrs}h`;
    return `hace ${Math.round(hrs / 24)}d`;
}

export default function SystemBackup() {
    const [status, setStatus] = useState(null);
    const [config, setConfig] = useState(null);
    const [snapshots, setSnapshots] = useState([]);
    const [loading, setLoading] = useState(true);
    const [creating, setCreating] = useState(false);
    const [restoring, setRestoring] = useState(null);
    const [feedback, setFeedback] = useState(null);
    const [usbAvailable, setUsbAvailable] = useState(false);

    const load = useCallback(async () => {
        try {
            const [s, c, sn, usb] = await Promise.all([
                getSystemBackupStatus(),
                getSystemBackupConfig(),
                listSystemBackupSnapshots(),
                detectSystemBackupUsb(),
            ]);
            setStatus(s);
            setConfig(c);
            setSnapshots(sn?.snapshots || []);
            setUsbAvailable(usb?.available || false);
        } catch (e) {
            setFeedback({ type: "error", msg: "Error cargando datos: " + e.message });
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { load(); }, [load]);

    async function handleCreate() {
        setCreating(true);
        setFeedback({ type: "info", msg: "Creando backup del sistema..." });
        try {
            const result = await createSystemBackup();
            if (result?.success) {
                setFeedback({ type: "success", msg: "Backup creado exitosamente." });
                await load();
            } else {
                setFeedback({ type: "error", msg: "Fallo: " + (result?.error || "Error desconocido") });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setCreating(false);
        }
    }

    async function handleRestore(snapshotId) {
        if (!window.confirm(`¿Restaurar backup ${snapshotId}? El NSP se reiniciará.`)) return;
        setRestoring(snapshotId);
        setFeedback({ type: "info", msg: "Restaurando... el NSP se reiniciará." });
        try {
            const result = await restoreSystemBackup(snapshotId);
            if (result?.success) {
                setFeedback({ type: "success", msg: "Restaurado. El NSP se está reiniciando..." });
            } else {
                setFeedback({ type: "error", msg: "Fallo: " + (result?.error || "") });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setRestoring(null);
        }
    }

    async function handleSaveConfig() {
        try {
            await saveSystemBackupConfig(config);
            setFeedback({ type: "success", msg: "Configuración guardada." });
        } catch (e) {
            setFeedback({ type: "error", msg: "Error guardando: " + e.message });
        }
    }

    if (loading) return <div className="sb-page"><div className="sb-loading">Cargando...</div></div>;

    return (
        <div className="sb-page">
            <h1>Backup del Sistema</h1>
            <p className="sb-subtitle">
                Copias de seguridad de la configuración completa del NSP: base de datos,
                archivos de configuración, reglas de firewall y claves.
            </p>

            {feedback && (
                <div className={`sb-feedback ${feedback.type}`}>
                    {feedback.msg}
                    <button className="sb-btn" style={{ marginLeft: 12, padding: "4px 10px" }}
                        onClick={() => setFeedback(null)}>×</button>
                </div>
            )}

            {/* Status cards */}
            <div className="sb-status-grid">
                <div className="sb-status-card">
                    <div className="label">Último backup</div>
                    <div className={`value ${status?.last_backup ? "ok" : "warn"}`}>
                        {formatWhen(status?.last_backup)}
                    </div>
                    {status?.last_backup && (
                        <div style={{ fontSize: "0.8rem", color: "#64748b", marginTop: 2 }}>
                            {elapsedSince(status?.last_backup)}
                        </div>
                    )}
                </div>
                <div className="sb-status-card">
                    <div className="label">Total backups</div>
                    <div className="value">{status?.total_backups || 0}</div>
                </div>
                <div className="sb-status-card">
                    <div className="label">Destino</div>
                    <div className="value">
                        {status?.destination === "usb" ? "USB" :
                         status?.destination === "cloud" ? "Nube" : "Local"}
                    </div>
                    {status?.destination === "usb" && !status?.usb_available && (
                        <div style={{ fontSize: "0.8rem", color: "#d97706", marginTop: 2 }}>
                            USB no conectado
                        </div>
                    )}
                </div>
                <div className="sb-status-card">
                    <div className="label">Estado</div>
                    <div className={`value ${status?.enabled ? "ok" : "warn"}`}>
                        {status?.enabled ? "Activo" : "Inactivo"}
                    </div>
                </div>
            </div>

            {/* Actions */}
            <div className="sb-actions">
                <button className="sb-btn primary" onClick={handleCreate} disabled={creating}>
                    {creating ? "Creando..." : "+ Crear backup ahora"}
                </button>
                <button className="sb-btn" onClick={load}>Actualizar</button>
            </div>

            {/* Snapshots */}
            <div className="sb-snapshots">
                <h2>Historial de backups ({snapshots.length})</h2>
                {snapshots.length === 0 ? (
                    <div className="sb-empty">
                        No hay backups aún. Creá el primero con el botón de arriba.
                    </div>
                ) : (
                    snapshots.slice().reverse().map((snap) => (
                        <div key={snap.id} className="sb-snapshot-row">
                            <div className="sb-snapshot-info">
                                <div className="id">{snap.id?.slice(0, 8)}</div>
                                <div className="meta">
                                    {formatWhen(snap.time)} · {snap.tree?.total_files || "?"} archivos
                                </div>
                                <div className="tags">
                                    {(snap.tags || []).map((tag) => (
                                        <span key={tag} className={`sb-tag ${tag}`}>
                                            {tag}
                                        </span>
                                    ))}
                                </div>
                            </div>
                            <button
                                className="sb-btn"
                                onClick={() => handleRestore(snap.id)}
                                disabled={restoring === snap.id}
                            >
                                {restoring === snap.id ? "Restaurando..." : "Restaurar"}
                            </button>
                        </div>
                    ))
                )}
            </div>

            {/* Config */}
            {config && (
                <div className="sb-config">
                    <h2>Configuración</h2>
                    <div className="sb-form-row">
                        <label>Destino:</label>
                        <select
                            value={config.destination || "local"}
                            onChange={(e) => setConfig({ ...config, destination: e.target.value })}
                        >
                            <option value="local">Local (/var/backups/stepad)</option>
                            <option value="usb" disabled={!usbAvailable}>
                                USB {usbAvailable ? "" : "(no detectado)"}
                            </option>
                            <option value="cloud">Nube (S3/B2)</option>
                        </select>
                    </div>
                    {config.destination === "cloud" && (
                        <div className="sb-form-row">
                            <label>Backend:</label>
                            <input
                                value={config.cloud_backend || ""}
                                onChange={(e) => setConfig({ ...config, cloud_backend: e.target.value })}
                                placeholder="s3:bucket-name"
                            />
                        </div>
                    )}
                    <div className="sb-form-row">
                        <label>Retener diarios:</label>
                        <input
                            type="number"
                            min="1"
                            max="90"
                            value={config.keep_daily || 7}
                            onChange={(e) => setConfig({ ...config, keep_daily: parseInt(e.target.value) || 7 })}
                        />
                    </div>
                    <div className="sb-form-row">
                        <label>Retener semanales:</label>
                        <input
                            type="number"
                            min="1"
                            max="52"
                            value={config.keep_weekly || 4}
                            onChange={(e) => setConfig({ ...config, keep_weekly: parseInt(e.target.value) || 4 })}
                        />
                    </div>
                    <div className="sb-form-row">
                        <label>Retener mensuales:</label>
                        <input
                            type="number"
                            min="1"
                            max="24"
                            value={config.keep_monthly || 6}
                            onChange={(e) => setConfig({ ...config, keep_monthly: parseInt(e.target.value) || 6 })}
                        />
                    </div>
                    <div style={{ marginTop: 12 }}>
                        <button className="sb-btn primary" onClick={handleSaveConfig}>
                            Guardar configuración
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}
