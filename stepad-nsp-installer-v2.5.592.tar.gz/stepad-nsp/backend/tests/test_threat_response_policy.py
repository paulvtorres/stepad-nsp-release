import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.ips.models.threat_response_policy import ThreatResponsePolicy
from backend.ips.services.threat_response_service import ThreatResponseService


@pytest.fixture
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    yield session
    session.close()


@pytest.fixture
def service():
    return ThreatResponseService()


def test_default_policies_are_safe(service, db):
    policies = service.get_policies(db)

    assert len(policies) == 4
    assert any(policy["name"] == "Default seguro" for policy in policies)


def test_snmp_signature_is_alert_only(service, db):
    policy = service.policy_for(
        db,
        "Attempted Information Leak",
        "GPL SNMP public access udp",
    )

    assert policy is not None
    assert policy.action == "alert"
    assert policy.name == "SNMP público / descubrimiento"


def test_high_confidence_malware_is_quarantine(service, db):
    policy = service.policy_for(
        db,
        "A Network Trojan was detected",
        "ET TROJAN Example",
    )

    assert policy is not None
    assert policy.action == "quarantine_and_block_c2"


def test_default_is_ignore(service, db):
    policy = service.policy_for(db, "Unknown", "Unclassified event")

    assert policy is not None
    assert policy.action == "ignore"


def test_create_and_update_policy(service, db):
    created = service.create_policy(
        db,
        name="Prueba",
        match_type="signature",
        match_value="test signature",
        action="alert",
        priority=50,
        enabled=True,
        description="Prueba",
    )

    updated = service.update_policy(
        db,
        created["id"],
        name="Prueba editada",
        match_type="signature",
        match_value="test signature",
        action="quarantine",
        priority=40,
        enabled=True,
        description="Editada",
    )

    assert updated["name"] == "Prueba editada"
    assert updated["action"] == "quarantine"
    assert updated["priority"] == 40


def test_invalid_action_is_rejected(service, db):
    with pytest.raises(ValueError):
        service.create_policy(
            db,
            name="Inválida",
            match_type="category",
            match_value="x",
            action="delete_everything",
            priority=10,
        )


def test_simulador_snmp_no_aisla(service, db):
    result = service.simulate_event(
        db,
        signature="GPL SNMP public access udp",
        category="Attempted Information Leak",
        severity="warning",
        src_ip="192.168.1.42",
        dst_ip="192.168.1.150",
        dst_port=161,
    )

    assert result["matched"] is True
    assert result["policy"]["name"] == "SNMP público / descubrimiento"
    assert result["action"] == "alert"
    assert result["quarantine"] is False
    assert result["block_c2"] is False


def test_simulador_malware_sin_dueno_verificado_no_aisla(service, db):
    result = service.simulate_event(
        db,
        signature="ET TROJAN Example",
        category="A Network Trojan was detected",
        severity="critical",
        src_ip="192.168.1.42",
        dst_ip="8.8.8.8",
        dst_port=443,
    )

    assert result["matched"] is True
    assert result["action"] == "quarantine_and_block_c2"
    assert result["quarantine"] is False
    assert "dueño actual" in result["reason"] or "dueño" in result["reason"]
