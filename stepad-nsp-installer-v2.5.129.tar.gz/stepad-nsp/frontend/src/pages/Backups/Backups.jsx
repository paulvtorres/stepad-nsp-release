import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";

import { getShareStatus, getWebFileList } from "../../services/api";
import { getToken } from "../../auth/authStorage";

import ShareBackupsPanel from "../Shares/SharesBackupsPanel";

import "../Shares/shares.css";

const _API_URL = import.meta.env.VITE_API_URL || "/api/v1";

async function fetchSilent(endpoint) {
    const token = getToken();
    const response = await fetch(`${_API_URL}${endpoint}`, {
        headers: {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
        },
    });
    if (!response.ok) throw new Error(`API Error ${response.status}`);
    return response.json();
}

export default function Backups() {
    const [params] = useSearchParams();
    const anchorSource = params.get("source") || "";

    const [status, setStatus] = useState(null);
    const [networkUnits, setNetworkUnits] = useState([]);
    const [subfolderSources, setSubfolderSources] = useState([]);

    useEffect(() => {
        let active = true;
        Promise.all([
            getShareStatus(),
            fetchSilent("/shares/network-units").catch(() => ({ units: [] })),
        ])
            .then(([s, nu]) => {
                if (!active) return;
                setStatus(s);
                setNetworkUnits(nu.units || []);
            })
            .catch((err) => {
                console.error(err);
            });
        return () => { active = false; };
    }, []);

    const volumes = useMemo(() => (status?.volumes || []), [status]);
    const folders = useMemo(() => (status?.folders || []), [status]);

    // Subcarpetas de las carpetas compartidas (un nivel) para poder elegirlas
    // como origen de respaldo (ej. Compartida/XML).
    useEffect(() => {
        let cancelled = false;
        (async () => {
            const items = [];
            const sharedFolders = (folders || []).filter((fl) => fl.shared && fl.path);
            for (const fl of sharedFolders) {
                const volume = volumes.find((v) => v.id === fl.volume_id);
                if (!volume?.mountpoint) continue;
                const parts = fl.path.split("/").filter(Boolean);
                const prefix = parts[parts.length - 1] || "";
                try {
                    const listing = await getWebFileList(volume.mountpoint, prefix);
                    for (const dir of listing.directories || []) {
                        items.push({
                            path: [volume.mountpoint, prefix, dir.name].filter(Boolean).join("/"),
                            label: `${prefix}/${dir.name}`,
                            kind: fl.shared ? "Compartida" : "Privada",
                            isVolume: false,
                            volumeName: volume.name || "",
                        });
                    }
                } catch {
                    // Si una carpeta no se puede listar, se omite.
                }
            }
            if (!cancelled) setSubfolderSources(items);
        })();
        return () => { cancelled = true; };
    }, [volumes, folders]);

    // Orígenes candidatos: carpetas COMPARTIDAS (y subcarpetas), más las
    // unidades de red montadas. Las privadas y el destino no se ofrecen.
    const backupSources = useMemo(() => {
        const opts = [];
        for (const fl of folders) {
            if (!fl.path || !fl.shared) continue;
            const volume = volumes.find((v) => v.id === fl.volume_id);
            const label = fl.name || fl.path;
            opts.push({
                path: fl.path,
                label,
                kind: "Compartida",
                isVolume: false,
                volumeName: volume?.name || "",
            });
        }
        for (const sub of subfolderSources) {
            if (sub.path !== anchorSource) opts.push(sub);
        }
        for (const nu of networkUnits) {
            if (!nu.mounted) continue;
            opts.push({
                path: nu.mount_point,
                label: nu.name || (nu.host + "/" + nu.share),
                kind: "Unidad de Red",
                isVolume: false,
                volumeName: nu.letter ? nu.letter + ":" : "",
            });
        }
        const seen = new Set();
        return opts.filter((o) => (seen.has(o.path) ? false : (seen.add(o.path), true)));
    }, [volumes, folders, anchorSource, subfolderSources, networkUnits]);

    // Destinos candidatos: carpeta privada «Respaldo» de cada unidad local.
    const destinationVaults = useMemo(() => (
        volumes
            .filter((v) => v.mountpoint)
            .map((v) => ({
                path: `${v.mountpoint}/Respaldo`,
                label: v.name || v.mountpoint,
            }))
    ), [volumes]);

    return (
        <div className="sh-page">
            <ShareBackupsPanel
                sources={backupSources}
                anchorSource={anchorSource || null}
                destinationVaults={destinationVaults}
            />
        </div>
    );
}