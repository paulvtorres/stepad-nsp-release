"""Ciclo de vida del inventario: archivar equipos sin evidencia."""

from __future__ import annotations

from datetime import timedelta

from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger

DEFAULT_ARCHIVE_DAYS = 30


class DeviceLifecycleService:

    def reconcile(self, db, days: int | None = None) -> dict:

        if days is None:

            try:

                from backend.shared.config.config_service import ConfigService

                days = int(
                    (ConfigService().get().get("monitoring", {}) or {}).get(
                        "device_archive_days", DEFAULT_ARCHIVE_DAYS
                    )
                    or DEFAULT_ARCHIVE_DAYS
                )

            except Exception:

                days = DEFAULT_ARCHIVE_DAYS

        cutoff = utcnow() - timedelta(days=max(1, int(days)))

        candidates = (
            db.query(NetworkDevice)
            .filter(
                NetworkDevice.archived_at.is_(None),
                NetworkDevice.current_ip == "",
                NetworkDevice.last_ip == "",
                NetworkDevice.ip_address == "",
                NetworkDevice.permanent_ip.is_(None),
                NetworkDevice.is_permanent.is_(False),
                NetworkDevice.linked_to_id.is_(None),
                NetworkDevice.last_seen < cutoff,
            )
            .all()
        )

        now = utcnow()
        for device in candidates:
            device.archived_at = now
            device.archive_reason = (
                f"Sin IP ni evidencia desde {device.last_seen.isoformat()}"
            )
            db.add(device)

        if candidates:
            db.commit()
            logger.info("Devices: %d equipo(s) archivado(s) por inactividad.", len(candidates))

        return {"success": True, "archived": len(candidates)}


def unarchive_if_observed(device) -> None:
    """Un equipo archivado vuelve al inventario al observarse de nuevo."""

    if getattr(device, "archived_at", None) is not None:
        device.archived_at = None
        device.archive_reason = None
