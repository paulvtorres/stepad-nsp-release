"""Guia practica en lenguaje claro para las alertas del IPS.

Cada alerta tecnica de Suricata se traduce a: que significa de verdad
y que acciones tomar, para que un administrador sin conocimientos de
seguridad sepa como actuar sin ayuda externa.
"""


def alert_guidance(title: str | None, message: str | None):

    text = f"{title or ''} {message or ''}".lower()

    if any(
        k in text
        for k in (
            "coinminer", "mining", "stratum", "cryptocurrency",
            "crypto", "monero", "verus", "xmr", "mineria", "minería",
            "criptomoneda", "cryptojacking",
        )
    ):

        return {
            "tipo": "Mineria de criptomonedas",
            "explicacion": (
                "Este equipo se esta comunicando con un pool de mineria "
                "de criptomonedas (protocolo Stratum). Suele indicar un "
                "minero instalado sin autorizacion o una infeccion que "
                "usa la electricidad e internet de la empresa."
            ),
            "acciones": [
                "Revisa el equipo indicado: busca programas mineros "
                "instalados o procesos desconocidos que consuman CPU.",
                "Escanea el equipo con antivirus (los mineros llegan "
                "habitualmente como malware).",
                "Opcional: pulsa 'Aislar equipo' para cortarlo de la red "
                "mientras lo revisas.",
                "Bloquea los pools de mineria (luckpool, srbminer, verus, "
                "vipor) globalmente para impedirlo.",
            ],
        }

    if any(
        k in text
        for k in ("trojan", "malware", "botnet", "ransomware", "banking")
    ):

        return {
            "tipo": "Posible malware",
            "explicacion": (
                "Se detecto actividad de software malicioso en este "
                "equipo (trojan, botnet, ransomware, robo de datos). "
                "Puede estar comprometido y conectandose a un servidor "
                "de control."
            ),
            "acciones": [
                "Aisla el equipo YA pulsando 'Aislar equipo' para cortar "
                "su comunicacion.",
                "Escanea con antivirus completo y actualizado.",
                "Cambia las contrasenas usadas desde ese equipo.",
                "No lo conectes a la red hasta estar seguro de que esta "
                "limpio.",
            ],
        }

    if any(
        k in text
        for k in (
            "command and control", "c2", "cnc", "callback",
            "malware cnc", "c2 server",
        )
    ):

        return {
            "tipo": "Comunicacion con servidor de control (C2)",
            "explicacion": (
                "El equipo se esta comunicando con un servidor de mando "
                "y control, tipico de malware que recibe ordenes o "
                "exfiltra datos."
            ),
            "acciones": [
                "Aisla el equipo pulsando 'Aislar equipo' de inmediato.",
                "Investiga que proceso se conecta a esa IP/destino.",
                "Escanea con antivirus y revisa procesos en ejecucion.",
                "Revisa si hubo exfiltracion de datos sensibles.",
            ],
        }

    if any(
        k in text
        for k in ("exploit", "attack", "intrusion", "sql injection", "overflow", "scan")
    ):

        return {
            "tipo": "Intento de ataque o explotacion",
            "explicacion": (
                "Se detecto un intento de ataque o explotacion "
                "relacionado con este equipo (puede ser un equipo de la "
                "red intentando atacar, o un equipo bajo ataque)."
            ),
            "acciones": [
                "Revisa si el equipo origen realiza el ataque (comprometido) "
                "o si es victima del mismo.",
                "Si el equipo origen es interno, aisla y escanea.",
                "Actualiza sistemas y aplicaciones (parches).",
                "Revisa el destino reportado para confirmar el vector.",
            ],
        }

    return {
        "tipo": "Alerta de seguridad",
        "explicacion": (
            "El IPS detecto actividad que coincide con una firma de "
            "seguridad. Revisa el detalle y el equipo origen."
        ),
        "acciones": [
            "Revisa el equipo indicado y su actividad.",
            "Si la alerta es critica o se repite, aísla el equipo y "
            "escanea con antivirus.",
            "Si crees que es un falso positivo, puedes marcarla como "
            "leida y seguir monitoreando.",
        ],
    }
