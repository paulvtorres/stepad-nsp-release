import socket

from sqlalchemy.orm import Session

from backend.siem.repositories.siem_repositories import (
    SyslogSettingsRepository
)

from backend.shared.logging.logger import logger


class SyslogService:

    def __init__(self):

        self.repository = SyslogSettingsRepository()

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        return {
            "enabled": settings.enabled,
            "server": settings.server,
            "port": settings.port,
            "protocol": settings.protocol
        }

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.repository.get(db)

        if data.enabled is not None:
            settings.enabled = data.enabled

        if data.server is not None:
            settings.server = data.server

        if data.port is not None:
            settings.port = data.port

        if data.protocol is not None:
            settings.protocol = data.protocol

        self.repository.save(db, settings)

        return self.get_settings(db)

    def _emit(
        self,
        settings,
        message: str
    ) -> None:

        payload = (message + "\n").encode("utf-8", "replace")

        if settings.protocol == "tcp":

            with socket.create_connection(
                (settings.server, settings.port),
                timeout=5
            ) as sock:

                sock.sendall(payload)

        else:

            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

            try:

                sock.sendto(
                    payload,
                    (settings.server, settings.port)
                )

            finally:

                sock.close()

    def forward(
        self,
        db: Session,
        action: str,
        resource: str,
        user_id: int | None,
        description: str
    ):

        settings = self.repository.get(db)

        if not settings.enabled or not settings.server:

            return

        message = (
            f'STEPAD_NSP action="{action}" '
            f'resource="{resource}" '
            f"user_id={user_id or '-'} "
            f'description="{description}"'
        )

        try:

            self._emit(settings, message)

        except Exception as error:

            logger.warning(
                f"Syslog forward failed: {error}"
            )

    def forward_ips_alert(
        self,
        db: Session,
        event: dict,
        severity: str,
    ) -> None:

        settings = self.repository.get(db)

        if not settings.enabled or not settings.server:

            return

        alert = event.get("alert", {})

        signature = alert.get("signature", "")

        category = alert.get("category", "")

        src_ip = event.get("src_ip", "")

        dst_ip = event.get("dest_ip", "")

        dst_port = event.get("dest_port", "")

        sid = alert.get("signature_id", "")

        message = (
            f'CEF:0|STEPAD|NSP|1.0|{sid}|{signature}|'
            f'{self._cef_severity(severity)}|'
            f'src={src_ip} dst={dst_ip} dpt={dst_port} '
            f'cat={category} cs1Label=SuricataCategory cs1={category}'
        )

        try:

            self._emit(settings, message)

        except Exception as error:

            logger.warning(
                f"Syslog IPS forward failed: {error}"
            )

    @staticmethod
    def _cef_severity(severity: str) -> int:

        mapping = {
            "critical": 10,
            "warning": 6,
            "info": 3,
        }

        return mapping.get(severity, 3)

    def test(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        if not settings.server:

            return {
                "success": False,
                "message": "Syslog server not configured"
            }

        try:

            self._emit(
                settings,
                "STEPAD_NSP test=" + settings.protocol
            )

            return {
                "success": True,
                "message": (
                    f"Test message sent to "
                    f"{settings.server}:{settings.port}"
                )
            }

        except Exception as error:

            return {
                "success": False,
                "message": f"Syslog error: {error}"
            }
