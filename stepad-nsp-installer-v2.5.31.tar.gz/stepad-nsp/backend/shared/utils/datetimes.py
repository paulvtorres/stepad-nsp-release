from datetime import datetime, timezone


def local_to_utc(value):
    """
    Convierte un datetime "naive" (hora local del servidor, como lo
    envia el frontend en los filtros de fecha, ej. "2026-08-15T23:59:59")
    a UTC naive para consultar los logs (que se guardan en UTC).

    Sin esta conversion, el backend interpretaba esas fechas como UTC y
    (siendo el servidor UTC-5) cortaba la actividad a partir de las 19h
    local. Aplicar esta conversion en TODOS los filtros de fecha evita
    el problema de una vez.
    """
    if value is None:
        return None
    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    local_tz = datetime.now().astimezone().tzinfo
    return (
        value.replace(tzinfo=local_tz)
        .astimezone(timezone.utc)
        .replace(tzinfo=None)
    )


def utc_to_local(value):
    """
    UTC naive (como se guardan los logs) -> hora local del servidor
    (naive), para mostrar en reportes/Excel.
    """
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone().replace(tzinfo=None)
