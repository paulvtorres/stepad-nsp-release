class DnsEngine:
    """
    Supported DNS blocking/resolution backends.

    Adding a new engine: implement DnsProviderInterface, register it in
    backend.dns.factory.get_dns_provider(), and extend
    DnsmasqDnsSectionBuilder if dnsmasq's role changes for that engine.
    """

    DNSMASQ = "dnsmasq"

    POWERDNS_RPZ = "powerdns_rpz"

    @classmethod
    def is_delegated(cls, engine: str) -> bool:
        """True when dnsmasq must NOT answer DNS (another engine does)."""

        return engine != cls.DNSMASQ
