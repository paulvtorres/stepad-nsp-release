from unittest.mock import MagicMock, patch

from backend.network.services.network_live_apply_service import (
    NetworkLiveApplyService,
)


def test_apply_lan_change_skips_when_no_interface():
    result = NetworkLiveApplyService().apply_lan_change(None)

    assert result["skipped"] is True


@patch("backend.dns.factory.get_dns_provider")
@patch("backend.dhcp.services.dhcp_service.DhcpService")
@patch(
    "backend.network.configuration.services."
    "interface_configuration_service.InterfaceConfigurationService"
)
def test_apply_lan_change_runs_all_steps(
    mock_lan_service,
    mock_dhcp_service,
    mock_get_dns_provider,
):
    mock_get_dns_provider.return_value = MagicMock(
        ensure_listen_address=MagicMock(return_value={"success": True})
    )
    mock_dhcp_service.return_value.apply_config.return_value = {
        "success": True
    }
    mock_lan_service.return_value.configure_lan.return_value = {
        "success": True
    }

    result = NetworkLiveApplyService().apply_lan_change("eth0")

    assert result["interface"] == "eth0"
    mock_lan_service.return_value.configure_lan.assert_called_once()
    mock_dhcp_service.return_value.apply_config.assert_called_once()
    mock_get_dns_provider.return_value.ensure_listen_address.assert_called_once()


@patch("backend.nat.services.nat_service.NatService")
def test_apply_wan_change_syncs_nat(mock_nat_service):
    mock_nat_service.return_value.enable_default_nat.return_value = {
        "forwarding": {"success": True},
        "nat": {"success": True},
    }

    result = NetworkLiveApplyService().apply_wan_change("eth1")

    assert result["interface"] == "eth1"
    mock_nat_service.return_value.enable_default_nat.assert_called_once()
