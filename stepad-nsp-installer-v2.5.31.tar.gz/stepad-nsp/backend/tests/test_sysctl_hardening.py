from backend.network.security.sysctl_hardening import (
    STEPAD_SYSCTL,
    build_sysctl_content,
)


def test_build_sysctl_content_includes_hardening_keys():
    content = build_sysctl_content()

    for key in (
        "net.ipv4.conf.all.rp_filter",
        "net.ipv4.tcp_syncookies",
        "net.ipv4.conf.all.accept_redirects",
    ):
        assert f"{key}=1" in content or f"{key}=0" in content


def test_build_sysctl_content_always_enables_forwarding():
    content = build_sysctl_content()

    assert "net.ipv4.ip_forward=1" in content


def test_stepad_sysctl_has_no_empty_values():
    assert all(value for value in STEPAD_SYSCTL.values())
