import ipaddress
from unittest.mock import patch

from backend.network.services.lan_scope_service import LanScopeService


@patch.object(
    LanScopeService,
    "lan_interface_names",
    return_value={"enx0"},
)
@patch.object(
    LanScopeService,
    "lan_networks",
    return_value=[ipaddress.ip_network("192.168.1.0/24")],
)
@patch.object(
    LanScopeService,
    "wan_interface_names",
    return_value={"enp0"},
)
def test_is_discoverable_only_lan_neighbors(
    _wan,
    _networks,
    _interfaces,
):

    scope = LanScopeService()

    assert scope.is_discoverable("192.168.1.10", "enx0")

    assert not scope.is_discoverable("192.168.1.10", "enp0")

    assert not scope.is_discoverable("8.8.8.8", "enx0")

    assert not scope.is_discoverable("192.168.100.5", "enx0")


@patch.object(
    LanScopeService,
    "lan_interface_names",
    return_value={"enx0"},
)
@patch.object(
    LanScopeService,
    "lan_networks",
    return_value=[ipaddress.ip_network("192.168.60.0/24")],
)
@patch.object(
    LanScopeService,
    "wan_interface_names",
    return_value={"enp0"},
)
def test_belongs_to_lan_keeps_stale_ip_on_lan_interface(
    _wan,
    _networks,
    _interfaces,
):

    scope = LanScopeService()

    assert scope.belongs_to_lan("192.168.60.20", "enx0")

    assert scope.belongs_to_lan("192.168.1.118", "enx0")

    assert not scope.belongs_to_lan("192.168.100.50", "enp0")

    assert not scope.belongs_to_lan("192.168.100.50", None)
