import os

import pytest


@pytest.fixture(scope="session", autouse=True)
def test_environment():
    """
    Force development mode so Settings does not require production
    secrets when test modules import backend packages.
    """

    os.environ.setdefault("STEPAD_ENV", "development")
    os.environ.setdefault("DB_PASSWORD", "test")
    os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")
