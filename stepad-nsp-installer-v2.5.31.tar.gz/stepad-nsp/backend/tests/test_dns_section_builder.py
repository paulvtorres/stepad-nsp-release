import pytest


def test_integrated_mode_uses_upstream_and_blocklist(monkeypatch):
    from backend.dhcp.dnsmasq import dns_section_builder

    monkeypatch.setattr(
        dns_section_builder.Settings,
        "DNS_ENGINE",
        "dnsmasq",
    )

    section = dns_section_builder.DnsmasqDnsSectionBuilder.build()

    assert "server=1.1.1.1" in section
    assert "server=8.8.8.8" in section
    assert "conf-file=" in section
    assert "port=0" not in section


def test_delegated_mode_disables_dnsmasq_dns(monkeypatch):
    from backend.dhcp.dnsmasq import dns_section_builder

    monkeypatch.setattr(
        dns_section_builder.Settings,
        "DNS_ENGINE",
        "powerdns_rpz",
    )

    section = dns_section_builder.DnsmasqDnsSectionBuilder.build()

    assert "port=0" in section
    assert "powerdns_rpz" in section
    assert "server=" not in section


def test_dns_engine_is_delegated():
    from backend.shared.enums.dns_engine import DnsEngine

    assert DnsEngine.is_delegated(DnsEngine.POWERDNS_RPZ) is True
    assert DnsEngine.is_delegated(DnsEngine.DNSMASQ) is False
