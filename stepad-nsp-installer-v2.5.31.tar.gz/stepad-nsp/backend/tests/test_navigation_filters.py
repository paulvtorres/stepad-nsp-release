from backend.dns.logging.navigation_filters import (
    is_effective_navigation_domain,
)


def test_accepts_real_sites():

    assert is_effective_navigation_domain("www.youtube.com")
    assert is_effective_navigation_domain("facebook.com.")
    assert is_effective_navigation_domain("Wikipedia.org")


def test_rejects_noise():

    assert not is_effective_navigation_domain("localhost")
    assert not is_effective_navigation_domain("_ldap._tcp.local")
    assert not is_effective_navigation_domain("connectivitycheck.gstatic.com")
    assert not is_effective_navigation_domain("msftconnecttest.com")
    assert not is_effective_navigation_domain("1.2.3.4.in-addr.arpa")
    assert not is_effective_navigation_domain("clients4.google.com")
    assert not is_effective_navigation_domain("")
