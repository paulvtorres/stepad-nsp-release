"""
Proactive IP threat intelligence blocklists (Feodo Tracker, Spamhaus DROP).

Complements reactive C2 blocking (IPs seen in Suricata alerts) with
known-bad networks updated from public feeds.
"""

import ipaddress
import subprocess
import urllib.request

from backend.shared.logging.logger import logger


NFT_BIN = "/usr/sbin/nft"

FEODO_BLOCKLIST = (
    "https://feodotracker.abuse.ch/downloads/ipblocklist.txt"
)

SPAMHAUS_DROP = "https://www.spamhaus.org/drop/drop.txt"

SET_NAME = "threat_intel_v4"
WAN_SET = "stepad_wan_ifaces"
RULE_COMMENT = "stepad-threat-intel"


class ThreatIntelService:

    MAX_ENTRIES = 5000

    def _fetch(self, url: str) -> str:

        request = urllib.request.Request(
            url,
            headers={"User-Agent": "STEPAD-NSP/1.0"},
        )

        with urllib.request.urlopen(request, timeout=30) as response:

            return response.read().decode("utf-8", errors="ignore")

    def _parse_feodo(self, text: str) -> set[str]:

        entries = set()

        for line in text.splitlines():

            line = line.strip()

            if not line or line.startswith("#"):

                continue

            if line.startswith("127.0.0.1"):

                continue

            try:

                ipaddress.ip_network(line, strict=False)

                entries.add(line)

            except ValueError:

                continue

        return entries

    def _parse_spamhaus_drop(self, text: str) -> set[str]:

        entries = set()

        for line in text.splitlines():

            line = line.strip()

            if not line or line.startswith(";"):

                continue

            token = line.split(";", 1)[0].strip()

            try:

                network = ipaddress.ip_network(token, strict=False)

                if network.version != 4:

                    continue

                entries.add(str(network))

            except ValueError:

                continue

        return entries

    def fetch_blocklist(self) -> dict:

        feodo = self._parse_feodo(self._fetch(FEODO_BLOCKLIST))

        drop = self._parse_spamhaus_drop(self._fetch(SPAMHAUS_DROP))

        combined = sorted(feodo | drop)[: self.MAX_ENTRIES]

        return {
            "feodo_count": len(feodo),
            "spamhaus_count": len(drop),
            "entries": combined,
            "total": len(combined),
        }

    def _run(self, command: list[str]) -> dict:

        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
        )

        return {
            "success": result.returncode == 0,
            "stderr": result.stderr.strip(),
        }

    def sync(self, wan_interfaces: list[str] | None = None) -> dict:

        if wan_interfaces is None:

            from backend.network.interfaces.services.interface_service import (
                InterfaceService,
            )

            wan_interfaces = [
                interface.name
                for interface in InterfaceService().get_wan_interfaces()
            ]

        if not wan_interfaces:

            return {
                "success": False,
                "error": "No WAN interface assigned",
            }

        try:

            blocklist = self.fetch_blocklist()

        except Exception as error:

            logger.error(f"Threat intel fetch failed: {error}")

            return {"success": False, "error": str(error)}

        entries = blocklist["entries"]

        self._run([NFT_BIN, "add", "table", "inet", "stepad"])
        self._run([NFT_BIN, "add", "chain", "inet", "stepad", "forward"])
        self._run([
            NFT_BIN, "add", "set", "inet", "stepad", SET_NAME,
            "{", "type", "ipv4_addr", ";", "flags", "interval", ";", "}",
        ])
        self._run([
            NFT_BIN, "add", "set", "inet", "stepad", WAN_SET,
            "{", "type", "ifname", ";", "}",
        ])

        self._run([NFT_BIN, "flush", "set", "inet", "stepad", SET_NAME])
        self._run([NFT_BIN, "flush", "set", "inet", "stepad", WAN_SET])

        wan_elements = ", ".join(wan_interfaces)

        self._run([
            NFT_BIN, "add", "element", "inet", "stepad", WAN_SET,
            "{", wan_elements, "}",
        ])

        if entries:

            # nft has argument length limits — batch in chunks.
            chunk_size = 200

            for index in range(0, len(entries), chunk_size):

                chunk = entries[index:index + chunk_size]

                elements = ", ".join(chunk)

                self._run([
                    NFT_BIN, "add", "element", "inet", "stepad", SET_NAME,
                    "{", elements, "}",
                ])

        # Replace existing TI rule (idempotent).
        list_result = subprocess.run(
            [NFT_BIN, "-a", "list", "chain", "inet", "stepad", "forward"],
            capture_output=True,
            text=True,
        )

        for line in list_result.stdout.splitlines():

            if RULE_COMMENT not in line or "handle" not in line:

                continue

            handle = line.split("handle")[1].strip().split()[0]

            self._run([
                NFT_BIN, "delete", "rule", "inet", "stepad", "forward",
                "handle", handle,
            ])

        if entries:

            rule_result = self._run([
                NFT_BIN, "add", "rule", "inet", "stepad", "forward",
                "iifname", "!=", f"@{WAN_SET}",
                "ip", "daddr", f"@{SET_NAME}",
                "counter", "drop",
                "comment", RULE_COMMENT,
            ])

        else:

            rule_result = {"success": True}

        logger.info(
            f"Threat intel synced: {blocklist['total']} entries "
            f"(Feodo={blocklist['feodo_count']}, "
            f"Spamhaus={blocklist['spamhaus_count']})"
        )

        return {
            "success": rule_result.get("success", False),
            "total": blocklist["total"],
            "feodo_count": blocklist["feodo_count"],
            "spamhaus_count": blocklist["spamhaus_count"],
        }


threat_intel_service = ThreatIntelService()
