import subprocess
import threading

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import (
    ComponentCriticality
)

from backend.ips.services.suricata_alert_ingest import (
    SuricataAlertIngest
)

from backend.dns.logging.services.sni_log_ingest import (
    sni_log_ingest
)

from backend.ips.services.threat_response_service import (
    threat_response_service
)

from backend.ips.services.threat_intel_service import (
    threat_intel_service,
)

from backend.core.database.session import SessionLocal

from backend.system.services.module_service import ModuleService

from backend.shared.logging.logger import logger


class IpsComponent(BaseComponent):


    name = "ips"

    criticality = ComponentCriticality.OPTIONAL


    def __init__(self):

        self.ingest = SuricataAlertIngest()


    def start(self):

        self._ensure_suricata_if_enabled()

        self._thread = threading.Thread(
            target=self.ingest.run_forever,
            daemon=True,
            name="suricata-alert-ingest"
        )

        self._thread.start()

        # Registro de conexiones HTTPS por dominio (SNI): cada handshake
        # TLS de un equipo deja el dominio exacto al que se conecta.
        self._sni_thread = threading.Thread(
            target=sni_log_ingest.run_forever,
            daemon=True,
            name="suricata-sni-ingest"
        )

        self._sni_thread.start()

        try:

            threat_response_service.sync_c2_rules()

        except Exception as error:

            logger.exception(
                "Fallo la sincronizacion de bloqueos C2 al arrancar: %s",
                error
            )

        try:

            threat_intel_service.sync()

        except Exception as error:

            logger.exception(
                "Fallo la sincronizacion de threat intel al arrancar: %s",
                error
            )

        logger.info(
            "IpsComponent iniciado (alertas Suricata + SNI)."
        )


    def _ensure_suricata_if_enabled(self):

        db = SessionLocal()

        try:

            modules = ModuleService().get_modules(db)

            ips = next(
                module for module in modules
                if module["key"] == "ips"
            )

            if not ips["enabled"]:

                return

            result = subprocess.run(
                ["systemctl", "enable", "--now", "suricata.service"],
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:

                logger.warning(
                    "No pude arrancar Suricata: %s",
                    result.stderr.strip(),
                )

        except Exception as error:

            logger.warning(
                "Fallo al verificar Suricata: %s",
                error,
            )

        finally:

            db.close()


    def stop(self):

        logger.info(
            "IpsComponent detenido."
        )
