"""ips fail-closed NFQUEUE toggle

Revision ID: 0004
Revises: 0003
Create Date: 2026-08-20 20:45:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "threat_response_settings",
        sa.Column(
            "ips_fail_closed",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )


def downgrade() -> None:
    op.drop_column("threat_response_settings", "ips_fail_closed")
