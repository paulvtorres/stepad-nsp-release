"""security dns alerts (mining/malware) settings

Revision ID: 0011
Revises: 0010
Create Date: 2026-08-22 14:10:00.000000

Agrega la configuracion de la nueva alerta prioritaria de seguridad:
cuando un equipo intenta contactar un pool de mineria de criptomonedas
o un dominio del feed de malware/phishing, se envia un correo
inmediato (con script de limpieza adjunto) ademas de la alerta critica
en el panel. Se guarda como toggle + lista de destinatarios propia,
separada del reporte periodico, para que el equipo de seguridad/TI la
pueda recibir aunque el reporte general este desactivado.
"""
from alembic import op
import sqlalchemy as sa


revision = "0011"
down_revision = "0010"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "notification_settings",
        sa.Column(
            "security_dns_alert_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "security_dns_alert_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )


def downgrade() -> None:
    op.drop_column("notification_settings", "security_dns_alert_emails")
    op.drop_column("notification_settings", "security_dns_alert_enabled")
