from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect, text


revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def upgrade() -> None:

    bind = op.get_bind()

    inspector = inspect(bind)

    tables = inspector.get_table_names()

    if "email_settings" not in tables:

        op.create_table(
            "email_settings",
            sa.Column("id", sa.Integer(), nullable=False),
            sa.Column(
                "provider",
                sa.String(length=32),
                nullable=False,
                server_default="custom",
            ),
            sa.Column(
                "smtp_host",
                sa.String(length=255),
                nullable=False,
                server_default="",
            ),
            sa.Column(
                "smtp_port",
                sa.Integer(),
                nullable=False,
                server_default="587",
            ),
            sa.Column("smtp_user", sa.String(length=255), nullable=True),
            sa.Column("smtp_password", sa.String(length=255), nullable=True),
            sa.Column(
                "from_email",
                sa.String(length=255),
                nullable=False,
                server_default="",
            ),
            sa.Column("updated_at", sa.DateTime(), nullable=True),
            sa.PrimaryKeyConstraint("id"),
        )

    else:

        columns = {
            column["name"]
            for column in inspector.get_columns("email_settings")
        }

        if "provider" not in columns:

            op.add_column(
                "email_settings",
                sa.Column(
                    "provider",
                    sa.String(length=32),
                    nullable=False,
                    server_default="custom",
                ),
            )

    bind.execute(
        text(
            """
            INSERT INTO email_settings (
                id, provider, smtp_host, smtp_port,
                smtp_user, smtp_password, from_email
            )
            SELECT
                1,
                CASE
                    WHEN LOWER(COALESCE(ns.smtp_host, '')) = 'smtp.gmail.com'
                        THEN 'gmail'
                    WHEN LOWER(COALESCE(ns.smtp_host, '')) = 'smtp-mail.outlook.com'
                        THEN 'outlook'
                    WHEN LOWER(COALESCE(ns.smtp_host, '')) = 'smtp.office365.com'
                        THEN 'office365'
                    WHEN LOWER(COALESCE(ns.smtp_host, '')) = 'smtp.mail.yahoo.com'
                        THEN 'yahoo'
                    ELSE 'custom'
                END,
                COALESCE(ns.smtp_host, ''),
                COALESCE(ns.smtp_port, 587),
                ns.smtp_user,
                ns.smtp_password,
                COALESCE(ns.from_email, '')
            FROM notification_settings ns
            WHERE ns.id = 1
              AND NOT EXISTS (
                  SELECT 1 FROM email_settings es WHERE es.id = 1
              )
            """
        )
    )

    bind.execute(
        text(
            """
            INSERT INTO email_settings (
                id, provider, smtp_host, smtp_port,
                smtp_user, smtp_password, from_email
            )
            VALUES (1, 'custom', '', 587, NULL, NULL, '')
            ON CONFLICT (id) DO NOTHING
            """
        )
    )


def downgrade() -> None:

    pass
