"""Conexiones HTTPS por dominio (SNI)

Revision ID: 0003
Revises: 0002
Create Date: 2026-08-16 05:00:00.000000

Registro de navegacion por SNI (dominio en claro del handshake TLS):
cada conexion HTTPS de un equipo queda asociada al dominio exacto al
que se conecta, de forma continua (no solo al resolver DNS). Complementa
a dns_query_logs para saber en que estan navegando en tiempo real.

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0003'
down_revision = '0002'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('sni_logs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('device_id', sa.Integer(), nullable=True),
    sa.Column('src_ip', sa.String(length=64), nullable=False),
    sa.Column('domain', sa.String(length=255), nullable=False),
    sa.Column('dest_ip', sa.String(length=64), nullable=True),
    sa.Column('dest_port', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(
        op.f('ix_sni_logs_created_at'),
        'sni_logs',
        ['created_at'],
        unique=False
    )


def downgrade() -> None:
    op.drop_index(
        op.f('ix_sni_logs_created_at'),
        table_name='sni_logs'
    )
    op.drop_table('sni_logs')
