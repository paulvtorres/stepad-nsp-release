"""Add BCC and per-report recipient fields for email delivery."""

from alembic import op
import sqlalchemy as sa


revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None


def upgrade() -> None:

    op.add_column(
        "notification_settings",
        sa.Column(
            "bcc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )

    op.add_column(
        "backup_settings",
        sa.Column(
            "to_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )

    op.add_column(
        "backup_settings",
        sa.Column(
            "bcc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )


def downgrade() -> None:

    op.drop_column("backup_settings", "bcc_emails")
    op.drop_column("backup_settings", "to_emails")
    op.drop_column("notification_settings", "bcc_emails")
