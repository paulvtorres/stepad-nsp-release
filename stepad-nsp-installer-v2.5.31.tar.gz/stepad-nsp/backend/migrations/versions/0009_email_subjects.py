"""Configurable professional email subjects for reports and alerts."""

from alembic import op
import sqlalchemy as sa


revision = "0009"
down_revision = "0008"
branch_labels = None
depends_on = None


def upgrade() -> None:

    op.add_column(
        "notification_settings",
        sa.Column(
            "report_subject",
            sa.String(length=255),
            nullable=False,
            server_default="",
        ),
    )

    op.add_column(
        "notification_settings",
        sa.Column(
            "alert_subject",
            sa.String(length=255),
            nullable=False,
            server_default="",
        ),
    )

    op.add_column(
        "backup_settings",
        sa.Column(
            "email_subject",
            sa.String(length=255),
            nullable=False,
            server_default="",
        ),
    )


def downgrade() -> None:

    op.drop_column("backup_settings", "email_subject")
    op.drop_column("notification_settings", "alert_subject")
    op.drop_column("notification_settings", "report_subject")
