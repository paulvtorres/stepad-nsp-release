"""email_settings table and migrate SMTP from notification_settings

Revision ID: 0006
Revises: 0005
Create Date: 2026-08-21 23:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade() -> None:

    op.create_table(
        "email_settings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("provider", sa.String(length=32), nullable=False),
        sa.Column("smtp_host", sa.String(length=255), nullable=False),
        sa.Column("smtp_port", sa.Integer(), nullable=False),
        sa.Column("smtp_user", sa.String(length=255), nullable=True),
        sa.Column("smtp_password", sa.String(length=255), nullable=True),
        sa.Column("from_email", sa.String(length=255), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )

    op.execute(
        """
        INSERT INTO email_settings (
            id, provider, smtp_host, smtp_port,
            smtp_user, smtp_password, from_email, updated_at
        )
        SELECT
            1,
            CASE
                WHEN LOWER(smtp_host) = 'smtp.gmail.com' THEN 'gmail'
                WHEN LOWER(smtp_host) = 'smtp-mail.outlook.com' THEN 'outlook'
                WHEN LOWER(smtp_host) = 'smtp.office365.com' THEN 'office365'
                WHEN LOWER(smtp_host) = 'smtp.mail.yahoo.com' THEN 'yahoo'
                ELSE 'custom'
            END,
            COALESCE(smtp_host, ''),
            COALESCE(smtp_port, 587),
            smtp_user,
            smtp_password,
            COALESCE(from_email, ''),
            updated_at
        FROM notification_settings
        WHERE id = 1
        """
    )

    op.execute(
        """
        INSERT INTO email_settings (
            id, provider, smtp_host, smtp_port,
            smtp_user, smtp_password, from_email
        )
        SELECT 1, 'custom', '', 587, NULL, NULL, ''
        WHERE NOT EXISTS (SELECT 1 FROM email_settings WHERE id = 1)
        """
    )


def downgrade() -> None:

    op.drop_table("email_settings")
