"""indexes for the devices listing (linked_to_id, group_devices.device_id)

Revision ID: 0010
Revises: 0009
Create Date: 2026-08-22 10:50:00.000000

El listado de equipos filtra por network_devices.linked_to_id (equipos
de nivel superior y sus NICs vinculadas) y group_devices.device_id
(grupo de cada equipo) en cada peticion -- sin indice, esas consultas
escanean toda la tabla a medida que crece el inventario.
"""
from alembic import op


revision = "0010"
down_revision = "0009"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_index(
        "ix_network_devices_linked_to_id",
        "network_devices",
        ["linked_to_id"],
        unique=False,
    )
    op.create_index(
        "ix_group_devices_device_id",
        "group_devices",
        ["device_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "ix_group_devices_device_id",
        table_name="group_devices",
    )
    op.drop_index(
        "ix_network_devices_linked_to_id",
        table_name="network_devices",
    )
