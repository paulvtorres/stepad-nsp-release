"""cc/bcc for the security dns alert (mining/malware) section

Revision ID: 0012
Revises: 0011
Create Date: 2026-08-22 14:55:00.000000

La seccion "Alertas de seguridad (DNS)" solo tenia un campo de
destinatarios ("Para"). Se agregan CC (copia visible) y CCO (copia
oculta) propios de esta alerta, igual que un correo normal.
"""
from alembic import op
import sqlalchemy as sa


revision = "0012"
down_revision = "0011"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "notification_settings",
        sa.Column(
            "security_dns_alert_cc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "security_dns_alert_bcc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )


def downgrade() -> None:
    op.drop_column("notification_settings", "security_dns_alert_bcc_emails")
    op.drop_column("notification_settings", "security_dns_alert_cc_emails")
