"""index on queried_at for navigation date-range reports

Revision ID: 0005
Revises: 0004
Create Date: 2026-08-21 12:45:00.000000

"""
from alembic import op


revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_index(
        "ix_dns_query_logs_queried_at",
        "dns_query_logs",
        ["queried_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "ix_dns_query_logs_queried_at",
        table_name="dns_query_logs",
    )
