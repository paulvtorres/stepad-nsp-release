"""
Kernel network hardening applied on every NAT bootstrap.

Centralizes sysctl tuning so routing (ip_forward) and anti-spoofing
live in one idempotent file under /etc/sysctl.d/.
"""

from pathlib import Path

import subprocess

from backend.shared.logging.logger import logger


SYSCTL_FILE = Path("/etc/sysctl.d/99-stepad.conf")

# Keys STEPAD owns outright — rewritten on each apply.
STEPAD_SYSCTL = {
    "net.ipv4.ip_forward": "1",
    "net.ipv4.conf.all.rp_filter": "1",
    "net.ipv4.conf.default.rp_filter": "1",
    "net.ipv4.conf.all.accept_redirects": "0",
    "net.ipv4.conf.default.accept_redirects": "0",
    "net.ipv4.conf.all.send_redirects": "0",
    "net.ipv4.conf.default.send_redirects": "0",
    "net.ipv4.conf.all.accept_source_route": "0",
    "net.ipv4.conf.default.accept_source_route": "0",
    "net.ipv4.tcp_syncookies": "1",
    "net.ipv4.conf.all.log_martians": "1",
    "net.ipv6.conf.all.forwarding": "0",
    "net.ipv6.conf.default.forwarding": "0",
}


def build_sysctl_content(extra: dict[str, str] | None = None) -> str:
    settings = dict(STEPAD_SYSCTL)

    if extra:

        settings.update(extra)

    lines = [
        "# Managed by STEPAD NSP — do not edit by hand.",
        "",
    ]

    for key in sorted(settings):

        lines.append(f"{key}={settings[key]}")

    lines.append("")

    return "\n".join(lines)


def apply_sysctl_hardening() -> dict:
    """
    Persist and live-apply kernel network hardening.
    Idempotent: safe to call on every boot and WAN/LAN change.
    """

    content = build_sysctl_content()

    write_result = {"success": True, "path": str(SYSCTL_FILE)}

    try:

        SYSCTL_FILE.parent.mkdir(parents=True, exist_ok=True)

        SYSCTL_FILE.write_text(content)

    except OSError as error:

        logger.error(f"Could not write {SYSCTL_FILE}: {error}")

        write_result = {"success": False, "error": str(error)}

    apply_result = subprocess.run(
        ["/usr/sbin/sysctl", "--system"],
        capture_output=True,
        text=True,
    )

    if apply_result.returncode != 0:

        logger.warning(
            "sysctl --system failed after writing hardening file: "
            f"{apply_result.stderr.strip()}"
        )

    # Belt-and-braces: ensure ip_forward is on even if --system skipped us.
    forward_result = subprocess.run(
        ["/usr/sbin/sysctl", "-w", "net.ipv4.ip_forward=1"],
        capture_output=True,
        text=True,
    )

    return {
        "success": (
            write_result.get("success", False)
            and forward_result.returncode == 0
        ),
        "file": write_result,
        "sysctl_system": {
            "success": apply_result.returncode == 0,
            "output": apply_result.stdout.strip(),
            "error": apply_result.stderr.strip(),
        },
        "forwarding": {
            "success": forward_result.returncode == 0,
            "output": forward_result.stdout.strip(),
        },
    }
