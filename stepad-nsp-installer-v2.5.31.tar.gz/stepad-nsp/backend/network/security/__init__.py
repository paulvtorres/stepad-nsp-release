"""Kernel-level network hardening for the STEPAD appliance."""
