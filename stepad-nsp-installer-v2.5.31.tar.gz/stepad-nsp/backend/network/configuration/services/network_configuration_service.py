import ipaddress

from backend.infrastructure.network.adapters.linux.linux_interface_provider import (
    LinuxInterfaceProvider
)

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)


class NetworkConfigurationService:


    def __init__(self):

        self.provider = LinuxInterfaceProvider()

        self.interface_service = InterfaceService()



    def get_interface_info(
        self,
        interface_name: str,
        deep: bool = True
    ):

        interfaces = self.provider.list_interfaces(deep=deep)

        for interface in interfaces:

            if interface.name == interface_name:

                network = None

                if interface.ipv4_address:

                    network = str(

                        ipaddress.ip_network(

                            f"{interface.ipv4_address}/{interface.subnet_mask}",

                            strict=False

                        )

                    )

                return {

                    "interface": interface.name,

                    "ip": interface.ipv4_address,

                    "mac": interface.mac_address,

                    "network": network,

                    "status": interface.status

                }

        return None



    def _get_configurations_for_role(
        self,
        role: str,
        deep: bool = True
    ):
        """
        Every live interface carrying `role`, in registry priority
        order -- the multi-interface view. The registry (by MAC, via
        InterfaceService) is the single source of truth for "which
        physical card has this role" -- NEVER config.yaml's raw
        interface name directly.

        Without this, a card that the registry correctly still shows
        as unassigned could keep getting treated as LAN/WAN here
        anyway, because config.yaml can hold a name left over from
        before the registry existed (or from a previous machine) that
        this function used to trust blindly. That's exactly what let
        device discovery keep ARP-scanning a card the admin hadn't
        assigned yet.
        """

        interfaces = self.interface_service.list_interfaces(deep=deep)

        matches = sorted(
            (
                interface
                for interface in interfaces
                if interface.role == role
            ),
            key=lambda interface: interface.priority
        )

        results = []

        for match in matches:

            info = self.get_interface_info(match.name, deep=deep)

            if info:

                results.append(info)

        return results


    def get_lan_configurations(self, deep: bool = False):

        # deep=False por defecto: esto se llama constantemente (una
        # vez por dispositivo en el listado, en cada escaneo, en DNS
        # por zona, etc.) y solo necesita la IP/subred de cada
        # interfaz LAN, no su estado de "carrier" en vivo. Con
        # deep=True cada llamada hace "ip link set <nic> up" +
        # sleep(2) por cada NIC fisica detectada (pensado para la
        # pantalla de interfaces, que si necesita ese detalle) -- eso
        # multiplicado por N dispositivos es lo que colgaba el
        # listado (visto en produccion: 57 equipos x ~2s = +100s).
        return self._get_configurations_for_role("LAN", deep=deep)


    def get_wan_configurations(self, deep: bool = False):

        return self._get_configurations_for_role("WAN", deep=deep)


    def _get_configuration_for_role(
        self,
        role: str
    ):
        """
        The PRIMARY interface for a role (lowest registry priority) --
        the single-LAN/WAN view. Kept for consumers that are only ever
        about one segment (e.g. the simple-mode DHCP config); anything
        that must cover every uplink/subnet should use the plural
        getters above instead.
        """

        configurations = self._get_configurations_for_role(role)

        return configurations[0] if configurations else None


    def get_lan_configuration(self):

        return self._get_configuration_for_role("LAN")


    def get_wan_configuration(self):

        return self._get_configuration_for_role("WAN")