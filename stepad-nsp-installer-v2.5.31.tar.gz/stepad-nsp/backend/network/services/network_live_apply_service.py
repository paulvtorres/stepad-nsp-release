"""
Re-applies network services when interface roles change at runtime.

Centralizes the live-apply logic that used to be scattered inside
InterfaceRegistryService._sync_config_cache so every role change
(LAN or WAN) follows the same, testable path.
"""

from backend.shared.logging.logger import logger


class NetworkLiveApplyService:
    """
    Applies DHCP, DNS listen addresses, and NAT after the interface
    registry updates config.yaml. Safe to call when a role is cleared
    (no interface assigned): each step no-ops gracefully.
    """

    def apply_lan_change(self, lan_interface_name: str | None) -> dict:
        """
        LAN assigned or moved to another NIC: reconfigure the gateway
        IP, restart dnsmasq, sync delegated DNS listen addresses.
        """

        if not lan_interface_name:

            logger.info(
                "LAN live-apply skipped: no LAN interface assigned."
            )

            return {"skipped": True, "reason": "no_lan"}

        from backend.network.configuration.services.interface_configuration_service import (
            InterfaceConfigurationService,
        )

        from backend.dhcp.services.dhcp_service import DhcpService

        from backend.dns.factory import get_dns_provider

        lan_result = InterfaceConfigurationService().configure_lan()

        dhcp_result = DhcpService().apply_config()

        dns_result = self._sync_delegated_dns_listen()

        logger.info(
            "LAN live-apply complete "
            f"(interface={lan_interface_name!r}): "
            f"lan={lan_result}, dhcp={dhcp_result}, dns={dns_result}"
        )

        return {
            "interface": lan_interface_name,
            "lan": lan_result,
            "dhcp": dhcp_result,
            "dns": dns_result,
        }

    def apply_wan_change(self, wan_interface_name: str | None) -> dict:
        """
        WAN assigned or moved: re-sync masquerade rules for all active
        WAN interfaces (multi-WAN aware via NatService).
        """

        from backend.nat.services.nat_service import NatService

        if not wan_interface_name:

            logger.warning(
                "WAN live-apply: no WAN assigned — clearing is handled "
                "by NatService when get_wan_interfaces() is empty."
            )

        nat_result = NatService().enable_default_nat()

        logger.info(
            "WAN live-apply complete "
            f"(primary={wan_interface_name!r}): nat={nat_result}"
        )

        return {
            "interface": wan_interface_name,
            "nat": nat_result,
        }

    def _sync_delegated_dns_listen(self) -> dict | None:
        from backend.dns.factory import get_dns_provider

        provider = get_dns_provider()

        if not hasattr(provider, "ensure_listen_address"):

            return None

        return provider.ensure_listen_address()
