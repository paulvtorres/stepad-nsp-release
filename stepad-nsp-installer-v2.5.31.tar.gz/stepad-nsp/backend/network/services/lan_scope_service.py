"""
LAN scope helpers.

The NSP only manages clients on configured LAN segments. WAN-side
neighbors, upstream routers, and foreign ARP entries must never be
discovered, scanned, or listed as network devices.
"""

import ipaddress
import time

from backend.network.configuration.services.network_configuration_service import (
    NetworkConfigurationService,
)


# TTL corto: algunos consumidores (DeviceDiscoveryService) guardan UNA
# instancia de LanScopeService durante toda la vida del proceso, asi
# que un cache permanente dejaria la config LAN/WAN "congelada" desde
# el primer arranque -- si el admin cambia de interfaz nunca se
# notaria sin reiniciar. Con un TTL corto, el listado de dispositivos
# (que reusa una sola instancia para los N equipos de una peticion,
# todo en milisegundos) igual se beneficia del cache, mientras que
# el escaneo periodico (separado por minutos) siempre lee de nuevo.
_CACHE_TTL_SECONDS = 5


class LanScopeService:

    def __init__(self):

        self.network_configuration = NetworkConfigurationService()

        self._lan_cache = None
        self._lan_cache_at = 0.0

        self._wan_cache = None
        self._wan_cache_at = 0.0

    def lan_configurations(self) -> list[dict]:

        now = time.monotonic()

        if (
            self._lan_cache is None
            or (now - self._lan_cache_at) > _CACHE_TTL_SECONDS
        ):

            self._lan_cache = (
                self.network_configuration.get_lan_configurations() or []
            )

            self._lan_cache_at = now

        return self._lan_cache

    def wan_configurations(self) -> list[dict]:

        now = time.monotonic()

        if (
            self._wan_cache is None
            or (now - self._wan_cache_at) > _CACHE_TTL_SECONDS
        ):

            self._wan_cache = (
                self.network_configuration.get_wan_configurations() or []
            )

            self._wan_cache_at = now

        return self._wan_cache

    def lan_networks(self) -> list[ipaddress.IPv4Network | ipaddress.IPv6Network]:

        networks = []

        for config in self.lan_configurations():

            cidr = config.get("network")

            if not cidr:

                continue

            try:

                networks.append(
                    ipaddress.ip_network(cidr, strict=False)
                )

            except ValueError:

                continue

        return networks

    def lan_interface_names(self) -> set[str]:

        return {
            config["interface"]
            for config in self.lan_configurations()
            if config.get("interface")
        }

    def wan_interface_names(self) -> set[str]:

        return {
            config["interface"]
            for config in self.wan_configurations()
            if config.get("interface")
        }

    def is_lan_ip(self, ip: str | None) -> bool:

        if not ip:

            return False

        try:

            address = ipaddress.ip_address(ip)

        except ValueError:

            return False

        return any(
            address in network
            for network in self.lan_networks()
        )

    def is_lan_interface(self, interface: str | None) -> bool:

        if not interface:

            return False

        return interface in self.lan_interface_names()

    def is_wan_interface(self, interface: str | None) -> bool:

        if not interface:

            return False

        return interface in self.wan_interface_names()

    def is_discoverable(
        self,
        ip: str | None,
        interface: str | None,
    ) -> bool:
        """
        True only for neighbors on a LAN interface with a LAN IP.
        Used when ingesting ARP / DHCP during a scan.
        """

        if not self.is_lan_interface(interface):

            return False

        return self.is_lan_ip(ip)

    def belongs_to_lan(
        self,
        ip: str | None,
        interface: str | None,
    ) -> bool:
        """
        Whether an existing inventory row should appear in the UI.
        Keeps LAN clients with a stale IP after a segment change.
        """

        if self.is_wan_interface(interface):

            return False

        if ip and self.is_lan_ip(ip):

            return True

        if interface and self.is_lan_interface(interface):

            return True

        if ip and not self.is_lan_ip(ip):

            return False

        return False
