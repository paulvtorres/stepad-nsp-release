"""
Suricata NFQUEUE configuration.

When fail_closed is False (default), nft uses `bypass` so traffic keeps
flowing if Suricata stops. When True, queued packets are dropped if
Suricata is not reading the queue.
"""

import subprocess

from backend.shared.logging.logger import logger


NFT_BIN = "/usr/sbin/nft"

FILTER_FAMILY = "inet"
FILTER_TABLE = "stepad"
FILTER_CHAIN = "forward"


class NfqueueService:

    def _run(self, command: list[str]) -> dict:

        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
        )

        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }

    def _chain_lines(self) -> list[str]:

        result = subprocess.run(
            [NFT_BIN, "-a", "list", "chain", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN],
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:

            return []

        return result.stdout.splitlines()

    def _remove_queue_rules(self):

        for line in self._chain_lines():

            if "queue" not in line or "handle" not in line:

                continue

            handle = line.split("handle")[1].strip().split()[0]

            self._run([
                NFT_BIN, "delete", "rule",
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
                "handle", handle,
            ])

    def sync(self, fail_closed: bool = False) -> dict:
        """
        Re-add a single NFQUEUE rule at the end of forward (after drops).
        """

        self._run([NFT_BIN, "add", "table", FILTER_FAMILY, FILTER_TABLE])
        self._run([
            NFT_BIN, "add", "chain", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "{", "type", "filter", "hook", "forward", "priority", "0", ";",
            "policy", "accept", ";", "}",
        ])

        self._remove_queue_rules()

        command = [
            NFT_BIN, "add", "rule",
            FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "queue", "num", "0",
        ]

        if not fail_closed:

            command.append("bypass")

        result = self._run(command)

        mode = "fail-closed" if fail_closed else "bypass"

        logger.info(
            f"NFQUEUE 0 configured ({mode})."
        )

        return {
            "success": result["success"],
            "fail_closed": fail_closed,
            "mode": mode,
        }

    @staticmethod
    def read_fail_closed_from_db() -> bool:

        try:

            from backend.core.database.session import SessionLocal

            from backend.ips.models.threat_response_setting import (
                ThreatResponseSetting,
            )

            db = SessionLocal()

            try:

                row = db.query(ThreatResponseSetting).first()

                if row is None:

                    return False

                return bool(getattr(row, "ips_fail_closed", False))

            finally:

                db.close()

        except Exception:

            return False

    def sync_from_settings(self) -> dict:

        return self.sync(fail_closed=self.read_fail_closed_from_db())
