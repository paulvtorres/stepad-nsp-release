from datetime import datetime

from sqlalchemy.orm import Session

from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository
)


FIELD_LABELS = {
    "company_name": "Nombre de la empresa",
    "ruc": "RUC",
    "address": "Dirección",
    "phone": "Teléfono",
    "email": "Correo de contacto",
    "city": "Ciudad",
    "country": "País",
}

RECOMMENDED_FIELDS = (
    "ruc",
    "address",
    "phone",
    "email",
)


class OrganizationService:

    def __init__(self):

        self.repository = OrganizationSettingsRepository()

    def _profile_status(
        self,
        settings,
    ) -> dict:

        values = {
            "company_name": settings.company_name or "",
            "ruc": settings.ruc or "",
            "address": settings.address or "",
            "phone": settings.phone or "",
            "email": settings.email or "",
            "city": settings.city or "",
            "country": settings.country or "",
        }

        filled = sum(
            1 for value in values.values()
            if value.strip()
        )

        total = len(values)

        missing_recommended = [
            FIELD_LABELS[key]
            for key in RECOMMENDED_FIELDS
            if not values[key].strip()
        ]

        configured = bool(values["company_name"].strip())

        return {
            "configured": configured,
            "fields_filled": filled,
            "fields_total": total,
            "completion_percent": round(filled / total * 100) if total else 0,
            "missing_recommended": missing_recommended,
            "profile_complete": configured and not missing_recommended,
        }

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        profile = self._profile_status(settings)

        return {
            "company_name": settings.company_name,
            "ruc": settings.ruc,
            "address": settings.address,
            "phone": settings.phone,
            "email": settings.email,
            "city": settings.city,
            "country": settings.country,
            "updated_at": (
                settings.updated_at.isoformat()
                if settings.updated_at else None
            ),
            **profile,
        }

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.repository.get(db)

        if data.company_name is not None:

            name = (data.company_name or "").strip()

            if not name:

                from fastapi import HTTPException

                raise HTTPException(
                    status_code=400,
                    detail="El nombre de la empresa es obligatorio.",
                )

            settings.company_name = name

        if data.ruc is not None:
            settings.ruc = (data.ruc or "").strip() or None

        if data.address is not None:
            settings.address = (data.address or "").strip() or None

        if data.phone is not None:
            settings.phone = (data.phone or "").strip() or None

        if data.email is not None:
            settings.email = (data.email or "").strip() or None

        if data.city is not None:
            settings.city = (data.city or "").strip() or None

        if data.country is not None:
            settings.country = (data.country or "").strip() or None

        settings.updated_at = datetime.utcnow()

        self.repository.save(db, settings)

        return self.get_settings(db)
