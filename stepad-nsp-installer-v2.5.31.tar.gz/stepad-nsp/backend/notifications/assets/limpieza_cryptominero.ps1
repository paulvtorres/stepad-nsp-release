<#
    STEPAD NSP - Diagnostico de posible mineria de criptomonedas (cryptojacking)
    ------------------------------------------------------------------------

    Este equipo intento repetidamente conectarse a un dominio de mineria
    de criptomonedas o malware que STEPAD NSP tiene bloqueado. Este
    script AYUDA A DIAGNOSTICAR el problema en el equipo Windows: por
    defecto NO borra ni detiene nada, solo muestra informacion para que
    decidas que hacer.

    COMO USARLO:
      1. Guarda este archivo con extension .ps1 (si tu correo lo entrego
         como .txt, quita el ".txt" del nombre, debe quedar terminado en
         ".ps1").
      2. Clic derecho sobre el archivo > "Ejecutar con PowerShell", o
         abre PowerShell como Administrador y ejecuta:
           Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
           .\limpieza_cryptominero.ps1
      3. Revisa la salida. Si aparecen procesos sospechosos y quieres
         detenerlos, vuelve a ejecutar con:
           .\limpieza_cryptominero.ps1 -MatarProcesos
#>

param(
    [switch]$MatarProcesos
)

$NombresSospechosos = @(
    "xmrig", "xmr-stak", "cpuminer", "minerd", "ccminer", "nheqminer",
    "ethminer", "t-rex", "phoenixminer", "lolminer", "nbminer",
    "srbminer", "cryptonight", "wincpu", "cnminer", "gminer",
    "xmrig-cuda", "teamredminer"
)

Write-Host "=== STEPAD NSP: diagnostico de posible mineria de criptomonedas ===" -ForegroundColor Cyan
Write-Host ""

Write-Host "-- Procesos con mayor uso de CPU en este momento --" -ForegroundColor White
Get-Process | Sort-Object CPU -Descending | Select-Object -First 15 Name, Id, CPU, WS |
    Format-Table -AutoSize

Write-Host ""
Write-Host "-- Procesos con nombre tipico de minero --" -ForegroundColor White

$Encontrados = Get-Process | Where-Object {
    $nombre = $_.ProcessName.ToLower()
    $NombresSospechosos | Where-Object { $nombre -like "*$_*" }
}

if ($Encontrados) {

    $Encontrados | Select-Object Name, Id, CPU, Path | Format-Table -AutoSize

    Write-Host "Se encontraron procesos con nombres tipicos de minero." -ForegroundColor Red

} else {

    Write-Host (
        "No se encontraron procesos con nombres tipicos de minero. " +
        "Esto NO garantiza que el equipo este limpio: revisa tambien " +
        "'Administrador de tareas > Rendimiento' para ver si la CPU " +
        "sube mucho estando el equipo en reposo."
    ) -ForegroundColor Yellow

}

Write-Host ""
Write-Host "-- Tareas programadas activas con ejecucion reciente (30 dias) --" -ForegroundColor White

Get-ScheduledTask | Where-Object { $_.State -ne "Disabled" } | ForEach-Object {

    $info = Get-ScheduledTaskInfo -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction SilentlyContinue

    if ($info -and $info.LastRunTime -and $info.LastRunTime -gt (Get-Date).AddDays(-30)) {

        [PSCustomObject]@{
            Tarea           = $_.TaskName
            Ruta            = $_.TaskPath
            UltimaEjecucion = $info.LastRunTime
        }
    }

} | Format-Table -AutoSize

Write-Host ""
Write-Host "-- Programas configurados para iniciar con Windows --" -ForegroundColor White

Get-CimInstance Win32_StartupCommand |
    Select-Object Name, Command, Location |
    Format-Table -AutoSize

if ($MatarProcesos) {

    if ($Encontrados) {

        Write-Host ""
        Write-Host "Deteniendo procesos sospechosos..." -ForegroundColor Red

        $Encontrados | ForEach-Object {

            Write-Host "  Deteniendo $($_.Name) (PID $($_.Id))"

            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue

        }

    } else {

        Write-Host ""
        Write-Host "No hay procesos sospechosos que detener." -ForegroundColor Yellow

    }

}

Write-Host ""
Write-Host "=== Recomendaciones ===" -ForegroundColor Cyan
Write-Host "1. Ejecuta un analisis completo con Windows Defender (PowerShell como Administrador):"
Write-Host "     Start-MpScan -ScanType FullScan"
Write-Host "2. Para una limpieza mas profunda, instala Malwarebytes (version gratuita):"
Write-Host "     https://www.malwarebytes.com/mwb-download"
Write-Host "3. Si viste procesos sospechosos arriba, puedes detenerlos con:"
Write-Host "     .\limpieza_cryptominero.ps1 -MatarProcesos"
Write-Host "4. Detener el proceso no siempre lo elimina: si vuelve a aparecer tras reiniciar,"
Write-Host "   el equipo probablemente necesita una revision antivirus completa."
Write-Host "5. Cambia las contrasenas usadas desde este equipo despues de limpiarlo."
