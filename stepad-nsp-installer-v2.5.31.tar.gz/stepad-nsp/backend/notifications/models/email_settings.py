from datetime import datetime

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class EmailSettings(Base):

    __tablename__ = "email_settings"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    provider: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        default="custom",
    )

    smtp_host: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default="",
    )

    smtp_port: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=587,
    )

    smtp_user: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    smtp_password: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    from_email: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default="",
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )
