from pydantic import BaseModel


class EmailSettingsRequest(BaseModel):

    provider: str | None = None

    smtp_host: str | None = None

    smtp_port: int | None = None

    account_email: str | None = None

    smtp_password: str | None = None

    from_email: str | None = None


class EmailTestRequest(BaseModel):

    to_email: str | None = None
