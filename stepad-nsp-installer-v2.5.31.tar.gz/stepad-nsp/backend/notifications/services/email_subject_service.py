"""Plantillas de asunto para correos del NSP."""

from datetime import datetime

from sqlalchemy.orm import Session

from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository,
)

# Plantillas por defecto (vacío en BD = usar estas).
DEFAULT_REPORT_SUBJECT = (
    "{empresa} | Reporte de navegación ({periodo}) — "
    "{fecha_inicio} – {fecha_fin}"
)
DEFAULT_ALERT_SUBJECT = "{empresa} | Alerta de seguridad — {titulo}"
DEFAULT_BACKUP_SUBJECT = (
    "{empresa} | Respaldo de configuración STEPAD — {fecha}"
)
DEFAULT_TEST_SUBJECT = "{empresa} | Verificación de correo STEPAD"
DEFAULT_CLOUD_FAIL_SUBJECT = (
    "{empresa} | Fallo en respaldo de logs a la nube"
)

SUBJECT_MAX_LENGTH = 255

REPORT_VARIABLES = (
    "empresa",
    "periodo",
    "fecha_inicio",
    "fecha_fin",
    "fecha",
)

ALERT_VARIABLES = (
    "empresa",
    "titulo",
    "fecha",
)

BACKUP_VARIABLES = (
    "empresa",
    "fecha",
)

FREQUENCY_PERIOD_LABELS = {
    "daily": "diario",
    "weekly": "semanal",
    "monthly": "mensual",
}


def company_name(db: Session) -> str:

    try:

        org = OrganizationSettingsRepository().get(db)

        name = (org.company_name or "").strip()

        if name:

            return name

    except Exception:

        pass

    return "STEPAD NSP"


def _sanitize_subject(value: str) -> str:

    cleaned = " ".join(
        (value or "").replace("\r", " ").replace("\n", " ").split()
    ).strip()

    if len(cleaned) > SUBJECT_MAX_LENGTH:

        return cleaned[: SUBJECT_MAX_LENGTH - 1].rstrip() + "…"

    return cleaned


def render_subject(
    template: str,
    *,
    defaults: dict[str, str] | None = None,
    **variables: str,
) -> str:

    merged = dict(defaults or {})

    merged.update(variables)

    class _SafeDict(dict):

        def __missing__(self, key: str) -> str:

            return ""

    try:

        rendered = (template or "").format_map(_SafeDict(merged))

    except Exception:

        rendered = template or ""

    return _sanitize_subject(rendered)


def report_subject_template(stored: str | None) -> str:

    value = (stored or "").strip()

    return value or DEFAULT_REPORT_SUBJECT


def alert_subject_template(stored: str | None) -> str:

    value = (stored or "").strip()

    return value or DEFAULT_ALERT_SUBJECT


def backup_subject_template(stored: str | None) -> str:

    value = (stored or "").strip()

    return value or DEFAULT_BACKUP_SUBJECT


def build_report_subject(
    db: Session,
    template: str | None,
    *,
    frequency: str,
    start: datetime,
    end: datetime,
) -> str:

    period = FREQUENCY_PERIOD_LABELS.get(
        frequency or "daily",
        frequency or "período",
    )

    now = datetime.now()

    return render_subject(
        report_subject_template(template),
        empresa=company_name(db),
        periodo=period,
        fecha_inicio=start.strftime("%d/%m/%Y"),
        fecha_fin=end.strftime("%d/%m/%Y"),
        fecha=now.strftime("%d/%m/%Y %H:%M"),
    )


def build_alert_subject(
    db: Session,
    template: str | None,
    *,
    title: str,
) -> str:

    return render_subject(
        alert_subject_template(template),
        empresa=company_name(db),
        titulo=(title or "Evento de seguridad").strip(),
        fecha=datetime.now().strftime("%d/%m/%Y %H:%M"),
    )


def build_backup_subject(
    db: Session,
    template: str | None,
) -> str:

    return render_subject(
        backup_subject_template(template),
        empresa=company_name(db),
        fecha=datetime.now().strftime("%d/%m/%Y %H:%M"),
    )


def build_test_subject(db: Session) -> str:

    return render_subject(
        DEFAULT_TEST_SUBJECT,
        empresa=company_name(db),
        fecha=datetime.now().strftime("%d/%m/%Y %H:%M"),
    )


def build_cloud_fail_subject(db: Session) -> str:

    return render_subject(
        DEFAULT_CLOUD_FAIL_SUBJECT,
        empresa=company_name(db),
        fecha=datetime.now().strftime("%d/%m/%Y %H:%M"),
    )
