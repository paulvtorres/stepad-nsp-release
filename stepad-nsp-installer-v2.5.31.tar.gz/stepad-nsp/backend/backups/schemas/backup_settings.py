from pydantic import BaseModel


class BackupSettingsRequest(BaseModel):

    enabled: bool | None = None

    send_hour: int | None = None

    send_minute: int | None = None

    retention_count: int | None = None

    email_backup: bool | None = None

    to_emails: str | None = None

    bcc_emails: str | None = None

    email_subject: str | None = None
