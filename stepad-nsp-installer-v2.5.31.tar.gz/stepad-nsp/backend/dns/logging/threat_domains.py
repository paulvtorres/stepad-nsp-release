"""Deteccion de dominios bloqueados que indican una amenaza activa
(mineria de criptomonedas o malware/phishing), a diferencia de un
bloqueo comun por filtro de contenido (adultos, apuestas, redes
sociales, etc).

Se usa para decidir cuando un bloqueo del DNS merece una alerta
PRIORITARIA (con correo inmediato y script de limpieza adjunto) en vez
de simplemente sumar al conteo de "accesos bloqueados" del reporte.
"""

from sqlalchemy.orm import Session

from backend.content.models.content_category import (
    ContentCategory,
    CategoryDomain,
)


# Lista curada de pools de mineria de criptomonedas (mayormente Monero/
# XMR, que es "CPU-mineable" y por eso el mas usado para infectar PCs de
# oficina sin GPU) y de servicios de mineria via navegador (cryptojacking
# JS). No pretende ser exhaustiva -- el feed de malware/phishing
# (URLhaus + OpenPhish, ver backend/content/services/malware_feed_service.py)
# cubre la parte mas amplia de amenazas; esta lista solo agrega la senal
# especifica de "este equipo esta tratando de minar criptomonedas".
MINING_POOL_DOMAINS = frozenset({
    "luckpool.net",
    "supportxmr.com",
    "minexmr.com",
    "xmrpool.eu",
    "moneroocean.stream",
    "hashvault.pro",
    "nanopool.org",
    "herominers.com",
    "2miners.com",
    "k1pool.com",
    "dwarfpool.com",
    "prohashing.com",
    "viaxmr.com",
    "c3pool.com",
    "zergpool.com",
    "unmineable.com",
    "f2pool.com",
    "poolin.com",
    "viabtc.com",
    "antpool.com",
    "minergate.com",
    "nicehash.com",
    "ethermine.org",
    "flexpool.io",
    "hiveon.net",
    "coinimp.com",
    "coinhive.com",
    "webminepool.com",
    "crypto-loot.com",
})


def _normalize(domain: str | None) -> str:

    return (domain or "").strip().lower().rstrip(".")


def _matches_suffix(domain: str, base: str) -> bool:

    return domain == base or domain.endswith("." + base)


def is_mining_pool_domain(domain: str | None) -> bool:

    normalized = _normalize(domain)

    if not normalized:

        return False

    return any(
        _matches_suffix(normalized, pool)
        for pool in MINING_POOL_DOMAINS
    )


def _domain_and_parent_suffixes(domain: str) -> set[str]:

    labels = domain.split(".")

    # Genera "sub.evil.com" -> {"sub.evil.com", "evil.com"}, deteniendose
    # en dos etiquetas (no tiene sentido comparar solo el TLD).
    return {
        ".".join(labels[i:])
        for i in range(len(labels) - 1)
    }


def is_malware_feed_domain(db: Session, domain: str | None) -> bool:

    normalized = _normalize(domain)

    if not normalized or "." not in normalized:

        return False

    candidates = _domain_and_parent_suffixes(normalized)

    match = (
        db.query(CategoryDomain.id)
        .join(
            ContentCategory,
            ContentCategory.id == CategoryDomain.category_id
        )
        .filter(
            ContentCategory.key == "malware",
            CategoryDomain.domain.in_(candidates)
        )
        .first()
    )

    return match is not None


def classify_blocked_domain(
    db: Session,
    domain: str | None
) -> dict | None:
    """Clasifica un dominio bloqueado como amenaza prioritaria, o None
    si es un bloqueo comun (filtro de contenido) que no lo amerita."""

    if is_mining_pool_domain(domain):

        return {
            "kind": "mining",
            "label": "Posible minería de criptomonedas",
        }

    if is_malware_feed_domain(db, domain):

        return {
            "kind": "malware",
            "label": "Posible malware o phishing",
        }

    return None
