"""
Heuristics for "effective browsing" navigation logs.

DNS/SNI pipelines use these filters so reports by date reflect real
site visits, not connectivity checks, reverse DNS, or local noise.
"""


NOISE_EXACT = frozenset({
    "localhost",
    "localhost.localdomain",
})

NOISE_SUFFIXES = (
    ".local",
    ".localdomain",
    ".lan",
    ".home",
    ".internal",
    ".arpa",
    ".invalid",
    ".test",
)

# Substrings common in OS/app background traffic (not user browsing).
NOISE_SUBSTRINGS = (
    "connectivitycheck",
    "connectivity-check",
    "msftconnecttest",
    "detectportal",
    "gvt1.com",
    "clients1.google.com",
    "clients2.google.com",
    "clients3.google.com",
    "clients4.google.com",
    "clients5.google.com",
    "clients6.google.com",
    "clients.google.com",
    "ocsp.",
    "crl.",
    "ctldl.windowsupdate.com",
    "wpad.",
    "isatap.",
    "in-addr.arpa",
    "ip6.arpa",
    "apple-dns.net",
    "push.apple.com",
    "gateway.icloud.com",
    "mask.icloud.com",
    "dns.google",
    "time.google.com",
    "pool.ntp.org",
    "ntp.org",
)


def normalize_domain(domain: str | None) -> str:

    if not domain:

        return ""

    return domain.strip().lower().rstrip(".")


def is_effective_navigation_domain(domain: str | None) -> bool:

    normalized = normalize_domain(domain)

    if not normalized:

        return False

    if normalized.startswith("_"):

        return False

    if normalized in NOISE_EXACT:

        return False

    if "." not in normalized:

        return False

    if any(normalized.endswith(suffix) for suffix in NOISE_SUFFIXES):

        return False

    if any(fragment in normalized for fragment in NOISE_SUBSTRINGS):

        return False

    return True
