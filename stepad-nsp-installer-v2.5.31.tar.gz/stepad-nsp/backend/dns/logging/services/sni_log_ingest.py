import json

import time

from datetime import datetime, timedelta

from pathlib import Path

from sqlalchemy import delete as sa_delete

from backend.core.database.session import SessionLocal

from backend.dns.logging.models.sni_log import SniLog

from backend.dns.logging.navigation_filters import (
    is_effective_navigation_domain,
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.shared.logging.logger import logger


EVE_LOG = Path("/var/log/suricata/eve.json")

STATE_FILE = Path("/etc/stepad/ips/sni_offset")

POLL_INTERVAL = 10

RETENTION_CHECK_INTERVAL_SECONDS = 3600

DEFAULT_RETENTION_DAYS = 90

# Reintentos rapidos del mismo (src, dominio) para no llenar la tabla
# con handshakes repetidos de la misma conexion.
DEDUPE_WINDOW_SECONDS = 30


class SniLogIngest:


    def __init__(self):

        self.device_repo = DeviceRepository()

        self._offset = 0

        self._recent = {}

        self._load_offset()


    def _load_offset(self):

        try:

            self._offset = int(
                STATE_FILE.read_text().strip()
            )

        except Exception:

            try:

                if EVE_LOG.exists():

                    self._offset = EVE_LOG.stat().st_size

            except Exception:

                self._offset = 0


    def _save_offset(self):

        try:

            STATE_FILE.parent.mkdir(
                parents=True,
                exist_ok=True
            )

            STATE_FILE.write_text(str(self._offset))

        except Exception as error:

            logger.warning(
                "No pude guardar el offset de eve.json (SNI): %s",
                error
            )


    def _process_event(self, event, db):

        if event.get("event_type") != "tls":

            return

        tls = event.get("tls", {})

        domain = tls.get("sni")

        if not domain or not is_effective_navigation_domain(domain):

            return

        src_ip = event.get("src_ip", "")

        if not src_ip:

            return

        now = time.time()

        key = (src_ip, domain)

        last = self._recent.get(key)

        if last and now - last < DEDUPE_WINDOW_SECONDS:

            return

        self._recent[key] = now

        device = self.device_repo.find_by_ip(db, src_ip)

        db.add(
            SniLog(
                device_id=device.id if device else None,
                src_ip=src_ip,
                domain=domain[:255],
                dest_ip=event.get("dest_ip"),
                dest_port=event.get("dest_port"),
            )
        )

        db.commit()


    def poll_once(self):

        try:

            if not EVE_LOG.exists():

                return

            size = EVE_LOG.stat().st_size

            if size <= self._offset:

                return

            db = SessionLocal()

            try:

                with open(EVE_LOG, "r") as file:

                    file.seek(self._offset)

                    for line in file:

                        line = line.strip()

                        if not line:

                            continue

                        try:

                            event = json.loads(line)

                        except ValueError:

                            continue

                        self._process_event(event, db)

                    self._offset = file.tell()

            finally:

                db.close()

            self._save_offset()

        except Exception as error:

            logger.error(
                "Error al leer eve.json (SNI): %s",
                error
            )


    def _retention_loop(self, retention_days: int):

        while True:

            time.sleep(RETENTION_CHECK_INTERVAL_SECONDS)

            db = SessionLocal()

            try:

                cutoff = datetime.utcnow() - timedelta(days=retention_days)

                deleted = db.execute(
                    sa_delete(SniLog).where(
                        SniLog.created_at < cutoff
                    )
                ).rowcount

                db.commit()

                if deleted:

                    logger.info(
                        "SNI log: pruned %s record(s) older than %s days",
                        deleted,
                        retention_days,
                    )

            except Exception as error:

                logger.error(
                    "SNI log: retention cleanup failed: %s",
                    error,
                )

            finally:

                db.close()


    def run_forever(self):

        retention_days = DEFAULT_RETENTION_DAYS

        try:

            db = SessionLocal()

            try:

                from backend.siem.services.compliance_service import (
                    ComplianceService,
                )

                retention_days = ComplianceService().retention_days(db)

            finally:

                db.close()

        except Exception:

            pass

        import threading

        threading.Thread(
            target=self._retention_loop,
            args=(retention_days,),
            daemon=True,
            name="sni-log-retention",
        ).start()

        logger.info(
            "Ingesta de conexiones SNI iniciada (eve.json, retencion %s dias).",
            retention_days,
        )

        while True:

            try:

                self.poll_once()

            except Exception as error:

                logger.exception(
                    "Error en el bucle de SNI: %s",
                    error
                )

            time.sleep(POLL_INTERVAL)


sni_log_ingest = SniLogIngest()
