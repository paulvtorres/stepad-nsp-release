from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class SniLog(Base):

    __tablename__ = "sni_logs"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    device_id: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )

    src_ip: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )

    # Dominio en claro del handshake TLS (SNI): el sitio EXACTO al que
    # el equipo se conecta, de forma continua (cada conexion HTTPS).
    domain: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )

    dest_ip: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True
    )

    dest_port: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        index=True
    )
