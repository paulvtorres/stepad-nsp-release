from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import (
    ComponentCriticality
)

from backend.core.config.settings import Settings

from backend.core.config.paths import (
    DOMAINS_CONFIG
)

from backend.dns.factory import get_dns_provider

from backend.dns.logging.dns_query_log_listener import dns_query_log_listener

from backend.core.database.session import SessionLocal

from backend.siem.services.compliance_service import ComplianceService

from backend.shared.enums.dns_engine import DnsEngine

from backend.shared.logging.logger import logger


class DnsComponent(BaseComponent):

    name = "dns"

    criticality = ComponentCriticality.IMPORTANT


    def start(self):
        logger.info(
            "DnsComponent started."
        )

        db = SessionLocal()

        try:

            retention = ComplianceService().retention_days(db)

        finally:

            db.close()

        listener_ok = dns_query_log_listener.start(
            retention_days=retention
        )

        if Settings.DNS_ENGINE == DnsEngine.DNSMASQ:

            DOMAINS_CONFIG.parent.mkdir(
                parents=True,
                exist_ok=True
            )

            DOMAINS_CONFIG.touch(
                exist_ok=True
            )

            logger.info(
                f"Domain configuration ready: {DOMAINS_CONFIG}"
            )

        else:

            # Engines other than dnsmasq may need one-time setup
            # (e.g. PowerDnsRpzProvider writes the Lua config that
            # points the recursor at our RPZ zone). Domain changes
            # after this never touch anything bootstrap() writes.
            provider = get_dns_provider()

            if hasattr(provider, "bootstrap"):

                provider.bootstrap()

            # pdns-recursor se mantiene corriendo entre reinicios del
            # NSP con una conexion STALE al socket anterior del listener
            # (CLOSE-WAIT). Reiniciarlo re-establece el canal de logs de
            # consultas DNS (es rapido, ~1s, y evita perder el registro).
            if listener_ok:

                try:

                    import subprocess

                    subprocess.run(
                        ["systemctl", "restart", "pdns-recursor"],
                        capture_output=True,
                        text=True,
                        timeout=15,
                    )

                except Exception as error:

                    logger.warning(
                        f"No se pudo reiniciar pdns-recursor para el "
                        f"registro DNS: {error}"
                    )

            logger.info(
                f"DNS engine '{Settings.DNS_ENGINE}' bootstrapped."
            )


    def stop(self):

        logger.info(
            "DnsComponent stopped."
        )
