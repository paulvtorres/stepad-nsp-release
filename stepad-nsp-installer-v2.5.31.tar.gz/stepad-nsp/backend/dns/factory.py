from backend.core.config.settings import Settings

from backend.dns.providers.dns_provider_interface import (
    DnsProviderInterface
)

from backend.shared.enums.dns_engine import DnsEngine


_provider_instance: DnsProviderInterface | None = None


def get_dns_provider() -> DnsProviderInterface:
    """
    Returns the shared DNS provider instance for the process.

    Controlled by Settings.DNS_ENGINE. To add a new engine: write a
    class implementing DnsProviderInterface, add a branch here, done
    -- no other file needs to change.
    """

    global _provider_instance

    if _provider_instance is None:

        engine = Settings.DNS_ENGINE

        if engine == DnsEngine.DNSMASQ:

            from backend.dns.providers.linux_dns_provider import (
                LinuxDnsProvider
            )

            _provider_instance = LinuxDnsProvider()

        elif engine == DnsEngine.POWERDNS_RPZ:

            from backend.dns.providers.powerdns_rpz_provider import (
                PowerDnsRpzProvider
            )

            _provider_instance = PowerDnsRpzProvider()

        else:

            raise ValueError(
                f"Unknown DNS_ENGINE: {engine!r}. "
                f"Supported: {DnsEngine.DNSMASQ!r}, {DnsEngine.POWERDNS_RPZ!r}."
            )

    return _provider_instance
