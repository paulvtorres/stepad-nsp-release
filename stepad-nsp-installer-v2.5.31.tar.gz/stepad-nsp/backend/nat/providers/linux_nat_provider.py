import subprocess

from backend.network.security.sysctl_hardening import apply_sysctl_hardening


class LinuxNatProvider:


    def run_command(
        self,
        command
    ):

        result = subprocess.run(
            command,
            capture_output=True,
            text=True
        )

        return {

            "success": result.returncode == 0,

            "output": result.stdout.strip(),

            "error": result.stderr.strip()

        }



    def enable_forwarding(self):

        return apply_sysctl_hardening()



    def sync_masquerade(
        self,
        wan_interfaces: list[str]
    ):
        """
        Makes the postrouting chain match reality: one masquerade
        rule per CURRENT WAN interface, and nothing else. Adding a
        second WAN, swapping a card (old oifname dies), or removing
        a WAN assignment all converge here -- this is the single
        reconciliation point instead of configure/cleanup pairs that
        drift.

        Idempotent: rules for current WANs that already exist are
        left alone, stale rules for interfaces no longer WAN are
        deleted, missing rules are added.
        """

        if not wan_interfaces:

            return {
                "success": False,
                "error": "No WAN interface detected"
            }

        # Crear tabla si no existe
        self.run_command(
            ["/usr/sbin/nft", "add", "table", "ip", "nat"]
        )

        # Crear chain si no existe
        self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "chain",
                "ip",
                "nat",
                "postrouting",
                "{",
                "type",
                "nat",
                "hook",
                "postrouting",
                "priority",
                "100",
                ";",
                "}"
            ]
        )

        existing = self.run_command(
            [
                "/usr/sbin/nft",
                "-a",
                "list",
                "chain",
                "ip",
                "nat",
                "postrouting"
            ]
        )

        seen = set()

        deleted = 0

        for line in existing["output"].splitlines():

            if "masquerade" not in line or "oifname" not in line:

                continue

            if "handle" not in line:

                continue

            # Pull the interface name out of the rule line -- the
            # token immediately following "oifname".
            tokens = line.split()

            try:

                interface = tokens[tokens.index("oifname") + 1].strip('"')

            except (ValueError, IndexError):

                continue

            if interface in wan_interfaces:

                seen.add(interface)

                continue

            handle = line.split("handle")[1].strip()

            self.run_command(
                [
                    "/usr/sbin/nft",
                    "delete",
                    "rule",
                    "ip",
                    "nat",
                    "postrouting",
                    "handle",
                    handle
                ]
            )

            deleted += 1

        added = []

        for interface in wan_interfaces:

            if interface in seen:

                continue

            result = self.run_command(
                [
                    "/usr/sbin/nft",
                    "add",
                    "rule",
                    "ip",
                    "nat",
                    "postrouting",
                    "oifname",
                    interface,
                    "masquerade"
                ]
            )

            if result["success"]:

                added.append(interface)

            else:

                return {
                    "success": False,
                    "error": f"Failed to masquerade {interface}: {result['error']}"
                }

        return {
            "success": True,
            "wan_interfaces": wan_interfaces,
            "added": added,
            "removed_stale": deleted
        }


    def sync_port_forwards(
        self,
        wan_interfaces: list[str],
        forwards: list
    ):
        """
        Publishes inbound services (DMZ): rebuilds a dedicated
        `port-forwards` chain in the ip/nat table, jumped to from
        prerouting, from the current set of port-forwards. One rule
        per (forward, applicable WAN interface, protocol). Stale
        rules disappear because the chain is flushed and rebuilt on
        every sync.
        """

        # Table / base prerouting chain / dedicated chain (all
        # idempotent -- errors mean "already exists").
        self.run_command(["nft", "add", "table", "ip", "nat"])

        self.run_command([
            "nft", "add", "chain", "ip", "nat", "prerouting", "{",
            "type", "nat", "hook", "prerouting", "priority", "-100", ";",
            "}"
        ])

        self.run_command([
            "nft", "add", "chain", "ip", "nat", "port-forwards"
        ])

        existing = self.run_command([
            "nft", "list", "chain", "ip", "nat", "prerouting"
        ])

        if "port-forwards" not in existing["output"]:

            self.run_command([
                "nft", "add", "rule", "ip", "nat", "prerouting",
                "jump", "port-forwards"
            ])

        self.run_command([
            "nft", "flush", "chain", "ip", "nat", "port-forwards"
        ])

        added = 0

        for forward in forwards:

            if not forward.enabled:

                continue

            interfaces = (
                [forward.wan_interface]
                if forward.wan_interface
                else wan_interfaces
            )

            protocols = (
                ["tcp", "udp"]
                if forward.protocol == "both"
                else [forward.protocol]
            )

            for interface in interfaces:

                for protocol in protocols:

                    result = self.run_command([
                        "nft", "add", "rule", "ip", "nat", "port-forwards",
                        "iifname", interface,
                        protocol, "dport", str(forward.external_port),
                        "dnat", "to", (
                            f"{forward.internal_ip}:"
                            f"{forward.internal_port}"
                        )
                    ])

                    if result["success"]:

                        added += 1

        return {
            "success": True,
            "wan_interfaces": wan_interfaces,
            "added": added
        }