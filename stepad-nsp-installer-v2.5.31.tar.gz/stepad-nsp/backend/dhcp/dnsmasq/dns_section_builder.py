"""
Builds the DNS-related fragment of dnsmasq.conf.

Two modes, controlled by Settings.DNS_ENGINE (see DnsEngine):

  dnsmasq
      dnsmasq is the authoritative LAN resolver: upstream forwarders,
      domain blocking via blocked_domains.conf.

  powerdns_rpz (and future delegated engines)
      dnsmasq is DHCP-only (port=0). The delegated engine listens on
      each LAN gateway IP directly (PowerDNS: ensure_listen_address()).
      Clients still receive the gateway as dhcp-option 6; the recursor
      must be reachable on that address — not on localhost only.
"""

from backend.core.config.paths import DOMAINS_CONFIG
from backend.core.config.settings import Settings
from backend.shared.enums.dns_engine import DnsEngine


class DnsmasqDnsSectionBuilder:
    """Single place that decides how dnsmasq participates in DNS."""

    DEFAULT_UPSTREAM_SERVERS = ("1.1.1.1", "8.8.8.8")

    @classmethod
    def build(cls) -> str:
        engine = Settings.DNS_ENGINE

        if DnsEngine.is_delegated(engine):
            return cls._delegated_section(engine)

        return cls._integrated_section()

    @classmethod
    def _delegated_section(cls, engine: str) -> str:
        return f"""# DNS delegated to {engine!r} — dnsmasq provides DHCP only.
# LAN clients query the gateway IP; the delegated engine must listen there
# (see PowerDnsRpzProvider.ensure_listen_address()).
port=0
"""

    @classmethod
    def _integrated_section(cls) -> str:
        upstream_lines = "\n".join(
            f"server={address}"
            for address in cls.DEFAULT_UPSTREAM_SERVERS
        )

        return f"""{upstream_lines}

domain-needed

bogus-priv

# Domain Rules

conf-file={DOMAINS_CONFIG}
"""
