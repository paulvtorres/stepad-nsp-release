import json
import os
import shutil
import subprocess
import tarfile
import threading
import urllib.request

from pathlib import Path

from backend.shared.constants.app_version import (
    APP_VERSION,
    REPO_DIR,
)
from backend.shared.logging.logger import logger

UPDATE_SCRIPT = "/home/paulan/stepad-nsp/update.sh"
RELEASE_REPO = "paulvtorres/stepad-nsp-release"


def _git(*args: str) -> str:

    try:

        result = subprocess.run(
            [
                "git", "-C", str(REPO_DIR),
                "-c", f"safe.directory={REPO_DIR}",
                *args,
            ],
            capture_output=True,
            text=True,
            timeout=15,
        )

        return result.stdout.strip()

    except Exception:

        return ""


def _is_git_install() -> bool:

    return (REPO_DIR / ".git").exists()


def _installed_version() -> str:

    try:

        marker = Path("/etc/stepad/version")

        if marker.exists():

            value = marker.read_text().strip()

            if value:

                return value

    except Exception:

        pass

    return APP_VERSION


def _latest_release() -> dict:
    """
    Resuelve la última versión publicada en stepad-nsp-release/main.

    El flujo de producción sube manualmente stepad-nsp-installer.tar.gz
    al branch main (no GitHub Releases). get-stepad.sh y este servicio
    leen la misma URL.
    """

    version_url = (
        f"https://raw.githubusercontent.com/{RELEASE_REPO}/main/VERSION"
    )

    installer_url = (
        f"https://raw.githubusercontent.com/{RELEASE_REPO}/main/"
        "stepad-nsp-installer.tar.gz"
    )

    try:

        request = urllib.request.Request(
            version_url,
            headers={"User-Agent": "STEPAD-NSP/1.0"},
        )

        with urllib.request.urlopen(request, timeout=15) as response:

            tag = response.read().decode("utf-8", errors="ignore").strip()

        if not tag:

            return {}

        return {"tag": tag, "url": installer_url}

    except Exception as error:

        logger.warning(
            f"No se pudo consultar la versión en {RELEASE_REPO}/main: {error}"
        )

        return {}


def _normalize(version: str) -> str:

    return version.strip().lstrip("v")


def update_status() -> dict:

    installed = _installed_version()

    git_mode = _is_git_install()

    if git_mode:

        try:

            subprocess.run(
                [
                    "git", "-C", str(REPO_DIR),
                    "-c", f"safe.directory={REPO_DIR}",
                    "fetch", "origin",
                ],
                capture_output=True,
                text=True,
                timeout=20,
            )

        except Exception:

            pass

        head = _git("rev-parse", "HEAD")

        remote = _git("rev-parse", "origin/main")

        pending = []

        if head and remote and head != remote:

            log = _git(
                "log", "--oneline", "-30",
                f"{head}..origin/main",
            )

            for line in log.splitlines():

                line = line.strip()

                if not line:

                    continue

                parts = line.split(" ", 1)

                pending.append({
                    "commit": parts[0] if parts else "",
                    "message": parts[1] if len(parts) > 1 else "",
                })

        latest = _latest_release()

        return {
            "version": installed,
            "commit": head or "-",
            "remote_commit": remote or "-",
            "latest_version": latest.get("tag", ""),
            "update_available": bool(
                head and remote and head != remote
            ) or (
                latest.get("tag")
                and _normalize(installed) != _normalize(latest["tag"])
            ),
            "pending_commits": pending,
            "mode": "git",
        }

    # Instalación por paquete: comparar versión instalada vs última.
    latest = _latest_release()

    update_available = bool(
        latest.get("tag")
        and _normalize(installed) != _normalize(latest["tag"])
    )

    return {
        "version": installed,
        "commit": "-",
        "remote_commit": "-",
        "latest_version": latest.get("tag", ""),
        "update_available": update_available,
        "pending_commits": [],
        "mode": "package",
    }


def start_update() -> dict:

    def run():

        try:

            if _is_git_install():

                subprocess.run(
                    ["bash", UPDATE_SCRIPT],
                    timeout=600,
                )

            else:

                _update_package()

        except Exception:

            pass

    thread = threading.Thread(
        target=run,
        daemon=True,
        name="stepad-update",
    )

    thread.start()

    return {
        "success": True,
        "message": "Actualización iniciada en segundo plano.",
    }


def _update_package():

    """Actualización asistida para instalaciones por paquete."""

    try:

        info = _latest_release()

        if not info.get("url"):

            logger.error(
                "No se pudo resolver la última versión para actualizar."
            )
            return

        app_dir = Path.cwd()

        logger.info(f"Actualizando por paquete en {app_dir}...")

        archive = "/tmp/stepad-update.tar.gz"

        urllib.request.urlretrieve(info["url"], archive)

        extract_dir = "/tmp/stepad-update-pkg"

        shutil.rmtree(extract_dir, ignore_errors=True)

        extract_dir = Path(extract_dir)

        with tarfile.open(archive, "r:gz") as tar:

            tar.extractall(extract_dir)

        pkg = extract_dir / "stepad-nsp"

        if not (pkg / "install.sh").exists():

            logger.error("Paquete de actualización inválido.")
            return

        # Sobrescribir el código nuevo sobre la carpeta actual de la app.
        for entry in pkg.iterdir():

            target = app_dir / entry.name

            if entry.is_dir():

                shutil.copytree(entry, target, dirs_exist_ok=True)

            else:

                shutil.copy2(entry, target)

        env = dict(os.environ)

        env["STEPAD_UPDATE"] = "1"

        subprocess.run(
            ["bash", str(app_dir / "install.sh")],
            env=env,
            timeout=900,
        )

    except Exception as error:

        logger.exception(
            f"Fallo la actualización por paquete: {error}"
        )
