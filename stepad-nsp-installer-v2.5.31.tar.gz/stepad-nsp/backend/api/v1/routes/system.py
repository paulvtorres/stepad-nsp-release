import re
import socket
import subprocess
import threading

from pathlib import Path

from fastapi import APIRouter, Depends

from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.core.lifecycle.services.system_status_service import SystemStatusService

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.shared.constants.app_version import APP_VERSION, git_commit, installed_version


class ModulesRequest(BaseModel):

    enabled_keys: list[str] = []


class PowerRequest(BaseModel):

    confirm: bool = False


from backend.system.services.update_service import (
    update_status,
    start_update
)

from backend.shared.logging.logger import logger


router = APIRouter(
    prefix="/system",
    tags=["System"]
)


service = SystemStatusService()

ENV_FILE = Path("/etc/stepad/stepad.env")

REMOTE_ADMIN_KEY = "STEPAD_VPN_REQUIRE_REMOTE_ADMIN"


def _read_env() -> dict:

    values = {}

    if ENV_FILE.exists():

        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():

            line = line.strip()

            if not line or "=" not in line or line.startswith("#"):

                continue

            key, value = line.split("=", 1)

            values[key.strip()] = value.strip().strip("\"'")

    return values


def _write_env_value(
    key: str,
    value: str
):

    values = _read_env()

    values[key] = value

    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)

    ENV_FILE.write_text(
        "\n".join(f"{k}={v}" for k, v in values.items()) + "\n",
        encoding="utf-8"
    )

    ENV_FILE.chmod(0o600)


def _restart_in_background():

    def run():

        subprocess.run(
            ["systemctl", "restart", "stepad-nsp"],
            timeout=60
        )

    thread = threading.Thread(target=run, daemon=True)

    thread.start()


class RemoteAdminRequest(BaseModel):

    enabled: bool


@router.get("/status")
def status(
    current_user: dict = Depends(get_current_user)
):

    return service.get_status()


@router.get("/navigation-status")
def navigation_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return _navigation_status(db)


def _proc_running(name: str) -> bool:

    try:

        result = subprocess.run(
            ["pgrep", "-x", name],
            capture_output=True,
            text=True,
            timeout=5,
        )

        return result.returncode == 0

    except Exception:

        return False


def _stepad_dhcp_running() -> bool:

    if _proc_running("dnsmasq"):

        return True

    try:

        result = subprocess.run(
            [
                "pgrep", "-f",
                "conf-file=/etc/stepad/dns/dnsmasq.conf",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )

        return bool(result.stdout.strip())

    except Exception:

        return False


def _dns_log_listener_running() -> bool:

    try:

        with socket.create_connection(
            ("127.0.0.1", 4242),
            timeout=2,
        ):

            return True

    except Exception:

        return False


def _navigation_status(db: Session) -> dict:
    """
    Estado de la navegacion: internet del NSP, DHCP, DNS y reenvio.
    El Panel lo muestra con un mensaje verde "Navegación OK".
    """

    # Internet: conexion TCP a un resolutor publico (tiempo corto).
    internet_ok = False
    try:

        with socket.create_connection(("1.1.1.1", 443), timeout=3):
            internet_ok = True

    except Exception:

        internet_ok = False

    dhcp_ok = _stepad_dhcp_running()

    dns_ok = _proc_running("pdns_recursor")

    log_listener_ok = _dns_log_listener_running()

    forwarding_ok = False
    try:

        result = subprocess.run(
            ["sysctl", "-n", "net.ipv4.ip_forward"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        forwarding_ok = result.stdout.strip() == "1"

    except Exception:

        forwarding_ok = False

    checks = {
        "internet": {
            "ok": internet_ok,
            "detail": "El NSP tiene salida a internet"
            if internet_ok else "El NSP no alcanza internet",
        },
        "dhcp": {
            "ok": dhcp_ok,
            "detail": "Servidor DHCP activo"
            if dhcp_ok else "DHCP inactivo",
        },
        "dns": {
            "ok": dns_ok,
            "detail": "Resolver DNS activo"
            if dns_ok else "Resolver DNS inactivo",
        },
        "log_listener": {
            "ok": log_listener_ok,
            "detail": (
                "Registro de navegacion (DNS) escuchando en 127.0.0.1:4242"
                if log_listener_ok else
                "El listener de logs DNS no responde — no se guardan visitas"
            ),
        },
        "forwarding": {
            "ok": forwarding_ok,
            "detail": "Reenvío (NAT) activo"
            if forwarding_ok else "Reenvío desactivado",
        },
    }

    # Conflictos de red (WAN/LAN solapados, gateway duplicado).
    try:

        from backend.network.configuration.services.network_topology_check_service import (
            NetworkTopologyCheckService
        )

        conflicts = NetworkTopologyCheckService().get_conflicts()

    except Exception:

        conflicts = {"ok": True, "detail": "Sin conflictos de red"}

    checks["conflicto"] = {
        "ok": conflicts.get("ok", True),
        "detail": conflicts.get("detail", "Sin conflictos de red"),
    }

    ok = all(check["ok"] for check in checks.values())

    stats = _navigation_log_stats(db)

    return {
        "ok": ok,
        "message": (
            "Navegación OK"
            if ok else "Navegación con problemas"
        ),
        "checks": checks,
        "log_stats": stats,
    }


def _navigation_log_stats(db: Session) -> dict:

    from datetime import datetime, timedelta

    from sqlalchemy import func

    from backend.dns.logging.models.dns_query_log import DnsQueryLog

    from backend.dns.logging.models.sni_log import SniLog

    try:

        now = datetime.utcnow()

        since_24h = now - timedelta(hours=24)

        dns_total = db.query(func.count(DnsQueryLog.id)).scalar() or 0

        dns_24h = (
            db.query(func.count(DnsQueryLog.id))
            .filter(DnsQueryLog.queried_at >= since_24h)
            .scalar()
        ) or 0

        dns_devices_24h = (
            db.query(func.count(func.distinct(DnsQueryLog.device_id)))
            .filter(
                DnsQueryLog.queried_at >= since_24h,
                DnsQueryLog.device_id.isnot(None),
            )
            .scalar()
        ) or 0

        sni_total = db.query(func.count(SniLog.id)).scalar() or 0

        sni_24h = (
            db.query(func.count(SniLog.id))
            .filter(SniLog.created_at >= since_24h)
            .scalar()
        ) or 0

        latest_dns = (
            db.query(func.max(DnsQueryLog.queried_at))
            .scalar()
        )

        return {
            "dns_total": dns_total,
            "dns_last_24h": dns_24h,
            "dns_devices_last_24h": dns_devices_24h,
            "dns_latest_at": (
                latest_dns.isoformat() + "Z"
                if latest_dns else None
            ),
            "sni_total": sni_total,
            "sni_last_24h": sni_24h,
        }

    except Exception as error:

        logger.warning(
            "No se pudieron leer estadisticas de navegacion: %s",
            error,
        )

        return {}


@router.get("/version")
def version(
    current_user: dict = Depends(get_current_user)
):

    return {
        "version": installed_version(),
        "commit": git_commit()
    }


@router.get("/update-status")
def update_status_endpoint(
    current_user: dict = Depends(get_current_user)
):

    return update_status()


@router.post("/update")
def update(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return start_update()


@router.get("/remote-admin")
def get_remote_admin(
    current_user: dict = Depends(get_current_user)
):

    value = _read_env().get(REMOTE_ADMIN_KEY, "true")

    return {"enabled": value.lower() in ("1", "true", "yes")}


@router.post("/remote-admin")
def set_remote_admin(
    request: RemoteAdminRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    value = "true" if request.enabled else "false"

    _write_env_value(REMOTE_ADMIN_KEY, value)

    logger.info(
        f"Remote-admin policy set to {value}; restarting to apply."
    )

    _restart_in_background()

    return {
        "success": True,
        "enabled": request.enabled,
        "message": (
            "Política aplicada. El servicio se está reiniciando; "
            "la web vuelve en unos segundos."
        )
    }


@router.post("/restart")
def restart(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    _restart_in_background()

    return {
        "success": True,
        "message": "Reiniciando servicios... (la web vuelve en unos segundos)"
    }


def _power_in_background(action: str):

    def run():

        try:

            import time

            time.sleep(2)

            subprocess.run(
                ["systemctl", action],
                timeout=30
            )

        except Exception:

            pass

    threading.Thread(
        target=run,
        daemon=True
    ).start()


@router.post("/reboot")
def reboot_machine(
    request: PowerRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    if not request.confirm:

        return {
            "success": False,
            "message": "Se requiere confirmación (confirm: true)"
        }

    _power_in_background("reboot")

    return {
        "success": True,
        "message": "Reiniciando el equipo... (vuelve en unos minutos)"
    }


@router.post("/shutdown")
def shutdown_machine(
    request: PowerRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    if not request.confirm:

        return {
            "success": False,
            "message": "Se requiere confirmación (confirm: true)"
        }

    _power_in_background("poweroff")

    return {
        "success": True,
        "message": "Apagando el equipo..."
    }


@router.get("/hardware")
def hardware(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.system.services.hardware_service import (
        HardwareService
    )

    from backend.system.services.module_service import ModuleService

    enabled_req = ModuleService().enabled_requirements(db)

    return HardwareService().get_hardware_info(
        enabled_requirements=enabled_req
    )


@router.get("/modules")
def get_modules(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.system.services.module_service import ModuleService

    return ModuleService().get_modules(db)


@router.put("/modules")
def set_modules(
    request: ModulesRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.system.services.module_service import ModuleService

    return ModuleService().set_modules(db, request.enabled_keys)
