from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from pathlib import Path

from backend.core.config.settings import Settings

from backend.api.middleware.trailing_slash import (
    register_trailing_slash_middleware
)

from backend.api.v1.routes.devices import router as devices_router
from backend.api.v1.routes.interfaces import router as interfaces_router
from backend.api.v1.routes.network import router as network_router
from backend.api.v1.routes.firewall import router as firewall_router
from backend.api.v1.routes.dhcp import router as dhcp_router
from backend.api.v1.routes.network_configuration import router as network_configuration_router
from backend.api.v1.routes.device_access_rules import (
    router as device_access_rules_router
)
from backend.api.v1.routes.auth_router import (
    router as auth_router
)
from backend.api.v1.routes.users import (
    router as users_router
)
from backend.api.v1.routes.security_rules import (
    router as security_rules_router
)

from backend.api.v1.routes.system import router as system_router
from backend.api.v1.routes.zones import router as zones_router
from backend.api.v1.routes.schedules import router as schedules_router
from backend.api.v1.routes.dns import router as dns_router
from backend.api.v1.routes.network_maintenance import router as network_maintenance_router
from backend.api.v1.routes.navigation_logs import router as navigation_logs_router
from backend.api.v1.routes.encrypted_dns import router as encrypted_dns_router
from backend.api.v1.routes.interface_registry import router as interface_registry_router
from backend.api.v1.routes.protection import router as protection_router
from backend.api.v1.routes.port_forwards import router as port_forwards_router
from backend.api.v1.routes.vpn import router as vpn_router
from backend.api.v1.routes.notifications import router as notifications_router
from backend.api.v1.routes.email_settings import router as email_settings_router
from backend.api.v1.routes.backups import router as backups_router
from backend.api.v1.routes.cloud_storage import router as cloud_storage_router
from backend.api.v1.routes.wan_monitor import router as wan_monitor_router
from backend.api.v1.routes.domain_groups import router as domain_groups_router
from backend.api.v1.routes.organization import router as organization_router
from backend.api.v1.routes.alerts import router as alerts_router
from backend.api.v1.routes.audit import router as audit_router
from backend.api.v1.routes.monitoring import router as monitoring_router
from backend.api.v1.routes.integration import router as integration_router
from backend.api.v1.routes.reports import router as reports_router
from backend.api.v1.routes.content_categories import router as content_categories_router
from backend.api.v1.routes.config_revisions import router as config_revisions_router
from backend.api.v1.routes.groups import router as groups_router
from backend.api.v1.routes.bandwidth import router as bandwidth_router
from backend.api.v1.routes.ips import router as ips_router

def create_app():

    app = FastAPI(
        title="STEPAD NSP API",
        version="1.0.0"
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=Settings.CORS_ORIGINS,
        allow_credentials=False,
        allow_methods=[
            "GET",
            "POST",
            "PUT",
            "PATCH",
            "DELETE",
            "OPTIONS"
        ],
        allow_headers=[
            "Authorization",
            "Content-Type"
        ],
    )

    register_trailing_slash_middleware(app)

    app.include_router(devices_router, prefix="/api/v1")
    app.include_router(interfaces_router, prefix="/api/v1")
    app.include_router(network_router, prefix="/api/v1")
    app.include_router(firewall_router, prefix="/api/v1")
    app.include_router(dhcp_router, prefix="/api/v1")
    app.include_router(network_configuration_router, prefix="/api/v1")
    app.include_router(device_access_rules_router, prefix="/api/v1")
    app.include_router(auth_router, prefix="/api/v1")
    app.include_router(users_router,prefix="/api/v1")
    app.include_router(security_rules_router, prefix="/api/v1")
    app.include_router(system_router, prefix="/api/v1")
    app.include_router(zones_router, prefix="/api/v1")
    app.include_router(schedules_router, prefix="/api/v1")
    app.include_router(dns_router, prefix="/api/v1")
    app.include_router(network_maintenance_router, prefix="/api/v1")
    app.include_router(navigation_logs_router, prefix="/api/v1")
    app.include_router(encrypted_dns_router, prefix="/api/v1")
    app.include_router(interface_registry_router, prefix="/api/v1")
    app.include_router(protection_router, prefix="/api/v1")
    app.include_router(port_forwards_router, prefix="/api/v1")
    app.include_router(vpn_router, prefix="/api/v1")
    app.include_router(notifications_router, prefix="/api/v1")
    app.include_router(email_settings_router, prefix="/api/v1")
    app.include_router(backups_router, prefix="/api/v1")
    app.include_router(cloud_storage_router, prefix="/api/v1")
    app.include_router(wan_monitor_router, prefix="/api/v1")
    app.include_router(domain_groups_router, prefix="/api/v1")
    app.include_router(organization_router, prefix="/api/v1")
    app.include_router(alerts_router, prefix="/api/v1")
    app.include_router(audit_router, prefix="/api/v1")
    app.include_router(monitoring_router, prefix="/api/v1")
    app.include_router(integration_router, prefix="/api/v1")
    app.include_router(reports_router, prefix="/api/v1")
    app.include_router(content_categories_router, prefix="/api/v1")
    app.include_router(config_revisions_router, prefix="/api/v1")
    app.include_router(groups_router, prefix="/api/v1")

    app.include_router(bandwidth_router, prefix="/api/v1")

    app.include_router(ips_router, prefix="/api/v1")

    _mount_frontend(app)

    return app


def _mount_frontend(
    app: FastAPI
):
    """
    Serves the built frontend (frontend/dist) from the same process
    that exposes the API. This is the production serving path: there
    is no dev server on 5173 exposed to the network. Falls back to a
    bare FastAPI app (API only) if the frontend has not been built.
    """

    dist = Path(Settings.FRONTEND_DIST)

    if not (dist / "index.html").exists():

        return

    assets = dist / "assets"

    if assets.exists():

        app.mount(
            "/assets",
            StaticFiles(directory=str(assets)),
            name="assets"
        )

    @app.get("/{full_path:path}")
    def spa(full_path: str):

        # Rutas de API desconocidas deben devolver 404 JSON, nunca el
        # index.html del SPA -- si no, el frontend intenta parsear HTML
        # como JSON ("Unexpected token '<'") sin decir qué falló.
        if full_path.startswith("api/"):

            raise HTTPException(
                status_code=404,
                detail="Not Found"
            )

        candidate = (dist / full_path).resolve()

        if full_path and candidate.is_file():

            return FileResponse(str(candidate))

        return FileResponse(str(dist / "index.html"))