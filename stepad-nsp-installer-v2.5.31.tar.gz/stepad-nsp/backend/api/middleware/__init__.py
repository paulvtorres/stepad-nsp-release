"""FastAPI middleware used by backend.api.app."""
