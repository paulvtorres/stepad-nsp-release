import { useEffect, useState } from "react";

import { getInterfaceDiagnosis } from "../../services/api";

import "./networkDiagnosis.css";


function StatusBadge({ ok, label }) {

    return (
        <span className={`netdiag-badge ${ok ? "ok" : "warn"}`}>
            {label}
        </span>
    );

}


function NetworkDiagnosis({ refreshKey = 0 }) {

    const [diagnosis, setDiagnosis] = useState(null);

    const [loading, setLoading] = useState(true);


    useEffect(() => {

        async function loadDiagnosis() {

            setLoading(true);

            try {

                const data = await getInterfaceDiagnosis();

                setDiagnosis(data);

            } catch (error) {

                console.error(error);

            } finally {

                setLoading(false);

            }

        }

        loadDiagnosis();

    }, [refreshKey]);


    if (loading && !diagnosis) {

        return (
            <section className="netdiag-panel">
                <p className="netdiag-loading">Cargando diagnóstico de red...</p>
            </section>
        );

    }

    if (!diagnosis) {

        return null;

    }


    return (

        <section className="netdiag-panel">

            <div className="netdiag-header">

                <div>
                    <h2>Estado de red</h2>
                    <p>Vista rápida antes de asignar roles WAN/LAN.</p>
                </div>

                <StatusBadge
                    ok={diagnosis.ready}
                    label={diagnosis.ready ? "Listo para operar" : "Configuración pendiente"}
                />

            </div>

            <div className="netdiag-grid">

                <div className="netdiag-card">
                    <span className="netdiag-card-label">Internet (WAN)</span>
                    <StatusBadge
                        ok={diagnosis.wan_detected}
                        label={diagnosis.wan_detected ? "Detectada" : "No detectada"}
                    />
                </div>

                <div className="netdiag-card">
                    <span className="netdiag-card-label">Red interna (LAN)</span>
                    <StatusBadge
                        ok={diagnosis.lan_detected}
                        label={diagnosis.lan_detected ? "Detectada" : "No detectada"}
                    />
                </div>

            </div>

            {
                diagnosis.messages?.length > 0 && (

                    <div className="netdiag-notes">

                        <h3>Observaciones</h3>

                        <ul>
                            {
                                diagnosis.messages.map((message, index) => (
                                    <li key={index}>{message}</li>
                                ))
                            }
                        </ul>

                    </div>

                )
            }

        </section>

    );

}


export default NetworkDiagnosis;
