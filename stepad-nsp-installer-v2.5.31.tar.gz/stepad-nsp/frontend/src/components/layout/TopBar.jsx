import { useEffect, useState } from "react";

import { Link, useNavigate } from "react-router-dom";

import { useAuth } from "../../auth/useAuth";

import { getPendingInterfaceActions, getSystemVersion, getAlertsUnreadCount } from "../../services/api";


function TopBar() {

    const navigate = useNavigate();


    const { user, logout } = useAuth();

    const [pendingInterfaces, setPendingInterfaces] = useState([]);

    const [version, setVersion] = useState(null);

    const [now, setNow] = useState(new Date());

    const [criticalAlerts, setCriticalAlerts] = useState(0);

    useEffect(() => {

        getSystemVersion()

            .then(setVersion)

            .catch(() => {});

    }, []);

    useEffect(() => {

        const t = setInterval(() => setNow(new Date()), 1000);

        return () => clearInterval(t);

    }, []);


    useEffect(() => {

        async function checkPending() {

            try {

                const pending = await getPendingInterfaceActions();

                setPendingInterfaces(pending || []);

            } catch (error) {

                console.error(error);

            }

        }

        checkPending();

        const interval = setInterval(checkPending, 30000);

        return () => clearInterval(interval);

    }, []);


    useEffect(() => {

        async function checkAlerts() {

            try {

                const data = await getAlertsUnreadCount();

                setCriticalAlerts(data?.critical || 0);

            } catch (error) {

                console.error(error);

            }

        }

        checkAlerts();

        const interval = setInterval(checkAlerts, 15000);

        return () => clearInterval(interval);

    }, []);



    return (

        <div className="topbar">


            <div className="brand">

                STEPAD NSP

            </div>



            <div className="status">

                Sistema en línea

                {
                    pendingInterfaces.length > 0 && (

                        <Link
                            to="/network/interfaces"
                            className="interface-alert-badge"
                            title="Hay tarjetas de red que necesitan tu atenci\u00f3n"
                        >

                            ⚠ {pendingInterfaces.length} tarjeta(s) de red requieren atención

                        </Link>

                    )
                }

            </div>



            <div
                className="topbar-version"
                title="Versión instalada"
                style={{
                    fontSize: 13,
                    color: "var(--muted)",
                    marginRight: 12,
                    whiteSpace: "nowrap"
                }}
            >
                {version ? version.version : ""}
            </div>

            <div
                className="topbar-clock"
                title="Hora del equipo (según su zona horaria)"
                style={{
                    fontSize: 13,
                    color: "var(--muted)",
                    marginRight: 12,
                    whiteSpace: "nowrap"
                }}
            >
                {now.toLocaleDateString("es-ES", { weekday: "short", day: "2-digit", month: "short" })}{" "}
                {now.toLocaleTimeString("es-ES")}
            </div>

            <button
                className={`alert-bell ${criticalAlerts > 0 ? "danger" : ""}`}
                onClick={() => navigate("/alerts")}
                title={
                    criticalAlerts > 0
                        ? `${criticalAlerts} alerta(s) crítica(s) sin atender — toca para revisar`
                        : "Ver alertas"
                }
            >
                <svg
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                >
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>

                {
                    criticalAlerts > 0 && (
                        <span className="alert-bell-badge">
                            {criticalAlerts > 99 ? "99+" : criticalAlerts}
                        </span>
                    )
                }
            </button>

            <div className="user-info">


                {
                    user && (

                        <>

                            <div className="user-identity">

                                <span className="user-name">
                                    {user.username}
                                </span>

                                <span className="user-role-badge">
                                    {user.role === "ADMIN" ? "Administrador" : "Operador"}
                                </span>

                            </div>


                            <div className="user-actions">

                                <button
                                    onClick={() => navigate("/change-password")}
                                >

                                    Cambiar contraseña

                                </button>


                                <button
                                    onClick={logout}
                                >

                                    Cerrar sesión

                                </button>

                            </div>

                        </>

                    )
                }


            </div>


        </div>

    );

}


export default TopBar;