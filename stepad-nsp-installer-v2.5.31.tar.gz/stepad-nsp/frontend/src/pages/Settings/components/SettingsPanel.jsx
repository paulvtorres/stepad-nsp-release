/** Layout compartido para pestañas de Ajustes (mismo estilo que Empresa/Notificaciones). */

export function SettingsPanel({
    title,
    lead,
    badge,
    badgeVariant = "",
    error,
    notice,
    children,
    className = "",
}) {

    return (

        <div className={`org-panel ${className}`.trim()}>

            <div className="org-header">

                <div>
                    <h3>{title}</h3>
                    {lead && <p className="org-lead">{lead}</p>}
                </div>

                {badge && (
                    <span className={`org-badge ${badgeVariant}`.trim()}>
                        {badge}
                    </span>
                )}

            </div>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            {children}

        </div>

    );

}


export function SettingsStatusGrid({ children }) {

    return <div className="org-status-grid">{children}</div>;

}


export function SettingsStatusCard({ label, value, meta, variant = "" }) {

    return (

        <div className={`org-status-card ${variant}`.trim()}>

            <span className="org-status-label">{label}</span>

            <strong>{value}</strong>

            {meta && (
                <span className="org-status-meta">{meta}</span>
            )}

        </div>

    );

}


export function SettingsBlock({ title, hint, children, first = false }) {

    return (

        <div className={`org-section${first ? " org-section-first" : ""}`}>

            {title && <h4>{title}</h4>}

            {hint && <p className="org-section-hint">{hint}</p>}

            {children}

        </div>

    );

}


export function SettingsActions({ children }) {

    return <div className="org-actions">{children}</div>;

}
