import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getConfigRevisions,
    captureConfigRevision,
    restoreConfigRevision,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function RevisionSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [revisions, setRevisions] = useState([]);

    const [label, setLabel] = useState("");

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);

    const [loading, setLoading] = useState(true);


    function load() {

        getConfigRevisions()

            .then((data) => setRevisions(data || []))

            .catch((err) => setError(err.message))

            .finally(() => setLoading(false));

    }


    useEffect(() => {

        let cancelled = false;

        getConfigRevisions()

            .then((data) => {
                if (!cancelled) setRevisions(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleCapture() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await captureConfigRevision(label || "Revisión manual");

            setLabel("");

            load();

            setNotice("Revisión de configuración guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRestore(revision) {

        setError(null);

        setNotice(null);

        const ok = window.confirm(
            `¿Restaurar la configuración a la revisión #${revision.id} ` +
            `("${revision.label}")? Se reemplazarán reglas, VPN, DMZ y ajustes.`
        );

        if (!ok) return;

        setBusy(true);

        try {

            const result = await restoreConfigRevision(revision.id);

            setNotice(
                `Configuración restaurada (${(result.restored || []).join(", ")}).`
            );

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const latest = revisions[0];

    const badge = loading
        ? "Cargando…"
        : `${revisions.length} guardada${revisions.length !== 1 ? "s" : ""}`;


    return (

        <SettingsPanel
            title="Revisión de configuración"
            lead="Guarda una foto de la configuración actual y, si algo sale mal, restáurala. Incluye reglas de bloqueo, peers VPN, reenvíos DMZ y ajustes."
            badge={badge}
            badgeVariant={revisions.length > 0 ? "complete" : "empty"}
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Revisiones"
                    value={loading ? "—" : String(revisions.length)}
                    meta="Puntos de restauración disponibles"
                />

                <SettingsStatusCard
                    label="Última"
                    value={latest
                        ? new Date(latest.created_at).toLocaleDateString("es-ES")
                        : "—"}
                    meta={latest ? latest.label : "Sin capturas aún"}
                />

            </SettingsStatusGrid>

            {
                isAdmin && (
                    <SettingsBlock title="Capturar ahora" first>

                        <div className="org-form-grid">

                            <label className="org-wide">
                                Etiqueta (opcional)
                                <input
                                    type="text"
                                    value={label}
                                    onChange={(e) => setLabel(e.target.value)}
                                    placeholder="ej. antes de cambiar filtrado"
                                />
                            </label>

                        </div>

                        <SettingsActions>

                            <button
                                className="primary-button"
                                onClick={handleCapture}
                                disabled={busy}
                            >
                                {busy ? "Guardando…" : "Guardar revisión ahora"}
                            </button>

                        </SettingsActions>

                    </SettingsBlock>
                )
            }

            <SettingsBlock title="Historial de revisiones">

                <div className="org-table-wrap">

                    <table className="org-table">

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Etiqueta</th>
                                <th>Usuario</th>
                                <th>Fecha</th>
                                {isAdmin && <th>Acciones</th>}
                            </tr>
                        </thead>

                        <tbody>

                            {
                                revisions.length === 0 && (
                                    <tr>
                                        <td colSpan={isAdmin ? 5 : 4} className="org-table-empty">
                                            Sin revisiones guardadas.
                                        </td>
                                    </tr>
                                )
                            }

                            {
                                revisions.map((revision) => (
                                    <tr key={revision.id}>

                                        <td>#{revision.id}</td>

                                        <td>{revision.label}</td>

                                        <td>{revision.username || "—"}</td>

                                        <td>{new Date(revision.created_at).toLocaleString("es-ES")}</td>

                                        {
                                            isAdmin && (
                                                <td>
                                                    <button
                                                        className="secondary-button small"
                                                        onClick={() => handleRestore(revision)}
                                                        disabled={busy}
                                                    >
                                                        Restaurar
                                                    </button>
                                                </td>
                                            )
                                        }

                                    </tr>
                                ))
                            }

                        </tbody>

                    </table>

                </div>

            </SettingsBlock>

        </SettingsPanel>

    );

}


export default RevisionSection;
