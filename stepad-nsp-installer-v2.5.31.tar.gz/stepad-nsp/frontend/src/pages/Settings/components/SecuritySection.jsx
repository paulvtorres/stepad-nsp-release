import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    mfaSetup,
    mfaConfirm,
    mfaDisable,
    getRemoteAdmin,
    setRemoteAdmin,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function RemoteAdminPanel() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [enabled, setEnabled] = useState(null);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getRemoteAdmin()

            .then((data) => {
                if (!cancelled) setEnabled(data.enabled);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleToggle() {

        setError(null);

        setNotice(null);

        const next = !enabled;

        const ok = window.confirm(
            next
                ? "¿Exigir VPN para el acceso remoto? La web quedará "
                  + "accesible solo por LAN o VPN desde la WAN."
                : "¿Permitir la web desde la WAN (sin exigir VPN)? Menos seguro."
        );

        if (!ok) return;

        setBusy(true);

        try {

            const result = await setRemoteAdmin(next);

            setEnabled(result.enabled);

            setNotice(result.message || "Configuración aplicada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const badge = enabled == null
        ? "Cargando…"
        : enabled
            ? "VPN obligatoria"
            : "WAN permitida";

    const badgeVariant = enabled == null
        ? ""
        : enabled
            ? "complete"
            : "partial";


    return (

        <SettingsPanel
            title="Acceso remoto a la web"
            lead="Exige la VPN (WireGuard) para entrar a la web desde fuera de la red local. Con esto activado, la interfaz solo es accesible por LAN o por túnel VPN."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Política WAN"
                    value={enabled == null ? "—" : enabled ? "Bloqueada sin VPN" : "Web abierta"}
                    meta="Acceso a la consola desde Internet"
                    variant={enabled ? "ok" : "warn"}
                />

                <SettingsStatusCard
                    label="Recomendación"
                    value="VPN + MFA"
                    meta="Combinar con autenticación en dos pasos"
                />

            </SettingsStatusGrid>

            {
                enabled != null && isAdmin && (
                    <SettingsBlock title="Configuración" first>

                        <label className="org-checkbox-row">
                            <input
                                type="checkbox"
                                checked={enabled}
                                onChange={handleToggle}
                                disabled={busy}
                            />
                            Exigir VPN para acceso remoto (bloquear la web desde WAN)
                        </label>

                    </SettingsBlock>
                )
            }

            {
                enabled != null && !isAdmin && (
                    <p className="org-readonly">
                        Solo un administrador puede cambiar esta política.
                    </p>
                )
            }

        </SettingsPanel>

    );

}


function MfaPanel() {

    const {
        mfaEnabled,
        setMfaEnabled,
        mfaMandatory,
        user,
        setMfaSetupRequired,
    } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const mfaBlocked = mfaMandatory && isAdmin;

    const [setup, setSetup] = useState(null);

    const [code, setCode] = useState("");

    const [currentPassword, setCurrentPassword] = useState("");

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);


    async function handleSetup() {

        setError(null);

        setBusy(true);

        try {

            const data = await mfaSetup();

            setSetup(data);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleConfirm() {

        setError(null);

        setBusy(true);

        try {

            await mfaConfirm(code.trim());

            setMfaEnabled(true);

            setMfaSetupRequired(false);

            setSetup(null);

            setCode("");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDisable() {

        setError(null);

        setBusy(true);

        try {

            await mfaDisable(currentPassword);

            setMfaEnabled(false);

            setCurrentPassword("");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const badge = mfaEnabled ? "Activa" : "Inactiva";

    const badgeVariant = mfaEnabled ? "complete" : "empty";


    return (

        <SettingsPanel
            title="Autenticación en dos pasos (MFA)"
            lead="Añade una segunda verificación con una app de autenticación (Google Authenticator, Authy, etc.) al iniciar sesión."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Estado"
                    value={mfaEnabled ? "Protegida" : "Sin MFA"}
                    meta={user?.username || "Usuario actual"}
                    variant={mfaEnabled ? "ok" : "warn"}
                />

                <SettingsStatusCard
                    label="Política admin"
                    value={mfaMandatory ? "Obligatoria" : "Opcional"}
                    meta={mfaBlocked ? "No puedes desactivarla" : "Puedes activar o desactivar"}
                />

            </SettingsStatusGrid>

            {mfaEnabled ? (

                <SettingsBlock title="Desactivar MFA" first>

                    {
                        mfaBlocked && (
                            <div className="org-warning-banner">
                                <strong>MFA es obligatoria</strong> para las
                                cuentas de administrador: no puedes desactivarla.
                            </div>
                        )
                    }

                    <div className="org-form-grid">

                        <label className="org-wide">
                            Contraseña actual para desactivar
                            <input
                                type="password"
                                value={currentPassword}
                                onChange={(e) => setCurrentPassword(e.target.value)}
                                placeholder="••••••••"
                            />
                        </label>

                    </div>

                    <SettingsActions>

                        <button
                            className="danger-button"
                            onClick={handleDisable}
                            disabled={busy || !currentPassword || mfaBlocked}
                        >
                            {busy ? "Desactivando…" : "Desactivar MFA"}
                        </button>

                    </SettingsActions>

                </SettingsBlock>

            ) : setup ? (

                <SettingsBlock title="Configurar app autenticadora" first>

                    <p className="org-section-hint">
                        Escanea o introduce esta clave en tu app de autenticación:
                    </p>

                    <div className="org-mfa-secret">
                        {setup.secret}
                    </div>

                    <details style={{ marginBottom: 12 }}>

                        <summary>URI manual</summary>

                        <code style={{ fontSize: ".8rem", wordBreak: "break-all" }}>
                            {setup.otpauth_uri}
                        </code>

                    </details>

                    <div className="org-form-grid">

                        <label>
                            Código de verificación
                            <input
                                type="text"
                                inputMode="numeric"
                                value={code}
                                onChange={(e) => setCode(e.target.value)}
                                placeholder="123456"
                            />
                        </label>

                    </div>

                    <SettingsActions>

                        <button
                            className="secondary-button"
                            onClick={() => setSetup(null)}
                            disabled={busy}
                        >
                            Cancelar
                        </button>

                        <button
                            className="primary-button"
                            onClick={handleConfirm}
                            disabled={busy || !code}
                        >
                            {busy ? "Verificando…" : "Confirmar y activar"}
                        </button>

                    </SettingsActions>

                </SettingsBlock>

            ) : (

                <SettingsBlock first>

                    <SettingsActions>

                        <button
                            className="primary-button"
                            onClick={handleSetup}
                            disabled={busy}
                        >
                            {busy ? "Preparando…" : "Activar MFA"}
                        </button>

                    </SettingsActions>

                </SettingsBlock>

            )}

        </SettingsPanel>

    );

}


function SecuritySection() {

    return (

        <div className="settings-stack">

            <RemoteAdminPanel />

            <MfaPanel />

        </div>

    );

}


export default SecuritySection;
