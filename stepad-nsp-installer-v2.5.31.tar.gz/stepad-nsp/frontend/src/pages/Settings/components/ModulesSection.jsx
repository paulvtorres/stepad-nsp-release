import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import { getModules, setModules } from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
} from "./SettingsPanel";

import "../settings.css";


function ModulesSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [modules, setModules] = useState([]);

    const [busy, setBusy] = useState(false);

    const [loading, setLoading] = useState(true);

    const [notice, setNotice] = useState(null);

    const [error, setError] = useState(null);


    useEffect(() => {

        let cancelled = false;

        getModules()

            .then((data) => {
                if (!cancelled) setModules(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleToggle(module) {

        const next = modules.map((m) =>
            m.key === module.key ? { ...m, enabled: !m.enabled } : m
        );

        const enabledKeys = next
            .filter((m) => m.enabled)
            .map((m) => m.key);

        setBusy(true);

        setError(null);

        setNotice(null);

        try {

            const saved = await setModules(enabledKeys);

            setModules(saved || next);

            setNotice("Servicios actualizados.");

        } catch (err) {

            setModules(modules);

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const enabledCount = modules.filter((m) => m.enabled).length;

    const badgeVariant = loading
        ? ""
        : enabledCount === 0
            ? "empty"
            : enabledCount === modules.length
                ? "complete"
                : "partial";

    const badge = loading
        ? "Cargando…"
        : `${enabledCount} de ${modules.length} activos`;


    return (

        <SettingsPanel
            title="Servicios activados"
            lead="Activa solo los servicios que el cliente contrató. El hardware se evalúa según los servicios activados (en Equipo se avisará si falta capacidad)."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Servicios activos"
                    value={loading ? "—" : String(enabledCount)}
                    meta="Contratados y habilitados en este equipo"
                    variant={enabledCount > 0 ? "ok" : "warn"}
                />

                <SettingsStatusCard
                    label="Disponibles"
                    value={loading ? "—" : String(modules.length)}
                    meta="Módulos instalados en la plataforma"
                />

                <SettingsStatusCard
                    label="Permisos"
                    value={isAdmin ? "Administrador" : "Solo lectura"}
                    meta={isAdmin ? "Puedes activar o desactivar servicios" : "Contacta a un administrador"}
                    variant={isAdmin ? "ok" : "muted"}
                />

            </SettingsStatusGrid>

            <SettingsBlock title="Módulos" first>

                {
                    loading && (
                        <p className="org-section-hint">Cargando servicios…</p>
                    )
                }

                {
                    !loading && modules.length === 0 && (
                        <p className="org-section-hint">No hay módulos configurados.</p>
                    )
                }

                <div className="modules-list">

                    {
                        modules.map((module) => (

                            <label key={module.key} className="module-item">

                                <input
                                    type="checkbox"
                                    checked={module.enabled}
                                    disabled={busy || !isAdmin}
                                    onChange={() => handleToggle(module)}
                                />

                                <div className="module-info">

                                    <strong>{module.name}</strong>

                                    <div className="module-meta">
                                        {module.description}
                                    </div>

                                    <div className="module-req">
                                        Requiere: mín. {module.min_cores} núcleos
                                        {" · "}{module.min_ram_mb / 1024} GB RAM
                                        {" · rec. "}{module.rec_cores} núcleos
                                        {" / "}{module.rec_ram_mb / 1024} GB
                                    </div>

                                </div>

                            </label>

                        ))
                    }

                </div>

            </SettingsBlock>

        </SettingsPanel>

    );

}


export default ModulesSection;
