import { useEffect, useRef, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getTemporaryLanIpStatus,
    startTemporaryLanIp,
    revertTemporaryLanIp,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function formatRemaining(seconds) {

    const minutes = Math.floor(seconds / 60);

    const secs = seconds % 60;

    return `${minutes}:${secs.toString().padStart(2, "0")}`;

}


function MaintenanceSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState({ active: false });

    const [temporaryIp, setTemporaryIp] = useState("192.168.0.100");

    const [temporaryPrefix, setTemporaryPrefix] = useState(24);

    const [durationMinutes, setDurationMinutes] = useState(10);

    const [showConfirm, setShowConfirm] = useState(false);

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);

    const pollRef = useRef(null);


    useEffect(() => {

        loadStatus();

        pollRef.current = setInterval(loadStatus, 5000);

        return () => clearInterval(pollRef.current);

    }, []);


    async function loadStatus() {

        try {

            const data = await getTemporaryLanIpStatus();

            setStatus(data);

        } catch (err) {

            console.error(err);

        }

    }


    async function handleConfirmStart() {

        setBusy(true);

        setError(null);

        try {

            await startTemporaryLanIp({
                temporary_ip: temporaryIp,
                temporary_prefix: Number(temporaryPrefix),
                duration_minutes: Number(durationMinutes),
            });

            setShowConfirm(false);

            await loadStatus();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRevertNow() {

        setBusy(true);

        setError(null);

        try {

            await revertTemporaryLanIp();

            await loadStatus();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const badge = status.active
        ? "Activo"
        : "Inactivo";

    const badgeVariant = status.active ? "partial" : "complete";


    return (

        <SettingsPanel
            title="Mantenimiento de red"
            lead="Cambia temporalmente la IP LAN del NSP para acceder a dispositivos en otra subred — por ejemplo, la IP de gestión por defecto de un switch."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
        >

            <div className="org-danger-banner">
                Mientras esté activo, <strong>toda la red se queda sin DHCP/DNS</strong> —
                ningún dispositivo podrá navegar hasta que termine el tiempo o lo reviertas manualmente.
                Avisa a los usuarios antes de activarlo.
            </div>

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Estado"
                    value={status.active ? "IP temporal activa" : "Red normal"}
                    meta={status.active
                        ? `Revierte en ${formatRemaining(status.remaining_seconds || 0)}`
                        : "Sin cambios pendientes"}
                    variant={status.active ? "warn" : "ok"}
                />

                {
                    status.active && (
                        <>
                            <SettingsStatusCard
                                label="IP temporal"
                                value={`${status.temporary_ip}/${status.temporary_prefix}`}
                            />

                            <SettingsStatusCard
                                label="Volverá a"
                                value={`${status.original_ip}/${status.original_prefix}`}
                            />
                        </>
                    )
                }

            </SettingsStatusGrid>

            {
                status.active ? (

                    <SettingsBlock title="Sesión activa" first>

                        <div className="org-countdown">
                            <span className="org-status-label">Tiempo restante</span>
                            <span className="org-countdown-time">
                                {formatRemaining(status.remaining_seconds || 0)}
                            </span>
                        </div>

                        {
                            isAdmin && (
                                <SettingsActions>

                                    <button
                                        className="danger-button"
                                        onClick={handleRevertNow}
                                        disabled={busy}
                                    >
                                        {busy ? "Revirtiendo…" : "Revertir ahora"}
                                    </button>

                                </SettingsActions>
                            )
                        }

                    </SettingsBlock>

                ) : (

                    <SettingsBlock
                        title="Cambio temporal de IP LAN"
                        hint="Uso típico: acceder al switch administrable para reconfigurarlo."
                        first
                    >

                        <div className="org-form-grid">

                            <label>
                                IP temporal
                                <input
                                    type="text"
                                    value={temporaryIp}
                                    disabled={!isAdmin}
                                    onChange={(e) => setTemporaryIp(e.target.value)}
                                    placeholder="ej. 192.168.0.100"
                                />
                            </label>

                            <label>
                                Prefijo (CIDR)
                                <input
                                    type="number"
                                    value={temporaryPrefix}
                                    disabled={!isAdmin}
                                    onChange={(e) => setTemporaryPrefix(e.target.value)}
                                    min={8}
                                    max={30}
                                />
                            </label>

                            <label>
                                Duración (minutos, máx. 15)
                                <input
                                    type="number"
                                    value={durationMinutes}
                                    disabled={!isAdmin}
                                    onChange={(e) => setDurationMinutes(e.target.value)}
                                    min={1}
                                    max={15}
                                />
                            </label>

                        </div>

                        {
                            isAdmin && (
                                <SettingsActions>

                                    <button
                                        className="primary-button"
                                        onClick={() => setShowConfirm(true)}
                                        disabled={!temporaryIp || busy}
                                    >
                                        Activar cambio temporal
                                    </button>

                                </SettingsActions>
                            )
                        }

                    </SettingsBlock>

                )
            }

            {
                showConfirm && (

                    <div className="confirm-overlay">

                        <div className="confirm-dialog">

                            <h4>¿Confirmas el cambio?</h4>

                            <p>
                                La red va a quedar <strong>sin internet</strong> por
                                hasta <strong>{durationMinutes} minutos</strong>. La IP
                                LAN pasará a{" "}
                                <strong>{temporaryIp}/{temporaryPrefix}</strong>.
                            </p>

                            <p>
                                Se revierte sola al cumplirse el tiempo, incluso si
                                cierras esta pantalla o el backend se reinicia.
                            </p>

                            <SettingsActions>

                                <button
                                    className="secondary-button"
                                    onClick={() => setShowConfirm(false)}
                                    disabled={busy}
                                >
                                    Cancelar
                                </button>

                                <button
                                    className="danger-button"
                                    onClick={handleConfirmStart}
                                    disabled={busy}
                                >
                                    {busy ? "Aplicando…" : "Sí, cortar la red y continuar"}
                                </button>

                            </SettingsActions>

                        </div>

                    </div>

                )
            }

        </SettingsPanel>

    );

}


export default MaintenanceSection;
