import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getEmailSettings,
    saveEmailSettings,
    testEmailSettings,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import {
    EMAIL_PROVIDERS,
    findEmailProvider,
    defaultProviderForm,
} from "../constants/emailProviders";

import "../settings.css";


const PROVIDER_ICONS = {
    gmail: "G",
    outlook: "O",
    office365: "365",
    yahoo: "Y!",
    custom: "⚙",
};


function EmailSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState(() => defaultProviderForm("gmail"));

    const [status, setStatus] = useState({
        config_ready: false,
        config_issues: [],
        has_password: false,
        provider_hint: findEmailProvider("gmail")?.hint || "",
        provider_label: findEmailProvider("gmail")?.label || "",
        updated_at: null,
        load_error: null,
    });

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);

    const [testing, setTesting] = useState(false);

    const [testFeedback, setTestFeedback] = useState(null);

    const [loading, setLoading] = useState(true);

    const [testRecipient, setTestRecipient] = useState("");


    function applySettings(data) {

        const provider = data.provider || "gmail";

        const preset = findEmailProvider(provider);

        setForm({
            provider,
            smtp_host: data.smtp_host || preset?.smtp_host || "",
            smtp_port: data.smtp_port || preset?.smtp_port || 587,
            account_email: data.account_email || "",
            smtp_password: "",
        });

        setTestRecipient((current) =>
            current.trim() || data.account_email || ""
        );

        setStatus({
            config_ready: Boolean(data.config_ready),
            config_issues: data.config_issues || [],
            has_password: Boolean(data.has_password),
            provider_hint: data.provider_hint || preset?.hint || "",
            provider_label: data.provider_label || preset?.label || "",
            updated_at: data.updated_at || null,
            load_error: null,
        });

    }


    useEffect(() => {

        let cancelled = false;

        getEmailSettings()

            .then((data) => {
                if (!cancelled) applySettings(data);
            })

            .catch((err) => {

                if (cancelled) return;

                const message = err.message || "No se pudo cargar la configuración.";

                setStatus((previous) => ({
                    ...previous,
                    load_error: message,
                }));

                const hint = message.includes("Failed to fetch")
                    ? (
                        "No se pudo contactar al backend. En desarrollo: "
                        + "reinicie el servicio (sudo systemctl restart stepad-nsp) "
                        + "y, si usa npm run dev, verifique frontend/.env.development "
                        + "(proxy a https://127.0.0.1:8443)."
                    )
                    : "Si persiste, actualice y reinicie el NSP.";

                setError(`${message}. ${hint}`);

            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => { cancelled = true; };

    }, []);


    function selectProvider(key) {

        const preset = findEmailProvider(key);

        if (!preset) return;

        setForm((previous) => ({
            ...previous,
            provider: key,
            smtp_host: preset.smtp_host || previous.smtp_host,
            smtp_port: preset.smtp_port || 587,
        }));

        setStatus((previous) => ({
            ...previous,
            provider_hint: preset.hint || "",
            provider_label: preset.label || "",
        }));

    }


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const payload = {
                provider: form.provider,
                account_email: form.account_email.trim(),
                smtp_password: form.smtp_password || null,
            };

            if (form.provider === "custom") {

                payload.smtp_host = form.smtp_host;

                payload.smtp_port = Number(form.smtp_port);

            }

            const saved = await saveEmailSettings(payload);

            applySettings(saved);

            setNotice("Cuenta de correo guardada.");

        } catch (err) {

            setError(err.message || "No se pudo guardar.");

        } finally {

            setBusy(false);

        }

    }


    async function handleTest() {

        setError(null);

        setNotice(null);

        setTestFeedback(null);

        const recipient = testRecipient.trim();

        if (!recipient) {

            setTestFeedback({
                type: "error",
                message: "Indique a qué correo enviar la prueba.",
            });

            return;

        }

        setTesting(true);

        try {

            const result = await testEmailSettings(recipient);

            if (result.success === false) {

                setTestFeedback({
                    type: "error",
                    message: result.message || "No se pudo enviar la prueba.",
                });

                return;

            }

            setTestFeedback({
                type: "ok",
                message: result.message || "Correo de prueba enviado.",
            });

        } catch (err) {

            setTestFeedback({
                type: "error",
                message: err.message || "No se pudo enviar la prueba.",
            });

        } finally {

            setTesting(false);

        }

    }


    const badge = loading
        ? "Cargando…"
        : status.config_ready
            ? "Lista"
            : "Incompleta";

    const badgeVariant = loading
        ? ""
        : status.config_ready
            ? "complete"
            : "empty";

    const activeHint = status.provider_hint
        || findEmailProvider(form.provider)?.hint
        || "";


    return (

        <SettingsPanel
            title="Cuenta de correo"
            lead="Configure una sola cuenta SMTP para todos los envíos del NSP: reportes automáticos, alertas de seguridad, respaldos por email y avisos del sistema."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Proveedor"
                    value={loading ? "—" : (status.provider_label || form.provider)}
                    meta="Servidor SMTP preconfigurado"
                />

                <SettingsStatusCard
                    label="Cuenta"
                    value={loading ? "—" : (form.account_email || "Sin configurar")}
                    meta="Usuario y remitente"
                    variant={form.account_email ? "ok" : "warn"}
                />

                <SettingsStatusCard
                    label="Estado"
                    value={status.config_ready ? "Operativa" : "Pendiente"}
                    meta={
                        status.config_ready
                            ? "Lista para enviar correos"
                            : (status.config_issues || []).join(", ") || "Complete los datos"
                    }
                    variant={status.config_ready ? "ok" : "warn"}
                />

            </SettingsStatusGrid>

            <SettingsBlock title="Seleccione su proveedor" first>

                <div className="email-provider-grid">

                    {
                        EMAIL_PROVIDERS.map((item) => (

                            <button
                                key={item.key}
                                type="button"
                                className={`email-provider-card ${form.provider === item.key ? "active" : ""}`}
                                disabled={busy}
                                onClick={() => selectProvider(item.key)}
                            >
                                <span className="email-provider-icon">
                                    {PROVIDER_ICONS[item.key] || "@"}
                                </span>
                                <span className="email-provider-name">
                                    {item.label.split(" / ")[0]}
                                </span>
                            </button>

                        ))
                    }

                </div>

                {
                    activeHint && (
                        <p className="org-section-hint">{activeHint}</p>
                    )
                }

                {
                    form.provider !== "custom" && form.smtp_host && (
                        <p className="org-readonly">
                            Servidor: <strong>{form.smtp_host}</strong>
                            {" · "}Puerto: <strong>{form.smtp_port}</strong>
                        </p>
                    )
                }

            </SettingsBlock>

            <SettingsBlock title="Credenciales">

                <div className="org-form-grid">

                    <label className="org-wide">
                        Correo de la cuenta
                        <input
                            type="email"
                            value={form.account_email}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, account_email: e.target.value })
                            }
                            placeholder="notificaciones@empresa.com"
                        />
                    </label>

                    <label className="org-wide">
                        Contraseña
                        <input
                            type="password"
                            value={form.smtp_password}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, smtp_password: e.target.value })
                            }
                            placeholder={
                                status.has_password
                                    ? "•••••••• (dejar vacío = no cambiar)"
                                    : "Contraseña o contraseña de aplicación"
                            }
                        />
                    </label>

                    {
                        form.provider === "custom" && (
                            <>
                                <label>
                                    Servidor SMTP
                                    <input
                                        type="text"
                                        value={form.smtp_host}
                                        disabled={!isAdmin}
                                        onChange={(e) =>
                                            setForm({ ...form, smtp_host: e.target.value })
                                        }
                                        placeholder="mail.empresa.com"
                                    />
                                </label>

                                <label>
                                    Puerto
                                    <input
                                        type="number"
                                        value={form.smtp_port}
                                        disabled={!isAdmin}
                                        onChange={(e) =>
                                            setForm({ ...form, smtp_port: e.target.value })
                                        }
                                        placeholder="587"
                                    />
                                </label>
                            </>
                        )
                    }

                </div>

            </SettingsBlock>

            <SettingsBlock title="Usado por">

                <ul className="email-usage-list">
                    <li>Reportes automáticos de Historial DNS</li>
                    <li>Alertas críticas del IPS y amenazas</li>
                    <li>Respaldos cifrados por correo</li>
                    <li>Avisos de monitoreo WAN y fallos en la nube</li>
                    <li>Recordatorios de revisión de logs</li>
                </ul>

            </SettingsBlock>

            <SettingsBlock title="Prueba de envío">

                <div className="org-form-grid">

                    <label className="org-wide">
                        Enviar prueba a
                        <input
                            type="email"
                            value={testRecipient}
                            disabled={!isAdmin || busy || testing}
                            onChange={(e) => setTestRecipient(e.target.value)}
                            placeholder="destino@empresa.com"
                        />
                    </label>

                </div>

                <p className="org-section-hint">
                    El mensaje de prueba se envía a esta dirección usando la
                    cuenta SMTP configurada arriba (no modifica los
                    destinatarios de notificaciones). Puede tardar hasta 30 s.
                </p>

                {
                    testing && (
                        <p className="org-section-hint">
                            Enviando correo de prueba…
                        </p>
                    )
                }

                {
                    testFeedback?.type === "error" && (
                        <div className="maintenance-error">{testFeedback.message}</div>
                    )
                }

                {
                    testFeedback?.type === "ok" && (
                        <div className="notification-ok">{testFeedback.message}</div>
                    )
                }

            </SettingsBlock>

            <SettingsActions>

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={busy || testing || !isAdmin || !form.account_email.trim()}
                >
                    {busy ? "Guardando…" : "Guardar cuenta"}
                </button>

                <button
                    className="secondary-button"
                    onClick={handleTest}
                    disabled={busy || testing || !isAdmin || !testRecipient.trim()}
                >
                    {testing ? "Enviando…" : "Enviar correo de prueba"}
                </button>

            </SettingsActions>

            {
                !isAdmin && (
                    <p className="org-readonly">
                        Solo administradores pueden guardar la cuenta de correo.
                    </p>
                )
            }

        </SettingsPanel>

    );

}


export default EmailSection;
