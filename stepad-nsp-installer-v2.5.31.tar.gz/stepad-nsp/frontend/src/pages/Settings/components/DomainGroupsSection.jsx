import { useEffect, useState } from "react";

import {
    getDomainGroups,
    createDomainGroup,
    deleteDomainGroup,
    addDomainGroupDomain,
    removeDomainGroupDomain,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function DomainGroupsSection() {

    const [groups, setGroups] = useState([]);

    const [newName, setNewName] = useState("");

    const [newDomain, setNewDomain] = useState("");

    const [activeGroupId, setActiveGroupId] = useState(null);

    const [busy, setBusy] = useState(false);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);


    async function load() {

        try {

            setGroups(await getDomainGroups() || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => { load(); }, []);


    async function handleCreateGroup() {

        if (!newName.trim()) return;

        setBusy(true);

        setError(null);

        try {

            await createDomainGroup(newName.trim());

            setNewName("");

            await load();

            setNotice("Grupo creado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleAddDomain(groupId) {

        if (!newDomain.trim()) return;

        setBusy(true);

        setError(null);

        try {

            await addDomainGroupDomain(groupId, newDomain.trim());

            setNewDomain("");

            setActiveGroupId(null);

            await load();

            setNotice("Dominio agregado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRemoveDomain(groupId, domain) {

        if (!window.confirm(`¿Quitar ${domain} del grupo?`)) return;

        setBusy(true);

        setError(null);

        try {

            await removeDomainGroupDomain(groupId, domain);

            await load();

            setNotice("Dominio eliminado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDeleteGroup(id, name) {

        if (!window.confirm(`¿Eliminar el grupo "${name}"?`)) return;

        setBusy(true);

        setError(null);

        try {

            await deleteDomainGroup(id);

            await load();

            setNotice("Grupo eliminado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const totalDomains = groups.reduce((sum, g) => sum + (g.domains?.length || 0), 0);

    const badge = loading
        ? "Cargando…"
        : `${groups.length} grupo${groups.length !== 1 ? "s" : ""}`;


    return (

        <SettingsPanel
            title="Grupos de dominios"
            lead="Al bloquear un dominio padre, se agregan automáticamente todos sus dominios relacionados. Mantén estos grupos actualizados cuando descubras CDNs o subdominios nuevos."
            badge={badge}
            badgeVariant={groups.length > 0 ? "complete" : "empty"}
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Grupos"
                    value={loading ? "—" : String(groups.length)}
                    meta="Conjuntos padre → hijos"
                />

                <SettingsStatusCard
                    label="Dominios"
                    value={loading ? "—" : String(totalDomains)}
                    meta="Entradas en todos los grupos"
                />

            </SettingsStatusGrid>

            <SettingsBlock title="Crear grupo" first>

                <div className="org-form-grid">

                    <label className="org-wide">
                        Nombre del grupo
                        <input
                            type="text"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            placeholder='ej. "HBO Max"'
                        />
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleCreateGroup}
                        disabled={busy || !newName.trim()}
                    >
                        Crear grupo
                    </button>

                </SettingsActions>

            </SettingsBlock>

            <SettingsBlock title="Grupos existentes">

                {
                    !loading && groups.length === 0 && (
                        <p className="org-section-hint">No hay grupos de dominios configurados.</p>
                    )
                }

                {
                    groups.map((g) => (
                        <div key={g.id} className="org-group-card">

                            <div className="org-group-card-header">
                                <strong>{g.name}</strong>
                                <button
                                    className="danger-button small"
                                    onClick={() => handleDeleteGroup(g.id, g.name)}
                                    disabled={busy}
                                >
                                    Eliminar
                                </button>
                            </div>

                            {g.description && (
                                <p className="org-section-hint">{g.description}</p>
                            )}

                            <div className="org-tag-list">

                                {
                                    g.domains.map((d) => (
                                        <span key={d} className="org-tag">
                                            {d}
                                            <button
                                                type="button"
                                                onClick={() => handleRemoveDomain(g.id, d)}
                                                title="Quitar dominio"
                                            >
                                                ✕
                                            </button>
                                        </span>
                                    ))
                                }

                                {
                                    g.domains.length === 0 && (
                                        <span className="org-section-hint">Sin dominios todavía.</span>
                                    )
                                }

                            </div>

                            <div className="org-form-grid" style={{ marginTop: 8 }}>

                                <label className="org-wide">
                                    Agregar dominio
                                    <input
                                        type="text"
                                        placeholder="ej. cdn.hbo.com"
                                        value={activeGroupId === g.id ? newDomain : ""}
                                        onFocus={() => setActiveGroupId(g.id)}
                                        onChange={(e) => {
                                            setActiveGroupId(g.id);
                                            setNewDomain(e.target.value);
                                        }}
                                        onKeyDown={(e) => {
                                            if (e.key === "Enter") handleAddDomain(g.id);
                                        }}
                                    />
                                </label>

                            </div>

                            <SettingsActions>

                                <button
                                    className="secondary-button"
                                    onClick={() => handleAddDomain(g.id)}
                                    disabled={busy || activeGroupId !== g.id || !newDomain.trim()}
                                >
                                    Agregar
                                </button>

                            </SettingsActions>

                        </div>
                    ))
                }

            </SettingsBlock>

        </SettingsPanel>

    );

}


export default DomainGroupsSection;
