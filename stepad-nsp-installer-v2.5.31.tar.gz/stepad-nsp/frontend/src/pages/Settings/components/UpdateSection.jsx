import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import { getUpdateStatus, runUpdate } from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function UpdateSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    function load() {

        getUpdateStatus()

            .then(setStatus)

            .catch((err) => setError(err.message));

    }


    useEffect(() => {

        let cancelled = false;

        getUpdateStatus()

            .then((data) => {
                if (!cancelled) setStatus(data);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleUpdate() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const ok = window.confirm(
                "¿Actualizar el software desde origin/main? " +
                "Se descargarán los cambios, se compilará el frontend " +
                "y se reiniciará el servicio."
            );

            if (!ok) return;

            const result = await runUpdate();

            setNotice(result.message || "Actualización iniciada.");

            setTimeout(load, 8000);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const badge = !status
        ? "Cargando…"
        : status.update_available
            ? "Actualización disponible"
            : "Al día";

    const badgeVariant = !status
        ? ""
        : status.update_available
            ? "partial"
            : "complete";


    return (

        <SettingsPanel
            title="Actualizaciones"
            lead="Descarga la última versión disponible y aplícala automáticamente, conservando la configuración y los datos."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
            notice={notice}
        >

            {
                status && (
                    <SettingsStatusGrid>

                        <SettingsStatusCard
                            label="Versión instalada"
                            value={status.version}
                            meta="Build en este equipo"
                        />

                        <SettingsStatusCard
                            label="Última versión"
                            value={status.latest_version || "—"}
                            meta={status.update_available ? "Hay cambios pendientes" : "Sin novedades"}
                            variant={status.update_available ? "warn" : "ok"}
                        />

                        {
                            status.mode !== "package" && (
                                <>
                                    <SettingsStatusCard
                                        label="Commit actual"
                                        value={status.commit?.slice(0, 7) || "—"}
                                        meta={status.commit || ""}
                                    />

                                    <SettingsStatusCard
                                        label="Último en main"
                                        value={status.remote_commit?.slice(0, 7) || "—"}
                                        meta={status.remote_commit || ""}
                                    />
                                </>
                            )
                        }

                    </SettingsStatusGrid>
                )
            }

            {
                status && status.pending_commits && status.pending_commits.length > 0 && (
                    <SettingsBlock title="Cambios pendientes" first>

                        <p className="org-section-hint">
                            {status.pending_commits.length} commit(s) por aplicar.
                            Revisa estos cambios antes de actualizar en producción.
                        </p>

                        <ul className="org-list">

                            {
                                status.pending_commits.map((c) => (
                                    <li key={c.commit} className="org-list-item">

                                        <div className="org-list-item-main">
                                            <span className="org-code">{c.commit.slice(0, 7)}</span>
                                            {" "}{c.message}
                                        </div>

                                    </li>
                                ))
                            }

                        </ul>

                    </SettingsBlock>
                )
            }

            {
                isAdmin && (
                    <SettingsBlock first={!(status?.pending_commits?.length)}>

                        <SettingsActions>

                            <button
                                className="primary-button"
                                onClick={handleUpdate}
                                disabled={busy}
                            >
                                {busy ? "Actualizando…" : "Actualizar ahora"}
                            </button>

                        </SettingsActions>

                    </SettingsBlock>
                )
            }

        </SettingsPanel>

    );

}


export default UpdateSection;
