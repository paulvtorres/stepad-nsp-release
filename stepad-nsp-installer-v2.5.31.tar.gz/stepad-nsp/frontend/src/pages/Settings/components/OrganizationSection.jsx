import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getOrganizationSettings,
    saveOrganizationSettings,
    getSystemVersion,
} from "../../../services/api";

import "../settings.css";


function formatDateTime(value) {

    if (!value) return "—";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return "—";

    return date.toLocaleString();

}


function buildPreviewLines(form) {

    const lines = [];

    if (form.company_name.trim()) {
        lines.push(form.company_name.trim());
    }

    if (form.ruc.trim()) {
        lines.push(`RUC: ${form.ruc.trim()}`);
    }

    if (form.address.trim()) {
        lines.push(form.address.trim());
    }

    const location = [form.city, form.country]
        .map((part) => part.trim())
        .filter(Boolean)
        .join(", ");

    if (location) {
        lines.push(location);
    }

    const contact = [form.phone, form.email]
        .map((part) => part.trim())
        .filter(Boolean);

    if (contact.length) {
        lines.push(contact.join(" · "));
    }

    return lines;

}


function OrganizationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        company_name: "",
        ruc: "",
        address: "",
        phone: "",
        email: "",
        city: "",
        country: "",
    });

    const [status, setStatus] = useState({
        configured: false,
        profile_complete: false,
        completion_percent: 0,
        fields_filled: 0,
        fields_total: 7,
        missing_recommended: [],
        updated_at: null,
    });

    const [version, setVersion] = useState(null);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    function applySettings(data) {

        setForm({
            company_name: data.company_name || "",
            ruc: data.ruc || "",
            address: data.address || "",
            phone: data.phone || "",
            email: data.email || "",
            city: data.city || "",
            country: data.country || "",
        });

        setStatus({
            configured: Boolean(data.configured),
            profile_complete: Boolean(data.profile_complete),
            completion_percent: data.completion_percent ?? 0,
            fields_filled: data.fields_filled ?? 0,
            fields_total: data.fields_total ?? 7,
            missing_recommended: data.missing_recommended || [],
            updated_at: data.updated_at || null,
        });

    }


    useEffect(() => {

        let cancelled = false;

        Promise.all([
            getOrganizationSettings(),
            getSystemVersion().catch(() => null),
        ])

            .then(([orgData, versionData]) => {
                if (cancelled) return;
                applySettings(orgData);
                setVersion(versionData);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleSave() {

        setError(null);

        setNotice(null);

        if (!form.company_name.trim()) {

            setError("El nombre de la empresa es obligatorio.");

            return;

        }

        setBusy(true);

        try {

            const saved = await saveOrganizationSettings({
                company_name: form.company_name.trim(),
                ruc: form.ruc.trim(),
                address: form.address.trim(),
                phone: form.phone.trim(),
                email: form.email.trim(),
                city: form.city.trim(),
                country: form.country.trim(),
            });

            applySettings(saved);

            setNotice("Datos de la empresa guardados correctamente.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const previewLines = buildPreviewLines(form);

    return (

        <div className="org-panel">

            <div className="org-header">

                <div>

                    <h3>Perfil de la empresa</h3>

                    <p className="org-lead">

                        Identidad corporativa usada en reportes Excel,
                        correos automáticos y documentación exportada del
                        NSP. Complete estos datos antes de entregar
                        reportes al dueño o área administrativa.

                    </p>

                </div>

                <div
                    className={`org-badge ${
                        status.profile_complete
                            ? "complete"
                            : status.configured
                                ? "partial"
                                : "empty"
                    }`}
                >
                    {status.profile_complete
                        ? "Perfil completo"
                        : status.configured
                            ? "Perfil parcial"
                            : "Sin configurar"}
                </div>

            </div>


            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}


            <div className="org-status-grid">

                <div className={`org-status-card ${status.configured ? "ok" : "warn"}`}>
                    <span className="org-status-label">Estado</span>
                    <strong>
                        {status.configured
                            ? "Empresa registrada"
                            : "Falta nombre de empresa"}
                    </strong>
                    <span className="org-status-meta">
                        {status.configured
                            ? "Visible en reportes y correos"
                            : "Complete al menos el nombre"}
                    </span>
                </div>

                <div className="org-status-card">
                    <span className="org-status-label">Completitud</span>
                    <strong>{status.completion_percent}%</strong>
                    <span className="org-status-meta">
                        {status.fields_filled} de {status.fields_total} campos
                    </span>
                </div>

                <div className="org-status-card">
                    <span className="org-status-label">Última actualización</span>
                    <strong>{formatDateTime(status.updated_at)}</strong>
                    <span className="org-status-meta">
                        {status.missing_recommended.length
                            ? `Pendiente: ${status.missing_recommended.slice(0, 2).join(", ")}${status.missing_recommended.length > 2 ? "…" : ""}`
                            : "Todos los campos recomendados completos"}
                    </span>
                </div>

                <div className="org-status-card muted">
                    <span className="org-status-label">Sistema NSP</span>
                    <strong>
                        {version?.version || "—"}
                    </strong>
                    <span className="org-status-meta">
                        {version?.commit && version.commit !== "-"
                            ? `Build ${version.commit}`
                            : "Versión instalada"}
                    </span>
                </div>

            </div>


            <div className="org-preview">

                <h4>Vista previa en reportes</h4>

                {
                    previewLines.length ? (
                        <div className="org-preview-box">
                            {previewLines.map((line) => (
                                <div key={line}>{line}</div>
                            ))}
                        </div>
                    ) : (
                        <p className="org-preview-empty">
                            Complete los datos para ver cómo aparecerán
                            en el encabezado de los reportes.
                        </p>
                    )
                }

            </div>


            <div className="org-section">

                <h4>Identificación</h4>

                <div className="org-form-grid">

                    <label className="org-wide">
                        Nombre de la empresa *
                        <input
                            type="text"
                            value={form.company_name}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, company_name: e.target.value })
                            }
                            placeholder="Mi Empresa S.A.C."
                        />
                    </label>

                    <label>
                        RUC / ID fiscal
                        <input
                            type="text"
                            value={form.ruc}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, ruc: e.target.value })
                            }
                            placeholder="20123456789"
                        />
                    </label>

                    <label className="org-wide">
                        Dirección fiscal o comercial
                        <input
                            type="text"
                            value={form.address}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, address: e.target.value })
                            }
                            placeholder="Av. Principal 123, Of. 401"
                        />
                    </label>

                </div>

            </div>


            <div className="org-section">

                <h4>Contacto</h4>

                <div className="org-form-grid">

                    <label>
                        Teléfono
                        <input
                            type="text"
                            value={form.phone}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, phone: e.target.value })
                            }
                            placeholder="+51 999 999 999"
                        />
                    </label>

                    <label>
                        Correo de contacto
                        <input
                            type="email"
                            value={form.email}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, email: e.target.value })
                            }
                            placeholder="contacto@empresa.com"
                        />
                    </label>

                </div>

            </div>


            <div className="org-section">

                <h4>Ubicación</h4>

                <div className="org-form-grid">

                    <label>
                        Ciudad
                        <input
                            type="text"
                            value={form.city}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, city: e.target.value })
                            }
                            placeholder="Lima"
                        />
                    </label>

                    <label>
                        País
                        <input
                            type="text"
                            value={form.country}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, country: e.target.value })
                            }
                            placeholder="Perú"
                        />
                    </label>

                </div>

            </div>


            <div className="org-actions">

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={busy || !isAdmin}
                >
                    {busy ? "Guardando..." : "Guardar datos de empresa"}
                </button>

            </div>

            {!isAdmin && (
                <p className="org-readonly">
                    Solo administradores pueden modificar el perfil de empresa.
                </p>
            )}

        </div>

    );

}


export default OrganizationSection;
