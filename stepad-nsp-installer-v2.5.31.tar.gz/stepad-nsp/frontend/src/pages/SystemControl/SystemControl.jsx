import { useAuth } from "../../auth/useAuth";

import {
    restartSystem,
    rebootMachine,
    shutdownMachine,
} from "../../services/api";

import "./systemControl.css";


export default function SystemControl() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";


    async function handleRestart() {

        const ok = window.confirm(
            "¿Reiniciar los servicios de STEPAD? " +
            "La web se caerá unos segundos."
        );

        if (!ok) return;

        try {

            const result = await restartSystem();

            alert(result.message || "Reiniciando...");

        } catch (error) {

            console.error(error);

            alert("No se pudo reiniciar.");

        }

    }


    async function handleRebootMachine() {

        const ok = window.confirm(
            "¿REINICIAR EL EQUIPO completo?\n\n" +
            "El servidor se reiniciará y la web tardará unos minutos " +
            "en volver. Confirma solo si estás seguro."
        );

        if (!ok) return;

        try {

            const result = await rebootMachine();

            alert(result.message || "Reiniciando equipo...");

        } catch (error) {

            console.error(error);

            alert("No se pudo reiniciar el equipo.");

        }

    }


    async function handleShutdownMachine() {

        const ok = window.confirm(
            "¿APAGAR EL EQUIPO?\n\n" +
            "El servidor se apagará por completo. Tendrás que encenderlo " +
            "físicamente para volver a usarlo."
        );

        if (!ok) return;

        try {

            const result = await shutdownMachine();

            alert(result.message || "Apagando equipo...");

        } catch (error) {

            console.error(error);

            alert("No se pudo apagar el equipo.");

        }

    }


    if (!isAdmin) {

        return (

            <div className="system-control-page">

                <h2>Control del servidor</h2>

                <p className="system-control-hint">
                    Solo un administrador puede reiniciar servicios o
                    apagar/reiniciar el equipo.
                </p>

            </div>

        );

    }


    return (

        <div className="system-control-page">

            <h2>Control del servidor</h2>

            <p className="system-control-hint">
                Estas acciones son independientes del resto del panel: no
                dependen de que la base de datos ni otras pantallas hayan
                cargado, para que siempre estén disponibles aunque el
                sistema esté teniendo problemas.
            </p>

            <div className="system-control-card">

                <h3>Servicios de STEPAD</h3>

                <p>
                    Reinicia el backend (API, DNS, DHCP, firewall...) sin
                    apagar el equipo. La web vuelve en unos segundos.
                </p>

                <button
                    className="restart-button"
                    onClick={handleRestart}
                >
                    Reiniciar servicios
                </button>

            </div>

            <div className="system-control-card">

                <h3>Equipo</h3>

                <p>
                    Reinicia o apaga físicamente el servidor. Úsalo solo
                    cuando reiniciar los servicios no sea suficiente.
                </p>

                <div className="system-control-actions">

                    <button
                        className="restart-button"
                        onClick={handleRebootMachine}
                    >
                        Reiniciar equipo
                    </button>

                    <button
                        className="restart-button danger"
                        onClick={handleShutdownMachine}
                    >
                        Apagar equipo
                    </button>

                </div>

            </div>

        </div>

    );

}
