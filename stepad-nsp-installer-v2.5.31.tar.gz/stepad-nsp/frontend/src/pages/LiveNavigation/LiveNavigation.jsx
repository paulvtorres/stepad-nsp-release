import { useEffect, useState } from "react";

import { getSniConnections } from "../../services/api";

import "./liveNavigation.css";


function LiveNavigation() {

    const [connections, setConnections] = useState([]);

    const [loading, setLoading] = useState(false);


    useEffect(() => {

        load();

        const timer = setInterval(load, 15000);

        return () => clearInterval(timer);

    }, []);


    async function load() {

        setLoading(true);

        try {

            const data = await getSniConnections(2);

            setConnections(data?.connections || []);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    const byDevice = {};

    connections.forEach((conn) => {

        if (!byDevice[conn.ip]) {

            byDevice[conn.ip] = {
                device_name: conn.device_name,
                ip: conn.ip,
                domains: []
            };

        }

        byDevice[conn.ip].domains.push(conn.domain);

    });


    const devices = Object.values(byDevice);


    return (

        <div className="live-nav-container">

            <div className="live-nav-header">

                <div>

                    <h2>Navegación en vivo</h2>

                    <p>
                        Equipos navegando en este momento y los dominios exactos a los que
                        se conectan (SNI del tráfico HTTPS). Se actualiza solo.
                    </p>

                </div>

                <div className="live-nav-controls">

                    <span className="live-nav-count">
                        <span className="live-dot"></span>
                        <strong>{devices.length}</strong>
                        <span>{devices.length === 1 ? "equipo" : "equipos"}</span>
                    </span>

                </div>

            </div>


            <div className="live-nav-list">

                {
                    !loading && devices.length === 0 && (
                        <p className="live-nav-empty">
                            Sin navegación en este momento.
                        </p>
                    )
                }

                {
                    devices.map((dev) => (

                        <div key={dev.ip} className="live-nav-row">

                            <span className="live-nav-device">
                                {dev.device_name} ({dev.ip.split(".").pop()})
                            </span>

                            <span className="live-nav-domains">
                                {(dev.domains || []).join(", ")}
                            </span>

                        </div>

                    ))
                }

            </div>

        </div>

    );

}


export default LiveNavigation;
