import { useEffect, useState } from "react";

import { getNavigationSummary, getSecurityRules } from "../../services/api";

import "./topPages.css";


function toDateInputValue(date) {

    const y = date.getFullYear();

    const m = String(date.getMonth() + 1).padStart(2, "0");

    const d = String(date.getDate()).padStart(2, "0");

    return `${y}-${m}-${d}`;

}


function TopPages() {

    const [startDate, setStartDate] = useState(toDateInputValue(new Date()));

    const [endDate, setEndDate] = useState(toDateInputValue(new Date()));

    const [topPages, setTopPages] = useState([]);

    const [blockedDomains, setBlockedDomains] = useState([]);

    const [loading, setLoading] = useState(false);

    const [filter, setFilter] = useState("");


    useEffect(() => {

        load();

        const timer = setInterval(load, 30000);

        return () => clearInterval(timer);

    }, [startDate, endDate]);


    async function load() {

        setLoading(true);

        try {

            const rules = await getSecurityRules();

            setBlockedDomains(
                (rules || [])
                    .filter((r) => r.value)
                    .map((r) => String(r.value).toLowerCase())
            );

            const rows = await getNavigationSummary({
                start: startDate ? `${startDate}T00:00:00` : undefined,
                end: endDate ? `${endDate}T23:59:59` : undefined
            });

            const pages = Object.values(
                (rows || []).reduce((acc, r) => {

                    const domain = r.domain || "?";

                    const entry = acc[domain] || (
                        acc[domain] = {
                            domain,
                            visits: 0,
                            devices: new Set()
                        }
                    );

                    entry.visits += (r.visit_count || 0);

                    if (r.device_id) entry.devices.add(r.device_id);

                    return acc;

                }, {})
            ).map((p) => ({
                ...p,
                devices: p.devices.size,
                suspicious: blockedDomains.some(
                    (blocked) =>
                        p.domain.toLowerCase() === blocked ||
                        p.domain.toLowerCase().endsWith("." + blocked)
                ),
            })).sort((a, b) => b.visits - a.visits);

            setTopPages(pages);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    return (

        <div className="toppages-container">

            <div className="toppages-header">

                <div>

                    <h2>Páginas más navegadas</h2>

                    <p>
                        Dominios más visitados en el rango de fechas seleccionado
                        (por defecto hoy), entre todos los equipos.
                    </p>

                </div>

                <div className="toppages-filters">

                    <label>
                        Buscar dominio
                        <input
                            type="text"
                            placeholder="ej. luckpool, youtube..."
                            value={filter}
                            onChange={(e) => setFilter(e.target.value)}
                        />
                    </label>

                    <label>
                        Desde
                        <input
                            type="date"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                        />
                    </label>

                    <label>
                        Hasta
                        <input
                            type="date"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                        />
                    </label>

                </div>

            </div>


            {
                filter.trim() !== "" && blockedDomains.some(
                    (b) => b.includes(filter.trim().toLowerCase())
                ) && (
                    <p className="toppages-blocked-note">
                        ⚠ El dominio buscado está en la <strong>lista de bloqueo</strong> del NSP (sospechoso).
                    </p>
                )
            }


            {
                !loading && topPages.length === 0 ? (
                    <p className="toppages-empty">Sin actividad en el rango seleccionado.</p>
                ) : (
                    <table className="toppages-table">

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Página (dominio)</th>
                                <th>Visitas</th>
                                <th>Equipos</th>
                            </tr>
                        </thead>

                        <tbody>

                            {
                                topPages
                                    .filter((p) =>
                                        filter.trim() === "" ||
                                        p.domain.toLowerCase().includes(filter.trim().toLowerCase())
                                    )
                                    .map((page, index) => (
                                        <tr key={page.domain}>

                                            <td>{index + 1}</td>

                                            <td className="toppages-domain">
                                                {page.domain}

                                                {
                                                    page.suspicious && (
                                                        <span className="toppages-suspicious">
                                                            ⚠ Sospechoso
                                                        </span>
                                                    )
                                                }
                                            </td>

                                            <td>{page.visits.toLocaleString()}</td>

                                            <td>{page.devices}</td>

                                        </tr>
                                    ))
                            }

                            {
                                filter.trim() !== "" &&
                                !topPages.some((p) =>
                                    p.domain.toLowerCase().includes(filter.trim().toLowerCase())
                                ) && (
                                    <tr>
                                        <td colSpan={4} className="toppages-empty-cell">
                                            Ningún dominio coincide con la búsqueda.
                                        </td>
                                    </tr>
                                )
                            }

                        </tbody>

                    </table>
                )
            }

        </div>

    );

}


export default TopPages;
