import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";


export default defineConfig(({ mode }) => {

    const env = loadEnv(mode, process.cwd(), "");

    // STEPAD en producción/dev local usa HTTPS :8443 (systemd). Sin TLS
    // cae a HTTP :8000. Sobrescriba con frontend/.env.local si hace falta.
    const backendUrl = env.VITE_BACKEND_URL || "https://127.0.0.1:8443";

    return {

        plugins: [react()],

        server: {

            host: "0.0.0.0",

            port: 5173,

            proxy: {

                "/api": {

                    target: backendUrl,

                    changeOrigin: true,

                    secure: false

                }

            }

        }

    };

});
