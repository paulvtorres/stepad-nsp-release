# DHCP operativo

## Principio: el pool es FIJO
El segmento y el pool están configurados como deben ser. STEPAD **nunca**
amplía el pool. Su trabajo es:

1. entregar IP a todo equipo mientras quede una libre,
2. liberar lo que no se usa para que siempre haya una disponible,
3. **avisar** cuando ya no queda nada por liberar.

## Estados de una IP
- **Reservada** (`permanent_ip`): nunca se libera ni se ofrece a otro equipo.
- **En uso**: el equipo está presente (ver `DEVICE_PRESENCE.md`).
- **Retenida**: lease de un equipo ausente. Se recicla cuando hace falta.
- **Libre**: disponible para dnsmasq.

## Reciclaje de leases
Se libera el lease de un equipo solo si:

- la **presencia** lo da OFFLINE (sin ARP alcanzable, DNS ni respuesta a la
  verificación activa en los últimos 30 min). No se usa el ARP crudo: el
  kernel conserva entradas de equipos que ya se fueron,
- no tiene reserva (`permanent_ip`) ni es infraestructura,
- y lleva más de `pool_emergency_reclaim_minutes` (60 por defecto) sin
  señales fuertes (`last_seen`).

Con el pool **agotado** (0 libres) o cuando dnsmasq rechaza a un equipo con
"no address available", no se espera esa ventana: alcanza con que la
presencia diga OFFLINE. Un equipo conectado nunca pierde su IP.

Si no hay presencia confiable (falla la lectura de la red o de la base) no
se libera nada.

Se libera hasta recuperar `pool_reclaim_target_free` direcciones (10 por
defecto). El cooldown entre intentos es de 60 s por defecto (0 es válido); no
aplica con el pool agotado ni tras un "no address available".

## Eventos de lease (tiempo real)
dnsmasq avisa de cada lease nuevo, renovación y liberación mediante
`dhcp-script`:

    dnsmasq -> dhcp-event.sh -> spool (dhcp-events.jsonl) -> NSP
                                                  |-> presencia (segundos)
                                                  |-> IPAM

- El script lo genera STEPAD (`<STEPAD_DIR>/dns/dhcp-event.sh`, root, 0750).
  Solo anota una línea y sale con 0: no puede frenar a dnsmasq. No incluye
  el hostname (texto libre del cliente).
- Se activa solo si el dnsmasq instalado declara `--dhcp-script`; y
  `script-on-renewal` solo si lo declara. Si no, no se emite nada (una
  opción desconocida haría que `dnsmasq --test` rechace toda la
  configuración) y el sondeo de 60 s sigue cubriendo.
- Se desactiva con `STEPAD_DHCP_EVENTS=0`.
- La primera vez que aparece la línea en la configuración dnsmasq se
  reinicia una vez.
- Si no llegan eventos: ejecutar a mano
  `sh <STEPAD_DIR>/dns/dhcp-event.sh add aa:bb:cc:dd:ee:ff 192.168.1.50` y ver
  si aparece una línea en el spool. Si no aparece, revisar permisos y el
  perfil de AppArmor/SELinux de dnsmasq (puede impedir ejecutar el script;
  `dnsmasq --test` no lo detecta).
- **Autochequeo:** si el archivo de leases de dnsmasq cambia y no llega ningún
  evento en 5 minutos, el NSP crea la alerta `DHCP_EVENTS_SILENT` (aviso) con
  la prueba a hacer; se resuelve sola cuando vuelven los eventos. Una red en
  calma, sin cambios de leases, nunca da falsa alarma. Mientras tanto la
  presencia sigue funcionando por sondeo cada 60 s.
- El spool se rota a los 256 KB. Un evento perdido en esa ventana lo cubre
  el sondeo.

## Lease
- Valor actual: 8h. Se configura en DHCP → Segmento y pool.
- Un lease corto hace que las IPs de equipos que se fueron queden libres sin
  intervención. Las reservas no dependen del lease.

## Alertas
- `DHCP_POOL_LOW`: quedan pocas IPs (un solo aviso al cruzar el umbral).
- `DHCP_POOL_EXHAUSTED` (crítica): 0 IPs libres. Si persiste, el pool está
  lleno de equipos conectados.
- `DHCP_NO_ADDRESS` (crítica): un equipo pidió IP y no había.
- `DHCP_POOL_TREND`: tendencia de agotamiento.
- `DHCP_POOL_RECLAIMED`: IPs recicladas.
- `DHCP_POOL_RECOVERED`: el pool volvió a tener espacio (un solo aviso).
- `DHCP_RESERVED_IP_OCCUPIED`: reserva ocupada por otra MAC.
- `DHCP_IP_DUPLICATE_ACTIVE`: una IP asignada por DHCP la usa otra MAC.

Las alertas del DHCP se **resuelven solas** cuando la condición desaparece
(pool con espacio, conflicto terminado): así el escalamiento no avisa de algo
que ya pasó. Una alerta crítica que se repite envía como máximo un correo por
ventana (el límite es compartido entre todas las instancias del servicio de
alertas) y un webhook por hora.

## IPs y conflictos
- Las asignaciones (reserva o lease) viven en `ip_assignments`; hay una sola
  activa por IP.
- Lo observado en la red (`device_ip_observations`) no está sujeto a esa
  unicidad: así un conflicto real se ve en lugar de ocultarse.
- `device_ip_history` conserva las IPs anteriores de cada equipo.

## Recuperación
- Componentes importantes: reintentos y supervisor.
- Componentes críticos: fallo → systemd reinicia el NSP.
- Watchdog externo: 3 fallos de `/healthz` → reinicia `stepad-nsp`.

## Dependencias externas
- HA/segundo DHCP requiere infraestructura.
- El correo de alertas requiere SMTP y destinatarios configurados.
