"""
Mount / protect the dedicated STEPAD network-share disk.

The share disk is always mounted at SHARE_DISK_MOUNT via a systemd
.mount unit keyed by filesystem UUID. While assigned (disk_locked),
it is not meant to be unmounted by hand — only released from the NSP UI.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from backend.core.config.paths import (
    SHARE_DISK_MOUNT,
    SHARE_DISK_MOUNT_UNIT,
)
from backend.shared.logging.logger import logger


class ShareDiskMountProvider:

    UNIT_PATH = Path(f"/etc/systemd/system/{SHARE_DISK_MOUNT_UNIT}")

    def _run(self, command: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout,
                env={**os.environ, "LC_ALL": "C", "LANG": "C"},
            )
        except subprocess.TimeoutExpired:
            logger.error("ShareDiskMountProvider: timeout ejecutando %s", command)
            return subprocess.CompletedProcess(
                args=command, returncode=1, stdout="",
                stderr=f"Tiempo de espera agotado ejecutando {command[0]}.",
            )
        except OSError as exc:
            # Incluye FileNotFoundError si el binario no está instalado.
            logger.error("ShareDiskMountProvider: error ejecutando %s: %s", command, exc)
            return subprocess.CompletedProcess(
                args=command, returncode=1, stdout="",
                stderr=f"No se pudo ejecutar {command[0]}: {exc}",
            )

    def blkid_field(self, device: str, field: str) -> str | None:
        result = self._run(["blkid", "-s", field, "-o", "value", device])
        if result.returncode != 0:
            return None
        value = (result.stdout or "").strip()
        return value or None

    def is_mounted_at(self, mountpoint: Path | str) -> bool:
        result = self._run(["findmnt", "-n", str(mountpoint)])
        return result.returncode == 0 and bool(result.stdout.strip())

    def current_source(self, mountpoint: Path | str) -> str | None:
        result = self._run(["findmnt", "-n", "-o", "SOURCE", str(mountpoint)])
        if result.returncode != 0:
            return None
        return (result.stdout or "").strip() or None

    @staticmethod
    def unit_name_for_mount(mountpoint: Path | str) -> str:
        """
        /mnt/stepad-share/datos -> mnt-stepad-share-datos.mount
        """

        raw = str(mountpoint).strip("/")
        escaped = raw.replace("-", "\\x2d").replace("/", "-")
        return f"{escaped}.mount"

    def write_volume_mount_unit(
        self,
        *,
        uuid: str,
        fstype: str,
        mountpoint: Path | str,
    ) -> str:
        mountpoint = Path(mountpoint)
        mountpoint.mkdir(parents=True, exist_ok=True)
        unit = self.unit_name_for_mount(mountpoint)
        unit_path = Path("/etc/systemd/system") / unit

        content = "\n".join([
            "[Unit]",
            f"Description=STEPAD share volume {mountpoint} (do not unmount manually)",
            "Before=smbd.service nmbd.service",
            "Conflicts=umount.target",
            "",
            "[Mount]",
            f"What=/dev/disk/by-uuid/{uuid}",
            f"Where={mountpoint}",
            f"Type={fstype}",
            "Options=defaults,nofail,x-systemd.device-timeout=10s",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ])
        unit_path.write_text(content, encoding="utf-8")
        self._run(["systemctl", "daemon-reload"])
        return unit

    def activate_unit(self, unit: str, mountpoint: Path | str) -> dict:
        self._run(["systemctl", "enable", unit])
        start = self._run(["systemctl", "start", unit])
        active = self._run(["systemctl", "is-active", unit])
        ok = active.stdout.strip() == "active" or self.is_mounted_at(mountpoint)
        if not ok:
            detail = (start.stderr or active.stderr or "").strip()
            return {"success": False, "message": detail or "No se pudo montar."}
        return {"success": True, "mountpoint": str(mountpoint), "unit": unit}

    def deactivate_unit(self, unit: str, mountpoint: Path | str) -> dict:
        self._run(["systemctl", "stop", unit])
        self._run(["systemctl", "disable", unit])
        unit_path = Path("/etc/systemd/system") / unit
        if unit_path.exists():
            try:
                unit_path.unlink()
            except Exception as error:
                logger.warning("Could not remove unit %s: %s", unit, error)
        self._run(["systemctl", "daemon-reload"])
        if self.is_mounted_at(mountpoint):
            umount = self._run(["umount", str(mountpoint)])
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        "Se dejó de compartir, pero el volumen sigue montado "
                        f"(ocupado): {(umount.stderr or '').strip()}"
                    ),
                }
        return {"success": True, "message": "Volumen liberado."}


    def mount_now(self, *, uuid: str, mountpoint: Path | str) -> dict:
        """
        Monta una partición por UUID en el instante, SIN habilitarla en
        el arranque (no es permanente: solo vive hasta que se desmonta
        o se reinicia). Usado por los roles "backup"/"private", que
        deben permanecer desmontados salvo mientras se respalda o se
        accede por la web.
        """
        mountpoint = Path(mountpoint)
        mountpoint.mkdir(parents=True, exist_ok=True)
        if self.is_mounted_at(mountpoint):
            return {
                "success": True,
                "mounted": True,
                "mountpoint": str(mountpoint),
                "unit": None,
            }
        mount = self._run([
            "mount", "-r" if False else "-o",
            "defaults,noatime,nofail", "/dev/disk/by-uuid/" + uuid,
            str(mountpoint),
        ])
        if mount.returncode != 0:
            return {
                "success": False,
                "message": (
                    f"No se pudo montar {uuid}: "
                    f"{(mount.stderr or '').strip()}"
                ),
            }
        return {"success": True, "mounted": True, "mountpoint": str(mountpoint)}

    def unmount_now(self, mountpoint: Path | str) -> dict:
        """
        Desmonta una partición montada por demanda, sin tocar el unit
        de systemd ni el registro en DB.
        """
        if not self.is_mounted_at(mountpoint):
            return {"success": True, "mounted": False, "message": "No estaba montado."}
        umount = self._run(["umount", str(mountpoint)])
        # Reintento forzado si está "busy" (algún handle abierto).
        if umount.returncode != 0:
            lazy = self._run(["umount", "-l", str(mountpoint)])
            if lazy.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        f"No se pudo desmontar {mountpoint}: "
                        f"{(umount.stderr or '').strip()}"
                    ),
                }
        return {"success": True, "mounted": False}

    def write_mount_unit(self, *, uuid: str, fstype: str) -> None:
        SHARE_DISK_MOUNT.mkdir(parents=True, exist_ok=True)

        # Keep the volume busy-friendly for Samba and remount on boot.
        content = "\n".join([
            "[Unit]",
            "Description=STEPAD network share disk (do not unmount manually)",
            "Documentation=https://stepad.local/shares",
            "Before=smbd.service nmbd.service",
            "Conflicts=umount.target",
            "",
            "[Mount]",
            f"What=/dev/disk/by-uuid/{uuid}",
            f"Where={SHARE_DISK_MOUNT}",
            f"Type={fstype}",
            "Options=defaults,nofail,x-systemd.device-timeout=10s",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ])

        self.UNIT_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.UNIT_PATH.write_text(content, encoding="utf-8")

        self._run(["systemctl", "daemon-reload"])

    def activate(self) -> dict:
        enable = self._run(["systemctl", "enable", SHARE_DISK_MOUNT_UNIT])
        start = self._run(["systemctl", "start", SHARE_DISK_MOUNT_UNIT])
        active = self._run(["systemctl", "is-active", SHARE_DISK_MOUNT_UNIT])

        ok = active.stdout.strip() == "active" or self.is_mounted_at(SHARE_DISK_MOUNT)

        if not ok:
            detail = (start.stderr or enable.stderr or active.stderr or "").strip()
            logger.error("Failed to activate share disk mount: %s", detail)
            return {"success": False, "message": detail or "No se pudo montar el disco."}

        return {
            "success": True,
            "mountpoint": str(SHARE_DISK_MOUNT),
            "message": "Disco montado y protegido.",
        }

    def deactivate(self) -> dict:
        self._run(["systemctl", "stop", SHARE_DISK_MOUNT_UNIT])
        self._run(["systemctl", "disable", SHARE_DISK_MOUNT_UNIT])

        if self.UNIT_PATH.exists():
            try:
                self.UNIT_PATH.unlink()
            except Exception as error:
                logger.warning("Could not remove mount unit: %s", error)

        self._run(["systemctl", "daemon-reload"])

        # Best-effort manual umount if still mounted.
        if self.is_mounted_at(SHARE_DISK_MOUNT):
            umount = self._run(["umount", str(SHARE_DISK_MOUNT)])
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        "Disco liberado en configuración, pero sigue montado "
                        f"(ocupado): {(umount.stderr or '').strip()}"
                    ),
                }

        return {"success": True, "message": "Disco liberado."}

    def format_ext4(
        self,
        device: str,
        *,
        label: str = "STEPAD-SHARE",
    ) -> dict:
        """
        Destructive: create ext4 on an existing partition.
        Windows clients access via Samba; ext4 is the NSP-side FS.
        """

        if not device.startswith("/dev/"):
            return {"success": False, "message": "Dispositivo inválido."}

        # Refuse if mounted anywhere.
        findmnt = self._run(["findmnt", "-n", "-S", device])
        if findmnt.returncode == 0 and findmnt.stdout.strip():
            return {
                "success": False,
                "message": (
                    f"{device} está montado. Desmóntalo o libéralo "
                    "antes de formatear."
                ),
            }

        mkfs = self._run(
            [
                "mkfs.ext4",
                "-F",
                "-L", label[:16],
                device,
            ],
            timeout=600,
        )

        if mkfs.returncode != 0:
            return {
                "success": False,
                "message": (mkfs.stderr or mkfs.stdout or "mkfs.ext4 falló").strip(),
            }

        # Refresh kernel partition table / udev.
        self._run(["udevadm", "settle"], timeout=30)
        uuid = self.blkid_field(device, "UUID")
        fstype = self.blkid_field(device, "TYPE") or "ext4"

        return {
            "success": True,
            "device": device,
            "uuid": uuid,
            "fstype": fstype,
            "message": f"Formateado {device} como ext4 (listo para Windows vía Samba).",
        }

    def prepare_whole_disk(
        self,
        disk: str,
        *,
        label: str = "STEPAD-SHARE",
    ) -> dict:
        """
        Wipe the entire secondary disk (any existing partitions), create
        a single GPT partition, and format ext4 for Samba sharing.
        """

        if not disk.startswith("/dev/"):
            return {"success": False, "message": "Disco inválido."}

        # Unmount every mounted child partition on this disk.
        lsblk = self._run(["lsblk", "-lnpo", "NAME,MOUNTPOINT", disk])
        for line in (lsblk.stdout or "").splitlines():
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            name, mountpoint = parts[0].strip(), parts[1].strip()
            if not mountpoint:
                continue
            if mountpoint.rstrip("/") in ("/", "/boot", "/boot/efi", "/home", "/var"):
                return {
                    "success": False,
                    "message": (
                        f"No se puede borrar {disk}: tiene montado "
                        f"{mountpoint} (ruta de sistema)."
                    ),
                }
            umount = self._run(["umount", mountpoint], timeout=60)
            if umount.returncode != 0:
                # Lazy unmount as fallback when busy.
                umount = self._run(["umount", "-l", mountpoint], timeout=60)
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        f"No se pudo desmontar {name} ({mountpoint}). "
                        "Libera el disco compartido o cierra usos del volumen."
                    ),
                }

        # Wipe partition signatures then the disk itself.
        children = self._run(["lsblk", "-lnpo", "NAME,TYPE", disk])
        for line in (children.stdout or "").splitlines():
            bits = line.split()
            if len(bits) >= 2 and bits[1] == "part":
                self._run(["wipefs", "-a", bits[0]], timeout=60)

        self._run(["wipefs", "-a", disk], timeout=60)

        parted = self._run(
            [
                "parted", "-s", disk,
                "mklabel", "gpt",
                "mkpart", "primary", "ext4", "1MiB", "100%",
            ],
            timeout=120,
        )
        if parted.returncode != 0:
            return {
                "success": False,
                "message": (parted.stderr or parted.stdout or "parted falló").strip(),
            }

        self._run(["partprobe", disk], timeout=30)
        self._run(["udevadm", "settle"], timeout=30)

        part = None
        for candidate in (f"{disk}1", f"{disk}p1"):
            if Path(candidate).exists():
                part = candidate
                break

        if not part:
            import time
            for _ in range(15):
                time.sleep(0.4)
                for candidate in (f"{disk}1", f"{disk}p1"):
                    if Path(candidate).exists():
                        part = candidate
                        break
                if part:
                    break

        if not part:
            return {
                "success": False,
                "message": "Se creó la partición pero no aparece el dispositivo.",
            }

        formatted = self.format_ext4(part, label=label)
        if formatted.get("success"):
            formatted["message"] = (
                f"Disco {disk} unificado en una sola partición ext4 "
                f"({part}). Listo para compartir con Windows vía Samba."
            )
        return formatted

    def delete_partition(self, device: str) -> dict:
        """
        Destructive: remove one partition from a secondary disk.
        Does not touch the OS disk.
        """

        if not device.startswith("/dev/"):
            return {"success": False, "message": "Partición inválida."}

        typ = self._run(["lsblk", "-no", "TYPE", device])
        if (typ.stdout or "").strip().lower() != "part":
            return {"success": False, "message": "Solo se pueden eliminar particiones."}

        pkname = (self._run(["lsblk", "-no", "PKNAME", device]).stdout or "").strip()
        if not pkname:
            return {"success": False, "message": "No se pudo determinar el disco padre."}
        disk = f"/dev/{pkname}"

        partn = (self._run(["lsblk", "-no", "PARTN", device]).stdout or "").strip()
        if not partn.isdigit():
            # Fallback: sdb1 -> 1, nvme0n1p3 -> 3
            name = Path(device).name
            digits = ""
            for ch in reversed(name):
                if ch.isdigit():
                    digits = ch + digits
                else:
                    break
            partn = digits
        if not partn.isdigit():
            return {"success": False, "message": "No se pudo determinar el número de partición."}

        mountpoint = (self._run(["lsblk", "-no", "MOUNTPOINT", device]).stdout or "").strip()
        if mountpoint:
            if mountpoint.rstrip("/") in ("/", "/boot", "/boot/efi", "/home", "/var"):
                return {
                    "success": False,
                    "message": f"No se puede eliminar {device}: montada en {mountpoint}.",
                }
            # Los montajes gestionados por systemd (.mount) no se sueltan con
            # umount a secas: hay que parar la unidad correspondiente.
            unit = self.unit_name_for_mount(mountpoint)
            self._run(["systemctl", "stop", unit], timeout=30)

            umount = self._run(["umount", mountpoint], timeout=60)
            if umount.returncode != 0:
                umount = self._run(["umount", "-l", mountpoint], timeout=60)
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        f"No se pudo desmontar {device} ({mountpoint}). "
                        "Déjala de compartir o cierra usos del volumen."
                    ),
                }

        # parted pide confirmación ("Partition is being used") cuando el
        # dispositivo sigue abierto tras el desmontaje; sin tty, -s no la
        # contesta y eliminar una partición montada falla siempre con rc=1.
        parted = self._run(
            ["bash", "-c", f"printf 'yes\\n' | parted {disk} rm {partn}"],
            timeout=120,
        )
        if parted.returncode != 0:
            return {
                "success": False,
                "message": (parted.stderr or parted.stdout or "parted rm falló").strip(),
            }

        # Solo después de confirmar que la partición se eliminó se limpian
        # firmas residuales. Antes se hacía wipefs ANTES de parted, y si este
        # fallaba la firma del filesystem ya se había borrado.
        self._run(["wipefs", "-a", device], timeout=60)

        self._run(["partprobe", disk], timeout=30)
        self._run(["udevadm", "settle"], timeout=30)

        return {
            "success": True,
            "device": device,
            "disk": disk,
            "message": f"Partición {device} eliminada del disco {disk}.",
        }

    def disk_size_bytes(self, disk: str) -> int | None:
        result = self._run(["blockdev", "--getsize64", disk])
        if result.returncode != 0:
            return None
        try:
            return int((result.stdout or "").strip())
        except ValueError:
            return None

    def ensure_gpt(self, disk: str) -> dict:
        """Create an empty GPT table if the disk has none (keeps data wipe minimal)."""

        print_table = self._run(["parted", "-sm", disk, "print"], timeout=30)
        out = (print_table.stdout or "") + (print_table.stderr or "")
        if "unrecognised disk label" in out.lower() or "unknown partition table" in out.lower():
            mk = self._run(["parted", "-s", disk, "mklabel", "gpt"], timeout=60)
            if mk.returncode != 0:
                return {
                    "success": False,
                    "message": (mk.stderr or mk.stdout or "No se pudo crear GPT").strip(),
                }
            return {"success": True, "created": True}
        if print_table.returncode != 0 and "gpt" not in out.lower() and "msdos" not in out.lower():
            mk = self._run(["parted", "-s", disk, "mklabel", "gpt"], timeout=60)
            if mk.returncode != 0:
                return {
                    "success": False,
                    "message": (mk.stderr or mk.stdout or "No se pudo crear GPT").strip(),
                }
            return {"success": True, "created": True}
        return {"success": True, "created": False}

    def free_regions_mib(self, disk: str) -> list[dict]:
        """
        Return free regions as [{start_mib, end_mib, size_mib}, ...] using parted.
        """

        result = self._run(
            ["parted", "-sm", disk, "unit", "MiB", "print", "free"],
            timeout=30,
        )
        regions: list[dict] = []
        for line in (result.stdout or "").splitlines():
            # N:start:end:size:free;
            if ":free;" not in line and not line.endswith(":free"):
                # parted -m: 1:1.00MiB:100MiB:99MiB:free;
                if ":free;" not in line and ":free" not in line:
                    continue
            parts = line.rstrip(";").split(":")
            if len(parts) < 4:
                continue
            kind = parts[4] if len(parts) > 4 else ""
            if kind != "free" and "free" not in line:
                continue
            try:
                start = float(parts[1].replace("MiB", "").replace(",", "."))
                end = float(parts[2].replace("MiB", "").replace(",", "."))
                size = float(parts[3].replace("MiB", "").replace(",", "."))
            except ValueError:
                continue
            if size < 8:
                continue
            regions.append({
                "start_mib": start,
                "end_mib": end,
                "size_mib": size,
            })
        return regions

    def partition_info(self, device: str) -> dict:
        """
        Metadata of a partition: parent disk, partition number, byte offset
        (start), current size, filesystem type and mount state. Used to
        validate/execute resize_partition.
        """
        device = (device or "").strip()
        if not device.startswith("/dev/"):
            return {"success": False, "message": "Dispositivo inválido."}
        rel = Path(device).name  # p. ej. sdb1
        # Disco padre: sdb1 -> sdb, mmcblk0p1 -> mmcblk0
        disk_name = rel
        while disk_name and disk_name[-1].isdigit():
            disk_name = disk_name[:-1]
        # mmcblk0p1 -> el supresor de digitos tambien come la p; re-append
        if rel.startswith("mmcblk") and disk_name.endswith("p") is False \
           and rel[-1].isdigit():
            base = rel.rsplit("p", 1)[0]  # mmcblk0p1 -> mmcblk0
            disk_name = base
        disk = f"/dev/{disk_name}"
        part_num = 0
        if rel.startswith("mmcblk") and "p" in rel:
            part_num = int(rel.rsplit("p", 1)[1])
        else:
            part_num = int("".join(ch for ch in rel[len(disk_name):] if ch.isdigit()) or "0")

        # Offset inicial en bytes via sysfs (sectores * 512).
        start_bytes = None
        try:
            sys_start = Path(f"/sys/class/block/{rel}/start").read_text().strip()
            start_bytes = int(sys_start) * 512
        except Exception:
            start_bytes = None

        # Tamaño actual en bytes.
        size_bytes = None
        try:
            size_bytes = int(Path(f"/sys/class/block/{rel}/size").read_text().strip()) * 512
        except Exception:
            sz = self._run(["blockdev", "--getsize64", device])
            if sz.returncode == 0 and sz.stdout.strip().isdigit():
                size_bytes = int(sz.stdout.strip())

        fstype = self.blkid_field(device, "TYPE")
        mounted = False
        mountpoint = ""
        findmnt = self._run(["findmnt", "-n", "-o", "TARGET", "-S", device])
        if findmnt.returncode == 0 and findmnt.stdout.strip():
            mounted = True
            mountpoint = findmnt.stdout.strip().splitlines()[0]

        return {
            "success": True,
            "device": device,
            "disk": disk,
            "part_num": part_num,
            "start_bytes": start_bytes,
            "size_bytes": size_bytes,
            "fstype": fstype,
            "mounted": mounted,
            "mountpoint": mountpoint,
        }

    def resize_partition(
        self,
        device: str,
        *,
        new_size_gb: float | None = None,
    ) -> dict:
        """
        Resize a partition (grow or shrink) on its parent disk.

        - GROW (new_size_gb > current): extends the partition first, then
          grows the filesystem (resize2fs for ext4, xfs_growfs for xfs).
          Safe online, keeps data.
        - SHRINK (new_size_gb < current): only ext4, MUST be unmounted.
          Filesystem is shrunk first, then the partition (resize2fs + parted).

        new_size_gb None => use all the adjacent free space at the END.

        README of risk: shrinking is accepted but requires the partition
        to be unmounted and non-xfs; the partition must have adjacent free
        space in the right position, else parted refuses.
        """
        info = self.partition_info(device)
        if not info.get("success"):
            return info

        disk = info["disk"]
        part_num = int(info["part_num"] or 0)
        if part_num <= 0:
            return {"success": False, "message": f"No pude determinar el número de partición de {device}."}
        start = info["start_bytes"]
        current = info["size_bytes"]
        if not start or not current:
            return {"success": False, "message": f"No pude leer el tamaño/offset de {device}."}

        fstype = (info.get("fstype") or "ext4").lower()
        # Por defecto, crecer hasta usar todo el espacio libre contiguo.
        if new_size_gb is None:
            new_bytes = current
            region = self._latest_free_after(disk, start + current)
            if region:
                new_bytes = max(current, int(region))
        else:
            try:
                new_bytes = int(float(new_size_gb) * 1024 * 1024 * 1024)
            except (TypeError, ValueError):
                return {"success": False, "message": "Tamaño inválido."}

        delta = new_bytes - current
        if abs(delta) < 1024 * 1024:  # menos de 1MiB: no-op
            return {
                "success": True,
                "message": "El tamaño no cambia (mismo valor).",
                "resized": False,
                "new_size_gb": round(current / 1024 / 1024 / 1024, 2),
            }

        growing = delta > 0

        if growing:
            # Crecer: particion primero, luego filesystem.
            new_end = start + new_bytes
            res = self._parted_resizepart(disk, part_num, new_end)
            if not res.get("success"):
                return res
            self._refresh_partitions(disk)
            fs_err = None
            if fstype == "ext4":
                grow = self._run(["resize2fs", device], timeout=900)
                if grow.returncode != 0:
                    fs_err = (grow.stderr or grow.stdout or "resize2fs falló").strip()
                else:
                    return {
                        "success": True,
                        "message": f"{device} agrandado y filesystem crecido a {round(new_bytes/1024/1024/1024, 2)} GB.",
                        "new_size_gb": round(new_bytes / 1024 / 1024 / 1024, 2),
                    }
            elif fstype == "xfs":
                mnt = info.get("mountpoint")
                if mnt:
                    grow = self._run(["xfs_growfs", mnt], timeout=900)
                else:
                    grow = self._run(["xfs_growfs", device], timeout=900)
                if grow.returncode != 0:
                    fs_err = (grow.stderr or grow.stdout or "xfs_growfs falló").strip()
                else:
                    return {
                        "success": True,
                        "message": f"{device} agrandado y xfs crecido a {round(new_bytes/1024/1024/1024, 2)} GB.",
                        "new_size_gb": round(new_bytes / 1024 / 1024 / 1024, 2),
                    }
            else:
                fs_err = f"Filesystem «{fstype}» no soporta resize automático."
            # Si falla el resize del FS, la partición ya creció pero el FS no:
            # avisar claramente (es recuperable con resize2fs manual).
            return {
                "success": False,
                "message": (
                    f"La partición {device} se agrandó a {round(new_bytes/1024/1024/1024,2)} GB "
                    f"pero el filesystem no pudo crecerse automáticamente: {fs_err}. "
                    "Ejecutá manualmente resize2fs/xfs_growfs."
                ),
            }

        # ---- SHRINK ----
        if info.get("mounted"):
            return {
                "success": False,
                "message": (
                    f"{device} está montado; reducirlo requiere desmontarlo "
                    "primero (Desmontar), porque se encoge el filesystem sin "
                    "ése montado."
                ),
            }
        if fstype != "ext4":
            return {
                "success": False,
                "message": (
                    f"Reducir filesystems «{fstype}» no está soportado de forma segura "
                    "(solo ext4). Agrandar sí se puede."
                ),
            }

        # Verificar que el filesystem puede caber en el nuevo tamaño.
        new_end = start + new_bytes
        # 1) reducir filesystem
        shrink = self._run(
            ["resize2fs", device, str(new_bytes)],
            timeout=900,
        )
        if shrink.returncode != 0:
            return {
                "success": False,
                "message": (shrink.stderr or shrink.stdout or "resize2fs falló").strip(),
            }
        # 2) reducir partición
        res = self._parted_resizepart(disk, part_num, new_end)
        if not res.get("success"):
            # intentar recuperar el filesystem a su tamaño anterior
            self._run(["resize2fs", device], timeout=900)
            return res
        self._refresh_partitions(disk)
        return {
            "success": True,
            "message": f"{device} reducido a {round(new_bytes/1024/1024/1024, 2)} GB.",
            "new_size_gb": round(new_bytes / 1024 / 1024 / 1024, 2),
        }

    def _parted_resizepart(self, disk: str, part_num: int, end_bytes: int) -> dict:
        # el final puede pasarse con sufijo "B"; parted lo acepta tras unit B.
        try:
            self._run(["parted", "-s", disk, "unit", "B", "print"], timeout=30)
            res = self._run(
                ["parted", "-s", "--", disk, "unit", "B", "resizepart", str(part_num), f"{int(end_bytes)}B"],
                timeout=120,
            )
        except Exception as exc:
            return {"success": False, "message": f"parted resizepart error: {exc}"}
        if res.returncode != 0:
            return {
                "success": False,
                "message": (res.stderr or res.stdout or "parted resizepart falló").strip(),
            }
        return {"success": True}

    def _refresh_partitions(self, disk: str) -> None:
        self._run(["udevadm", "settle"], timeout=30)
        self._run(["partprobe", disk], timeout=30)
        self._run(["udevadm", "settle"], timeout=30)

    def _latest_free_after(self, disk: str, from_bytes: int) -> int | None:
        """Mayor región libre inmediatamente a partir de from_bytes (bytes)."""
        result = self._run(
            ["parted", "-sm", disk, "unit", "B", "print", "free"],
            timeout=30,
        )
        best = None
        for line in (result.stdout or "").splitlines():
            if ":free" not in line:
                continue
            parts = line.rstrip(";").split(":")
            if len(parts) < 4:
                continue
            try:
                start = float(parts[1].replace("B", "").replace(",", "."))
                end = float(parts[2].replace("B", "").replace(",", "."))
            except ValueError:
                continue
            # La región libre debe empezar justo donde termina la partición
            # (contiguo hacia delante).
            if abs(start - from_bytes) < 4096:
                size = end - start
                if best is None or size > best:
                    best = int(size)
        return best

    def create_partition(
        self,
        disk: str,
        *,
        size_gb: float | None = None,
        use_remaining: bool = False,
        label: str = "STEPAD-SHARE",
    ) -> dict:
        """
        Create one GPT partition in free space (NOT formatted yet).
        size_gb: requested size; use_remaining uses the largest free region fully.
        The caller formats it with format_ext4 before sharing.
        """

        if not disk.startswith("/dev/"):
            return {"success": False, "message": "Disco inválido."}

        gpt = self.ensure_gpt(disk)
        if not gpt.get("success"):
            return gpt

        # Refresh free map after possible GPT create.
        self._run(["partprobe", disk], timeout=30)
        regions = self.free_regions_mib(disk)
        if not regions:
            return {
                "success": False,
                "message": (
                    "No hay espacio libre en el disco. "
                    "Elimina una partición o usa otro disco."
                ),
            }

        region = max(regions, key=lambda r: r["size_mib"])
        # Align start to at least 1 MiB for first partition.
        start = max(region["start_mib"], 1.0)
        available = region["end_mib"] - start
        if available < 64:
            return {
                "success": False,
                "message": "El espacio libre es demasiado pequeño (mín. ~64 MiB).",
            }

        if use_remaining or not size_gb:
            # Leave a small margin so `end` is strictly inside the device:
            # parted rejects an end exactly at the device boundary.
            end = max(start + 1.0, region["end_mib"] - 1.0)
        else:
            need = float(size_gb) * 1024.0  # GiB -> MiB
            if need < 64:
                return {"success": False, "message": "El tamaño mínimo es 0.1 GB."}
            if need > available - 1:
                return {
                    "success": False,
                    "message": (
                        f"Solo hay ~{available / 1024:.1f} GB libres. "
                        "Reduce el tamaño o usa el espacio restante."
                    ),
                }
            end = start + need

        # Leave a tiny gap before end of region when not using remaining.
        if end > region["end_mib"]:
            end = region["end_mib"]

        parted = self._run(
            [
                "parted", "-s", disk,
                "unit", "MiB",
                "mkpart", "primary", "ext4",
                f"{start:.0f}",
                f"{end:.0f}",
            ],
            timeout=120,
        )
        if parted.returncode != 0:
            return {
                "success": False,
                "message": (parted.stderr or parted.stdout or "parted mkpart falló").strip(),
            }

        self._run(["partprobe", disk], timeout=30)
        self._run(["udevadm", "settle"], timeout=30)

        import time
        part = self._newest_partition(disk)
        if not part:
            for _ in range(20):
                time.sleep(0.3)
                part = self._newest_partition(disk)
                if part:
                    break

        if not part:
            return {
                "success": False,
                "message": "Se creó la partición pero no aparece el dispositivo.",
            }

        size_msg = "espacio restante" if use_remaining or not size_gb else f"{size_gb:g} GB"
        return {
            "success": True,
            "device": part,
            "disk": disk,
            "fstype": None,
            "message": (
                f"Partición {part} creada ({size_msg}). "
                "Formátala desde el NSP para compartirla."
            ),
        }

    def _newest_partition(self, disk: str) -> str | None:
        """Pick the highest-numbered partition child of disk."""

        result = self._run(["lsblk", "-lnpo", "NAME,TYPE", disk])
        parts: list[str] = []
        for line in (result.stdout or "").splitlines():
            bits = line.split()
            if len(bits) >= 2 and bits[1] == "part":
                parts.append(bits[0])
        if not parts:
            return None

        def sort_key(path: str) -> int:
            name = Path(path).name
            digits = ""
            for ch in reversed(name):
                if ch.isdigit():
                    digits = ch + digits
                else:
                    break
            return int(digits) if digits else 0

        parts.sort(key=sort_key)
        return parts[-1]

    def ensure_boot(self, uuid: str | None, fstype: str | None = None) -> None:
        if not uuid:
            return
        fstype = fstype or self.blkid_field(f"/dev/disk/by-uuid/{uuid}", "TYPE") or "auto"
        try:
            self.write_mount_unit(uuid=uuid, fstype=fstype)
            self.activate()
        except Exception as error:
            logger.error("Share disk boot mount failed: %s", error)