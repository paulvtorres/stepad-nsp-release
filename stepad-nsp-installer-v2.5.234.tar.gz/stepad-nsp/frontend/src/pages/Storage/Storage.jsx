import { useState, useEffect, useCallback } from "react";
import {
    getDisks,
    mountDisk,
    unmountDisk,
    exploreDirectory,
    createDiskFolder,
    deleteDiskItem,
    resizeSharePartition,
} from "../../services/api";
import "./storage.css";

function formatSize(bytes) {
    if (!bytes) return "—";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

function formatDate(iso) {
    if (!iso) return "—";
    return new Date(iso).toLocaleDateString("es-EC", { dateStyle: "short", timeStyle: "short" });
}

export default function Storage() {
    const [disks, setDisks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [feedback, setFeedback] = useState(null);
    const [currentPath, setCurrentPath] = useState("/mnt/stepad-disk");
    const [items, setItems] = useState([]);
    const [exploring, setExploring] = useState(false);
    const [newFolder, setNewFolder] = useState("");
    const [actionBusy, setActionBusy] = useState(null);
    const [resizingPart, setResizingPart] = useState(null);
    const [resizeInput, setResizeInput] = useState("");

    const loadDisks = useCallback(async () => {
        try {
            const data = await getDisks();
            setDisks(data?.disks || []);
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { loadDisks(); }, [loadDisks]);

    const loadDir = useCallback(async (path) => {
        setExploring(true);
        try {
            const data = await exploreDirectory(path);
            setItems(data?.items || []);
            setCurrentPath(path);
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setExploring(false);
        }
    }, []);

    async function handleMount(device) {
        setActionBusy(device);
        setFeedback({ type: "info", msg: `Montando ${device}...` });
        try {
            const result = await mountDisk(device);
            if (result?.success) {
                setFeedback({ type: "success", msg: `${device} montado en ${result.mountpoint}` });
                await loadDisks();
                loadDir(result.mountpoint);
            } else {
                setFeedback({ type: "error", msg: result?.error || "Error" });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: e.message });
        } finally {
            setActionBusy(null);
        }
    }

    async function handleUnmount(device) {
        if (!window.confirm(`¿Desmontar ${device}? Los procesos que lo usen se interrumpirán.`)) return;
        setActionBusy(device);
        try {
            const result = await unmountDisk(device);
            if (result?.success) {
                setFeedback({ type: "success", msg: `${device} desmontado` });
                setItems([]);
                setCurrentPath("/mnt/stepad-disk");
                await loadDisks();
            } else {
                setFeedback({ type: "error", msg: result?.error || "Error" });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: e.message });
        } finally {
            setActionBusy(null);
        }
    }

    async function handleResize(device, currentGb) {
        const confirmText = window.prompt(
            `Redimensionar ${device} (actual ${currentGb} GB).\n\n`
            + "Agrandar es seguro. Reducir solo ext4 y desmontada (asumís el riesgo de pérdida de datos).\n"
            + "Dejalo vacío para crecer hasta usar el espacio libre.\n"
            + "Tamaño en GB:",
            ""
        );
        if (confirmText === null) return;
        const mode = confirmText.trim() ? "custom" : "max";
        if (mode === "custom" && confirmText.trim().toLowerCase() === "x") return;
        const finalConfirm = window.confirm(
            `¿Confirmás el redimensionado de ${device}? ${mode === "max" ? "Se usará todo el espacio libre contiguo." : `Nuevo tamaño: ${confirmText.trim()} GB.`}\n\n`
            + (mode === "custom" && parseFloat(confirmText) < currentGb
                ? "¡ADVERTENCIA! Vas a REDUCIR la partición. Asegurate de que el filesystem quepa y de haber respaldado los datos.\n"
                : "")
            + "Escribe ELIMINAR para continuar:"
        );
        const confirmWord = window.prompt(
            "Para confirmar escribe: ELIMINAR",
            ""
        );
        if (confirmWord === null || confirmWord.trim().toUpperCase() !== "ELIMINAR") return;
        setActionBusy(device);
        try {
            const result = await resizeSharePartition({
                device,
                new_size_gb: mode === "custom" ? parseFloat(confirmText) : null,
                confirm: confirmWord.trim().toUpperCase(),
            });
            if (result?.success) {
                setFeedback({ type: "success", msg: result.message || `${device} redimensionado` });
                await loadDisks();
            } else {
                setFeedback({ type: "error", msg: result?.error || "Error" });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: e.message });
        } finally {
            setActionBusy(null);
        }
    }

    async function handleCreateFolder() {
        if (!newFolder.trim()) return;
        setActionBusy("mkdir");
        try {
            const result = await createDiskFolder(currentPath, newFolder.trim());
            if (result?.success) {
                setFeedback({ type: "success", msg: `Carpeta "${newFolder}" creada` });
                setNewFolder("");
                loadDir(currentPath);
            } else {
                setFeedback({ type: "error", msg: result?.error || "Error" });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: e.message });
        } finally {
            setActionBusy(null);
        }
    }

    async function handleDelete(path, name) {
        if (!window.confirm(`¿Eliminar "${name}"?`)) return;
        setActionBusy(name);
        try {
            const result = await deleteDiskItem(path);
            if (result?.success) {
                setFeedback({ type: "success", msg: `"${name}" eliminado` });
                loadDir(currentPath);
            } else {
                setFeedback({ type: "error", msg: result?.error || "Error" });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: e.message });
        } finally {
            setActionBusy(null);
        }
    }

    if (loading) return <div className="st-page"><div className="st-empty">Cargando...</div></div>;

    return (
        <div className="st-page">
            <h1>Discos</h1>
            <p className="st-subtitle">Gestiona los discos conectados, monta particiones y explora archivos.</p>

            {feedback && (
                <div className={`st-feedback ${feedback.type}`}>
                    {feedback.msg}
                    <button className="st-btn" style={{ marginLeft: 8, padding: "2px 8px" }} onClick={() => setFeedback(null)}>×</button>
                </div>
            )}

            {disks.length === 0 ? (
                <div className="st-empty">No se detectaron discos conectados.</div>
            ) : (
                disks.map((disk) => (
                    <div key={disk.name} className="st-disk">
                        <div className="st-disk-header">
                            <div>
                                <div className="st-disk-name">💾 {disk.name}</div>
                                <div className="st-disk-model">{disk.model}</div>
                            </div>
                            <div className="st-disk-size">{disk.size}</div>
                        </div>
                        {disk.partitions.map((part) => (
                            <div key={part.name} className="st-part">
                                <div className="st-part-info">
                                    <div className="st-part-name">{part.name}</div>
                                    <div className="st-part-detail">
                                        {part.size} · {part.fstype} {part.mountpoint ? `· ${part.mountpoint}` : ""}
                                    </div>
                                    {part.mounted && part.total_bytes != null && (
                                        <div className="st-part-usage">
                                            <div className="st-usage-bar">
                                                <div
                                                    className="st-usage-fill"
                                                    style={{ width: `${Math.min(100, (part.used_bytes / part.total_bytes) * 100).toFixed(1)}%` }}
                                                ></div>
                                            </div>
                                            <span className="st-usage-text">
                                                {formatSize(part.used_bytes)} usado de {formatSize(part.total_bytes)} · {formatSize(part.free_bytes)} libres
                                            </span>
                                        </div>
                                    )}
                                </div>
                                {part.mounted ? (
                                    <>
                                        <button className="st-btn" onClick={() => loadDir(part.mountpoint)}>
                                            Explorar
                                        </button>
                                        <button className="st-btn danger" onClick={() => handleUnmount(part.name)} disabled={actionBusy === part.name}>
                                            Desmontar
                                        </button>
                                    </>
                                ) : (
                                    <button className="st-btn primary" onClick={() => handleMount(part.name)} disabled={actionBusy === part.name}>
                                        {actionBusy === part.name ? "Montando..." : "Montar"}
                                    </button>
                                )}
                                <button
                                    className="st-btn"
                                    onClick={() => handleResize(part.name, Math.round((part.total_bytes || 0) / 1024 / 1024 / 1024))}
                                    disabled={actionBusy === part.name}
                                    title="Redimensionar partición (agrandar/reducir)"
                                >
                                    Redimensionar
                                </button>
                            </div>
                        ))}
                    </div>
                ))
            )}

            {items.length > 0 && (
                <div className="st-card st-explorer">
                    <div className="st-explorer-header">
                        <button className="st-btn" onClick={() => {
                            const parent = currentPath.split("/").slice(0, -1).join("/") || "/mnt/stepad-disk";
                            loadDir(parent);
                        }}>← Atrás</button>
                        <div className="st-explorer-path">{currentPath}</div>
                        <input className="st-mkdir-input" placeholder="Nueva carpeta..." value={newFolder} onChange={(e) => setNewFolder(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleCreateFolder()} />
                        <button className="st-btn primary" onClick={handleCreateFolder} disabled={!newFolder.trim() || actionBusy === "mkdir"}>
                            Crear
                        </button>
                    </div>
                    {exploring ? (
                        <div className="st-empty">Cargando...</div>
                    ) : (
                        items.map((item) => (
                            <div key={item.name} className="st-file-row">
                                <div className="st-file-icon">
                                    {item.type === "directory" ? "📁" : item.type === "restricted" ? "🔒" : "📄"}
                                </div>
                                <div
                                    className={`st-file-name ${item.type === "directory" ? "dir" : ""}`}
                                    onClick={() => item.type === "directory" && loadDir(`${currentPath}/${item.name}`)}
                                >
                                    {item.name}
                                </div>
                                <div className="st-file-size">{item.type === "file" ? formatSize(item.size) : "—"}</div>
                                <div className="st-file-date">{formatDate(item.modified)}</div>
                                {item.type !== "restricted" && (
                                    <button className="st-btn" style={{ padding: "2px 8px" }} onClick={() => handleDelete(`${currentPath}/${item.name}`, item.name)} disabled={actionBusy === item.name}>
                                        🗑
                                    </button>
                                )}
                            </div>
                        ))
                    )}
                </div>
            )}
        </div>
    );
}
