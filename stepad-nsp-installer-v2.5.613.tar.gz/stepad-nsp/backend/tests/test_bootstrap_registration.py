"""Catch invalid lifecycle.register calls before a release."""

import ast
from pathlib import Path


def test_bootstrap_registers_one_component_per_call():
    path = Path(__file__).resolve().parents[1] / "core" / "bootstrap.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))

    bad = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "register":
            continue
        if len(node.args) != 1 or node.keywords:
            bad.append(node.lineno)

    assert not bad, f"register() debe recibir exactamente un componente: líneas {bad}"
