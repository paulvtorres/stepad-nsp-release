from datetime import timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.alerts.models.alert import Alert
from backend.alerts.services.alert_escalation_service import AlertEscalationService
from backend.core.database.base import Base
from backend.notifications.models.notification_settings import NotificationSettings
from backend.shared.datetime_utils import utcnow


def db_session():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_alerta_critica_vieja_se_escala(monkeypatch):
    db = db_session()
    db.add(NotificationSettings(
        id=1,
        alert_escalation_enabled=True,
        alert_escalation_minutes=30,
        alert_escalation_emails="jefe@empresa.com",
    ))
    alert = Alert(
        alert_type="RESOURCE_CPU",
        severity="critical",
        title="CPU crítica",
        message="95%",
        created_at=utcnow() - timedelta(hours=1),
    )
    db.add_all([alert])
    db.commit()

    class Delivery:
        smtp_host = "smtp"
        from_email = "nsp@empresa.com"
        to_emails = "jefe@empresa.com"
        cc_emails = ""
        bcc_emails = ""

    monkeypatch.setattr(
        "backend.alerts.services.alert_escalation_service.build_delivery_context",
        lambda *args, **kwargs: Delivery(),
    )
    monkeypatch.setattr(
        "backend.alerts.services.alert_escalation_service.EmailService.send_html",
        lambda *args, **kwargs: {"success": True},
    )

    result = AlertEscalationService().run(db)

    db.refresh(alert)
    assert result["sent"] == 1
    assert alert.escalated_at is not None


def test_alerta_resuelta_no_se_escala(monkeypatch):
    db = db_session()
    db.add(NotificationSettings(
        id=1,
        alert_escalation_enabled=True,
        alert_escalation_minutes=30,
        alert_escalation_emails="jefe@empresa.com",
    ))
    alert = Alert(
        alert_type="RESOURCE_CPU",
        severity="critical",
        title="CPU crítica",
        message="95%",
        created_at=utcnow() - timedelta(hours=1),
        resolved_at=utcnow(),
    )
    db.add(alert)
    db.commit()

    assert AlertEscalationService().run(db)["sent"] == 0
