from backend.backups.services.disaster_recovery_service import (
    DisasterRecoveryService,
)
from backend.shared.utils.datetimes import now_ecuador


def test_dr_ready_con_backup_y_restauracion(monkeypatch):
    import backend.backups.services.backup_service as backup
    import backend.backups.services.restore_verification_service as restore
    import backend.backups.services.system_restore_verification_service as system

    monkeypatch.setattr(
        backup.BackupService,
        "get_settings",
        lambda self, db: {"last_backup_at": now_ecuador().isoformat()},
    )
    monkeypatch.setattr(
        restore.RestoreVerificationService,
        "status",
        lambda self: {"success": True, "message": "OK"},
    )
    monkeypatch.setattr(
        system.SystemRestoreVerificationService,
        "status",
        lambda self: {"success": True, "message": "OK"},
    )

    result = DisasterRecoveryService().get(None)

    assert result["ready"] is True
    assert result["status"] == "ready"


def test_dr_degradado_sin_respaldo(monkeypatch):
    import backend.backups.services.backup_service as backup
    import backend.backups.services.restore_verification_service as restore
    import backend.backups.services.system_restore_verification_service as system

    monkeypatch.setattr(
        backup.BackupService,
        "get_settings",
        lambda self, db: {"last_backup_at": None},
    )
    monkeypatch.setattr(
        restore.RestoreVerificationService,
        "status",
        lambda self: {"success": False, "message": "sin verificaciones"},
    )
    monkeypatch.setattr(
        system.SystemRestoreVerificationService,
        "status",
        lambda self: {"success": False, "message": "sin verificaciones"},
    )

    result = DisasterRecoveryService().get(None)

    assert result["ready"] is False
    assert result["recommendations"]
