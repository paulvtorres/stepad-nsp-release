"""Escalate unresolved critical alerts to a separate recipient list."""

from __future__ import annotations

from datetime import timedelta

from backend.alerts.models.alert import Alert
from backend.core.database.session import SessionLocal
from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository,
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.email_settings_service import (
    build_delivery_context,
)
from backend.shared.datetime_utils import utcnow
from backend.shared.utils.datetimes import to_iso_utc
from backend.shared.logging.logger import logger


class AlertEscalationService:

    MAX_PER_RUN = 20

    def run(self, db=None):

        own = db is None
        if own:
            db = SessionLocal()

        try:
            settings = NotificationSettingsRepository().get(db)

            if not settings.alert_escalation_enabled:
                return {"sent": 0}

            recipients = (settings.alert_escalation_emails or "").strip()
            if not recipients:
                return {"sent": 0}

            minutes = max(1, min(1440, int(settings.alert_escalation_minutes or 30)))
            cutoff = utcnow() - timedelta(minutes=minutes)
            alerts = (
                db.query(Alert)
                .filter(
                    Alert.severity == "critical",
                    Alert.resolved_at.is_(None),
                    Alert.escalated_at.is_(None),
                    Alert.created_at <= cutoff,
                )
                .order_by(Alert.id)
                .limit(self.MAX_PER_RUN)
                .all()
            )

            sent = 0
            for alert in alerts:

                delivery = build_delivery_context(
                    db,
                    to_emails=recipients,
                    cc_emails=settings.alert_escalation_cc_emails or "",
                    bcc_emails=settings.alert_escalation_bcc_emails or "",
                )
                if delivery is None:
                    break

                subject = f"ESCALAMIENTO: {alert.title}"[:255]
                body = (
                    f"<h3>Alerta crítica sin resolver</h3>"
                    f"<p><strong>{alert.title}</strong></p>"
                    f"<p>{alert.message}</p>"
                    f"<p>Severidad: <strong>{alert.severity}</strong><br>"
                    f"Primera vez: {to_iso_utc(alert.created_at)}<br>"
                    f"Última vez: {to_iso_utc(alert.last_seen_at)}</p>"
                    f"<p>Revisar en <em>Alertas</em> y resolver o silenciar.</p>"
                )
                result = EmailService().send_html(
                    delivery, subject, body, channel="escalation"
                )

                # The outbox keeps retrying a failed send; mark the alert
                # once it has been handed off so it is not duplicated.
                if result.get("success") or "outbox" in str(result.get("message", "")).lower():
                    alert.escalated_at = utcnow()
                    db.add(alert)
                    db.commit()
                    sent += 1
                else:
                    logger.warning(
                        "Escalamiento de alerta %s no enviado: %s",
                        alert.id,
                        result.get("message"),
                    )

            return {"sent": sent}

        finally:
            if own:
                db.close()
