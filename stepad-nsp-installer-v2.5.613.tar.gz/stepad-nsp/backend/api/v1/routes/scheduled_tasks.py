from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.core.database.dependency import get_db
from backend.shared.constants.user_roles import UserRoles
from backend.maintenance.services.scheduled_tasks_service import (
    ScheduledTasksService,
)


router = APIRouter(prefix="/maintenance", tags=["maintenance"])


@router.get("/scheduled")
def scheduled(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return ScheduledTasksService().status(db)


@router.post("/vacuum")
def run_vacuum(
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    from backend.maintenance.services.database_maintenance_service import (
        DatabaseMaintenanceService,
    )

    return DatabaseMaintenanceService().run()
