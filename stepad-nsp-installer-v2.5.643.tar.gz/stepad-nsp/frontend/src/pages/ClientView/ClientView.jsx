import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import {
    getAdsBlocked,
    getAlerts,
    getBandwidthLive,
    getDevices,
    getIpsStatus,
    getProtectionSummary,
    getSystemMonitoring,
    getSystemVersion,
    getWanMonitorStatus,
} from "../../services/api";

import "./client-view.css";


function formatMbps(value) {

    const number = Number(value || 0);

    if (number >= 1000) return `${(number / 1000).toFixed(2)} Gb/s`;

    return `${number.toFixed(number >= 10 ? 1 : 2)} Mb/s`;

}


function formatNumber(value) {

    return new Intl.NumberFormat("es-EC").format(Number(value || 0));

}


function formatUptime(seconds) {

    if (!seconds) return "—";

    const days = Math.floor(seconds / 86400);

    const hours = Math.floor((seconds % 86400) / 3600);

    return days > 0 ? `${days}d ${hours}h` : `${hours}h`;

}


function DeviceShape({ type }) {

    return (
        <span className={`cv-device-shape ${type}`} aria-hidden="true" />
    );

}


export default function ClientView() {

    const [traffic, setTraffic] = useState(null);

    const [wan, setWan] = useState(null);

    const [devices, setDevices] = useState([]);

    const [protection, setProtection] = useState(null);

    const [ads, setAds] = useState(null);

    const [ips, setIps] = useState(null);

    const [alerts, setAlerts] = useState(null);

    const [hardware, setHardware] = useState(null);

    const [version, setVersion] = useState(null);

    const [lastUpdated, setLastUpdated] = useState(null);

    const [error, setError] = useState("");


    async function loadTraffic() {

        try {

            setTraffic(await getBandwidthLive(true));

            setLastUpdated(new Date());

        } catch (err) {

            setError("Sin lectura de tráfico en este momento.");

        }

    }


    async function loadStatus() {

        const results = await Promise.allSettled([
            getWanMonitorStatus(),
            getDevices(),
            getProtectionSummary(1),
            getAdsBlocked(1, 1),
            getIpsStatus(),
            getAlerts(5),
            getSystemMonitoring(),
            getSystemVersion(),
        ]);

        const [
            wanResult,
            devicesResult,
            protectionResult,
            adsResult,
            ipsResult,
            alertsResult,
            hardwareResult,
            versionResult,
        ] = results;

        if (wanResult.status === "fulfilled") setWan(wanResult.value);
        if (devicesResult.status === "fulfilled") setDevices(devicesResult.value || []);
        if (protectionResult.status === "fulfilled") setProtection(protectionResult.value);
        if (adsResult.status === "fulfilled") setAds(adsResult.value);
        if (ipsResult.status === "fulfilled") setIps(ipsResult.value);
        if (alertsResult.status === "fulfilled") setAlerts(alertsResult.value);
        if (hardwareResult.status === "fulfilled") setHardware(hardwareResult.value);
        if (versionResult.status === "fulfilled") setVersion(versionResult.value);

    }


    useEffect(() => {

        loadTraffic();

        loadStatus();

        const trafficTimer = setInterval(loadTraffic, 5000);

        const statusTimer = setInterval(loadStatus, 20000);

        return () => {

            clearInterval(trafficTimer);

            clearInterval(statusTimer);

        };

    }, []);


    const wanEntry = Object.values(wan?.interfaces || {})[0] || {};

    const internetOk = Boolean(wanEntry.link_up && wanEntry.ping_ok);

    const onlineDevices = devices.filter(
        (device) => (device.presence_status || device.status) === "ONLINE",
    ).length;

    const dnsBlocked = protection?.dns?.blocked ?? 0;

    const adsBlocked = ads?.total ?? 0;

    const ipsAlerts = ips?.alerts_last_24h ?? 0;

    const unreadAlerts = alerts?.unread ?? 0;

    const latency = wanEntry.latency_ms;

    const loss = wanEntry.packet_loss ?? 0;

    const quality = wanEntry.quality?.label_es || "Sin medición";

    const stable = internetOk && loss < 1 && (!latency || latency < 100);

    const totalTraffic = (traffic?.wan?.rx_mbps || 0) + (traffic?.wan?.tx_mbps || 0);

    const protectedNow = Boolean(ips?.suricata_running && ads?.category?.enabled);


    return (

        <div className="cv-page">

            <header className="cv-hero">

                <div className="cv-hero-glow" aria-hidden="true" />

                <div>
                    <span className="cv-eyebrow">SERVICIO DE RED</span>
                    <h1>Tu red está protegida<span className="cv-live"><i /> 24 / 7</span></h1>
                </div>

                <div className="cv-hero-right">
                    <span className="cv-status-pill">
                        <i className={internetOk ? "ok" : "warn"} />
                        {internetOk ? "SERVICIO ACTIVO" : "REVISANDO ENLACE"}
                    </span>
                    <small>{lastUpdated ? lastUpdated.toLocaleTimeString("es-EC") : "Conectando…"}</small>
                </div>

            </header>

            {error && <div className="cv-error">{error}</div>}

            <section className="cv-flow-panel">

                <div className="cv-flow-top">
                    <div>
                        <span className="cv-flow-kicker">FLUJO DE INFORMACIÓN</span>
                        <h2>Lo útil pasa. Lo malo se detiene.</h2>
                    </div>

                    <span className={`cv-clean-pill ${stable ? "ok" : "warn"}`}>
                        <i />
                        {stable ? "SIN CUELLOS DE BOTELLA" : "REVISANDO CALIDAD"}
                    </span>
                </div>

                <div className="cv-flow" role="img" aria-label="El tráfico útil atraviesa el NSP hacia los equipos; el tráfico malicioso se bloquea en el escudo">

                    <div className="cv-zone internet">
                        <span className="cv-zone-icon globe" aria-hidden="true" />
                        <strong>Internet</strong>
                        <small>{internetOk ? "Conectada" : "Sin respuesta"}</small>
                    </div>

                    <div className="cv-rail good" aria-hidden="true">
                        <span className="cv-rail-label">TRÁFICO ÚTIL</span>
                        <span className="cv-packet g1" />
                        <span className="cv-packet g2" />
                        <span className="cv-packet g3" />
                        <span className="cv-packet g4" />
                    </div>

                    <div className="cv-shield-wrap">
                        <span className="cv-orbit orbit-one" aria-hidden="true" />
                        <span className="cv-orbit orbit-two" aria-hidden="true" />
                        <span className="cv-shield" aria-hidden="true" />
                        <strong>NSP</strong>
                        <small>{protectedNow ? "Protección activa" : "Iniciando"}</small>
                        <span className="cv-block-burst" aria-hidden="true" />
                    </div>

                    <div className="cv-rail good outbound" aria-hidden="true">
                        <span className="cv-packet g1" />
                        <span className="cv-packet g2" />
                        <span className="cv-packet g3" />
                    </div>

                    <div className="cv-rail bad" aria-hidden="true">
                        <span className="cv-rail-label danger">AMENAZAS</span>
                        <span className="cv-packet r1" />
                        <span className="cv-packet r2" />
                        <span className="cv-packet r3" />
                    </div>

                    <div className="cv-zone lan">
                        <strong>Equipos de trabajo</strong>
                        <small>{onlineDevices} conectados</small>
                        <div className="cv-devices">
                            <DeviceShape type="pc" />
                            <DeviceShape type="phone" />
                            <DeviceShape type="printer" />
                        </div>
                    </div>

                </div>

                <div className="cv-flow-legend">
                    <span><i className="good" /> Permitido</span>
                    <span><i className="bad" /> Bloqueado</span>
                    <span><i className="info" /> Registrado</span>
                </div>

            </section>

            <div className="cv-kpis">

                <div className="cv-kpi accent">
                    <span>Tráfico ahora</span>
                    <strong>{formatMbps(totalTraffic)}</strong>
                    <small>Entrada + salida</small>
                </div>

                <div className={`cv-kpi ${stable ? "ok" : "warn"}`}>
                    <span>Calidad</span>
                    <strong>{latency ? `${latency.toFixed(1)} ms` : "—"}</strong>
                    <small>{quality} · {loss}% pérdida</small>
                </div>

                <div className="cv-kpi">
                    <span>Equipos en línea</span>
                    <strong>{onlineDevices}</strong>
                    <small>de {devices.length || "—"} registrados</small>
                </div>

                <div className="cv-kpi">
                    <span>Amenazas IPS 24 h</span>
                    <strong>{formatNumber(ipsAlerts)}</strong>
                    <small>{ipsAlerts === 0 ? "Sin alertas" : "En revisión"}</small>
                </div>

                <div className="cv-kpi">
                    <span>Bloqueos web 1 h</span>
                    <strong>{formatNumber(dnsBlocked)}</strong>
                    <small>{formatNumber(adsBlocked)} de publicidad</small>
                </div>

                <div className="cv-kpi">
                    <span>Servicio activo</span>
                    <strong>{formatUptime(hardware?.uptime_seconds)}</strong>
                    <small>{version?.version || "NSP"} · 24/7</small>
                </div>

            </div>

            <div className="cv-lower">

                <section className="cv-blocked-panel">

                    <div className="cv-section-head">
                        <div>
                            <span className="cv-flow-kicker">ESCUDO NSP</span>
                            <h2>Lo que se detuvo</h2>
                        </div>
                        <span className="cv-section-count">{formatNumber(dnsBlocked + ipsAlerts)}</span>
                    </div>

                    <div className="cv-blocked-grid">

                        <div className="cv-blocked-item ads">
                            <span className="cv-blocked-icon" aria-hidden="true" />
                            <strong>Publicidad</strong>
                            <b>{formatNumber(adsBlocked)}</b>
                        </div>

                        <div className="cv-blocked-item web">
                            <span className="cv-blocked-icon" aria-hidden="true" />
                            <strong>Sitios no laborales</strong>
                            <b>{formatNumber(Math.max(0, dnsBlocked - adsBlocked))}</b>
                        </div>

                        <div className="cv-blocked-item threats">
                            <span className="cv-blocked-icon" aria-hidden="true" />
                            <strong>Amenazas</strong>
                            <b>{formatNumber(ipsAlerts)}</b>
                        </div>

                    </div>

                </section>

                <section className="cv-trust-panel">

                    <div className="cv-trust-ring" aria-hidden="true">
                        <span />
                    </div>

                    <div>
                        <span className="cv-flow-kicker">CONFIANZA</span>
                        <h2>{stable && ipsAlerts === 0 ? "Red limpia y estable" : "Red bajo vigilancia"}</h2>
                        <div className="cv-trust-tags">
                            <span><i className={stable ? "ok" : "warn"} /> Flujo estable</span>
                            <span><i className={ipsAlerts === 0 ? "ok" : "warn"} /> Sin alertas IPS</span>
                            <span><i className={unreadAlerts === 0 ? "ok" : "warn"} /> {unreadAlerts} avisos pendientes</span>
                        </div>
                    </div>

                    <Link to="/performance" className="cv-detail-link">
                        Ver rendimiento
                    </Link>

                </section>

            </div>

            <footer className="cv-footer">
                <span>Actualización automática · datos reales</span>
                <span>{lastUpdated ? lastUpdated.toLocaleString("es-EC") : "—"}</span>
            </footer>

        </div>

    );

}
