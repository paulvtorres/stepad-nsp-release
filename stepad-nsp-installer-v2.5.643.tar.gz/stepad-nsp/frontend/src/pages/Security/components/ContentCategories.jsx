import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import { useAuth } from "../../../auth/useAuth";

import {
    getContentCategories,
    getContentCategory,
    previewContentCategory,
    setCategoryEnabled,
    addCategoryDomain,
    removeCategoryDomain,
    refreshContentFeed
} from "../../../services/api";


function ContentCategories() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [categories, setCategories] = useState([]);

    const [expanded, setExpanded] = useState(null);

    const [detail, setDetail] = useState(null);

    const [newDomain, setNewDomain] = useState("");

    const [previewDomain, setPreviewDomain] = useState("");

    const [preview, setPreview] = useState(null);

    const [domainSearch, setDomainSearch] = useState("");

    const [domainsBusy, setDomainsBusy] = useState(false);

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);

    const activeCount = categories.filter((item) => item.enabled).length;

    const adsCategory = categories.find((item) => item.key === "ads_trackers");


    useEffect(() => {

        let cancelled = false;

        getContentCategories()

            .then((data) => {
                if (!cancelled) setCategories(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleRefreshFeed(categoryKey = "malware") {

        setBusy(true);

        try {

            const result = await refreshContentFeed(categoryKey);

            alert(`Feed actualizado: ${result?.added ?? 0} dominios nuevos (${result?.total ?? 0} en total).`);

            const data = await getContentCategories();

            setCategories(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function loadDetail(key) {

        setExpanded(key);

        setNewDomain("");

        setPreviewDomain("");

        setPreview(null);

        setDomainSearch("");

        try {

            const data = await getContentCategory(key, 200, 0, "");

            setDetail(data);

        } catch (err) {

            setError(err.message);

        }

    }


    async function handleToggle(category) {

        setError(null);

        setBusy(true);

        try {

            await setCategoryEnabled(category.key, !category.enabled);

            const data = await getContentCategories();

            setCategories(data || []);

            if (expanded === category.key) {

                const d = await getContentCategory(category.key, 200, 0, domainSearch);

                setDetail(d);

            }

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    useEffect(() => {

        if (!expanded || !detail || detail.key !== expanded) {
            return undefined;
        }

        const timer = setTimeout(async () => {

            try {

                const data = await getContentCategory(
                    expanded,
                    200,
                    0,
                    domainSearch,
                );

                setDetail(data);

            } catch (err) {

                setError(err.message);

            }

        }, 350);

        return () => clearTimeout(timer);

    }, [domainSearch, expanded]);


    async function handleLoadMoreDomains() {

        if (!expanded || !detail?.has_more) {
            return;
        }

        setDomainsBusy(true);

        try {

            const data = await getContentCategory(
                expanded,
                200,
                detail.domains.length,
                domainSearch,
            );

            setDetail((current) => ({
                ...data,
                domains: [...(current?.domains || []), ...(data.domains || [])],
            }));

        } catch (err) {

            setError(err.message);

        } finally {

            setDomainsBusy(false);

        }

    }


    async function handlePreview() {

        if (!expanded) return;

        setError(null);

        try {

            setPreview(
                await previewContentCategory(expanded, previewDomain.trim())
            );

        } catch (err) {

            setError(err.message);

        }

    }


    async function handleAddDomain() {

        if (!expanded || !newDomain.trim()) return;

        setError(null);

        setBusy(true);

        try {

            await addCategoryDomain(expanded, newDomain.trim());

            setNewDomain("");

            const [detailData, data] = await Promise.all([
                getContentCategory(expanded, 200, 0, domainSearch),
                getContentCategories(),
            ]);

            setDetail(detailData);

            setCategories(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRemoveDomain(domain) {

        if (!expanded) return;

        setError(null);

        setBusy(true);

        try {

            await removeCategoryDomain(expanded, domain);

            const [detailData, data] = await Promise.all([
                getContentCategory(expanded, 200, 0, domainSearch),
                getContentCategories(),
            ]);

            setDetail(detailData);

            setCategories(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="security-section">

            <h3>Filtrado por categoría</h3>

            <p className="security-description">

                Bloqueos globales de raiz para toda la red: porno, apuestas
                y juegos se mantienen activos siempre. Malware y el resto de
                categorías se gestionan aquí. Para restricciones extra por
                área (redes sociales, streaming…), use Grupos (DNS por
                grupos).

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            <div className="category-summary-bar">
                <span><strong>{activeCount}</strong> categorías activas</span>
                {adsCategory && (
                    <span className={adsCategory.enabled ? "summary-on" : "summary-off"}>
                        Anuncios/rastreadores: <strong>{adsCategory.enabled ? "activo" : "inactivo"}</strong>
                        {" · "}{adsCategory.domains.toLocaleString()} dominios
                        {" · "}
                        <Link className="category-live-link" to="/protection?view=ads">
                            Ver bloqueos en vivo
                        </Link>
                    </span>
                )}
            </div>

            <div className="category-list">

                {
                    categories.map((category) => (
                        <div key={category.key} className={`category-row ${category.enabled ? "on" : ""}`}>

                            <div className="category-head" onClick={() => loadDetail(category.key)}>

                                <div className="category-info">

                                    <span className="category-name">{category.name}</span>

                                    <span className="category-meta">
                                        {category.domains.toLocaleString()} dominios ·{" "}
                                        {category.key === "ads_trackers" && "feed cargado · "}
                                        {category.is_root
                                            ? "bloqueo de raíz"
                                            : category.enabled
                                                ? "activa"
                                                : "inactiva"}
                                    </span>
                                    <span className={`category-state ${category.enabled ? "on" : "off"}`}>
                                        {category.enabled ? "ACTIVO" : "INACTIVO"}
                                    </span>

                                    {category.key === "ads_trackers" && (
                                        <Link
                                            className="category-live-link"
                                            to="/protection?view=ads"
                                            onClick={(event) => event.stopPropagation()}
                                        >
                                            Ver bloqueos en vivo
                                        </Link>
                                    )}

                                </div>

                                {
                                    isAdmin && !category.is_root && (
                                        <button
                                            className={`category-toggle ${category.enabled ? "on" : ""}`}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleToggle(category);
                                            }}
                                            disabled={busy}
                                        >
                                            {category.enabled ? "Desactivar" : "Activar"}
                                        </button>
                                    )
                                }

                                {
                                    isAdmin && (category.key === "malware" || category.key === "ads_trackers") && (
                                        <button
                                            className="category-refresh"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleRefreshFeed(category.key);
                                            }}
                                            disabled={busy}
                                            title={
                                                category.key === "ads_trackers"
                                                    ? "Actualizar anuncios y rastreadores"
                                                    : "Actualizar dominios maliciosos/phishing"
                                            }
                                        >
                                            Actualizar feed
                                        </button>
                                    )
                                }

                            </div>

                            {
                                expanded === category.key && detail && detail.key === category.key && (
                                    <div className="category-detail">

                                        <div className="category-preview">
                                            <strong>Simulación</strong>
                                            <div className="category-add">
                                                <input
                                                    type="text"
                                                    value={previewDomain}
                                                    onChange={(e) => setPreviewDomain(e.target.value)}
                                                    placeholder="dominio a probar, ej. dobleclick.net"
                                                />
                                                <button
                                                    className="secondary-button"
                                                    onClick={handlePreview}
                                                    disabled={!previewDomain.trim()}
                                                >
                                                    Probar
                                                </button>
                                            </div>
                                            {preview && (
                                                <div className={`category-preview-result ${preview.would_block ? "blocked" : "allowed"}`}>
                                                    {preview.would_block
                                                        ? `Se bloquearía: coincide con ${preview.matched_domain}`
                                                        : "No coincide con esta categoría."}
                                                    <br />
                                                    <span>
                                                        {preview.domain_count} dominios · {preview.enabled ? "categoría activa" : "categoría inactiva"}
                                                    </span>
                                                </div>
                                            )}
                                        </div>

                                        <div className="category-domain-tools">

                                            <input
                                                type="search"
                                                value={domainSearch}
                                                onChange={(e) => setDomainSearch(e.target.value)}
                                                placeholder="Buscar en todos los dominios..."
                                                autoComplete="off"
                                            />

                                            <span>
                                                {detail.domains.length} de {detail.domain_count ?? detail.domains.length} dominios
                                            </span>

                                        </div>

                                        <div className="category-domains">

                                            {
                                                detail.domains.map((domain) => (
                                                    <span key={domain} className="category-domain-chip">
                                                        {domain}
                                                        {
                                                            isAdmin && (
                                                                <button
                                                                    className="category-remove"
                                                                    onClick={() => handleRemoveDomain(domain)}
                                                                    disabled={busy}
                                                                    title="Quitar dominio"
                                                                >
                                                                    ✕
                                                                </button>
                                                            )
                                                        }
                                                    </span>
                                                ))
                                            }

                                        </div>

                                        {
                                            detail.has_more && (
                                                <button
                                                    type="button"
                                                    className={`secondary-button category-more${domainsBusy ? " btn-busy" : ""}`}
                                                    onClick={handleLoadMoreDomains}
                                                    disabled={domainsBusy}
                                                >
                                                    Mostrar 200 más
                                                </button>
                                            )
                                        }

                                        {
                                            isAdmin && (
                                                <div className="category-add">
                                                    <input
                                                        type="text"
                                                        value={newDomain}
                                                        onChange={(e) => setNewDomain(e.target.value)}
                                                        placeholder="dominio.com"
                                                    />
                                                    <button
                                                        className="primary-button"
                                                        onClick={handleAddDomain}
                                                        disabled={busy || !newDomain.trim()}
                                                    >
                                                        Añadir dominio
                                                    </button>
                                                </div>
                                            )
                                        }

                                    </div>
                                )
                            }

                        </div>
                    ))
                }

            </div>

        </div>

    );

}


export default ContentCategories;
