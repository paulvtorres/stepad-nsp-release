"""Alertas de capacidad del pool: pool bajo/agotado/recuperado, tendencia,
correo y resolucion automatica. Se mezcla en DhcpReconciler.
"""

from __future__ import annotations

from backend.shared.logging.logger import logger


class PoolAlertsMixin:

    def _default_alert(self, alert_type, severity, title, message) -> None:

        try:

            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                AlertService().create(
                    db,
                    alert_type=alert_type,
                    severity=severity,
                    title=title[:120],
                    message=message[:500],
                )

                db.commit()

            finally:

                db.close()

        except Exception as error:

            logger.warning("DHCP: no se pudo crear la alerta %s: %s", alert_type, error)

    def _default_resolve(self, *alert_types: str) -> None:
        """Marca como RESUELTAS las alertas activas cuando la condicion se
        fue. Sin esto, una alerta critica que ya no aplica seguiria sin
        resolver y el escalamiento avisaria "sin resolver" de algo que ya
        paso."""

        try:

            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                for alert_type in alert_types:

                    AlertService().resolve(db, alert_type)

            finally:

                db.close()

        except Exception as error:

            logger.warning("DHCP: no se pudieron resolver alertas %s: %s", alert_types, error)

    def _resolve_alerts(self, *alert_types: str) -> None:

        try:

            self._alert_resolver(*alert_types)

        except Exception as error:

            logger.warning("DHCP: resolver alertas fallo: %s", error)

    def _notify_by_email(self, kind: str, pool: dict, was_low: bool, low: bool) -> None:

        if self._email_notifier is None:

            return

        try:

            self._email_notifier(
                kind,
                int(pool.get("free") or 0),
                int(pool.get("threshold") or 0),
            )

        except Exception as error:

            logger.warning("DHCP: no se pudo enviar el aviso por correo: %s", error)

    def _notify_pool(self, pool: dict) -> None:

        """Alertas de capacidad del pool FIJO: bajo, agotado y recuperado.

        Solo en las transiciones. Agotado (0 libres) es CRITICO: ahi hay
        equipos que no pueden obtener IP. Al volver el espacio se avisa UNA
        sola vez, cuando ya no esta ni bajo ni agotado. El pool nunca se
        amplia: lo unico que hace el sistema es liberar lo que no se usa y
        avisar.
        """

        if not pool:

            return

        was_low = bool(self._state.get("pool_low"))

        was_exhausted = bool(self._state.get("pool_exhausted"))

        low = bool(pool.get("low"))

        free = int(pool.get("free") or 0)

        exhausted = free <= 0

        if was_exhausted and not exhausted:

            self._resolve_alerts("DHCP_POOL_EXHAUSTED", "DHCP_NO_ADDRESS")

        if was_low and not low:

            self._resolve_alerts("DHCP_POOL_LOW", "DHCP_POOL_TREND")

        if low and not was_low:

            self._notify_by_email("low", pool, was_low, low)

            if not exhausted:

                self._alert_notifier(
                    "DHCP_POOL_LOW",
                    "warning",
                    "DHCP: pool de IPs casi agotado",
                    (
                        f"Quedan {free} direcciones libres "
                        f"(umbral {pool.get('threshold')}). STEPAD libera "
                        "automaticamente los leases de equipos ausentes; "
                        "las reservas no se tocan. El pool es fijo: no se "
                        "amplia."
                    ),
                )

        if exhausted and not was_exhausted:

            self._alert_notifier(
                "DHCP_POOL_EXHAUSTED",
                "critical",
                "DHCP: no quedan IPs libres",
                (
                    "El pool no tiene direcciones libres: los equipos "
                    "nuevos NO pueden obtener IP. STEPAD libera de "
                    "inmediato los leases de equipos ausentes (las "
                    "reservas no se tocan). Si este aviso persiste, el "
                    "pool esta lleno de equipos conectados: revisa cuales "
                    "son o reduce el lease_time."
                ),
            )

        if (was_low or was_exhausted) and not low:

            self._notify_by_email("recovered", pool, was_low, low)

            self._alert_notifier(
                "DHCP_POOL_RECOVERED",
                "info",
                "DHCP: el pool de IPs tiene espacio nuevamente",
                (
                    f"Direcciones libres: {free} "
                    f"(umbral {pool.get('threshold')})."
                ),
            )

        self._state["pool_low"] = low

        self._state["pool_exhausted"] = exhausted

        self._notify_pool_trend(pool)

    def _notify_pool_trend(self, pool: dict) -> None:
        """Avisa si el consumo reciente indica agotamiento cercano."""

        import time

        free = int(pool.get("free") or 0)

        threshold = int(pool.get("threshold") or 0)

        if free > max(20, threshold * 2):

            return

        now = time.monotonic()

        self._pool_samples.append((now, free))

        self._pool_samples = [
            (stamp, value)
            for stamp, value in self._pool_samples
            if now - stamp <= 3600
        ][-120:]

        if len(self._pool_samples) < 2:

            return

        first_stamp, first_free = self._pool_samples[0]

        elapsed = now - first_stamp

        if elapsed < 300:

            return

        drop = first_free - free

        if drop <= 0:

            return

        rate = drop / (elapsed / 3600)  # IPs por hora

        if rate <= 0:

            return

        eta = free / rate

        if eta > 24:

            return

        self._alert_notifier(
            "DHCP_POOL_TREND",
            "warning",
            "DHCP: el pool se está agotando",
            (
                f"Quedan {free} IP(s) libres. Consumo reciente: "
                f"~{rate:.1f} IP/hora; a este ritmo se agotaría en "
                f"~{eta:.1f} hora(s). STEPAD liberará leases retenidos; "
                "las reservas no se tocan."
            ),
        )
