"""Reciclaje de leases de equipos ausentes cuando el pool se queda sin IPs.
Se mezcla en DhcpReconciler.
"""

from __future__ import annotations

from backend.shared.logging.logger import logger
from backend.dhcp.domain.leases import parse_leases
from backend.dhcp.domain.reclaim import select_reclaimable
from datetime import timedelta
from backend.shared.datetime_utils import utcnow


class LeaseReclaimMixin:

    def signal_no_address(self, seconds: int = 120) -> None:
        """Un equipo pidio IP y no habia: durante `seconds` el reciclaje
        trata el pool como agotado, aunque las cifras digan otra cosa."""

        import time

        self._no_address_until = time.monotonic() + max(1, int(seconds))

    def _reclaim_if_needed(self, pool: dict | None = None, config=None) -> int:

        """Libera leases de equipos inactivos cuando el pool esta bajo."""

        import time as _time

        signaled = _time.monotonic() < getattr(
            self, "_no_address_until", float("-inf")
        )

        if not signaled and (not pool or not pool.get("low")):

            return 0

        pool = pool or {}

        try:

            config = self._get_config_service().get_dhcp_config() or {}

            if not config.get("pool_reclaim_enabled", True):

                return 0

            # La reclamación solo corre cuando el pool cruzó el umbral.
            # En ese momento no se puede esperar 7 días: se liberan leases
            # de equipos que no están en ARP y no se vieron en la red en
            # los últimos `pool_emergency_reclaim_minutes` minutos.
            import time

            free = 0 if signaled else int((pool or {}).get("free") or 0)
            exhausted = free <= 0
            threshold = int((pool or {}).get("threshold") or 0)
            configured_target = int(
                config.get("pool_reclaim_target_free", 10) or 10
            )
            target_free = max(
                threshold,
                max(1, min(500, configured_target)),
            )
            needed = max(0, target_free - free)
            if needed <= 0:
                return 0
            raw_cooldown = config.get("pool_reclaim_cooldown_seconds")

            cooldown = max(
                0,
                min(3600, 60 if raw_cooldown is None else int(raw_cooldown)),
            )
            now = time.monotonic()
            last_attempt = getattr(self, "_last_reclaim_attempt", float("-inf"))
            if (
                cooldown
                and not signaled
                and not exhausted
                and now - last_attempt < cooldown
            ):
                return 0
            self._last_reclaim_attempt = now
            minutes = max(
                1,
                int(
                    config.get("pool_emergency_reclaim_minutes")
                    or 60
                ),
            )

            # Con el pool AGOTADO no se espera a la ventana de inactividad:
            # alcanza con que la presencia diga OFFLINE (sin ARP/DNS/ping en
            # los ultimos 30 min). Un equipo conectado nunca se libera.
            cutoff = utcnow() if exhausted else utcnow() - timedelta(minutes=minutes)

        except Exception as error:

            logger.debug("DhcpReconciler: sin config de reclamacion: %s", error)

            return 0

        live_ips: set[str] = set()

        meta: dict = {}

        try:

            from backend.core.database.session import SessionLocal
            from backend.network.devices.models.network_device import (
                NetworkDevice,
            )
            from backend.network.devices.services.device_classifier import (
                DeviceClassifier,
            )
            from backend.network.devices.services.device_presence_service import (
                DevicePresenceService,
            )

            db = SessionLocal()

            try:

                # Presencia FRESCA antes de decidir (ARP + DNS + ping). El
                # ARP crudo no sirve: el kernel conserva entradas STALE de
                # equipos que ya se fueron, y eso bloquearia justo lo que se
                # quiere liberar. Un lease tampoco prueba presencia.
                DevicePresenceService().reconcile(db)

                for device in db.query(NetworkDevice).all():

                    mac = (device.mac_address or "").lower()

                    meta[mac] = {
                        "last_seen": device.last_seen,
                        "permanent": device.permanent_ip or "",
                        "presence": device.presence_status,
                        "protected": bool(
                            device.is_permanent
                            or DeviceClassifier.is_infrastructure(
                                device.device_type
                            )
                        ),
                    }

                    if (
                        device.presence_status in ("ONLINE", "PROBABLE")
                        and device.current_ip
                    ):

                        live_ips.add(device.current_ip)

            finally:

                db.close()

        except Exception as error:

            # Sin presencia confiable no se puede demostrar que una IP
            # esta sin uso: no se libera nada.
            logger.warning(
                "DhcpReconciler: sin presencia confiable, no se libera: %s",
                error,
            )

            return 0

        try:

            text = self._leases_path.read_text(encoding="utf-8", errors="replace")

        except OSError:

            return 0

        candidates = select_reclaimable(
            parse_leases(text),
            live_ips,
            meta,
            cutoff,
            # Margen para descartar por ping sin quedarse sin candidatos.
            limit=max(needed + 10, needed * 3),
        )

        if not candidates:

            return 0

        # La confirmación activa (ping/ARP) vive en DevicePresenceService,
        # fuera del lock de dnsmasq. Aquí usamos ARP/observaciones y no
        # mantenemos el servicio bloqueado mientras se sondean equipos.
        reclaimable = set(candidates[:needed])

        if not reclaimable:

            return 0

        keep = [
            line
            for line in text.splitlines()
            if not (len(line.split()) >= 3 and line.split()[2] in reclaimable)
        ]

        # dnsmasq mantiene los leases en memoria; editar el archivo con el
        # proceso vivo permite que los reescriba y se pierda la reclamación.
        was_running = bool(self._process.status().get("running"))

        if was_running:

            stopper = getattr(self._process, "stop", None)

            if stopper is not None:

                stopped = stopper()

                if not stopped.get("success", True):

                    logger.warning(
                        "DHCP: no se pudo detener dnsmasq para reclamar leases: %s",
                        stopped,
                    )

                    return 0

        self._write_atomic(self._leases_path, "\n".join(keep) + "\n")

        if was_running:

            started = self._process.start()

            if not started.get("success"):

                logger.error(
                    "DHCP: dnsmasq no arrancó después de reclamar leases: %s",
                    started,
                )

        self._no_address_until = float("-inf")

        self._state["reclaimed_last"] = len(reclaimable)

        self._state["reclaimed_total"] += len(reclaimable)

        logger.warning(
            "DHCP: %s, liberadas %d IPs de equipos sin señal reciente",
            "pool agotado" if exhausted else "pool bajo",
            len(reclaimable),
        )

        self._alert_notifier(
            "DHCP_POOL_RECLAIMED",
            "info",
            "DHCP: IPs liberadas por falta de espacio",
            (
                f"Se liberaron {len(reclaimable)} direcciones de equipos "
                "ausentes (sin ARP, DNS ni respuesta a ping). Se conservan "
                "las reservas y todo equipo presente en la red."
            ),
        )

        return len(reclaimable)
