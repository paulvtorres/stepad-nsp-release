import DhcpStatusPanel from "./DhcpStatusPanel";
import DhcpPoolStatsPanel from "./DhcpPoolStatsPanel";
import LanSegmentPanel from "./LanSegmentPanel";
import DhcpAlertPanel from "./DhcpAlertPanel";
import DhcpCleanupPanel from "./DhcpCleanupPanel";
import DhcpLogPanel from "./DhcpLogPanel";

import "../Interfaces/interfaces.css";
import "./dhcp.css";


function Dhcp() {

    return (

        <div className="interfaces-page dhcp-page">

            <header className="interfaces-header">
                <h2>DHCP</h2>
                <p>
                    Estado del servicio, uso de IPs, segmento, alertas por
                    correo, limpieza de reservas y registro de actividad.
                </p>
            </header>

            <DhcpStatusPanel />

            <DhcpPoolStatsPanel />

            <LanSegmentPanel />

            <DhcpAlertPanel />

            <DhcpCleanupPanel />

            <DhcpLogPanel />

        </div>

    );

}


export default Dhcp;
