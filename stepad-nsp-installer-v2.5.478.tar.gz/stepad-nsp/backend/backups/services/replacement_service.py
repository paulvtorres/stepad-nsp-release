"""Create a guided replacement bundle for moving the NSP to new hardware.

Contains the database dump, /etc/stepad secrets and config, encrypted with
a user passphrase (OpenSSL AES-256 + PBKDF2). The import side is a CLI
script (scripts/import-replacement.sh): restoring the DB from the API would
kill the API mid-operation.
"""

import gzip
import os
import shutil
import socket
import subprocess
import tempfile

from pathlib import Path

from backend.backups.services import replacement_bundle
from backend.shared.logging.logger import logger


class ReplacementService:

    def create_bundle(self, passphrase: str) -> tuple[Path, str]:
        if not passphrase or len(passphrase) < 12:
            raise ValueError(
                "La frase de seguridad debe tener al menos 12 caracteres."
            )

        version = ""
        try:
            version = Path("/etc/stepad/version").read_text("utf-8").strip()
        except OSError:
            pass

        work = Path(tempfile.mkdtemp(prefix="stepad-replacement-"))
        os.chmod(work, 0o700)
        try:
            db_name = os.environ.get("DB_NAME", "stepad_nsp")
            dump = work / "database.sql"
            env = {
                **os.environ,
                "PGPASSWORD": os.environ.get("DB_PASSWORD", ""),
                "LC_ALL": "C",
            }
            result = subprocess.run(
                [
                    "pg_dump",
                    "-h", os.environ.get("DB_HOST", "127.0.0.1"),
                    "-p", os.environ.get("DB_PORT", "5432"),
                    "-U", os.environ.get("DB_USER", "stepad_app"),
                    "--no-owner",
                    "--no-privileges",
                    "-f", str(dump),
                    db_name,
                ],
                env=env,
                capture_output=True,
                text=True,
                timeout=3600,
            )
            if result.returncode != 0:
                raise RuntimeError(
                    "No se pudo volcar la base de datos: "
                    + ((result.stderr or result.stdout or "").strip()[:300])
                )
            with open(dump, "rb") as source, gzip.open(
                work / "database.sql.gz", "wb"
            ) as target:
                shutil.copyfileobj(source, target, length=1024 * 1024)
            dump.unlink()

            etc = work / "etc"
            etc.mkdir()
            for source, name in (
                (Path("/etc/stepad/stepad.env"), "stepad.env"),
                (Path("/etc/stepad/config.yaml"), "config.yaml"),
            ):
                if source.is_file():
                    shutil.copy2(source, etc / name)
                    os.chmod(etc / name, 0o600)

            files = {}
            for path in sorted(work.rglob("*")):
                if path.is_file() and path.name != "manifest.json":
                    files[str(path.relative_to(work))] = path.stat().st_size
            manifest = replacement_bundle.build_manifest(
                version, socket.gethostname(), db_name, files
            )
            import json

            (work / "manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            os.chmod(work / "manifest.json", 0o600)

            # The archive MUST live outside `work`: inside it, tar would
            # try to include (and read) the file it is writing to.
            handle, tar_name = tempfile.mkstemp(
                prefix="stepad-replacement-", suffix=".tar.gz"
            )
            os.close(handle)
            tar_path = Path(tar_name)
            subprocess.run(
                ["tar", "czf", str(tar_path), "-C", str(work), "."],
                check=True,
                timeout=3600,
            )
            name = replacement_bundle.bundle_filename(version)
            # Unique temp path per export: two bundles in the same minute
            # must not share (and delete) each other's file.
            handle, temp_name = tempfile.mkstemp(
                prefix="stepad-replacement-", suffix=".enc"
            )
            os.close(handle)
            final = Path(temp_name)
            subprocess.run(
                [
                    "openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-salt",
                    "-in", str(tar_path),
                    "-out", str(final),
                    "-pass", "stdin",
                ],
                input=passphrase + "\n",
                text=True,
                check=True,
                timeout=3600,
            )
            os.chmod(final, 0o600)
            logger.info("Paquete de reemplazo creado: %s", name)
            return final, name
        finally:
            shutil.rmtree(work, ignore_errors=True)
            try:
                tar_path.unlink(missing_ok=True)
            except (OSError, UnboundLocalError):
                pass
