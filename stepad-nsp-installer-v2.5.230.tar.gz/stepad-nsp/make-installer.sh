#!/usr/bin/env bash
#
# Crea el paquete instalador de STEPAD NSP (para llevar en USB o
# subir a una nube compartida).
#
# Uso (en la máquina de desarrollo, dentro del repo):
#   bash make-installer.sh
#
# Genera: stepad-nsp-installer-<versión>.tar.gz
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

VERSION="$(git describe --tags --always 2>/dev/null || echo 1.0.0)"
NAME="stepad-nsp-installer-${VERSION}.tar.gz"

# Escribir la versión dentro del paquete para que la instalación la
# guarde en /etc/stepad/version (usada por el check de actualizaciones).
VERSION_DIR="$(mktemp -d)"
echo "${VERSION}" > "${VERSION_DIR}/VERSION"

echo "==> Compilando frontend para incluirlo en el instalador..."
(
    cd "${SCRIPT_DIR}/frontend"
    if [ ! -d node_modules ]; then
        npm install
    fi
    npm run build
)
if [ ! -f "${SCRIPT_DIR}/frontend/dist/index.html" ]; then
    echo "ERROR: frontend/dist/index.html no existe tras npm run build."
    exit 1
fi

STAGE="$(mktemp -d)"
trap 'rm -rf "${STAGE}"' EXIT

cp -a "${SCRIPT_DIR}" "${STAGE}/stepad-nsp"
cp "${VERSION_DIR}/VERSION" "${STAGE}/stepad-nsp/VERSION"

# Limpieza: sin git, venv, node_modules/__pycache__, logs,
# archivos macOS (._*) ni paquetes anteriores. Se conserva frontend/dist
# (compilado arriba) para que la UI funcione aunque npm falle en destino.
rm -rf \
    "${STAGE}/stepad-nsp/.git" \
    "${STAGE}/stepad-nsp/.venv" \
    "${STAGE}/stepad-nsp/frontend/node_modules" \
    "${STAGE}/stepad-nsp/backend/.pytest_cache" \
    "${STAGE}/stepad-nsp/logs" \
    "${STAGE}/stepad-nsp/stepad-nsp-installer-"*.tar.gz

find "${STAGE}/stepad-nsp" -name "__pycache__" -type d -prune -exec rm -rf {} +
find "${STAGE}/stepad-nsp" -name "._*" -delete

if [ ! -f "${STAGE}/stepad-nsp/frontend/dist/index.html" ]; then
    echo "ERROR: el paquete no incluye frontend/dist/index.html."
    exit 1
fi

# ------------------------------------------------------------------
# Validacion PREVIA (que el instalador no salga roto a produccion):
#  - sintaxis de los scripts de shell
#  - sintaxis de los scripts python del repo (incluido configure_suricata)
#  - sintaxis de CUALQUIER heredoc python dentro de los .sh de instalacion
#    (asi un error como el de suricata se detecta aqui, no en el cliente)
# ------------------------------------------------------------------
echo "==> Validando instalador..."

bash -n "${STAGE}/stepad-nsp/install.sh"
bash -n "${STAGE}/stepad-nsp/make-installer.sh"
if [ -f "${STAGE}/stepad-nsp/update.sh" ]; then bash -n "${STAGE}/stepad-nsp/update.sh"; fi

python3 - <<'VALEOF'
import pathlib, re, subprocess, sys

errors = 0
root = pathlib.Path("${STAGE}/stepad-nsp")

for py in root.rglob("*.py"):
    r = subprocess.run(
        [sys.executable, "-m", "py_compile", str(py)],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        errors += 1
        print("PY ERROR:", py)
        print(r.stderr)

for sh in ["install.sh", "update.sh", "uninstall.sh"]:
    path = root / sh
    if not path.exists():
        continue
    src = path.read_text()
    blocks = re.findall(r"python3 - <<'(\w+)'\n(.*?)\n\1", src, re.S)
    for name, code in blocks:
        r = subprocess.run(
            [sys.executable, "-c", "compile(__import__('sys').stdin.read(), '<install-sh>', 'exec')"],
            input=code, capture_output=True, text=True,
        )
        if r.returncode != 0:
            errors += 1
            print(f"HEREDOC PY ERROR en {sh} (<<'{name}'):")
            print(r.stderr)

if errors:
    print(f"FALLO LA VALIDACION: {errors} error(es). NO se arma el instalador.")
    sys.exit(1)

print("Validacion OK (shell + python + heredocs).")
VALEOF

tar czf "${NAME}" -C "${STAGE}" stepad-nsp

echo "Instalador creado: ${NAME}"
echo "Llévalo a la VM en una USB o nube compartida y ejecuta:"
echo "  tar xzf ${NAME} && cd stepad-nsp && sudo bash install.sh"
