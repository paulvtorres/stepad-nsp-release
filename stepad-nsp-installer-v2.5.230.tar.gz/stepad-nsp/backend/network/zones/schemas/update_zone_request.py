from pydantic import BaseModel


class UpdateZoneRequest(BaseModel):

    name: str | None = None

    description: str | None = None

    is_default: bool | None = None

    enforce_time_cutoff: bool | None = None

    time_cutoff_schedule_id: int | None = None

    interface_mac: str | None = None

    physical_interface: str | None = None
