import ipaddress

from backend.infrastructure.network.adapters.linux.linux_interface_provider import (
    LinuxInterfaceProvider
)


class ZoneInterfaceResolver:

    def __init__(self):

        self.provider = LinuxInterfaceProvider()

    def _resolve_by_mac(self, mac: str) -> str | None:
        mac = (mac or "").strip().lower()
        if not mac:
            return None
        for interface in self.provider.list_interfaces():
            if str(getattr(interface, "mac_address", "") or "").lower() == mac:
                return interface.name
        return None

    def _resolve_by_name(self, name: str) -> str | None:
        name = (name or "").strip()
        if not name:
            return None
        for interface in self.provider.list_interfaces():
            if interface.name == name:
                return interface.name
        return None

    def _resolve_by_network(self, zone) -> str | None:
        """
        Fallback dinámico por red: si el NIC fue cambiado o renombrado
        (el nombre y la MAC guardados ya no existen), encontrar la
        interfaz cuya IP viva cae dentro del CIDR de la zona o que
        tiene la gateway de la zona. Así, al cambiar la tarjeta de red,
        el DHCP se re-enlaza a la interfaz correcta en el próximo
        arranque sin editar nada a mano.
        """
        network = getattr(zone, "network_cidr", None)
        gateway = getattr(zone, "gateway_ip", None)

        wanted = None
        if network:
            try:
                wanted = ipaddress.ip_network(str(network), strict=False)
            except ValueError:
                wanted = None

        gateway = (gateway or "").strip()

        for interface in self.provider.list_interfaces():
            ip = str(getattr(interface, "ipv4_address", "") or "").strip()
            if not ip:
                continue
            try:
                current = ipaddress.ip_address(ip)
            except ValueError:
                continue
            if gateway and ip == gateway:
                return interface.name
            if wanted and current in wanted:
                return interface.name

        return None

    def resolve(
        self,
        zone
    ) -> str:
        """
        Returns the current Linux interface name a zone should bind
        to. Resolution is dynamic, in this order:

        1. interface_mac, if set: the card is looked up by MAC so
           swapping/re-plugging the NIC keeps working.
        2. physical_interface, if that interface name still exists.
        3. network fallback: the live interface whose IPv4 belongs to
           the zone's network_cidr (or equals its gateway_ip). This
           keeps DHCP bound to a changed NIC automatically.
        """

        by_mac = self._resolve_by_mac(
            getattr(zone, "interface_mac", None)
        )
        if by_mac:
            return by_mac

        stored = getattr(zone, "physical_interface", None)
        by_name = self._resolve_by_name(stored)
        if by_name:
            return by_name

        by_network = self._resolve_by_network(zone)
        if by_network:
            return by_network

        # Nada match: devolver lo guardado tal cual (lo captura el log
        # de dnsmasq y sigue siendo el valor más cercano al deseado).
        return stored