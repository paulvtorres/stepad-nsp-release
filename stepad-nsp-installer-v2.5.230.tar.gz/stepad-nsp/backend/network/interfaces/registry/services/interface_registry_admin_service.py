import re
import subprocess

from sqlalchemy.orm import Session

from backend.network.interfaces.registry.repositories.managed_interface_repository import (
    ManagedInterfaceRepository
)

from backend.network.interfaces.registry.services.interface_registry_service import (
    InterfaceRegistryService
)

from backend.infrastructure.network.adapters.linux.linux_interface_provider import (
    LinuxInterfaceProvider
)

from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc

from backend.nat.services.nat_service import NatService


class InterfaceRegistryAdminService:
    """
    The web-facing half of the interface registry: list what's
    known (merged with live link/IP status for display), and let the
    admin assign a role to a newly detected card, reassign one, or
    remove a stale entry for hardware that's gone for good. Every
    action here is something the user does from the UI -- there is
    no other way to change a role, by design (see the child-safety-
    adjacent reasoning that applies just as much to network config:
    an unattended automatic role change is exactly the kind of thing
    that could silently misconfigure someone's network).
    """

    def __init__(self):

        self.repository = ManagedInterfaceRepository()

        self.registry_service = InterfaceRegistryService()

        self.provider = LinuxInterfaceProvider()


    def list_interfaces(
        self,
        db: Session,
        deep: bool = False
    ):

        live_by_mac = {
            interface.mac_address.lower(): interface
            for interface in self.provider.list_interfaces(deep=deep)
            if interface.mac_address
        }

        entries = self.repository.find_all(db)

        suggestions = self._compute_suggested_replacements(entries)

        results = []

        for entry in entries:

            live = live_by_mac.get(entry.mac_address)

            results.append({
                "id": entry.id,
                "mac_address": entry.mac_address,
                "display_name": entry.display_name,
                "role": entry.role,
                "priority": entry.priority,
                "status": entry.status,
                "last_seen_name": entry.last_seen_name,
                "last_seen_at": to_iso_utc(entry.last_seen_at),
                "current_name": live.name if live else None,
                "link_detected": live.link_detected if live else False,
                "ip_address": live.ipv4_address if live else None,
                "is_live": live is not None,
                "suggested_replacement": suggestions.get(entry.id)
            })

        return results


    def _compute_suggested_replacements(
        self,
        entries
    ):
        """
        Surfaces a one-click "did you replace this card?" suggestion
        -- NEVER applied automatically, only ever shown for the admin
        to confirm from the web UI (see the class docstring for why).

        Deliberately conservative: only fires when the match is
        unambiguous -- exactly one card went missing and exactly one
        new, unassigned card showed up. Anything less clear-cut (a
        full machine swap with several cards changing at once, for
        instance) has no reliable way to know which new card should
        take which old role, so it's left as-is: every new card shows
        up as "pending_assignment" and the admin assigns each by hand,
        same as today.
        """

        missing = [entry for entry in entries if entry.status == "missing"]

        pending = [entry for entry in entries if entry.status == "pending_assignment"]

        if len(missing) != 1 or len(pending) != 1:

            return {}

        missing_entry = missing[0]

        pending_entry = pending[0]

        return {

            pending_entry.id: {

                "suggested_role": missing_entry.role,

                "suggested_display_name": missing_entry.display_name,

                "replaces_mac": missing_entry.mac_address,

                "replaces_last_seen_name": missing_entry.last_seen_name

            }

        }


    def assign(
        self,
        db: Session,
        interface_id: int,
        role: str,
        display_name: str | None = None,
        priority: int | None = None,
        replaces_mac: str | None = None
    ):

        if role not in ("WAN", "LAN"):

            return {"success": False, "message": "role must be WAN or LAN"}

        entry = self.repository.find_by_id(db, interface_id)

        if not entry:

            return {"success": False, "message": "Interface not found"}

        # Proteccion: una conexion que llega a internet no puede ser LAN.
        if role == "LAN":

            check = self.test_connectivity(db, interface_id)

            if check.get("has_internet"):

                return {
                    "success": False,
                    "message": (
                        "Esta conexión tiene acceso a internet — no puede "
                        "asignarse como LAN. Si es un proveedor WAN, "
                        "asígnala como WAN."
                    )
                }

        entry.role = role

        entry.status = "assigned"

        if display_name is not None:

            entry.display_name = display_name

        if priority is not None:

            entry.priority = priority

        self.repository.update(db, entry)

        logger.info(
            f"Interface {entry.mac_address} assigned role {role} "
            f"(priority {entry.priority}) via web UI."
        )

        zone_setup = None

        if role == "LAN":

            live_name = entry.last_seen_name

            for interface in self.provider.list_interfaces():

                if (
                    interface.mac_address
                    and interface.mac_address.lower() == entry.mac_address.lower()
                ):

                    live_name = interface.name

                    break

            try:

                from backend.network.zones.services.network_zone_service import (
                    NetworkZoneService
                )

                zone_setup = NetworkZoneService().ensure_zone_for_lan(
                    db,
                    mac_address=entry.mac_address,
                    interface_name=live_name or entry.last_seen_name or "",
                    replaces_mac=replaces_mac,
                )

            except Exception as error:

                logger.exception(
                    f"Auto zone setup after LAN assign failed: {error}"
                )

                zone_setup = {
                    "created": False,
                    "needs_zone_setup": True,
                    "interface_mac": entry.mac_address,
                    "physical_interface": live_name,
                    "message": (
                        "No se pudo crear la zona automáticamente. "
                        "Créala en Zonas eligiendo esta tarjeta."
                    ),
                }

        try:

            self.registry_service.reconcile()

            # Asignar el rol no ocurre en cada arranque: re-aplicar
            # NAT/forwarding/masquerade ahora (si el rol es WAN) para
            # que la LAN tenga salida a internet de inmediato.
            NatService().enable_default_nat()

            from backend.firewall.dns_security.services.encrypted_dns_service import (
                EncryptedDnsService
            )

            EncryptedDnsService().reapply_on_boot()

        except Exception as error:

            # The role assignment is already committed; reconciliation
            # (LAN IP / DHCP / DNS) is best-effort and must not turn a
            # successful role change into a 500 (which left the web UI
            # showing the old state until a page reload).
            logger.exception(
                f"Reconcile after LAN/WAN assignment failed: {error}"
            )

        result = {"success": True, "id": entry.id, "role": entry.role}

        if zone_setup is not None:

            result["zone_setup"] = zone_setup

        return result


    def unassign(
        self,
        db: Session,
        interface_id: int
    ):

        entry = self.repository.find_by_id(db, interface_id)

        if not entry:

            return {"success": False, "message": "Interface not found"}

        entry.role = None

        entry.status = "pending_assignment"

        self.repository.update(db, entry)

        logger.info(
            f"Interface {entry.mac_address} unassigned via web UI."
        )

        try:

            self.registry_service.reconcile()

            NatService().enable_default_nat()

        except Exception as error:

            logger.exception(
                f"Reconcile after unassignment failed: {error}"
            )

        return {"success": True}


    def compare_wan(self) -> list[dict]:

        """Responde a "cual proveedor es mejor": mide latencia y perdida
        a internet por cada tarjeta con enlace y ordena de mejor a peor
        (internet OK primero, luego menor latencia)."""

        results = []

        for interface in self.provider.list_interfaces():

            if not interface.link_detected:

                continue

            latency, loss = self._ping_metrics(interface.name)

            results.append({
                "name": interface.name,
                "mac_address": interface.mac_address,
                "has_internet": latency is not None,
                "latency_ms": latency,
                "packet_loss": loss,
            })

        results.sort(
            key=lambda r: (
                not r["has_internet"],
                r["latency_ms"] if r["latency_ms"] is not None else 9999,
                r["packet_loss"],
            )
        )

        return results


    def _ping_metrics(
        self,
        interface_name: str,
        target: str = "1.1.1.1"
    ):

        result = subprocess.run(
            [
                "ping", "-I", interface_name,
                "-c", "3", "-W", "2", target
            ],
            capture_output=True,
            text=True,
        )

        out = result.stdout

        loss = 100.0

        m = re.search(r"(\d+(?:\.\d+)?)% packet loss", out)

        if m:

            loss = float(m.group(1))

        latency = None

        m = re.search(
            r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)/",
            out,
        )

        if m:

            latency = float(m.group(1))

        if result.returncode != 0:

            latency = None

        return latency, loss


    def test_connectivity(

        self,
        db: Session,
        interface_id: int
    ):
        """
        Answers "does THIS specific card reach the internet right
        now?" -- the actual signal an admin needs to tell WAN from
        LAN before assigning either, since "has a cable plugged in"
        (link_detected) doesn't distinguish them: both cards can be
        plugged into something. This pings out through the live
        interface currently matching this entry's MAC, bypassing
        routing entirely, so it works even before any role is
        assigned.
        """

        entry = self.repository.find_by_id(db, interface_id)

        if not entry:

            return {"success": False, "message": "Interface not found"}

        live_by_mac = {
            interface.mac_address.lower(): interface
            for interface in self.provider.list_interfaces()
            if interface.mac_address
        }

        live = live_by_mac.get(entry.mac_address)

        if not live:

            return {
                "success": False,
                "has_internet": False,
                "message": "Esta tarjeta no está conectada ahora mismo."
            }

        result = subprocess.run(
            [
                "ping",
                "-I", live.name,
                "-c", "1",
                "-W", "2",
                "1.1.1.1"
            ],
            capture_output=True,
            text=True
        )

        has_internet = result.returncode == 0

        return {

            "success": True,

            "has_internet": has_internet,

            "message": (
                "Esta tarjeta SÍ llega a internet -- probablemente es tu WAN."
                if has_internet else
                "Esta tarjeta no tiene salida a internet ahora mismo -- "
                "probablemente es tu LAN, o el cable no está en el módem/router."
            )

        }


    def delete(
        self,
        db: Session,
        interface_id: int
    ):

        entry = self.repository.find_by_id(db, interface_id)

        if not entry:

            return {"success": False, "message": "Interface not found"}

        self.repository.delete(db, entry)

        logger.info(
            f"Interface registry entry {entry.mac_address} removed "
            f"via web UI."
        )

        return {"success": True}
