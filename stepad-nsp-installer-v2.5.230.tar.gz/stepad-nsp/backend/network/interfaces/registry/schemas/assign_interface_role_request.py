from pydantic import BaseModel


class AssignInterfaceRoleRequest(BaseModel):

    role: str

    display_name: str | None = None

    priority: int | None = None

    replaces_mac: str | None = None
