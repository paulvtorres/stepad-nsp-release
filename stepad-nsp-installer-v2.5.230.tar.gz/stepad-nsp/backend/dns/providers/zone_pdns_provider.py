import subprocess
import socket
import time

import psutil

from backend.core.config.paths import ZONES_DIR
from backend.network.zones.models.network_zone import NetworkZone
from backend.shared.logging.logger import logger
from backend.shared.process.subprocess_log import open_rotated_log


PDNS_RECURSOR_BIN = "/usr/sbin/pdns_recursor"

REC_CONTROL_BIN = "/usr/bin/rec_control"

RPZ_TTL_SECONDS = 300

START_CHECK_DELAY_SECONDS = 0.5

SOCKET_WAIT_TIMEOUT_SECONDS = 20

SOCKET_WAIT_POLL_SECONDS = 0.5

ZONE_PDNS_LOG_MAX_BYTES = 5 * 1024 * 1024

ZONE_PDNS_LOG_BACKUP_COUNT = 3


class ZonePdnsProvider:

    def __init__(
        self,
        zone: NetworkZone
    ):

        self.zone = zone

        self.zone_dir = ZONES_DIR / str(zone.id)

        self.rpz_zone_file = self.zone_dir / "blocked_domains.rpz"

        self.lua_config_file = self.zone_dir / "rpz.lua"

        self.recursor_yml = self.zone_dir / "recursor.yml"

        self.pid_file = self.zone_dir / "pdns.pid"

        self.log_file = self.zone_dir / "pdns.log"

        self.zone_name = f"stepad-zone-{zone.id}"

        self._log_handle = None

    def bootstrap(self):

        self.zone_dir.mkdir(parents=True, exist_ok=True)

        lua_content = (
            f'rpzFile("{self.rpz_zone_file}", '
            f'{{defpol=Policy.NXDOMAIN, policyName="{self.zone_name}"}})\n'
        )

        self.lua_config_file.write_text(lua_content)

        if not self.rpz_zone_file.exists():

            self.generate_domains_config([])

        prefix_length = self.zone.network_cidr.split("/")[-1]

        network = self.zone.network_cidr

        recursor_yml_content = (
            "dnssec:\n"
            "  validation: 'validate'\n\n"
            "logging:\n"
            "  loglevel: 4\n"
            "  quiet: false\n"
            "  protobuf_servers:\n"
            "    - servers:\n"
            "        - '127.0.0.1:4242'\n\n"
            "incoming:\n"
            "  listen:\n"
            f"    - {self.zone.gateway_ip}\n"
            "  allow_from:\n"
            "    - 127.0.0.1\n"
            f"    - {network}\n\n"
            "recursor:\n"
            f"  socket_dir: '{self.zone_dir}'\n\n"
            # El lua (rpz.lua) se pasa por --lua-config-file en start():
            # en el YAML, `recursor.lua_config_file` es incompatible con
            # PowerDNS 5.2 y hace que el proceso no cree su socket de
            # control (dejaba el NSP colgado, web caída).
        )

        self.recursor_yml.write_text(recursor_yml_content)


    def generate_domains_config(
        self,
        domains: list[str]
    ):

        self.rpz_zone_file.parent.mkdir(parents=True, exist_ok=True)

        serial = int(time.time())

        lines = [
            "$TTL " + str(RPZ_TTL_SECONDS),
            f"@ SOA localhost. root.localhost. ({serial} 3600 600 604800 {RPZ_TTL_SECONDS})",
            "  NS localhost.",
            ""
        ]

        for domain in sorted(set(
            domain.strip().lower()
            for domain in domains
            if domain and domain.strip()
        )):

            lines.append(f"{domain}. CNAME .")
            lines.append(f"*.{domain}. CNAME .")

        self.rpz_zone_file.write_text("\n".join(lines) + "\n")


    def _gateway_served(self):

        # Prueba si alguien ya esta escuchando DNS en el gateway de la
        # zona (tcp:53 y udp:53). Si el bind falla con Address already
        # in use, ya hay un recursor atendiendo esa IP (tipicamente el
        # del sistema) y la zona no debe duplicarlo ni bloquearse.
        for socktype in (socket.SOCK_STREAM, socket.SOCK_DGRAM):
            try:
                probe = socket.socket(
                    socket.AF_INET, socktype
                )
                try:
                    probe.bind((self.zone.gateway_ip, 53))
                except OSError:
                    return True
                finally:
                    probe.close()
            except Exception:
                continue

        return False


    def _find_pid(self):

        if self.pid_file.exists():

            try:

                pid = int(self.pid_file.read_text().strip())

                if psutil.pid_exists(pid):

                    return pid

            except ValueError:

                pass

        for process in psutil.process_iter(["pid", "name", "cmdline"]):

            if process.info["name"] != "pdns_recursor":
                continue

            cmdline = " ".join(process.info.get("cmdline") or [])

            if str(self.zone_dir) in cmdline:

                return process.info["pid"]

        return None

    def _close_log(self) -> None:

        if self._log_handle is None:

            return

        try:

            self._log_handle.close()

        except Exception:

            pass

        finally:

            self._log_handle = None

    def start(self):

        if self._find_pid():

            return {"success": True, "message": "Zone resolver already running"}

        # Regenerar SIEMPRE la config del recursor (recursor.yml). Asi una
        # version nueva corrige/actualiza el YAML aunque el archivo ya
        # exista en el equipo (evita quedar colgado con un recursor.yml
        # viejo que tienen campo invalido y no arranca).
        try:
            self.bootstrap()
        except Exception as exc:
            logger.error("Zone %s bootstrap falló: %s", self.zone.id, exc)

        self._close_log()

        self._log_handle = open_rotated_log(
            self.log_file,
            ZONE_PDNS_LOG_MAX_BYTES,
            ZONE_PDNS_LOG_BACKUP_COUNT,
        )

        process = subprocess.Popen(
            [
                PDNS_RECURSOR_BIN,
                "--daemon=no",
                "--write-pid=no",
                f"--config-dir={self.zone_dir}",
                f"--socket-dir={self.zone_dir}",
                f"--lua-config-file={self.lua_config_file}",
            ],
            stdout=self._log_handle,
            stderr=subprocess.STDOUT,
        )

        time.sleep(START_CHECK_DELAY_SECONDS)

        if process.poll() is not None:

            self._close_log()

            tail = ""

            try:

                if self.log_file.exists():

                    tail = self.log_file.read_text(encoding="utf-8")[-500:]

            except Exception:

                pass

            logger.error(
                "Zone %s resolver failed to start: %s",
                self.zone.id,
                tail.strip(),
            )

            return {
                "success": False,
                "error": tail.strip() or "pdns_recursor failed to start",
            }

        self.pid_file.write_text(str(process.pid))

        return {"success": True, "pid": process.pid}


    def stop(self):

        pid = self._find_pid()

        if not pid:

            self._close_log()

            return {"success": True, "message": "Not running"}

        try:

            psutil.Process(pid).terminate()

        except psutil.NoSuchProcess:

            pass

        if self.pid_file.exists():

            self.pid_file.unlink()

        self._close_log()

        return {"success": True}


    def reload(self):

        socket_path = self.zone_dir / "pdns_recursor.controlsocket"

        # Si el gateway de la zona ya esta respondiendo DNS (otro
        # recursor -- normalmente el del sistema, PowerDnsRpzProvider --
        # ya bindea gateway:53), la zona esta cubierta y NO debe
        # lanzarse un recursor duplicado ni bloquear el arranque: sin
        # este chequeo, el pdns por zona chocaba con el del sistema
        # (Address already in use) y el boot quedaba colgado esperando
        # un socket que nunca aparecia (web caida).
        if self._gateway_served():
            logger.info(
                "Zone %s: subred %s ya servida por el recursor del sistema;"
                " se saltea el recursor de zona (sin bloqueo).",
                self.zone.id,
                self.zone.network_cidr,
            )
            return {"success": True, "skipped": True}

        # Auto-recuperacion: si el recursor de la zona no esta corriendo
        # (p. ej. config recursor.yml vieja/invalida que impidio arrancar),
        # se regenera la config y se inicia antes de intentar recargar.
        try:
            self.bootstrap()
        except Exception as exc:
            logger.error("Zone %s bootstrap falló: %s", self.zone.id, exc)

        if not socket_path.exists():
            try:
                self.start()
            except Exception as exc:
                logger.error("Zone %s start (auto) falló: %s", self.zone.id, exc)

        waited = 0.0

        while not socket_path.exists() and waited < SOCKET_WAIT_TIMEOUT_SECONDS:

            time.sleep(SOCKET_WAIT_POLL_SECONDS)

            waited += SOCKET_WAIT_POLL_SECONDS

        if not socket_path.exists():

            message = (
                f"Zone {self.zone.id}: control socket never appeared "
                f"({socket_path}) -- its pdns_recursor process is "
                "likely not running (see start())."
            )

            logger.error(message)

            return {"success": False, "error": message}

        result = subprocess.run(
            [
                REC_CONTROL_BIN,
                f"--socket-dir={self.zone_dir}",
                "reload-lua-config"
            ],
            capture_output=True,
            text=True,
            timeout=15
        )

        if result.returncode == 0:

            return {"success": True, "message": f"Zone {self.zone.id} RPZ reloaded"}

        logger.error(
            f"Zone {self.zone.id} reload-lua-config failed: {result.stderr.strip()}"
        )

        return {"success": False, "error": result.stderr.strip()}


    def get_status(self):

        pid = self._find_pid()

        return {"running": pid is not None, "pid": pid}
