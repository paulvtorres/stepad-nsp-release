from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.backups.services.backup_service import BackupService
from backend.backups.services.cloud_storage_service import CloudStorageService
from backend.backups.services.system_backup_service import (
    system_backup_service
)

from backend.shared.logging.logger import logger


class BackupComponent(BaseComponent):

    name = "backups"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.service = BackupService()

    def start(self):

        logger.info("BackupComponent started.")

        self.service.start_scheduler()

        CloudStorageService().start_scheduler()

        # Respaldo automático de la configuración del NSP (config + postgres)
        # programado según system-backup-config.json (por defecto 03:00).
        try:
            system_backup_service.start_scheduler()
        except Exception as error:
            logger.warning(
                "No se pudo iniciar el scheduler de respaldo del sistema: %s",
                error,
            )

    def stop(self):

        logger.info("BackupComponent stopped.")

        try:
            system_backup_service.stop_scheduler()
        except Exception:
            pass