from sqlalchemy import String, Boolean, DateTime, Integer, Float, Index
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class WanMonitorSettings(Base):

    __tablename__ = "wan_monitor_settings"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    interval_seconds: Mapped[int] = mapped_column(
        Integer,
        default=60
    )


    # comma-separated targets probed with ping.
    ping_targets: Mapped[str] = mapped_column(
        String(255),
        default="8.8.8.8,1.1.1.1"
    )


    http_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    http_url: Mapped[str] = mapped_column(
        String(255),
        default="https://www.google.com"
    )


    # consecutive failed samples before an alert is fired.
    alert_threshold: Mapped[int] = mapped_column(
        Integer,
        default=3
    )


    retention_days: Mapped[int] = mapped_column(
        Integer,
        default=30
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


class WanMonitorSample(Base):

    __tablename__ = "wan_monitor_samples"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    interface: Mapped[str] = mapped_column(
        String(50),
        index=True
    )


    timestamp: Mapped[datetime] = mapped_column(
        DateTime,
        index=True
    )


    link_up: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    link_speed_mbps: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )


    ping_ok: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    latency_ms: Mapped[float | None] = mapped_column(
        Float,
        nullable=True
    )


    packet_loss: Mapped[float] = mapped_column(
        Float,
        default=0.0
    )


    http_ok: Mapped[bool | None] = mapped_column(
        Boolean,
        nullable=True
    )


    rx_bps: Mapped[int] = mapped_column(
        Integer,
        default=0
    )


    tx_bps: Mapped[int] = mapped_column(
        Integer,
        default=0
    )


Index(
    "ix_wan_sample_iface_time",
    WanMonitorSample.interface,
    WanMonitorSample.timestamp
)


class WanMonitorOutage(Base):
    """Incidente de falta de internet consolidado por período.

    Se registra un corte (started_at = inicio de la caída) cuando el
    monitor confirma la falla, y se cierra al volver la señal
    (ended_at + duración). Así el NSP lleva un reporte continuo del
    tiempo SIN internet por interfaz, consultable para justificar
    caídas del proveedor ante los usuarios.
    """

    __tablename__ = "wan_monitor_outages"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    interface: Mapped[str] = mapped_column(
        String(50),
        index=True
    )

    started_at: Mapped[datetime] = mapped_column(
        DateTime,
        index=True
    )

    # "started_at" exacto es el primer fallo; ended_at solo se llena
    # cuando la señal vuelve (None = corte aún activo).
    ended_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )

    duration_seconds: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )

    acknowledge: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False
    )
