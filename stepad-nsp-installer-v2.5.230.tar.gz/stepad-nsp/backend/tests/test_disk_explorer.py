"""Pruebas del explorador de discos: confinamiento de rutas y operaciones."""

import asyncio
import io
import os

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

import pytest
from fastapi import HTTPException, UploadFile

from backend.storage.services import fs_ops
from backend.storage.services.disk_service import DiskService


@pytest.fixture()
def svc(tmp_path, monkeypatch):
    root = tmp_path / "disk"
    root.mkdir()
    (root / "docs").mkdir()
    (root / "docs" / "a.txt").write_text("hola")
    (root / "docs" / "sub").mkdir()
    (root / "b.bin").write_bytes(b"x" * 2048)
    (tmp_path / "outside").mkdir()
    (tmp_path / "outside" / "secret.txt").write_text("secreto")

    service = DiskService.__new__(DiskService)
    service._roots_cache = None
    service._allowed_roots = lambda: [root.resolve()]
    monkeypatch.setattr(service, "_mount_covering", lambda p: None)
    service.root = root
    service.outside = tmp_path / "outside"
    return service


def test_explore_lists_folders_first_with_info(svc):
    res = svc.explore(str(svc.root))
    names = [i["name"] for i in res["items"]]
    assert names == ["docs", "b.bin"]
    docs = res["items"][0]
    assert docs["type"] == "directory" and docs["is_directory"] is True
    assert docs["item_count"] == 2
    assert res["items"][1]["size"] == 2048
    assert res["items"][1]["modified"].endswith("+00:00")
    assert res["summary"] == {"folders": 1, "files": 1, "total_size": 2048}
    assert res["parent"] is None and res["root"] == str(svc.root)
    assert res["usage"]["total"] > 0


def test_explore_subfolder_has_parent(svc):
    res = svc.explore(str(svc.root / "docs"))
    assert res["parent"] == str(svc.root)


@pytest.mark.parametrize("bad", ["/etc", "/", "relativa", "", "/tmp/../etc"])
def test_paths_outside_roots_are_rejected(svc, bad):
    with pytest.raises(HTTPException) as exc:
        svc.explore(bad)
    assert exc.value.status_code in (400, 403)


def test_symlink_escape_is_rejected(svc):
    link = svc.root / "escape"
    link.symlink_to(svc.outside)
    with pytest.raises(HTTPException) as exc:
        svc.explore(str(link))
    assert exc.value.status_code == 403
    with pytest.raises(HTTPException):
        svc.download_path(str(link / "secret.txt"))


def test_delete_symlink_removes_link_not_target(svc):
    link = svc.root / "lnk"
    link.symlink_to(svc.outside)
    svc.delete_item(str(link), recursive=True)
    assert not os.path.lexists(link)
    assert (svc.outside / "secret.txt").exists()


def test_delete_folder_needs_recursive(svc):
    with pytest.raises(HTTPException) as exc:
        svc.delete_item(str(svc.root / "docs"))
    assert exc.value.status_code == 409
    svc.delete_item(str(svc.root / "docs"), recursive=True)
    assert not (svc.root / "docs").exists()


def test_cannot_delete_or_rename_root(svc):
    with pytest.raises(HTTPException):
        svc.delete_item(str(svc.root), recursive=True)
    with pytest.raises(HTTPException):
        svc.rename(str(svc.root), "otro")


def test_rename(svc):
    svc.rename(str(svc.root / "b.bin"), "c.bin")
    assert (svc.root / "c.bin").exists()
    with pytest.raises(HTTPException) as exc:
        svc.rename(str(svc.root / "c.bin"), "docs")
    assert exc.value.status_code == 409
    for bad in ("", "a/b", "..", "."):
        with pytest.raises(HTTPException):
            svc.rename(str(svc.root / "c.bin"), bad)


def test_create_folder(svc):
    svc.create_folder(str(svc.root), "nueva")
    assert (svc.root / "nueva").is_dir()
    with pytest.raises(HTTPException) as exc:
        svc.create_folder(str(svc.root), "nueva")
    assert exc.value.status_code == 409
    with pytest.raises(HTTPException):
        svc.create_folder(str(svc.root), "../x")


def test_move_and_guards(svc):
    svc.move(str(svc.root / "b.bin"), str(svc.root / "docs"))
    assert (svc.root / "docs" / "b.bin").exists()
    with pytest.raises(HTTPException):
        svc.move(str(svc.root / "docs"), str(svc.root / "docs" / "sub"))
    with pytest.raises(HTTPException):
        svc.move(str(svc.root / "docs" / "b.bin"), str(svc.outside))


def test_copy_names_like_windows(svc):
    a = svc.copy(str(svc.root / "docs" / "a.txt"), str(svc.root / "docs"))
    assert a["name"] == "a - copia.txt"
    b = svc.copy(str(svc.root / "docs" / "a.txt"), str(svc.root / "docs"))
    assert b["name"] == "a - copia (2).txt"
    svc.copy(str(svc.root / "docs"), str(svc.root))
    assert (svc.root / "docs - copia" / "a.txt").exists()
    with pytest.raises(HTTPException):
        svc.copy(str(svc.root / "docs"), str(svc.root / "docs" / "sub"))


def test_info_folder_and_file(svc):
    d = svc.info(str(svc.root / "docs"))
    assert d["stats"]["files"] == 1 and d["stats"]["folders"] == 1
    f = svc.info(str(svc.root / "b.bin"))
    assert f["size"] == 2048 and f["type"] == "file"


def test_search(svc):
    res = svc.search(str(svc.root), "A.TXT")
    assert [r["name"] for r in res["results"]] == ["a.txt"]
    assert res["results"][0]["parent"] == "docs"
    assert svc.search(str(svc.root), "*.bin")["results"][0]["name"] == "b.bin"
    with pytest.raises(HTTPException):
        svc.search(str(svc.root), "  ")


def test_upload_skips_existing_and_creates_subfolders(svc):
    files = [
        UploadFile(io.BytesIO(b"1"), filename="nuevo.txt"),
        UploadFile(io.BytesIO(b"2"), filename="b.bin"),
        UploadFile(io.BytesIO(b"3"), filename="carpeta/dentro.txt"),
        UploadFile(io.BytesIO(b"4"), filename="../mal.txt"),
    ]
    res = asyncio.run(svc.upload(str(svc.root), files))
    assert len(res["created"]) == 2
    assert res["skipped"] == ["b.bin"]
    assert len(res["failed"]) == 1
    assert (svc.root / "carpeta" / "dentro.txt").read_bytes() == b"3"
    assert not (svc.root.parent / "mal.txt").exists()


def test_fs_ops_validate_name():
    assert fs_ops.validate_name("  ok.txt ") == "ok.txt"
    with pytest.raises(HTTPException):
        fs_ops.validate_name("x" * 300)


def test_unmount_handles_missing_mount(monkeypatch):
    service = DiskService.__new__(DiskService)
    service._roots_cache = None
    monkeypatch.setattr(service, "_find_mount_of_device", lambda d: None)
    assert service.unmount("sdz9")["success"] is True
    monkeypatch.setattr(
        service, "_find_mount_of_device",
        lambda d: {"mountpoint": "/mnt/stepad-share/x", "options": set()},
    )
    assert service.unmount("sdz9")["success"] is False


# --------------------------------------------------------------------------- #
# Unidades compartidas (WebFileService)
# --------------------------------------------------------------------------- #

@pytest.fixture()
def web(tmp_path, monkeypatch):
    from backend.shares.services import web_file_service as wfs

    root = tmp_path / "unit"
    root.mkdir()
    (root / "Respaldo").mkdir()
    (root / "Respaldo" / "vault.txt").write_text("privado")
    (root / "Datos").mkdir()
    (root / "Datos" / "x.txt").write_text("x")
    (root / "notas.md").write_text("# hola")

    monkeypatch.setattr(wfs, "_make_samba_writable", lambda p: None)
    service = wfs.WebFileService()
    monkeypatch.setattr(service, "_allowed_roots", lambda db: [root.resolve()])
    service.root = root
    return service


def test_web_list_hides_backup_vault_and_reports_info(web):
    res = web.list_dir(None, str(web.root), "")
    assert [d["name"] for d in res["directories"]] == ["Datos"]
    assert [f["name"] for f in res["files"]] == ["notas.md"]
    assert res["directories"][0]["item_count"] == 1
    assert res["directories"][0]["type"] == "dir"
    assert res["files"][0]["mtime"] and res["files"][0]["modified"]
    assert res["usage"]["free"] > 0


def test_web_copy_info_search(web):
    out = web.copy(None, str(web.root), "Datos/x.txt", "Datos")
    assert out["path"] == "Datos/x - copia.txt"
    info = web.info(None, str(web.root), "Datos")
    assert info["stats"]["files"] == 2 and info["path"] == "Datos"
    found = web.search(None, str(web.root), "", "vault")
    assert found["results"] == []  # la bóveda de respaldo nunca es alcanzable
    assert web.search(None, str(web.root), "", "x")["results"][0]["parent"] == "Datos"
    with pytest.raises(HTTPException):
        web.info(None, str(web.root), "Respaldo")
