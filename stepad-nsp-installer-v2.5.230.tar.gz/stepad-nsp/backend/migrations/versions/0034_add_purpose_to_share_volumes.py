"""add purpose role to share volumes

Revision ID: 0034
Revises: 0033
Create Date: 2026-09-23 20:10:00.000000
"""

from alembic import op
import sqlalchemy as sa


revision = "0034"
down_revision = "0033"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_volumes",
        sa.Column(
            "purpose",
            sa.String(16),
            nullable=False,
            server_default="shared",
        ),
    )


def downgrade() -> None:
    op.drop_column(
        "network_share_volumes",
        "purpose",
    )