"""add wan monitor outages

Revision ID: 0035
Revises: 0034
Create Date: 2026-09-24 11:00:00.000000
"""

from alembic import op
import sqlalchemy as sa


revision = "0035"
down_revision = "0034"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "wan_monitor_outages",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("interface", sa.String(50), nullable=False),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("ended_at", sa.DateTime(), nullable=True),
        sa.Column("duration_seconds", sa.Integer(), nullable=True),
        sa.Column("acknowledge", sa.Boolean(), nullable=False, server_default=sa.false()),
    )
    op.create_index(
        "ix_wan_outage_interface",
        "wan_monitor_outages",
        ["interface"],
    )
    op.create_index(
        "ix_wan_outage_started",
        "wan_monitor_outages",
        ["started_at"],
    )


def downgrade() -> None:
    op.drop_index("ix_wan_outage_started", table_name="wan_monitor_outages")
    op.drop_index("ix_wan_outage_interface", table_name="wan_monitor_outages")
    op.drop_table("wan_monitor_outages")