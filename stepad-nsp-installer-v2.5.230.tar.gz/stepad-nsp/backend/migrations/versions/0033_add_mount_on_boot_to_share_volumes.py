"""add mount on boot to share volumes

Revision ID: 0033
Revises: 0032
Create Date: 2026-09-20 04:13:54.905852
"""

from alembic import op
import sqlalchemy as sa


revision = "0033"
down_revision = "0032"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_volumes",
        sa.Column(
            "mount_on_boot",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
    )


def downgrade() -> None:
    op.drop_column(
        "network_share_volumes",
        "mount_on_boot",
    )