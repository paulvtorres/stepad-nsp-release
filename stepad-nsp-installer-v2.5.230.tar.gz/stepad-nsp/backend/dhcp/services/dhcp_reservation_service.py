from datetime import datetime

from backend.core.database.session import SessionLocal

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.groups.repositories.device_group_repository import (
    DeviceGroupRepository
)

from backend.dhcp.providers.dnsmasq_reservation_provider import (
    DnsmasqReservationProvider
)


class DhcpReservationService:


    def __init__(self):

        self.provider = DnsmasqReservationProvider()

        self.zone_repository = NetworkZoneRepository()

        self.group_repository = DeviceGroupRepository()



    def _deduplicate_by_ip(self, devices):
        """
        Un mismo ip_address puede quedar guardado en mas de un
        dispositivo cuando dnsmasq reasigna la direccion a un equipo
        nuevo pero el registro viejo (ya OFFLINE) nunca se actualiza.
        Escribir dos "dhcp-host" con la misma IP hace que dnsmasq
        rechace el archivo completo y el servicio de DHCP/DNS no
        arranca. Nos quedamos con un solo dispositivo por IP:
        preferimos el que esta ONLINE y, en caso de empate, el visto
        mas recientemente.
        """

        best_by_ip = {}

        for device in devices:

            if not device.ip_address:
                continue

            current = best_by_ip.get(device.ip_address)

            if current is None or self._is_more_current(device, current):
                best_by_ip[device.ip_address] = device

        return list(best_by_ip.values())

    def _is_more_current(self, candidate, current):

        candidate_online = candidate.status == "ONLINE"

        current_online = current.status == "ONLINE"

        if candidate_online != current_online:

            return candidate_online

        return (
            (candidate.last_seen or datetime.min)
            > (current.last_seen or datetime.min)
        )

    def synchronize(self):

        db = SessionLocal()

        try:

            devices = (

                db.query(NetworkDevice)

                .filter(
                    NetworkDevice.mac_address.isnot(None),
                    NetworkDevice.blocked == False,
                )

                .all()

            )

            devices = self._deduplicate_by_ip(devices)

            from backend.shared.config.config_service import ConfigService
            from backend.groups.constants.group_dns_ip_reserve import (
                is_group_dns_alias_ip,
            )

            gateway = (
                ConfigService().get_dhcp_config().get("gateway")
                or "192.168.1.1"
            )

            zones_by_id = {
                zone.id: zone
                for zone in self.zone_repository.find_all(db)
            }

            # Mapa device_id -> grupo DNS (para tag set:grpN dentro de la
            # reserva, en vez de depender de dhcp-host duplicados en
            # groups_dns.conf que rompen la asignación de IP).
            groups = self.group_repository.find_all(db)

            group_ids_by_device: dict[int, list[int]] = {}

            for group in groups:

                for device_id in self.group_repository.device_ids(
                    db, group.id
                ):

                    group_ids_by_device.setdefault(device_id, []).append(
                        group.id
                    )

            default_group_id = None

            for group in groups:

                if bool(getattr(group, "is_default", False)):

                    default_group_id = group.id

                    break

            reservations = []


            for device in devices:

                # FUENTE UNICA DE VERDAD: una reserva existe SOLO cuando el
                # usuario marco permanent_ip (reserva explícita). Los demás
                # dispositivos con IP dinamica NO se escriben como
                # dhcp-host: deben seguir cayendo en el pool dinamico del
                # DHCP. Antes se emitia dhcp-host para cualquiera con IP,
                # lo que sacaba IPs usadas del pool y generaba
                # desincronizaciones base<>archivo.
                if not device.permanent_ip:
                    continue

                if not device.ip_address:
                    continue

                if is_group_dns_alias_ip(device.ip_address, gateway):
                    # Nunca publicar dhcp-host sobre IPs de alias de grupo.
                    continue

                zone = zones_by_id.get(device.zone_id)

                # The default zone's dhcp-range is deliberately left
                # untagged (see NetworkZoneService._regenerate_zone_dhcp)
                # so brand-new, not-yet-reserved devices always have
                # somewhere to land -- reservations into it don't need
                # a tag either. Every other zone requires its tag so
                # dnsmasq's multinetting picks the right range when
                # zones share one physical wire (IP aliasing, no VLAN).
                zone_tag = (
                    f"zone{zone.id}"
                    if zone and not zone.is_default
                    else None
                )

                # Tag del grupo DNS (grpN). Un dispositivo pertenece a
                # UN SOLO grupo DNS: si el default coincide, se usa como
                # fallback; un grupo especifico (no default) siempre gana.
                device_groups = group_ids_by_device.get(device.id, [])

                group_tag = None

                for gid in device_groups:

                    if gid == default_group_id:

                        continue

                    group_tag = f"grp{gid}"

                    break

                if group_tag is None and default_group_id in device_groups:

                    group_tag = f"grp{default_group_id}"

                # IMPORTANTE: las reservas NO fijan hostname. Si se
                # escribe el nombre aquí, dnsmasq lo impone en el lease
                # por encima del que la máquina declara por DHCP y el
                # nombre queda congelado para siempre aunque el equipo
                # se renombre. El nombre debe venir siempre del cliente.
                reservations.append(

                    {
                        "mac": device.mac_address,

                        "ip": device.permanent_ip or device.ip_address,

                        "hostname": "",

                        "zone_tag": zone_tag,

                        "group_tag": group_tag,

                    }

                )


            result = self.provider.write_reservations(
                reservations
            )

            # Aplicar al instante: el DHCP debe excluir las IPs
            # reservadas del pool y entregarlas a sus MAC. Sin esto, el
            # archivo nuevo solo surtiria efecto en el proximo reinicio
            # del servicio.
            try:
                from backend.core.dnsmasq.process_manager import (
                    dnsmasq_process_manager
                )
                dnsmasq_process_manager.restart()
            except Exception as error:
                logger.warning(
                    "No se pudo reiniciar dnsmasq tras sincronizar "
                    "reservas: %s", error
                )

            return result


        finally:

            db.close()