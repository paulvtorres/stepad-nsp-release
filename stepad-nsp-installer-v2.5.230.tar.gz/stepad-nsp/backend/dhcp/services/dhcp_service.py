from backend.dhcp.models.dhcp_config import (
    DhcpConfig
)

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.shared.config.config_service import (
    ConfigService
)

from backend.dhcp.services.dhcp_diagnosis_service import (

    DhcpDiagnosisService

)

from backend.dhcp.services.dhcp_process_service import (

    DhcpProcessService

)

from backend.dhcp.services.dhcp_reload_service import (
    DhcpReloadService
)

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)

from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider

from backend.core.dnsmasq.process_manager import dnsmasq_process_manager

from backend.shared.logging.logger import logger

class DhcpService:


    def __init__(self):

        self.interface_service = InterfaceService()

        self.config_service = ConfigService()
        self.diagnosis_service = DhcpDiagnosisService()
        self.process_service = DhcpProcessService()
        self.reload_service = DhcpReloadService()
        self.reservation_service = DhcpReservationService()
        self.provider = LinuxDhcpProvider()

    def get_default_config(self):

        lan = self.interface_service.get_primary_lan()

        if lan is None:

            return None


        config = self.config_service.get_dhcp_config()

        gateway = config["gateway"]

        from backend.groups.constants.group_dns_ip_reserve import (
            group_ip_bounds,
            group_ip_capacity,
            merge_group_dns_exclusions,
            validate_pool_against_group_reserve,
        )

        exclusions = merge_group_dns_exclusions(
            list(config.get("excluded_ips") or []),
            gateway,
        )

        # Las IP reservadas (permanentes) de dispositivos NO deben salir del
        # pool dinámico: si el equipo reservado aún está apagado, dnsmasq no
        # debe entregarlas a otro. Se agregan a las exclusiones del rango.
        try:
            from backend.core.database.session import SessionLocal
            from backend.network.devices.models.network_device import NetworkDevice
            db = SessionLocal()
            try:
                reserved_ips = (
                    db.query(NetworkDevice.permanent_ip)
                    .filter(
                        NetworkDevice.permanent_ip.isnot(None),
                        NetworkDevice.permanent_ip != "",
                    )
                    .all()
                )
                for (ip,) in reserved_ips:
                    ip = (ip or "").strip()
                    if ip and ip not in exclusions:
                        exclusions.append(ip)
            finally:
                db.close()
        except Exception as error:
            logger.warning(
                "No se pudieron agregar IPs reservadas al pool DHCP: %s",
                error,
            )

        try:
            validate_pool_against_group_reserve(
                config["pool_start"],
                config["pool_end"],
                gateway,
            )
        except ValueError as error:
            logger.warning(
                f"DHCP pool vs reserva de grupos: {error}"
            )

        try:
            g_first, g_last = group_ip_bounds(config)
            group_start = str(g_first)
            group_end = str(g_last)
            group_count = group_ip_capacity(config)
        except Exception:
            group_start = config.get("group_ip_start")
            group_end = config.get("group_ip_end")
            group_count = config.get("group_ip_count")

        return DhcpConfig(

            interface=lan.name,

            network=config["network"],

            netmask=config["netmask"],

            gateway=gateway,

            dns_server=config["dns_server"],

            pool_start=config["pool_start"],

            pool_end=config["pool_end"],

            lease_time=config["lease_time"],

            # Siempre incluye el subrango de grupos (p. ej. .10-.19)
            # para alias DNS — el DHCP no puede entregarlos a equipos.
            excluded_ips=exclusions,

            group_ip_start=group_start,

            group_ip_end=group_end,

            group_ip_count=group_count,

        )


    def get_exclusions(self):

        config = self.config_service.get_dhcp_config()

        from backend.groups.constants.group_dns_ip_reserve import (
            merge_group_dns_exclusions,
        )

        return merge_group_dns_exclusions(
            list(config.get("excluded_ips") or []),
            config.get("gateway") or "192.168.1.1",
        )


    def set_exclusions(
        self,
        ips: list[str],
        pool_start: str | None = None,
        pool_end: str | None = None,
    ):
        """Guarda las IPs que el DHCP no debe asignar y reaplica DHCP."""
        config = self.config_service.get_dhcp_config()

        from backend.groups.constants.group_dns_ip_reserve import (
            merge_group_dns_exclusions,
        )

        exclusions = self._validate_exclusions(
            ips,
            network=config.get("network"),
            netmask=config.get("netmask"),
            gateway=config.get("gateway")
        )

        # La reserva de alias de grupos no es opcional.
        exclusions = merge_group_dns_exclusions(
            exclusions,
            config.get("gateway") or "192.168.1.1",
        )

        config["excluded_ips"] = exclusions

        self.config_service.update_section("dhcp", config)

        result = self.apply_config()

        return {
            "success": result.get("success", False),
            "excluded_ips": exclusions,
            "dhcp": result
        }


    def _validate_exclusions(
        self,
        ips: list[str],
        network: str,
        netmask: str,
        gateway: str
    ):
        from backend.dhcp.services.dhcp_exclusion_utils import (
            normalize_exclusions
        )

        return normalize_exclusions(
            ips,
            network,
            netmask,
            gateway
        )


    def apply_config(self):
        """
        The one place that makes dnsmasq actually match "what LAN is
        currently assigned". Used at boot (DhcpComponent.start()) AND
        live, right when a LAN role gets assigned through the web UI
        (see InterfaceRegistryService._sync_config_cache) -- without
        the live path, assigning LAN only moved the IP onto the
        interface; dnsmasq itself stayed down until the next full
        STEPAD restart, which isn't the behavior anyone assigning a
        role from the UI would expect.

        Safe to call with no LAN assigned: returns immediately without
        writing anything or touching dnsmasq (see get_default_config).
        """

        reservation_result = self.reservation_service.synchronize()

        config = self.get_default_config()

        if config is None:

            logger.error(
                "DHCP configuration not available. LAN not detected."
            )

            return {"success": False, "message": "LAN not detected"}

        write_result = self.provider.write_config(config)

        if dnsmasq_process_manager.status().get("running"):

            start_result = dnsmasq_process_manager.restart()

        else:

            start_result = self.provider.start()

        logger.info(
            f"DHCP applied -- reservations: {reservation_result}, "
            f"config: {write_result}, service: {start_result}"
        )

        return {

            "success": write_result.get("success", False) and start_result.get("success", False),

            "reservations": reservation_result,

            "config": write_result,

            "service": start_result

        }


    def get_status(self):

        return self.process_service.status()
    
    def diagnose(self):

        return self.diagnosis_service.diagnose()
    
    def reload(self):

        return self.reload_service.reload()

    def sync_device_ips(self) -> dict:
        """Sincroniza ip_address de dispositivos con ARP/leases DHCP.

        Así, cuando un equipo renueva y toma su IP reservada, ip_address se
        actualiza solo y las referencias (Samba, ancho de banda, grupos) que
        usan ip_address cambian automáticamente a la reservada."""
        import subprocess
        from backend.core.database.session import SessionLocal
        from backend.network.devices.models.network_device import NetworkDevice

        arp_ips = {}
        try:
            with open("/proc/net/arp") as f:
                for line in f.readlines()[1:]:
                    parts = line.split()
                    if len(parts) >= 4 and parts[2] != "0x0":
                        ip = parts[0]
                        mac = parts[3].lower()
                        if mac != "00:00:00:00:00:00":
                            arp_ips[mac] = ip
        except Exception:
            pass

        lease_ips = {}
        try:
            result = subprocess.run(
                ["cat", "/var/lib/misc/dnsmasq.leases"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 4:
                    lease_ips[parts[1].lower()] = parts[2]
        except Exception:
            pass

        real_ips = {**lease_ips, **arp_ips}

        db = SessionLocal()
        try:
            devices = (
                db.query(NetworkDevice)
                .filter(NetworkDevice.mac_address.isnot(None))
                .all()
            )
            updated = 0
            cleared = 0
            for device in devices:
                mac = (device.mac_address or "").lower()
                real_ip = real_ips.get(mac)
                if getattr(device, "is_permanent", False):
                    if real_ip and device.ip_address != real_ip:
                        device.ip_address = real_ip
                        updated += 1
                else:
                    if real_ip and device.ip_address != real_ip:
                        device.ip_address = real_ip
                        updated += 1
                    elif not real_ip and device.ip_address:
                        device.ip_address = ""
                        cleared += 1
            db.commit()
            return {
                "success": True,
                "updated": updated,
                "cleared": cleared,
                "arp_count": len(arp_ips),
                "lease_count": len(lease_ips),
            }
        finally:
            db.close()
    