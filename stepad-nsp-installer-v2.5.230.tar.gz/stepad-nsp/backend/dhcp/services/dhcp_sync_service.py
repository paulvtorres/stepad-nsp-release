"""
Central DHCP synchronization service.

Responsibilities:
- Sync device IPs with ARP table and DHCP leases
- Maintain permanent IP reservations
- Clean up stale IPs and leases
- Ensure database matches real network state
"""
import subprocess
from pathlib import Path

from sqlalchemy.orm import Session

from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.logging.logger import logger


class DhcpSyncService:
    """Central service for DHCP synchronization."""

    ARP_FILE = "/proc/net/arp"
    LEASE_FILE = "/var/lib/misc/dnsmasq.leases"

    def sync_all(self, db: Session) -> dict:
        """Sync all device IPs from ARP table and DHCP leases."""
        arp_ips = self._read_arp()
        lease_ips = self._read_leases()
        real_ips = {**lease_ips, **arp_ips}

        devices = db.query(NetworkDevice).filter(
            NetworkDevice.mac_address.isnot(None)
        ).all()

        updated = 0
        cleared = 0
        for device in devices:
            mac = (device.mac_address or "").lower()
            real_ip = real_ips.get(mac)

            if real_ip and device.ip_address != real_ip:
                device.ip_address = real_ip
                updated += 1
            elif not real_ip and device.ip_address:
                device.ip_address = ""
                cleared += 1

        db.commit()
        return {
            "success": True,
            "updated": updated,
            "cleared": cleared,
            "arp_count": len(arp_ips),
            "lease_count": len(lease_ips),
        }

    def write_reservation(self, mac: str, ip: str) -> bool:
        """Write DHCP reservation for a MAC address."""
        from backend.core.config.paths import RESERVATIONS_CONFIG
        try:
            result = subprocess.run(
                ["grep", "-v", mac.lower(), str(RESERVATIONS_CONFIG)],
                capture_output=True, text=True, timeout=5
            )
            lines = result.stdout.rstrip("\n") + "\n"
            lines += f"dhcp-host={mac.lower()},{ip},\n"
            with open(str(RESERVATIONS_CONFIG), "w") as f:
                f.write(lines)
            return True
        except Exception as e:
            logger.error("Failed to write reservation: %s", e)
            return False

    def remove_lease(self, mac: str) -> bool:
        """Remove DHCP lease for a MAC address."""
        try:
            result = subprocess.run(
                ["grep", "-v", mac.lower(), self.LEASE_FILE],
                capture_output=True, text=True, timeout=5
            )
            with open(self.LEASE_FILE, "w") as f:
                f.write(result.stdout)
            return True
        except Exception as e:
            logger.error("Failed to remove lease: %s", e)
            return False

    def update_hosts_entry(self, hostname: str, ip: str) -> bool:
        """Update /etc/hosts with hostname -> IP mapping."""
        if not hostname:
            return False
        try:
            result = subprocess.run(
                ["grep", "-v", hostname, "/etc/hosts"],
                capture_output=True, text=True, timeout=5
            )
            lines = result.stdout.rstrip("\n") + "\n"
            lines += f"{ip}\t{hostname}\n"
            with open("/etc/hosts", "w") as f:
                f.write(lines)
            return True
        except Exception as e:
            logger.error("Failed to update hosts: %s", e)
            return False

    def restart_dnsmasq(self) -> bool:
        """Kill and restart dnsmasq fresh (clears in-memory state)."""
        try:
            pid = subprocess.check_output(
                ["pidof", "dnsmasq"]
            ).decode().strip()
            subprocess.run(["kill", "-9", pid], timeout=5)
            import time
            time.sleep(1)
            subprocess.run(
                ["/usr/sbin/dnsmasq", "--conf-file=/etc/stepad/dns/dnsmasq.conf"],
                timeout=5
            )
            return True
        except Exception as e:
            logger.error("Failed to restart dnsmasq: %s", e)
            return False

    def sync_device_permanent(self, device) -> None:
        """Atomic sync when permanent IP is assigned.

        FUENTE UNICA DE VERDAD: la reserva es device.permanent_ip en la
        base. En lugar de escribir el archivo aparte (que se pisaba con
        el barrido masivo), se regenera reservations.conf completo desde
        la DB via DhcpReservationService.synchronize() (que además
        reinicia dnsmasq). Tambien mantiene /etc/hosts y limpia la lease
        vieja de la MAC para que tome la nueva IP.
        """
        if not device.mac_address or not device.permanent_ip:
            return

        mac = device.mac_address.lower()
        ip = device.permanent_ip
        hostname = device.hostname or ""

        # hosts y lease: intenciones concretas de este cambio.
        self.update_hosts_entry(hostname, ip)
        self.remove_lease(mac)

        # Regenerar reservations.conf completo desde la DB (fuente
        # unica) y reiniciar dnsmasq.
        from backend.dhcp.services.dhcp_reservation_service import (
            DhcpReservationService
        )
        DhcpReservationService().synchronize()

    def _read_arp(self) -> dict:
        """Read ARP table, only REACHABLE/STALE/DELAY entries."""
        arp_ips = {}
        try:
            with open(self.ARP_FILE) as f:
                for line in f.readlines()[1:]:
                    parts = line.split()
                    if len(parts) >= 5 and parts[4] in ("REACHABLE", "STALE", "DELAY"):
                        arp_ips[parts[3].lower()] = parts[0]
        except Exception:
            pass
        return arp_ips

    def _read_leases(self) -> dict:
        """Read DHCP leases."""
        lease_ips = {}
        try:
            result = subprocess.run(
                ["cat", self.LEASE_FILE],
                capture_output=True, text=True, timeout=5
            )
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 3:
                    lease_ips[parts[1].lower()] = parts[2]
        except Exception:
            pass
        return lease_ips
