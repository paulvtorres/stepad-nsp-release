from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.dhcp.services.dhcp_service import DhcpService
from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider

from backend.shared.logging.logger import logger

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)

from backend.dhcp.services.dhcp_reservation_cleanup_service import (
    DhcpReservationCleanupService
)

from backend.dhcp.services.dhcp_alert_service import (
    DhcpAlertService
)


class DhcpComponent(BaseComponent):

    name = "dhcp"

    criticality = ComponentCriticality.IMPORTANT


    def __init__(self):

        self.service = DhcpService()

        self.provider = LinuxDhcpProvider()
        self.reservation_service = DhcpReservationService()
        self.cleanup_service = DhcpReservationCleanupService()
        self.alert_service = DhcpAlertService()

        self.process = None
        self._sync_stop = False
        self._sync_thread = None

    def _sync_ip_loop(self) -> None:
        """Sincroniza periódicamente ip_address desde ARP/leases.

        Cuando un equipo con IP reservada renueva y toma la reservada,
        ip_address se actualiza aquí y las referencias (Samba, ancho de
        banda, grupos) cambian automáticamente a la IP nueva."""
        import time
        while not self._sync_stop:
            try:
                self.service.sync_device_ips()
            except Exception as error:
                logger.warning(
                    "DHCP sync de IPs (periodico) falló: %s",
                    error,
                )
            for _ in range(60):
                if self._sync_stop:
                    return
                time.sleep(1)


    def start(self):

        logger.info(
            "DhcpComponent started."
        )

        result = self.service.apply_config()

        if result.get("success"):

            self.process = result.get("service", {}).get("pid")

        self.cleanup_service.start_scheduler()
        self.alert_service.start_scheduler()

        if self._sync_thread is None:
            self._sync_stop = False
            import threading
            self._sync_thread = threading.Thread(
                target=self._sync_ip_loop,
                daemon=True,
                name="dhcp-sync-ips",
            )
            self._sync_thread.start()


    def stop(self):

        logger.info(
            "Stopping DHCP service."
        )

        self._sync_stop = True
        thread = self._sync_thread
        if thread and thread.is_alive():
            thread.join(timeout=3)
        self._sync_thread = None

        self.cleanup_service.stop_scheduler()
        self.alert_service.stop_scheduler()

        result = self.provider.stop()


        logger.info(
            f"DHCP stopped: {result}"
        )