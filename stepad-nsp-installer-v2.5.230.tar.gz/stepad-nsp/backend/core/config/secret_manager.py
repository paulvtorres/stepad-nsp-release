"""
Gestor centralizado de secretos del sistema.

Garantiza que una clave tipo "password del repositorio restic" JAMÁS
se pierda por una reinstalación o reinicio:

  - Lee primero del archivo de entorno (`/etc/stepad/stepad.env`).
  - Si falta, la restaura desde las copias versionadas que deja el
    actualizador en `ENV_BACKUP_DIR` (get-stepad.sh) antes de echar a
    rodar una instalación.
  - Si tampoco hay copia, RE-CREA la clave pero la persiste de forma
    atómica en todos los sitios a la vez (env + backup), de modo que a
    partir de ese instante existe redundancia.
  - Cada llamada a `ensure_secret` deja además una copia fresca en
    `ENV_BACKUP_DIR` si la más reciente tiene ya >N horas, para que
    siempre haya un respaldo reciente de la clave.

Es el único punto del sistema que crea claves: nada más debe generar
passwords de forma ad-hoc (ese patrón era la fuente del bug: el
instalador reescribía el env borrando la clave, y luego cada servicio
generaba una distinta a su antojo).
"""

from __future__ import annotations

import re
import secrets as _secrets
from datetime import datetime, timezone
from pathlib import Path

from backend.shared.logging.logger import logger


ENV_FILE = Path("/etc/stepad/stepad.env")
ENV_BACKUP_DIR = Path("/etc/stepad/env-backups")

# Una clave que no es de SEGURIDAD critica (modo 0644) pero cuyo rotor
# no debe perderse. La conservamos exclusivamente con los metodos de
# esta clase.
_RESTIC_KEY_NAME = "STEPAD_RESTIC_PASSWORD"

BACKUP_MAX_AGE_SECONDS = 6 * 3600  # renovar backup reciente cada 6h


def _read_env() -> dict[str, str]:
    values: dict[str, str] = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or "=" not in line or line.startswith("#"):
                continue
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip().strip("\"'")
    return values


def _latest_backup() -> Path | None:
    if not ENV_BACKUP_DIR.is_dir():
        return None
    backups = sorted(
        (
            p
            for p in ENV_BACKUP_DIR.iterdir()
            if p.name.startswith("stepad.env.") and p.is_file()
        ),
        key=lambda p: p.name,
        reverse=True,
    )
    return backups[0] if backups else None


def _backup_now() -> Path:
    ENV_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    dest = ENV_BACKUP_DIR / f"stepad.env.{ts}.manual"
    if ENV_FILE.exists():
        import shutil
        shutil.copy2(ENV_FILE, dest)
    else:
        dest.write_text("", encoding="utf-8")
    try:
        dest.chmod(0o600)
    except Exception:
        pass
    # Poda de copias viejas: 90 dias.
    cutoff = datetime.now(timezone.utc).timestamp() - 90 * 86400
    for p in ENV_BACKUP_DIR.glob("stepad.env.*"):
        try:
            if p.stat().st_mtime < cutoff:
                p.unlink()
        except OSError:
            pass
    return dest


def _restore_from_backups() -> str | None:
    """Devuelve STEPAD_RESTIC_PASSWORD de la copia de env mas reciente."""
    backup = _latest_backup()
    if backup is None:
        return None
    try:
        for line in backup.read_text(encoding="utf-8").splitlines():
            if line.startswith(_RESTIC_KEY_NAME + "="):
                value = (
                    line.split("=", 1)[1].strip().strip("\"'")
                )
                if value:
                    return value
    except Exception as error:
        logger.warning(
            "No se pudo leer backup de env (%s): %s", backup.name, error
        )
    return None


def _persist_to_env(key: str, value: str) -> None:
    """Agrega la clave al env. No la pisa, para no corromper otras claves."""
    if not ENV_FILE.exists():
        ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
        ENV_FILE.write_text("", encoding="utf-8")
    existing = _read_env()
    if existing.get(key):
        return
    with ENV_FILE.open("a", encoding="utf-8") as file:
        file.write(f"\n{key}={value}\n")
    try:
        ENV_FILE.chmod(0o600)
    except Exception:
        pass


def get_restic_password(*, force_persist: bool = True) -> str:
    """
    Fuente unica de la password del repositorio restic. Nunca devuelve
    None: si no hay forma de recuperarla, genera una nueva y la
    persiste en TODOS los sitios de forma atomica.
    """
    value = _read_env().get(_RESTIC_KEY_NAME)

    if not value:
        restored = _restore_from_backups()
        if restored:
            value = restored
            _persist_to_env(_RESTIC_KEY_NAME, value)
            logger.warning(
                "STEPAD_RESTIC_PASSWORD no estaba en el env; "
                "restaurada desde los backups del actualizador."
            )

    if not value:
        value = _secrets.token_hex(16)
        _persist_to_env(_RESTIC_KEY_NAME, value)
        logger.warning(
            "STEPAD_RESTIC_PASSWORD no existía en ningún lado; "
            "generada nueva y persistida (repos existentes no se "
            "podrán descifrar con esta clave)."
        )

    if force_persist:
        # Mantiene fresco el respaldo: si el mas reciente ya no está
        # vigente o no contiene la clave, hace una copia nueva.
        backup = _latest_backup()
        if backup is None or _RESTIC_KEY_NAME not in (
            backup.read_text(encoding="utf-8", errors="ignore")
        ):
            _backup_now()
        else:
            try:
                age = datetime.now(timezone.utc).timestamp() - backup.stat().st_mtime
                if age > BACKUP_MAX_AGE_SECONDS:
                    _backup_now()
            except OSError:
                _backup_now()

    return value


def ensure_env_backup() -> Path | None:
    """Llama desde el arranque para garantizar una copia reciente."""
    try:
        get_restic_password()
        return _latest_backup()
    except Exception as error:
        logger.warning("ensure_env_backup falló: %s", error)
        return None