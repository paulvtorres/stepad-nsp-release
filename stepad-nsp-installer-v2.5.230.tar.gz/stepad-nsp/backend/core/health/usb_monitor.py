"""Monitor de discos USB: detecta si un disco se desconecta montado y genera alerta."""

import subprocess
import threading
import time
from datetime import datetime

from backend.shared.logging.logger import logger


class UsbMonitor:
    def __init__(self):
        self._known_usb = set()
        self._running = False
        self._thread = None

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="usb-monitor")
        self._thread.start()
        logger.info("USB monitor: iniciado (verifica cada 30s)")

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self._check()
            except Exception as e:
                logger.warning("USB monitor: error: %s", e)
            time.sleep(30)

    def _check(self):
        result = subprocess.run(
            ["lsblk", "-o", "NAME,TYPE,TRAN", "-nr"],
            capture_output=True, text=True, timeout=5,
        )
        current_usb = set()
        for line in result.stdout.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[1] == "disk" and parts[2] == "usb":
                current_usb.add(parts[0])

        disconnected = self._known_usb - current_usb
        if disconnected:
            for disk in disconnected:
                self._alert_disconnected(disk)

        self._known_usb = current_usb

    def _alert_disconnected(self, disk):
        logger.warning("USB monitor: disco %s desconectado", disk)
        try:
            from backend.core.database.session import SessionLocal
            from sqlalchemy import text

            db = SessionLocal()
            try:
                db.execute(
                    text(
                        "INSERT INTO alerts (alert_type, severity, title, message, "
                        "read, created_at) VALUES "
                        "(:at, :sev, :title, :msg, false, :ts)"
                    ),
                    {
                        "at": "USB_DISCONNECTED",
                        "sev": "warning",
                        "title": f"Disco USB desconectado: {disk}",
                        "message": (
                            f"El disco {disk} fue desconectado mientras estaba "
                            "montado. Si tenias archivos abiertos, podrian haberse "
                            "corrompido. Reconectalo y verifica su integridad."
                        ),
                        "ts": datetime.utcnow(),
                    },
                )
                db.commit()
            except Exception as e:
                logger.error("USB monitor: no pude crear alerta: %s", e)
            finally:
                db.close()
        except Exception as e:
            logger.error("USB monitor: error creando alerta: %s", e)


usb_monitor = UsbMonitor()
