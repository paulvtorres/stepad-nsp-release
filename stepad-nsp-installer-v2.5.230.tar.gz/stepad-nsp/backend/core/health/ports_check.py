"""Verificacion de puertos abiertos en el NSP.

Compara los puertos escuchando contra la lista de puertos permitidos.
Si encuentra puertos no esperados, genera alerta.
"""

import subprocess

from backend.shared.logging.logger import logger


# Puertos que el NSP DEBE escuchar (TCP, en 0.0.0.0)
EXPECTED_TCP = {
    22: "SSH (admin)",
    53: "DNS (local)",
    8443: "HTTPS (panel web)",
    51820: "WireGuard VPN",
}

# Puertos que NUNCA deben estar abiertos en 0.0.0.0 (TCP)
FORBIDDEN_TCP = {
    80: "HTTP (debe usar HTTPS 8443)",
    3306: "MySQL (base de datos no expuesta)",
    5432: "PostgreSQL (debe ser solo localhost)",
    445: "Samba/SMB (no exponer)",
    139: "NetBIOS (no exponer)",
    3389: "RDP (no exponer)",
    11211: "Memcached (no exponer)",
    6379: "Redis (no exponer)",
    27017: "MongoDB (no exponer)",
}


def check_ports():
    """Verifica puertos abiertos y retorna problemas encontrados."""
    issues = []

    try:
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            logger.warning("ports_check: no pude ejecutar ss")
            return issues

        open_ports = {}
        for line in result.stdout.splitlines()[1:]:
            parts = line.split()
            if len(parts) < 4:
                continue
            local = parts[3]
            if ":" not in local:
                continue
            port_str = local.rsplit(":", 1)[-1]
            try:
                port = int(port_str)
            except ValueError:
                continue
            if local.startswith("0.0.0.0:") or local.startswith("[::]:"):
                open_ports[port] = line.strip()

        for port, desc in FORBIDDEN_TCP.items():
            if port in open_ports:
                issues.append({
                    "check": "ports",
                    "severity": "critical",
                    "title": "Puerto prohibido abierto: %d (%s)" % (port, desc),
                    "message": (
                        "El puerto %d (%s) esta escuchando en todas las "
                        "interfaces. Esto es un riesgo de seguridad."
                        "\n\nLinea: %s"
                        % (port, desc, open_ports.get(port, ""))
                    ),
                    "repair": (
                        "1) Identifique que servicio lo abre: "
                        "ss -tlnp | grep ':%d'\n"
                        "2) Detenga ese servicio: "
                        "sudo systemctl stop <servicio>\n"
                        "3) Si es intencional, restrinja a localhost: "
                        "bind 127.0.0.1 en su config" % port
                    ),
                })

        for port, desc in EXPECTED_TCP.items():
            if port not in open_ports:
                issues.append({
                    "check": "ports",
                    "severity": "warning",
                    "title": "Puerto esperado no escucha: %d (%s)" % (port, desc),
                    "message": (
                        "El puerto %d (%s) no esta escuchando. "
                        "Esto puede indicar un servicio caido." % (port, desc)
                    ),
                    "repair": (
                        "Verifique el servicio asociado y reinicie si es necesario."
                    ),
                })

    except Exception as exc:
        logger.warning("ports_check: error: %s", exc)

    return issues
