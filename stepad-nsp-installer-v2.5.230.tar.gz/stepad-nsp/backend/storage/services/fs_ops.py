"""Operaciones de sistema de archivos compartidas por los exploradores web.

Este módulo NO valida que una ruta esté permitida: lo hacen los servicios que
lo usan (``DiskService`` para discos físicos y ``WebFileService`` para las
unidades compartidas). Aquí solo se describe, copia, busca y calcula tamaños
sobre rutas que ya fueron confinadas a una raíz permitida.

Todos los errores de usuario se lanzan como ``HTTPException`` para que el
frontend reciba un ``detail`` legible.
"""

from __future__ import annotations

import errno
import fnmatch
import grp
import mimetypes
import os
import pwd
import shutil
import stat as stat_mod
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from fastapi import HTTPException

# Límites para que un directorio enorme (o un disco lento) no cuelgue la API.
CHILD_COUNT_CAP = 5000          # tope de elementos que se cuentan por carpeta
LISTING_COUNT_BUDGET_S = 1.5    # tiempo total para contar hijos de un listado
STATS_MAX_ENTRIES = 200_000     # tope para el cálculo recursivo de tamaño
STATS_MAX_SECONDS = 6.0
SEARCH_MAX_RESULTS = 500
SEARCH_MAX_SCANNED = 100_000
SEARCH_MAX_SECONDS = 8.0
MAX_NAME_BYTES = 255


# --------------------------------------------------------------------------- #
# Utilidades básicas
# --------------------------------------------------------------------------- #

def iso_utc(timestamp: float | None) -> str | None:
    """ISO 8601 con zona horaria explícita (UTC).

    El frontend convierte a la hora de la empresa; devolver un instante sin
    zona (``fromtimestamp().isoformat()``) haría que se interprete en la zona
    del servidor y las horas salgan corridas.
    """
    if timestamp is None:
        return None
    try:
        return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()
    except (OverflowError, OSError, ValueError):
        return None


def legacy_mtime(timestamp: float | None) -> str | None:
    """Formato histórico ``YYYY-MM-DD HH:MM`` (UTC) que ya usaba el API."""
    if timestamp is None:
        return None
    try:
        return time.strftime("%Y-%m-%d %H:%M", time.gmtime(timestamp))
    except (OverflowError, OSError, ValueError):
        return None


def validate_name(name: str | None) -> str:
    """Valida el nombre de un archivo/carpeta nuevo (crear o renombrar)."""
    value = (name or "").strip()
    if not value:
        raise HTTPException(400, "El nombre no puede estar vacío.")
    if value in (".", ".."):
        raise HTTPException(400, "Nombre no permitido.")
    if "/" in value or "\x00" in value:
        raise HTTPException(400, "El nombre no puede contener «/».")
    if len(value.encode("utf-8", errors="ignore")) > MAX_NAME_BYTES:
        raise HTTPException(400, "El nombre es demasiado largo (máx. 255 bytes).")
    return value


def raise_os_error(exc: OSError, action: str = "completar la operación") -> None:
    """Traduce un ``OSError`` a un ``HTTPException`` con mensaje claro."""
    code = getattr(exc, "errno", None)
    if code == errno.EROFS:
        raise HTTPException(403, "El disco está montado en solo lectura.") from exc
    if code in (errno.EACCES, errno.EPERM):
        raise HTTPException(403, f"Sin permiso para {action}.") from exc
    if code == errno.ENOSPC:
        raise HTTPException(507, "No hay espacio suficiente en la unidad.") from exc
    if code == errno.ENAMETOOLONG:
        raise HTTPException(400, "El nombre es demasiado largo.") from exc
    if code in (errno.EEXIST, errno.ENOTEMPTY):
        raise HTTPException(409, "Ya existe o la carpeta no está vacía.") from exc
    if code == errno.EINVAL:
        raise HTTPException(
            400, "Nombre no válido para el sistema de archivos de esta unidad."
        ) from exc
    detail = exc.strerror or str(exc)
    raise HTTPException(500, f"No se pudo {action}: {detail}") from exc


def _permission_string(mode: int) -> str:
    return stat_mod.filemode(mode)


def _owner_group(st: os.stat_result) -> tuple[str, str]:
    try:
        owner = pwd.getpwuid(st.st_uid).pw_name
    except (KeyError, OverflowError):
        owner = str(st.st_uid)
    try:
        group = grp.getgrgid(st.st_gid).gr_name
    except (KeyError, OverflowError):
        group = str(st.st_gid)
    return owner, group


def count_children(
    path: Path,
    *,
    hidden_names: Iterable[str] = (),
    cap: int = CHILD_COUNT_CAP,
) -> int | None:
    """Cantidad de elementos directos de una carpeta (``None`` si no se puede leer)."""
    hidden = set(hidden_names)
    total = 0
    try:
        with os.scandir(path) as it:
            for entry in it:
                if entry.name in hidden:
                    continue
                total += 1
                if total >= cap:
                    break
    except OSError:
        return None
    return total


# --------------------------------------------------------------------------- #
# Descripción de elementos y listados
# --------------------------------------------------------------------------- #

def describe_entry(
    path: Path,
    *,
    count_dir_children: bool = False,
    hidden_names: Iterable[str] = (),
) -> dict | None:
    """Metadatos de un elemento. ``None`` si desapareció o no se puede leer."""
    try:
        lst = path.lstat()
    except OSError:
        return None

    is_link = stat_mod.S_ISLNK(lst.st_mode)
    broken = False
    st = lst
    if is_link:
        try:
            st = path.stat()
        except OSError:
            broken = True

    is_dir = (not broken) and stat_mod.S_ISDIR(st.st_mode)
    name = path.name
    suffix = "" if is_dir else path.suffix.lstrip(".").lower()

    item = {
        "name": name,
        "type": "dir" if is_dir else "file",
        "size": None if is_dir else (0 if broken else st.st_size),
        "modified": iso_utc(st.st_mtime),
        "mtime": legacy_mtime(st.st_mtime),
        "ext": suffix,
        "hidden": name.startswith("."),
        "symlink": is_link,
        "broken_link": broken,
        "item_count": None,
    }
    if is_dir and count_dir_children:
        item["item_count"] = count_children(path, hidden_names=hidden_names)
    return item


def list_entries(
    target: Path,
    *,
    hidden_names: Iterable[str] = (),
    dir_type_name: str = "dir",
) -> dict:
    """Lista una carpeta: carpetas primero, luego archivos (orden alfabético).

    Devuelve ``{"items", "directories", "files", "summary"}``. ``directories`` y
    ``files`` mantienen el formato que ya consumía el explorador de unidades
    compartidas; ``items`` es la lista combinada.
    """
    hidden = set(hidden_names)
    try:
        raw = list(os.scandir(target))
    except PermissionError as exc:
        raise HTTPException(403, "Sin permiso para leer la carpeta.") from exc
    except OSError as exc:
        raise HTTPException(500, f"No se pudo leer la carpeta: {exc}") from exc

    directories: list[dict] = []
    files: list[dict] = []
    deadline = time.monotonic() + LISTING_COUNT_BUDGET_S
    total_size = 0

    for entry in sorted(raw, key=lambda e: e.name.lower()):
        if entry.name in hidden:
            continue
        item = describe_entry(Path(entry.path))
        if item is None:
            continue
        if item["type"] == "dir":
            if time.monotonic() < deadline:
                item["item_count"] = count_children(
                    Path(entry.path), hidden_names=hidden
                )
            directories.append(item)
        else:
            total_size += item["size"] or 0
            files.append(item)

    if dir_type_name != "dir":
        for item in directories:
            item["type"] = dir_type_name
    items = directories + files
    for item in items:
        item["is_directory"] = item["type"] != "file"

    return {
        "items": items,
        "directories": directories,
        "files": files,
        "summary": {
            "folders": len(directories),
            "files": len(files),
            "total_size": total_size,
        },
    }


def disk_usage(path: Path) -> dict | None:
    """Espacio total/usado/libre del sistema de archivos que contiene ``path``."""
    try:
        usage = shutil.disk_usage(path)
    except OSError:
        return None
    return {"total": usage.total, "used": usage.used, "free": usage.free}


# --------------------------------------------------------------------------- #
# Propiedades (equivalente a «Propiedades» de Windows)
# --------------------------------------------------------------------------- #

def folder_stats(
    path: Path,
    *,
    hidden_names: Iterable[str] = (),
    max_entries: int = STATS_MAX_ENTRIES,
    max_seconds: float = STATS_MAX_SECONDS,
) -> dict:
    """Tamaño y cantidad de archivos/carpetas de forma recursiva (con topes)."""
    hidden = set(hidden_names)
    files = 0
    folders = 0
    total = 0
    on_disk = 0
    scanned = 0
    partial = False
    deadline = time.monotonic() + max_seconds
    stack = [str(path)]

    while stack:
        current = stack.pop()
        try:
            with os.scandir(current) as it:
                for entry in it:
                    if entry.name in hidden:
                        continue
                    scanned += 1
                    if scanned > max_entries or time.monotonic() > deadline:
                        partial = True
                        stack.clear()
                        break
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            folders += 1
                            stack.append(entry.path)
                        else:
                            st = entry.stat(follow_symlinks=False)
                            files += 1
                            total += st.st_size
                            on_disk += getattr(st, "st_blocks", 0) * 512
                    except OSError:
                        continue
        except OSError:
            continue

    return {
        "files": files,
        "folders": folders,
        "total_size": total,
        "size_on_disk": on_disk,
        "partial": partial,
    }


def entry_properties(
    path: Path,
    *,
    hidden_names: Iterable[str] = (),
    display_path: str | None = None,
) -> dict:
    """Propiedades detalladas de un archivo o carpeta."""
    try:
        lst = path.lstat()
    except OSError as exc:
        raise HTTPException(404, "No existe.") from exc

    item = describe_entry(path, count_dir_children=True, hidden_names=hidden_names)
    if item is None:
        raise HTTPException(404, "No existe.")

    try:
        st = path.stat()
    except OSError:
        st = lst

    owner, group = _owner_group(st)
    props = {
        **item,
        "path": display_path if display_path is not None else str(path),
        "permissions": _permission_string(st.st_mode),
        "owner": owner,
        "group": group,
        "accessed": iso_utc(st.st_atime),
        # En Linux ctime es el último cambio de metadatos, no la creación.
        "changed": iso_utc(st.st_ctime),
        "size_on_disk": getattr(st, "st_blocks", 0) * 512,
        "mime": None,
        "symlink_target": None,
        "stats": None,
    }

    if item["symlink"]:
        try:
            props["symlink_target"] = os.readlink(path)
        except OSError:
            pass

    if item["type"] == "file":
        props["mime"] = mimetypes.guess_type(path.name)[0]
    else:
        props["stats"] = folder_stats(path, hidden_names=hidden_names)
        props["size"] = props["stats"]["total_size"]
        props["size_on_disk"] = props["stats"]["size_on_disk"]
        props["usage"] = disk_usage(path) if os.path.ismount(path) else None

    return props


# --------------------------------------------------------------------------- #
# Copiar / mover / búsqueda
# --------------------------------------------------------------------------- #

def unique_copy_name(dest_dir: Path, name: str) -> str:
    """Nombre libre en ``dest_dir`` al estilo Windows: «x - copia (2).txt»."""
    if not os.path.lexists(dest_dir / name):
        return name
    source = Path(name)
    stem, suffix = source.stem, source.suffix
    if not suffix and name.startswith("."):
        stem, suffix = name, ""
    candidate = f"{stem} - copia{suffix}"
    counter = 2
    while os.path.lexists(dest_dir / candidate):
        candidate = f"{stem} - copia ({counter}){suffix}"
        counter += 1
    return candidate


def copy_item(src: Path, dest_dir: Path) -> Path:
    """Copia un archivo o carpeta dentro de ``dest_dir`` y devuelve la nueva ruta."""
    if not dest_dir.is_dir():
        raise HTTPException(400, "La carpeta de destino no existe.")

    src_real = src.resolve()
    dest_real = dest_dir.resolve()
    if src.is_dir():
        if dest_real == src_real or src_real in dest_real.parents:
            raise HTTPException(400, "No se puede copiar una carpeta dentro de sí misma.")

    final = dest_dir / unique_copy_name(dest_dir, src.name)
    try:
        if src.is_dir():
            shutil.copytree(src, final, symlinks=True)
        else:
            shutil.copy2(src, final, follow_symlinks=False)
    except shutil.Error as exc:
        raise HTTPException(500, f"No se pudo copiar todo el contenido: {exc}") from exc
    except OSError as exc:
        raise_os_error(exc, "copiar")
    return final


def move_item(src: Path, final: Path) -> None:
    """Mueve/renombra (cruza sistemas de archivos si hace falta)."""
    try:
        if src.parent == final.parent:
            os.rename(src, final)
        else:
            shutil.move(str(src), str(final))
    except OSError as exc:
        raise_os_error(exc, "mover")


def search_tree(
    top: Path,
    query: str,
    *,
    hidden_names: Iterable[str] = (),
    limit: int = SEARCH_MAX_RESULTS,
) -> dict:
    """Busca por nombre (subcadena o comodines ``*``/``?``) bajo ``top``."""
    needle = (query or "").strip().lower()
    if not needle:
        raise HTTPException(400, "Escribe qué buscar.")
    use_glob = any(ch in needle for ch in "*?[")
    hidden = set(hidden_names)
    results: list[dict] = []
    scanned = 0
    truncated = False
    deadline = time.monotonic() + SEARCH_MAX_SECONDS

    def matches(name: str) -> bool:
        low = name.lower()
        return fnmatch.fnmatch(low, needle) if use_glob else needle in low

    stack = [top]
    while stack and not truncated:
        current = stack.pop()
        try:
            entries = sorted(os.scandir(current), key=lambda e: e.name.lower())
        except OSError:
            continue
        for entry in entries:
            if entry.name in hidden:
                continue
            scanned += 1
            if scanned > SEARCH_MAX_SCANNED or time.monotonic() > deadline:
                truncated = True
                break
            try:
                is_dir = entry.is_dir(follow_symlinks=False)
            except OSError:
                continue
            if is_dir:
                stack.append(Path(entry.path))
            if matches(entry.name):
                item = describe_entry(Path(entry.path))
                if item is None:
                    continue
                rel_parent = os.path.relpath(current, top)
                item["parent"] = "" if rel_parent == "." else rel_parent
                results.append(item)
                if len(results) >= limit:
                    truncated = True
                    break

    return {"query": query, "results": results, "truncated": truncated}
