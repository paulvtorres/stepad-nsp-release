#!/bin/bash
#
# BACKUP PRE-ACTUALIZACION
# Se ejecuta automaticamente antes de install.sh
# Si falla, advierte pero permite continuar (no bloquea la actualizacion)
#
set -uo pipefail

echo "==> Backup pre-actualizacion..."

# Verificar si hay destino de backup
if [ ! -d "/mnt/backup" ] && [ ! -d "/var/backups/stepad" ]; then
    echo "    AVISO: No hay destino de backup configurado."
    echo "    Configure un USB o backup local antes de actualizar."
    echo "    Continuando sin backup..."
    exit 0
fi

# Ejecutar backup via Python
cd /home/paulan/stepad-nsp
.venv/bin/python3 -c "
from backend.backups.services.backup_service import backup_service
result = backup_service.create_backup(reason=pre-update)
if result[success]:
    print( Backup pre-update completado: %s % result.get(repo, ))
else:
    print( AVISO: Backup pre-update fallo: %s % result.get(error, ))
    print( La actualizacion continuara de todas formas.)
" 2>&1

echo "    Backup pre-actualizacion finalizado."
