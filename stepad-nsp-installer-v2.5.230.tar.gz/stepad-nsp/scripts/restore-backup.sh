#!/bin/bash
#
# RESTAURAR BACKUP DE STEPAD NSP
# Uso: sudo bash restore-backup.sh [snapshot_id]
# Si no se especifica snapshot, restaura el mas reciente.
#
set -euo pipefail

SNAPSHOT="${1:-latest}"
REPO=""

echo "============================================"
echo "  STEPAD NSP - Restaurar Backup"
echo "============================================"
echo ""

# Detectar repositorio
for candidate in \
    "/mnt/backup/stepad/stepad-backup" \
    "/mnt/usb-*/stepad-backup" \
    "/var/backups/stepad"; do
    if [ -d "$candidate" ] || ls "$candidate"/config >/dev/null 2>&1; then
        REPO="$candidate"
        break
    fi
done

if [ -z "$REPO" ]; then
    echo "ERROR: No se encontro repositorio de backup."
    echo ""
    echo "Buscando en:"
    echo "  - /mnt/backup/stepad/"
    echo "  - /mnt/usb-*/"
    echo "  - /var/backups/stepad/"
    echo ""
    echo "Monte el USB y vuelva a intentar."
    exit 1
fi

echo "Repositorio: $REPO"
echo "Snapshot: $SNAPSHOT"
echo ""

# Listar snapshots disponibles
echo "=== Backups disponibles ==="
restic snapshots --repo "$REPO" 2>/dev/null || true
echo ""

# Confirmar
if [ "$SNAPSHOT" = "latest" ]; then
    echo "Se restaurara el backup MAS RECIENTE."
else
    echo "Se restaurara el snapshot: $SNAPSHOT"
fi
echo ""
read -p "¿Continuar? (S/N): " CONFIRM
case "$CONFIRM" in
    [sS]|[sS][iI]|[yY]) ;;
    *) echo "Cancelado."; exit 0 ;;
esac

echo ""
echo "=== Paso 1: Deteniendo servicios ==="
systemctl stop stepad-nsp.service 2>/dev/null || true
sleep 2

echo "=== Paso 2: Restaurando archivos ==="
restic restore "$SNAPSHOT" --repo "$REPO" --target / 2>&1
echo ""

echo "=== Paso 3: Restaurando base de datos ==="
# Buscar dump de PostgreSQL
if restic ls "$SNAPSHOT" /tmp/stepad-backup-db.sql.gz --repo "$REPO" >/dev/null 2>&1; then
    echo "Restaurando PostgreSQL..."
    restic cat "$SNAPSHOT" /tmp/stepad-backup-db.sql.gz --repo "$REPO" | \
        gzip -d | \
        psql -h 127.0.0.1 -U stepad_app -d stepad_nsp 2>&1
    echo "PostgreSQL restaurado."
else
    echo "AVISO: No se encontro dump de PostgreSQL en este backup."
fi
echo ""

echo "=== Paso 4: Recargando servicios ==="
systemctl daemon-reload
systemctl restart stepad-nsp.service
sleep 5

echo "=== Paso 5: Verificando ==="
if systemctl is-active stepad-nsp.service >/dev/null 2>&1; then
    echo "OK: NSP esta corriendo."
else
    echo "ERROR: NSP no pudo iniciar. Revise logs:"
    echo "  sudo journalctl -u stepad-nsp.service -n 30"
fi

echo ""
echo "============================================"
echo "  Restauracion completada"
echo "============================================"
