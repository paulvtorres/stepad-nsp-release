# Cambios en «Unidades de disco»

## Corrección crítica
- `backend/shares/models/network_share_volume.py`: faltaba la clase `GroupVolumeAccess`
  (tabla de la migración 0020). Sin ella `import backend.shares` fallaba con ImportError.

## Backend
- `backend/storage/services/fs_ops.py` (nuevo): listado con tamaños/fechas/cantidad de elementos,
  propiedades, tamaño recursivo, copiar, mover, buscar, errores claros (solo lectura, sin espacio…).
- `backend/storage/services/disk_service.py` (reescrito):
  - Solo explora unidades de datos montadas; nunca el disco del sistema. Bloquea rutas fuera de raíz y
    escapes por enlaces simbólicos. No permite borrar/renombrar la raíz de una unidad.
  - `mount` ya no confunde /dev/sda1 con /dev/sda10; `unmount` realmente desmonta.
  - Fechas en UTC con zona (antes salían corridas).
- `backend/api/v1/routes/disks.py`: nuevas rutas `info`, `search`, `rename`, `move`, `copy`,
  `download`, `upload`; `delete` acepta `recursive`.
- `web_file_service.py` / `share_web_files.py`: `info`, `search`, `copy` y listado enriquecido.
- Tests: `backend/tests/test_disk_explorer.py` (22 pruebas).

## Frontend
- `src/components/FileExplorer/` (nuevo): explorador único para discos y carpetas compartidas.
- `Shares.jsx` y `SharesExplorer.jsx` ahora lo usan (se eliminó el explorador básico).
- `services/api.js`: funciones nuevas de disco/archivos web.
