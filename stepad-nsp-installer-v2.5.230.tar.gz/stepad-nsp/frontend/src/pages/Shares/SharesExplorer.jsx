import { useEffect, useMemo, useState } from "react";

import { getWebFileUnits } from "../../services/api";
import FileExplorer from "../../components/FileExplorer/FileExplorer";
import { createWebAdapter } from "../../components/FileExplorer/adapters";


function resolveUnit(folderPath, units) {
    const path = String(folderPath || "").replace(/\/+$/, "");
    if (!path) return null;
    let best = null;
    let bestLen = -1;
    for (const unit of units || []) {
        const root = String(unit.path || unit.resolved || "").replace(/\/+$/, "");
        if (!root) continue;
        const prefix = path.startsWith(root + "/")
            ? path.slice(root.length + 1)
            : path === root
                ? ""
                : null;
        if (prefix === null) continue;
        if (root.length > bestLen) {
            bestLen = root.length;
            best = { unit, prefix };
        }
    }
    return best;
}


/**
 * Explorador de una carpeta compartida. Localiza la unidad que la contiene y
 * delega todo el trabajo en el explorador genérico (ver components/FileExplorer).
 */
export default function FolderExplorer({ folder, onClose }) {
    const [unitMatch, setUnitMatch] = useState(null);   // {unit, prefix}
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        let cancelled = false;
        getWebFileUnits()
            .then((res) => {
                if (cancelled) return;
                setUnitMatch(resolveUnit(folder.path, res?.units || []));
            })
            .catch((err) => {
                if (!cancelled) setError(err.message || String(err));
            })
            .finally(() => {
                if (!cancelled) setLoading(false);
            });
        return () => { cancelled = true; };
    }, [folder.path]);

    const baseCrumbs = useMemo(
        () => (unitMatch?.prefix || "").split("/").filter(Boolean),
        [unitMatch],
    );

    const adapter = useMemo(
        () => (unitMatch ? createWebAdapter(unitMatch.unit.path, baseCrumbs) : null),
        [unitMatch, baseCrumbs],
    );

    const access = !folder.shared
        ? { text: "Privada", cls: "private" }
        : (folder.groups || []).length === 0
            ? { text: "Compartida", cls: "public" }
            : { text: "Compartida", cls: "private" };

    return (
        <section className="sh-card sh-explorer">
            <div className="sh-wf-toolbar">
                <strong>📁 {folder.name}</strong>
                <span className={`sh-badge ${access.cls}`}>{access.text}</span>
                {folder.unc_path && (
                    <code className="sh-inline-code">{folder.unc_path}</code>
                )}
            </div>

            {loading && !unitMatch ? (
                <p className="sh-loading">Localizando unidad…</p>
            ) : !unitMatch ? (
                <p className="sh-error">
                    {error || "No se encontró una unidad montada para esta carpeta."}
                </p>
            ) : (
                <FileExplorer
                    key={`${adapter.key}:${baseCrumbs.join("/")}`}
                    adapter={adapter}
                    baseCrumbs={baseCrumbs}
                    rootLabel={folder.name}
                    exitLabel="← Volver a carpetas"
                    onExit={onClose}
                />
            )}
        </section>
    );
}
