import { useState, useEffect } from "react";
import { getToken } from "../../auth/authStorage";

const API_URL = import.meta.env.VITE_API_URL || "/api/v1";

export default function NetworkUnitsCard({ onExplore }) {
  const [units, setUnits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ name: "", host: "", share: "", letter: "", user: "", password: "" });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [scannedShares, setScannedShares] = useState(null);
  const [browseShare, setBrowseShare] = useState(null);
  const [browsePath, setBrowsePath] = useState("");
  const [browseFolders, setBrowseFolders] = useState(null);
  const [browseBusy, setBrowseBusy] = useState(false);

  function resetBrowse() {
    setBrowseShare(null);
    setBrowsePath("");
    setBrowseFolders(null);
  }

  async function load() {
    try {
      const token = getToken();
      const res = await fetch(API_URL + "/shares/network-units", { headers: { Authorization: "Bearer " + token } });
      setUnits((await res.json()).units || []);
    } catch (e) { setError(e.message); }
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function handleTestNoAuth() {
    setBusy(true); setError(null); setTestResult(null);
    try {
      const token = getToken();
      const res = await fetch(API_URL + "/shares/network/test?host=" + encodeURIComponent(form.host) + "&share=" + encodeURIComponent(form.share) + "&user=&password=", { headers: { Authorization: "Bearer " + token } });
      const data = await res.json();
      if (data.success) {
        setTestResult({ success: true, message: "Conexion exitosa sin credenciales" });
        const res2 = await fetch(API_URL + "/shares/network/list-shares?host=" + encodeURIComponent(form.host) + "&user=&password=", { headers: { Authorization: "Bearer " + token } });
        const shares = (await res2.json()).shares || [];
        setScannedShares(shares.filter(function(s) { return s.type !== "Auth" && !s.name.startsWith("__"); }));
        resetBrowse();
        setStep(3);
      } else {
        setStep(2);
      }
    } catch (e) { setStep(2); }
    setBusy(false);
  }

  async function handleTestWithAuth() {
    setBusy(true); setError(null); setTestResult(null);
    try {
      const token = getToken();
      var url = API_URL + "/shares/network/test?host=" + encodeURIComponent(form.host) + "&share=" + encodeURIComponent(form.share) + "&user=" + encodeURIComponent(form.user) + "&password=" + encodeURIComponent(form.password);
      const res = await fetch(url, { headers: { Authorization: "Bearer " + token } });
      const data = await res.json();
      if (data.success) {
        var url2 = API_URL + "/shares/network/list-shares?host=" + encodeURIComponent(form.host) + "&user=" + encodeURIComponent(form.user) + "&password=" + encodeURIComponent(form.password);
        const res2 = await fetch(url2, { headers: { Authorization: "Bearer " + token } });
        const shares = (await res2.json()).shares || [];
        setScannedShares(shares.filter(function(s) { return s.type !== "Auth" && !s.name.startsWith("__"); }));
        setTestResult({ success: true, message: "Conexion exitosa. " + shares.length + " shares encontrados." });
        resetBrowse();
        setStep(3);
      } else {
        setError("Credenciales incorrectas. Verifique usuario y contrasena.");
      }
    } catch (e) { setError(e.message); }
    setBusy(false);
  }

  async function fetchBrowse(shareName, newPath) {
    setBrowseBusy(true); setError(null);
    try {
      const token = getToken();
      const url = API_URL + "/shares/network/browse?host=" + encodeURIComponent(form.host) + "&share=" + encodeURIComponent(shareName) + "&path=" + encodeURIComponent(newPath) + "&user=" + encodeURIComponent(form.user) + "&password=" + encodeURIComponent(form.password);
      const res = await fetch(url, { headers: { Authorization: "Bearer " + token } });
      const data = await res.json();
      setBrowsePath(newPath);
      setBrowseFolders((data.items || []).filter(function(i) { return i.type === "dir"; }));
    } catch (e) { setError(e.message); setBrowseFolders(null); }
    setBrowseBusy(false);
  }

  function handleBrowseShare(shareName) {
    setForm(Object.assign({}, form, { share: shareName }));
    setBrowseShare(shareName);
    fetchBrowse(shareName, "");
  }

  function enterFolder(folderName) {
    if (!browseShare) return;
    fetchBrowse(browseShare, browsePath === "" ? folderName : browsePath + "/" + folderName);
  }

  function goUp() {
    if (!browsePath) return;
    const parts = browsePath.split("/");
    parts.pop();
    fetchBrowse(browseShare, parts.length ? parts.join("/") : "");
  }

  function useThisFolder() {
    if (!browseShare) return;
    setForm(Object.assign({}, form, { share: browsePath ? browseShare + "/" + browsePath : browseShare }));
  }

  async function handleCreate(e) {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const token = getToken();
      const res = await fetch(API_URL + "/shares/network-units", {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
        body: JSON.stringify({ name: form.name || (form.host + " " + form.share), host: form.host, share: form.share, letter: form.letter, user: form.user, password: form.password }),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.detail || "Error " + res.status); }
      setStep(0); setForm({ name: "", host: "", share: "", letter: "", user: "", password: "" });
      setScannedShares(null); setTestResult(null); resetBrowse();
      await load();
    } catch (e) { setError(e.message); }
    setBusy(false);
  }

  function handleReset() { setStep(0); setForm({ name: "", host: "", share: "", letter: "", user: "", password: "" }); setError(null); setTestResult(null); setScannedShares(null); resetBrowse(); }

  async function handleDelete(id) {
    if (!confirm("Eliminar esta unidad de red?")) return;
    setBusy(true);
    try { const token = getToken(); await fetch(API_URL + "/shares/network-units/" + id, { method: "DELETE", headers: { Authorization: "Bearer " + token } }); await load(); } catch (e) { setError(e.message); }
    setBusy(false);
  }

  return (
    <div className="sh-unit-card">
      <div className="sh-unit-card-head">
        <span className="sh-unit-icon">&#127760;</span>
        <div>
          <strong>Unidades de Red</strong>
          <p className="sh-muted" style={{margin:0,fontSize:"0.78rem"}}>Montar shares SMB como unidades locales para respaldos</p>
        </div>
        {step === 0 && <button type="button" className="sh-btn sh-btn-sm primary" onClick={function() { setStep(1); }}>+ Conectar unidad</button>}
        {step > 0 && <button type="button" className="sh-btn sh-btn-sm" onClick={handleReset}>Cancelar</button>}
      </div>

      {error && <p className="sh-banner warn">{error}</p>}

      {step === 1 && (
        <div className="sh-unit-step">
          <p className="sh-muted" style={{fontSize:"0.82rem",marginBottom:6}}>Ingrese la IP o nombre del equipo en la red:</p>
          <div className="sh-unit-form-row">
            <label><span>IP / Host</span><input value={form.host} onChange={function(e) { setForm(Object.assign({}, form, { host: e.target.value })); }} placeholder="192.168.1.59" required /></label>
          </div>
          <button type="button" className="sh-btn primary" onClick={handleTestNoAuth} disabled={busy || !form.host}>{busy ? "Conectando..." : "Conectar"}</button>
        </div>
      )}

      {step === 2 && (
        <div className="sh-unit-step">
          <p className="sh-muted" style={{fontSize:"0.82rem",marginBottom:6}}>El share requiere autenticacion. Ingrese credenciales:</p>
          <div className="sh-unit-form-row">
            <label><span>Usuario</span><input value={form.user} onChange={function(e) { setForm(Object.assign({}, form, { user: e.target.value })); }} placeholder="usuario" required /></label>
            <label><span>Contrasena</span><input type="password" value={form.password} onChange={function(e) { setForm(Object.assign({}, form, { password: e.target.value })); }} required /></label>
          </div>
          <button type="button" className="sh-btn primary" onClick={handleTestWithAuth} disabled={busy || !form.user}>{busy ? "Probando..." : "Probar conexion"}</button>
        </div>
      )}

      {step === 3 && (
        <div className="sh-unit-step">
          <p className="sh-muted" style={{fontSize:"0.82rem",marginBottom:6}}>Conexion verificada. Seleccione el share y navegue hasta la subcarpeta:</p>
          {scannedShares && scannedShares.length > 0 && (
            <div style={{marginBottom:8}}>
              <span className="sh-muted" style={{fontSize:"0.78rem"}}>Shares disponibles: </span>
              {scannedShares.map(function(s) {
                const active = browseShare === s.name;
                return <span key={s.name} className="sh-badge" style={{marginLeft:4,cursor:"pointer",background:active ? "rgba(34,197,94,0.2)" : "rgba(59,130,246,0.15)",border:"1px solid " + (active ? "rgba(34,197,94,0.5)" : "rgba(59,130,246,0.3)"),color: active ? "#86efac" : "#93c5fd",padding:"2px 8px",borderRadius:4,fontSize:"0.78rem"}} onClick={function() { handleBrowseShare(s.name); }}>{s.name}</span>;
              })}
            </div>
          )}

          {browseShare && (
            <div className="sh-unit-browse" style={{margin:"4px 0 8px"}}>
              <div className="sh-unit-browse-bar">
                <code>//{form.host}/{browsePath ? browseShare + "/" + browsePath : browseShare}</code>
                {browsePath && <button type="button" className="sh-btn sh-btn-sm" onClick={goUp} disabled={browseBusy}>↑ Subir</button>}
              </div>
              {browseBusy ? (
                <p className="sh-muted" style={{fontSize:"0.8rem"}}>Cargando carpetas...</p>
              ) : browseFolders && browseFolders.length > 0 ? (
                <div className="sh-unit-folder-list">
                  {browseFolders.map(function(f) {
                    return <div key={f.name} className="sh-unit-folder" onClick={function() { enterFolder(f.name); }}>📁 {f.name}</div>;
                  })}
                </div>
              ) : browseFolders ? (
                <p className="sh-muted" style={{fontSize:"0.8rem"}}>Esta carpeta no contiene subcarpetas.</p>
              ) : null}
              <button type="button" className="sh-btn sh-btn-sm primary" onClick={useThisFolder} style={{marginTop:6}} disabled={!browseShare}>Usar esta carpeta como unidad</button>
            </div>
          )}

          <form onSubmit={handleCreate}>
            <div className="sh-unit-form-row">
              <label><span>Nombre</span><input value={form.name} onChange={function(e) { setForm(Object.assign({}, form, { name: e.target.value })); }} placeholder={form.host + " " + form.share} /></label>
              <label><span>Letra</span><input value={form.letter} onChange={function(e) { setForm(Object.assign({}, form, { letter: e.target.value.toUpperCase() })); }} maxLength={1} style={{width:50,textAlign:"center"}} required /></label>
            </div>
            <p className="sh-muted" style={{fontSize:"0.78rem",marginBottom:6}}>Se montara: //{form.host}/{form.share}</p>
            <button type="submit" className="sh-btn primary" disabled={busy || !form.share}>{busy ? "Creando..." : "Crear unidad"}</button>
          </form>
        </div>
      )}

      {units.length > 0 && (
        <div className="sh-unit-list">
          {units.map(function(u) {
            return (
              <div key={u.id} className={"sh-unit-item" + (u.mounted ? " mounted" : "")}>
                <span className="sh-unit-letter">{u.letter}:</span>
                <div className="sh-unit-info">
                  <strong>{u.name}</strong>
                  <span className="sh-muted" style={{fontSize:"0.78rem"}}>//{u.host}/{u.share}</span>
                  {u.mounted ? <span className="sh-badge green">Montada</span> : <span className="sh-badge">Sin montar</span>}
                </div>
                {u.mounted && (
                  <button type="button" className="sh-btn sh-btn-sm" onClick={function() { onExplore && onExplore(u); }} disabled={busy}>Explorar contenido</button>
                )}
                <button type="button" className="sh-btn sh-btn-sm danger" onClick={function() { handleDelete(u.id); }} disabled={busy}>Eliminar</button>
              </div>
            );
          })}
        </div>
      )}

      {units.length === 0 && step === 0 && !loading && (
        <p className="sh-muted" style={{fontSize:"0.85rem",padding:"8px 0"}}>No hay unidades de red configuradas.</p>
      )}

      <style dangerouslySetInnerHTML={{__html: "\n.sh-unit-card{border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:12px;margin-bottom:12px}\n.sh-unit-card-head{display:flex;align-items:center;gap:10px}\n.sh-unit-card-head .sh-btn{margin-left:auto}\n.sh-unit-icon{font-size:1.5rem}\n.sh-unit-step{margin:12px 0;padding:10px;border-radius:6px;border:1px solid rgba(255,255,255,0.1)}\n.sh-unit-form-row{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:8px}\n.sh-unit-form-row label{display:flex;flex-direction:column;font-size:0.8rem;min-width:120px}\n.sh-unit-form-row input{margin-top:2px}\n.sh-unit-list{margin-top:8px}\n.sh-unit-item{display:flex;align-items:center;gap:10px;padding:8px;border-radius:6px;border:1px solid rgba(255,255,255,0.05);margin-bottom:4px}\n.sh-unit-item.mounted{border-color:rgba(34,197,94,0.3);background:rgba(34,197,94,0.03)}\n.sh-unit-letter{font-weight:700;font-size:1.1rem;min-width:30px}\n.sh-unit-info{flex:1;display:flex;flex-direction:column;gap:2px}\n.sh-unit-browse{border:1px solid rgba(255,255,255,0.12);border-radius:6px;padding:8px;background:rgba(255,255,255,0.02)}\n.sh-unit-browse-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;font-size:0.75rem;color:#93c5fd;word-break:break-all}\n.sh-unit-folder-list{max-height:220px;overflow-y:auto;border:1px solid rgba(255,255,255,0.06);border-radius:4px;padding:2px}\n.sh-unit-folder{padding:3px 6px;border-radius:3px;cursor:pointer;font-size:0.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.sh-unit-folder:hover{background:rgba(255,255,255,0.06)}"}} />
    </div>
  );
}