import { useState, useEffect, useCallback } from "react";
import {
    getLoadBalancingStatus,
    getLoadBalancingInterfaces,
    configureLoadBalancing,
} from "../../services/api";
import "./load-balancing.css";

export default function LoadBalancing() {
    const [status, setStatus] = useState(null);
    const [interfaces, setInterfaces] = useState([]);
    const [loading, setLoading] = useState(true);
    const [configuring, setConfiguring] = useState(false);
    const [feedback, setFeedback] = useState(null);
    const [mode, setMode] = useState("ecmp");

    const load = useCallback(async () => {
        try {
            const [s, ifaces] = await Promise.all([
                getLoadBalancingStatus(),
                getLoadBalancingInterfaces(),
            ]);
            setStatus(s);
            setInterfaces(ifaces?.interfaces || []);
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { load(); }, [load]);

    async function handleConfigure() {
        setConfiguring(true);
        setFeedback({ type: "info", msg: "Configurando balanceo..." });
        try {
            const result = await configureLoadBalancing({
                enabled: true,
                mode,
                interfaces: interfaces.map((i) => ({
                    name: i.name,
                    gateway: i.gateway,
                })),
            });
            if (result?.success) {
                setFeedback({ type: "success", msg: "Balanceo configurado: " + (result.mode || mode) });
                await load();
            } else {
                setFeedback({ type: "error", msg: "Fallo: " + (result?.error || result?.message || "Error") });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setConfiguring(false);
        }
    }

    async function handleDisable() {
        setConfiguring(true);
        try {
            const result = await configureLoadBalancing({ enabled: false });
            if (result?.success) {
                setFeedback({ type: "success", msg: "Balanceo desactivado." });
                await load();
            }
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setConfiguring(false);
        }
    }

    if (loading) return <div className="lb-page"><div className="lb-empty">Cargando...</div></div>;

    const wanInterfaces = interfaces.filter((i) => i.name && !i.name.startsWith("tailscale") && !i.name.startsWith("wg"));
    const canBalance = wanInterfaces.length >= 2;

    return (
        <div className="lb-page">
            <h1>Balanceo de Carga WAN</h1>
            <p className="lb-subtitle">
                Distribuye el tráfico entre múltiples conexiones a Internet para
                mayor ancho de banda y redundancia.
            </p>

            {feedback && (
                <div className={`lb-feedback ${feedback.type}`}>
                    {feedback.msg}
                    <button className="lb-btn" style={{ marginLeft: 12, padding: "4px 10px" }}
                        onClick={() => setFeedback(null)}>×</button>
                </div>
            )}

            <div className="lb-status-grid">
                <div className="lb-card">
                    <div className="label">Estado</div>
                    <div className={`value ${status?.healthy ? "ok" : "warn"}`}>
                        {status?.enabled ? (status?.healthy ? "Saludable" : "Degradado") : "Inactivo"}
                    </div>
                </div>
                <div className="lb-card">
                    <div className="label">WANs activas</div>
                    <div className="value">{status?.online_count || 0} / {status?.total_count || 0}</div>
                </div>
                <div className="lb-card">
                    <div className="label">Modo</div>
                    <div className="value">{status?.enabled ? (status?.mode || "ecmp") : "N/A"}</div>
                </div>
            </div>

            <div className="lb-section">
                <h2>Interfaces WAN</h2>
                {wanInterfaces.length === 0 ? (
                    <div className="lb-empty">
                        No hay interfaces WAN configuradas. Configure al menos 2 en Red → Interfaces.
                    </div>
                ) : (
                    wanInterfaces.map((iface) => (
                        <div key={iface.name} className="lb-iface-row">
                            <div className="lb-iface-info">
                                <div className="name">{iface.name}</div>
                                <div className="detail">{iface.ipv4 || "Sin IP"} → {iface.gateway || "?"}</div>
                            </div>
                            <div className={`lb-dot ${iface.online ? "online" : "offline"}`} />
                        </div>
                    ))
                )}
            </div>

            {wanInterfaces.length >= 2 && (
                <div className="lb-section">
                    <h2>Configurar Balanceo</h2>
                    <div className="lb-form-row">
                        <label>Modo:</label>
                        <select value={mode} onChange={(e) => setMode(e.target.value)}>
                            <option value="ecmp">ECMP (distribuir tráfico)</option>
                            <option value="failover">Failover (primaria + backup)</option>
                        </select>
                    </div>
                    <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
                        <button className="lb-btn primary" onClick={handleConfigure} disabled={configuring}>
                            {configuring ? "Configurando..." : "Activar balanceo"}
                        </button>
                        {status?.enabled && (
                            <button className="lb-btn" onClick={handleDisable} disabled={configuring}>
                                Desactivar
                            </button>
                        )}
                    </div>
                </div>
            )}

            {wanInterfaces.length < 2 && (
                <div className="lb-section" style={{ background: "#fffbeb", borderColor: "#fde68a" }}>
                    <h2 style={{ color: "#92400e" }}>Se necesitan 2+ interfaces WAN</h2>
                    <p style={{ color: "#92400e", fontSize: "0.9rem", margin: 0 }}>
                        Para balanceo de carga, configure al menos 2 interfaces con rol WAN en
                        <strong> Red → Interfaces</strong>. Puede usar 2 adaptadores de red físicos
                        o combinar una conexión física con una VPN (WireGuard/Tailscale) como backup.
                    </p>
                </div>
            )}
        </div>
    );
}
