import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";

import { getShareBackups, getShareStatus, getWebFileList } from "../../services/api";
import { getToken } from "../../auth/authStorage";

import ShareBackupsPanel from "../Shares/SharesBackupsPanel";

import "../Shares/shares.css";

const _API_URL = import.meta.env.VITE_API_URL || "/api/v1";

async function fetchSilent(endpoint) {
    const token = getToken();
    const response = await fetch(`${_API_URL}${endpoint}`, {
        headers: {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
        },
    });
    if (!response.ok) throw new Error(`API Error ${response.status}`);
    return response.json();
}

function isErrorResult(result) {
    if (!result) return false;
    const r = String(result).toLowerCase();
    return r.includes("error") || r.includes("falló") || r.includes("fallo")
        || r.includes("fatal") || r.includes("no se pudo") || r.includes("abort")
        || r.includes("failed") || r.includes("cancelled");
}

function summarizeResult(result) {
    if (!result) return "";
    let text = String(result).trim();
    const m = text.match(/"message"\s*:\s*"([^"]+)"/);
    if (m) return m[1].slice(0, 300);
    if (text.startsWith("{")) return text.slice(0, 300);
    return text.length > 300 ? text.slice(0, 300) + "..." : text;
}

function formatWhen(iso) {
    if (!iso) return "";
    const ts = new Date(iso).getTime();
    if (!Number.isFinite(ts)) return "";
    return new Date(ts).toLocaleString("es-EC", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
    });
}

function elapsedSince(iso) {
    if (!iso) return "";
    const started = new Date(iso).getTime();
    if (!Number.isFinite(started)) return "";
    const minutes = Math.max(0, Math.round((Date.now() - started) / 60000));
    if (minutes < 1) return "hace instantes";
    if (minutes === 1) return "hace 1 min";
    return `hace ${minutes} min`;
}

function scheduleSummary(job) {
    if (job.schedule_mode === "on_change") return "respaldando al cambiar archivos";
    if (job.schedule_times && job.schedule_times.length > 0) {
        return `todos los días a las ${job.schedule_times.join(", ")}`;
    }
    return `todos los días ${String(job.schedule_hour).padStart(2, "0")}:${String(job.schedule_minute).padStart(2, "0")}`;
}

// Agrupa los respaldos por UNIDAD DE DESTINO (el disco donde se guardan).
// Ej: /mnt/stepad-share/unidad1/Respaldo -> {key, label}
function destGroup(path) {
    const p = String(path || "").replace(/\/+$/, "").split("/").filter(Boolean);
    if (p.length >= 3 && (p[0] === "mnt" || p[0] === "media")) {
        const key = "/" + p.slice(0, 3).join("/"); // /mnt/stepad-disk/sda1
        return { key, label: key };
    }
    if (p.length >= 2) {
        return { key: "/" + p.slice(0, 2).join("/"), label: "/" + p.slice(0, 2).join("/") };
    }
    return { key: (path || "respaldo"), label: (path || "respaldo") };
}

function unitFriendly(label) {
    // /mnt/stepad-disk/sda1 -> "sda1 · PATO interno"
    const parts = String(label || "").split("/").filter(Boolean);
    const name = parts.length ? parts[parts.length - 1] : label;
    if ((label || "").includes("/stepad-disk/")) return `${name} · Disco interno`;
    if ((label || "").includes("/stepad-share/")) return `${name} · Volumen compartido`;
    if ((label || "").includes("/usb-")) return `${name} · USB`;
    return name || label;
}

export default function Backups() {
    const [params] = useSearchParams();
    const anchorSource = params.get("source") || "";

    const [view, setView] = useState(() => (anchorSource ? "detail" : "list"));
    const [detailSource, setDetailSource] = useState(anchorSource || "");
    const detailSourceRef = useRef(anchorSource || "");
    useEffect(() => {
        detailSourceRef.current = detailSource;
    }, [detailSource]);

    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [loadError, setLoadError] = useState(null);

    const [status, setStatus] = useState(null);
    const [networkUnits, setNetworkUnits] = useState([]);
    const [subfolderSources, setSubfolderSources] = useState([]);

    useEffect(() => {
        let active = true;
        Promise.all([
            getShareStatus(),
            fetchSilent("/shares/network-units").catch(() => ({ units: [] })),
        ])
            .then(([s, nu]) => {
                if (!active) return;
                setStatus(s);
                setNetworkUnits(nu.units || []);
            })
            .catch((err) => {
                console.error(err);
            });
        return () => { active = false; };
    }, []);

    function reconcileView(currentView, dataSnapshot) {
        if (currentView !== "detail") return currentView;
        const source = detailSourceRef.current;
        if (!source) return currentView;
        const stillThere = ((dataSnapshot && dataSnapshot.jobs) || []).some(
            (job) => job.source_path === source
        );
        return stillThere ? currentView : "list";
    }

    function load() {
        return getShareBackups()
            .then((d) => {
                setData(d);
                setView((current) => reconcileView(current, d));
            })
            .catch((err) => setLoadError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(() => {
            getShareBackups()
                .then((d) => {
                    setData(d);
                    setView((current) => reconcileView(current, d));
                })
                .catch(() => {});
        }, 30000);
        return () => clearInterval(timer);
    }, []);

    const [progress, setProgress] = useState({});
    useEffect(() => {
        const jobs = (data?.jobs || []).filter((j) => j.running);
        if (jobs.length === 0) return undefined;
        const timer = setInterval(() => {
            for (const job of jobs) {
                fetchSilent(`/shares/backups/${job.id}/progress`)
                    .then((p) => setProgress((prev) => ({ ...prev, [job.id]: p })))
                    .catch(() => {});
            }
        }, 2000);
        return () => clearInterval(timer);
    }, [data?.jobs]);

    function progressPercent(p) {
        if (!p) return 0;
        if (typeof p.percent === "number") return Math.min(100, Math.max(0, p.percent));
        if (p.bytes_total > 0) return Math.min(100, Math.round(p.bytes_done / p.bytes_total * 100));
        if (p.files_total > 0) return Math.min(100, Math.round(p.files_done / p.files_total * 100));
        return 0;
    }

    function formatEta(seconds) {
        if (!Number.isFinite(seconds) || seconds < 0) return "";
        if (seconds < 60) return `~${Math.round(seconds)}s rest.`;
        const minutes = Math.round(seconds / 60);
        if (minutes < 60) return `~${minutes} min rest.`;
        const hours = Math.floor(minutes / 60);
        const rest = minutes % 60;
        return `~${hours}h ${rest}m rest.`;
    }

    const volumes = useMemo(() => (status?.volumes || []), [status]);
    const folders = useMemo(() => (status?.folders || []), [status]);

    // Subcarpetas de las carpetas compartidas (un nivel) para poder elegirlas
    // como origen de respaldo (ej. Compartida/XML).
    useEffect(() => {
        let cancelled = false;
        (async () => {
            const items = [];
            const sharedFolders = (folders || []).filter((fl) => fl.shared && fl.path);
            for (const fl of sharedFolders) {
                const volume = volumes.find((v) => v.id === fl.volume_id);
                if (!volume?.mountpoint) continue;
                const parts = fl.path.split("/").filter(Boolean);
                const prefix = parts[parts.length - 1] || "";
                try {
                    const listing = await getWebFileList(volume.mountpoint, prefix);
                    for (const dir of listing.directories || []) {
                        items.push({
                            path: [volume.mountpoint, prefix, dir.name].filter(Boolean).join("/"),
                            label: `${prefix}/${dir.name}`,
                            kind: fl.shared ? "Compartida" : "Privada",
                            isVolume: false,
                            volumeName: volume.name || "",
                        });
                    }
                } catch {
                    // Si una carpeta no se puede listar, se omite.
                }
            }
            if (!cancelled) setSubfolderSources(items);
        })();
        return () => { cancelled = true; };
    }, [volumes, folders]);

    // Orígenes candidatos: carpetas COMPARTIDAS (y subcarpetas), más las
    // unidades de red montadas. Las privadas y el destino no se ofrecen.
    const backupSources = useMemo(() => {
        const opts = [];
        for (const fl of folders) {
            if (!fl.path || !fl.shared) continue;
            if (fl.exists === false) continue;
            const volume = volumes.find((v) => v.id === fl.volume_id);
            const label = fl.name || fl.path;
            opts.push({
                path: fl.path,
                label,
                kind: "Compartida",
                isVolume: false,
                volumeName: volume?.name || "",
            });
        }
        for (const sub of subfolderSources) {
            if (sub.path !== anchorSource) opts.push(sub);
        }
        for (const nu of networkUnits) {
            if (!nu.mounted) continue;
            if (nu.available === false) continue;
            opts.push({
                path: nu.mount_point,
                label: nu.name || (nu.host + "/" + nu.share),
                kind: "Unidad de Red",
                isVolume: false,
                volumeName: nu.letter ? nu.letter + ":" : "",
            });
        }
        const seen = new Set();
        return opts.filter((o) => (seen.has(o.path) ? false : (seen.add(o.path), true)));
    }, [volumes, folders, anchorSource, subfolderSources, networkUnits]);

    // Destinos candidatos: carpeta privada «Respaldo» de cada unidad local.
    const destinationVaults = useMemo(() => (
        volumes
            .filter((v) => v.mountpoint)
            .map((v) => ({
                path: `${v.mountpoint}/Respaldo`,
                label: v.name || v.mountpoint,
            }))
    ), [volumes]);

    const openDetail = useCallback((source) => {
        setDetailSource(source);
        setView("detail");
    }, []);

    const goCreate = useCallback(() => {
        setDetailSource("");
        setView("detail");
    }, []);

    if (view === "detail") {
        return (
            <div className="sh-page">
                <div className="sh-bk-backbar">
                    <button type="button" className="sh-btn sh-btn-sm" onClick={() => setView("list")}>
                        ← Volver al listado
                    </button>
                </div>
                <ShareBackupsPanel
                    sources={backupSources}
                    anchorSource={detailSource || null}
                    destinationVaults={destinationVaults}
                    folders={folders}
                />
            </div>
        );
    }

    const jobs = data?.jobs || [];

    return (
        <div className="sh-page">
            <section className="sh-bk-overview">
                <header className="sh-bk-overview-head">
                    <div>
                        <p className="sh-eyebrow">Protección de datos</p>
                        <h2>Respaldo de datos</h2>
                        <p className="sh-lede">
                            Copias cifradas y versionadas de tus carpetas. Tocá un respaldo para administrarlo o
                            ejecutarlo.
                        </p>
                    </div>
                    {destinationVaults.length > 0 && (
                        <button type="button" className="sh-btn primary" onClick={goCreate}>
                            + Programar nuevo respaldo
                        </button>
                    )}
                </header>

                {data?.installed === false && (
                    <div className="sh-banner warn">
                        Falta restic en el servidor. Instala: <code>sudo apt-get install -y restic</code>
                    </div>
                )}
                {loading ? (
                    <p className="sh-loading">Cargando respaldos…</p>
                ) : loadError ? (
                    <div className="sh-banner error">No se pudo cargar la lista de respaldos: {loadError}</div>
                ) : jobs.length === 0 ? (
                    destinationVaults.length === 0 ? (
                        <div className="sh-bk-empty">
                            <p>
                                No existen particiones de tipo «Respaldo» todavía.
                                Las programaciones se crean junto con la partición
                                de respaldo, así que primero crea una partición con
                                finalidad «Respaldo» (Discos y particiones) y su
                                respaldo quedará listo ahí.
                            </p>
                            <p className="sh-muted" style={{ fontSize: "0.82rem", marginTop: 6 }}>
                                No hay nada que programar hasta que exista una
                                partición de respaldo.
                            </p>
                        </div>
                    ) : (
                        <div className="sh-bk-empty">
                            <p>
                                Hay una partición de respaldo lista, pero aún no
                                hay programaciones cargadas en ella. Creá el primer
                                respaldo eligiendo el origen a respaldar; el destino
                                ya queda ligado a la partición «Respaldo».
                            </p>
                            <button type="button" className="sh-btn primary" onClick={goCreate}>
                                Programar el primer respaldo
                            </button>
                        </div>
                    )
                ) : (
                    (() => {
                        const groups = new Map();
                        for (const job of jobs) {
                            const dest = destGroup(job.destination_path || job.repository_path);
                            if (!groups.has(dest.key)) groups.set(dest.key, { ...dest, jobs: [] });
                            groups.get(dest.key).jobs.push(job);
                        }
                        const ordered = [...groups.values()]
                            .sort((a, b) => a.label.localeCompare(b.label))
                            .map((g) => ({
                                ...g,
                                jobs: g.jobs.sort((x, y) =>
                                    (x.name || x.source_path).localeCompare(y.name || y.source_path)
                                ),
                            }));
                        return (
                            <div className="sh-bk-groups">
                                {ordered.map((group) => (
                                    <section key={group.key} className="sh-bk-group">
                                        <header className="sh-bk-group-head">
                                            <span className="sh-bk-group-tag">Unidad destino</span>
                                            <strong className="sh-bk-group-name">
                                                {unitFriendly(group.label)}
                                            </strong>
                                            <code className="sh-inline-code">{group.key} </code>
                                            <span className="sh-muted sh-bk-group-count">
                                                · {group.jobs.length} {group.jobs.length === 1 ? "respaldo" : "respaldos"}
                                            </span>
                                        </header>
                                        <div className="sh-bk-grid">
                                            {group.jobs.map((job) => (
                                                <article
                                                    key={job.id}
                                                    className="sh-bk-card"
                                                    onClick={() => openDetail(job.source_path)}
                                                    title="Administrar este respaldo"
                                                >
                                                    <div className="sh-bk-card-head">
                                                        <strong>{job.name || job.source_path.split("/").pop()}</strong>
                                                        <div className="sh-bk-card-badges">
                                                            <span className={`sh-badge ${job.enabled ? "green" : "readonly"}`}>
                                                                {job.enabled ? "programado" : "apagado"}
                                                            </span>
                                                            {job.running && (
                                                                <span
                                                                    className="sh-badge sh-badge-running"
                                                                    title="Respaldo en ejecución"
                                                                >
                                                                    🔄 Respaldando
                                                                    {job.running_since ? ` · ${elapsedSince(job.running_since)}` : "…"}
                                                                    {progress[job.id] && progressPercent(progress[job.id]) > 0
                                                                        ? ` · ${progressPercent(progress[job.id])}%`
                                                                        : ""}
                                                                    {progress[job.id] && progress[job.id].eta_seconds != null
                                                                        ? ` · ${formatEta(progress[job.id].eta_seconds)}`
                                                                        : ""}
                                                                </span>
                                                            )}
                                                            {job.failing && !job.running && (
                                                                <span
                                                                    className="sh-badge sh-badge-failing"
                                                                    title="Este respaldo lleva varios intentos fallidos seguidos"
                                                                >
                                                                    ⚠️ Fallando ({job.consecutive_failures})
                                                                </span>
                                                            )}
                                                            {job.source_exists === false && (
                                                                <span
                                                                    className="sh-badge sh-badge-failing"
                                                                    title={
                                                                        job.source_path
                                                                            ? "La carpeta origen ya no existe (la unidad no está montada)"
                                                                            : "Este respaldo aún no tiene origen: configuralo la primera vez (elegí qué carpeta respaldar)."
                                                                    }
                                                                >
                                                                    {job.source_path
                                                                        ? "⚠️ Origen no disponible"
                                                                        : "🆕 Falta elegir el origen"}
                                                                </span>
                                                            )}
                                                        </div>
                                                    </div>
                                                    <p className="sh-bk-card-line">
                                                        <span className="sh-muted">Origen:</span>{" "}
                                                        <code className="sh-inline-code">{job.source_path}</code>
                                                    </p>
                                                    <p className="sh-bk-card-line">
                                                        <span className="sh-muted">Destino:</span>{" "}
                                                        <code className="sh-inline-code">
                                                            {job.destination_path || job.repository_path || "(sin crear aún)"}
                                                        </code>
                                                    </p>
                                                    <p className="sh-muted sh-bk-card-schedule">
                                                        {scheduleSummary(job)} · conserva {job.retention_count} versiones
                                                    </p>
                                                    {job.last_result && (
                                                        <p className={"sh-bk-last " + (isErrorResult(job.last_result) ? "has-error" : "")}>
                                                            <span className="sh-bk-last-status">
                                                                {isErrorResult(job.last_result)
                                                                    ? "❌ Error"
                                                                    : (job.last_bytes === 0 ? "⏸ Sin cambios" : "✅ Respaldado")}
                                                            </span>
                                                            {job.last_backup_at && (
                                                                <span className="sh-bk-last-date">
                                                                    {" · "}{formatWhen(job.last_backup_at)}
                                                                </span>
                                                            )}
                                                            <span className={isErrorResult(job.last_result) ? "sh-bk-result-error" : "sh-muted"}>
                                                                {" "}{summarizeResult(job.last_result)}
                                                            </span>
                                                        </p>
                                                    )}
                                                    <div className="sh-bk-card-actions">
                                                        <button type="button" className="sh-btn sh-btn-sm primary" onClick={() => openDetail(job.source_path)}>
                                                            {job.source_path
                                                                ? "Administrar este respaldo"
                                                                : "Configurar origen (primera vez)"}
                                                        </button>
                                                    </div>
                                                </article>
                                            ))}
                                        </div>
                                    </section>
                                ))}
                            </div>
                        );
                    })()
                )}
            </section>
        </div>
    );
}