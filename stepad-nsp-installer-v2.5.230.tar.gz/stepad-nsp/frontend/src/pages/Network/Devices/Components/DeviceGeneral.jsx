import { useState } from "react";

import { useAuth } from "../../../../auth/useAuth";
import { updateDevice } from "../../../../services/api";


function DeviceGeneral({ device, onDeviceChange }) {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";

    const [busy, setBusy] = useState(false);
    const [error, setError] = useState(null);


    if (!device)
        return <p>Loading...</p>;


    async function handleClearReservation() {

        if (!window.confirm(
            `¿Quitar la IP reservada ${device.permanent_ip}?\n\n` +
            "El equipo dejará de tener una IP fija; volverá a tomarla del pool."
        )) {
            return;
        }

        setBusy(true);
        setError(null);

        try {
            const updated = await updateDevice(device.id, {
                permanent_ip: null,
                is_permanent: false,
            });

            if (onDeviceChange) {
                onDeviceChange(updated);
            }

        } catch (err) {
            setError(err.message || "No se pudo quitar la reserva.");
        } finally {
            setBusy(false);
        }

    }


    return (

        <div className="card">

            <h3>Información del dispositivo</h3>

            {error && <p style={{ color: "var(--danger)", fontSize: 13 }}>{error}</p>}

            <table>

                <tbody>

                    <tr>
                        <td>Dirección IP</td>
                        <td>{device.ip_address || "-"}</td>
                    </tr>


                    <tr>
                        <td>IP reservada</td>
                        <td>
                            {device.permanent_ip ? (
                                <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                                    <span style={{ color: "#86efac", fontWeight: 600 }}>
                                        {device.permanent_ip}
                                    </span>
                                    {isAdmin && (
                                        <button
                                            type="button"
                                            className="manage-button"
                                            style={{ fontSize: "0.72rem", padding: "1px 6px" }}
                                            onClick={handleClearReservation}
                                            disabled={busy}
                                            title="Quitar la reserva de IP"
                                        >
                                            Quitar
                                        </button>
                                    )}
                                </span>
                            ) : "Sin reservar"}
                        </td>
                    </tr>


                    <tr>
                        <td>MAC</td>
                        <td>{device.mac_address || "-"}</td>
                    </tr>


                    <tr>
                        <td>Interfaz</td>
                        <td>{device.interface || "-"}</td>
                    </tr>


                    <tr>
                        <td>Estado</td>
                        <td>{device.status || "-"}</td>
                    </tr>


                    <tr>
                        <td>Tipo</td>
                        <td>{device.device_type || "-"}</td>
                    </tr>


                    <tr>
                        <td>Nombre de equipo</td>
                        <td>{device.hostname || "-"}</td>
                    </tr>


                    <tr>
                        <td>Zona</td>
                        <td>{device.zone?.name || device.zone_name || "Sin asignar"}</td>
                    </tr>


                    <tr>
                        <td>Grupo</td>
                        <td>
                            {
                                device.groups && device.groups.length > 0
                                    ? device.groups.map((g) => g.name).join(", ")
                                    : "Sin asignar (usa el grupo por defecto)"
                            }
                        </td>
                    </tr>


                </tbody>

            </table>

        </div>

    );

}

export default DeviceGeneral;
