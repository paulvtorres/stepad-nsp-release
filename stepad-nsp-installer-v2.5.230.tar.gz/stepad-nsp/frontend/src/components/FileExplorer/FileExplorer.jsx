import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { formatDateTime } from "../../utils/datetime";
import {
    collectDropped,
    fileTypeLabel,
    formatBytes,
    iconFor,
    isDirItem,
    itemKey,
    previewKind,
    sortItems,
} from "./explorerUtils";

import "./fileExplorer.css";


const COLUMNS = [
    { key: "name", label: "Nombre" },
    { key: "modified", label: "Fecha de modificación", cls: "fx-col-date" },
    { key: "type", label: "Tipo", cls: "fx-col-type" },
    { key: "size", label: "Tamaño", cls: "fx-col-size" },
    { key: "items", label: "Contenido", cls: "fx-col-items" },
];

const NEW_FOLDER_NAME = "Nueva carpeta";


function fmtDate(value) {
    return formatDateTime(value, "—").replace(/:\d{2}$/, "");
}

function itemsLabel(count) {
    if (count == null) return "—";
    const text = count >= 5000 ? "5000+" : String(count);
    return `${text} ${count === 1 ? "elemento" : "elementos"}`;
}

function errMsg(err) {
    return (err && err.message) || String(err);
}


/**
 * Explorador de archivos con las funciones habituales del Explorador de
 * Windows: navegación (atrás/adelante/arriba/ruta), detalles de cada carpeta y
 * archivo, ordenar, selección múltiple, cortar/copiar/pegar, renombrar,
 * eliminar, propiedades, búsqueda, vista previa, subir/descargar, arrastrar y
 * soltar, menú contextual y atajos de teclado.
 *
 * Props:
 *  - adapter: ver adapters.js (list/info/search/mkdir/rename/move/copy/...)
 *  - baseCrumbs: carpeta inicial que actúa como raíz (no se puede subir más)
 *  - rootLabel: texto de la raíz en la barra de ruta
 *  - readOnly: fuerza modo solo lectura
 *
 * Usar `key={adapter.key}` en el padre para reiniciar al cambiar de unidad.
 */
export default function FileExplorer({
    adapter,
    baseCrumbs = [],
    rootLabel = "Unidad",
    readOnly: readOnlyProp = false,
    onExit = null,
    exitLabel = "← Volver",
    onShareFolder = null,
}) {
    const baseKey = baseCrumbs.join("/");

    const [crumbs, setCrumbs] = useState(baseCrumbs);
    const [history, setHistory] = useState({ back: [], forward: [] });
    const [listing, setListing] = useState(null);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);

    const [selected, setSelected] = useState(() => new Set());
    const [sort, setSort] = useState({ key: "name", dir: "asc" });
    const [view, setView] = useState("details");
    const [clipboard, setClipboard] = useState(null);
    const [menu, setMenu] = useState(null);
    const [renaming, setRenaming] = useState(null);
    const [creating, setCreating] = useState(null);
    const [confirmDel, setConfirmDel] = useState(null);
    const [propsDlg, setPropsDlg] = useState(null);
    const [preview, setPreview] = useState(null);
    const [searchText, setSearchText] = useState("");
    const [searchResults, setSearchResults] = useState(null);
    const [dropping, setDropping] = useState(false);
    const [dropFolder, setDropFolder] = useState(null);

    const [anchor, setAnchor] = useState(null);
    const [dragItems, setDragItems] = useState(null);
    const rootRef = useRef(null);
    const searchRef = useRef(null);
    const fileInputRef = useRef(null);
    const dirInputRef = useRef(null);

    const readOnly = readOnlyProp || Boolean(listing?.mount?.readonly);
    const locked = busy || loading;

    /* ------------------------------------------------------------------ */
    /* Datos                                                               */
    /* ------------------------------------------------------------------ */

    const rawItems = useMemo(() => {
        if (searchResults) return searchResults.results || [];
        if (!listing) return [];
        return listing.items || [
            ...(listing.directories || []),
            ...(listing.files || []),
        ];
    }, [listing, searchResults]);

    const items = useMemo(() => sortItems(rawItems, sort), [rawItems, sort]);

    const selectedItems = useMemo(
        () => items.filter((it) => selected.has(itemKey(it))),
        [items, selected],
    );

    const crumbsOf = useCallback(
        (item) => (item && item.parent ? [...crumbs, ...item.parent.split("/")] : crumbs),
        [crumbs],
    );

    const selectedSize = useMemo(
        () => selectedItems.reduce((acc, it) => acc + (isDirItem(it) ? 0 : it.size || 0), 0),
        [selectedItems],
    );

    /* ------------------------------------------------------------------ */
    /* Carga y navegación                                                  */
    /* ------------------------------------------------------------------ */

    useEffect(() => {
        let cancelled = false;
        adapter
            .list(baseCrumbs)
            .then((res) => { if (!cancelled) setListing(res); })
            .catch((err) => { if (!cancelled) setError(errMsg(err)); })
            .finally(() => { if (!cancelled) setLoading(false); });
        return () => { cancelled = true; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [adapter, baseKey]);

    useEffect(() => {
        if (!notice) return undefined;
        const timer = setTimeout(() => setNotice(null), 6000);
        return () => clearTimeout(timer);
    }, [notice]);

    const go = useCallback(async (target, { record = true, select = null } = {}) => {
        setLoading(true);
        setError(null);
        try {
            const res = await adapter.list(target);
            if (record) {
                setHistory((h) => ({ back: [...h.back, crumbs], forward: [] }));
            }
            setListing(res);
            setCrumbs(target);
            setSearchResults(null);
            setSelected(new Set(select ? [select] : []));
            setAnchor(null);
            setRenaming(null);
            setCreating(null);
        } catch (err) {
            setError(errMsg(err));
        } finally {
            setLoading(false);
        }
    }, [adapter, crumbs]);

    const refresh = useCallback(async (keepSelection = true, select = null) => {
        setError(null);
        try {
            const res = await adapter.list(crumbs);
            setListing(res);
            setSelected((prev) => {
                if (select) return new Set([select]);
                if (!keepSelection) return new Set();
                const names = new Set((res.items || []).map((i) => i.name));
                return new Set([...prev].filter((k) => names.has(k)));
            });
        } catch (err) {
            setError(errMsg(err));
        }
    }, [adapter, crumbs]);

    const canGoUp = crumbs.length > baseCrumbs.length;

    function goUp() {
        if (canGoUp) go(crumbs.slice(0, -1), { select: crumbs[crumbs.length - 1] });
    }

    function goBack() {
        if (!history.back.length) return;
        const target = history.back[history.back.length - 1];
        setHistory((h) => ({
            back: h.back.slice(0, -1),
            forward: [crumbs, ...h.forward],
        }));
        go(target, { record: false });
    }

    function goForward() {
        if (!history.forward.length) return;
        const [target, ...rest] = history.forward;
        setHistory((h) => ({ back: [...h.back, crumbs], forward: rest }));
        go(target, { record: false });
    }

    function openItem(item) {
        if (isDirItem(item)) {
            go([...crumbsOf(item), item.name]);
            return;
        }
        if (previewKind(item)) {
            openPreview(item);
        } else {
            downloadItems([item]);
        }
    }

    /* ------------------------------------------------------------------ */
    /* Selección                                                           */
    /* ------------------------------------------------------------------ */

    function selectItem(event, item, index) {
        const key = itemKey(item);
        if (event.shiftKey && anchor != null) {
            const [a, b] = [anchor, index].sort((x, y) => x - y);
            setSelected(new Set(items.slice(a, b + 1).map(itemKey)));
        } else if (event.ctrlKey || event.metaKey) {
            setSelected((prev) => {
                const next = new Set(prev);
                if (next.has(key)) next.delete(key); else next.add(key);
                return next;
            });
            setAnchor(index);
        } else {
            setSelected(new Set([key]));
            setAnchor(index);
        }
    }

    function moveSelection(delta, extend) {
        if (!items.length) return;
        const current = anchor != null
            ? anchor
            : items.findIndex((it) => selected.has(itemKey(it)));
        const next = Math.max(0, Math.min(items.length - 1, (current < 0 ? (delta > 0 ? -1 : items.length) : current) + delta));
        if (extend && anchor != null) {
            const [a, b] = [anchor, next].sort((x, y) => x - y);
            setSelected(new Set(items.slice(a, b + 1).map(itemKey)));
        } else {
            setSelected(new Set([itemKey(items[next])]));
            setAnchor(next);
        }
    }

    /* ------------------------------------------------------------------ */
    /* Operaciones                                                         */
    /* ------------------------------------------------------------------ */

    async function runBatch(list, doOne, { done, failed }) {
        setBusy(true);
        setError(null);
        setNotice(null);
        let ok = 0;
        const errors = [];
        for (const item of list) {
            try {
                await doOne(item);
                ok += 1;
            } catch (err) {
                errors.push(`«${item.name}»: ${errMsg(err)}`);
            }
        }
        await refresh();
        setBusy(false);
        if (ok) setNotice(done(ok));
        if (errors.length) setError(`${failed(errors.length)} ${errors.join(" · ")}`);
        return ok;
    }

    async function downloadItems(list) {
        const files = list.filter((it) => !isDirItem(it));
        if (!files.length) {
            setError("Solo se pueden descargar archivos; abre la carpeta para elegir archivos.");
            return;
        }
        setBusy(true);
        setError(null);
        try {
            for (const file of files) {
                const blob = await adapter.download(crumbsOf(file), file.name);
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = file.name;
                document.body.appendChild(a);
                a.click();
                a.remove();
                setTimeout(() => URL.revokeObjectURL(url), 4000);
            }
        } catch (err) {
            setError(errMsg(err));
        } finally {
            setBusy(false);
        }
    }

    async function doUpload(entries, targetCrumbs = crumbs) {
        if (!entries.length || readOnly) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const res = await adapter.upload(targetCrumbs, entries);
            await refresh();
            setNotice(res?.message || "Archivos subidos.");
            if (res?.failed?.length) {
                setError(res.failed.map((f) => `«${f.name}»: ${f.error}`).join(" · "));
            }
        } catch (err) {
            setError(errMsg(err));
        } finally {
            setBusy(false);
            if (fileInputRef.current) fileInputRef.current.value = "";
            if (dirInputRef.current) dirInputRef.current.value = "";
        }
    }

    function onPickFiles(fileList) {
        const entries = Array.from(fileList || []).map((file) => ({
            file,
            name: file.webkitRelativePath || file.name,
        }));
        doUpload(entries);
    }

    async function commitNewFolder() {
        const name = (creating?.draft || "").trim();
        setCreating(null);
        if (!name) return;
        setBusy(true);
        setError(null);
        try {
            await adapter.mkdir(crumbs, name);
            await refresh(false, name);
            setNotice(`Carpeta «${name}» creada.`);
        } catch (err) {
            setError(errMsg(err));
        } finally {
            setBusy(false);
        }
    }

    async function commitRename() {
        const target = renaming;
        setRenaming(null);
        const name = (target?.draft || "").trim();
        if (!target || !name || name === target.item.name) return;
        setBusy(true);
        setError(null);
        try {
            await adapter.rename(crumbsOf(target.item), target.item.name, name);
            if (searchResults) {
                setSearchResults(null);
            }
            await refresh(false, target.item.parent ? null : name);
            setNotice(`«${target.item.name}» renombrado a «${name}».`);
        } catch (err) {
            setError(errMsg(err));
        } finally {
            setBusy(false);
        }
    }

    function startRename(item = selectedItems[0]) {
        if (!item || readOnly) return;
        setRenaming({ item, draft: item.name });
    }

    function startNewFolder() {
        if (readOnly) return;
        setSearchResults(null);
        setCreating({ draft: NEW_FOLDER_NAME });
    }

    function copyToClipboard(mode, list = selectedItems) {
        if (!list.length) return;
        if (mode === "cut" && readOnly) return;
        setClipboard({
            mode,
            entries: list.map((it) => ({
                name: it.name,
                crumbs: crumbsOf(it),
                isDir: isDirItem(it),
            })),
        });
        setNotice(`${list.length} elemento(s) ${mode === "cut" ? "cortado(s)" : "copiado(s)"}.`);
    }

    async function paste(targetCrumbs = crumbs) {
        if (!clipboard || readOnly) return;
        const { mode, entries } = clipboard;
        const sameFolder = (c) => c.join("/") === targetCrumbs.join("/");
        const work = mode === "cut" ? entries.filter((e) => !sameFolder(e.crumbs)) : entries;
        if (!work.length) {
            setClipboard(null);
            return;
        }
        const ok = await runBatch(
            work,
            (e) => (mode === "cut"
                ? adapter.move(e.crumbs, e.name, targetCrumbs)
                : adapter.copy(e.crumbs, e.name, targetCrumbs)),
            {
                done: (n) => `${n} elemento(s) ${mode === "cut" ? "movido(s)" : "copiado(s)"}.`,
                failed: (n) => `${n} error(es):`,
            },
        );
        if (mode === "cut" && ok === work.length) setClipboard(null);
    }

    async function doDelete() {
        const list = confirmDel;
        setConfirmDel(null);
        if (!list || !list.length) return;
        await runBatch(
            list,
            (it) => adapter.remove(crumbsOf(it), it.name, isDirItem(it)),
            {
                done: (n) => `${n} elemento(s) eliminado(s).`,
                failed: (n) => `${n} error(es):`,
            },
        );
        setSelected(new Set());
    }

    async function moveOrCopyInto(list, folderCrumbs, copy) {
        const work = list.filter((it) => {
            const from = crumbsOf(it);
            if (!copy && from.join("/") === folderCrumbs.join("/")) return false;
            // No soltar una carpeta sobre sí misma.
            return !(isDirItem(it) && [...from, it.name].join("/") === folderCrumbs.join("/"));
        });
        if (!work.length) return;
        await runBatch(
            work,
            (it) => (copy
                ? adapter.copy(crumbsOf(it), it.name, folderCrumbs)
                : adapter.move(crumbsOf(it), it.name, folderCrumbs)),
            {
                done: (n) => `${n} elemento(s) ${copy ? "copiado(s)" : "movido(s)"}.`,
                failed: (n) => `${n} error(es):`,
            },
        );
    }

    async function openProperties(item = null) {
        const label = item ? item.name : (crumbs[crumbs.length - 1] || rootLabel);
        setPropsDlg({ label, loading: true, data: null, error: null });
        try {
            const data = item
                ? await adapter.info(crumbsOf(item), item.name)
                : await adapter.info(crumbs);
            setPropsDlg({ label, loading: false, data, error: null });
        } catch (err) {
            setPropsDlg({ label, loading: false, data: null, error: errMsg(err) });
        }
    }

    async function openPreview(item) {
        const kind = previewKind(item);
        if (!kind) return;
        setPreview({ item, kind: kind.kind, loading: true });
        try {
            const blob = await adapter.download(crumbsOf(item), item.name);
            if (kind.kind === "text") {
                const text = await blob.text();
                setPreview({ item, kind: "text", text, loading: false });
            } else {
                const typed = new Blob([blob], { type: kind.mime });
                setPreview({
                    item,
                    kind: kind.kind,
                    url: URL.createObjectURL(typed),
                    loading: false,
                });
            }
        } catch (err) {
            setPreview({ item, kind: kind.kind, loading: false, error: errMsg(err) });
        }
    }

    useEffect(() => {
        const url = preview?.url;
        return () => { if (url) URL.revokeObjectURL(url); };
    }, [preview?.url]);

    async function runSearch(event) {
        event?.preventDefault();
        const q = searchText.trim();
        if (!q) {
            setSearchResults(null);
            return;
        }
        setLoading(true);
        setError(null);
        try {
            const res = await adapter.search(crumbs, q);
            setSearchResults(res);
            setSelected(new Set());
            setAnchor(null);
        } catch (err) {
            setError(errMsg(err));
        } finally {
            setLoading(false);
        }
    }

    function closeSearch() {
        setSearchResults(null);
        setSearchText("");
    }

    function showInFolder(item) {
        go(crumbsOf(item), { select: item.name });
    }

    /* ------------------------------------------------------------------ */
    /* Menú contextual, teclado, arrastrar y soltar                        */
    /* ------------------------------------------------------------------ */

    useEffect(() => {
        if (!menu) return undefined;
        const close = () => setMenu(null);
        window.addEventListener("click", close);
        window.addEventListener("scroll", close, true);
        window.addEventListener("resize", close);
        return () => {
            window.removeEventListener("click", close);
            window.removeEventListener("scroll", close, true);
            window.removeEventListener("resize", close);
        };
    }, [menu]);

    function onContextMenu(event, item, index) {
        event.preventDefault();
        event.stopPropagation();
        if (item && !selected.has(itemKey(item))) {
            setSelected(new Set([itemKey(item)]));
            setAnchor(index);
        }
        setMenu({ x: event.clientX, y: event.clientY, onItem: Boolean(item) });
    }

    function onKeyDown(event) {
        const tag = event.target?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        const ctrl = event.ctrlKey || event.metaKey;
        if (event.key === "ArrowDown") { event.preventDefault(); moveSelection(1, event.shiftKey); }
        else if (event.key === "ArrowUp" && !event.altKey) { event.preventDefault(); moveSelection(-1, event.shiftKey); }
        else if (event.key === "ArrowUp" && event.altKey) { event.preventDefault(); goUp(); }
        else if (event.key === "ArrowLeft" && event.altKey) { event.preventDefault(); goBack(); }
        else if (event.key === "ArrowRight" && event.altKey) { event.preventDefault(); goForward(); }
        else if (event.key === "Backspace") { event.preventDefault(); goUp(); }
        else if (event.key === "Enter" && selectedItems.length === 1) { event.preventDefault(); openItem(selectedItems[0]); }
        else if (event.key === "F2") { event.preventDefault(); startRename(); }
        else if (event.key === "F5") { event.preventDefault(); refresh(); }
        else if (event.key === "Delete" && selectedItems.length && !readOnly) { event.preventDefault(); setConfirmDel(selectedItems); }
        else if (ctrl && event.key.toLowerCase() === "a") { event.preventDefault(); setSelected(new Set(items.map(itemKey))); }
        else if (ctrl && event.key.toLowerCase() === "c") { event.preventDefault(); copyToClipboard("copy"); }
        else if (ctrl && event.key.toLowerCase() === "x") { event.preventDefault(); copyToClipboard("cut"); }
        else if (ctrl && event.key.toLowerCase() === "v") { event.preventDefault(); paste(); }
        else if (ctrl && event.key.toLowerCase() === "f") { event.preventDefault(); searchRef.current?.focus(); }
        else if (event.key === "Escape") { setSelected(new Set()); setMenu(null); }
    }

    function onDragStartItem(event, item) {
        const key = itemKey(item);
        const list = selected.has(key) ? selectedItems : [item];
        setDragItems(list);
        event.dataTransfer.effectAllowed = "copyMove";
        event.dataTransfer.setData("text/plain", list.map((i) => i.name).join("\n"));
    }

    async function onDropFolder(event, folderCrumbs) {
        event.preventDefault();
        event.stopPropagation();
        setDropFolder(null);
        setDropping(false);
        if (readOnly || locked) return;
        if (dragItems) {
            const list = dragItems;
            setDragItems(null);
            await moveOrCopyInto(list, folderCrumbs, event.ctrlKey || event.altKey);
            return;
        }
        const entries = await collectDropped(event.dataTransfer);
        doUpload(entries, folderCrumbs);
    }

    async function onDropArea(event) {
        event.preventDefault();
        setDropping(false);
        if (dragItems) {
            setDragItems(null);
            return;
        }
        if (readOnly || locked) return;
        const entries = await collectDropped(event.dataTransfer);
        doUpload(entries);
    }

    /* ------------------------------------------------------------------ */
    /* Render                                                              */
    /* ------------------------------------------------------------------ */

    const usage = listing?.usage;
    const usedPct = usage && usage.total ? Math.min(100, Math.round((usage.used / usage.total) * 100)) : null;
    const summary = listing?.summary;

    function renderName(item) {
        const key = itemKey(item);
        if (renaming && itemKey(renaming.item) === key) {
            const dot = renaming.item.name.lastIndexOf(".");
            const end = !isDirItem(item) && dot > 0 ? dot : renaming.item.name.length;
            return (
                <input
                    className="fx-rename"
                    autoFocus
                    value={renaming.draft}
                    maxLength={255}
                    onFocus={(e) => e.target.setSelectionRange(0, end)}
                    onChange={(e) => setRenaming((r) => ({ ...r, draft: e.target.value }))}
                    onClick={(e) => e.stopPropagation()}
                    onDoubleClick={(e) => e.stopPropagation()}
                    onBlur={commitRename}
                    onKeyDown={(e) => {
                        e.stopPropagation();
                        if (e.key === "Enter") commitRename();
                        if (e.key === "Escape") setRenaming(null);
                    }}
                />
            );
        }
        return (
            <>
                <span className="fx-icon" aria-hidden="true">{iconFor(item)}</span>
                <span className="fx-name-text" title={item.name}>{item.name}</span>
                {item.symlink && <span className="fx-tag">enlace</span>}
                {searchResults && (
                    <span className="fx-where" title={item.parent || "(raíz)"}>
                        {" "}en /{item.parent || ""}
                    </span>
                )}
            </>
        );
    }

    function rowProps(item, index) {
        const key = itemKey(item);
        const dir = isDirItem(item);
        return {
            key,
            className: [
                "fx-row",
                selected.has(key) ? "selected" : "",
                clipboard?.mode === "cut"
                    && clipboard.entries.some((e) => e.name === item.name && e.crumbs.join("/") === crumbsOf(item).join("/"))
                    ? "cut" : "",
                dir && dropFolder === key ? "drop-target" : "",
            ].filter(Boolean).join(" "),
            draggable: !readOnly && !renaming,
            onClick: (e) => { e.stopPropagation(); selectItem(e, item, index); },
            onDoubleClick: () => openItem(item),
            onContextMenu: (e) => onContextMenu(e, item, index),
            onDragStart: (e) => onDragStartItem(e, item),
            onDragEnd: () => { setDragItems(null); setDropFolder(null); },
            onDragOver: dir && !readOnly ? (e) => { e.preventDefault(); e.stopPropagation(); if (dropFolder !== key) setDropFolder(key); } : undefined,
            onDragLeave: dir ? () => setDropFolder((cur) => (cur === key ? null : cur)) : undefined,
            onDrop: dir ? (e) => onDropFolder(e, [...crumbsOf(item), item.name]) : undefined,
        };
    }

    const toolbarDisabled = locked;
    const hasSel = selectedItems.length > 0;
    const single = selectedItems.length === 1;

    return (
        <div
            ref={rootRef}
            className={["fx", dropping ? "dropping" : ""].filter(Boolean).join(" ")}
            tabIndex={0}
            onKeyDown={onKeyDown}
            onClick={() => setSelected(new Set())}
            onContextMenu={(e) => onContextMenu(e, null, null)}
            onDragEnter={(e) => { if (!dragItems && !readOnly) { e.preventDefault(); setDropping(true); } }}
            onDragOver={(e) => { e.preventDefault(); }}
            onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setDropping(false); }}
            onDrop={onDropArea}
        >
            {dropping && <div className="fx-drop-hint">Suelta los archivos o carpetas para subirlos aquí</div>}

            {/* Barra de navegación */}
            <div className="fx-nav" onClick={(e) => e.stopPropagation()}>
                {onExit && (
                    <button type="button" className="fx-btn" onClick={onExit} disabled={busy}>{exitLabel}</button>
                )}
                <button type="button" className="fx-btn fx-icon-btn" title="Atrás (Alt+←)" disabled={toolbarDisabled || !history.back.length} onClick={goBack}>←</button>
                <button type="button" className="fx-btn fx-icon-btn" title="Adelante (Alt+→)" disabled={toolbarDisabled || !history.forward.length} onClick={goForward}>→</button>
                <button type="button" className="fx-btn fx-icon-btn" title="Subir un nivel (Alt+↑)" disabled={toolbarDisabled || !canGoUp} onClick={goUp}>↑</button>
                <button type="button" className="fx-btn fx-icon-btn" title="Actualizar (F5)" disabled={busy} onClick={() => refresh()}>⟳</button>

                <nav className="fx-crumbs" aria-label="Ruta actual">
                    <button
                        type="button"
                        className="fx-crumb"
                        disabled={locked}
                        onClick={() => go(baseCrumbs)}
                        onDragOver={(e) => { if (!readOnly) e.preventDefault(); }}
                        onDrop={(e) => onDropFolder(e, baseCrumbs)}
                    >
                        💽 {rootLabel}
                    </button>
                    {crumbs.slice(baseCrumbs.length).map((part, idx) => {
                        const target = crumbs.slice(0, baseCrumbs.length + idx + 1);
                        return (
                            <span key={`${part}-${idx}`} className="fx-crumb-wrap">
                                <span className="fx-sep">›</span>
                                <button
                                    type="button"
                                    className="fx-crumb"
                                    disabled={locked}
                                    onClick={() => go(target)}
                                    onDragOver={(e) => { if (!readOnly) e.preventDefault(); }}
                                    onDrop={(e) => onDropFolder(e, target)}
                                >
                                    {part}
                                </button>
                            </span>
                        );
                    })}
                </nav>

                <form className="fx-search" onSubmit={runSearch}>
                    <input
                        ref={searchRef}
                        type="search"
                        placeholder="Buscar en esta carpeta (Ctrl+F)"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                        onKeyDown={(e) => { if (e.key === "Escape") closeSearch(); }}
                    />
                    <button type="submit" className="fx-btn" disabled={locked || !searchText.trim()}>Buscar</button>
                </form>
            </div>

            {/* Barra de comandos */}
            <div className="fx-toolbar" onClick={(e) => e.stopPropagation()}>
                <input ref={fileInputRef} type="file" multiple hidden onChange={(e) => onPickFiles(e.target.files)} />
                <input ref={dirInputRef} type="file" multiple hidden {...{ webkitdirectory: "", directory: "" }} onChange={(e) => onPickFiles(e.target.files)} />

                <button type="button" className="fx-btn primary" disabled={toolbarDisabled || readOnly} onClick={startNewFolder}>＋ Nueva carpeta</button>
                <button type="button" className="fx-btn" disabled={toolbarDisabled || readOnly} onClick={() => fileInputRef.current?.click()}>Subir archivos</button>
                <button type="button" className="fx-btn" disabled={toolbarDisabled || readOnly} onClick={() => dirInputRef.current?.click()}>Subir carpeta</button>
                <span className="fx-divider" />
                <button type="button" className="fx-btn" disabled={toolbarDisabled || !hasSel || readOnly} onClick={() => copyToClipboard("cut")} title="Cortar (Ctrl+X)">Cortar</button>
                <button type="button" className="fx-btn" disabled={toolbarDisabled || !hasSel} onClick={() => copyToClipboard("copy")} title="Copiar (Ctrl+C)">Copiar</button>
                <button type="button" className="fx-btn" disabled={toolbarDisabled || !clipboard || readOnly} onClick={() => paste()} title="Pegar (Ctrl+V)">Pegar</button>
                <button type="button" className="fx-btn" disabled={toolbarDisabled || !single || readOnly} onClick={() => startRename()} title="Cambiar nombre (F2)">Renombrar</button>
                <button type="button" className="fx-btn danger" disabled={toolbarDisabled || !hasSel || readOnly} onClick={() => setConfirmDel(selectedItems)} title="Eliminar (Supr)">Eliminar</button>
                <span className="fx-divider" />
                <button type="button" className="fx-btn" disabled={toolbarDisabled || !hasSel} onClick={() => downloadItems(selectedItems)}>Descargar</button>
                {onShareFolder && selectedItems.length === 1 && isDirItem(selectedItems[0]) && (
                    <button type="button" className="fx-btn primary" disabled={toolbarDisabled || readOnly} onClick={() => onShareFolder(selectedItems[0], crumbs)}>Compartir</button>
                )}
                <button type="button" className="fx-btn" disabled={toolbarDisabled} onClick={() => openProperties(single ? selectedItems[0] : null)}>
                    Propiedades
                </button>
                <span className="fx-spacer" />
                {readOnly && <span className="fx-badge warn">Solo lectura</span>}
                <div className="fx-viewtoggle" role="group" aria-label="Vista">
                    <button type="button" className={view === "details" ? "active" : ""} onClick={() => setView("details")} title="Detalles">☰</button>
                    <button type="button" className={view === "icons" ? "active" : ""} onClick={() => setView("icons")} title="Iconos grandes">▦</button>
                </div>
            </div>

            {notice && <p className="fx-notice" role="status">{notice}</p>}
            {error && (
                <p className="fx-error" role="alert">
                    {error}
                    <button type="button" className="fx-x" onClick={() => setError(null)} aria-label="Cerrar">×</button>
                </p>
            )}

            {searchResults && (
                <div className="fx-searchbar" onClick={(e) => e.stopPropagation()}>
                    Resultados de «{searchResults.query}»: {searchResults.results.length}
                    {searchResults.truncated ? " (búsqueda limitada; afina el texto)" : ""}
                    <button type="button" className="fx-btn" onClick={closeSearch}>Cerrar búsqueda</button>
                </div>
            )}

            {/* Lista */}
            <div className="fx-list" role="grid" aria-busy={loading}>
                {loading && !listing ? (
                    <p className="fx-empty">Cargando…</p>
                ) : view === "details" ? (
                    <table className="fx-table">
                        <thead>
                            <tr>
                                {COLUMNS.map((col) => (
                                    <th
                                        key={col.key}
                                        className={col.cls}
                                        aria-sort={sort.key === col.key ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}
                                    >
                                        <button
                                            type="button"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                setSort((s) => ({
                                                    key: col.key,
                                                    dir: s.key === col.key && s.dir === "asc" ? "desc" : "asc",
                                                }));
                                            }}
                                        >
                                            {col.label}
                                            {sort.key === col.key ? (sort.dir === "asc" ? " ▲" : " ▼") : ""}
                                        </button>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {creating && (
                                <tr className="fx-row selected" onClick={(e) => e.stopPropagation()}>
                                    <td colSpan={COLUMNS.length}>
                                        <span className="fx-icon">📁</span>
                                        <input
                                            className="fx-rename"
                                            autoFocus
                                            value={creating.draft}
                                            maxLength={255}
                                            onFocus={(e) => e.target.select()}
                                            onChange={(e) => setCreating({ draft: e.target.value })}
                                            onBlur={commitNewFolder}
                                            onKeyDown={(e) => {
                                                e.stopPropagation();
                                                if (e.key === "Enter") commitNewFolder();
                                                if (e.key === "Escape") setCreating(null);
                                            }}
                                        />
                                    </td>
                                </tr>
                            )}
                            {items.map((item, index) => {
                                const { key, ...rp } = rowProps(item, index);
                                const dir = isDirItem(item);
                                return (
                                    <tr key={key} {...rp} aria-selected={selected.has(key)}>
                                        <td className="fx-col-name">{renderName(item)}</td>
                                        <td className="fx-col-date">{fmtDate(item.modified)}</td>
                                        <td className="fx-col-type">{fileTypeLabel(item)}</td>
                                        <td className="fx-col-size">{dir ? "" : formatBytes(item.size)}</td>
                                        <td className="fx-col-items">{dir ? itemsLabel(item.item_count) : ""}</td>
                                    </tr>
                                );
                            })}
                            {!items.length && !creating && (
                                <tr>
                                    <td colSpan={COLUMNS.length} className="fx-empty">
                                        {searchResults
                                            ? "No se encontraron coincidencias."
                                            : "Esta carpeta está vacía."}
                                        {!readOnly && !searchResults && " Arrastra archivos aquí o usa «Subir archivos»."}
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                ) : (
                    <div className="fx-grid">
                        {creating && (
                            <div className="fx-tile selected" onClick={(e) => e.stopPropagation()}>
                                <span className="fx-tile-icon">📁</span>
                                <input
                                    className="fx-rename"
                                    autoFocus
                                    value={creating.draft}
                                    onFocus={(e) => e.target.select()}
                                    onChange={(e) => setCreating({ draft: e.target.value })}
                                    onBlur={commitNewFolder}
                                    onKeyDown={(e) => {
                                        e.stopPropagation();
                                        if (e.key === "Enter") commitNewFolder();
                                        if (e.key === "Escape") setCreating(null);
                                    }}
                                />
                            </div>
                        )}
                        {items.map((item, index) => {
                            const { key, className, ...rp } = rowProps(item, index);
                            const dir = isDirItem(item);
                            return (
                                <div key={key} className={className.replace("fx-row", "fx-tile")} {...rp}>
                                    <span className="fx-tile-icon" aria-hidden="true">{iconFor(item)}</span>
                                    {renaming && itemKey(renaming.item) === key
                                        ? renderName(item)
                                        : <span className="fx-tile-name" title={item.name}>{item.name}</span>}
                                    <span className="fx-tile-sub">
                                        {dir ? itemsLabel(item.item_count) : formatBytes(item.size)}
                                    </span>
                                </div>
                            );
                        })}
                        {!items.length && !creating && (
                            <p className="fx-empty">{searchResults ? "No se encontraron coincidencias." : "Esta carpeta está vacía."}</p>
                        )}
                    </div>
                )}
            </div>

            {/* Barra de estado */}
            <div className="fx-status" onClick={(e) => e.stopPropagation()}>
                <span>
                    {items.length} elemento{items.length === 1 ? "" : "s"}
                    {!searchResults && summary && (
                        <> · {summary.folders} carpeta{summary.folders === 1 ? "" : "s"}, {summary.files} archivo{summary.files === 1 ? "" : "s"} · {formatBytes(summary.total_size)}</>
                    )}
                </span>
                {hasSel && (
                    <span>
                        {selectedItems.length} seleccionado{selectedItems.length === 1 ? "" : "s"}
                        {selectedSize > 0 && ` · ${formatBytes(selectedSize)}`}
                    </span>
                )}
                {clipboard && (
                    <span className="fx-muted">
                        Portapapeles: {clipboard.entries.length} ({clipboard.mode === "cut" ? "cortar" : "copiar"})
                    </span>
                )}
                <span className="fx-spacer" />
                {usage && (
                    <span className="fx-usage" title={`${formatBytes(usage.used)} usados de ${formatBytes(usage.total)}`}>
                        <span className="fx-usage-bar">
                            <span
                                className={usedPct >= 90 ? "crit" : usedPct >= 75 ? "warn" : ""}
                                style={{ width: `${usedPct}%` }}
                            />
                        </span>
                        {formatBytes(usage.free)} libres de {formatBytes(usage.total)}
                    </span>
                )}
            </div>

            {/* Menú contextual */}
            {menu && (
                <ul
                    className="fx-menu"
                    style={{
                        left: Math.min(menu.x, window.innerWidth - 220),
                        top: Math.min(menu.y, window.innerHeight - 320),
                    }}
                    onClick={(e) => e.stopPropagation()}
                    role="menu"
                >
                    {menu.onItem ? (
                        <>
                            <li><button type="button" disabled={!single} onClick={() => { setMenu(null); openItem(selectedItems[0]); }}>Abrir</button></li>
                            {searchResults && single && (
                                <li><button type="button" onClick={() => { setMenu(null); showInFolder(selectedItems[0]); }}>Abrir ubicación</button></li>
                            )}
                            <li><button type="button" onClick={() => { setMenu(null); downloadItems(selectedItems); }}>Descargar</button></li>
                            {onShareFolder && isDirItem(selectedItems[0]) && (
                                <li><button type="button" onClick={() => { setMenu(null); onShareFolder(selectedItems[0], crumbs); }}>Compartir</button></li>
                            )}
                            <li className="fx-menu-sep" />
                            <li><button type="button" disabled={readOnly} onClick={() => { setMenu(null); copyToClipboard("cut"); }}>Cortar <kbd>Ctrl+X</kbd></button></li>
                            <li><button type="button" onClick={() => { setMenu(null); copyToClipboard("copy"); }}>Copiar <kbd>Ctrl+C</kbd></button></li>
                            <li><button type="button" disabled={!single || readOnly} onClick={() => { setMenu(null); startRename(); }}>Cambiar nombre <kbd>F2</kbd></button></li>
                            <li><button type="button" className="danger" disabled={readOnly} onClick={() => { setMenu(null); setConfirmDel(selectedItems); }}>Eliminar <kbd>Supr</kbd></button></li>
                            <li className="fx-menu-sep" />
                            <li><button type="button" disabled={!single} onClick={() => { setMenu(null); openProperties(selectedItems[0]); }}>Propiedades</button></li>
                        </>
                    ) : (
                        <>
                            <li><button type="button" disabled={readOnly} onClick={() => { setMenu(null); startNewFolder(); }}>Nueva carpeta</button></li>
                            <li><button type="button" disabled={readOnly} onClick={() => { setMenu(null); fileInputRef.current?.click(); }}>Subir archivos…</button></li>
                            <li><button type="button" disabled={!clipboard || readOnly} onClick={() => { setMenu(null); paste(); }}>Pegar <kbd>Ctrl+V</kbd></button></li>
                            <li className="fx-menu-sep" />
                            <li><button type="button" onClick={() => { setMenu(null); refresh(); }}>Actualizar <kbd>F5</kbd></button></li>
                            <li><button type="button" onClick={() => { setMenu(null); setSelected(new Set(items.map(itemKey))); }}>Seleccionar todo <kbd>Ctrl+A</kbd></button></li>
                            <li className="fx-menu-sep" />
                            <li><button type="button" onClick={() => { setMenu(null); openProperties(null); }}>Propiedades de la carpeta</button></li>
                        </>
                    )}
                </ul>
            )}

            {/* Confirmar eliminación */}
            {confirmDel && (
                <div className="fx-overlay" onClick={(e) => { e.stopPropagation(); setConfirmDel(null); }}>
                    <div className="fx-dialog" role="alertdialog" onClick={(e) => e.stopPropagation()}>
                        <h4>Eliminar</h4>
                        <p>
                            {confirmDel.length === 1
                                ? <>¿Eliminar <strong>«{confirmDel[0].name}»</strong>?</>
                                : <>¿Eliminar <strong>{confirmDel.length} elementos</strong>?</>}
                        </p>
                        {confirmDel.some(isDirItem) && (
                            <p className="fx-warn">Las carpetas se eliminan con todo su contenido. No se puede deshacer.</p>
                        )}
                        <div className="fx-dialog-actions">
                            <button type="button" className="fx-btn" onClick={() => setConfirmDel(null)}>Cancelar</button>
                            <button type="button" className="fx-btn danger" autoFocus onClick={doDelete}>Sí, eliminar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Propiedades */}
            {propsDlg && (
                <div className="fx-overlay" onClick={(e) => { e.stopPropagation(); setPropsDlg(null); }}>
                    <div className="fx-dialog wide" onClick={(e) => e.stopPropagation()}>
                        <h4>Propiedades de «{propsDlg.label}»</h4>
                        {propsDlg.loading && <p>Calculando…</p>}
                        {propsDlg.error && <p className="fx-warn">{propsDlg.error}</p>}
                        {propsDlg.data && <PropertiesTable data={propsDlg.data} />}
                        <div className="fx-dialog-actions">
                            <button type="button" className="fx-btn" onClick={() => setPropsDlg(null)}>Cerrar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Vista previa */}
            {preview && (
                <div className="fx-overlay" onClick={(e) => { e.stopPropagation(); setPreview(null); }}>
                    <div className="fx-dialog preview" onClick={(e) => e.stopPropagation()}>
                        <h4>{preview.item.name}</h4>
                        <div className="fx-preview-body">
                            {preview.loading && <p>Cargando vista previa…</p>}
                            {preview.error && <p className="fx-warn">{preview.error}</p>}
                            {preview.kind === "image" && preview.url && <img src={preview.url} alt={preview.item.name} />}
                            {preview.kind === "pdf" && preview.url && <iframe src={preview.url} title={preview.item.name} />}
                            {preview.kind === "audio" && preview.url && <audio src={preview.url} controls />}
                            {preview.kind === "video" && preview.url && <video src={preview.url} controls />}
                            {preview.kind === "text" && preview.text != null && <pre>{preview.text}</pre>}
                        </div>
                        <div className="fx-dialog-actions">
                            <button type="button" className="fx-btn" onClick={() => downloadItems([preview.item])}>Descargar</button>
                            <button type="button" className="fx-btn primary" onClick={() => setPreview(null)}>Cerrar</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}


function PropertiesTable({ data }) {
    const dir = data.type !== "file";
    const rows = [
        ["Tipo", fileTypeLabel(data)],
        ["Ubicación", data.path || "(raíz de la unidad)"],
        ["Tamaño", data.size != null ? `${formatBytes(data.size)} (${Number(data.size).toLocaleString("es")} bytes)` : "—"],
        ["Tamaño en disco", data.size_on_disk != null ? formatBytes(data.size_on_disk) : "—"],
    ];
    if (dir && data.stats) {
        rows.push([
            "Contiene",
            `${data.stats.files.toLocaleString("es")} archivo(s), ${data.stats.folders.toLocaleString("es")} carpeta(s)${data.stats.partial ? " — cálculo parcial (carpeta muy grande)" : ""}`,
        ]);
    }
    if (data.mime) rows.push(["Tipo MIME", data.mime]);
    rows.push(
        ["Modificado", fmtDate(data.modified)],
        ["Último acceso", fmtDate(data.accessed)],
        ["Cambio de metadatos", fmtDate(data.changed)],
        ["Permisos", data.permissions || "—"],
        ["Propietario / grupo", `${data.owner || "—"} / ${data.group || "—"}`],
    );
    if (data.symlink) rows.push(["Enlace simbólico a", data.symlink_target || "(roto)"]);
    if (data.usage) {
        rows.push(["Espacio", `${formatBytes(data.usage.used)} usados · ${formatBytes(data.usage.free)} libres de ${formatBytes(data.usage.total)}`]);
    }
    return (
        <dl className="fx-props">
            {rows.map(([k, v]) => (
                <div key={k}>
                    <dt>{k}</dt>
                    <dd>{v}</dd>
                </div>
            ))}
        </dl>
    );
}
