/* Utilidades puras del explorador de archivos. */

const collator = new Intl.Collator("es", { numeric: true, sensitivity: "base" });

export function formatBytes(bytes) {
    if (bytes == null || !Number.isFinite(Number(bytes)) || Number(bytes) < 0) return "—";
    const value = Number(bytes);
    if (value === 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB", "PB"];
    const idx = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
    const size = value / 1024 ** idx;
    return `${size.toFixed(size >= 100 || idx === 0 ? 0 : 1)} ${units[idx]}`;
}

export function isDirItem(item) {
    if (!item) return false;
    if (typeof item.is_directory === "boolean") return item.is_directory;
    return item.type === "dir" || item.type === "directory";
}

/** Clave única; en resultados de búsqueda incluye la subcarpeta. */
export function itemKey(item) {
    return item.parent ? `${item.parent}/${item.name}` : item.name;
}

const ICONS = {
    image: ["png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "ico", "tif", "tiff", "heic"],
    video: ["mp4", "mkv", "avi", "mov", "webm", "wmv", "flv"],
    audio: ["mp3", "wav", "ogg", "flac", "m4a", "aac"],
    archive: ["zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso"],
    doc: ["doc", "docx", "odt", "rtf", "txt", "md"],
    sheet: ["xls", "xlsx", "ods", "csv"],
    slides: ["ppt", "pptx", "odp"],
    pdf: ["pdf"],
    code: ["js", "jsx", "ts", "py", "sh", "json", "xml", "yml", "yaml", "html", "css", "sql", "conf", "ini", "log"],
    exe: ["exe", "msi", "bat", "cmd", "deb", "rpm", "apk"],
};

const ICON_EMOJI = {
    image: "🖼️", video: "🎞️", audio: "🎵", archive: "🗜️", doc: "📝",
    sheet: "📊", slides: "📽️", pdf: "📕", code: "📜", exe: "⚙️",
};

export function iconFor(item) {
    if (isDirItem(item)) return "📁";
    const ext = (item.ext || "").toLowerCase();
    for (const [kind, list] of Object.entries(ICONS)) {
        if (list.includes(ext)) return ICON_EMOJI[kind];
    }
    return "📄";
}

const TYPE_LABELS = {
    pdf: "Documento PDF", txt: "Documento de texto", md: "Documento Markdown",
    doc: "Documento de Word", docx: "Documento de Word",
    xls: "Hoja de cálculo", xlsx: "Hoja de cálculo", csv: "Archivo CSV",
    ppt: "Presentación", pptx: "Presentación",
    zip: "Carpeta comprimida (ZIP)", rar: "Archivo RAR", "7z": "Archivo 7Z",
    iso: "Imagen de disco", exe: "Aplicación", msi: "Paquete de Windows",
    json: "Archivo JSON", log: "Registro", html: "Documento HTML",
};

export function fileTypeLabel(item) {
    if (isDirItem(item)) return "Carpeta de archivos";
    const ext = (item.ext || "").toLowerCase();
    if (!ext) return "Archivo";
    if (TYPE_LABELS[ext]) return TYPE_LABELS[ext];
    for (const [kind, list] of Object.entries(ICONS)) {
        if (list.includes(ext) && ["image", "video", "audio"].includes(kind)) {
            const label = { image: "Imagen", video: "Vídeo", audio: "Audio" }[kind];
            return `${label} ${ext.toUpperCase()}`;
        }
    }
    return `Archivo ${ext.toUpperCase()}`;
}

const MB = 1024 * 1024;

const PREVIEW = [
    { kind: "image", max: 25 * MB, mimes: { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", bmp: "image/bmp", svg: "image/svg+xml", ico: "image/x-icon" } },
    { kind: "pdf", max: 25 * MB, mimes: { pdf: "application/pdf" } },
    { kind: "audio", max: 50 * MB, mimes: { mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg", m4a: "audio/mp4", flac: "audio/flac" } },
    { kind: "video", max: 50 * MB, mimes: { mp4: "video/mp4", webm: "video/webm" } },
    {
        kind: "text",
        max: 1 * MB,
        mimes: Object.fromEntries(
            ["txt", "md", "log", "json", "csv", "xml", "yml", "yaml", "ini", "conf", "cfg", "py", "js", "sh", "sql", "css", "html"]
                .map((e) => [e, "text/plain"]),
        ),
    },
];

/** {kind, mime} si el archivo se puede previsualizar en el navegador. */
export function previewKind(item) {
    if (isDirItem(item)) return null;
    const ext = (item.ext || "").toLowerCase();
    for (const group of PREVIEW) {
        if (group.mimes[ext] && (item.size == null || item.size <= group.max)) {
            return { kind: group.kind, mime: group.mimes[ext] };
        }
    }
    return null;
}

/** Carpetas siempre primero; luego por la columna elegida. */
export function sortItems(items, { key, dir }) {
    const mult = dir === "desc" ? -1 : 1;
    return [...items].sort((a, b) => {
        const da = isDirItem(a);
        const db = isDirItem(b);
        if (da !== db) return da ? -1 : 1;
        let cmp;
        switch (key) {
            case "modified":
                cmp = (Date.parse(a.modified) || 0) - (Date.parse(b.modified) || 0);
                break;
            case "type":
                cmp = collator.compare(fileTypeLabel(a), fileTypeLabel(b));
                break;
            case "size":
                cmp = (a.size ?? -1) - (b.size ?? -1);
                break;
            case "items":
                cmp = (a.item_count ?? -1) - (b.item_count ?? -1);
                break;
            default:
                cmp = 0;
        }
        if (cmp === 0) {
            cmp = collator.compare(a.name, b.name);
            return key === "name" ? cmp * mult : cmp;
        }
        return cmp * mult;
    });
}

/**
 * Convierte lo soltado (archivos y CARPETAS) en [{file, name}] donde `name` es
 * la ruta relativa. Debe llamarse de forma síncrona dentro del evento `drop`.
 */
export async function collectDropped(dataTransfer) {
    const files = Array.from(dataTransfer?.files || []);
    const roots = Array.from(dataTransfer?.items || [])
        .map((it) => (it.kind === "file" && it.webkitGetAsEntry ? it.webkitGetAsEntry() : null))
        .filter(Boolean);

    if (!roots.length) {
        return files.map((file) => ({ file, name: file.name }));
    }

    const out = [];

    async function readAll(reader) {
        const all = [];
        for (;;) {
            const batch = await new Promise((resolve, reject) => reader.readEntries(resolve, reject));
            if (!batch.length) break;
            all.push(...batch);
        }
        return all;
    }

    async function walk(entry, prefix) {
        if (entry.isFile) {
            const file = await new Promise((resolve, reject) => entry.file(resolve, reject));
            out.push({ file, name: `${prefix}${entry.name}` });
        } else if (entry.isDirectory) {
            const children = await readAll(entry.createReader());
            for (const child of children) {
                await walk(child, `${prefix}${entry.name}/`);
            }
        }
    }

    for (const root of roots) {
        try {
            await walk(root, "");
        } catch {
            // un elemento ilegible no debe cancelar el resto
        }
    }
    return out;
}
