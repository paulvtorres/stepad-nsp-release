import {
    exploreDirectory,
    getDiskItemInfo,
    searchDisk,
    createDiskFolder,
    renameDiskItem,
    moveDiskItem,
    copyDiskItem,
    deleteDiskItem,
    downloadDiskFile,
    uploadDiskFiles,
    getWebFileList,
    getWebFileInfo,
    searchWebFiles,
    mkdirWebFile,
    moveWebFile,
    copyWebFile,
    deleteWebFile,
    downloadWebFile,
    uploadWebFile,
} from "../../services/api";

/*
 * Un "adaptador" traduce las acciones del explorador (siempre expresadas como
 * una lista de carpetas relativa a la raíz: `crumbs`) a las llamadas de cada
 * API. Así el mismo componente sirve para discos físicos y para unidades
 * compartidas.
 */

function joinRel(crumbs, name) {
    return [...(crumbs || []), name].filter(Boolean).join("/");
}

function joinAbs(root, crumbs, name) {
    const base = String(root || "").replace(/\/+$/, "");
    return [base, ...(crumbs || []), ...(name ? [name] : [])].join("/");
}

/** Disco físico montado en `mountpoint` (rutas absolutas). */
export function createDiskAdapter(mountpoint) {
    const abs = (crumbs, name) => joinAbs(mountpoint, crumbs, name);

    return {
        key: `disk:${mountpoint}`,
        rootLabel: mountpoint,
        list: (crumbs) => exploreDirectory(abs(crumbs)),
        info: (crumbs, name) => getDiskItemInfo(abs(crumbs, name)),
        search: (crumbs, q) => searchDisk(abs(crumbs), q),
        mkdir: (crumbs, name) => createDiskFolder(abs(crumbs), name),
        rename: (crumbs, name, newName) => renameDiskItem(abs(crumbs, name), newName),
        move: (crumbs, name, destCrumbs) => moveDiskItem(abs(crumbs, name), abs(destCrumbs)),
        copy: (crumbs, name, destCrumbs) => copyDiskItem(abs(crumbs, name), abs(destCrumbs)),
        remove: (crumbs, name, isDir) => deleteDiskItem(abs(crumbs, name), isDir),
        download: (crumbs, name) => downloadDiskFile(abs(crumbs, name)),
        upload: (crumbs, files) => uploadDiskFiles(abs(crumbs), files),
    };
}

/** Unidad compartida (`unit` = ruta de la unidad; rutas relativas). */
export function createWebAdapter(unit, startCrumbs = []) {
    return {
        key: `web:${unit}`,
        rootLabel: unit,
        startCrumbs,
        list: (crumbs) => getWebFileList(unit, crumbs.join("/")),
        info: (crumbs, name) => getWebFileInfo(unit, joinRel(crumbs, name)),
        search: (crumbs, q) => searchWebFiles(unit, crumbs.join("/"), q),
        mkdir: (crumbs, name) => mkdirWebFile(unit, crumbs.join("/"), name),
        rename: (crumbs, name, newName) =>
            moveWebFile(unit, joinRel(crumbs, name), joinRel(crumbs, newName)),
        move: (crumbs, name, destCrumbs) =>
            moveWebFile(unit, joinRel(crumbs, name), joinRel(destCrumbs, name)),
        copy: (crumbs, name, destCrumbs) =>
            copyWebFile(unit, joinRel(crumbs, name), destCrumbs.join("/")),
        remove: (crumbs, name) => deleteWebFile(unit, joinRel(crumbs, name)),
        download: (crumbs, name) => downloadWebFile(unit, joinRel(crumbs, name)),
        upload: (crumbs, files) => uploadWebFile(unit, crumbs.join("/"), files),
    };
}
