import threading
import time

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.backups.services.backup_service import BackupService
from backend.backups.services.cloud_storage_service import CloudStorageService
from backend.backups.services.system_backup_service import (
    system_backup_service
)

from backend.shared.logging.logger import logger


class BackupComponent(BaseComponent):

    name = "backups"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.service = BackupService()

    def start(self):

        logger.info("BackupComponent started.")

        self.service.start_scheduler()

        # Monthly proof that the latest backup is restorable (temp DB).
        try:

            from backend.backups.services.restore_verification_service import (
                RestoreVerificationService,
            )
            from backend.audit.services.audit_chain_check_service import (
                AuditChainCheckService,
            )

            self._verify = RestoreVerificationService()

            self._audit_check = AuditChainCheckService()

            threading.Thread(
                target=self._verify_loop,
                name="restore-verify",
                daemon=True,
            ).start()

        except Exception as error:

            logger.warning(
                "No se pudo iniciar la verificación de respaldos: %s", error
            )

        CloudStorageService().start_scheduler()

        # Respaldo automático de la configuración del NSP (config + postgres)
        # programado según system-backup-config.json (por defecto 03:00).
        try:
            system_backup_service.start_scheduler()
        except Exception as error:
            logger.warning(
                "No se pudo iniciar el scheduler de respaldo del sistema: %s",
                error,
            )

    def _verify_loop(self):

        # Give the system time to settle after boot, then check daily and
        # run the verification once a month.
        time.sleep(600)

        while True:

            try:

                if self._verify.should_run():

                    self._verify.run()

                if getattr(self, "_audit_check", None) and self._audit_check.should_run():

                    self._audit_check.run()

            except Exception as error:

                logger.warning(
                    "Verificación de respaldo falló al ejecutarse: %s", error
                )

            time.sleep(86400)

    def stop(self):

        logger.info("BackupComponent stopped.")

        try:
            system_backup_service.stop_scheduler()
        except Exception as error:
            logger.debug("backup_component.stop: %s", error)