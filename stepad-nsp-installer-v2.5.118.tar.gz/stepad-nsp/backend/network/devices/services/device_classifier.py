class DeviceClassifier:


    # Tipos que NO son equipos de usuario: no pueden pertenecer a
    # grupos. Siguen listándose en Dispositivos si tienen IP en LAN.
    INFRASTRUCTURE_TYPES = frozenset(
        {"PRINTER", "ROUTER", "IP_PHONE", "SERVER", "SWITCH", "AP"}
    )

    # Prefijos OUI (primeros 3 octetos en minusculas) de fabricantes de
    # telefonia IP, para clasificar por MAC cuando el equipo no declara
    # nombre (muchos telefonos no responden a netbios/mDNS/LLMNR).
    PHONE_OUI = frozenset({
        # Grandstream
        "00:0b:82", "00:0d:0b", "00:1d:0d",
        # Yealink
        "00:15:65", "3c:64:d9", "1c:b7:2c", "74:64:a6", "f8:a7:63",
        # Cisco / Linksys (SPA, CP, PAP2)
        "00:0e:08", "00:1b:0c", "64:16:66", "9c:34:26", "00:0f:66",
        # Polycom
        "00:04:f2", "00:e0:db", "24:c9:a1", "00:0f:20",
        # Snom
        "00:04:13",
        # Avaya
        "00:04:0d", "00:1b:9f",
        # Fanvil
        "28:f9:da",
        # Obihai
        "9c:93:4e", "d0:9c:6b",
        # Gigaset
        "00:25:ca", "00:24:2c",
        # Panasonic
        "00:80:f0", "00:07:05",
        # Audiocodes
        "00:0e:5f",
    })

    # Prefijos OUI de impresoras comunes (por si el nombre no se resuelve).
    PRINTER_OUI = frozenset({
        "00:1f:45",  # HP (algunos)
        "00:23:7d",  # Ricoh
        "00:21:b7",  # Brother
        "00:00:48",  # Xerox
        "e0:bb:9e",  # Epson
        "00:26:ab",  # Canon
        "00:1e:8f",  # Canon (algunos)
    })

    # Prefijos OUI de routers/AP/mesh (TP-Link, Ubiquiti, Mikrotik...).
    ROUTER_OUI = frozenset({
        "50:c7:bf",  # TP-Link
        "f4:f2:6d",  # TP-Link
        "6c:9c:ed",  # TP-Link
        "98:da:c4",  # TP-Link
        "c0:3a:55",  # TP-Link Deco mesh
        "04:d9:f5",  # Ubiquiti
        "24:a4:3c",  # Ubiquiti
        "dc:9f:db",  # Mikrotik
        "48:8f:5a",  # Mikrotik
        "10:27:f5",  # Mikrotik
    })

    # Prefijos OUI de fabricantes de PC/computadores (fallback por MAC
    # cuando no se resuelve el nombre).
    COMPUTER_OUI = frozenset({
        "3c:d9:2b",  # HP
        "b4:2e:99",  # HP
        "9c:b6:54",  # HP
        "d8:cb:8a",  # HP
        "f8:75:a4",  # Dell
        "00:14:22",  # Dell
        "18:66:da",  # Dell
        "b8:ae:ed",  # Dell
        "34:17:eb",  # Lenovo
        "54:ee:75",  # Lenovo
        "3c:a6:f6",  # Lenovo
        "20:cf:30",  # Acer
        "54:04:a6",  # Acer
        "00:1b:fc",  # ASUSTek
        "bc:ae:c5",  # ASUSTek
        "4c:cc:6a",  # ASUSTek
        "00:1e:8f",  # ASUSTek
        "f0:18:98",  # ASUSTek
        "5c:f9:38",  # Toshiba
        "04:92:26",  # Toshiba
        # Apple
        "a4:83:e7",  # Apple
        "f0:18:98",  # Apple (algunos)
        "3c:22:fb",  # Apple
        "a8:51:6b",  # Apple
        "f4:5c:89",  # Apple
        "dc:a4:ca",  # Apple
        # Huawei (laptops/PCs)
        "00:e0:4c",  # Huawei
        "48:46:fb",  # Huawei
        "04:bd:70",  # Huawei
    })

    # Prefijos OUI de camaras IP (Hikvision, Dahua, Axis, Uniview...).
    CAMERA_OUI = frozenset({
        "7c:8b:ca",  # Hikvision
        "28:57:be",  # Hikvision
        "c4:2f:90",  # Hikvision
        "44:19:b6",  # Hikvision
        "18:68:cb",  # Hikvision
        "b4:a3:82",  # Hikvision
        "3c:ef:8c",  # Dahua
        "e0:50:8b",  # Dahua
        "9c:8e:cd",  # Dahua
        "00:40:8c",  # Axis
        "ac:cc:8e",  # Axis
        "84:2e:14",  # Uniview
        # Reolink
        "34:12:98",  # Reolink
        "1c:61:b4",  # Reolink
        # Foscam
        "00:a2:f3",  # Foscam
        "2c:61:04",  # Foscam
        # Amcrest
        "2c:13:ef",  # Amcrest
    })

    # Prefijos OUI de control de acceso / marcadores de asistencia
    # biometricos (ZKTeco, etc.).
    ACCESS_OUI = frozenset({
        "00:17:61",  # ZKTeco
        "d8:84:01",  # ZKTeco
        "e0:3f:49",  # ZKTeco
    })

    # Prefijos OUI de servidores (Dell PowerEdge, HPE ProLiant, IBM/Lenovo
    # ThinkSystem, Supermicro, etc.).
    SERVER_OUI = frozenset({
        "18:66:da",  # Dell (PowerEdge)
        "f8:75:a4",  # Dell (PowerEdge)
        "b8:ae:ed",  # Dell (PowerEdge)
        "00:14:22",  # Dell (PowerEdge)
        "3c:d9:2b",  # HPE (ProLiant)
        "b4:2e:99",  # HPE (ProLiant)
        "9c:b6:54",  # HPE (ProLiant)
        "d8:cb:8a",  # HPE (ProLiant)
        "00:1b:78",  # Intel (servidores)
        "00:1e:67",  # Intel (servidores)
        "3c:a8:2a",  # Lenovo (ThinkSystem)
        "70:5a:0f",  # Lenovo (ThinkSystem)
        "28:d2:44",  # Lenovo (ThinkSystem)
        "00:25:90",  # Supermicro
        "30:d0:42",  # Supermicro
        "44:a8:42",  # Supermicro
    })

    # Prefijos OUI de switches administrados (Cisco, HP/Aruba, Juniper,
    # Netgear, TP-Link managed).
    SWITCH_OUI = frozenset({
        "00:1b:0c",  # Cisco
        "00:1a:2f",  # Cisco
        "00:50:56",  # Cisco
        "00:1e:49",  # Cisco
        "64:f6:9d",  # Cisco
        "b0:aa:77",  # Cisco
        "3c:d9:2b",  # HPE/Aruba
        "b4:2e:99",  # HPE/Aruba
        "9c:b6:54",  # HPE/Aruba
        "2c:57:41",  # Aruba
        "94:b4:0f",  # Aruba
        "00:1f:f3",  # Juniper
        "28:8a:1c",  # Juniper
        "5c:45:27",  # Juniper
        "88:5a:85",  # Netgear
        "20:e5:2a",  # Netgear
        "44:94:fc",  # Netgear
        "c0:3f:0e",  # Netgear
        "20:6b:e7",  # TP-Link (managed)
    })

    # Prefijos OUI de access points WiFi (Ubiquiti UniFi, TP-Link EAP,
    # Aruba, Ruckus, Cambium).
    AP_OUI = frozenset({
        "04:d9:f5",  # Ubiquiti
        "24:a4:3c",  # Ubiquiti
        "78:8a:20",  # Ubiquiti
        "b4:fb:e4",  # Ubiquiti
        "dc:9f:db",  # Ubiquiti
        "f0:9f:c2",  # Ubiquiti
        "e0:63:da",  # Ubiquiti
        "20:6b:e7",  # TP-Link EAP
        "50:c7:bf",  # TP-Link (AP)
        "14:cc:20",  # TP-Link EAP
        "2c:57:41",  # Aruba
        "94:b4:0f",  # Aruba
        "6c:f3:7f",  # Aruba
        "24:de:c6",  # Ruckus
        "74:91:1a",  # Ruckus
        "c8:3a:35",  # Ruckus
        "00:04:57",  # Cambium
        "04:87:27",  # Cambium
    })

    # Prefijos OUI de IoT / smart home (Tuya, Sonoff, Shelly, etc.)
    IOT_OUI = frozenset({
        "18:69:8a",  # Tuya
        "d4:a6:51",  # Tuya
        "bc:dd:c2",  # Tuya
        "50:02:91",  # Sonoff (ITEAD)
        "a4:cf:12",  # Sonoff (ITEAD)
        "ec:fa:bc",  # Shelly
        "a8:48:fa",  # Shelly
        "30:96:fb",  # Yeelight
        "7c:78:b2",  # Yeelight
        "04:cf:8c",  # Espressif (ESP8266/ESP32)
        "30:ae:a4",  # Espressif (ESP8266/ESP32)
        "60:01:94",  # Espressif (ESP8266/ESP32)
        "2c:3a:e8",  # Espressif (ESP8266/ESP32)
        "10:52:1c",  # Philips Hue
        "ec:08:6b",  # Philips Hue
        "00:17:88",  # Philips Hue
    })

    # Prefijos OUI de smart TVs / streaming devices.
    TV_OUI = frozenset({
        "00:0c:29",  # Samsung TV
        "00:12:47",  # Samsung TV
        "00:15:99",  # Samsung TV
        "00:1e:58",  # Samsung TV
        "00:21:4c",  # Samsung TV
        "00:23:39",  # Samsung TV
        "00:23:d6",  # Samsung TV
        "00:24:54",  # Samsung TV
        "00:25:66",  # Samsung TV
        "00:26:37",  # Samsung TV
        "8c:71:f8",  # Samsung TV
        "cc:6d:a0",  # Samsung TV
        "34:c3:ac",  # LG TV
        "10:68:3f",  # LG TV
        "cc:2d:83",  # LG TV
        "a8:23:fe",  # LG TV
        "f8:01:13",  # LG TV
        "b4:e9:b0",  # Roku
        "d0:21:f9",  # Roku
        "ac:3a:7a",  # Roku
        "88:de:a9",  # Roku
        "dc:3a:5e",  # Fire TV (Amazon)
        "f0:27:2d",  # Fire TV (Amazon)
        "74:c2:46",  # Apple TV
        "3c:2e:ff",  # Apple TV
        "a4:83:e7",  # Apple TV
        "dc:a9:04",  # Chromecast (Google)
        "30:fd:38",  # Chromecast (Google)
        "54:60:09",  # Chromecast (Google)
        "f8:a8:19",  # Chromecast (Google)
    })


    @staticmethod
    def is_infrastructure(
        device_type: str | None
    ) -> bool:

        return (
            device_type
            in DeviceClassifier.INFRASTRUCTURE_TYPES
        )


    @staticmethod
    def classify_by_mac(
        mac: str | None
    ) -> str:
        """
        Clasifica por fabricante (primeros 3 octetos de la MAC) cuando
        el equipo no declara hostname. Muchos telefonos IP, impresoras
        y routers no responden a netbios/mDNS/LLMNR, asi que el nombre
        nunca llega a resolverlos.
        """

        if not mac:

            return "UNKNOWN"

        oui = mac.strip().lower()[:8]

        if oui in DeviceClassifier.PHONE_OUI:

            return "IP_PHONE"

        if oui in DeviceClassifier.PRINTER_OUI:

            return "PRINTER"

        if oui in DeviceClassifier.SWITCH_OUI:

            return "SWITCH"

        if oui in DeviceClassifier.AP_OUI:

            return "AP"

        if oui in DeviceClassifier.ROUTER_OUI:

            return "ROUTER"

        if oui in DeviceClassifier.SERVER_OUI:

            return "SERVER"

        if oui in DeviceClassifier.COMPUTER_OUI:

            return "COMPUTER"

        if oui in DeviceClassifier.TV_OUI:

            return "TV"

        if oui in DeviceClassifier.IOT_OUI:

            return "IOT"

        if oui in DeviceClassifier.ACCESS_OUI:

            return "ACCESO"

        if oui in DeviceClassifier.CAMERA_OUI:

            return "CAMERA"

        return "UNKNOWN"


    def classify(
        self,
        hostname: str | None
    ) -> str:


        if not hostname:
            return "UNKNOWN"


        name = hostname.lower()


        mobile_keywords = [

            "iphone",
            "ipad",
            "android",
            "realme",
            "xiaomi",
            "redmi",
            "samsung",
            "galaxy",
            "motorola",
            "moto",
            "oppo",
            "vivo",
            "tecno",
            "spark",
            "infinix",
            "itel",
            "honor",
            "huawei",
            "oneplus",
            "nokia",
            "zte",
            "lg",
            "poco",

        ]


        computer_keywords = [

            "pc",
            "desktop",
            "laptop",
            "macbook",
            "imac",
            "ubuntu",
            "windows",
            # Nombres de equipos por departamento/negocio (muy comunes
            # en oficinas: el hostname no es "DESKTOP-*").
            "gerencia",
            "comercial",
            "contabilidad",
            "rrhh",
            "rh-",
            "recepcion",
            "ventas",
            "sistemas",
            "pizzeria",
            "administracion",
            "bodega",
            "tienda",
            "caja",
            "oficina",
            "secretaria",
            "gerente",
            "auditoria",
            "logistica",
            "pagos",
            "cobros",
            "tesoreria",
            "financiero",
            "coys",
            "a17-",
            "asistente",
            "pasante",
            "lptp-",
            "laptop-",

        ]


        server_keywords = [

            "server",
            "svr",
            "nas",
            "synology",
            "qnap",
            "truenas",
            "unraid",
            "proxmox",
            "esxi",
            "hyperv",

        ]


        printer_keywords = [

            "printer",
            "epson",
            "hp",
            "canon",
            "brother",
            "scanner",
            "mfp",
            "laserjet",
            "deskjet"

        ]


        phone_keywords = [

            "yealink",
            "polycom",
            "grandstream",
            "gxp",
            "gxv",
            "grp",
            "ht8",
            "fanvil",
            "gigaset",
            "snom",
            "avaya",
            "panasonic",
            "obihai",
            "cisco-spa",
            "cisco-cp",
            "sep",
            "sip",
            "voip",
            "ip-phone",
            "ipphone",
            "audiocodes",
            "alcatel"

        ]


        router_keywords = [

            "router",
            "mikrotik",
            "tplink",
            "tp-link",
            "ubiquiti",
            "cisco",
            "openwrt",
            "access-point",
            "deco"

        ]


        camera_keywords = [

            "camera",
            "ipcam",
            "hikvision",
            "dahua",
            "axis",
            "dvr",
            "nvr",
            "cam",

        ]


        switch_keywords = [

            "switch",
            "sg200",
            "sg300",
            "sg500",
            "catalyst",
            "aruba",
            "netgear",
            "juniper",

        ]


        iot_keywords = [

            "tuya",
            "sonoff",
            "shelly",
            "yeelight",
            "philips-hue",
            "smart",
            "iot",
            "sensor",
            "temperatura",
            "humedad",

        ]


        tv_keywords = [

            "samsung-tv",
            "lg-tv",
            "roku",
            "fire-tv",
            "apple-tv",
            "chromecast",
            "smarttv",
            "smart-tv",
            "android-tv",

        ]


        for keyword in mobile_keywords:

            if keyword in name:
                return "MOBILE"



        for keyword in server_keywords:

            if keyword in name:
                return "SERVER"


        for keyword in camera_keywords:

            if keyword in name:
                return "CAMERA"



        for keyword in computer_keywords:

            if keyword in name:
                return "COMPUTER"



        for keyword in printer_keywords:

            if keyword in name:
                return "PRINTER"



        for keyword in phone_keywords:

            if keyword in name:
                return "IP_PHONE"



        for keyword in router_keywords:

            if keyword in name:
                return "ROUTER"


        for keyword in switch_keywords:

            if keyword in name:
                return "SWITCH"


        for keyword in iot_keywords:

            if keyword in name:
                return "IOT"


        for keyword in tv_keywords:

            if keyword in name:
                return "TV"


        return "OTRO"


    @staticmethod
    def guess_os(
        hostname: str | None,
        device_type: str | None = None,
    ) -> str:
        """Sistema operativo probable a partir del nombre / tipo.

        No es fingerprinting profundo: usa señales del hostname
        (NetBIOS/mDNS/DHCP) y del tipo clasificado. Si no hay pista,
        devuelve 'Desconocido'.
        """

        name = (hostname or "").strip().lower()
        dtype = (device_type or "").upper()

        if dtype in {"PRINTER", "ROUTER", "IP_PHONE", "CAMERA", "ACCESO", "SWITCH", "AP", "TV", "IOT"}:
            return "—"

        if dtype == "SERVER":
            return "Linux/Server"

        if name:
            if any(k in name for k in ("iphone", "ipad", "ipod")):
                return "iOS"

            if any(
                k in name
                for k in ("macbook", "imac", "mac-mini", "macpro", "macos")
            ):
                return "macOS"

            if any(
                k in name
                for k in (
                    "android", "realme", "xiaomi", "redmi", "samsung",
                    "galaxy", "motorola", "moto-", "moto ", "oppo",
                    "vivo", "tecno", "spark", "infinix", "itel",
                    "honor", "huawei", "oneplus", "poco",
                )
            ):
                return "Android"

            if any(
                k in name
                for k in (
                    "ubuntu", "debian", "linux", "fedora", "centos",
                    "raspberry", "raspi",
                )
            ):
                return "Linux"

            if any(
                k in name
                for k in (
                    "desktop-", "laptop-", "win-", "windows",
                    "notebook-", "pc-",
                )
            ):
                return "Windows"

        if dtype == "MOBILE":
            return "Android"

        if dtype == "COMPUTER":
            return "Windows"

        return "Desconocido"
