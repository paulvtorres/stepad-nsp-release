"""
Salud operativa del DHCP (dnsmasq).

Detecta proceso caído o colgado (cola UDP 67 llena / bloqueado en
pipe) y reintenta arrancar. Genera alerta crítica en el panel y, si
hay destinatarios de alertas configurados, un aviso inmediato.
"""

from __future__ import annotations

import re
import subprocess
import time

from sqlalchemy.orm import Session

from backend.alerts.services.alert_service import AlertService
from backend.core.dnsmasq.process_manager import (
    DNSMASQ_BIN,
    dnsmasq_process_manager,
)
from backend.shared.logging.logger import logger


# Cola Recv-Q en bytes. DHCP sano suele estar en 0; si el proceso
# deja de leer el socket (p. ej. bloqueado en logs) la cola crece.
STUCK_RECVQ_BYTES = 8192

# No repetir correo/alerta cada 30s del monitor.
ALERT_COOLDOWN_SECONDS = 1800


_SS_LINE = re.compile(
    r"^(?:UNCONN|UNCONN-P)\s+(\d+)\s+\d+\s+\S+:67\b"
)


def udp67_recv_queue_bytes(ss_output: str | None = None) -> int:
    """Recv-Q de UDP/67 de nuestro dnsmasq. 0 si no escucha."""

    if ss_output is None:

        result = subprocess.run(
            ["ss", "-ulnp"],
            capture_output=True,
            text=True,
        )

        ss_output = result.stdout or ""

    best = 0

    for line in ss_output.splitlines():

        if ":67" not in line:

            continue

        if DNSMASQ_BIN not in line and "dnsmasq" not in line:

            continue

        match = _SS_LINE.search(line.strip())

        if match:

            best = max(best, int(match.group(1)))

    return best


class DhcpHealthService:

    def __init__(self):

        self.alert_service = AlertService()

        self._last_alert_at: float = 0.0
        self._down_since: float | None = None

    def inspect(self) -> dict:

        status = dnsmasq_process_manager.status()

        recv_q = 0

        if status.get("running"):

            try:

                recv_q = udp67_recv_queue_bytes()

            except Exception as error:

                logger.warning("DHCP health: no se leyó Recv-Q: %s", error)

        stuck = bool(status.get("running") and recv_q >= STUCK_RECVQ_BYTES)

        pool_low = False
        pool_exhausted = False
        conflicts = 0

        try:

            from backend.dhcp.reconciler import get_dhcp_reconciler

            reconciler_status = get_dhcp_reconciler().status()
            pool_low = bool(reconciler_status.get("pool_low"))
            pool_exhausted = bool(reconciler_status.get("pool_exhausted"))
            conflicts = int(reconciler_status.get("conflicts") or 0)

        except Exception as error:
            logger.debug("dhcp_health_service.inspect: %s", error)

        healthy = bool(status.get("running") and not stuck)

        return {
            "running": bool(status.get("running")),
            "pid": status.get("pid"),
            "recv_q": recv_q,
            "stuck": stuck,
            # `pool_low` NO afecta a `healthy`: el watchdog no debe
            # reiniciar dnsmasq porque falten direcciones (no lo arregla).
            "pool_low": pool_low,
            "pool_exhausted": pool_exhausted,
            "conflicts": conflicts,
            # El icono del panel usa attention; el watchdog sigue usando
            # healthy para no reiniciar dnsmasq por falta de direcciones.
            "attention": bool(
                not healthy or pool_low or pool_exhausted or conflicts > 0
            ),
            "healthy": healthy,
        }

    def ensure_healthy(self, db: Session) -> dict:

        snap = self.inspect()

        if snap["healthy"]:

            self._down_since = None

            return snap

        if self._down_since is None:

            self._down_since = time.monotonic()

        down_for = time.monotonic() - self._down_since

        if not snap["running"]:

            title = "DHCP caído: los equipos no reciben IP"
            message = (
                "El servicio DHCP (dnsmasq) no está en ejecución. "
                "STEPAD intenta reiniciarlo."
            )
            reason = "down"

        else:

            title = "DHCP colgado: no responde a pedidos de IP"
            message = (
                f"El servidor DHCP está escuchando pero no procesa "
                f"peticiones (cola UDP 67 = {snap['recv_q']} bytes). "
                "STEPAD intenta reiniciarlo."
            )
            reason = "stuck"

        logger.warning("DHCP %s: %s (reintentando)", reason, message)

        from backend.dhcp.services.dhcp_apply import apply_dhcp_change

        restarted = apply_dhcp_change(force=True)

        snap["restart"] = restarted
        snap["reason"] = reason

        # Solo se alerta si sigue fallando DESPUES del reintento: un
        # arranque o un reinicio del servicio deja a dnsmasq unos segundos
        # levantandose y antes generaba una alerta critica falsa.
        snap["after_restart"] = self.inspect()

        # Alerta si sigue caído después del reintento o si lleva más de
        # 45 s sin servicio: un reinicio normal tarda pocos segundos y no
        # debe generar falsos positivos.
        if (not snap["after_restart"]["healthy"]) or down_for >= 45:

            self._raise_alert(db, title, message)

        return snap

    def _raise_alert(self, db: Session, title: str, message: str) -> None:

        now = time.time()

        if now - self._last_alert_at < ALERT_COOLDOWN_SECONDS:

            return

        self._last_alert_at = now

        try:

            self.alert_service.create(
                db,
                alert_type="DHCP_HEALTH",
                severity="critical",
                title=title,
                message=message,
            )

        except Exception as error:

            logger.error("DHCP health: no se creó alerta: %s", error)

        # AlertService ya dispara el correo inmediato para alertas
        # críticas con los destinatarios configurados.

    def _send_email(self, db: Session, title: str, message: str) -> None:

        try:

            from backend.dhcp.services.dhcp_alert_service import (
                DhcpAlertService,
            )

            if not DhcpAlertService().service_email_allowed():

                logger.info(
                    "DHCP health: correo omitido "
                    "(desactivado en Red → DHCP)."
                )

                return

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            html_body = f"""
            <p><strong>{title}</strong></p>
            <p>{message}</p>
            <p>Revise <em>Alertas</em> y <em>Red → DHCP</em> en el panel
            del NSP y que los equipos vuelvan a obtener IP.</p>
            """

            CriticalAlertEmailService().send(
                db,
                title,
                message,
                html_body=html_body,
            )

        except Exception as error:

            logger.warning("DHCP health: no se envió correo: %s", error)
