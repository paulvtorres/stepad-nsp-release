"""El icono DHCP debe alertar por algo más que el proceso vivo."""

from backend.dhcp.services import dhcp_health_service as module
from backend.dhcp.services.dhcp_health_service import DhcpHealthService


class FakeProcess:

    def __init__(self, running=True):
        self.running = running

    def status(self):
        return {"running": self.running, "pid": 123 if self.running else None}


class FakeReconciler:

    def __init__(self, **status):
        self._status = status

    def status(self):
        return dict(self._status)


def configure(monkeypatch, reconciler, running=True):
    monkeypatch.setattr(
        module,
        "dnsmasq_process_manager",
        FakeProcess(running),
    )
    import backend.dhcp.reconciler as reconciler_module

    monkeypatch.setattr(
        reconciler_module,
        "get_dhcp_reconciler",
        lambda: reconciler,
    )


def test_health_ok_sin_alertas(monkeypatch):
    configure(monkeypatch, FakeReconciler(pool_low=False, conflicts=0))
    snap = DhcpHealthService().inspect()
    assert snap["healthy"] is True
    assert snap["attention"] is False


def test_pool_bajo_pone_attention_sin_marcar_health_false(monkeypatch):
    configure(monkeypatch, FakeReconciler(pool_low=True, conflicts=0))
    snap = DhcpHealthService().inspect()
    assert snap["healthy"] is True
    assert snap["pool_low"] is True
    assert snap["attention"] is True


def test_pool_agotado_y_conflictos_piden_attention(monkeypatch):
    configure(
        monkeypatch,
        FakeReconciler(pool_low=False, pool_exhausted=True, conflicts=2),
    )
    snap = DhcpHealthService().inspect()
    assert snap["attention"] is True
    assert snap["pool_exhausted"] is True
    assert snap["conflicts"] == 2


def test_proceso_caido_es_danger_y_no_attention_extra(monkeypatch):
    configure(
        monkeypatch,
        FakeReconciler(pool_low=False, conflicts=0),
        running=False,
    )
    snap = DhcpHealthService().inspect()
    assert snap["healthy"] is False
    assert snap["attention"] is True
