"""API para escaneo de shares de red."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles
from backend.shares.services.network_scan import NetworkShareScanner

router = APIRouter(
    prefix="/shares/network",
    tags=["Network Share Discovery"],
)

scanner = NetworkShareScanner()


@router.get("/scan")
def scan_network(
    subnet: str = "192.168.100.0/24",
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Escanea la LAN buscando shares SMB."""
    results = scanner.scan_lan(subnet)
    return {
        "success": True,
        "subnet": subnet,
        "hosts": results,
        "total_hosts": len(results),
        "total_shares": sum(len(h["shares"]) for h in results),
    }


@router.post("/test")
def test_share_connection(
    host: str,
    share: str,
    user: str = "",
    password: str = "",
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Prueba conexión a un share específico."""
    result = scanner.test_connection(host, share, user, password)
    return result


@router.get("/list-shares")
def list_shares_with_credentials(
    host: str,
    user: str,
    password: str,
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Lista shares SMB de un host usando credenciales."""
    shares = scanner.list_shares_with_auth(host, user, password)
    return {
        "success": True,
        "host": host,
        "shares": shares,
        "total": len(shares),
    }


@router.get("/browse")
def browse_share_content(
    host: str,
    share: str,
    path: str = "",
    user: str = "",
    password: str = "",
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Navega el contenido de un share SMB."""
    items = scanner.browse_share(host, share, path, user, password)
    return {
        "success": True,
        "host": host,
        "share": share,
        "path": path,
        "items": items,
        "total": len(items),
    }
