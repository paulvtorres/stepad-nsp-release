#!/usr/bin/env bash
#
# Pulls the latest changes from origin/main and applies them
# (deps + frontend build + restart). Run as root.
#
set -euo pipefail

APP_USER="${APP_USER:-paulan}"
APP_DIR="/home/${APP_USER}/stepad-nsp"
BRANCH="main"

cd "${APP_DIR}"

echo "==> Fetching origin/${BRANCH}..."
sudo -u "${APP_USER}" git fetch origin

HEAD="$(sudo -u "${APP_USER}" git rev-parse HEAD)"
REMOTE="$(sudo -u "${APP_USER}" git rev-parse "origin/${BRANCH}")"

if [ "${HEAD}" = "${REMOTE}" ]; then
    echo "Up to date at ${HEAD}"
    exit 0
fi

echo "==> Pulling..."
sudo -u "${APP_USER}" git pull --ff-only origin "${BRANCH}"

echo "==> Python dependencies..."
sudo -u "${APP_USER}" .venv/bin/pip install -r requirements.txt

echo "==> Frontend build..."
sudo -u "${APP_USER}" bash -lc '
    export NVM_DIR="$HOME/.nvm"
    . "$NVM_DIR/nvm.sh"
    cd "${APP_DIR}/frontend"
    npm install || true
    npm run build
'

echo "==> Restarting service..."
systemctl restart stepad-nsp

echo "Updated to ${REMOTE}"
