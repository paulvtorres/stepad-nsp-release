#!/usr/bin/env bash
#
# STEPAD NSP - instalador para Debian 12 limpio.
#
# Uso (como root, DENTRO de la carpeta del repositorio):
#   sudo bash install.sh
#
# Hace TODO automáticamente y al final imprime cómo entrar a la web
# y las credenciales iniciales.
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

APP_USER="${APP_USER:-paulan}"
REPO_URL="${REPO_URL:-git@github.com:paulvtorres/stepad-nsp.git}"
REPO_BRANCH="${REPO_BRANCH:-main}"
# Opcional: si pones STEPAD_TAILSCALE_KEY (pre-auth key), el NSP se
# une a tu red Tailscale automáticamente para administrarlo remoto.
TAILSCALE_KEY="${STEPAD_TAILSCALE_KEY:-tskey-auth-kwaC1MzyqJ11CNTRL-odGsrVTP4LPCprkJKtrnKPyLMstpS1TK}"
TAILSCALE_HOSTNAME="${STEPAD_HOSTNAME:-stepad-nsp}"

if [ "$(id -u)" -ne 0 ]; then
    echo "Ejecuta como root: sudo bash install.sh"
    exit 1
fi

# Detectar si ya existe una versión instalada para advertir antes
# de actualizar (evita pisar una instalación sin avisar).
ALREADY_INSTALLED=0
if [ -f "/etc/stepad/stepad.env" ] || systemctl list-unit-files 2>/dev/null | grep -q "stepad-nsp.service"; then
    ALREADY_INSTALLED=1
fi

if [ "${ALREADY_INSTALLED}" = "1" ]; then
    echo ""
    echo "======================================================================"
    echo "⚠  YA EXISTE una versión de STEPAD NSP instalada en este equipo."
    echo "    El instalador la ACTUALIZARÁ manteniendo la configuración y datos."
    echo "======================================================================"
    echo ""
    if [ "${STEPAD_UPDATE:-0}" = "1" ]; then
        # Actualización disparada desde la web (ya confirmada por el admin).
        RESPUESTA=S
    elif [ -t 0 ]; then
        printf "¿Deseas continuar con la actualización? (S/N): "
        read -r RESPUESTA
    else
        # Sin terminal (p. ej. curl | sudo bash): continuar sin preguntar.
        RESPUESTA=S
    fi
    case "${RESPUESTA}" in
        [sS]|[sS][iI]|[yY]|[yY][eE][sS])
            echo ""
            echo "Continuando con la actualización..."
            ;;
        *)
            echo "Instalación cancelada."
            exit 1
            ;;
    esac
fi

# Si estamos dentro del código (paquete descargado o repo clonado),
# úsalo tal cual; si no, clónalo.
if [ -d "${SCRIPT_DIR}/backend" ] && [ -f "${SCRIPT_DIR}/install.py" ]; then
    APP_DIR="${SCRIPT_DIR}"
else
    APP_DIR="/home/${APP_USER}/stepad-nsp"
fi

echo "==> [1/8] Usuario de aplicación"
id -u "${APP_USER}" >/dev/null 2>&1 || useradd -m -s /bin/bash "${APP_USER}"

echo "==> [2/8] Código"
if [ ! -d "${APP_DIR}/backend" ] || [ ! -f "${APP_DIR}/install.py" ]; then
    if [ ! -d "${APP_DIR}/.git" ]; then
        sudo -u "${APP_USER}" git clone -b "${REPO_BRANCH}" "${REPO_URL}" "${APP_DIR}"
    else
        sudo -u "${APP_USER}" git -C "${APP_DIR}" pull --ff-only origin "${REPO_BRANCH}"
    fi
fi
if [ "$(stat -c %U "${APP_DIR}")" != "${APP_USER}" ]; then
    chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"
fi

echo "==> [3/8] Dependencias del sistema"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y \
    git curl unzip build-essential \
    python3 python3-venv python3-pip \
    postgresql \
    wireguard-tools nftables dnsmasq pdns-recursor openssl \
    samba-common-bin iproute2 ethtool iputils-ping rclone \
    suricata suricata-update
systemctl enable postgresql
systemctl stop dnsmasq.service 2>/dev/null || true
systemctl disable dnsmasq.service 2>/dev/null || true
# dnsmasq lo maneja la app directamente (process_manager). Se MASKEA el
# servicio systemd para que nunca pueda arrancar y chocar (puerto 53 /
# UDP 67) con el dnsmasq de la app -> sin esto, en una instalacion
# limpia Debian deja el servicio habilitado y el DHCP puede no servir.
systemctl mask dnsmasq.service 2>/dev/null || true
# El filtrado web (reglas DOMAIN) depende de pdns-recursor: se deja
# habilitado para que arranque con el sistema (el NSP escribe su config).
systemctl enable pdns-recursor.service 2>/dev/null || true

echo "==> [4/8] Node.js (para el frontend)"
sudo -u "${APP_USER}" bash -lc '
    export NVM_DIR="$HOME/.nvm"
    if [ ! -s "$NVM_DIR/nvm.sh" ]; then
        curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    fi
    . "$NVM_DIR/nvm.sh"
    nvm install 22 || true
    nvm alias default 22 || true
' || true

echo "==> [5/8] Entorno Python"
sudo -u "${APP_USER}" python3 -m venv "${APP_DIR}/.venv"
sudo -u "${APP_USER}" "${APP_DIR}/.venv/bin/pip" install --upgrade pip
sudo -u "${APP_USER}" "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt"

echo "==> [6/8] Base de datos, secretos y administrador"
"${APP_DIR}/.venv/bin/python3" "${APP_DIR}/install.py"

echo "==> [7/8] Frontend"
sudo -u "${APP_USER}" bash -lc "
    export NVM_DIR=\"\$HOME/.nvm\"
    . \"\$NVM_DIR/nvm.sh\"
    cd \"${APP_DIR}/frontend\"
    npm install || true
    npm run build
" || echo "AVISO: no se pudo compilar el frontend (revisa node/npm)."

echo "==> [8/8] Servicio"
cp "${APP_DIR}/stepad-nsp.service" /etc/systemd/system/stepad-nsp.service
systemctl daemon-reload
systemctl enable stepad-nsp.service
# Arrancar el recursor antes del NSP: el NSP espera su socket de control
# hasta 20s y luego le carga la config de filtrado.
systemctl start pdns-recursor.service 2>/dev/null || true
systemctl start stepad-nsp.service

# Guardar la versión instalada (para el check de actualizaciones).
if [ -f "${SCRIPT_DIR}/VERSION" ]; then
    mkdir -p /etc/stepad
    cp "${SCRIPT_DIR}/VERSION" /etc/stepad/version
    echo "==> Versión instalada: $(cat /etc/stepad/version)"
fi

echo "==> [9/9] Suricata (IPS) - listo para activar"

# Config IPS: NFQUEUE 0 (en linea, modo IPS)
mkdir -p /etc/systemd/system/suricata.service.d
cat > /etc/systemd/system/suricata.service.d/override.conf <<'EOF'
[Service]
ExecStart=
ExecStart=/usr/bin/suricata -D -q 0 -c /etc/suricata/suricata.yaml --pidfile /run/suricata.pid
EOF

# Config Suricata: HOME_NET, modo IPS (NFQUEUE 0), reglas SNI de
# grupos y socket de control (script dedicado, sin heredoc).
mkdir -p /var/lib/suricata/rules
python3 "${SCRIPT_DIR}/scripts/configure_suricata.py"

# Suricata activo desde el arranque: el bloqueo por grupo (DNS+IP+SNI)
# y el IPS dependen de que la cola NFQUEUE sea procesada.
systemctl enable suricata.service >/dev/null 2>&1 || true

# Actualizacion diaria de reglas
cat > /usr/local/bin/stepad-suricata-update.sh <<'EOF'
#!/bin/bash
suricata-update >/tmp/suricata-update.log 2>&1 || exit 1
suricatasc -c reload-rules >/dev/null 2>&1
EOF
chmod +x /usr/local/bin/stepad-suricata-update.sh

cat > /etc/systemd/system/stepad-suricata-update.service <<'EOF'
[Unit]
Description=STEPAD Suricata signature update
[Service]
Type=oneshot
ExecStart=/usr/local/bin/stepad-suricata-update.sh
EOF

cat > /etc/systemd/system/stepad-suricata-update.timer <<'EOF'
[Unit]
Description=STEPAD Suricata signature update daily
[Timer]
OnCalendar=*-*-* 04:17:00
Persistent=true
[Install]
WantedBy=timers.target
EOF
systemctl enable stepad-suricata-update.timer >/dev/null 2>&1 || true

# Descarga inicial de reglas (best-effort; necesita internet)
echo "    Descargando reglas de Suricata (ET)..."
suricata-update >/tmp/suricata-update.log 2>&1 || true

# Suricata queda habilitado por defecto: el bloqueo por SNI (capa de
# respaldo al DNS) debe estar activo desde el arranque para no depender
# solo del DNS del cliente.
systemctl enable suricata.service >/dev/null 2>&1 || true


if [ -n "${TAILSCALE_KEY}" ]; then
    echo "==> [opcional] Uniendo el NSP a Tailscale..."
    curl -fsSL https://tailscale.com/install.sh | sh || true
    tailscale up --authkey="${TAILSCALE_KEY}" --hostname="${TAILSCALE_HOSTNAME}" || true
fi

echo
echo "======================================================"
echo "  STEPAD NSP INSTALADO"
echo "======================================================"
echo "  Web (desde la LAN o VPN):"
WEB_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [ -z "${WEB_IP}" ]; then
    WEB_IP="<IP-de-este-equipo>"
fi
echo "      https://${WEB_IP}:8443"
echo
echo "  Usuario: admin"
echo "  Contraseña: la que tengas configurada (cámbiala en"
echo "      Ajustes > Usuarios si lo necesitas)"
echo
echo "  IMPORTANTE al entrar:"
echo "    1. Activa la MFA (recomendado)."
echo "    2. Registra los datos de tu empresa."
echo "    3. Asigna las tarjetas WAN/LAN en 'Interfaces'."
echo "    4. Pon contraseña al usuario SSH (paulan): sudo passwd paulan"
echo "======================================================"
