#!/usr/bin/env bash
#
# Publica una versión de STEPAD NSP en paulvtorres/stepad-nsp-release.
#
# Flujo manual (el que usas en producción):
#   1. Tag + push en stepad-nsp (repo de desarrollo)
#   2. make-installer.sh -> stepad-nsp-installer-<tag>.tar.gz
#   3. Copiar a stepad-nsp-release como stepad-nsp-installer.tar.gz
#   4. git commit + push en stepad-nsp-release
#   5. Instalar/actualizar en cualquier NSP:
#        curl -fsSL https://raw.githubusercontent.com/paulvtorres/stepad-nsp-release/main/get-stepad.sh | sudo bash
#
# Uso:
#   bash scripts/publish-release.sh v2.5.12 "Descripción breve"
#
set -euo pipefail

VERSION="${1:-}"
NOTES="${2:-Release ${VERSION}}"

if [ -z "${VERSION}" ]; then
    echo "Uso: bash scripts/publish-release.sh <tag> [notas]"
    echo "Ejemplo: bash scripts/publish-release.sh v2.5.12 \"Seguridad de red\""
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEV_REPO="$(cd "${SCRIPT_DIR}/.." && pwd)"
RELEASE_REPO="${STEPAD_RELEASE_DIR:-/home/paulan/stepad-nsp-release}"
RELEASE_REMOTE="paulvtorres/stepad-nsp-release"
SIGNING_KEY="${STEPAD_SIGNING_KEY:-${HOME}/.config/stepad/update-signing.key}"

cd "${DEV_REPO}"

if ! git diff-index --quiet HEAD --; then
    echo "ERROR: stepad-nsp tiene cambios sin commitear. Commitea primero."
    git status --short
    exit 1
fi

echo "==> Versión: ${VERSION}"
echo "${VERSION}" > "${DEV_REPO}/VERSION"

git add VERSION
git commit -m "chore: bump version to ${VERSION}" || true

if git rev-parse "${VERSION}" >/dev/null 2>&1; then
    echo "==> Tag ${VERSION} ya existe"
else
    git tag -a "${VERSION}" -m "${NOTES}"
fi

echo "==> Empujando stepad-nsp..."
git push origin main
git push origin "${VERSION}"

echo "==> Construyendo instalador..."
bash "${DEV_REPO}/make-installer.sh"

# make-installer.sh nombra el paquete con `git describe --tags`
# (p. ej. v2.5.170-11-g3e63a52), que casi nunca coincide con el VERSION
# solicitado. Buscar por `${VERSION}*` podía tomar un paquete viejo de un
# release anterior y publicar código desactualizado. Siempre se usa el
# instalador recién construido (el más reciente por fecha).
INSTALLER=$(ls -t stepad-nsp-installer-*.tar.gz 2>/dev/null | head -1) || true

if [ ! -f "${DEV_REPO}/${INSTALLER}" ]; then
    echo "ERROR: no se generó ${INSTALLER}"
    exit 1
fi

if [ ! -f "${SIGNING_KEY}" ]; then
    echo "ERROR: falta la clave privada de firma: ${SIGNING_KEY}"
    echo "No se publica un instalador sin firma (fail-closed)."
    exit 1
fi

echo "==> Firmando instalador..."
SIGNATURE="${INSTALLER}.sig"
openssl pkeyutl -sign -inkey "${SIGNING_KEY}" -rawin \
    -in "${DEV_REPO}/${INSTALLER}" -out "${DEV_REPO}/${SIGNATURE}"

if [ ! -d "${RELEASE_REPO}/.git" ]; then
    echo "ERROR: no existe ${RELEASE_REPO}."
    echo "Clona el repo release:"
    echo "  git clone git@github.com:${RELEASE_REMOTE}.git ${RELEASE_REPO}"
    exit 1
fi

echo "==> Subiendo a ${RELEASE_REPO}..."
cp "${DEV_REPO}/get-stepad.sh" "${RELEASE_REPO}/get-stepad.sh"
cp "${DEV_REPO}/VERSION" "${RELEASE_REPO}/VERSION"
cp "${DEV_REPO}/${INSTALLER}" "${RELEASE_REPO}/stepad-nsp-installer.tar.gz"
cp "${DEV_REPO}/${INSTALLER}" "${RELEASE_REPO}/${INSTALLER}"
cp "${DEV_REPO}/${SIGNATURE}" "${RELEASE_REPO}/${SIGNATURE}"
cp "${DEV_REPO}/${SIGNATURE}" "${RELEASE_REPO}/stepad-nsp-installer.tar.gz.sig"
cp "${DEV_REPO}/scripts/update-signing.pub.pem" "${RELEASE_REPO}/update-signing.pub.pem"

cd "${RELEASE_REPO}"

git add get-stepad.sh VERSION stepad-nsp-installer.tar.gz "${INSTALLER}" \
    "${SIGNATURE}" stepad-nsp-installer.tar.gz.sig update-signing.pub.pem
git commit -m "release ${VERSION}: ${NOTES}"
git push origin main

echo ""
echo "Publicado. Instalar o actualizar desde cualquier terminal:"
echo ""
echo "  curl -fsSL https://raw.githubusercontent.com/${RELEASE_REMOTE}/main/get-stepad.sh | sudo bash"
echo ""
