#!/usr/bin/env python3
"""
Configura /etc/suricata/suricata.yaml para STEPAD NSP:
  - HOME_NET por defecto
  - Modo IPS (NFQUEUDAD 0, en linea)
  - Regla de bloqueo por grupo (stepad-sni.rules) en rule-files
  - Socket de control (suricatasc reload-rules)

Se ejecuta desde install.sh (como root) y desde las actualizaciones.
"""
import yaml

P = "/etc/suricata/suricata.yaml"
SNI_RULE = "/var/lib/suricata/rules/stepad-sni.rules"


def main() -> int:
    with open(P) as f:
        cfg = yaml.safe_load(f) or {}

    cfg.setdefault("vars", {}).setdefault(
        "address-groups", {}
    )["HOME_NET"] = "[192.168.50.0/24,10.200.0.0/24]"

    cfg["nfq"] = [{"mode": "ips", "queue": 0, "repeat-mark": "yes"}]

    # Se corre en modo NFQUEUE inline (-q 0). El yaml por defecto trae
    # `af-packet: eth0` (interfaz inexistente en muchos equipos). Se usa
    # `interface: default` (generico: enlaza las disponibles) para que
    # Suricata arranque sin depender del nombre de la NIC.
    cfg["af-packet"] = [{"interface": "default"}]

    rule_files = cfg.get("rule-files") or []
    if SNI_RULE not in rule_files:
        rule_files.append(SNI_RULE)
    cfg["rule-files"] = rule_files

    cfg["unix-command"] = {
        "enabled": True,
        "filename": "/var/run/suricata-command.socket",
    }

    with open(P, "w") as f:
        # Suricata exige el encabezado YAML 1.1 (safe_dump lo omite).
        f.write("%YAML 1.1\n---\n")
        yaml.safe_dump(cfg, f, default_flow_style=False, sort_keys=False)

    print("suricata.yaml configurado (IPS + reglas SNI + socket).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
