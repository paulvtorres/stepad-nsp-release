"""
STEPAD NSP non-interactive installer.

Run as root on a provisioned Debian (deps + repo + venv already in
place via install.sh). It:
  1. loads any existing secrets (idempotent re-runs),
  2. generates missing secrets,
  3. creates the PostgreSQL role + database,
  4. creates the tables,
  5. creates the initial administrator (password printed once),
  6. writes /etc/stepad/stepad.env and the admin credentials file.
"""

import os
import secrets
import subprocess

from pathlib import Path

ENV_FILE = Path("/etc/stepad/stepad.env")

CREDENTIALS_FILE = Path("/etc/stepad/stepad-admin-credentials.txt")


def load_existing_env():

    values = {}

    if ENV_FILE.exists():

        for line in ENV_FILE.read_text(
            encoding="utf-8"
        ).splitlines():

            line = line.strip()

            if not line or "=" not in line or line.startswith("#"):

                continue

            key, value = line.split("=", 1)

            values[key.strip()] = value.strip().strip("\"'")

    return values


# ------------------------------------------------------------------
# Resolve secrets BEFORE importing backend modules so Settings picks
# them up from os.environ (Settings is evaluated at import time).
# ------------------------------------------------------------------
existing = load_existing_env()

db_password = (
    existing.get("DB_PASSWORD")
    or os.getenv("DB_PASSWORD")
    or secrets.token_urlsafe(16)
)

jwt_secret = (
    existing.get("STEPAD_JWT_SECRET")
    or os.getenv("STEPAD_JWT_SECRET")
    or secrets.token_urlsafe(48)
)

db_host = existing.get("DB_HOST") or os.getenv("DB_HOST") or "127.0.0.1"

db_port = existing.get("DB_PORT") or os.getenv("DB_PORT") or "5432"

db_name = existing.get("DB_NAME") or os.getenv("DB_NAME") or "stepad_nsp"

db_user = existing.get("DB_USER") or os.getenv("DB_USER") or "stepad_app"

admin_password = os.getenv("STEPAD_ADMIN_PASSWORD", "$Coys0318")

os.environ["STEPAD_ENV"] = "production"

os.environ["DB_PASSWORD"] = db_password

os.environ["DB_HOST"] = db_host

os.environ["DB_PORT"] = db_port

os.environ["DB_NAME"] = db_name

os.environ["DB_USER"] = db_user

os.environ["STEPAD_JWT_SECRET"] = jwt_secret

os.environ["STEPAD_DNS_ENGINE"] = "powerdns_rpz"


# Now the backend modules can be imported safely.
from backend.core.database.connection import engine
from backend.core.database.base import Base
from backend.core.database.session import SessionLocal

from backend.network.devices.models.network_device import NetworkDevice
from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.users.models.user import User
from backend.audit.models.audit_log import AuditLog
from backend.nat.models.port_forward import PortForward
from backend.vpn.models.vpn_peer import VpnPeer
from backend.notifications.models.notification_settings import NotificationSettings
from backend.backups.models.backup_settings import BackupSettings
from backend.organization.models.organization_settings import OrganizationSettings
from backend.alerts.models.alert import Alert
from backend.siem.models.syslog_settings import SyslogSettings
from backend.siem.models.compliance_settings import ComplianceSettings
from backend.content.models.content_category import ContentCategory, CategoryDomain
from backend.config_revisions.models.config_revision import ConfigRevision
from backend.network.zones.models.network_zone import NetworkZone
from backend.network.zones.models.schedule import Schedule
from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.network.interfaces.registry.models.managed_interface import (
    ManagedInterface
)

from backend.users.services.user_service import UserService
from backend.users.security.password_hasher import PasswordHasher


def psql(sql: str) -> str:

    result = subprocess.run(
        ["runuser", "-u", "postgres", "--", "psql", "-tAc", sql],
        capture_output=True,
        text=True
    )

    return result.stdout.strip()


def ensure_database():

    role = psql(
        f"SELECT 1 FROM pg_roles WHERE rolname='{db_user}'"
    )

    if not role:

        psql(
            f"CREATE ROLE {db_user} LOGIN PASSWORD '{db_password}'"
        )

        print(f"✓ PostgreSQL role '{db_user}' created")

    else:

        psql(
            f"ALTER ROLE {db_user} WITH LOGIN PASSWORD '{db_password}'"
        )

        print(f"✓ PostgreSQL role '{db_user}' ready")

    database = psql(
        f"SELECT 1 FROM pg_database WHERE datname='{db_name}'"
    )

    if not database:

        psql(f"CREATE DATABASE {db_name} OWNER {db_user}")

        print(f"✓ PostgreSQL database '{db_name}' created")

    else:

        print(f"✓ PostgreSQL database '{db_name}' ready")


def write_env_file():

    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)

    ENV_FILE.write_text(
        "\n".join([
            "STEPAD_ENV=production",
            "STEPAD_DNS_ENGINE=powerdns_rpz",
            f"DB_HOST={db_host}",
            f"DB_PORT={db_port}",
            f"DB_NAME={db_name}",
            f"DB_USER={db_user}",
            f"DB_PASSWORD={db_password}",
            f"STEPAD_JWT_SECRET={jwt_secret}",
            "STEPAD_VPN_REQUIRE_REMOTE_ADMIN=false",
        ]) + "\n",
        encoding="utf-8"
    )

    ENV_FILE.chmod(0o600)

    print(f"✓ Runtime secrets written to {ENV_FILE} (mode 0600)")


def install():

    print("========================================")
    print("      STEPAD NSP Installation")
    print("========================================")

    ensure_database()

    # El esquema lo crea Alembic (backend/scripts/migrate_schema.py,
    # llamado desde install.sh y desde el arranque del servicio). Aqui
    # NO se usa create_all: la migracion es la fuente unica de verdad.
    print("✓ Base de datos lista (esquema vía Alembic)")

    write_env_file()

    db = SessionLocal()

    try:

        hasher = PasswordHasher()

        service = UserService()

        existing_admin = (
            db.query(User)
            .filter(User.username == "admin")
            .first()
        )

        if existing_admin:

            print("✓ Administrator user already exists (password unchanged)")

        else:

            service.create_admin(
                db=db,
                username="admin",
                password_hash=hasher.hash(admin_password)
            )

            print("✓ Administrator user created")

            CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)

            CREDENTIALS_FILE.write_text(
                f"username=admin\npassword={admin_password}\n",
                encoding="utf-8"
            )

            CREDENTIALS_FILE.chmod(0o600)

            print()
            print("  Administrator user created (admin).")
            print(
                "  No se muestra la contraseña en pantalla; usa la "
                "predeterminada o cámbiala en Usuarios."
            )
            print()

    finally:

        db.close()

    print("========================================")
    print(" Installation completed successfully")
    print("========================================")


if __name__ == "__main__":

    install()
