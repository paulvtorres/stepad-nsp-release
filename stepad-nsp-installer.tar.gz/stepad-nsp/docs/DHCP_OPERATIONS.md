# DHCP operativo

## Principio: el pool es FIJO
El segmento y el pool están configurados como deben ser. STEPAD **nunca**
amplía el pool. Su trabajo es:

1. entregar IP a todo equipo mientras quede una libre,
2. liberar lo que no se usa para que siempre haya una disponible,
3. **avisar** cuando ya no queda nada por liberar.

## Estados de una IP
- **Reservada** (`permanent_ip`): nunca se libera ni se ofrece a otro equipo.
- **En uso**: el equipo está presente (ver `DEVICE_PRESENCE.md`).
- **Retenida**: lease de un equipo ausente. Se recicla cuando hace falta.
- **Libre**: disponible para dnsmasq.

## Reciclaje de leases
Se libera el lease de un equipo solo si:

- la **presencia** lo da OFFLINE (sin ARP alcanzable, DNS ni respuesta a la
  verificación activa en los últimos 30 min). No se usa el ARP crudo: el
  kernel conserva entradas de equipos que ya se fueron,
- no tiene reserva (`permanent_ip`) ni es infraestructura,
- y lleva más de `pool_emergency_reclaim_minutes` (60 por defecto) sin
  señales fuertes (`last_seen`).

Con el pool **agotado** (0 libres) o cuando dnsmasq rechaza a un equipo con
"no address available", no se espera esa ventana: alcanza con que la
presencia diga OFFLINE. Un equipo conectado nunca pierde su IP.

Si no hay presencia confiable (falla la lectura de la red o de la base) no
se libera nada.

Se libera hasta recuperar `pool_reclaim_target_free` direcciones (10 por
defecto). El cooldown entre intentos es de 60 s por defecto (0 es válido); no
aplica con el pool agotado ni tras un "no address available".

## Zonas (VLAN / 2da LAN)
Cada zona tiene su propio `dhcp-range`, y se vigila igual que el pool
principal: umbral propio (el automático, con tope del 50 % de sus IPs para que
una zona chica no viva en alerta), alertas por zona y reciclaje **solo de los
leases de esa zona** (liberar IPs de otra no le daría espacio). Una zona cuyo
rango ya está dentro del pool principal no se cuenta dos veces.

- `DHCP_ZONE_POOL_LOW` (aviso) y `DHCP_ZONE_POOL_EXHAUSTED` (crítica): el
  título lleva el nombre de la zona; se resuelven solas, una por una, y si la
  zona se elimina no quedan alertas colgadas.
- El aviso «no address available» de dnsmasq no dice de qué rango vino, así
  que solo acelera el pool principal; cada zona actúa por su propio estado.

## Liberación en caliente (`dhcp_release`)
Para reciclar, el NSP usa `dhcp_release` (paquete `dnsmasq-utils`): avisa a
dnsmasq, que sigue corriendo, y este borra el lease. **No se reinicia el
DHCP** (antes se detenía dnsmasq, se editaba el archivo y se arrancaba, y
`apply` reiniciaba una segunda vez, justo con el pool agotado).

- La interfaz se deduce de la IP con las direcciones reales del kernel
  (principal, alias y VLAN); si el lease tiene client-id, se pasa.
- Nunca se da por hecho: se verifica contra el archivo de leases (hasta 2 s).
  Lo que no desaparezca se libera con el método anterior (detener, editar,
  arrancar) y solo entonces se reinicia.
- En máquinas ya instaladas: `sudo apt install dnsmasq-utils`. Sin el
  paquete todo sigue funcionando con el método anterior.

## Aviso de tendencia (con memoria)
Cada pool (principal y zonas) tiene su serie de IPs libres, muestreada siempre
(una vez por minuto como máximo) y guardada en `dns/pool_samples.json`: al
reiniciar el NSP no se pierde y el aviso no tarda otra hora en poder calcularse.

El ritmo sale de una recta por mínimos cuadrados sobre la última hora, no de
«primer punto vs último»: el reciclaje hace dientes de sierra (baja, se liberan
IPs, sube) y comparar dos puntos engaña. Se exige un mínimo de 4 muestras
repartidas en 5 minutos y un consumo de al menos 1 IP/hora (menos es ruido).

- `DHCP_POOL_TREND` (principal) y `DHCP_ZONE_POOL_TREND` (zona, con su nombre):
  se avisa al empezar la tendencia, una sola vez, y se resuelve sola cuando
  deja de cumplirse o cuando la zona se elimina.
- Se avisa si el pool se agotaría dentro del horizonte (24 h por defecto).
- Ajustes (Red → DHCP → Alertas): `pool_trend_alert_enabled` (activo) y
  `pool_trend_horizon_hours` (1–168).

## Correo por zona
Las zonas usan los mismos destinatarios que el aviso del pool principal. Se
envía al bajar de su umbral y al recuperarse (una vez por transición); el
asunto y el texto llevan el nombre de la zona.

## Ajustes en pantalla (Red → DHCP → Alertas)
Limpieza anticipada (activar y minutos de ausencia, 30–2880) y aviso de
tendencia (activar y horizonte) ya no requieren editar `config.yaml`.

## Por qué el lease NO es adaptativo
Cambiar el `lease_time` implica reescribir `dhcp-range` y **reiniciar
dnsmasq** (SIGHUP no relee `dnsmasq.conf`). Un lease que se acorta cuando el
pool se llena reiniciaría el DHCP justo en ese momento, que es lo que este
diseño evita. El mismo objetivo lo cubren, sin reinicio, la limpieza
anticipada y el reciclaje con `dhcp_release`. Si el pool se llena de equipos
conectados de verdad, ni un lease corto ayuda: hay que ampliar el rango o
revisar qué equipos hay (la alerta crítica lo indica).

## Panel por zona
El resumen del DHCP muestra una tarjeta «Zonas» con el pool de cada zona
adicional (usadas, libres, umbral y estado). Sale de las mismas funciones que
usan las alertas y el reciclaje (`zone_pool_specs` y las constantes de
`dhcp/domain/pool.py`), así que lo que ves es exactamente lo que dispara
`DHCP_ZONE_POOL_LOW` y `DHCP_ZONE_POOL_EXHAUSTED`. La zona por defecto de una
red simple no aparece aparte: su rango es el del pool principal.

## «No address available» sabe de qué pool vino
dnsmasq escribe la interfaz en la línea del evento
(`DHCPDISCOVER(enp3s0.30) … no address available`). El monitor la lee y el
reciclaje apunta al pool de esa interfaz (principal o zona), deducida del
rango y de las direcciones reales del servidor. Si varios pools comparten
interfaz (alias) se marcan todos; sin dato o sin coincidencia, solo el
principal, como antes. El MAC de la alerta sale de esa misma línea (antes era
el primero del fragmento del log, que podía ser de otro evento).

## Zona por defecto = segmento principal
La zona por defecto de la LAN principal se crea copiando el segmento y el pool
de «Segmento y pool». Desde ahora **sigue a ese segmento**: al cambiarlo
(`set_lan_segment`), la zona se alinea (red, gateway y pool) y se reescribe
`zones.conf` antes del único reinicio de dnsmasq. Antes `zones.conf` seguía con
el rango y el gateway viejos (las `dhcp-option` 3 y 6 sin etiqueta son las de
esa zona).

Solo se alinea la zona por defecto que vive en la tarjeta LAN principal. Una
VLAN o una 2.ª LAN marcada como «por defecto» tiene su propio segmento y no se
toca. Las zonas adicionales se crean a mano con su CIDR y su pool.

## Orden del reciclaje: quién vuelve menos, sale primero
El orden solo reparte entre candidatos ya elegibles (OFFLINE, sin reserva, no
infraestructura, pasada la ventana de inactividad): **nunca** vuelve elegible
a un equipo. De menos a más probable que vuelva:

0. Sin nombre y MAC aleatoria (bit «administrada localmente», p. ej. celulares
   con dirección privada) o visita de menos de 1 hora.
1. Sin nombre, conocido hace menos de 3 días.
2. Sin nombre, conocido hace más tiempo (o sin datos).
3. Con nombre puesto por el admin.
4. Activo de la empresa.

Dentro de cada nivel, el que lleva más tiempo sin verse sale primero.

## Limpieza anticipada
Cuando un pool baja de su holgura (el mayor entre 2 × el umbral y el 15 % de
sus IPs dinámicas) pero todavía no está «bajo», se liberan con calma solo los
equipos del nivel 0 ausentes hace horas. Reglas:

- **Solo en caliente** (`dhcp_release`). Si la herramienta no está o dnsmasq
  no corre, no se hace nada: nunca se reinicia dnsmasq por una limpieza
  anticipada.
- Sin alerta (queda en el log) y con su propio cooldown (10 min).
- Configurable en la sección `dhcp`: `pool_proactive_reclaim_enabled`
  (por defecto activo), `pool_proactive_offline_minutes` (360) y
  `pool_proactive_cooldown_seconds` (600).

## Eventos de lease (tiempo real)
dnsmasq avisa de cada lease nuevo, renovación y liberación mediante
`dhcp-script`:

    dnsmasq -> dhcp-event.sh -> spool (dhcp-events.jsonl) -> NSP
                                                  |-> presencia (segundos)
                                                  |-> IPAM

- El script lo genera STEPAD (`<STEPAD_DIR>/dns/dhcp-event.sh`, root, 0750).
  Solo anota una línea y sale con 0: no puede frenar a dnsmasq. No incluye
  el hostname (texto libre del cliente).
- Se activa solo si el dnsmasq instalado declara `--dhcp-script`; y
  `script-on-renewal` solo si lo declara. Si no, no se emite nada (una
  opción desconocida haría que `dnsmasq --test` rechace toda la
  configuración) y el sondeo de 60 s sigue cubriendo.
- Se desactiva con `STEPAD_DHCP_EVENTS=0`.
- La primera vez que aparece la línea en la configuración dnsmasq se
  reinicia una vez.
- Si no llegan eventos: ejecutar a mano
  `sh <STEPAD_DIR>/dns/dhcp-event.sh add aa:bb:cc:dd:ee:ff 192.168.1.50` y ver
  si aparece una línea en el spool. Si no aparece, revisar permisos y el
  perfil de AppArmor/SELinux de dnsmasq (puede impedir ejecutar el script;
  `dnsmasq --test` no lo detecta).
- **Autochequeo:** si el archivo de leases de dnsmasq cambia y no llega ningún
  evento en 5 minutos, el NSP crea la alerta `DHCP_EVENTS_SILENT` (aviso) con
  la prueba a hacer; se resuelve sola cuando vuelven los eventos. Una red en
  calma, sin cambios de leases, nunca da falsa alarma. Mientras tanto la
  presencia sigue funcionando por sondeo cada 60 s.
- El spool se rota a los 256 KB. Un evento perdido en esa ventana lo cubre
  el sondeo.

## Velocidad de asignación: ping previo (`ping_check`)
dnsmasq, por defecto, hace un ping antes de ofrecer una IP **nueva** y espera
hasta 3 s por tanda. Medido con dnsmasq real:

| Escenario | Con ping | Sin ping |
|---|---|---|
| 30 equipos nuevos a la vez | 18 s | — |
| 120 equipos nuevos a la vez | ~70 s (estimado) | **0,6 s** |
| Equipos que ya tienen lease | instantáneo | instantáneo |

Tras un corte de luz largo (leases vencidos) todos los equipos son "nuevos":
con el ping, algunos se quedan en 169.254.x.x (Windows reintenta cada 5 min).
Por eso el NSP escribe `no-ping` por defecto. El ping previo era una defensa
débil (los equipos Windows con firewall no contestan) y las IPs fijas dentro del
pool ya las protege el NSP con ARP verificado. Se puede reactivar en
DHCP → Alertas → *Velocidad de asignación*.

## Estructura del reconciliador
`reconciler.py` orquesta; el resto vive en módulos con una sola responsabilidad:
`reconciler_alerts.py` (alertas de capacidad del pool) y
`reconciler_reclaim.py` (reciclaje de leases). Los conflictos de IP siguen en
`reconciler.py` junto a las lecturas de ARP y leases.

## Lease
- Valor actual: 8h. Se configura en DHCP → Segmento y pool.
- Un lease corto hace que las IPs de equipos que se fueron queden libres sin
  intervención. Las reservas no dependen del lease.

## Alertas
- `DHCP_POOL_LOW`: quedan pocas IPs (un solo aviso al cruzar el umbral).
- `DHCP_POOL_EXHAUSTED` (crítica): 0 IPs libres. Si persiste, el pool está
  lleno de equipos conectados.
- `DHCP_NO_ADDRESS` (crítica): un equipo pidió IP y no había.
- `DHCP_POOL_TREND`: tendencia de agotamiento.
- `DHCP_POOL_RECLAIMED`: IPs recicladas.
- `DHCP_POOL_RECOVERED`: el pool volvió a tener espacio (un solo aviso).
- `DHCP_RESERVED_IP_OCCUPIED`: reserva ocupada por otra MAC.
- `DHCP_IP_DUPLICATE_ACTIVE`: una IP asignada por DHCP la usa otra MAC.

Las alertas del DHCP se **resuelven solas** cuando la condición desaparece
(pool con espacio, conflicto terminado): así el escalamiento no avisa de algo
que ya pasó. Una alerta crítica que se repite envía como máximo un correo por
ventana (el límite es compartido entre todas las instancias del servicio de
alertas) y un webhook por hora.

## IPs y conflictos
- Las asignaciones (reserva o lease) viven en `ip_assignments`; hay una sola
  activa por IP.
- Lo observado en la red (`device_ip_observations`) no está sujeto a esa
  unicidad: así un conflicto real se ve en lugar de ocultarse.
- `device_ip_history` conserva las IPs anteriores de cada equipo.

## Recuperación
- Componentes importantes: reintentos y supervisor.
- Componentes críticos: fallo → systemd reinicia el NSP.
- Watchdog externo: 3 fallos de `/healthz` → reinicia `stepad-nsp`.

## Dependencias externas
- HA/segundo DHCP requiere infraestructura.
- El correo de alertas requiere SMTP y destinatarios configurados.
