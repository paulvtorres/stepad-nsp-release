from backend.core.database.connection import engine
from backend.core.database.base import Base

# Importa TODOS los modelos (registra todas las tablas en Base.metadata).
from backend.core.database import models_registry  # noqa: F401


Base.metadata.create_all(engine)

print("Tables created")
