from backend.core.database.connection import engine
from backend.core.database.base import Base

from backend.network.devices.models.network_device import NetworkDevice
from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.users.models.user import User


Base.metadata.create_all(engine)

print("Tables created")