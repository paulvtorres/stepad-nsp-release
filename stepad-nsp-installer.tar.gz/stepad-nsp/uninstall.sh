#!/usr/bin/env bash
#
# STEPAD NSP - desinstalación completa (deja el equipo como antes de
# instalar, listo para reinstalar desde 0).
#
# Uso (como root):
#   sudo bash uninstall.sh            (pide confirmación por teclado)
#   sudo bash uninstall.sh --yes      (sin preguntar)
#
set -euo pipefail

APP_USER="${APP_USER:-paulan}"
APP_DIR="/home/${APP_USER}/stepad-nsp"
DB_NAME="stepad_nsp"
DB_USER="stepad_app"

if [ "$(id -u)" -ne 0 ]; then
    echo "Ejecuta como root: sudo bash uninstall.sh"
    exit 1
fi

if [ "${1:-}" != "--yes" ]; then
    echo ""
    echo "======================================================================"
    echo "  DESINSTALACIÓN DE STEPAD NSP"
    echo "  Se borrarán TODOS los datos del NSP: configuración, base de datos,"
    echo "  reglas de firewall, VPN y servicios. La máquina queda lista para"
    echo "  reinstalar desde 0."
    echo "======================================================================"
    echo ""
    printf "¿Estás seguro? Escribe SI para confirmar: "
    read -r CONFIRM
    if [ "${CONFIRM}" != "SI" ] && [ "${CONFIRM}" != "si" ]; then
        echo "Cancelado."
        exit 1
    fi
fi

echo "==> [1/8] Deteniendo y quitando servicios de NSP"
UNITS="$(systemctl list-unit-files --no-legend --type=service,timer 2>/dev/null | awk '$1 ~ /^stepad-/ {print $1}')"
for u in ${UNITS}; do
    systemctl stop "${u}" 2>/dev/null || true
    systemctl disable "${u}" 2>/dev/null || true
    echo "    - ${u}"
done
rm -f /etc/systemd/system/stepad-*.service /etc/systemd/system/stepad-*.timer
rm -rf /etc/systemd/system/stepad-nsp.service.d
systemctl daemon-reload

echo "==> [2/8] Quitando la carpeta de la aplicación"
rm -rf "${APP_DIR}"

echo "==> [3/8] Quitando configuración (/etc/stepad)"
rm -rf /etc/stepad

echo "==> [4/8] Quitando la base de datos y el rol"
sudo -u postgres psql -tAc "DROP DATABASE IF EXISTS ${DB_NAME};" >/dev/null 2>&1 || true
sudo -u postgres psql -tAc "DROP ROLE IF EXISTS ${DB_USER};" >/dev/null 2>&1 || true

echo "==> [5/8] Quitando reglas de firewall (tabla stepad)"
if nft list tables 2>/dev/null | grep -q "table inet stepad"; then
    nft delete table inet stepad
fi

echo "==> [6/8] Quitando interfaz VPN (wg0)"
if ip link show wg0 >/dev/null 2>&1; then
    ip link del wg0
fi

echo "==> [7/8] Limpiando dnsmasq del NSP"
rm -f /etc/dnsmasq.d/stepad-*.conf 2>/dev/null || true
pkill -f "dnsmasq.*stepad" 2>/dev/null || true

echo "==> [8/8] Deteniendo pdns-recursor (lo usaba el filtrado del NSP)"
systemctl stop pdns-recursor.service 2>/dev/null || true
systemctl disable pdns-recursor.service 2>/dev/null || true

echo ""
echo "======================================================"
echo "  DESINSTALACIÓN COMPLETA."
echo "  Ya puedes reinstalar desde 0 con el instalador."
echo "======================================================"
