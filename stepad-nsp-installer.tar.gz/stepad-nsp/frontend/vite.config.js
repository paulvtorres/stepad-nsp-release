import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";


export default defineConfig(({ mode }) => {

    // Reads VITE_BACKEND_URL from .env.local if present (gitignored
    // via the existing *.local pattern) -- lets each machine/dev
    // point at a different backend without ever touching this file.
    // Falls back to localhost, which is correct for the common case
    // of frontend and backend running on the same box.
    const env = loadEnv(mode, process.cwd(), "");

    const backendUrl = env.VITE_BACKEND_URL || "https://localhost:8443";

    return {

        plugins: [react()],

        server: {

            host: "0.0.0.0",

            port: 5173,

            proxy: {

                "/api": {

                    target: backendUrl,

                    changeOrigin: true,

                    secure: false

                }

            }

        }

    };

});
