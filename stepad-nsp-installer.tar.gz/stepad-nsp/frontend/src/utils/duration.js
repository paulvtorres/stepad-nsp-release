/**
 * Duración legible: 90 -> "1m", 3700 -> "1h 1m", 90000 -> "1d 1h".
 * (Estaba definida dentro de Monitoring.jsx pero OutagesCard la usaba
 * sin importarla: la tarjeta de cortes fallaba en tiempo de ejecución.)
 */
export function formatDuration(seconds) {
    if (seconds == null) return "—";
    const m = Math.floor(seconds / 60);
    const h = Math.floor(m / 60);
    const d = Math.floor(h / 24);
    if (d > 0) return `${d}d ${h % 24}h`;
    if (h > 0) return `${h}h ${m % 60}m`;
    if (m > 0) return `${m}m`;
    return `${seconds}s`;
}
