import { apiClient } from "./apiClient";


const diagnosisEndpoints = {

    dhcp: "/dhcp/diagnosis",

    dns: "/dns/diagnosis",

    firewall: "/firewall/diagnosis"

};



export async function getComponentDiagnosis(
    component
) {


    const endpoint = diagnosisEndpoints[component];


    if (!endpoint) {

        throw new Error(
            `No diagnosis endpoint for ${component}`
        );

    }


    return await apiClient.get(
        endpoint
    );

}



export function hasDiagnosis(
    component
) {

    return Boolean(
        diagnosisEndpoints[component]
    );

}