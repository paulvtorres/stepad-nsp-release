import { getToken } from "../auth/authStorage";
import { notifyAuthExpired } from "../auth/authEvents";

// Matches userService.js's hardcoded "/api/v1" -- this needs the
// same default. Without it, every page except login/auth (which
// uses userService.js, not this file) silently breaks: fetch()
// resolves "undefined/interfaces/..." as a relative path that never
// reaches Vite's "/api" proxy rule, and Vite serves its own
// index.html for the unmatched route instead -- which is why the
// error in the browser console is a JSON parse failure on HTML
// ("Unexpected token '<'"), not a network error.
const API_URL = import.meta.env.VITE_API_URL || "/api/v1";


async function request(
    endpoint,
    options = {}
) {


    const token = getToken();

    const response = await fetch(

        `${API_URL}${endpoint}`,

        {
            ...options,

            headers: {

                "Content-Type":
                    "application/json",


                ...(token && {

                    Authorization:
                        `Bearer ${token}`

                }),


                ...options.headers

            }

        }

    );



    if (response.status === 401) {

        notifyAuthExpired();

        throw new Error("Unauthorized");

    }

    if (!response.ok) {

        let detail = `API Error ${response.status}`;

        try {

            const body = await response.json();

            if (body && body.detail) {

                detail = body.detail;

            }

        } catch {

            // response wasn't JSON -- keep the generic message

        }

        throw new Error(detail);

    }



    const contentType = response.headers.get("content-type") || "";

    if (!contentType.includes("application/json")) {

        throw new Error(
            `Respuesta inesperada (${contentType || "no JSON"}) en ${endpoint}`
        );

    }



    return response.json();

}



export const apiClient = {


    get(endpoint) {

        return request(
            endpoint
        );

    },


    post(endpoint, data) {

        return request(

            endpoint,

            {

                method: "POST",

                body:
                    JSON.stringify(data)

            }

        );

    },


    patch(endpoint, data) {

        return request(

            endpoint,

            {

                method: "PATCH",

                body:
                    JSON.stringify(data)

            }

        );

    },


    put(endpoint, data) {

        return request(

            endpoint,

            {

                method: "PUT",

                body:
                    JSON.stringify(data)

            }

        );

    },


    delete(endpoint) {

        return request(

            endpoint,

            {

                method: "DELETE"

            }

        );

    },


    async download(endpoint) {

        const token = getToken();

        const response = await fetch(

            `${API_URL}${endpoint}`,

            {
                headers: {

                    ...(token && {

                        Authorization:
                            `Bearer ${token}`

                    })

                }
            }

        );

        if (response.status === 401) {

            notifyAuthExpired();

            throw new Error("Unauthorized");

        }

        if (!response.ok) {

            throw new Error(`API Error ${response.status}`);

        }

        return response.blob();

    }


};