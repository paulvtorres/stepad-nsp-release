import { apiClient } from "./apiClient";

export async function getSystemStatus() {

    return await apiClient.get("/system/status");

}