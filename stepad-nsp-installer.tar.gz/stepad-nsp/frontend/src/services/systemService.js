import { apiClient } from "./apiClient";

export async function getSystemStatus() {

    return await apiClient.get("/system/status");

}

export async function getNavigationStatus() {

    return await apiClient.get("/system/navigation-status");

}

export async function getZoneIsolationStatus() {

    return await apiClient.get("/zones/isolation");

}

export async function getMalwareEvents(limit = 5) {

    return await apiClient.get(`/ips/malware-events?limit=${limit}`);

}

export async function getLiveBrowsing() {

    return await apiClient.get("/logs/navigation/live");

}