import { apiClient } from "./apiClient";

export async function getSystemStatus() {

    return await apiClient.get("/system/status");

}

export async function getNavigationStatus() {

    return await apiClient.get("/system/navigation-status");

}