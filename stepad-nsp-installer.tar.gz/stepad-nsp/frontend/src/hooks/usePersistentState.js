import { useEffect, useState } from "react";


/**
 * Estado que sobrevive a la navegación y a recargar el panel.
 *
 * Se guarda en localStorage con JSON. Si el navegador no permite
 * almacenamiento (modo privado, cuota llena) el estado sigue viviendo en
 * memoria: la pantalla nunca se rompe por esto.
 *
 * Uso:
 *   const [sortKey, setSortKey] = usePersistentState("devices.sortKey", "status");
 */
export function usePersistentState(key, initialValue) {
    const [value, setValue] = useState(function () {
        try {
            const raw = window.localStorage.getItem(key);
            return raw === null ? initialValue : JSON.parse(raw);
        } catch {
            return initialValue;
        }
    });

    useEffect(function () {
        try {
            window.localStorage.setItem(key, JSON.stringify(value));
        } catch {
            /* sin almacenamiento: se mantiene solo en memoria */
        }
    }, [key, value]);

    return [value, setValue];
}
