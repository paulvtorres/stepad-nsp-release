import { describe, expect, it } from "vitest";

import {
    getBottlenecks,
    getFlowSeconds,
    getServices,
    getTopConsumers,
} from "../liveOperationsUtils";

describe("operación en vivo", () => {
    it("ordena consumidores reales y calcula su participación", () => {
        const result = getTopConsumers({
            devices: [
                { name: "PC", ip: "10.0.0.2", rx_mbps: 5, tx_mbps: 5 },
                { name: "TV", ip: "10.0.0.3", rx_mbps: 20, tx_mbps: 0 },
                { name: "Este equipo (NSP)", ip: "10.0.0.1", rx_mbps: 99, tx_mbps: 0 },
            ],
        });

        expect(result.map((item) => item.name)).toEqual(["TV", "PC"]);
        expect(result[0].share).toBe(66.66666666666666);
        expect(result[0].width).toBe(100);
    });

    it("detecta servicios caídos, recursos altos y pool bajo", () => {
        const result = getBottlenecks({
            system: {
                components: {
                    dns: { status: "failed" },
                    dhcp: { status: "running" },
                },
            },
            operationalHealth: { checks: [] },
            monitoring: { cpu_percent: 95, ram_percent: 20, disk_percent: 91 },
            pool: {
                overall: { low: true, free: 2, threshold: 5 },
                zones: [{ name: "Invitados", low: true, free: 0, threshold: 2 }],
            },
            bandwidthError: "",
        });

        expect(result.some((item) => item.title === "DNS no operativo")).toBe(true);
        expect(result.some((item) => item.title === "CPU alta")).toBe(true);
        expect(result.some((item) => item.title === "Disco casi lleno")).toBe(true);
        expect(result.some((item) => item.title === "Pool DHCP bajo")).toBe(true);
        expect(result.some((item) => item.title.includes("Invitados"))).toBe(true);
    });

    it("no inventa problemas cuando todo está operativo", () => {
        const result = getBottlenecks({
            system: {
                components: { dns: { status: "running" }, dhcp: { status: "running" } },
            },
            operationalHealth: { checks: [] },
            monitoring: { cpu_percent: 10, ram_percent: 20, disk_percent: 30 },
            pool: { overall: { low: false }, zones: [] },
            bandwidthError: "",
        });

        expect(result).toEqual([]);
    });

    it("acelera el flujo con más tráfico y se detiene sin tráfico", () => {
        expect(getFlowSeconds(0, 100)).toBe(0);
        expect(getFlowSeconds(100, 100)).toBeLessThan(getFlowSeconds(10, 100));
    });

    it("muestra solo servicios presentes", () => {
        expect(
            getServices({ components: { dns: { status: "running" } } })
        ).toEqual([
            { name: "dns", label: "DNS", icon: "◎", state: "running" },
        ]);
    });
});
