export default function Dialog({

    title,

    open,

    onClose,

    children

}) {

    if (!open) {

        return null;

    }

    return (

        <div className="dialog-overlay">

            <div className="dialog">

                <div className="dialog-header">

                    <h2>

                        {title}

                    </h2>

                    <button
                        onClick={onClose}
                    >
                        ✕
                    </button>

                </div>

                <div className="dialog-body">

                    {children}

                </div>

            </div>

        </div>

    );

}