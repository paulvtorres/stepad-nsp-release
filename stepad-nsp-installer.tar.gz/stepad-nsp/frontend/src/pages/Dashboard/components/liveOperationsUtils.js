const SERVICE_LABELS = {
    dns: "DNS",
    dhcp: "DHCP",
    firewall: "Firewall",
    zones: "Zonas",
    network: "Red",
    api: "API",
};

const SERVICE_ICONS = {
    dns: "◎",
    dhcp: "⇄",
    firewall: "▣",
    zones: "⬡",
    network: "⌁",
    api: "◇",
};

export function formatMbps(value) {
    const number = Number(value || 0);

    if (number >= 1000) return `${(number / 1000).toFixed(2)} Gb/s`;

    return `${number.toFixed(number >= 10 ? 1 : 2)} Mb/s`;
}

export function getFlowSeconds(totalMbps, referenceMbps) {
    const total = Math.max(0, Number(totalMbps) || 0);

    if (total <= 0.01) return 0;

    const reference = Math.max(10, Number(referenceMbps) || 0);

    const load = Math.min(1, total / reference);

    return Number((2.8 - load * 2.0).toFixed(2));
}

export function getTopConsumers(bandwidth, limit = 5) {
    const devices = Array.isArray(bandwidth?.devices) ? bandwidth.devices : [];

    const visible = devices.filter(
        (device) => device && device.name !== "Este equipo (NSP)"
    );

    const total = visible.reduce(
        (sum, device) => sum
            + Number(device.rx_mbps || 0)
            + Number(device.tx_mbps || 0),
        0
    );

    const ordered = visible
        .map((device) => {
            const rx = Number(device.rx_mbps || 0);
            const tx = Number(device.tx_mbps || 0);
            const totalDevice = rx + tx;

            return {
                ...device,
                rx,
                tx,
                total: totalDevice,
                share: total > 0 ? (totalDevice / total) * 100 : 0,
            };
        })
        .sort((a, b) => b.total - a.total);

    const maximum = ordered[0]?.total || 0;

    return ordered.slice(0, limit).map((device) => ({
        ...device,
        width: maximum > 0 ? Math.max(4, (device.total / maximum) * 100) : 0,
    }));
}

export function getServices(system) {
    const components = system?.components || {};

    return Object.keys(SERVICE_LABELS)
        .filter((name) => components[name])
        .map((name) => ({
            name,
            label: SERVICE_LABELS[name],
            icon: SERVICE_ICONS[name],
            state: components[name]?.status || "unknown",
        }));
}

export function getBottlenecks({
    system,
    operationalHealth,
    monitoring,
    pool,
    bandwidthError,
}) {
    const issues = [];
    const components = system?.components || {};

    Object.entries(components).forEach(([name, component]) => {
        const label = SERVICE_LABELS[name];

        if (!label) return;

        const state = component?.status;

        if (state && state !== "running") {
            issues.push({
                severity: state === "failed" || state === "stopped"
                    ? "critical"
                    : "warning",
                title: `${label} no operativo`,
                detail: state === "starting" ? "Iniciando" : "Revisar servicio",
            });
        }
    });

    (operationalHealth?.checks || [])
        .filter((check) => check && check.status !== "ok")
        .forEach((check) => {
            issues.push({
                severity: check.status === "critical" ? "critical" : "warning",
                title: check.label || "Control operativo",
                detail: check.detail || check.action || "Revisar",
            });
        });

    if (Number(monitoring?.cpu_percent || 0) >= 90) {
        issues.push({
            severity: "warning",
            title: "CPU alta",
            detail: `${monitoring.cpu_percent}% de uso`,
        });
    }

    if (Number(monitoring?.ram_percent || 0) >= 90) {
        issues.push({
            severity: "warning",
            title: "Memoria alta",
            detail: `${monitoring.ram_percent}% en uso`,
        });
    }

    if (Number(monitoring?.disk_percent || 0) >= 90) {
        issues.push({
            severity: "critical",
            title: "Disco casi lleno",
            detail: `${monitoring.disk_percent}% ocupado`,
        });
    }

    const overall = pool?.overall || {};
    const lowZones = (pool?.zones || []).filter((zone) => zone?.low);

    if (pool?.pool_low || overall.low) {
        issues.push({
            severity: "warning",
            title: "Pool DHCP bajo",
            detail: `${overall.free ?? 0} IPs libres (umbral ${overall.threshold ?? 0})`,
        });
    }

    lowZones.forEach((zone) => {
        issues.push({
            severity: "warning",
            title: `Zona «${zone.name || "sin nombre"}» con pocas IPs`,
            detail: `${zone.free ?? 0} libres (umbral ${zone.threshold ?? 0})`,
        });
    });

    if (bandwidthError) {
        issues.push({
            severity: "warning",
            title: "Sin telemetría de tráfico",
            detail: bandwidthError,
        });
    }

    const priority = { critical: 0, warning: 1 };

    return issues
        .sort((a, b) => (priority[a.severity] ?? 2) - (priority[b.severity] ?? 2))
        .slice(0, 5);
}
