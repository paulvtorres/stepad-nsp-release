import { useEffect, useState } from "react";

import { useAuth } from "../../../../auth/useAuth";

import {
    getSchedules,
    createSchedule,
    deleteSchedule
} from "../../../../services/api";

import "../zones.css";


const DAYS = [
    "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday"
];


function Schedules() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";


    const [schedules, setSchedules] = useState([]);

    const [name, setName] = useState("");

    const [selectedDays, setSelectedDays] = useState([]);

    const [startTime, setStartTime] = useState("");

    const [endTime, setEndTime] = useState("");

    const [startDate, setStartDate] = useState("");

    const [endDate, setEndDate] = useState("");


    useEffect(() => {

        loadSchedules();

    }, []);


    async function loadSchedules() {

        try {

            const data = await getSchedules();

            setSchedules(data);

        } catch (error) {

            console.error(error);

        }

    }


    function toggleDay(day) {

        setSelectedDays((current) =>

            current.includes(day)
                ? current.filter((d) => d !== day)
                : [...current, day]

        );

    }


    async function handleCreate() {

        try {

            await createSchedule({
                name: name || null,
                days_of_week: selectedDays.length
                    ? selectedDays.join(",")
                    : null,
                start_time: startTime || null,
                end_time: endTime || null,
                start_date: startDate || null,
                end_date: endDate || null
            });

            setName("");
            setSelectedDays([]);
            setStartTime("");
            setEndTime("");
            setStartDate("");
            setEndDate("");

            await loadSchedules();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleDelete(id) {

        try {

            await deleteSchedule(id);

            await loadSchedules();

        } catch (error) {

            console.error(error);

        }

    }


    function describeSchedule(schedule) {

        const parts = [];

        if (schedule.days_of_week) {

            parts.push(schedule.days_of_week.split(",").join(", "));

        } else {

            parts.push("Todos los días");

        }

        if (schedule.start_time || schedule.end_time) {

            parts.push(
                `${schedule.start_time || "00:00"} - ${schedule.end_time || "23:59"}`
            );

        }

        if (schedule.start_date || schedule.end_date) {

            parts.push(
                `${schedule.start_date || "..."} → ${schedule.end_date || "..."}`
            );

        }

        return parts.join(" · ");

    }


    return (

        <div className="schedules-panel">

            <h3>Horarios</h3>

            <p className="schedules-hint">
                Un horario define cuándo aplica una regla o un corte de
                internet. Sin días/horas = siempre activo; agrega fechas
                para ventanas puntuales (ej. un curso de una semana).
            </p>

            {
                isAdmin && (
                    <div className="schedule-form">

                        <input
                            type="text"
                            placeholder="Nombre (opcional, ej. 'Horario laboral')"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                        />

                        <div className="day-picker">

                            {
                                DAYS.map((day) => (

                                    <button
                                        key={day}
                                        type="button"
                                        className={
                                            `day-chip ${selectedDays.includes(day) ? "active" : ""}`
                                        }
                                        onClick={() => toggleDay(day)}
                                    >
                                        {day.slice(0, 3)}
                                    </button>

                                ))
                            }

                        </div>

                        <div className="schedule-row">

                            <label>
                                Desde
                                <input
                                    type="time"
                                    value={startTime}
                                    onChange={(e) => setStartTime(e.target.value)}
                                />
                            </label>

                            <label>
                                Hasta
                                <input
                                    type="time"
                                    value={endTime}
                                    onChange={(e) => setEndTime(e.target.value)}
                                />
                            </label>

                        </div>

                        <div className="schedule-row">

                            <label>
                                Fecha inicio (opcional)
                                <input
                                    type="date"
                                    value={startDate}
                                    onChange={(e) => setStartDate(e.target.value)}
                                />
                            </label>

                            <label>
                                Fecha fin (opcional)
                                <input
                                    type="date"
                                    value={endDate}
                                    onChange={(e) => setEndDate(e.target.value)}
                                />
                            </label>

                        </div>

                        <button
                            className="primary-button"
                            onClick={handleCreate}
                        >
                            Crear horario
                        </button>

                    </div>
                )
            }

            <ul className="schedules-list">

                {
                    schedules.map((schedule) => (

                        <li key={schedule.id}>

                            <span>
                                <strong>{schedule.name || "(sin nombre)"}</strong>
                                {" — "}
                                {describeSchedule(schedule)}
                            </span>

                            {
                                isAdmin && (
                                    <button
                                        className="danger-button"
                                        onClick={() => handleDelete(schedule.id)}
                                    >
                                        Eliminar
                                    </button>
                                )
                            }

                        </li>

                    ))
                }

            </ul>

        </div>

    );

}


export default Schedules;
