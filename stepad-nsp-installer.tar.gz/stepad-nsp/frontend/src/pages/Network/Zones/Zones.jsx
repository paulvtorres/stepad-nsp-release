import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getZones,
    createZone,
    updateZone,
    deleteZone,
    getSchedules
} from "../../../services/api";

import Schedules from "./components/Schedules";

import "./zones.css";


const emptyForm = {
    name: "",
    description: "",
    vlan_id: "",
    physical_interface: "",

    interface_mac: "",
    network_cidr: "",
    gateway_ip: "",
    dhcp_pool_start: "",
    dhcp_pool_end: "",
    is_default: false,
    enforce_time_cutoff: false,
    time_cutoff_schedule_id: ""
};


function Zones() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";


    const [zones, setZones] = useState([]);

    const [schedules, setSchedules] = useState([]);

    const [form, setForm] = useState(emptyForm);

    const [showForm, setShowForm] = useState(false);

    const [showSchedules, setShowSchedules] = useState(false);


    useEffect(() => {

        loadZones();

        loadSchedules();

    }, []);


    async function loadZones() {

        try {

            const data = await getZones();

            setZones(data);

        } catch (error) {

            console.error(error);

        }

    }


    async function loadSchedules() {

        try {

            const data = await getSchedules();

            setSchedules(data);

        } catch (error) {

            console.error(error);

        }

    }


    function updateField(field, value) {

        setForm((current) => ({ ...current, [field]: value }));

    }


    async function handleCreate() {

        try {

            await createZone({
                name: form.name,
                description: form.description || null,
                vlan_id: form.vlan_id ? Number(form.vlan_id) : null,
                physical_interface: form.physical_interface,
                interface_mac: form.interface_mac.trim() || null,
                network_cidr: form.network_cidr,
                gateway_ip: form.gateway_ip,
                dhcp_pool_start: form.dhcp_pool_start,
                dhcp_pool_end: form.dhcp_pool_end,
                is_default: form.is_default,
                enforce_time_cutoff: form.enforce_time_cutoff,
                time_cutoff_schedule_id: form.time_cutoff_schedule_id
                    ? Number(form.time_cutoff_schedule_id)
                    : null
            });

            setForm(emptyForm);

            setShowForm(false);

            await loadZones();

        } catch (error) {

            console.error(error);

            alert("No se pudo crear la zona -- revisa la consola.");

        }

    }


    async function handleToggleCutoff(zone) {

        try {

            await updateZone(zone.id, {
                enforce_time_cutoff: !zone.enforce_time_cutoff
            });

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleAssignSchedule(zone, scheduleId) {

        try {

            await updateZone(zone.id, {
                time_cutoff_schedule_id: scheduleId ? Number(scheduleId) : null
            });

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleSetDefault(zone) {

        try {

            await updateZone(zone.id, { is_default: true });

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleDelete(zone) {

        if (!confirm(`¿Eliminar la zona "${zone.name}"? Esto detiene su resolver y su interfaz.`)) {

            return;

        }

        try {

            await deleteZone(zone.id);

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    return (

        <div className="zones-container">

            <div className="zones-header">

                <div>

                    <h2>Zonas / Grupos</h2>

                    <p>
                        Cada zona es una subred con su propia política de
                        bloqueo de dominios y, opcionalmente, su propio
                        VLAN. Los dispositivos nuevos caen en la zona
                        marcada como default.
                    </p>

                </div>

                <div className="zones-header-actions">

                    {
                        isAdmin && (
                            <>
                                <button
                                    className="secondary-button"
                                    onClick={() => setShowSchedules(!showSchedules)}
                                >
                                    {showSchedules ? "Ocultar horarios" : "Gestionar horarios"}
                                </button>

                                <button
                                    className="primary-button"
                                    onClick={() => setShowForm(!showForm)}
                                >
                                    {showForm ? "Cancelar" : "+ Nueva zona"}
                                </button>
                            </>
                        )
                    }

                </div>

            </div>

            {
                showSchedules && <Schedules />
            }

            {
                showForm && (

                    <div className="zone-form">

                        <div className="zone-form-grid">

                            <label>
                                Nombre
                                <input
                                    type="text"
                                    placeholder="ej. Contabilidad"
                                    value={form.name}
                                    onChange={(e) => updateField("name", e.target.value)}
                                />
                            </label>

                            <label>
                                Descripción
                                <input
                                    type="text"
                                    value={form.description}
                                    onChange={(e) => updateField("description", e.target.value)}
                                />
                            </label>

                            <label>
                                VLAN ID (vacío = sin switch administrable, IP-alias)
                                <input
                                    type="number"
                                    placeholder="ej. 60 (opcional)"
                                    value={form.vlan_id}
                                    onChange={(e) => updateField("vlan_id", e.target.value)}
                                />
                            </label>

                            <label>
                                Interfaz física
                                <input
                                    type="text"
                                    placeholder="ej. enx00e04c554a88"
                                    value={form.physical_interface}
                                    onChange={(e) => updateField("physical_interface", e.target.value)}
                                />
                            </label>

                            <label>
                                MAC de la tarjeta (opcional)
                                <input
                                    type="text"
                                    placeholder="ej. 00:e0:4c:55:4a:88"
                                    value={form.interface_mac}
                                    onChange={(e) => updateField("interface_mac", e.target.value)}
                                />
                                <small style={{ color: "var(--muted)", fontSize: 11 }}>
                                    Si lo indicas, la zona sigue a la tarjeta aunque la cambies de puerto o la reemplaces.
                                </small>
                            </label>

                            <label>
                                Red (CIDR)
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.60.0/24"
                                    value={form.network_cidr}
                                    onChange={(e) => updateField("network_cidr", e.target.value)}
                                />
                            </label>

                            <label>
                                IP de gateway/DNS de la zona
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.60.1"
                                    value={form.gateway_ip}
                                    onChange={(e) => updateField("gateway_ip", e.target.value)}
                                />
                            </label>

                            <label>
                                Pool DHCP desde
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.60.100"
                                    value={form.dhcp_pool_start}
                                    onChange={(e) => updateField("dhcp_pool_start", e.target.value)}
                                />
                            </label>

                            <label>
                                Pool DHCP hasta
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.60.200"
                                    value={form.dhcp_pool_end}
                                    onChange={(e) => updateField("dhcp_pool_end", e.target.value)}
                                />
                            </label>

                            <label>
                                Horario de corte total (solo si activas el corte abajo)
                                <select
                                    value={form.time_cutoff_schedule_id}
                                    onChange={(e) => updateField("time_cutoff_schedule_id", e.target.value)}
                                >
                                    <option value="">-- Sin horario --</option>
                                    {
                                        schedules.map((schedule) => (
                                            <option key={schedule.id} value={schedule.id}>
                                                {schedule.name || `Horario #${schedule.id}`}
                                            </option>
                                        ))
                                    }
                                </select>
                            </label>

                        </div>

                        <div className="zone-form-checkboxes">

                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    checked={form.is_default}
                                    onChange={(e) => updateField("is_default", e.target.checked)}
                                />
                                Zona por defecto (dispositivos nuevos, celulares incluidos, caen aquí)
                            </label>

                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    checked={form.enforce_time_cutoff}
                                    onChange={(e) => updateField("enforce_time_cutoff", e.target.checked)}
                                />
                                Cortar todo internet fuera del horario (solo equipos de empresa)
                            </label>

                        </div>

                        <button
                            className="primary-button"
                            onClick={handleCreate}
                        >
                            Guardar zona
                        </button>

                    </div>

                )
            }

            <div className="table-card">

                <table className="zones-table">

                    <thead>

                        <tr>
                            <th>Nombre</th>
                            <th>Red</th>
                            <th>VLAN</th>
                            <th>Default</th>
                            <th>Corte por horario</th>
                            <th>Horario asignado</th>
                            <th>Acciones</th>
                        </tr>

                    </thead>

                    <tbody>

                        {
                            zones.map((zone) => (

                                <tr key={zone.id}>

                                    <td>{zone.name}</td>

                                    <td>{zone.network_cidr} ({zone.gateway_ip})</td>

                                    <td>{zone.vlan_id || "— (IP alias)"}</td>

                                    <td>
                                        {
                                            zone.is_default
                                                ? "✓"
                                                : (
                                                    isAdmin && (
                                                        <button
                                                            className="secondary-button small"
                                                            onClick={() => handleSetDefault(zone)}
                                                        >
                                                            Hacer default
                                                        </button>
                                                    )
                                                )
                                        }
                                    </td>

                                    <td>
                                        {
                                            isAdmin && (
                                                <label className="checkbox-label">
                                                    <input
                                                        type="checkbox"
                                                        checked={zone.enforce_time_cutoff}
                                                        onChange={() => handleToggleCutoff(zone)}
                                                    />
                                                </label>
                                            )
                                        }
                                        {
                                            !isAdmin && (zone.enforce_time_cutoff ? "✓" : "—")
                                        }
                                    </td>

                                    <td>
                                        {
                                            isAdmin ? (
                                                <select
                                                    value={zone.time_cutoff_schedule_id || ""}
                                                    onChange={(e) =>
                                                        handleAssignSchedule(zone, e.target.value)
                                                    }
                                                    disabled={!zone.enforce_time_cutoff}
                                                >
                                                    <option value="">-- Sin horario --</option>
                                                    {
                                                        schedules.map((schedule) => (
                                                            <option key={schedule.id} value={schedule.id}>
                                                                {schedule.name || `Horario #${schedule.id}`}
                                                            </option>
                                                        ))
                                                    }
                                                </select>
                                            ) : (
                                                zone.enforce_time_cutoff
                                                    ? (schedules.find((s) => s.id === zone.time_cutoff_schedule_id)?.name || "Asignado")
                                                    : "—"
                                            )
                                        }
                                    </td>

                                    <td>
                                        {
                                            isAdmin && (
                                                <button
                                                    className="danger-button"
                                                    onClick={() => handleDelete(zone)}
                                                >
                                                    Eliminar
                                                </button>
                                            )
                                        }
                                    </td>

                                </tr>

                            ))
                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}


export default Zones;
