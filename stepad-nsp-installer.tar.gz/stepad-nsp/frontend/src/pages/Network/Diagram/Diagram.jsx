import { useEffect, useState } from "react";

import {
    getRegisteredInterfaces,
    getZones,
    getDevices
} from "../../../services/api";

import "./diagram.css";


function Diagram() {

    const [interfaces, setInterfaces] = useState([]);

    const [zones, setZones] = useState([]);

    const [devices, setDevices] = useState([]);

    const [loading, setLoading] = useState(true);


    useEffect(() => {

        let cancelled = false;

        Promise.all([
            getRegisteredInterfaces(),
            getZones(),
            getDevices()
        ])

            .then(([ifaces, zoneList, deviceList]) => {
                if (cancelled) return;
                setInterfaces(ifaces || []);
                setZones(zoneList || []);
                setDevices(deviceList || []);
            })

            .catch(() => {
                if (!cancelled) setLoading(false);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    const wan = interfaces.filter((i) => i.role === "WAN");

    const lan = interfaces.filter((i) => i.role === "LAN");

    const devicesInZone = (zoneId) =>
        devices.filter((d) => d.zone_id === zoneId);

    const unassigned = devices.filter((d) => !d.zone_id);


    return (

        <div className="diagram">

            <h2>Diagrama de red</h2>

            <p className="diagram-hint">

                Vista de la topología actual: WAN, interfaces y zonas con
                sus dispositivos. Mantén este diagrama al día y revísalo
                al menos una vez al año o ante cualquier cambio de red.

            </p>

            {
                loading && (
                    <p>Cargando topología...</p>
                )
            }

            {
                !loading && (
                    <>

                        <div className="diagram-row">

                            <div className="diagram-box diagram-wan">

                                <div className="diagram-box-title">Internet / WAN</div>

                                {
                                    wan.length === 0 ? (
                                        <div className="diagram-muted">Sin WAN asignada</div>
                                    ) : (
                                        wan.map((i) => (
                                            <div key={i.mac_address} className="diagram-item">
                                                {i.current_name || i.mac_address}
                                            </div>
                                        ))
                                    )
                                }

                            </div>

                            <div className="diagram-link">──▼──</div>

                            <div className="diagram-box diagram-core">

                                <div className="diagram-box-title">STEPAD NSP</div>

                                <div className="diagram-muted">
                                    Firewall · DHCP · DNS · NAT
                                </div>

                                <div className="diagram-subtitle">Interfaces LAN</div>

                                {
                                    lan.length === 0 ? (
                                        <div className="diagram-muted">Sin LAN asignada</div>
                                    ) : (
                                        lan.map((i) => (
                                            <div key={i.mac_address} className="diagram-item">
                                                {i.current_name || i.mac_address} ({i.ip_address || "sin IP"})
                                            </div>
                                        ))
                                    )
                                }

                            </div>

                        </div>

                        <div className="diagram-row">

                            {
                                zones.map((zone) => (
                                    <div key={zone.id} className="diagram-box diagram-zone">

                                        <div className="diagram-box-title">
                                            {zone.name}
                                            {zone.is_default ? " (default)" : ""}
                                        </div>

                                        <div className="diagram-zone-meta">
                                            {zone.network_cidr} · gw {zone.gateway_ip}
                                            {zone.vlan_id ? ` · VLAN ${zone.vlan_id}` : ""}
                                        </div>

                                        <div className="diagram-zone-devices">

                                            {
                                                devicesInZone(zone.id).length === 0 ? (
                                                    <div className="diagram-muted">Sin dispositivos</div>
                                                ) : (
                                                    devicesInZone(zone.id).map((d) => (
                                                        <div key={d.id} className="diagram-item">
                                                            {d.hostname || d.mac_address}
                                                        </div>
                                                    ))
                                                )
                                            }

                                        </div>

                                    </div>
                                ))
                            }

                            {
                                zones.length === 0 && (
                                    <div className="diagram-box diagram-zone">
                                        <div className="diagram-box-title">Sin zonas</div>
                                        <div className="diagram-muted">
                                            Crea zonas (VLAN/subred) para segmentar la red.
                                        </div>
                                    </div>
                                )
                            }

                            <div className="diagram-box diagram-zone diagram-unassigned">

                                <div className="diagram-box-title">Sin zona asignada</div>

                                <div className="diagram-zone-devices">

                                    {
                                        unassigned.length === 0 ? (
                                            <div className="diagram-muted">Ninguno</div>
                                        ) : (
                                            unassigned.map((d) => (
                                                <div key={d.id} className="diagram-item">
                                                    {d.hostname || d.mac_address}
                                                </div>
                                            ))
                                        )
                                    }

                                </div>

                            </div>

                        </div>

                    </>
                )
            }

        </div>

    );

}


export default Diagram;
