import { useEffect, useState } from "react";

import {
    getRegisteredInterfaces,
    rescanInterfaces,
    assignInterfaceRole,
    unassignInterfaceRole,
    deleteRegisteredInterface,
    testInterfaceConnectivity,
    getDhcpConfig,
    setLanSegment,
    setDhcpExclusions
} from "../../../services/api";

import NetworkDiagnosis from "../../../components/network/NetworkDiagnosis";

import WriteGuard from "../../../components/WriteGuard";


function InterfaceCard({ item, busyId, testResults, onTest, onUnassign, onPriorityChange }) {

    return (

        <div className="registry-card">

            <div className="registry-card-main">

                <div className="registry-card-name">
                    {item.current_name || item.last_seen_name || "-"}
                    {item.display_name && (
                        <span className="registry-card-label"> ({item.display_name})</span>
                    )}
                </div>

                <div className="registry-card-details">
                    <span>MAC: {item.mac_address}</span>
                    <span>{item.link_detected ? "🟢 Conectado" : "⚪ Sin cable"}</span>
                    <span>IP: {item.ip_address || "-"}</span>
                </div>

            </div>

            <div className="registry-card-priority">

                <WriteGuard>
                    <button
                        disabled={busyId === item.id}
                        title="Subir prioridad (preferir esta tarjeta primero)"
                        onClick={() => onPriorityChange(item.id, item.priority - 10)}
                    >
                        ▲
                    </button>
                </WriteGuard>

                <span>Prioridad {item.priority}</span>

                <WriteGuard>
                    <button
                        disabled={busyId === item.id}
                        title="Bajar prioridad"
                        onClick={() => onPriorityChange(item.id, item.priority + 10)}
                    >
                        ▼
                    </button>
                </WriteGuard>

            </div>

            <div className="registry-card-actions">

                {
                    item.role === "WAN" && (

                        <>
                            <WriteGuard>
                                <button
                                    disabled={busyId === item.id}
                                    onClick={() => onTest(item.id)}
                                >
                                    {busyId === item.id ? "Probando..." : "Probar conectividad"}
                                </button>
                            </WriteGuard>

                            {
                                testResults[item.id] && (
                                    <div
                                        className={
                                            testResults[item.id].has_internet
                                                ? "registry-test-result-ok"
                                                : "registry-test-result-no"
                                        }
                                    >
                                        {testResults[item.id].message}
                                    </div>
                                )
                            }
                        </>

                    )
                }

                <WriteGuard>
                    <button
                        disabled={busyId === item.id}
                        onClick={() => onUnassign(item.id)}
                    >
                        Quitar rol
                    </button>
                </WriteGuard>

            </div>

        </div>

    );

}


function UnassignedCard({ item, busyId, testResults, onTest, onAssign, onDelete }) {

    const [selectedRole, setSelectedRole] = useState("");


    function handleConfirm() {

        if (!selectedRole) return;

        onAssign(item.id, selectedRole);

    }


    return (

        <div className="registry-card registry-card-unassigned">

            <div className="registry-card-main">

                <div className="registry-card-name">
                    {item.current_name || item.last_seen_name || "-"}
                </div>

                <div className="registry-card-details">
                    <span>MAC: {item.mac_address}</span>
                    <span>{item.link_detected ? "🟢 Conectado" : "⚪ Sin cable"}</span>
                    <span>IP: {item.ip_address || "-"}</span>
                </div>

                {
                    item.status === "missing" && (
                        <div className="registry-missing-tag">
                            No detectada -- esta tarjeta tenía un rol asignado y ya no aparece.
                        </div>
                    )
                }

                {
                    item.suggested_replacement && (

                        <div className="registry-suggestion">

                            ¿Reemplazaste la tarjeta{" "}
                            {item.suggested_replacement.suggested_role}
                            {" "}(antes{" "}
                            {item.suggested_replacement.replaces_last_seen_name}
                            {")? "}

                            <WriteGuard>
                                <button
                                    disabled={busyId === item.id}
                                    onClick={() =>
                                        onAssign(
                                            item.id,
                                            item.suggested_replacement.suggested_role,
                                            item.suggested_replacement.suggested_display_name
                                        )
                                    }
                                >
                                    Sí, asignar el mismo rol
                                </button>
                            </WriteGuard>

                        </div>

                    )
                }

            </div>

            <div className="registry-card-actions">

                {
                    item.link_detected && (

                        <>
                            <WriteGuard>
                                <button
                                    disabled={busyId === item.id}
                                    onClick={() => onTest(item.id)}
                                >
                                    {busyId === item.id ? "Probando..." : "Probar conectividad a internet"}
                                </button>
                            </WriteGuard>

                            {
                                testResults[item.id] && (
                                    <div
                                        className={
                                            testResults[item.id].has_internet
                                                ? "registry-test-result-ok"
                                                : "registry-test-result-no"
                                        }
                                    >
                                        {testResults[item.id].message}
                                    </div>
                                )
                            }
                        </>

                    )
                }

                <WriteGuard>
                    <div className="registry-assign-row">

                        {
                            item.status !== "missing" && (
                                <>
                                    <select
                                        value={selectedRole}
                                        onChange={(e) => setSelectedRole(e.target.value)}
                                    >
                                        <option value="">Elegir rol...</option>
                                        <option value="WAN">WAN (internet)</option>
                                        <option value="LAN">LAN (red interna)</option>
                                    </select>

                                    <button
                                        disabled={busyId === item.id || !selectedRole}
                                        onClick={handleConfirm}
                                    >
                                        Confirmar
                                    </button>
                                </>
                            )
                        }

                        {
                            item.status === "missing" && (
                                <button
                                    disabled={busyId === item.id}
                                    onClick={() => onDelete(item.id)}
                                    title="Eliminar del registro -- ya no está conectada"
                                >
                                    Eliminar
                                </button>
                            )
                        }

                    </div>
                </WriteGuard>

            </div>

        </div>

    );

}


function InterfaceRegistryPanel({ onRegistryChange }) {

    const [registered, setRegistered] = useState([]);

    const [busyId, setBusyId] = useState(null);

    const [testResults, setTestResults] = useState({});

    const [compareResults, setCompareResults] = useState([]);

    const [compareBusy, setCompareBusy] = useState(false);


    async function handleCompareWan() {

        setCompareBusy(true);

        try {

            const res = await compareWan();

            setCompareResults(res || []);

        } catch (error) {

            console.error(error);

        } finally {

            setCompareBusy(false);

        }

    }


    useEffect(() => {

        loadRegistered();

    }, []);


    async function loadRegistered() {

        try {

            const data = await getRegisteredInterfaces();

            setRegistered(data || []);

        } catch (error) {            console.error(error);

        }

    }


    const [rescanBusy, setRescanBusy] = useState(false);

    async function handleRescan() {

        setRescanBusy(true);

        try {

            const data = await rescanInterfaces();

            setRegistered(data || []);

        } catch (error) {

            console.error(error);

        } finally {

            setRescanBusy(false);

        }

    }


    async function handleTestConnectivity(id) {

        setBusyId(id);

        try {

            const result = await testInterfaceConnectivity(id);

            setTestResults((previous) => ({
                ...previous,
                [id]: result
            }));

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handleAssign(id, role, displayName) {

        setBusyId(id);

        try {

            const payload = displayName
                ? { role, display_name: displayName }
                : { role };

            await assignInterfaceRole(id, payload);

            await loadRegistered();

            onRegistryChange?.();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handlePriorityChange(id, newPriority) {

        setBusyId(id);

        try {

            const item = registered.find((entry) => entry.id === id);

            await assignInterfaceRole(id, { role: item.role, priority: newPriority });

            await loadRegistered();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handleUnassign(id) {

        setBusyId(id);

        try {

            await unassignInterfaceRole(id);

            await loadRegistered();

            onRegistryChange?.();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    async function handleDelete(id) {

        setBusyId(id);

        try {

            await deleteRegisteredInterface(id);

            await loadRegistered();

            onRegistryChange?.();

        } catch (error) {

            console.error(error);

        } finally {

            setBusyId(null);

        }

    }


    const wanCards = registered
        .filter((item) => item.role === "WAN")
        .sort((a, b) => a.priority - b.priority);

    const lanCards = registered
        .filter((item) => item.role === "LAN")
        .sort((a, b) => a.priority - b.priority);

    const unassignedCards = registered.filter(
        (item) => item.status === "pending_assignment" || item.status === "missing"
    );


    return (

        <div className="registry-panel">

            <h3>Tarjetas de red</h3>

            <p className="registry-hint">
                Cada tarjeta se identifica por su MAC, no por el nombre
                que le da Linux -- así el rol asignado sobrevive a un
                cambio de máquina, una tarjeta reemplazada, o un
                reinicio. Puedes tener varias WAN y varias LAN; el
                número de prioridad decide cuál se usa primero.
            </p>

            <div className="confirm-actions">
                <button className="secondary-button" onClick={handleRescan} disabled={rescanBusy}>
                    {rescanBusy ? "Rescaneando..." : "Rescanear"}
                </button>
                <button className="secondary-button" onClick={handleCompareWan} disabled={compareBusy}>
                    {compareBusy ? "Midiendo..." : "Comparar proveedores de internet"}
                </button>
            </div>

            {
                compareResults.length > 0 && (
                    <div className="registry-compare" style={{ marginBottom: 12 }}>
                        <h4>Resultado (mejor primero)</h4>
                        {
                            compareResults.map((r, i) => (
                                <div
                                    key={r.mac_address || r.name}
                                    style={{
                                        padding: "8px 12px",
                                        borderRadius: 6,
                                        marginBottom: 6,
                                        border: "1px solid var(--border)",
                                        background: (i === 0 && r.has_internet)
                                            ? "rgba(34, 197, 94, 0.12)"
                                            : "var(--panel-2)"
                                    }}
                                >
                                    <strong>{r.name}</strong>{" "}
                                    {
                                        r.has_internet
                                            ? `✔ Internet OK — latencia ${r.latency_ms ? r.latency_ms.toFixed(0) : "—"} ms — pérdida ${r.packet_loss}%`
                                            : "✖ Sin internet"
                                    }
                                    {i === 0 && r.has_internet && " ← MEJOR"}
                                </div>
                            ))
                        }
                    </div>
                )
            }

            <div className="registry-section">

                <h4>WAN {wanCards.length > 0 && `(${wanCards.length})`}</h4>

                {
                    wanCards.length === 0 ? (
                        <p className="registry-empty">Ninguna tarjeta asignada como WAN todavía.</p>
                    ) : (
                        wanCards.map((item) => (
                            <InterfaceCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onUnassign={handleUnassign}
                                onPriorityChange={handlePriorityChange}
                            />
                        ))
                    )
                }

            </div>

            <div className="registry-section">

                <h4>LAN {lanCards.length > 0 && `(${lanCards.length})`}</h4>

                {
                    lanCards.length === 0 ? (
                        <p className="registry-empty">Ninguna tarjeta asignada como LAN todavía.</p>
                    ) : (
                        lanCards.map((item) => (
                            <InterfaceCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onUnassign={handleUnassign}
                                onPriorityChange={handlePriorityChange}
                            />
                        ))
                    )
                }

            </div>

            <div className="registry-section">

                <h4>Sin asignar {unassignedCards.length > 0 && `(${unassignedCards.length})`}</h4>

                {
                    unassignedCards.length === 0 ? (
                        <p className="registry-empty">No hay tarjetas pendientes de asignar.</p>
                    ) : (
                        unassignedCards.map((item) => (
                            <UnassignedCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onAssign={handleAssign}
                                onDelete={handleDelete}
                            />
                        ))
                    )
                }

            </div>

        </div>

    );

}


function LanSegmentPanel() {

    const [config, setConfig] = useState(null);

    const [network, setNetwork] = useState("");

    const [poolStart, setPoolStart] = useState("");

    const [poolEnd, setPoolEnd] = useState("");

    const [exclusions, setExclusions] = useState("");

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpConfig();

            setConfig(data);

            setNetwork(`${data.network}/${data.netmask}`);
            setPoolStart(data.pool_start);
            setPoolEnd(data.pool_end);
            setExclusions((data.excluded_ips || []).join(", "));

        } catch (e) {

            setError("No se pudo leer la configuración DHCP.");

        }

    }


    useEffect(() => {

        load();

    }, []);


    function parseExclusions() {

        return exclusions
            .split(",")
            .map((x) => x.trim())
            .filter(Boolean);

    }


    async function handleApplySegment() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setLanSegment({
                network,
                pool_start: poolStart,
                pool_end: poolEnd,
                excluded_ips: parseExclusions()
            });

            setMessage(result?.message || "Segmento aplicado.");

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudo aplicar el segmento."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveExclusions() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setDhcpExclusions(parseExclusions());

            setMessage(
                result?.success
                    ? "Exclusiones guardadas y DHCP reaplicado."
                    : "Exclusiones guardadas."
            );

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudieron guardar las exclusiones."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel">

            <h3>Segmento LAN y DHCP</h3>

            <p className="registry-hint">
                El DHCP reparte solo el rango (pool) que configures dentro
                del segmento. El NSP siempre usa el primer host (.1) como
                gateway. Las IPs excluidas (individuales o por rango,
                ej. 192.168.60.150 o 192.168.60.200-192.168.60.210) nunca
                se entregan por DHCP: úsalas para dispositivos con IP
                estática.
            </p>

            {
                config && (
                    <p style={{ color: "var(--muted)" }}>
                        Segmento actual: <strong>{config.network}/{config.netmask}</strong>{" "}
                        · gateway <strong>{config.gateway}</strong> ·{" "}
                        pool {config.pool_start}–{config.pool_end}
                        {config.excluded_ips?.length > 0 && (
                            <> · excluidas: {config.excluded_ips.join(", ")}</>
                        )}
                    </p>
                )
            }

            <WriteGuard>

                <div style={{ marginTop: 12, padding: 12, border: "1px solid var(--border)", borderRadius: 8, background: "var(--panel-2)" }}>

                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12 }}>

                        <label>
                            Red (CIDR)
                            <input
                                type="text"
                                placeholder="ej. 192.168.60.0/24"
                                value={network}
                                onChange={(e) => setNetwork(e.target.value)}
                            />
                        </label>

                        <label>
                            Pool DHCP desde
                            <input
                                type="text"
                                placeholder="ej. 192.168.60.100"
                                value={poolStart}
                                onChange={(e) => setPoolStart(e.target.value)}
                            />
                        </label>

                        <label>
                            Pool DHCP hasta
                            <input
                                type="text"
                                placeholder="ej. 192.168.60.200"
                                value={poolEnd}
                                onChange={(e) => setPoolEnd(e.target.value)}
                            />
                        </label>

                    </div>

                    <label style={{ display: "block", marginTop: 12 }}>
                        IPs excluidas (IP o rango, separadas por coma)
                        <input
                            type="text"
                            placeholder="ej. 192.168.60.150, 192.168.60.200-192.168.60.210"
                            value={exclusions}
                            onChange={(e) => setExclusions(e.target.value)}
                            style={{ width: "100%" }}
                        />
                    </label>

                    <div style={{ display: "flex", gap: 10, marginTop: 12 }}>

                        <button
                            className="primary-button"
                            onClick={handleApplySegment}
                            disabled={busy}
                        >
                            {busy ? "Aplicando..." : "Cambiar segmento"}
                        </button>

                        <button
                            className="secondary-button"
                            onClick={handleSaveExclusions}
                            disabled={busy}
                        >
                            {busy ? "Guardando..." : "Guardar exclusiones"}
                        </button>

                    </div>

                </div>

            </WriteGuard>

            {message && (
                <p style={{ color: "var(--success)", marginTop: 8 }}>
                    ✔ {message}
                </p>
            )}

            {error && (
                <p style={{ color: "var(--danger)", marginTop: 8 }}>
                    ✖ {error}
                </p>
            )}

        </div>

    );

}


function Interfaces() {

    const [diagKey, setDiagKey] = useState(0);


    return (

        <>

            <NetworkDiagnosis refreshKey={diagKey} />


            <hr />


            <InterfaceRegistryPanel onRegistryChange={() => setDiagKey((k) => k + 1)} />


            <hr />


            <LanSegmentPanel />


        </>

    );

}


export default Interfaces;