import { useEffect, useState } from "react";

import { getDhcpPoolStats } from "../../../services/api";


function StatCard({ label, value, hint, tone }) {

    return (

        <div className={`dhcp-stat-card ${tone || ""}`}>
            <span className="dhcp-stat-label">{label}</span>
            <strong className="dhcp-stat-value">{value}</strong>
            {hint && <span className="dhcp-stat-hint">{hint}</span>}
        </div>

    );

}


function DhcpPoolStatsPanel() {

    const [stats, setStats] = useState(null);

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpPoolStats();

            setStats(data);
            setError("");

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudieron leer las estadísticas DHCP."
            );

        }

    }


    useEffect(() => {

        load();

        const timer = setInterval(load, 20000);

        return () => clearInterval(timer);

    }, []);


    if (!stats && !error) {
        return (
            <div className="registry-panel">
                <h3>Uso de IPs</h3>
                <p className="registry-hint">Cargando...</p>
            </div>
        );
    }


    const devices = stats?.devices || {};
    const groups = stats?.groups || {};
    const overall = stats?.overall || {};

    const network = stats?.network || {};

    const staticInPool = stats?.static_in_pool || [];


    return (

        <div className="registry-panel">

            <div className="registry-panel-head">
                <div>
                    <h3>Uso de IPs</h3>
                    <p className="registry-hint">
                        Equipos {stats?.pool_start}–{stats?.pool_end} ·
                        grupos {stats?.group_ip_start}–{stats?.group_ip_end}.
                        «Libres» ya descuenta leases, reservas e IPs fijas
                        dentro del pool.
                    </p>
                </div>
                <button
                    type="button"
                    className="secondary-button"
                    onClick={load}
                >
                    Actualizar
                </button>
            </div>

            <div className="dhcp-stat-grid">
                <StatCard
                    label="Total IPs"
                    value={overall.total ?? "—"}
                    hint="Equipos + grupos"
                />
                <StatCard
                    label="Asignadas (pool)"
                    value={devices.leased ?? "—"}
                    hint="Leases que ocupan el pool"
                    tone="ok"
                />
                <StatCard
                    label="En la red ahora"
                    value={network?.present ?? "—"}
                    hint={`${network?.in_pool ?? 0} en el pool · ${network?.outside_pool ?? 0} fuera`}
                    tone="warn"
                />
                <StatCard
                    label="Libres"
                    value={overall.free ?? "—"}
                    hint="Disponibles ahora"
                    tone="accent"
                />
            </div>

            <div className="lan-stat-row" style={{ marginTop: 14 }}>
                <span className="lan-stat">
                    <span>Pool equipos</span>
                    <strong>
                        {devices.dynamic ?? 0} dinámicas
                        {" · "}asignadas {devices.leased ?? 0}
                        {" · "}libres {devices.free ?? 0}
                        {" · "}reservadas {devices.reserved ?? 0}
                        (en uso {devices.reserved_in_use ?? 0})
                        {" · "}fijas en pool {devices.static ?? 0}
                    </strong>
                </span>
                <span className="lan-stat">
                    <span>IPs de grupos</span>
                    <strong>
                        {groups.total ?? 0}
                        {" · "}usadas {groups.used ?? 0}
                        {" · "}libres {groups.free ?? 0}
                    </strong>
                </span>
            </div>

            {staticInPool.length > 0 && (
                <div className="dhcp-static-warning">
                    <strong>
                        {staticInPool.length} equipo(s) con IP fija
                        dentro del pool
                    </strong>
                    <p>
                        Usan una dirección del rango automático sin reserva;
                        pueden chocar con una asignación del DHCP. Cambiá su
                        IP, excluila o creá una reserva.
                    </p>
                    <ul>
                        {staticInPool.map((item) => (
                            <li key={item.ip}>
                                {item.ip}
                                {item.hostname ? ` · ${item.hostname}` : ""}
                                {item.mac ? ` · ${item.mac}` : ""}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpPoolStatsPanel;
