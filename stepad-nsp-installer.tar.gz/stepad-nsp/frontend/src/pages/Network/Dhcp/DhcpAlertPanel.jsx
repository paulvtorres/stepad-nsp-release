import { useEffect, useState } from "react";

import {
    getDhcpAlertSettings,
    saveDhcpAlertSettings,
    runDhcpAlertCheck,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function DhcpAlertPanel() {

    const [serviceAlertEnabled, setServiceAlertEnabled] = useState(true);

    const [scheduledCheckEnabled, setScheduledCheckEnabled] = useState(false);

    const [runTime, setRunTime] = useState("08:00");

    const [poolLowAlertEnabled, setPoolLowAlertEnabled] = useState(false);

    const [poolLowThreshold, setPoolLowThreshold] = useState(10);

    const [reclaimEnabled, setReclaimEnabled] = useState(true);
    const [pingCheck, setPingCheck] = useState(false);

    const [reclaimMinutes, setReclaimMinutes] = useState(60);

    const [reclaimTargetFree, setReclaimTargetFree] = useState(10);

    const [reclaimCooldown, setReclaimCooldown] = useState(60);

    const [proactiveEnabled, setProactiveEnabled] = useState(true);

    const [proactiveMinutes, setProactiveMinutes] = useState(360);

    const [trendEnabled, setTrendEnabled] = useState(true);

    const [trendHours, setTrendHours] = useState(24);



    const [secondaryDhcpEnabled, setSecondaryDhcpEnabled] = useState(false);
    const [secondaryDhcpIp, setSecondaryDhcpIp] = useState("");
    const [secondaryDhcpStart, setSecondaryDhcpStart] = useState("");
    const [secondaryDhcpEnd, setSecondaryDhcpEnd] = useState("");
    const [secondaryDhcpNotes, setSecondaryDhcpNotes] = useState("");

    // Destinatarios PROPIOS del aviso de pool (independientes de Alertas).
    const [poolLowEmails, setPoolLowEmails] = useState("");

    const [healthy, setHealthy] = useState(true);

    const [problems, setProblems] = useState([]);

    const [lastRunAt, setLastRunAt] = useState(null);

    const [lastResult, setLastResult] = useState(null);

    const [section, setSection] = useState("avisos");

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpAlertSettings();

            setServiceAlertEnabled(
                data.service_alert_enabled !== false
            );
            setScheduledCheckEnabled(
                Boolean(data.scheduled_check_enabled)
            );
            setRunTime(data.run_time || "08:00");
            setPoolLowAlertEnabled(
                Boolean(data.pool_low_alert_enabled)
            );
            setPoolLowThreshold(
                Number(data.pool_low_threshold) || 10
            );
            setPoolLowEmails(
                (data.pool_low_alert_emails || []).join(", ")
            );
            setReclaimEnabled(data.pool_reclaim_enabled !== false);
            setReclaimMinutes(Number(data.pool_emergency_reclaim_minutes) || 60);
            setPingCheck(Boolean(data.ping_check));
            setReclaimTargetFree(
                Number(data.pool_reclaim_target_free) || 10
            );
            setReclaimCooldown(
                Number(data.pool_reclaim_cooldown_seconds) || 60
            );
            setProactiveEnabled(data.pool_proactive_reclaim_enabled !== false);
            setProactiveMinutes(
                Number(data.pool_proactive_offline_minutes) || 360
            );
            setTrendEnabled(data.pool_trend_alert_enabled !== false);
            setTrendHours(Number(data.pool_trend_horizon_hours) || 24);
            setSecondaryDhcpEnabled(
                Boolean(data.secondary_dhcp_enabled)
            );
            setSecondaryDhcpIp(data.secondary_dhcp_ip || "");
            setSecondaryDhcpStart(data.secondary_dhcp_pool_start || "");
            setSecondaryDhcpEnd(data.secondary_dhcp_pool_end || "");
            setSecondaryDhcpNotes(data.secondary_dhcp_notes || "");
            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setLastRunAt(data.last_run_at || null);
            setLastResult(data.last_result || null);

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudieron leer las alertas DHCP."
            );

        }

    }


    useEffect(() => {

        load();

    }, []);


    async function handleSave() {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await saveDhcpAlertSettings({
                service_alert_enabled: serviceAlertEnabled,
                scheduled_check_enabled: scheduledCheckEnabled,
                run_time: runTime,
                pool_low_alert_enabled: poolLowAlertEnabled,
                pool_low_threshold: Number(poolLowThreshold),
                pool_low_alert_emails: poolLowEmails,
                pool_reclaim_enabled: reclaimEnabled,
                ping_check: pingCheck,
                pool_emergency_reclaim_minutes: Number(reclaimMinutes),
                pool_reclaim_target_free: Number(reclaimTargetFree),
                pool_reclaim_cooldown_seconds: Number(reclaimCooldown),
                pool_proactive_reclaim_enabled: proactiveEnabled,
                pool_proactive_offline_minutes: Number(proactiveMinutes),
                pool_trend_alert_enabled: trendEnabled,
                pool_trend_horizon_hours: Number(trendHours),
                secondary_dhcp_enabled: secondaryDhcpEnabled,
                secondary_dhcp_ip: secondaryDhcpIp,
                secondary_dhcp_pool_start: secondaryDhcpStart,
                secondary_dhcp_pool_end: secondaryDhcpEnd,
                secondary_dhcp_notes: secondaryDhcpNotes,
            });

            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setMessage(
                data.message
                || "Programación de alertas guardada."
            );

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo guardar."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleCheck(forceEmail = false) {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await runDhcpAlertCheck({
                force_email: forceEmail,
            });

            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setMessage(
                `${data.message || "Verificación lista."}`
                + (data.emailed ? " Correo enviado." : "")
            );
            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo verificar."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel dhcp-alert-panel">

            <div className="registry-panel-head">

                <div>

                    <h3>Alertas y comportamiento DHCP</h3>

                    <p className="registry-hint">
                        Avisos, rendimiento del pool, reciclaje de IPs y
                        segundo DHCP. Cada grupo tiene su propia pestaña.
                    </p>

                </div>

                <span className={`dhcp-health-pill ${healthy ? "ok" : "warn"}`}>
                    {healthy ? "Saludable" : "Con problemas"}
                </span>

            </div>

            <div className="dhcp-summary-grid">

                <div className={`dhcp-summary-card ${serviceAlertEnabled ? "on" : "off"}`}>
                    <span>Correo inmediato</span>
                    <strong>{serviceAlertEnabled ? "Activo" : "Inactivo"}</strong>
                    <small>Si DHCP cae o se cuelga</small>
                </div>

                <div className={`dhcp-summary-card ${poolLowAlertEnabled ? "on" : "off"}`}>
                    <span>Pool bajo</span>
                    <strong>{poolLowAlertEnabled ? `≤ ${poolLowThreshold}` : "Inactivo"}</strong>
                    <small>IPs libres del pool</small>
                </div>

                <div className={`dhcp-summary-card ${reclaimEnabled ? "on" : "off"}`}>
                    <span>Reciclaje</span>
                    <strong>{reclaimEnabled ? "Activo" : "Inactivo"}</strong>
                    <small>{reclaimMinutes} min sin señal</small>
                </div>

                <div className={`dhcp-summary-card ${secondaryDhcpEnabled ? "on" : "off"}`}>
                    <span>Segundo DHCP</span>
                    <strong>{secondaryDhcpEnabled ? (secondaryDhcpIp || "Configurado") : "Inactivo"}</strong>
                    <small>{secondaryDhcpEnabled ? "Monitoreado" : "Sin monitoreo"}</small>
                </div>

            </div>

            <div className="dhcp-check-strip">
                <span>Última verificación: <strong>{lastRunAt || "—"}</strong></span>
                <span>Resultado: <strong>{lastResult || "—"}</strong></span>
                <span>Estado: <strong className={healthy ? "ok-text" : "err-text"}>{healthy ? "Sin problemas" : "Requiere atención"}</strong></span>
            </div>

            <div className="dhcp-subtabs" role="tablist">

                <button
                    type="button"
                    role="tab"
                    aria-selected={section === "avisos"}
                    className={`dhcp-subtab ${section === "avisos" ? "active" : ""}`}
                    onClick={() => setSection("avisos")}
                >
                    Avisos
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={section === "rendimiento"}
                    className={`dhcp-subtab ${section === "rendimiento" ? "active" : ""}`}
                    onClick={() => setSection("rendimiento")}
                >
                    Rendimiento
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={section === "reciclaje"}
                    className={`dhcp-subtab ${section === "reciclaje" ? "active" : ""}`}
                    onClick={() => setSection("reciclaje")}
                >
                    Reciclaje
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={section === "segundo"}
                    className={`dhcp-subtab ${section === "segundo" ? "active" : ""}`}
                    onClick={() => setSection("segundo")}
                >
                    Segundo DHCP
                </button>

            </div>

            <WriteGuard>

                {section === "avisos" && (

                    <div className="dhcp-config-card">

                        <div className="dhcp-config-heading">

                            <h4>Avisos por correo</h4>

                            <p>
                                Elegí cuándo el NSP debe avisar y a quién.
                            </p>

                        </div>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={serviceAlertEnabled}
                                onChange={(e) => setServiceAlertEnabled(e.target.checked)}
                            />
                            <span>
                                <strong>Correo inmediato si DHCP cae o se cuelga</strong>
                                <small>Se envía al detectar el problema, sin esperar la verificación diaria.</small>
                            </span>
                        </label>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={scheduledCheckEnabled}
                                onChange={(e) => setScheduledCheckEnabled(e.target.checked)}
                            />
                            <span>
                                <strong>Verificación diaria programada</strong>
                                <small>Solo envía correo si encuentra problemas.</small>
                            </span>
                        </label>

                        <div className="segment-field-grid">

                            <label className="segment-field">
                                Hora de verificación
                                <input
                                    type="time"
                                    value={runTime}
                                    onChange={(e) => setRunTime(e.target.value)}
                                    disabled={!scheduledCheckEnabled}
                                />
                            </label>

                            <label className="segment-field">
                                Umbral de IPs libres
                                <input
                                    type="number"
                                    min={1}
                                    max={500}
                                    value={poolLowThreshold}
                                    onChange={(e) => setPoolLowThreshold(e.target.value)}
                                />
                                <span className="segment-field-hint">
                                    Se avisa cuando el pool queda en este valor o menos.
                                </span>
                            </label>

                        </div>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={poolLowAlertEnabled}
                                onChange={(e) => setPoolLowAlertEnabled(e.target.checked)}
                            />
                            <span>
                                <strong>Avisar si el pool de equipos se está agotando</strong>
                                <small>Se controla contra el umbral configurado arriba.</small>
                            </span>
                        </label>

                        <label className="segment-field segment-field-full">
                            Destinatarios del aviso de pool
                            <input
                                type="text"
                                value={poolLowEmails}
                                onChange={(e) => setPoolLowEmails(e.target.value)}
                                placeholder="sistemas@empresa.com, jefe@empresa.com"
                                disabled={!poolLowAlertEnabled}
                            />
                            <span className="segment-field-hint">
                                Correos separados por coma. Son independientes de los destinatarios generales.
                            </span>
                        </label>

                    </div>

                )}

                {section === "rendimiento" && (

                    <div className="dhcp-config-card">

                        <div className="dhcp-config-heading">

                            <h4>Velocidad de asignación</h4>

                            <p>
                                El ping previo evita conflictos, pero hace más lenta
                                la entrega de IPs nuevas.
                            </p>

                        </div>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={pingCheck}
                                onChange={(e) => setPingCheck(e.target.checked)}
                            />
                            <span>
                                <strong>Verificar con ping antes de ofrecer una IP nueva</strong>
                                <small>
                                    Recomendado desactivado. Con ping, dnsmasq puede
                                    esperar hasta 3 s por tanda.
                                </small>
                            </span>
                        </label>

                        <div className="dhcp-info-box">
                            <strong>Sin ping</strong>
                            <span>
                                120 equipos se atienden en menos de 1 s. Las IPs
                                fijas dentro del pool se protegen con ARP verificado.
                            </span>
                        </div>

                        <div className="dhcp-info-box warn">
                            <strong>Con ping</strong>
                            <span>
                                30 equipos nuevos pueden tardar unos 18 s. Tras un
                                corte de luz, algunos equipos podrían quedarse sin IP.
                            </span>
                        </div>

                    </div>

                )}

                {section === "reciclaje" && (

                    <div className="dhcp-config-card">

                        <div className="dhcp-config-heading">

                            <h4>Reciclaje automático de IPs</h4>

                            <p>
                                Libera direcciones de equipos ausentes cuando el pool
                                se está quedando sin espacio.
                            </p>

                        </div>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={reclaimEnabled}
                                onChange={(e) => setReclaimEnabled(e.target.checked)}
                            />
                            <span>
                                <strong>Liberar IPs sin uso cuando falten direcciones</strong>
                                <small>Las reservas nunca se tocan.</small>
                            </span>
                        </label>

                        <div className="segment-field-grid">

                            <label className="segment-field">
                                Minutos sin señal para considerar inactivo
                                <input
                                    type="number"
                                    min={5}
                                    max={1440}
                                    value={reclaimMinutes}
                                    onChange={(e) => setReclaimMinutes(e.target.value)}
                                    disabled={!reclaimEnabled}
                                />
                            </label>

                            <label className="segment-field">
                                Colchón de IPs libres a recuperar
                                <input
                                    type="number"
                                    min={1}
                                    max={500}
                                    value={reclaimTargetFree}
                                    onChange={(e) => setReclaimTargetFree(e.target.value)}
                                    disabled={!reclaimEnabled}
                                />
                            </label>

                            <label className="segment-field">
                                Cooldown entre intentos
                                <input
                                    type="number"
                                    min={0}
                                    max={3600}
                                    value={reclaimCooldown}
                                    onChange={(e) => setReclaimCooldown(e.target.value)}
                                    disabled={!reclaimEnabled}
                                />
                                <span className="segment-field-hint">En segundos.</span>
                            </label>

                        </div>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={proactiveEnabled}
                                onChange={(e) => setProactiveEnabled(e.target.checked)}
                                disabled={!reclaimEnabled}
                            />
                            <span>
                                <strong>Limpieza anticipada</strong>
                                <small>
                                    Antes de que falten IPs, libera con calma solo
                                    visitas y equipos con MAC aleatoria que ya
                                    se fueron. Nunca reinicia el DHCP.
                                </small>
                            </span>
                        </label>

                        <div className="segment-field-grid">

                            <label className="segment-field">
                                Minutos de ausencia (limpieza anticipada)
                                <input
                                    type="number"
                                    min={30}
                                    max={2880}
                                    value={proactiveMinutes}
                                    onChange={(e) => setProactiveMinutes(e.target.value)}
                                    disabled={!reclaimEnabled || !proactiveEnabled}
                                />
                                <span className="segment-field-hint">
                                    Más que el tiempo normal: aquí no hay urgencia.
                                </span>
                            </label>

                        </div>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={trendEnabled}
                                onChange={(e) => setTrendEnabled(e.target.checked)}
                            />
                            <span>
                                <strong>Avisar si el pool se agota por tendencia</strong>
                                <small>
                                    Alerta con horas de margen cuando el consumo
                                    reciente agotaría el pool (principal o de una zona).
                                </small>
                            </span>
                        </label>

                        <div className="segment-field-grid">

                            <label className="segment-field">
                                Horizonte del aviso
                                <input
                                    type="number"
                                    min={1}
                                    max={168}
                                    value={trendHours}
                                    onChange={(e) => setTrendHours(e.target.value)}
                                    disabled={!trendEnabled}
                                />
                                <span className="segment-field-hint">
                                    En horas: avisa si se agotaría dentro de este plazo.
                                </span>
                            </label>

                        </div>

                        <div className="dhcp-info-box">
                            <strong>Qué libera</strong>
                            <span>
                                Solo equipos ausentes sin ARP, DNS ni ping, y sin
                                reserva. Si el pool se llena, libera sin esperar
                                los minutos configurados.
                            </span>
                        </div>

                    </div>

                )}

                {section === "segundo" && (

                    <div className="dhcp-config-card">

                        <div className="dhcp-config-heading">

                            <h4>Segundo DHCP (router/DLink)</h4>

                            <p>
                                Registrá un DHCP externo para monitorearlo y evitar
                                que entregue IPs que choquen con el pool del NSP.
                            </p>

                        </div>

                        <label className="dhcp-toggle-card">
                            <input
                                type="checkbox"
                                checked={secondaryDhcpEnabled}
                                onChange={(e) => setSecondaryDhcpEnabled(e.target.checked)}
                            />
                            <span>
                                <strong>Registrar y monitorear un segundo DHCP</strong>
                                <small>El NSP no configura el router: solo lo vigila.</small>
                            </span>
                        </label>

                        <div className="segment-field-grid">

                            <label className="segment-field">
                                IP del router/DHCP
                                <input
                                    type="text"
                                    value={secondaryDhcpIp}
                                    onChange={(e) => setSecondaryDhcpIp(e.target.value)}
                                    placeholder="192.168.1.2"
                                    disabled={!secondaryDhcpEnabled}
                                />
                            </label>

                            <label className="segment-field">
                                Rango secundario desde
                                <input
                                    type="text"
                                    value={secondaryDhcpStart}
                                    onChange={(e) => setSecondaryDhcpStart(e.target.value)}
                                    placeholder="192.168.1.120"
                                    disabled={!secondaryDhcpEnabled}
                                />
                            </label>

                            <label className="segment-field">
                                Rango secundario hasta
                                <input
                                    type="text"
                                    value={secondaryDhcpEnd}
                                    onChange={(e) => setSecondaryDhcpEnd(e.target.value)}
                                    placeholder="192.168.1.150"
                                    disabled={!secondaryDhcpEnabled}
                                />
                            </label>

                            <label className="segment-field">
                                Notas
                                <input
                                    type="text"
                                    value={secondaryDhcpNotes}
                                    onChange={(e) => setSecondaryDhcpNotes(e.target.value)}
                                    placeholder="DLink en modo router"
                                    disabled={!secondaryDhcpEnabled}
                                />
                            </label>

                        </div>

                        <div className="dhcp-info-box warn">
                            <strong>Importante</strong>
                            <span>
                                El NSP solo excluye y monitorea este rango. Si el
                                router entrega direcciones, la configuración debe
                                hacerse en el router.
                            </span>
                        </div>

                    </div>

                )}

            </WriteGuard>

            {problems.length > 0 && (

                <div className="dhcp-problems-box">

                    <strong>Problemas detectados</strong>

                    <ul>
                        {problems.map((row, index) => (
                            <li key={`${row.code}-${index}`}>
                                <strong>{row.title}</strong>
                                {" — "}
                                {row.message}
                            </li>
                        ))}
                    </ul>

                </div>

            )}

            <div className="dhcp-config-actions">

                <span className="registry-hint">
                    Guardá los ajustes antes de cerrar. La verificación manual
                    solo comprueba el estado actual.
                </span>

                <div className="confirm-actions">

                    <button
                        className={`primary-button${busy ? " btn-busy" : ""}`}
                        onClick={handleSave}
                        disabled={busy}
                    >
                        Guardar ajustes
                    </button>

                    <button
                        className={`secondary-button${busy ? " btn-busy" : ""}`}
                        onClick={() => handleCheck(false)}
                        disabled={busy}
                    >
                        Verificar ahora
                    </button>

                    <button
                        className={`secondary-button${busy ? " btn-busy" : ""}`}
                        onClick={() => handleCheck(true)}
                        disabled={busy}
                    >
                        Forzar correo
                    </button>

                </div>

            </div>

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpAlertPanel;
