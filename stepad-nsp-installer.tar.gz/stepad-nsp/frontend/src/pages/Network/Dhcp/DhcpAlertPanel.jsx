import { useEffect, useState } from "react";

import {
    getDhcpAlertSettings,
    saveDhcpAlertSettings,
    runDhcpAlertCheck,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function DhcpAlertPanel() {

    const [serviceAlertEnabled, setServiceAlertEnabled] = useState(true);

    const [scheduledCheckEnabled, setScheduledCheckEnabled] = useState(false);

    const [runTime, setRunTime] = useState("08:00");

    const [poolLowAlertEnabled, setPoolLowAlertEnabled] = useState(false);

    const [poolLowThreshold, setPoolLowThreshold] = useState(10);

    const [reclaimEnabled, setReclaimEnabled] = useState(true);
    const [pingCheck, setPingCheck] = useState(false);

    const [reclaimMinutes, setReclaimMinutes] = useState(60);

    const [reclaimTargetFree, setReclaimTargetFree] = useState(10);

    const [reclaimCooldown, setReclaimCooldown] = useState(60);



    const [secondaryDhcpEnabled, setSecondaryDhcpEnabled] = useState(false);
    const [secondaryDhcpIp, setSecondaryDhcpIp] = useState("");
    const [secondaryDhcpStart, setSecondaryDhcpStart] = useState("");
    const [secondaryDhcpEnd, setSecondaryDhcpEnd] = useState("");
    const [secondaryDhcpNotes, setSecondaryDhcpNotes] = useState("");

    // Destinatarios PROPIOS del aviso de pool (independientes de Alertas).
    const [poolLowEmails, setPoolLowEmails] = useState("");

    const [healthy, setHealthy] = useState(true);

    const [problems, setProblems] = useState([]);

    const [lastRunAt, setLastRunAt] = useState(null);

    const [lastResult, setLastResult] = useState(null);

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpAlertSettings();

            setServiceAlertEnabled(
                data.service_alert_enabled !== false
            );
            setScheduledCheckEnabled(
                Boolean(data.scheduled_check_enabled)
            );
            setRunTime(data.run_time || "08:00");
            setPoolLowAlertEnabled(
                Boolean(data.pool_low_alert_enabled)
            );
            setPoolLowThreshold(
                Number(data.pool_low_threshold) || 10
            );
            setPoolLowEmails(
                (data.pool_low_alert_emails || []).join(", ")
            );
            setReclaimEnabled(data.pool_reclaim_enabled !== false);
            setReclaimMinutes(Number(data.pool_emergency_reclaim_minutes) || 60);
            setPingCheck(Boolean(data.ping_check));
            setReclaimTargetFree(
                Number(data.pool_reclaim_target_free) || 10
            );
            setReclaimCooldown(
                Number(data.pool_reclaim_cooldown_seconds) || 60
            );
            setSecondaryDhcpEnabled(
                Boolean(data.secondary_dhcp_enabled)
            );
            setSecondaryDhcpIp(data.secondary_dhcp_ip || "");
            setSecondaryDhcpStart(data.secondary_dhcp_pool_start || "");
            setSecondaryDhcpEnd(data.secondary_dhcp_pool_end || "");
            setSecondaryDhcpNotes(data.secondary_dhcp_notes || "");
            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setLastRunAt(data.last_run_at || null);
            setLastResult(data.last_result || null);

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudieron leer las alertas DHCP."
            );

        }

    }


    useEffect(() => {

        load();

    }, []);


    async function handleSave() {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await saveDhcpAlertSettings({
                service_alert_enabled: serviceAlertEnabled,
                scheduled_check_enabled: scheduledCheckEnabled,
                run_time: runTime,
                pool_low_alert_enabled: poolLowAlertEnabled,
                pool_low_threshold: Number(poolLowThreshold),
                pool_low_alert_emails: poolLowEmails,
                pool_reclaim_enabled: reclaimEnabled,
                ping_check: pingCheck,
                pool_emergency_reclaim_minutes: Number(reclaimMinutes),
                pool_reclaim_target_free: Number(reclaimTargetFree),
                pool_reclaim_cooldown_seconds: Number(reclaimCooldown),
                secondary_dhcp_enabled: secondaryDhcpEnabled,
                secondary_dhcp_ip: secondaryDhcpIp,
                secondary_dhcp_pool_start: secondaryDhcpStart,
                secondary_dhcp_pool_end: secondaryDhcpEnd,
                secondary_dhcp_notes: secondaryDhcpNotes,
            });

            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setMessage(
                data.message
                || "Programación de alertas guardada."
            );

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo guardar."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleCheck(forceEmail = false) {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await runDhcpAlertCheck({
                force_email: forceEmail,
            });

            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setMessage(
                `${data.message || "Verificación lista."}`
                + (data.emailed ? " Correo enviado." : "")
            );
            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo verificar."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel">

            <h3>Alertas por correo (DHCP)</h3>

            <p className="registry-hint">
                Avisos si DHCP se cae, se cuelga o si el pool de IPs se agota.
            </p>

            <WriteGuard>

                <div className="registry-form-panel">

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={serviceAlertEnabled}
                            onChange={(e) =>
                                setServiceAlertEnabled(e.target.checked)
                            }
                        />
                        Correo inmediato si DHCP cae o se cuelga
                    </label>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={scheduledCheckEnabled}
                            onChange={(e) =>
                                setScheduledCheckEnabled(e.target.checked)
                            }
                        />
                        Verificación diaria programada (solo envía si hay
                        problemas)
                    </label>

                    <div className="registry-form-grid">

                        <label>
                            Hora de verificación (HH:MM)
                            <input
                                type="time"
                                value={runTime}
                                onChange={(e) => setRunTime(e.target.value)}
                                disabled={!scheduledCheckEnabled}
                            />
                        </label>

                        <label>
                            Umbral IPs libres (pool equipos)
                            <input
                                type="number"
                                min={1}
                                max={500}
                                value={poolLowThreshold}
                                onChange={(e) =>
                                    setPoolLowThreshold(e.target.value)
                                }
                            />
                        </label>

                    </div>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={poolLowAlertEnabled}
                            onChange={(e) =>
                                setPoolLowAlertEnabled(e.target.checked)
                            }
                        />
                        Avisar si las IPs libres del pool ≤ umbral
                    </label>

                    <label>
                        Destinatarios de este aviso (correo)
                        <input
                            type="text"
                            value={poolLowEmails}
                            onChange={(e) =>
                                setPoolLowEmails(e.target.value)
                            }
                            placeholder="sistemas@empresa.com, jefe@empresa.com"
                            disabled={!poolLowAlertEnabled}
                        />
                    </label>

                    <p className="registry-hint">
                        Destinatarios propios de este aviso (separados por coma).
                    </p>

                    <p className="registry-section-label">
                        Velocidad de asignación
                    </p>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={pingCheck}
                            onChange={(e) =>
                                setPingCheck(e.target.checked)
                            }
                        />
                        Verificar con ping antes de ofrecer una IP nueva
                    </label>

                    <p className="registry-hint">
                        Recomendado desactivado. Con el ping, dnsmasq espera
                        hasta 3 s por tanda: 30 equipos nuevos tardan unos
                        18 s (y tras un corte de luz algunos equipos se quedan
                        sin IP). Sin él, 120 equipos se atienden en menos de
                        1 s. Las IPs fijas dentro del pool las protege el NSP
                        con ARP verificado.
                    </p>

                    <p className="registry-section-label">
                        Limpieza automática del pool
                    </p>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={reclaimEnabled}
                            onChange={(e) =>
                                setReclaimEnabled(e.target.checked)
                            }
                        />
                        Liberar IPs sin uso cuando falten direcciones
                    </label>

                    <div className="registry-form-grid">
                        <label>
                            Minutos sin señal para considerarlo inactivo
                            <input
                                type="number"
                                min={5}
                                max={1440}
                                value={reclaimMinutes}
                                onChange={(e) => setReclaimMinutes(e.target.value)}
                                disabled={!reclaimEnabled}
                            />
                        </label>

                        <label>
                            Colchón de IPs libres a recuperar
                            <input
                                type="number"
                                min={1}
                                max={500}
                                value={reclaimTargetFree}
                                onChange={(e) => setReclaimTargetFree(e.target.value)}
                                disabled={!reclaimEnabled}
                            />
                        </label>

                        <label>
                            Cooldown entre intentos (segundos)
                            <input
                                type="number"
                                min={0}
                                max={3600}
                                value={reclaimCooldown}
                                onChange={(e) => setReclaimCooldown(e.target.value)}
                                disabled={!reclaimEnabled}
                            />
                        </label>
                    </div>

                    <p className="registry-hint">
                        Libera solo equipos ausentes (sin ARP, DNS ni ping) y
                        sin reserva. Si el pool se llena del todo, libera sin
                        esperar esos minutos. Las reservas nunca se tocan.
                        El pool es fijo: nunca se amplía solo; si no queda
                        nada por liberar, el NSP avisa.
                    </p>

                    <p className="registry-section-label">
                        Segundo DHCP (router/DLink)
                    </p>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={secondaryDhcpEnabled}
                            onChange={(e) => setSecondaryDhcpEnabled(e.target.checked)}
                        />
                        Registrar y monitorear un segundo DHCP
                    </label>

                    <div className="registry-form-grid">
                        <label>
                            IP del router/DHCP
                            <input
                                type="text"
                                value={secondaryDhcpIp}
                                onChange={(e) => setSecondaryDhcpIp(e.target.value)}
                                placeholder="192.168.1.2"
                                disabled={!secondaryDhcpEnabled}
                            />
                        </label>
                        <label>
                            Rango secundario desde
                            <input
                                type="text"
                                value={secondaryDhcpStart}
                                onChange={(e) => setSecondaryDhcpStart(e.target.value)}
                                placeholder="192.168.1.120"
                                disabled={!secondaryDhcpEnabled}
                            />
                        </label>
                        <label>
                            Rango secundario hasta
                            <input
                                type="text"
                                value={secondaryDhcpEnd}
                                onChange={(e) => setSecondaryDhcpEnd(e.target.value)}
                                placeholder="192.168.1.150"
                                disabled={!secondaryDhcpEnabled}
                            />
                        </label>
                        <label>
                            Notas
                            <input
                                type="text"
                                value={secondaryDhcpNotes}
                                onChange={(e) => setSecondaryDhcpNotes(e.target.value)}
                                placeholder="DLink en modo router"
                                disabled={!secondaryDhcpEnabled}
                            />
                        </label>
                    </div>

                    <p className="registry-hint">
                        El NSP no configura el router; solo excluye su rango,
                        lo muestra y avisa si no responde o se solapa.
                    </p>

                    <div className="confirm-actions registry-form-actions">

                        <button
                            className={`primary-button${busy ? " btn-busy" : ""}`}
                            onClick={handleSave}
                            disabled={busy}
                        >
                            Guardar alertas
                        </button>

                        <button
                            className={`secondary-button${busy ? " btn-busy" : ""}`}
                            onClick={() => handleCheck(false)}
                            disabled={busy}
                        >
                            Verificar ahora
                        </button>

                        <button
                            className={`secondary-button${busy ? " btn-busy" : ""}`}
                            onClick={() => handleCheck(true)}
                            disabled={busy}
                        >
                            Verificar y forzar correo
                        </button>

                    </div>

                </div>

            </WriteGuard>

            <div className="lan-stat-row">
                <span className="lan-stat">
                    <span>Estado actual</span>
                    <strong className={healthy ? "ok-text" : "err-text"}>
                        {healthy ? "Saludable" : "Con problemas"}
                    </strong>
                </span>
                <span className="lan-stat">
                    <span>Última verificación</span>
                    <strong>{lastRunAt || "—"}</strong>
                </span>
                <span className="lan-stat">
                    <span>Resultado</span>
                    <strong>{lastResult || "—"}</strong>
                </span>
            </div>

            {problems.length > 0 && (
                <div className="dhcp-candidates">
                    <p className="registry-section-label">
                        Problemas detectados
                    </p>
                    <ul>
                        {problems.map((row, index) => (
                            <li key={`${row.code}-${index}`}>
                                <strong>{row.title}</strong>
                                {" — "}
                                {row.message}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpAlertPanel;
