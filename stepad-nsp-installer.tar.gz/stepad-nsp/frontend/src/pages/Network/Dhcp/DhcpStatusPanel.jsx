import { useEffect, useState } from "react";

import {
    getDhcpStatus,
    restartDhcp,
    applyDhcp,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function DhcpStatusPanel() {

    const [status, setStatus] = useState(null);

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpStatus();

            setStatus(data);

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo leer el estado de DHCP."
            );

        }

    }


    useEffect(() => {

        load();

        const timer = setInterval(load, 20000);

        return () => clearInterval(timer);

    }, []);


    async function handleRestart() {

        if (!window.confirm(
            "¿Reiniciar solo el servicio DHCP (dnsmasq)?\n\n"
            + "No reinicia el NSP completo."
        )) {
            return;
        }

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const result = await restartDhcp();

            setMessage(result?.message || "DHCP reiniciado.");

            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo reiniciar DHCP."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleApply() {

        if (!window.confirm(
            "¿Reaplicar configuración y reservas DHCP?\n\n"
            + "Se regeneran las reservas y se reinicia dnsmasq."
        )) {
            return;
        }

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const result = await applyDhcp();

            setMessage(result?.message || "DHCP reaplicado.");

            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo reaplicar DHCP."
            );

        } finally {

            setBusy(false);

        }

    }


    const running = Boolean(
        status?.running
        ?? status?.service?.running
        ?? status?.pid
    );


    const reconcile = status?.reconcile || {};

    // Contador que solo sube cuando de verdad se reinició dnsmasq: sirve
    // para verificar que la reconciliación es idempotente.
    const lastApply = reconcile.last_apply_at
        ? new Date(reconcile.last_apply_at + (reconcile.last_apply_at.endsWith("Z") ? "" : "Z"))
        : null;


    return (

        <div className="registry-panel">

            <div className="registry-panel-head">

                <div>

                    <h3>Servicio DHCP</h3>

                    <p className="registry-hint">
                        Control del servidor DHCP local (dnsmasq).
                        Reiniciar solo DHCP no detiene el resto del NSP.
                    </p>

                </div>

                <WriteGuard>

                    <div className="confirm-actions">

                        <button
                            className={`secondary-button${busy ? " btn-busy" : ""}`}
                            onClick={handleRestart}
                            disabled={busy}
                        >
                            Reiniciar DHCP
                        </button>

                        <button
                            className={`primary-button${busy ? " btn-busy" : ""}`}
                            onClick={handleApply}
                            disabled={busy}
                        >
                            Reaplicar reservas
                        </button>

                    </div>

                </WriteGuard>

            </div>

            <div className="lan-stat-row">

                <span className="lan-stat">
                    <span>Estado</span>
                    <strong className={running ? "ok-text" : "err-text"}>
                        {running ? "En ejecución" : "Detenido / desconocido"}
                    </strong>
                </span>

                {
                    status?.pid && (
                        <span className="lan-stat">
                            <span>PID</span>
                            <strong>{status.pid}</strong>
                        </span>
                    )
                }

            </div>

            <div className="lan-stat-row" style={{ marginTop: 8 }}>

                <span className="lan-stat">
                    <span>Reconciliación</span>
                    <strong className={reconcile.last_ok === false ? "err-text" : "ok-text"}>
                        {
                            reconcile.last_ok === undefined
                                ? "—"
                                : reconcile.last_ok
                                    ? "OK"
                                    : `Error: ${reconcile.last_error || "desconocido"}`
                        }
                    </strong>
                </span>

                <span className="lan-stat">
                    <span>Última</span>
                    <strong>
                        {lastApply
                            ? lastApply.toLocaleTimeString("es-EC", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
                            : "—"}
                    </strong>
                </span>

                <span className="lan-stat">
                    <span>Reinicios / sin cambios</span>
                    <strong>
                        {reconcile.restarts ?? 0} / {reconcile.skipped ?? 0}
                    </strong>
                </span>

                {
                    reconcile.pool_low && (
                        <span className="lan-stat">
                            <span>Pool</span>
                            <strong className="err-text">Casi agotado</strong>
                        </span>
                    )
                }

                {
                    (reconcile.conflicts ?? 0) > 0 && (
                        <span className="lan-stat">
                            <span>Conflictos de IP</span>
                            <strong className="err-text">{reconcile.conflicts}</strong>
                        </span>
                    )
                }

            </div>

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpStatusPanel;
