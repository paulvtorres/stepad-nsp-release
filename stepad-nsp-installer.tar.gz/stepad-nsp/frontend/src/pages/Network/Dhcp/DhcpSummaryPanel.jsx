import { useEffect, useState } from "react";

import {
    getDhcpStatus,
    getDhcpPoolStats,
    restartDhcp,
    applyDhcp,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";
import ActionButton from "../../../components/ui/ActionButton";


function formatNumber(value) {

    if (value === null || value === undefined) return "—";

    return new Intl.NumberFormat("es-EC").format(value);

}


function percent(part, total) {

    if (!total || total <= 0) return 0;

    return Math.min(100, Math.max(0, Math.round((part / total) * 100)));

}


export default function DhcpSummaryPanel() {

    const [status, setStatus] = useState(null);

    const [stats, setStats] = useState(null);

    const [busy, setBusy] = useState("");

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const [statusData, statsData] = await Promise.all([
                getDhcpStatus(),
                getDhcpPoolStats(),
            ]);

            setStatus(statusData);

            setStats(statsData);

            setError("");

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo leer el estado de DHCP."
            );

        }

    }


    useEffect(() => {

        load();

        const timer = setInterval(load, 20000);

        return () => clearInterval(timer);

    }, []);


    async function handleRestart() {

        if (!window.confirm(
            "¿Reiniciar solo el servicio DHCP (dnsmasq)?\n\n"
            + "No reinicia el NSP completo."
        )) {
            return;
        }

        setBusy("restart");
        setMessage("");
        setError("");

        try {

            const result = await restartDhcp();

            setMessage(result?.message || "DHCP reiniciado.");

            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo reiniciar DHCP."
            );

        } finally {

            setBusy("");

        }

    }


    async function handleApply() {

        if (!window.confirm(
            "¿Reaplicar configuración y reservas DHCP?\n\n"
            + "Se regeneran las reservas y se reinicia dnsmasq."
        )) {
            return;
        }

        setBusy("apply");
        setMessage("");
        setError("");

        try {

            const result = await applyDhcp();

            setMessage(result?.message || "DHCP reaplicado.");

            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo reaplicar DHCP."
            );

        } finally {

            setBusy("");

        }

    }


    const running = Boolean(
        status?.running
        ?? status?.service?.running
        ?? status?.pid
    );

    const reconcile = status?.reconcile || {};

    const devices = stats?.devices || {};

    const groups = stats?.groups || {};

    const overall = stats?.overall || {};

    const network = stats?.network || {};

    const staticInPool = stats?.static_in_pool || [];

    const poolTotal = Number(devices.dynamic ?? 0);

    const poolFree = Number(devices.free ?? 0);

    const poolUsed = Math.max(0, poolTotal - poolFree);

    const groupTotal = Number(groups.total ?? 0);

    const groupUsed = Number(groups.used ?? 0);

    const lastApply = reconcile.last_apply_at
        ? new Date(
            reconcile.last_apply_at
            + (reconcile.last_apply_at.endsWith("Z") ? "" : "Z")
        )
        : null;

    const hasConflict = (reconcile.conflicts ?? 0) > 0;

    const zones = stats?.zones || [];

    const zonesLow = zones.some((zone) => zone.low);

    const poolLow = Boolean(reconcile.pool_low) || zonesLow;


    return (

        <div className="dhcp-overview">

            <div className={`dhcp-overview-hero ${running ? "ok" : "warn"}`}>

                <div className="dhcp-overview-hero-main">

                    <span className="dhcp-overview-eyebrow">ESTADO DEL SERVICIO</span>

                    <h3>
                        {running
                            ? "Servicio DHCP operativo"
                            : "Servicio DHCP detenido o desconocido"}
                    </h3>

                    <p>
                        {stats
                            ? `Pool ${stats.pool_start}–${stats.pool_end} · ${formatNumber(poolFree)} IPs libres · ${formatNumber(devices.leased ?? 0)} asignadas`
                            : "Cargando estado del pool y del servicio…"}
                    </p>

                </div>

                <div className="dhcp-overview-hero-side">

                    <span className={`dhcp-overview-pill ${running ? "ok" : "warn"}`}>
                        {running ? "EN EJECUCIÓN" : "DETENIDO"}
                    </span>

                    {lastApply && (
                        <small>
                            Última aplicación:{" "}
                            {lastApply.toLocaleTimeString("es-EC", {
                                hour: "2-digit",
                                minute: "2-digit",
                                second: "2-digit",
                            })}
                        </small>
                    )}

                </div>

            </div>

            <div className="dhcp-overview-kpis">

                <div className={`dhcp-overview-kpi ${poolLow ? "warn" : "ok"}`}>
                    <span>IPs libres</span>
                    <strong>{formatNumber(overall.free)}</strong>
                    <small>
                        {reconcile.pool_low
                            ? "Pool casi agotado"
                            : zonesLow
                                ? "Una zona casi sin IPs"
                                : "Disponibles ahora"}
                    </small>
                </div>

                <div className="dhcp-overview-kpi accent">
                    <span>Asignadas</span>
                    <strong>{formatNumber(devices.leased)}</strong>
                    <small>Leases activos en el pool</small>
                </div>

                <div className="dhcp-overview-kpi">
                    <span>En la red ahora</span>
                    <strong>{formatNumber(network.present)}</strong>
                    <small>
                        {formatNumber(network.in_pool)} en pool ·{" "}
                        {formatNumber(network.outside_pool)} fuera
                    </small>
                </div>

                <div className={`dhcp-overview-kpi ${hasConflict ? "warn" : ""}`}>
                    <span>Conflictos</span>
                    <strong>{formatNumber(reconcile.conflicts ?? 0)}</strong>
                    <small>{hasConflict ? "Revisar IPs duplicadas" : "Sin conflictos detectados"}</small>
                </div>

            </div>

            <div className="dhcp-overview-grid">

                <section className="dhcp-overview-card">

                    <header className="dhcp-overview-card-head">

                        <div>
                            <h4>Servicio y reconciliación</h4>
                            <p>dnsmasq, reservas y última aplicación.</p>
                        </div>

                        <span className={`dhcp-overview-state ${reconcile.last_ok === false ? "warn" : "ok"}`}>
                            {reconcile.last_ok === undefined
                                ? "Sin datos"
                                : reconcile.last_ok
                                    ? "OK"
                                    : "Con error"}
                        </span>

                    </header>

                    <div className="dhcp-overview-rows">

                        <div>
                            <span>Estado</span>
                            <strong className={running ? "ok-text" : "err-text"}>
                                {running ? "En ejecución" : "Detenido"}
                            </strong>
                        </div>

                        {status?.pid && (
                            <div>
                                <span>PID</span>
                                <strong>{status.pid}</strong>
                            </div>
                        )}

                        <div>
                            <span>Última aplicación</span>
                            <strong>
                                {lastApply
                                    ? lastApply.toLocaleString("es-EC")
                                    : "—"}
                            </strong>
                        </div>

                        <div>
                            <span>Reinicios / sin cambios</span>
                            <strong>
                                {reconcile.restarts ?? 0} / {reconcile.skipped ?? 0}
                            </strong>
                        </div>

                        {reconcile.last_error && (
                            <div className="dhcp-overview-row-error">
                                <span>Último error</span>
                                <strong>{reconcile.last_error}</strong>
                            </div>
                        )}

                    </div>

                    <WriteGuard>

                        <div className="dhcp-overview-actions">

                            <ActionButton
                                variant="secondary"
                                loading={busy === "restart"}
                                disabled={Boolean(busy)}
                                onClick={handleRestart}
                            >
                                Reiniciar DHCP
                            </ActionButton>

                            <ActionButton
                                variant="primary"
                                loading={busy === "apply"}
                                disabled={Boolean(busy)}
                                onClick={handleApply}
                            >
                                Reaplicar reservas
                            </ActionButton>

                        </div>

                    </WriteGuard>

                </section>

                <section className="dhcp-overview-card">

                    <header className="dhcp-overview-card-head">

                        <div>
                            <h4>Uso del pool</h4>
                            <p>
                                {stats
                                    ? `${stats.pool_start}–${stats.pool_end}`
                                    : "Cargando rango…"}
                            </p>
                        </div>

                        <span className="dhcp-overview-state">
                            {formatNumber(poolUsed)} / {formatNumber(poolTotal)}
                        </span>

                    </header>

                    <div className="dhcp-overview-progress-block">

                        <div className="dhcp-overview-progress-label">
                            <span>Ocupación del pool</span>
                            <strong>{percent(poolUsed, poolTotal)}%</strong>
                        </div>

                        <div className="dhcp-overview-progress">
                            <span style={{ width: `${percent(poolUsed, poolTotal)}%` }} />
                        </div>

                    </div>

                    <div className="dhcp-overview-rows compact">

                        <div>
                            <span>Asignadas</span>
                            <strong>{formatNumber(devices.leased)}</strong>
                        </div>

                        <div>
                            <span>Reservadas</span>
                            <strong>
                                {formatNumber(devices.reserved)}
                                {" "}
                                ({formatNumber(devices.reserved_in_use)} en uso)
                            </strong>
                        </div>

                        <div>
                            <span>Libres</span>
                            <strong>{formatNumber(devices.free)}</strong>
                        </div>

                        <div>
                            <span>IPs de grupos</span>
                            <strong>
                                {formatNumber(groupUsed)} / {formatNumber(groupTotal)} usadas
                            </strong>
                        </div>

                    </div>

                    <div className="dhcp-overview-progress-block">

                        <div className="dhcp-overview-progress-label">
                            <span>IPs de grupos</span>
                            <strong>{percent(groupUsed, groupTotal)}%</strong>
                        </div>

                        <div className="dhcp-overview-progress groups">
                            <span style={{ width: `${percent(groupUsed, groupTotal)}%` }} />
                        </div>

                    </div>

                </section>

            </div>

            {zones.length > 0 && (

                <section className="dhcp-overview-card dhcp-zones-card">

                    <header className="dhcp-overview-card-head">

                        <div>
                            <h4>Zonas</h4>
                            <p>
                                Pool de cada zona adicional (VLAN o 2.ª LAN).
                                Mismos umbrales que las alertas.
                            </p>
                        </div>

                        <span className={`dhcp-overview-state ${zonesLow ? "warn" : "ok"}`}>
                            {zones.length}
                        </span>

                    </header>

                    <div className="dhcp-zone-list">

                        {zones.map((zone) => {

                            const total = Number(zone.dynamic ?? 0);

                            const free = Number(zone.free ?? 0);

                            const used = Math.max(0, total - free);

                            const state = zone.exhausted
                                ? "err"
                                : zone.low
                                    ? "warn"
                                    : "";

                            return (

                                <div
                                    key={zone.name}
                                    className={`dhcp-zone-row ${state}`}
                                >

                                    <div className="dhcp-zone-row-head">
                                        <strong>{zone.name}</strong>
                                        <span>{zone.pool_start}–{zone.pool_end}</span>
                                    </div>

                                    <div className="dhcp-overview-progress">
                                        <span style={{ width: `${percent(used, total)}%` }} />
                                    </div>

                                    <small>
                                        {formatNumber(used)} / {formatNumber(total)} usadas
                                        {" · "}
                                        {formatNumber(free)} libres
                                        {zone.exhausted
                                            ? " · sin IPs libres"
                                            : zone.low
                                                ? ` · pocas IPs (umbral ${formatNumber(zone.threshold)})`
                                                : ""}
                                    </small>

                                </div>

                            );

                        })}

                    </div>

                </section>

            )}

            {staticInPool.length > 0 && (
                <div className="dhcp-static-warning">
                    <strong>
                        {staticInPool.length} equipo(s) con IP fija dentro del pool
                    </strong>
                    <p>
                        Pueden chocar con una asignación automática. Cambiá su
                        IP, excluila o creá una reserva.
                    </p>
                </div>
            )}

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}
