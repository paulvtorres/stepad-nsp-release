import { useEffect, useState } from "react";

import { getDeviceRules, deleteDeviceRule } from "../../../../services/api";


function DeviceRules({ device }) {

    const [rules, setRules] = useState([]);

    const [error, setError] = useState(null);


    useEffect(() => {

        async function loadRules() {

            if (!device)

                return;


            try {

                const data = await getDeviceRules(device.id);

                setRules(data);

            } catch (error) {

                console.error(error);

            }

        }


        loadRules();


    }, [device]);


    if (!device) {

        return <p>Selecciona un dispositivo...</p>;

    }

    async function handleDelete(ruleId) {

        setError(null);

        try {

            await deleteDeviceRule(ruleId);


            setRules(

                rules.filter(

                    rule => rule.id !== ruleId

                )

            );


        } catch (error) {

            console.error(error);

            setError(error.message || "No se pudo eliminar la regla.");

        }

    }

    return (

        <div className="card">

            <h3>
                Reglas de bloqueo
            </h3>

            <p style={{ color: "var(--muted)", fontSize: 13, marginTop: -8 }}>

                Reglas específicas de este dispositivo. Si no ves ninguna,
                este equipo sigue la política de su zona y el bloqueo global.

            </p>


            {
                error && <p style={{ color: "var(--danger)", fontSize: 13 }}>{error}</p>
            }


            {
                rules.length === 0 && (

                    <p style={{ color: "var(--muted)", fontSize: 13 }}>

                        Sin reglas específicas para este dispositivo.

                    </p>

                )
            }


            <table>

                <thead>

                    <tr>

                        <th>Tipo</th>

                        <th>Acción</th>

                        <th>Valor</th>

                        <th>Estado</th>

                        <th>Acción</th>

                    </tr>

                </thead>


                <tbody>

                    {
                        rules.map((rule) => (

                            <tr key={rule.id}>

                                <td>
                                    {rule.rule_type}
                                </td>

                                <td>
                                    {rule.action}
                                </td>

                                <td>
                                    {rule.value}
                                </td>

                                <td>
                                    {rule.enabled ? "Activo" : "Inactivo"}
                                </td>
                                <td>

                                    <button

                                        onClick={() => handleDelete(rule.id)}

                                    >

                                        Eliminar

                                    </button>

                                </td>

                            </tr>

                        ))
                    }

                </tbody>


            </table>


        </div>

    );


}


export default DeviceRules;
