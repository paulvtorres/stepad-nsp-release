import { useEffect, useState } from "react";

import { getZones, updateDevice, refreshDevice } from "../../../../services/api";


function DeviceSettings({ device }) {

    const [zones, setZones] = useState([]);

    const [bandwidthMbps, setBandwidthMbps] = useState("");

    const [zoneId, setZoneId] = useState("");

    const [busy, setBusy] = useState(false);

    const [notice, setNotice] = useState(null);

    const [error, setError] = useState(null);


    useEffect(() => {

        getZones()

            .then(setZones)

            .catch(() => {});

    }, []);


    useEffect(() => {

        if (device) {

            setBandwidthMbps(
                device.bandwidth_limit_kbps
                    ? (device.bandwidth_limit_kbps / 1000)
                    : ""
            );

            setZoneId(device.zone_id || "");

        }

    }, [device?.id]);


    if (!device) {

        return <p>Selecciona un dispositivo...</p>;

    }


    async function handleSave() {

        setBusy(true);

        setError(null);

        setNotice(null);

        const kbps = bandwidthMbps === "" ? null : (Number(bandwidthMbps) * 1000);

        if (kbps !== null && (!Number.isFinite(kbps) || kbps <= 0)) {

            setError("Ingresa un valor válido en Mbps.");

            setBusy(false);

            return;

        }

        try {

            await updateDevice(device.id, {
                zone_id: zoneId ? Number(zoneId) : null,
                bandwidth_limit_kbps: kbps
            });

            setNotice("Configuración guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRefresh() {

        setBusy(true);

        setError(null);

        setNotice(null);

        try {

            const result = await refreshDevice(device.id);

            setNotice(
                result?.message || "Dispositivo actualizado."
            );

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="card">

            <h3>Configuración del dispositivo</h3>

            {
                error && (
                    <div className="maintenance-error" style={{ marginBottom: 12 }}>
                        {error}
                    </div>
                )
            }

            {
                notice && (
                    <div className="notification-ok">{notice}</div>
                )
            }

            <table>

                <tbody>

                    <tr>
                        <td style={{ width: 220 }}>Nombre de equipo</td>
                        <td>{device.hostname || "-"}</td>
                    </tr>

                    <tr>
                        <td>Tipo</td>
                        <td>{device.device_type || "-"}</td>
                    </tr>

                    <tr>
                        <td>Estado</td>
                        <td>{device.status || "-"}</td>
                    </tr>

                    <tr>
                        <td>Dirección MAC</td>
                        <td>{device.mac_address || "-"}</td>
                    </tr>

                    <tr>
                        <td>Dirección IP</td>
                        <td>{device.ip_address || "-"}</td>
                    </tr>

                    <tr>
                        <td>Interfaz</td>
                        <td>{device.interface || "-"}</td>
                    </tr>

                </tbody>

            </table>

            <h4 style={{ margin: "16px 0 8px" }}>Zona</h4>

            <select
                value={zoneId}
                onChange={(e) => setZoneId(e.target.value)}
                disabled={busy}
            >
                <option value="">Sin asignar</option>
                {
                    zones.map((zone) => (
                        <option key={zone.id} value={zone.id}>
                            {zone.name}
                            {zone.is_default ? " (default)" : ""}
                        </option>
                    ))
                }
            </select>

            <h4 style={{ margin: "16px 0 8px" }}>Ancho de banda (Mbps)</h4>

            <input
                type="number"
                min="1"
                placeholder="Mbps (vacío = sin límite)"
                value={bandwidthMbps}
                onChange={(e) => setBandwidthMbps(e.target.value)}
                disabled={busy}
                style={{ width: 220 }}
            />

            <div className="confirm-actions" style={{ marginTop: 18 }}>

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={busy}
                >
                    {busy ? "Guardando..." : "Guardar"}
                </button>

                <button
                    className="secondary-button"
                    onClick={handleRefresh}
                    disabled={busy}
                >
                    Actualizar datos del equipo
                </button>

            </div>

        </div>

    );

}


export default DeviceSettings;
