import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import { getEncryptedDnsStatus } from "../../../../services/api";


function DeviceSecurity({ device }) {

    const [encryptedDns, setEncryptedDns] = useState(null);


    useEffect(() => {

        async function load() {

            try {

                const data = await getEncryptedDnsStatus();

                setEncryptedDns(data);

            } catch (error) {

                console.error(error);

            }

        }


        load();


    }, []);


    if (!device) {

        return <p>Selecciona un dispositivo...</p>;

    }


    const layers = [

        {

            title: "Bloqueo de dominios",

            ok: true,

            detail: "Aplicado por el resolver para toda la red según la zona del dispositivo."

        },

        {

            title: "Bloqueo DoT/DoH",

            ok: Boolean(encryptedDns?.enabled),

            detail: encryptedDns?.enabled

                ? `${encryptedDns.blocklist_ips} resolutores públicos bloqueados en el firewall.`

                : "Inactivo — este equipo podría evadir el bloqueo usando DNS cifrado externo."

        },

        {

            title: "Bloqueo por IP de servicios",

            ok: Boolean(encryptedDns?.service_block_enabled),

            detail: encryptedDns?.service_block_enabled

                ? `Conexiones hacia Meta/Facebook cortadas (${encryptedDns.service_ipv4_ranges} rangos IPv4, ${encryptedDns.service_ipv6_ranges} IPv6).`

                : "Inactivo."

        }

    ];


    return (

        <div className="card">

            <h3>Seguridad aplicada</h3>

            <p style={{ color: "var(--muted)", fontSize: 13, marginTop: -8 }}>

                La protección que cubre a este equipo. Los bloqueos globales
                se administran en la sección <strong>Seguridad</strong> y la
                política de su zona en <strong>Zonas</strong>.

            </p>


            <table>

                <tbody>

                    {
                        layers.map(layer => (

                            <tr key={layer.title}>

                                <td style={{ width: 220 }}>

                                    {layer.ok ? "🟢" : "🔴"} {layer.title}

                                </td>

                                <td style={{ color: "var(--muted)", fontSize: 13 }}>

                                    {layer.detail}

                                </td>

                            </tr>

                        ))
                    }

                </tbody>

            </table>


            <p style={{ fontSize: 13 }}>

                Zona asignada:{" "}

                <strong>

                    {device.zone?.name || device.zone_name || "Sin asignar"}

                </strong>

            </p>


            <Link to="/security" style={{ color: "var(--primary)", fontSize: 13 }}>

                Administrar bloqueos globales →

            </Link>

        </div>

    );


}


export default DeviceSecurity;
