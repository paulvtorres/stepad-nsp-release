function DeviceGeneral({ device }) {


    if (!device)
        return <p>Loading...</p>;


    return (

        <div className="card">

            <h3>Información del dispositivo</h3>

            <table>

                <tbody>

                    <tr>
                        <td>Dirección IP</td>
                        <td>{device.ip_address}</td>
                    </tr>


                    <tr>
                        <td>MAC</td>
                        <td>{device.mac_address}</td>
                    </tr>


                    <tr>
                        <td>Interfaz</td>
                        <td>{device.interface || "-"}</td>
                    </tr>


                    <tr>
                        <td>Estado</td>
                        <td>{device.status || "-"}</td>
                    </tr>


                    <tr>
                        <td>Tipo</td>
                        <td>{device.device_type || "-"}</td>
                    </tr>


                    <tr>
                        <td>Nombre de equipo</td>
                        <td>{device.hostname || "-"}</td>
                    </tr>


                    <tr>
                        <td>Zona</td>
                        <td>{device.zone?.name || device.zone_name || "Sin asignar"}</td>
                    </tr>


                    <tr>
                        <td>Grupo</td>
                        <td>
                            {
                                device.groups && device.groups.length > 0
                                    ? device.groups.map((g) => g.name).join(", ")
                                    : "Sin asignar (usa el grupo por defecto)"
                            }
                        </td>
                    </tr>


                </tbody>

            </table>

        </div>

    );

}

export default DeviceGeneral;