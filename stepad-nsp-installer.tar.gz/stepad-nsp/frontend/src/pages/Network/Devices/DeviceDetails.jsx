import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { getDevice, refreshDevice, deleteDevice } from "../../../services/api";

import DeviceGeneral from "./Components/DeviceGeneral";
import DeviceRules from "./Components/DeviceRules";
import DeviceActivity from "./Components/DeviceActivity";
import DeviceSecurity from "./Components/DeviceSecurity";
import DeviceSettings from "./Components/DeviceSettings";


function DeviceDetails() {

    const { deviceId } = useParams();
    const [device, setDevice] = useState(null);

    const [busy, setBusy] = useState(false);

    const navigate = useNavigate();
    const [tab, setTab] = useState("general");


    useEffect(() => {

        async function loadDevice() {

            try {

                const data = await getDevice(deviceId);

                setDevice(data);

            } catch (error) {

                console.error(error);

            }

        }


        if (deviceId) {

            loadDevice();

        }

    }, [deviceId]);



    async function handleRefresh() {

        setBusy(true);

        try {

            const result = await refreshDevice(deviceId);

            if (result && result.changed) {

                const fresh = await getDevice(deviceId);

                setDevice(fresh);

                alert(result.message || "Dispositivo actualizado.");

            } else {

                alert(result.message || "No hay nada que actualizar.");

            }

        } catch (error) {

            console.error(error);

            alert("No se pudo actualizar el dispositivo.");

        } finally {

            setBusy(false);

        }

    }


    async function handleDelete() {

        if (!window.confirm(
            `¿Eliminar el dispositivo "${device?.hostname || "desconocido"}"?\n\n` +
            "Se quitará del listado junto con sus reglas y grupos."
        )) {

            return;

        }

        setBusy(true);

        try {

            await deleteDevice(deviceId);

            navigate("/network/devices");

        } catch (error) {

            console.error(error);

            alert("No se pudo eliminar el dispositivo.");

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="device-details">

            <h2>Gestión del dispositivo</h2>

            <div className="confirm-actions" style={{ marginBottom: 16 }}>

                <button className="secondary-button" onClick={handleRefresh} disabled={busy}>
                    {busy ? "Actualizando..." : "Actualizar datos"}
                </button>

                <button className="secondary-button" onClick={() => navigate("/network/devices")}>
                    Volver
                </button>

                <button className="secondary-button" onClick={handleDelete} disabled={busy}>
                    Eliminar dispositivo
                </button>

            </div>

            <div className="tabs">

                <button onClick={() => setTab("general")}>
                    General
                </button>

                <button onClick={() => setTab("rules")}>
                    Reglas de bloqueo
                </button>

                <button onClick={() => setTab("activity")}>
                    Actividad
                </button>

                <button onClick={() => setTab("security")}>
                    Seguridad
                </button>

                <button onClick={() => setTab("settings")}>
                    Configuración
                </button>

            </div>


            {tab === "general" &&
                <DeviceGeneral device={device} />
            }

            {tab === "rules" &&
                <DeviceRules
                    key={device?.id}
                    device={device}
                />
            }

            {tab === "activity" &&
                <DeviceActivity device={device} />
            }

            {tab === "security" &&
                <DeviceSecurity device={device} />
            }

            {tab === "settings" &&
                <DeviceSettings device={device} />
            }


        </div>

    );

}


export default DeviceDetails;