import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../../../auth/useAuth";

import { getDevices, scanDevices, getZones, updateDevice, linkDevice, unlinkDevice } from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";

import "./devices.css";


function Devices() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";


    const [devices, setDevices] = useState([]);

    const [zones, setZones] = useState([]);

    const [search, setSearch] = useState("");

    const [filter, setFilter] = useState("ALL");

    const [showInfra, setShowInfra] = useState(false);

    const [showExtra, setShowExtra] = useState(false);

    const [linkOpen, setLinkOpen] = useState(null);

    const [linkPrimary, setLinkPrimary] = useState("");

    const [sortKey, setSortKey] = useState("status");

    const [sortDir, setSortDir] = useState("asc");


    const navigate = useNavigate();

    const [scanning, setScanning] = useState(false);

    useEffect(() => {

        loadDevices();

        loadZones();

        // Refresco automatico cada 30s: las luces verde/roja se
        // actualizan solas (sin pulsar "Escanear red").
        const timer = setInterval(() => {

            getDevices(showInfra)

                .then(setDevices)

                .catch(() => {});

        }, 30000);

        return () => clearInterval(timer);

    }, []);


    async function loadZones() {

        try {

            const data = await getZones();

            setZones(data);

        } catch (error) {

            console.error(error);

        }

    }


    async function handleZoneChange(deviceId, zoneId) {

        try {

            await updateDevice(
                deviceId,
                { zone_id: zoneId ? Number(zoneId) : null }
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleDeviceBandwidth(device, value) {

        const mbps = String(value).trim();

        const kbps = mbps === "" ? null : (Number(mbps) * 1000);

        if (kbps !== null && (!Number.isFinite(kbps) || kbps <= 0)) {

            alert("Ingresa un valor válido en Mbps");

            loadDevices();

            return;

        }

        try {

            await updateDevice(
                device.id,
                { bandwidth_limit_kbps: kbps }
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

            alert("No se pudo guardar el ancho de banda.");

        }

    }


    async function handleLinkDevice(deviceId, primaryDeviceId) {

        if (!primaryDeviceId) {

            return;

        }

        try {

            await linkDevice(
                deviceId,
                Number(primaryDeviceId)
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleUnlinkDevice(deviceId) {

        try {

            await unlinkDevice(
                deviceId
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function loadDevices() {

        setScanning(true);

        try {

            const data = await getDevices(showInfra);

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }


    function handleToggleInfra() {

        setShowInfra((prev) => {

            const next = !prev;

            getDevices(next).then(setDevices).catch(console.error);

            return next;

        });

    }


    async function handleScan() {

        setScanning(true);

        try {

            const data = await scanDevices();

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }

const deviceTypes = {

    COMPUTER: "💻 Computadora",

    MOBILE: "📱 Celular",

    PRINTER: "🖨 Impresora",

    ROUTER: "📡 Router",

    IP_PHONE: "☎️ Teléfono",

    CAMERA: "🎥 Cámara",

    ACCESO: "🛡️ Acceso/Asistencia",

    OTRO: "❓ Otro",

    HOST: "❓ Otro",

    UNKNOWN: "❓ Otro"

};


const statusLabels = {

    ONLINE: "En línea",

    OFFLINE: "Sin conexión",

    UNKNOWN: "Desconocido",

    BLOCKED: "Bloqueado"

};


    const filteredDevices = devices.filter((device) => {


        const text = (

            `${device.hostname || ""}
             ${device.ip_address || ""}
             ${device.mac_address || ""}`

        ).toLowerCase();



        const matchesSearch =
            text.includes(
                search.toLowerCase()
            );



        const matchesStatus =
            filter === "ALL"
            ||
            device.status === filter;



        return matchesSearch && matchesStatus;


    });


    const sortedDevices = [...filteredDevices].sort((a, b) => {

        let va, vb;

        if (sortKey === "status") {

            // ONLINE primero siempre (independiente de la direccion).
            va = a.status === "ONLINE" ? 0 : 1;

            vb = b.status === "ONLINE" ? 0 : 1;

        } else {

            va = (a[sortKey] ?? "").toString().toLowerCase();

            vb = (b[sortKey] ?? "").toString().toLowerCase();

        }

        if (va < vb) return sortDir === "asc" ? -1 : 1;

        if (va > vb) return sortDir === "asc" ? 1 : -1;

        return 0;

    });


    function handleSort(key) {

        if (sortKey === key) {

            setSortDir((d) => (d === "asc" ? "desc" : "asc"));

        } else {

            setSortKey(key);

            setSortDir("asc");

        }

    }





    const onlineDevices =
        devices.filter(
            d => d.status === "ONLINE"
        ).length;



    const offlineDevices =
        devices.length - onlineDevices;





    function formatDate(date) {


        if (!date) {

            return "-";

        }


        return new Date(date)
            .toLocaleString();


    }





    return (


        <div className="devices-container">


            <div className="devices-header">

                <div>

                    <h2>

                        Dispositivos de red

                    </h2>

                    <p>

                        Descubre, monitorea y administra todos los equipos conectados a tu red protegida.

                    </p>

                </div>

                <button

                    className={`scan-button ${scanning ? "scanning" : ""}`}

                    onClick={handleScan}

                    disabled={scanning}

                >

                    <span className="scan-icon">

                        {scanning ? "⟳" : "🔄"}

                    </span>

                    {scanning ? "Escaneando..." : "Escanear red"}

                </button>

            </div>

            <div className="device-summary">

                <div className="summary-item">

                    <span className="summary-label">
                        Total de dispositivos
                    </span>

                    <span className="summary-value">
                        {devices.length}
                    </span>

                </div>

                <div className="summary-divider"></div>

                <div className="summary-item">

                    <span className="summary-label">
                        En línea
                    </span>

                    <span className="summary-value online">
                        {onlineDevices}
                    </span>

                </div>

                <div className="summary-divider"></div>

                <div className="summary-item">

                    <span className="summary-label">
                        Sin conexión
                    </span>

                    <span className="summary-value offline">
                        {offlineDevices}
                    </span>

                </div>

            </div>

            <div className="device-toolbar">

                <input

                    type="text"

                    placeholder="Buscar por nombre, IP o MAC..."

                    value={search}

                    onChange={
                        e => setSearch(e.target.value)
                    }

                />

                <select

                    value={filter}

                    onChange={
                        e => setFilter(e.target.value)
                    }

                >

                    <option value="ALL">
                        Todos
                    </option>

                    <option value="ONLINE">
                        En línea
                    </option>

                    <option value="OFFLINE">
                        Sin conexión
                    </option>

                    <option value="UNKNOWN">
                        Desconocidos
                    </option>

                </select>

                <label className="checkbox-label" style={{ marginLeft: 8 }}>
                    <input
                        type="checkbox"
                        checked={showInfra}
                        onChange={handleToggleInfra}
                    />
                    Mostrar dispositivos de red (impresoras, teléfonos IP)
                </label>

                <button
                    className="secondary-button"
                    style={{ marginLeft: 8 }}
                    onClick={() => setShowExtra(!showExtra)}
                >
                    {showExtra ? "Ocultar detalles" : "Ver detalles"}
                </button>
            </div>




            <div className="devices-table-wrap">

            <div className="table-card">

                <table className="devices-table">


                    <thead>

                        <tr>

                            <th style={{ width: 30 }}></th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("hostname")}>
                                    Nombre {sortKey === "hostname" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("device_type")}>
                                    Tipo {sortKey === "device_type" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("ip_address")}>
                                    IP {sortKey === "ip_address" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            {
                                showExtra && (
                                    <>
                                        <th>MAC</th>

                                        <th>Zona</th>

                                        <th>Última vez</th>

                                        <th>Acciones</th>
                                    </>
                                )
                            }


                        </tr>

                    </thead>




                    <tbody>


                        {
                            sortedDevices.map((device) => (


                                <tr key={device.id}>


                                    <td>

                                        <span
                                            title={
                                                device.status === "ONLINE"
                                                    ? "En línea"
                                                    : "Sin conexión"
                                            }
                                            style={{
                                                display: "inline-block",
                                                width: 14,
                                                height: 14,
                                                borderRadius: "50%",
                                                background: device.status === "ONLINE"
                                                    ? "#22c55e"
                                                    : "#ef4444",
                                                boxShadow: device.status === "ONLINE"
                                                    ? "0 0 6px rgba(34,197,94,0.7)"
                                                    : "0 0 6px rgba(239,68,68,0.7)",
                                            }}
                                        />
                                    </td>



                                    <td>

                                        <div className="device-name-cell">

                                            <span className="device-name-value">
                                                {device.hostname || "Desconocido"}
                                            </span>

                                        </div>

                                    </td>


                                    <td>

                                        <span className={`device-type ${device.device_type?.toLowerCase()}`}>

                                            {

                                                deviceTypes[

                                                device.device_type?.toUpperCase()

                                                ]

                                                ||

                                                "❓ Desconocido"

                                            }

                                        </span>

                                        <span
                                            style={{
                                                marginLeft: 6,
                                                fontSize: 11,
                                                padding: "1px 6px",
                                                borderRadius: 10,
                                                background: device.navigates
                                                    ? "rgba(34,197,94,0.15)"
                                                    : "rgba(107,114,128,0.15)",
                                                color: device.navigates ? "#16a34a" : "#6b7280",
                                                border: `1px solid ${device.navigates ? "#22c55e" : "#9ca3af"}`,
                                            }}
                                        >
                                            {device.navigates ? "Navega" : "No navega"}
                                        </span>

                                    </td>

                                    <td>

                                        {device.ip_address}

                                    </td>


                                    {
                                        showExtra && (
                                            <>

                                    <td>

                                        <div className="mac-cell">

                                            {device.mac_address || "-"}

                                            {
                                                (device.linked_devices || []).length > 0 && (
                                                    <span className="linked-badge">
                                                        +{device.linked_devices.length} NICs
                                                    </span>
                                                )
                                            }

                                        </div>

                                    </td>




                                    <td>

                                        {
                                            isAdmin ? (
                                                <select
                                                    value={device.zone_id || ""}
                                                    onChange={(e) =>
                                                        handleZoneChange(
                                                            device.id,
                                                            e.target.value
                                                        )
                                                    }
                                                >

                                                    <option value="">
                                                        Sin asignar
                                                    </option>

                                                    {
                                                        zones.map((zone) => (
                                                            <option
                                                                key={zone.id}
                                                                value={zone.id}
                                                            >
                                                                {zone.name}
                                                                {zone.is_default ? " (default)" : ""}
                                                            </option>
                                                        ))
                                                    }

                                                </select>
                                            ) : (
                                                <span className="zone-readonly">
                                                    {device.zone_id
                                                        ? (zones.find((z) => z.id === device.zone_id)?.name || device.zone_id)
                                                        : "Sin asignar"}
                                                </span>
                                            )
                                        }
                                    </td>




                                    <td>

                                        {formatDate(device.last_seen)}

                                    </td>

                                    <td>

                                        <div className="manage-menu">

                                            <button
                                                className="manage-button"
                                                onClick={() =>
                                                    navigate(
                                                        `/network/devices/${device.id}`
                                                    )
                                                }
                                            >

                                                Gestionar

                                            </button>

                                            <button
                                                className="manage-button"
                                                onClick={() => {
                                                    setLinkOpen(linkOpen === device.id ? null : device.id);
                                                    setLinkPrimary("");
                                                }}
                                            >
                                                Vincular
                                            </button>

                                            {
                                                linkOpen === device.id && (
                                                    <div style={{ marginTop: 6, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                                                        <select
                                                            value={linkPrimary}
                                                            onChange={(e) => setLinkPrimary(e.target.value)}
                                                        >
                                                            <option value="">-- Equipo principal --</option>
                                                            {
                                                                devices
                                                                    .filter((d) => d.id !== device.id)
                                                                    .map((d) => (
                                                                        <option key={d.id} value={d.id}>
                                                                            {d.hostname || d.ip_address || d.mac_address || `#${d.id}`}
                                                                        </option>
                                                                    ))
                                                            }
                                                        </select>
                                                        <button
                                                            className="secondary-button small"
                                                            disabled={!linkPrimary}
                                                            onClick={() => {
                                                                handleLinkDevice(device.id, Number(linkPrimary));
                                                                setLinkOpen(null);
                                                            }}
                                                        >
                                                            Confirmar
                                                        </button>
                                                    </div>
                                                )
                                            }

                                        </div>

                                    </td>

                                            </>
                                        )
                                    }

                                </tr>


                            ))
                        }


                    </tbody>


                </table>

                {
                    scanning && (
                        <div className="devices-scan-overlay">
                            <div className="devices-spinner"></div>
                            <p>Escaneando red, espere...</p>
                        </div>
                    )
                }

            </div>

            </div>
        </div>


    );


}


export default Devices;