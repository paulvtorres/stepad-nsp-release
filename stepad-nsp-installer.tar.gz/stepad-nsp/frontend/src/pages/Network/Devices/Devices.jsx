import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../../../auth/useAuth";

import { getDevices, scanDevices, getZones, updateDevice, linkDevice, unlinkDevice } from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";

import "./devices.css";


function Devices() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";


    const [devices, setDevices] = useState([]);

    const [zones, setZones] = useState([]);

    const [search, setSearch] = useState("");

    const [filter, setFilter] = useState("ALL");

    const [showInfra, setShowInfra] = useState(false);


    const navigate = useNavigate();

    const [scanning, setScanning] = useState(false);

    useEffect(() => {

        loadDevices();

        loadZones();

    }, []);


    async function loadZones() {

        try {

            const data = await getZones();

            setZones(data);

        } catch (error) {

            console.error(error);

        }

    }


    async function handleZoneChange(deviceId, zoneId) {

        try {

            await updateDevice(
                deviceId,
                { zone_id: zoneId ? Number(zoneId) : null }
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleDeviceBandwidth(device, value) {

        const mbps = String(value).trim();

        const kbps = mbps === "" ? null : (Number(mbps) * 1000);

        if (kbps !== null && (!Number.isFinite(kbps) || kbps <= 0)) {

            alert("Ingresa un valor válido en Mbps");

            loadDevices();

            return;

        }

        try {

            await updateDevice(
                device.id,
                { bandwidth_limit_kbps: kbps }
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

            alert("No se pudo guardar el ancho de banda.");

        }

    }


    async function handleLinkDevice(deviceId, primaryDeviceId) {

        if (!primaryDeviceId) {

            return;

        }

        try {

            await linkDevice(
                deviceId,
                Number(primaryDeviceId)
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleUnlinkDevice(deviceId) {

        try {

            await unlinkDevice(
                deviceId
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function loadDevices() {

        setScanning(true);

        try {

            const data = await getDevices(showInfra);

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }


    function handleToggleInfra() {

        setShowInfra((prev) => {

            const next = !prev;

            getDevices(next).then(setDevices).catch(console.error);

            return next;

        });

    }


    async function handleScan() {

        setScanning(true);

        try {

            const data = await scanDevices();

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }

const deviceTypes = {

    COMPUTER: "💻 Computadora",

    MOBILE: "📱 Celular",

    PRINTER: "🖨 Impresora",

    ROUTER: "📡 Router",

    HOST: "❓ Desconocido",

    UNKNOWN: "❓ Desconocido"

};


const statusLabels = {

    ONLINE: "En línea",

    OFFLINE: "Sin conexión",

    UNKNOWN: "Desconocido",

    BLOCKED: "Bloqueado"

};


    const filteredDevices = devices.filter((device) => {


        const text = (

            `${device.hostname || ""}
             ${device.ip_address || ""}
             ${device.mac_address || ""}`

        ).toLowerCase();



        const matchesSearch =
            text.includes(
                search.toLowerCase()
            );



        const matchesStatus =
            filter === "ALL"
            ||
            device.status === filter;



        return matchesSearch && matchesStatus;


    });





    const onlineDevices =
        devices.filter(
            d => d.status === "ONLINE"
        ).length;



    const offlineDevices =
        devices.length - onlineDevices;





    function formatDate(date) {


        if (!date) {

            return "-";

        }


        return new Date(date)
            .toLocaleString();


    }





    return (


        <div className="devices-container">


            <div className="devices-header">

                <div>

                    <h2>

                        Dispositivos de red

                    </h2>

                    <p>

                        Descubre, monitorea y administra todos los equipos conectados a tu red protegida.

                    </p>

                </div>

                <button

                    className={`scan-button ${scanning ? "scanning" : ""}`}

                    onClick={handleScan}

                    disabled={scanning}

                >

                    <span className="scan-icon">

                        {scanning ? "⟳" : "🔄"}

                    </span>

                    {scanning ? "Escaneando..." : "Escanear red"}

                </button>

            </div>

            <div className="device-summary">

                <div className="summary-item">

                    <span className="summary-label">
                        Total de dispositivos
                    </span>

                    <span className="summary-value">
                        {devices.length}
                    </span>

                </div>

                <div className="summary-divider"></div>

                <div className="summary-item">

                    <span className="summary-label">
                        En línea
                    </span>

                    <span className="summary-value online">
                        {onlineDevices}
                    </span>

                </div>

                <div className="summary-divider"></div>

                <div className="summary-item">

                    <span className="summary-label">
                        Sin conexión
                    </span>

                    <span className="summary-value offline">
                        {offlineDevices}
                    </span>

                </div>

            </div>

            <div className="device-toolbar">

                <input

                    type="text"

                    placeholder="Buscar por nombre, IP o MAC..."

                    value={search}

                    onChange={
                        e => setSearch(e.target.value)
                    }

                />

                <select

                    value={filter}

                    onChange={
                        e => setFilter(e.target.value)
                    }

                >

                    <option value="ALL">
                        Todos
                    </option>

                    <option value="ONLINE">
                        En línea
                    </option>

                    <option value="OFFLINE">
                        Sin conexión
                    </option>

                    <option value="UNKNOWN">
                        Desconocidos
                    </option>

                </select>

                <label className="checkbox-label" style={{ marginLeft: 8 }}>
                    <input
                        type="checkbox"
                        checked={showInfra}
                        onChange={handleToggleInfra}
                    />
                    Mostrar dispositivos de red (impresoras, teléfonos IP)
                </label>
            </div>




            <div className="table-card">

                <table className="devices-table">


                    <thead>

                        <tr>

                            <th>Estado</th>

                            <th>Nombre</th>
                            <th>Tipo</th>

                            <th>IP</th>

                            <th>MAC</th>

                             <th>Zona</th>

                             <th>Última vez</th>

                             <th>Acciones</th>


                        </tr>

                    </thead>




                    <tbody>


                        {
                            filteredDevices.map((device) => (


                                <tr key={device.id}>


                                    <td>

                                        <span

                                            className={

                                                `status-badge ${device.status.toLowerCase()}`

                                            }

                                        >

                                            <span className="status-dot"></span>

                                            {statusLabels[device.status] || device.status}

                                        </span>

                                    </td>




                                    <td>

                                        <div className="device-name-cell">

                                            <span className="device-name-value">
                                                {device.hostname || "Desconocido"}
                                            </span>

                                        </div>

                                    </td>


                                    <td>

                                        <span className={`device-type ${device.device_type?.toLowerCase()}`}>

                                            {

                                                deviceTypes[

                                                device.device_type?.toUpperCase()

                                                ]

                                                ||

                                                "❓ Desconocido"

                                            }

                                        </span>

                                    </td>

                                    <td>

                                        {device.ip_address}

                                    </td>




                                    <td>

                                        <div className="mac-cell">

                                            {device.mac_address || "-"}

                                            {
                                                (device.linked_devices || []).length > 0 && (
                                                    <span className="linked-badge">
                                                        +{device.linked_devices.length} NICs
                                                    </span>
                                                )
                                            }

                                        </div>

                                    </td>




                                    <td>

                                        {
                                            isAdmin ? (
                                                <select
                                                    value={device.zone_id || ""}
                                                    onChange={(e) =>
                                                        handleZoneChange(
                                                            device.id,
                                                            e.target.value
                                                        )
                                                    }
                                                >

                                                    <option value="">
                                                        Sin asignar
                                                    </option>

                                                    {
                                                        zones.map((zone) => (
                                                            <option
                                                                key={zone.id}
                                                                value={zone.id}
                                                            >
                                                                {zone.name}
                                                                {zone.is_default ? " (default)" : ""}
                                                            </option>
                                                        ))
                                                    }

                                                </select>
                                            ) : (
                                                <span className="zone-readonly">
                                                    {device.zone_id
                                                        ? (zones.find((z) => z.id === device.zone_id)?.name || device.zone_id)
                                                        : "Sin asignar"}
                                                </span>
                                            )
                                        }
                                    </td>




                                    <td>

                                        {formatDate(device.last_seen)}

                                    </td>

                                    <td>

                                        <div className="manage-menu">

                                            <button
                                                className="manage-button"
                                                onClick={() =>
                                                    navigate(
                                                        `/network/devices/${device.id}`
                                                    )
                                                }
                                            >

                                                Gestionar

                                            </button>

                                        </div>

                                    </td>

                                </tr>


                            ))
                        }


                    </tbody>


                </table>

            </div>
        </div>


    );


}


export default Devices;