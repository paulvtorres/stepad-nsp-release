import { useEffect, useState } from "react";

import { usePersistentState } from "../../../hooks/usePersistentState";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../../../auth/useAuth";

import { useNetworkSegment } from "../../../network/useNetworkSegment";

import { getDevices, scanDevices, getDevicesLiveStatus, updateDevice, linkDevice } from "../../../services/api";


import { formatDateTime } from "../../../utils/datetime";

import ActionButton from "../../../components/ui/ActionButton";

import "./devices.css";


function Devices() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const {
        selectedLan,
        selectedZones,
        selectedZoneIds,
        hostsDefaultZone,
        lanCards,
    } = useNetworkSegment();


    const [devices, setDevices] = useState([]);
    const [showArchived, setShowArchived] = useState(false);

    const zones = selectedZones;

    // La vista se conserva entre pantallas y recargas: al volver del
    // detalle de un equipo, o al cambiar de sección, sigue igual.
    const [search, setSearch] = usePersistentState("devices.search", "");

    const [filter, setFilter] = usePersistentState("devices.filter", "ALL");

    const [showExtra, setShowExtra] = useState(function () {
        try {
            return sessionStorage.getItem("devices.showExtra") === "1";
        } catch {
            return false;
        }
    });

    // Persistir el modo (simple / ver detalles) durante la SESIÓN activa:
    // si cambia de pantalla o de opción y regresa, mantiene lo elegido.
    useEffect(function () {
        try {
            sessionStorage.setItem("devices.showExtra", showExtra ? "1" : "0");
        } catch {
            /* ignorar */
        }
    }, [showExtra]);

    const [linkOpen, setLinkOpen] = useState(null);

    const [linkPrimary, setLinkPrimary] = useState("");
    const [reserveOpen, setReserveOpen] = useState(null);
    const [reserveIp, setReserveIp] = useState("");

    const [sortKey, setSortKey] = usePersistentState(
        "devices.sortKey",
        "status"
    );

    const [sortDir, setSortDir] = usePersistentState("devices.sortDir", "asc");


    const navigate = useNavigate();

    const [scanning, setScanning] = useState(false);

    const [liveStatus, setLiveStatus] = useState({});

    const [liveReady, setLiveReady] = useState(false);

    async function refreshLiveStatus() {

        try {

            const data = await getDevicesLiveStatus();

            setLiveStatus(data?.live || {});

            setLiveReady(true);

        } catch (error) {

            console.error(error);

        }

    }

    useEffect(() => {

        loadDevices();

        refreshLiveStatus();

        // Refresco automatico cada 30s: las luces se actualizan solas
        // (sin pulsar "Escanear red").
        const timer = setInterval(() => {

            getDevices(showArchived)

                .then(setDevices)

                .catch(() => {});

        }, 30000);

        // Ping ligero en segundo plano cada 15s: actualiza la luz
        // segun si cada equipo responde AHORA.
        const liveTimer = setInterval(() => {

            refreshLiveStatus();

        }, 15000);

        return () => {
            clearInterval(timer);
            clearInterval(liveTimer);
        };

    }, []);


    async function handleZoneChange(deviceId, zoneId) {

        try {

            await updateDevice(
                deviceId,
                { zone_id: zoneId ? Number(zoneId) : null }
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleLinkDevice(deviceId, primaryDeviceId) {

        if (!primaryDeviceId) {

            return;

        }

        try {

            await linkDevice(
                deviceId,
                Number(primaryDeviceId)
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleReserveIp(device) {
        const ip = reserveIp.trim();
        if (!ip) return;
        try {
            await updateDevice(device.id, {
                permanent_ip: ip,
                is_permanent: true,
            });
            setReserveOpen(null);
            setReserveIp('');
            await loadDevices();
        } catch (error) {
            console.error(error);
        }
    }

    async function handleClearReservation(device) {
        try {
            await updateDevice(device.id, {
                permanent_ip: null,
                is_permanent: false,
            });
            await loadDevices();
        } catch (error) {
            console.error(error);
        }
    }


    async function loadDevices() {

        setScanning(true);

        try {

            const data = await getDevices(showArchived);

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }


    async function handleScan() {

        setScanning(true);

        try {

            const data = await scanDevices();

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }

const deviceTypes = {

    COMPUTER: "💻 Computadora",

    MOBILE: "📱 Celular",

    PRINTER: "🖨 Impresora",

    ROUTER: "📡 Router",

    IP_PHONE: "☎️ Teléfono",

    CAMERA: "🎥 Cámara",

    ACCESO: "🛡️ Acceso/Asistencia",

    OTRO: "❓ Otro",

    HOST: "❓ Otro",

    UNKNOWN: "❓ Otro"

};


    const CONNECTION_TITLE = {
        pending: "Comprobando conexión…",
        probable: "Probablemente en línea",
        online: "En línea",
        offline: "Sin conexión"
    };

    const SOURCE_LABEL = {
        arp_reachable: "ARP",
        arp_stale: "ARP (antiguo)",
        dns: "DNS"
    };

    // "hace 3 min" a partir de la hora de la ULTIMA evidencia.
    function agoLabel(iso) {

        if (!iso) {

            return "";

        }

        const stamp = new Date(
            /[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : `${iso}Z`
        ).getTime();

        if (Number.isNaN(stamp)) {

            return "";

        }

        const seconds = Math.max(0, Math.round((Date.now() - stamp) / 1000));

        if (seconds < 60) return "hace segundos";

        if (seconds < 3600) return `hace ${Math.round(seconds / 60)} min`;

        if (seconds < 86400) return `hace ${Math.round(seconds / 3600)} h`;

        return `hace ${Math.round(seconds / 86400)} d`;

    }

    // Por que el listado dice lo que dice: fuente + antigüedad.
    function evidenceHint(device) {

        const source = SOURCE_LABEL[device.presence_source];

        const ago = agoLabel(device.presence_at);

        if (source && ago) {

            return `${source} · ${ago}`;

        }

        return ago ? `Última señal ${ago}` : "Sin señales registradas";

    }

    // La presencia la decide el servidor (ARP + DNS + verificacion
    // activa). El ping en vivo solo puede CONFIRMAR: que un equipo no
    // conteste ICMP (firewall) no lo da de baja si hay evidencia reciente.
    function connectionOf(device) {

        const presence = device.presence_status || device.status;

        if (presence === "ONLINE") {

            return "online";

        }

        const ip = device.current_ip || "";

        if (ip && liveStatus[ip] === true) {

            return "online";

        }

        if (presence === "PROBABLE") {

            return "probable";

        }

        if (!liveReady && presence === "UNKNOWN") {

            return "pending";

        }

        return "offline";

    }


    const filteredDevices = devices.filter((device) => {


        const text = (

            `${device.hostname || ""}
             ${device.current_ip || ""}
             ${device.ip_address || ""}
             ${device.mac_address || ""}`

        ).toLowerCase();



        const matchesSearch =
            text.includes(
                search.toLowerCase()
            );



        const connection = connectionOf(device);

        const matchesStatus =
            filter === "ALL"
            || (filter === "ONLINE" && (connection === "online" || connection === "probable"))
            || (filter === "OFFLINE" && connection === "offline")
            || (filter !== "ONLINE" && filter !== "OFFLINE"
                && (device.presence_status || device.status) === filter);

        // Misma pantalla; el selector de tarjeta/red filtra el alcance.
        let matchesSegment = true;

        if (lanCards.length > 1) {

            if (device.zone_id) {

                matchesSegment = selectedZoneIds.has(device.zone_id);

            } else {

                matchesSegment = hostsDefaultZone || selectedZones.length === 0;

            }

        }

        return matchesSearch && matchesStatus && matchesSegment;


    });


    const sortedDevices = [...filteredDevices].sort((a, b) => {

        let va, vb;

        if (sortKey === "status") {

            // asc = en línea, comprobando, sin conexión.
            const order = { online: 0, pending: 1, offline: 2 };

            va = order[connectionOf(a)] ?? 1;

            vb = order[connectionOf(b)] ?? 1;

        } else if (sortKey === "ip_address") {

            // Orden NUMÉRICO por el último octeto (1,2,3…9,10…) y no texto
            // (que pondría 100,101 antes que 2).
            const octet = (v) => {
                const n = parseInt(String(v ?? "").split(".").pop(), 10);
                return Number.isNaN(n) ? -1 : n;
            };
            va = octet(a.current_ip || a.ip_address);
            vb = octet(b.current_ip || b.ip_address);

        } else {

            va = (a[sortKey] ?? "").toString().toLowerCase();

            vb = (b[sortKey] ?? "").toString().toLowerCase();

        }

        if (va < vb) return sortDir === "asc" ? -1 : 1;

        if (va > vb) return sortDir === "asc" ? 1 : -1;

        return 0;

    });


    function handleSort(key) {

        if (sortKey === key) {

            setSortDir((d) => (d === "asc" ? "desc" : "asc"));

        } else {

            setSortKey(key);

            setSortDir("asc");

        }

    }





    const onlineDevices =
        devices.filter((d) => ["online", "probable"].includes(connectionOf(d))).length;

    const offlineDevices =
        devices.filter((d) => connectionOf(d) === "offline").length;

    const unknownDevices =
        devices.filter((d) => (d.presence_status || d.status) === "UNKNOWN").length;





    function formatDate(date) {

        return formatDateTime(date, "-");

    }





    return (


        <div className="devices-container">


            <div className="devices-header">

                <div className="devices-header-copy">

                    <span className="devices-eyebrow">INVENTARIO DE RED</span>

                    <h2>

                        Dispositivos

                        <span className={`devices-live-pill ${liveReady ? "ready" : ""}`}>
                            <i />
                            {liveReady ? "EN VIVO" : "CONECTANDO"}
                        </span>

                    </h2>

                    <p>

                        {
                            lanCards.length > 1
                                ? (
                                    <>
                                        Equipos del segmento seleccionado arriba
                                        {selectedLan
                                            ? ` (${selectedLan.display_name || selectedLan.current_name || selectedLan.last_seen_name || "LAN"})`
                                            : ""}
                                        . Cambia la tarjeta en la barra superior para ver otra red.
                                    </>
                                )
                                : "Descubre, monitorea y administra los equipos conectados a tu red protegida."
                        }

                    </p>

                </div>

                <div className="devices-header-actions">

                    <span
                        className={`devices-live-hint ${liveReady ? "" : "pending"}`}
                        title="Las luces se actualizan cada 15 s con ping."
                    >
                        <i />
                        {liveReady ? "Ping cada 15 s" : "Comprobando…"}
                    </span>

                    <ActionButton
                        variant="primary"
                        loading={scanning}
                        onClick={handleScan}
                        title="Escaneo profundo: actualiza nombres, tipo y sistema operativo detectados."
                    >
                        Escanear red
                    </ActionButton>

                    <a
                        className="devices-export-button"
                        href="/api/v1/devices/export"
                        title="Descarga un Excel con IP actual, IP reservada, MAC, tipo y estado."
                    >
                        Exportar Excel
                    </a>

                </div>

            </div>

            <div className="device-summary">

                <div className="summary-card total">

                    <span className="summary-label">
                        Total
                    </span>

                    <strong className="summary-value">
                        {devices.length}
                    </strong>

                    <span className="summary-hint">
                        equipos descubiertos
                    </span>

                </div>

                <div className="summary-card online">

                    <span className="summary-label">
                        En línea
                    </span>

                    <strong className="summary-value">
                        {liveReady ? onlineDevices : "—"}
                    </strong>

                    <span className="summary-hint">
                        responden ahora
                    </span>

                </div>

                <div className="summary-card offline">

                    <span className="summary-label">
                        Sin conexión
                    </span>

                    <strong className="summary-value">
                        {liveReady ? offlineDevices : "—"}
                    </strong>

                    <span className="summary-hint">
                        no responden
                    </span>

                </div>

                <div className="summary-card unknown">

                    <span className="summary-label">
                        Desconocidos
                    </span>

                    <strong className="summary-value">
                        {unknownDevices}
                    </strong>

                    <span className="summary-hint">
                        sin identificar
                    </span>

                </div>

            </div>

            <div className="device-toolbar">

                <div className="device-filters">

                    {
                        [
                            { id: "ALL", label: "Todos", count: devices.length },
                            { id: "ONLINE", label: "En línea", count: onlineDevices },
                            { id: "OFFLINE", label: "Sin conexión", count: offlineDevices },
                            { id: "UNKNOWN", label: "Desconocidos", count: unknownDevices },
                        ].map((chip) => (
                            <button
                                key={chip.id}
                                type="button"
                                className={`device-filter-chip ${filter === chip.id ? "active" : ""}`}
                                onClick={() => setFilter(chip.id)}
                            >
                                {chip.label}
                                <span className="device-filter-count">
                                    {chip.count}
                                </span>
                            </button>
                        ))
                    }

                </div>

                <div className="device-toolbar-right">

                    <label className="device-archived-toggle">
                        <input
                            type="checkbox"
                            checked={showArchived}
                            onChange={(e) => {
                                setShowArchived(e.target.checked);
                                setTimeout(loadDevices, 0);
                            }}
                        />
                        Mostrar archivados
                    </label>

                    <input

                        type="text"

                        placeholder="Buscar por nombre, IP o MAC..."

                        value={search}

                        onChange={
                            e => setSearch(e.target.value)
                        }

                    />

                    <button
                        className="secondary-button"
                        onClick={() => setShowExtra(!showExtra)}
                    >
                        {showExtra ? "Ocultar detalles" : "Ver detalles"}
                    </button>

                </div>

            </div>

            <div className="device-result-count">

                <span>
                    Mostrando <strong>{sortedDevices.length}</strong> de <strong>{devices.length}</strong> equipos
                    {search.trim() ? ` · búsqueda “${search.trim()}”` : ""}
                </span>

                <span className="device-result-live">
                    <i />
                    Actualización automática
                </span>

            </div>




            <div className="devices-table-wrap">

            <div className="devices-table-card">

                <table className="devices-table">


                    <thead>

                        <tr>

                            <th style={{ width: 70 }}>

                                <button
                                    className="th-sort"
                                    onClick={() => handleSort("status")}
                                    title="Ordenar por estado (online/offline)"
                                >
                                    On/Off {sortKey === "status" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>

                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("hostname")}>
                                    Nombre {sortKey === "hostname" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("device_type")}>
                                    Tipo {sortKey === "device_type" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("os_name")}>
                                    Sistema {sortKey === "os_name" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("ip_address")}>
                                    IP {sortKey === "ip_address" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>IP Reservada</th>

                            {
                                showExtra && (
                                    <>
                                        <th>MAC</th>

                                        <th>Zona</th>

                                        <th>Última vez</th>

                                        <th>Acciones</th>
                                    </>
                                )
                            }


                        </tr>

                    </thead>




                    <tbody>


                        {
                            sortedDevices.map((device) => (


                                <tr key={device.id}>


                                    <td>

                                        <span
                                            className={`device-live-dot ${connectionOf(device)}`}
                                            title={`${CONNECTION_TITLE[connectionOf(device)]} — ${evidenceHint(device)}`}
                                        />
                                    </td>



                                    <td>

                                        <div className="device-name-cell">

                                            <span className="device-name-value">
                                                {device.hostname || "Desconocido"}
                                            </span>

                                        </div>

                                    </td>


                                    <td>

                                        <span className={`device-type ${device.device_type?.toLowerCase()}`}>

                                            {

                                                deviceTypes[

                                                device.device_type?.toUpperCase()

                                                ]

                                                ||

                                                "❓ Desconocido"

                                            }

                                        </span>

                                    </td>

                                    <td>

                                        <span className="device-os">
                                            {device.os_name || "Desconocido"}
                                        </span>

                                    </td>

                                    <td>

                                        {device.archived_at && (
                                            <span title={device.archive_reason || "Equipo archivado"} style={{ marginRight: 6, fontSize: 11, color: "var(--muted)" }}>
                                                archivado
                                            </span>
                                        )}
                                        {device.current_ip || (
                                            <span
                                                title="Sin IP actual: última IP conocida"
                                                style={{ opacity: 0.55 }}
                                            >
                                                {device.last_ip || device.ip_address || "—"}
                                            </span>
                                        )}
                                        {device.ip_conflict && (
                                            <span
                                                title="La IP asignada por DHCP a un equipo la está usando otro"
                                                style={{
                                                    marginLeft: 6,
                                                    padding: "1px 6px",
                                                    borderRadius: 999,
                                                    border: "1px solid #f59e0b",
                                                    color: "#fbbf24",
                                                    fontSize: "0.68rem",
                                                    fontWeight: 600,
                                                }}
                                            >
                                                conflicto
                                            </span>
                                        )}

                                        {(device.ip_kind === "static"
                                            || device.ip_kind === "static_out") && (
                                            <span
                                                title={
                                                    device.ip_kind === "static"
                                                        ? "IP fija DENTRO del pool del DHCP: puede entregarse a otro equipo (riesgo de conflicto)"
                                                        : "IP fija fuera del pool del DHCP (configuración normal)"
                                                }
                                                style={{
                                                    marginLeft: 6,
                                                    padding: "1px 6px",
                                                    borderRadius: 999,
                                                    border: `1px solid ${device.ip_kind === "static" ? "#f59e0b" : "#475569"}`,
                                                    color: device.ip_kind === "static" ? "#fbbf24" : "#94a3b8",
                                                    fontSize: "0.68rem",
                                                    fontWeight: 600,
                                                    textTransform: "uppercase",
                                                    letterSpacing: "0.03em",
                                                    whiteSpace: "nowrap",
                                                }}
                                            >
                                                fija
                                            </span>
                                        )}

                                    </td>

                                    <td>
                                        {device.permanent_ip ? (
                                            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                                                <span style={{ color: "#86efac", fontWeight: 600, fontSize: "0.82rem" }}>
                                                    {device.permanent_ip}
                                                </span>
                                                {isAdmin && (
                                                    <button
                                                        className="manage-button"
                                                        style={{ fontSize: "0.72rem", padding: "1px 5px" }}
                                                        title="Quitar reserva"
                                                        onClick={() => handleClearReservation(device)}
                                                    >
                                                        x
                                                    </button>
                                                )}
                                            </div>
                                        ) : reserveOpen === device.id ? (
                                            <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
                                                <input
                                                    type="text"
                                                    value={reserveIp}
                                                    onChange={(e) => setReserveIp(e.target.value)}
                                                    placeholder="192.168.1.X"
                                                    style={{ width: 120, fontSize: "0.78rem", padding: "2px 5px" }}
                                                    onKeyDown={(e) => {
                                                        if (e.key === "Enter") handleReserveIp(device);
                                                        if (e.key === "Escape") { setReserveOpen(null); setReserveIp(""); }
                                                    }}
                                                    autoFocus
                                                />
                                                <button
                                                    className="manage-button small"
                                                    onClick={() => handleReserveIp(device)}
                                                    disabled={!reserveIp.trim()}
                                                >
                                                    OK
                                                </button>
                                                <button
                                                    className="manage-button small"
                                                    onClick={() => { setReserveOpen(null); setReserveIp(""); }}
                                                >
                                                    x
                                                </button>
                                            </div>
                                        ) : isAdmin ? (
                                            <button
                                                className="manage-button"
                                                style={{ fontSize: "0.75rem" }}
                                                onClick={() => { setReserveOpen(device.id); setReserveIp(device.current_ip || device.ip_address || ""); }}
                                            >
                                                Reservar IP
                                            </button>
                                        ) : (
                                            <span style={{ color: "var(--muted)", fontSize: "0.78rem" }}>-</span>
                                        )}
                                    </td>


                                    {
                                        showExtra && (
                                            <>

                                    <td>

                                        <div className="mac-cell">

                                            {device.mac_address || "-"}

                                            {
                                                (device.linked_devices || []).length > 0 && (
                                                    <span className="linked-badge">
                                                        +{device.linked_devices.length} NICs
                                                    </span>
                                                )
                                            }

                                        </div>

                                    </td>

                                    <td>

                                        {
                                            isAdmin ? (
                                                <select
                                                    value={device.zone_id || ""}
                                                    onChange={(e) =>
                                                        handleZoneChange(
                                                            device.id,
                                                            e.target.value
                                                        )
                                                    }
                                                >

                                                    <option value="">
                                                        Sin asignar
                                                    </option>

                                                    {
                                                        zones.map((zone) => (
                                                            <option
                                                                key={zone.id}
                                                                value={zone.id}
                                                            >
                                                                {zone.name}
                                                                {zone.is_default ? " (default)" : ""}
                                                            </option>
                                                        ))
                                                    }

                                                </select>
                                            ) : (
                                                <span className="zone-readonly">
                                                    {device.zone_id
                                                        ? (zones.find((z) => z.id === device.zone_id)?.name || device.zone_id)
                                                        : "Sin asignar"}
                                                </span>
                                            )
                                        }
                                    </td>




                                    <td>

                                        {formatDate(device.last_seen)}

                                    </td>

                                    <td>

                                        <div className="manage-menu">

                                            <button
                                                className="manage-button"
                                                onClick={() =>
                                                    navigate(
                                                        `/network/devices/${device.id}`
                                                    )
                                                }
                                            >

                                                Gestionar

                                            </button>

                                            <button
                                                className="manage-button"
                                                onClick={() => {
                                                    setLinkOpen(linkOpen === device.id ? null : device.id);
                                                    setLinkPrimary("");
                                                }}
                                            >
                                                Vincular
                                            </button>

                                            {
                                                linkOpen === device.id && (
                                                    <div style={{ marginTop: 6, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                                                        <select
                                                            value={linkPrimary}
                                                            onChange={(e) => setLinkPrimary(e.target.value)}
                                                        >
                                                            <option value="">-- Equipo principal --</option>
                                                            {
                                                                devices
                                                                    .filter((d) => d.id !== device.id)
                                                                    .map((d) => (
                                                                        <option key={d.id} value={d.id}>
                                                                            {d.hostname || d.ip_address || d.mac_address || `#${d.id}`}
                                                                        </option>
                                                                    ))
                                                            }
                                                        </select>
                                                        <button
                                                            className="secondary-button small"
                                                            disabled={!linkPrimary}
                                                            onClick={() => {
                                                                handleLinkDevice(device.id, Number(linkPrimary));
                                                                setLinkOpen(null);
                                                            }}
                                                        >
                                                            Confirmar
                                                        </button>
                                                    </div>
                                                )
                                            }

                                        </div>

                                    </td>

                                            </>
                                        )
                                    }

                                </tr>


                            ))
                        }


                    </tbody>


                </table>

                {
                    scanning && (
                        <div className="devices-scan-overlay">
                            <div className="devices-spinner"></div>
                            <p>Escaneando red, espere...</p>
                        </div>
                    )
                }

            </div>

            </div>
        </div>


    );


}


export default Devices;