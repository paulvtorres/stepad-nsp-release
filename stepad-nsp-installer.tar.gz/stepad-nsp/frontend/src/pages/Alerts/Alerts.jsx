import { Fragment, useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getAlerts,
    markAlertRead,
    markAllAlertsRead,
    quarantineAlert,
    downloadIntrusionDiagnosticScript,
    getAlertIgnoreRules,
    addAlertIgnoreRule,
    deleteAlertIgnoreRule
} from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./alerts.css";


const SEVERITY_LABELS = {
    critical: "Crítica",
    warning: "Advertencia",
    info: "Información",
};


const TYPE_LABELS = {
    suricata: "IPS (Suricata)",
    NAVIGATION_HEALTH: "Salud de red",
    DHCP_HEALTH: "Salud de DHCP",
    DHCP_POOL_LOW: "DHCP: pool de IPs",
    DHCP_IP_CONFLICT: "DHCP: IP duplicada",
    DHCP_STATIC_IN_POOL: "DHCP: IP fija en el pool",
    DHCP_EVENTS_SILENT: "DHCP: sin eventos de lease",
    DHCP_RESERVATION_INVALID: "DHCP: reservas omitidas",
    IPS_POLICY_ALERT: "Detección IPS (política)",
    QUARANTINE_LIMIT_REACHED: "Cuarentena pausada por límite",
    DHCP_POOL_RECOVERED: "DHCP: pool normalizado",
    DHCP_POOL_EXHAUSTED: "DHCP: sin IPs libres",
    DHCP_POOL_RECLAIMED: "DHCP: IPs recicladas",
    DHCP_NO_ADDRESS: "DHCP: no hay IP para asignar",
    DHCP_POOL_TREND: "DHCP: tendencia de agotamiento",
    DHCP_RESERVED_IP_OCCUPIED: "DHCP: reserva ocupada",
    DHCP_IP_DUPLICATE_ACTIVE: "DHCP: IP duplicada activa",
    BOOT_HEALTH_NFTABLES: "Diagnóstico: firewall",
    BOOT_HEALTH_PROCESS: "Diagnóstico: servicios",
    BOOT_HEALTH_WATCHDOG: "Diagnóstico: watchdog externo",
    BOOT_HEALTH_PORTS: "Diagnóstico: puertos",
    BOOT_HEALTH_SCHEMA: "Diagnóstico: base de datos",
    RESOURCE_CPU: "Recursos: CPU",
    RESOURCE_RAM: "Recursos: memoria",
    RESOURCE_DISK: "Recursos: disco",
    NEW_DEVICE: "Nuevo dispositivo",
    USER_LOGIN_FAILED: "Inicio de sesión fallido",
    ACCOUNT_LOCKED: "Cuenta bloqueada",
    HARDENING_DEGRADED: "Firewall degradado",
    SECURITY_DNS_THREAT: "DNS de riesgo",
    DNS_TUNNELING: "Posible túnel DNS",
    DNS_DGA_ACTIVITY: "Posible actividad DGA",
    DNS_BEACONING: "Posible beaconing DNS",
    DNS_ENCRYPTED_BYPASS: "Posible evasión DNS cifrada",
    CONFIG_DRIFT: "Configuración dorada desviada",
    quarantine: "Equipo aislado",
    c2_block: "Bloqueo de servidor de mando (C2)",
    attack_block: "Ataque bloqueado",
    attack_unblock: "Ataque desbloqueado",
    SHARE_DISK_HEALTH: "Salud de disco",
    SHARE_MASS_CHANGE: "Cambio masivo de archivos",
    system: "Sistema",
};


function severityLabel(severity) {
    return SEVERITY_LABELS[severity] || severity;
}


function typeLabel(type) {
    return TYPE_LABELS[type] || type || "otro";
}


function Alerts() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [alerts, setAlerts] = useState([]);

    const [unread, setUnread] = useState(0);

    const [loading, setLoading] = useState(false);

    const [severityFilter, setSeverityFilter] = useState("all");
    const [showResolved, setShowResolved] = useState(false);

    const [typeFilter, setTypeFilter] = useState("all");

    const [ignoredRules, setIgnoredRules] = useState([]);

    const [ignoredCount, setIgnoredCount] = useState(0);

    const [ignoreDialog, setIgnoreDialog] = useState(null);

    const [ignoreText, setIgnoreText] = useState("");

    const [ignoreMode, setIgnoreMode] = useState("exact");

    const [ignoreDuration, setIgnoreDuration] = useState("24h");

    const [ignoreReason, setIgnoreReason] = useState("");

    const [showIgnored, setShowIgnored] = useState(false);

    const [ignoring, setIgnoring] = useState(false);


    useEffect(() => {

        load();

        const timer = setInterval(load, 15000);

        return () => clearInterval(timer);

    }, []);


    async function load() {

        setLoading(true);

        try {

            const data = await getAlerts(200, false);

            setAlerts(data.alerts || []);

            setUnread(data.unread || 0);

            setIgnoredCount(data.ignored || 0);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    async function handleMarkRead(id) {

        await markAlertRead(id);

        setAlerts((prev) =>
            prev.map((a) => (a.id === id ? { ...a, read: true } : a))
        );

        setUnread((u) => Math.max(0, u - 1));

    }


    async function handleMarkAllRead() {

        await markAllAlertsRead();

        setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));

        setUnread(0);

    }


    useEffect(() => {

        loadIgnoreRules();

    }, []);


    async function loadIgnoreRules() {

        try {

            const data = await getAlertIgnoreRules();

            const rules = data.rules || [];

            setIgnoredRules(rules);

            setIgnoredCount(data.count || rules.length || 0);

        } catch (error) {

            console.error(error);

        }

    }


    function openIgnoreDialog(alert) {

        const signature = String(alert.title || alert.message || "");

        setIgnoreDialog(alert);

        setIgnoreText(signature.startsWith("IPS: ") ? signature.slice(5) : signature);

        setIgnoreMode("exact");
        setIgnoreDuration("24h");
        setIgnoreReason("");

    }


    async function handleConfirmIgnore() {

        if (!ignoreDialog || !ignoreText.trim()) return;

        setIgnoring(true);

        try {

            const hours = {
                "1h": 1,
                "24h": 24,
                "7d": 168,
            }[ignoreDuration];

            const result = await addAlertIgnoreRule({

                match_field: "title",

                matcher: ignoreMode,

                value: ignoreMode === "exact"
                    ? String(ignoreDialog.title || "")
                    : ignoreText.trim(),

                expires_at: hours
                    ? new Date(Date.now() + hours * 3600 * 1000).toISOString()
                    : null,

                reason: ignoreReason.trim(),

                remove_existing: !hours,

            });

            setIgnoreDialog(null);

            setIgnoreText("");

            await load();

            await loadIgnoreRules();

            window.alert(
                (hours
                    ? "Mensaje silenciado temporalmente. Seguirá sin generar ruido hasta la expiración."
                    : "Tipo de mensaje silenciado permanentemente.") +
                (result.removed
                    ? ` Se eliminaron ${result.removed} alertas guardadas de este tipo.`
                    : " Las alertas existentes se conservan.")
            );

        } catch (error) {

            window.alert("No se pudo silenciar: " + (error.message || "error"));

        } finally {

            setIgnoring(false);

        }

    }


    async function handleUnignore(rule) {

        if (!window.confirm(`¿Dejar de ignorar el tipo "${rule.value}"?`)) return;

        try {

            await deleteAlertIgnoreRule(rule.id);

            await loadIgnoreRules();

            await load();

        } catch (error) {

            window.alert("No se pudo quitar: " + (error.message || "error"));

        }

    }


    async function handleDownloadIntrusionScript() {

        try {

            const blob = await downloadIntrusionDiagnosticScript();

            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");

            link.href = url;

            link.download = "diagnostico_intrusos.ps1";

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        } catch (error) {

            window.alert(
                "No se pudo descargar el script: " + (error.message || "error")
            );

        }

    }


    async function handleQuarantine(alert) {

        const ok = window.confirm(
            "¿Aislar el equipo que originó esta alerta?\n\n" +
            alert.title + "\n\n" +
            "Se bloqueará su acceso a la red hasta que lo desbloquees."
        );

        if (!ok) return;

        try {

            const result = await quarantineAlert(alert.id);

            window.alert(
                "Equipo aislado: " + (result.device || "") +
                " (" + (result.ip || "") + ")"
            );

            load();

        } catch (error) {

            window.alert(
                "No se pudo aislar: " + (error.message || "error")
            );

        }

    }


    const SEVERITY_RANK = { critical: 0, warning: 1, info: 2 };


    const filtered = alerts
        .filter((alert) => {

            if (!showResolved && alert.resolved_at) {

                return false;

            }

            if (severityFilter !== "all" && alert.severity !== severityFilter) {

                return false;

            }

            if (typeFilter !== "all" && alert.type !== typeFilter) {

                return false;

            }

            return true;

        })
        // Prioridad primero: no leídas antes que leídas, y dentro de
        // cada grupo, críticas antes que advertencias/info. Así una
        // amenaza (mineria/malware) aparece siempre arriba sin importar
        // cuando llegaron otras alertas menores.
        .sort((a, b) => {

            if (a.read !== b.read) return a.read ? 1 : -1;

            const rankDiff = (SEVERITY_RANK[a.severity] ?? 3) -
                (SEVERITY_RANK[b.severity] ?? 3);

            if (rankDiff !== 0) return rankDiff;

            return b.id - a.id;

        });


    const types = [...new Set(alerts.map((a) => a.type || "otro"))];


    function consultSignature(alert) {

        const signature = (alert.message || alert.title || "")
            .split("|")[0]
            .trim();

        window.open(
            "https://www.google.com/search?q=" +
            encodeURIComponent(signature),
            "_blank"
        );

    }


    return (

        <div className="alerts-page">

            <div className="alerts-page-header">

                <div>

                    <h2>Alertas</h2>

                    <p>
                        Alertas de seguridad del IPS y del sistema. En las del IPS puedes
                        <strong> aislar el equipo</strong> que las originó de inmediato.
                    </p>

                </div>

                <div className="alerts-page-controls">

                    <label className="alerts-page-toggle">
                        <input
                            type="checkbox"
                            checked={showResolved}
                            onChange={(e) => setShowResolved(e.target.checked)}
                        />
                        Mostrar resueltas
                    </label>

                    <label>
                        Severidad
                        <select
                            value={severityFilter}
                            onChange={(e) => setSeverityFilter(e.target.value)}
                        >
                            <option value="all">Todas</option>
                            <option value="critical">Crítica</option>
                            <option value="warning">Advertencia</option>
                            <option value="info">Info</option>
                        </select>
                    </label>

                    <label>
                        Tipo
                        <select
                            value={typeFilter}
                            onChange={(e) => setTypeFilter(e.target.value)}
                        >
                            <option value="all">Todos</option>
                            {
                                types.map((t) => (
                                    <option key={t} value={t}>{typeLabel(t)}</option>
                                ))
                            }
                        </select>
                    </label>

                    {
                        unread > 0 && (
                            <button
                                className="alerts-mark-read"
                                onClick={handleMarkAllRead}
                            >
                                Marcar todas leídas ({unread})
                            </button>
                        )
                    }

                    {
                        ignoredCount > 0 && (
                            <button
                                className="alerts-mark-read"
                                onClick={() => setShowIgnored(true)}
                                title="Ver los tipos de mensaje silenciados"
                            >
                                Silenciados ({ignoredCount})
                            </button>
                        )
                    }

                </div>

            </div>


            <details className="alerts-page-help">

                <summary className="alerts-page-help-title">
                    ¿Qué significa una alerta y cómo actuar?
                </summary>

                <p>
                    Cada alerta es una firma de seguridad (de Suricata/IPS) detectada en un
                    equipo. Para entender <strong>el detalle específico</strong> de una alerta,
                    pulsa <strong>"Consultar firma"</strong> en ella: busca el mensaje exacto
                    en internet y verás qué indica y cómo se conoce.
                </p>

                <ol>
                    <li>Revisa el <strong>equipo origen</strong> indicado en la alerta.</li>
                    <li>Pulsa <strong>"Consultar firma"</strong> para leer qué significa ese mensaje concreto.</li>
                    <li>Si es crítica o se repite, <strong>"Aislar equipo"</strong> para cortar al equipo de la red.</li>
                    <li>Escanea el equipo con antivirus y decide si desbloquearlo.</li>
                </ol>

            </details>

            {
                isAdmin && (
                    <div className="alerts-page-tools">

                        <div>
                            <div className="alerts-page-tools-title">
                                ¿Sospechas que un equipo Windows fue intervenido?
                            </div>
                            <p>
                                Descarga este script y ejecútalo en el equipo sospechoso.
                                Revisa acceso remoto no autorizado (AnyDesk, TeamViewer, RDP),
                                cuentas de administrador nuevas e inicios de sesión remotos.
                                Es solo de diagnóstico: no borra ni detiene nada.
                            </p>
                        </div>

                        <button
                            className="alerts-page-tools-download"
                            onClick={handleDownloadIntrusionScript}
                        >
                            Descargar script de diagnóstico de intrusos
                        </button>

                    </div>
                )
            }


            {
                !loading && filtered.length === 0 ? (
                    <p className="alerts-empty">Sin alertas.</p>
                ) : (
                    <ul className="alerts-page-list">

                        {
                            filtered.map((alert, index) => {

                                const previous = filtered[index - 1];

                                const startsOld = previous && !previous.read && alert.read;

                                return (

                                <Fragment key={alert.id}>

                                {startsOld && (
                                    <li className="alerts-page-divider">
                                        Anteriores
                                    </li>
                                )}

                                <li
                                    key={alert.id}
                                    className={`alerts-page-item severity-${alert.severity} ${alert.read ? "read" : ""} ${alert.resolved_at ? "resolved" : ""}`}
                                >

                                    <div className="alerts-page-sev">
                                        {severityLabel(alert.severity)}
                                    </div>

                                    <div className="alerts-page-body">

                                        <div className="alerts-page-title">
                                            {alert.title}
                                            {alert.occurrences > 1 && (
                                                <span
                                                    className="alerts-page-occurrences"
                                                    title={`${alert.occurrences} ocurrencias agrupadas`}
                                                >
                                                    ×{alert.occurrences}
                                                </span>
                                            )}
                                        </div>

                                        {
                                            alert.device_name && (
                                                <div className="alerts-page-device">
                                                    Equipo: <strong>{alert.device_name}</strong>
                                                    {alert.device_ip ? ` (${alert.device_ip})` : ""}
                                                </div>
                                            )
                                        }

                                        {
                                            alert.message && alert.message !== alert.title && (
                                                <div className="alerts-page-message">
                                                    {alert.message}
                                                </div>
                                            )
                                        }

                                        {
                                            alert.guidance && (
                                                <details className="alerts-page-guidance">
                                                    <summary>
                                                        {alert.guidance.tipo} — qué hacer
                                                    </summary>
                                                    <p>{alert.guidance.explicacion}</p>
                                                    <ul>
                                                        {
                                                            (alert.guidance.acciones || []).map((accion, idx) => (
                                                                <li key={idx}>{accion}</li>
                                                            ))
                                                        }
                                                    </ul>
                                                </details>
                                            )
                                        }

                                        <div className="alerts-page-meta">
                                            {alert.created_at_ec || formatDateTime(alert.created_at)}
                                            {" · "}
                                            hora Ecuador
                                            {" · "}
                                            tipo: {typeLabel(alert.type)}
                                            {alert.resolved_at && (
                                                <>
                                                    {" · "}
                                                    <strong>Resuelta</strong>
                                                </>
                                            )}
                                        </div>

                                    </div>

                                    <div className="alerts-page-actions">

                                        {
                                            isAdmin && (
                                                <button
                                                    className="alerts-page-ignore"
                                                    onClick={() => openIgnoreDialog(alert)}
                                                    title="No crear más mensajes de este tipo"
                                                >
                                                    Silenciar tipo
                                                </button>
                                            )
                                        }

                                        {
                                            alert.type === "suricata" && (
                                                <button
                                                    className="alerts-page-consult"
                                                    onClick={() => consultSignature(alert)}
                                                    title="Buscar el detalle específico de esta firma"
                                                >
                                                    Consultar firma
                                                </button>
                                            )
                                        }

                                        {
                                            alert.type === "suricata" && isAdmin &&
                                            (alert.severity === "critical" || alert.severity === "warning") && (
                                                <button
                                                    className="alerts-page-quarantine"
                                                    onClick={() => handleQuarantine(alert)}
                                                    title="Aislar el equipo que originó esta alerta"
                                                >
                                                    Aislar equipo
                                                </button>
                                            )
                                        }

                                        {
                                            !alert.read && (
                                                <button
                                                    className="alerts-page-read"
                                                    onClick={() => handleMarkRead(alert.id)}
                                                >
                                                    Marcar leída
                                                </button>
                                            )
                                        }

                                    </div>

                                </li>

                                </Fragment>

                                );

                            })
                        }

                    </ul>
                )
            }

            {
                ignoreDialog && (
                    <div className="alerts-overlay">
                        <div className="alerts-dialog">
                            <h3>Silenciar este tipo de mensaje</h3>
                            <p className="alerts-dialog-sub">
                                {ignoreDialog.title}
                            </p>
                            <p>
                                Podés silenciar temporalmente o de forma permanente.
                                El silenciamiento temporal no borra alertas existentes.
                            </p>

                            {
                                ignoreDialog.severity === "critical" && (
                                    <p className="alerts-dialog-warn">
                                        Alerta de severidad crítica: silenciar este tipo
                                        ocultará posibles amenazas reales. Verificá que no sea un
                                        falso positivo antes de continuar.
                                    </p>
                                )
                            }

                            <label className="alerts-radio-row">
                                <input
                                    type="radio"
                                    name="ignore-mode"
                                    checked={ignoreMode === "exact"}
                                    onChange={() => setIgnoreMode("exact")}
                                />
                                <span>Solo este mensaje exacto</span>
                            </label>

                            <label className="alerts-radio-row">
                                <input
                                    type="radio"
                                    name="ignore-mode"
                                    checked={ignoreMode === "contains"}
                                    onChange={() => setIgnoreMode("contains")}
                                />
                                <span>Los mensajes que contengan el texto:</span>
                            </label>

                            <input
                                className="alerts-dialog-input"
                                type="text"
                                value={ignoreText}
                                onChange={(e) => setIgnoreText(e.target.value)}
                                placeholder="firma o fragmento"
                            />

                            <label className="alerts-radio-row">
                                <span>Duración</span>
                                <select
                                    className="alerts-dialog-input"
                                    value={ignoreDuration}
                                    onChange={(e) => setIgnoreDuration(e.target.value)}
                                >
                                    <option value="1h">1 hora</option>
                                    <option value="24h">24 horas</option>
                                    <option value="7d">7 días</option>
                                    <option value="permanent">Permanente</option>
                                </select>
                            </label>

                            <input
                                className="alerts-dialog-input"
                                type="text"
                                value={ignoreReason}
                                onChange={(e) => setIgnoreReason(e.target.value)}
                                placeholder="Motivo (ej. mantenimiento)"
                            />

                            <div className="alerts-dialog-actions">
                                <button
                                    className="alerts-btn-cancel"
                                    onClick={() => setIgnoreDialog(null)}
                                >
                                    Cancelar
                                </button>
                                <button
                                    className="alerts-btn-go"
                                    onClick={handleConfirmIgnore}
                                    disabled={ignoring || !ignoreText.trim()}
                                >
                                    {ignoring ? "Silenciando..." : "Silenciar"}
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {
                showIgnored && (
                    <div className="alerts-overlay">
                        <div className="alerts-dialog">
                            <h3>Tipos de mensaje silenciados</h3>

                            {
                                ignoredRules.length === 0 ? (
                                    <p className="alerts-empty">No hay tipos silenciados.</p>
                                ) : (
                                    <ul className="alerts-ignored-list">
                                        {
                                            ignoredRules.map((rule) => (
                                                <li key={rule.id}>
                                                    <div>
                                                        <strong>{rule.value}</strong>
                                                        <span>
                                                            {rule.matcher === "contains" ? "contiene" : "exacto"} · campo {rule.match_field}
                                                            {rule.expires_at
                                                                ? ` · hasta ${new Date(rule.expires_at).toLocaleString()}`
                                                                : " · permanente"}
                                                            {rule.reason ? ` · ${rule.reason}` : ""}
                                                        </span>
                                                    </div>
                                                    <button
                                                        className="alerts-btn-unignore"
                                                        onClick={() => handleUnignore(rule)}
                                                    >
                                                        Dejar de ignorar
                                                    </button>
                                                </li>
                                            ))
                                        }
                                    </ul>
                                )
                            }

                            <div className="alerts-dialog-actions">
                                <button
                                    className="alerts-btn-cancel"
                                    onClick={() => setShowIgnored(false)}
                                >
                                    Cerrar
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

        </div>

    );

}


export default Alerts;
