import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getAlerts,
    markAlertRead,
    markAllAlertsRead,
    quarantineAlert
} from "../../services/api";

import "./alerts.css";


function Alerts() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [alerts, setAlerts] = useState([]);

    const [unread, setUnread] = useState(0);

    const [loading, setLoading] = useState(false);

    const [severityFilter, setSeverityFilter] = useState("all");

    const [typeFilter, setTypeFilter] = useState("all");


    useEffect(() => {

        load();

        const timer = setInterval(load, 15000);

        return () => clearInterval(timer);

    }, []);


    async function load() {

        setLoading(true);

        try {

            const data = await getAlerts(200, false);

            setAlerts(data.alerts || []);

            setUnread(data.unread || 0);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    async function handleMarkRead(id) {

        await markAlertRead(id);

        setAlerts((prev) =>
            prev.map((a) => (a.id === id ? { ...a, read: true } : a))
        );

        setUnread((u) => Math.max(0, u - 1));

    }


    async function handleMarkAllRead() {

        await markAllAlertsRead();

        setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));

        setUnread(0);

    }


    async function handleQuarantine(alert) {

        const ok = window.confirm(
            "¿Aislar el equipo que originó esta alerta?\n\n" +
            alert.title + "\n\n" +
            "Se bloqueará su acceso a la red hasta que lo desbloquees."
        );

        if (!ok) return;

        try {

            const result = await quarantineAlert(alert.id);

            window.alert(
                "Equipo aislado: " + (result.device || "") +
                " (" + (result.ip || "") + ")"
            );

            load();

        } catch (error) {

            window.alert(
                "No se pudo aislar: " + (error.message || "error")
            );

        }

    }


    const filtered = alerts.filter((alert) => {

        if (severityFilter !== "all" && alert.severity !== severityFilter) {

            return false;

        }

        if (typeFilter !== "all" && alert.type !== typeFilter) {

            return false;

        }

        return true;

    });


    const types = [...new Set(alerts.map((a) => a.type || "otro"))];


    return (

        <div className="alerts-page">

            <div className="alerts-page-header">

                <div>

                    <h2>Alertas</h2>

                    <p>
                        Alertas de seguridad del IPS y del sistema. En las del IPS puedes
                        <strong> aislar el equipo</strong> que las originó de inmediato.
                    </p>

                </div>

                <div className="alerts-page-controls">

                    <label>
                        Severidad
                        <select
                            value={severityFilter}
                            onChange={(e) => setSeverityFilter(e.target.value)}
                        >
                            <option value="all">Todas</option>
                            <option value="critical">Crítica</option>
                            <option value="warning">Advertencia</option>
                            <option value="info">Info</option>
                        </select>
                    </label>

                    <label>
                        Tipo
                        <select
                            value={typeFilter}
                            onChange={(e) => setTypeFilter(e.target.value)}
                        >
                            <option value="all">Todos</option>
                            {
                                types.map((t) => (
                                    <option key={t} value={t}>{t}</option>
                                ))
                            }
                        </select>
                    </label>

                    {
                        unread > 0 && (
                            <button
                                className="alerts-mark-read"
                                onClick={handleMarkAllRead}
                            >
                                Marcar todas leídas ({unread})
                            </button>
                        )
                    }

                </div>

            </div>


            {
                !loading && filtered.length === 0 ? (
                    <p className="alerts-empty">Sin alertas.</p>
                ) : (
                    <ul className="alerts-page-list">

                        {
                            filtered.map((alert) => (

                                <li
                                    key={alert.id}
                                    className={`alerts-page-item severity-${alert.severity} ${alert.read ? "read" : ""}`}
                                >

                                    <div className="alerts-page-sev">
                                        {alert.severity}
                                    </div>

                                    <div className="alerts-page-body">

                                        <div className="alerts-page-title">
                                            {alert.title}
                                        </div>

                                        {
                                            alert.device_name && (
                                                <div className="alerts-page-device">
                                                    Equipo: <strong>{alert.device_name}</strong>
                                                    {alert.device_ip ? ` (${alert.device_ip})` : ""}
                                                </div>
                                            )
                                        }

                                        {
                                            alert.message && alert.message !== alert.title && (
                                                <div className="alerts-page-message">
                                                    {alert.message}
                                                </div>
                                            )
                                        }

                                        <div className="alerts-page-meta">
                                            {new Date(alert.created_at).toLocaleString("es-ES")}
                                            {" · "}
                                            tipo: {alert.type || "otro"}
                                        </div>

                                        {
                                            alert.guidance && (
                                                <div className="alerts-page-guidance">
                                                    <div className="alerts-page-guidance-title">
                                                        {alert.guidance.tipo} — ¿qué hago?
                                                    </div>
                                                    <p>{alert.guidance.explicacion}</p>
                                                    <ol>
                                                        {
                                                            alert.guidance.acciones.map((action, i) => (
                                                                <li key={i}>{action}</li>
                                                            ))
                                                        }
                                                    </ol>
                                                </div>
                                            )
                                        }

                                    </div>

                                    <div className="alerts-page-actions">

                                        {
                                            alert.type === "suricata" && isAdmin && (
                                                <button
                                                    className="alerts-page-quarantine"
                                                    onClick={() => handleQuarantine(alert)}
                                                    title="Aislar el equipo que originó esta alerta"
                                                >
                                                    Aislar equipo
                                                </button>
                                            )
                                        }

                                        {
                                            !alert.read && (
                                                <button
                                                    className="alerts-page-read"
                                                    onClick={() => handleMarkRead(alert.id)}
                                                >
                                                    Marcar leída
                                                </button>
                                            )
                                        }

                                    </div>

                                </li>

                            ))
                        }

                    </ul>
                )
            }

        </div>

    );

}


export default Alerts;
