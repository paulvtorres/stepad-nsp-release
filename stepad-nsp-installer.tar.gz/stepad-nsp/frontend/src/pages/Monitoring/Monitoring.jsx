import { useEffect, useState } from "react";
import {
    getWanMonitorStatus,
    getWanMonitorHistory,
    saveWanMonitorSettings,
    snapshotWanMonitor,
} from "../../services/api";
import { useAuth } from "../../auth/useAuth";
import "./monitoring.css";

function LineChart({ points, width, height, stroke, yMax, ySuffix, label }) {

    if (!points || points.length < 2) {
        return (
            <div className="vpn-empty" style={{ height, lineHeight: `${height}px` }}>
                Sin datos aún.
            </div>
        );
    }

    const max = yMax || Math.max(...points.map((p) => p), 1) * 1.2;
    const step = width / (points.length - 1);

    const coords = points.map((p, i) => {
        const x = i * step;
        const y = height - (Math.min(p, max) / max) * (height - 8) - 4;
        return [x, y];
    });

    const path = coords.map(([x, y], i) => (i === 0 ? `M ${x} ${y}` : `L ${x} ${y}`)).join(" ");

    return (
        <div>
            <div className="vpn-code" style={{ marginBottom: 4 }}>{label}</div>
            <svg
                width="100%"
                height={height}
                viewBox={`0 0 ${width} ${height}`}
                preserveAspectRatio="none"
                style={{ background: "#0f172a", borderRadius: 6 }}
            >
                <polyline
                    points={coords.map(([x, y]) => `${x},${y}`).join(" ")}
                    fill="none"
                    stroke={stroke}
                    strokeWidth={2}
                />
            </svg>
            <div className="vpn-hint" style={{ marginTop: 2 }}>
                {ySuffix} · últimos {points.length} muestras
            </div>
        </div>
    );
}

function formatBps(bps) {
    if (!bps) return "0 b/s";
    if (bps >= 1e6) return `${(bps / 1e6).toFixed(1)} Mb/s`;
    if (bps >= 1e3) return `${(bps / 1e3).toFixed(0)} Kb/s`;
    return `${bps.toFixed(0)} b/s`;
}

export default function Monitoring() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [settings, setSettings] = useState(null);

    const [history, setHistory] = useState({});

    const [range, setRange] = useState(24);

    const [msg, setMsg] = useState(null);

    const [busy, setBusy] = useState(false);

    async function loadStatus() {

        try {

            const data = await getWanMonitorStatus();

            setStatus(data);

            if (!settings) setSettings(data.settings);

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        }
    }

    async function loadHistory() {

        try {

            const data = await getWanMonitorHistory(range);

            setHistory(data || {});

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        }
    }

    useEffect(() => {

        loadStatus();

        const timer = setInterval(loadStatus, 30000);

        return () => clearInterval(timer);

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {

        loadHistory();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [range]);

    async function handleSave() {

        setMsg(null);

        setBusy(true);

        try {

            const saved = await saveWanMonitorSettings({
                enabled: settings.enabled,
                interval_seconds: Number(settings.interval_seconds),
                ping_targets: settings.ping_targets,
                http_enabled: settings.http_enabled,
                http_url: settings.http_url,
                alert_threshold: Number(settings.alert_threshold),
                retention_days: Number(settings.retention_days),
            });

            setSettings(saved);

            setMsg("Configuración de monitoreo guardada.");

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }
    }

    async function handleSnapshot() {

        setMsg(null);

        setBusy(true);

        try {

            await snapshotWanMonitor();

            await loadStatus();

            setMsg("Muestra tomada.");

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }
    }

    const interfaces = status?.interfaces || {};

    const ifaceNames = Object.keys(interfaces);

    return (

        <div className="monitoring-page">

            <h3 className="monitoring-title">Monitoreo de Internet (WAN)</h3>

            <p className="monitoring-hint">
                Estado del enlace, latencia, pérdida de paquetes, chequeo HTTP y
                uso de ancho de banda por cada interfaz WAN. Se muestrea cada
                {settings ? ` ${settings.interval_seconds}s` : " 60s"}.
            </p>

            {msg && (
                <div className="notification-ok">{msg}</div>
            )}

            {ifaceNames.length === 0 ? (

                <p className="vpn-empty">
                    No hay interfaces marcadas como WAN en "Interfaces".
                    Asigna el rol WAN a la tarjeta de internet para empezar a
                    monitorear.
                </p>

            ) : (

                ifaceNames.map((name) => {

                    const iface = interfaces[name];

                    if (!iface) return null;

                    const up = iface.link_up && iface.ping_ok;

                    return (
                        <div key={name} className="vpn-form">

                            <div
                                style={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    flexWrap: "wrap",
                                    gap: 8,
                                    marginBottom: 10
                                }}
                            >
                                <strong style={{ fontSize: 16 }}>{name}</strong>
                                <span
                                    style={{
                                        background: up ? "#16a34a" : "#dc2626",
                                        color: "#fff",
                                        borderRadius: 6,
                                        padding: "3px 10px",
                                        fontSize: 12,
                                        fontWeight: 600
                                    }}
                                >
                                    {up ? "INTERNET OK" : "SIN INTERNET"}
                                </span>
                            </div>

                            <div className="vpn-status-grid">
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">Enlace</div>
                                    <div className="vpn-status-value">{iface.link_up ? "Conectado" : "Caído"}</div>
                                </div>
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">Velocidad</div>
                                    <div className="vpn-status-value">{iface.link_speed_mbps ? `${iface.link_speed_mbps} Mb/s` : "—"}</div>
                                </div>
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">Ping</div>
                                    <div className="vpn-status-value">{iface.ping_ok ? "OK" : "fallando"}</div>
                                </div>
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">Latencia</div>
                                    <div className="vpn-status-value">{iface.latency_ms ? `${iface.latency_ms.toFixed(0)} ms` : "—"}</div>
                                </div>
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">Pérdida</div>
                                    <div className="vpn-status-value">{`${iface.packet_loss || 0} %`}</div>
                                </div>
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">HTTP</div>
                                    <div className="vpn-status-value">{iface.http_ok === null ? "—" : (iface.http_ok ? "OK" : "falla")}</div>
                                </div>
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">Descarga</div>
                                    <div className="vpn-status-value">{formatBps(iface.rx_bps)}</div>
                                </div>
                                <div className="vpn-status-card">
                                    <div className="vpn-status-label">Subida</div>
                                    <div className="vpn-status-value">{formatBps(iface.tx_bps)}</div>
                                </div>
                            </div>

                            <div className="vpn-status-grid" style={{ marginTop: 6 }}>
                                <div className="vpn-status-card">
                                    <LineChart
                                        points={(history[name] || []).map((h) => h.latency_ms || 0)}
                                        width={320}
                                        height={80}
                                        stroke="#38bdf8"
                                        label={`Latencia - ${name}`}
                                        ySuffix="ms"
                                    />
                                </div>
                                <div className="vpn-status-card">
                                    <LineChart
                                        points={(history[name] || []).map((h) => h.packet_loss || 0)}
                                        width={320}
                                        height={80}
                                        stroke="#facc15"
                                        label={`Pérdida - ${name}`}
                                        ySuffix="%"
                                    />
                                </div>
                                <div className="vpn-status-card">
                                    <LineChart
                                        points={(history[name] || []).map((h) => h.rx_bps || 0)}
                                        width={320}
                                        height={80}
                                        stroke="#22c55e"
                                        label={`Descarga - ${name}`}
                                        ySuffix="bps"
                                    />
                                </div>
                                <div className="vpn-status-card">
                                    <LineChart
                                        points={(history[name] || []).map((h) => h.tx_bps || 0)}
                                        width={320}
                                        height={80}
                                        stroke="#a855f7"
                                        label={`Subida - ${name}`}
                                        ySuffix="bps"
                                    />
                                </div>
                            </div>

                        </div>
                    );
                })
            )}

            <h3>Historial</h3>

            <div className="confirm-actions">
                {[24, 168, 720].map((h) => (
                    <button
                        key={h}
                        className={range === h ? "primary-button" : "secondary-button"}
                        onClick={() => setRange(h)}
                    >
                        {h === 24 ? "24 h" : h === 168 ? "7 días" : "30 días"}
                    </button>
                ))}
            </div>

            <h3>Configuración del monitoreo</h3>

            {settings && (
                <div className="vpn-form">

                    <label className="checkbox-label">
                        <input
                            type="checkbox"
                            checked={settings.enabled}
                            onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
                        />
                        Monitoreo habilitado
                    </label>

                    <label className="checkbox-label">
                        <input
                            type="checkbox"
                            checked={settings.http_enabled}
                            onChange={(e) => setSettings({ ...settings, http_enabled: e.target.checked })}
                        />
                        Chequeo HTTP (verifica que el internet responde)
                    </label>

                    <div className="schedule-row">
                        <label>
                            Intervalo (segundos)
                            <input
                                type="number"
                                value={settings.interval_seconds}
                                min={15}
                                max={3600}
                                onChange={(e) => setSettings({ ...settings, interval_seconds: e.target.value })}
                            />
                        </label>
                        <label>
                            Avisar tras fallos seguidos
                            <input
                                type="number"
                                value={settings.alert_threshold}
                                min={1}
                                max={60}
                                onChange={(e) => setSettings({ ...settings, alert_threshold: e.target.value })}
                            />
                        </label>
                        <label>
                            Conservar (días)
                            <input
                                type="number"
                                value={settings.retention_days}
                                min={1}
                                max={365}
                                onChange={(e) => setSettings({ ...settings, retention_days: e.target.value })}
                            />
                        </label>
                    </div>

                    <label>
                        Targets de ping (separados por coma)
                        <input
                            type="text"
                            value={settings.ping_targets}
                            onChange={(e) => setSettings({ ...settings, ping_targets: e.target.value })}
                        />
                    </label>

                    <label>
                        URL del chequeo HTTP
                        <input
                            type="text"
                            value={settings.http_url}
                            onChange={(e) => setSettings({ ...settings, http_url: e.target.value })}
                        />
                    </label>

                    <div className="confirm-actions">
                        <button className="primary-button" onClick={handleSave} disabled={busy || !isAdmin}>
                            {busy ? "Guardando..." : "Guardar configuración"}
                        </button>
                        <button className="secondary-button" onClick={handleSnapshot} disabled={busy || !isAdmin}>
                            Tomar muestra ahora
                        </button>
                    </div>

                </div>
            )}

        </div>
    );
}
