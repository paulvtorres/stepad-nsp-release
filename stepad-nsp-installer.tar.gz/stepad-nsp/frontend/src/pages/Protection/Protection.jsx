import { useEffect, useState } from "react";

import {
    getProtectionSummary
} from "../../services/api";

import "./protection.css";


const PERIODS = [
    { label: "Última hora", hours: 1 },
    { label: "24 horas", hours: 24 },
    { label: "7 días", hours: 168 }
];


const EVASION_RULES = {
    dot_udp: "DNS sobre TLS (UDP)",
    dot_tcp: "DNS sobre TLS (TCP)",
    doh_v4: "DNS sobre HTTPS (IPv4)",
    doh_v6: "DNS sobre HTTPS (IPv6)",
    doh_v4_quic: "DNS sobre QUIC (IPv4)",
    doh_v6_quic: "DNS sobre QUIC (IPv6)"
};


const SERVICE_RULES = {
    service_block_v4: "Bloqueo de servicios (IPv4)",
    service_block_v6: "Bloqueo de servicios (IPv6)"
};


function formatBytes(value) {

    if (!value) return "0 B";

    const units = ["B", "KB", "MB", "GB", "TB"];

    let index = 0;

    let amount = value;

    while (amount >= 1024 && index < units.length - 1) {

        amount /= 1024;

        index += 1;

    }

    return `${amount.toFixed(amount >= 100 ? 0 : 1)} ${units[index]}`;

}


function formatPackets(value) {

    return new Intl.NumberFormat("es").format(value || 0);

}


function formatDateTime(value) {

    if (!value) return "—";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleString("es", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    });

}


function RulesTable({ title, rules, labels }) {

    const entries = Object.entries(labels);

    return (

        <div className="protection-card">

            <h3>{title}</h3>

            <table className="protection-table">

                <thead>
                    <tr>
                        <th>Regla</th>
                        <th className="num-cell">Paquetes</th>
                        <th className="num-cell">Tráfico</th>
                    </tr>
                </thead>

                <tbody>

                    {
                        entries.map(([key, label]) => {

                            const rule = rules?.[key] || {};

                            return (
                                <tr key={key}>
                                    <td>{label}</td>
                                    <td className="num-cell">{formatPackets(rule.packets)}</td>
                                    <td className="num-cell">{formatBytes(rule.bytes)}</td>
                                </tr>
                            );

                        })
                    }

                </tbody>

            </table>

        </div>

    );

}


function Protection() {

    const [summary, setSummary] = useState(null);

    const [hours, setHours] = useState(24);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);


    useEffect(() => {

        loadSummary(hours);

    }, [hours]);


    async function loadSummary(periodHours) {

        setLoading(true);

        setError(null);

        try {

            const data = await getProtectionSummary(periodHours);

            setSummary(data);

        } catch (err) {

            setError(err.message);

        } finally {

            setLoading(false);

        }

    }


    const dns = summary?.dns || {};

    const evasion = summary?.evasion || {};

    const serviceBlock = summary?.service_block || {};

    const blockedPercent = dns.total > 0
        ? Math.round((dns.blocked / dns.total) * 100)
        : 0;


    return (

        <div className="protection-container">

            <div className="protection-header">

                <div>

                    <h2>Protección</h2>

                    <p>Detección de ataques, evasión y actividad de la red.</p>

                </div>

                <div className="protection-controls">

                    <div className="period-selector">

                        {
                            PERIODS.map((period) => (

                                <button
                                    key={period.hours}
                                    className={period.hours === hours ? "period active" : "period"}
                                    onClick={() => setHours(period.hours)}
                                    disabled={loading}
                                >
                                    {period.label}
                                </button>

                            ))
                        }

                    </div>

                    <button
                        className="primary-button"
                        onClick={() => loadSummary(hours)}
                        disabled={loading}
                    >
                        {loading ? "Actualizando..." : "Actualizar"}
                    </button>

                </div>

            </div>

            {
                error && (
                    <div className="protection-error">
                        {error}
                    </div>
                )
            }

            {
                !error && !summary && loading && (
                    <div className="protection-loading">
                        Cargando datos de protección...
                    </div>
                )
            }

            {
                summary && (

                    <div className="protection-grid">

                        <div className="stats-grid">

                            <div className="stat-card">
                                <span className="stat-label">Consultas DNS</span>
                                <span className="stat-value">{formatPackets(dns.total)}</span>
                                <span className="stat-hint">
                                    {formatPackets(dns.blocked)} bloqueadas en el período
                                </span>
                            </div>

                            <div className="stat-card">
                                <span className="stat-label">Dominios bloqueados</span>
                                <span className="stat-value danger">{formatPackets(dns.blocked)}</span>
                                <span className="stat-hint">
                                    {blockedPercent}% de las consultas
                                </span>
                            </div>

                            <div className="stat-card">
                                <span className="stat-label">Dispositivos nuevos</span>
                                <span className="stat-value">{formatPackets(summary.new_devices_7d)}</span>
                                <span className="stat-hint">Últimos 7 días</span>
                            </div>

                            <div className="stat-card">
                                <span className="stat-label">Evasión (DoT/DoH)</span>
                                <span className="stat-value">{formatPackets(evasion.packets)}</span>
                                <span className="stat-hint">
                                    {formatBytes(evasion.bytes)} de tráfico cifrado a servidores DNS externos
                                </span>
                            </div>

                            <div className="stat-card">
                                <span className="stat-label">Servicios bloqueados</span>
                                <span className="stat-value">{formatPackets(serviceBlock.packets)}</span>
                                <span className="stat-hint">
                                    {formatBytes(serviceBlock.bytes)} de tráfico a servicios restringidos
                                </span>
                            </div>

                        </div>

                        <div className="protection-columns">

                            <div className="protection-card">

                                <h3>Dominios más bloqueados</h3>

                                <table className="protection-table">

                                    <thead>
                                        <tr>
                                            <th>Dominio</th>
                                            <th className="num-cell">Intentos</th>
                                            <th>Última vez</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        {
                                            summary.top_blocked_domains.length === 0 && (
                                                <tr>
                                                    <td colSpan={3} className="protection-empty">
                                                        Sin bloqueos en este período.
                                                    </td>
                                                </tr>
                                            )
                                        }

                                        {
                                            summary.top_blocked_domains.map((row) => (
                                                <tr key={row.domain}>
                                                    <td className="domain-cell">{row.domain}</td>
                                                    <td className="num-cell">{formatPackets(row.attempts)}</td>
                                                    <td>{formatDateTime(row.last_seen)}</td>
                                                </tr>
                                            ))
                                        }

                                    </tbody>

                                </table>

                            </div>

                            <div className="protection-card">

                                <h3>Dispositivos con más bloqueos</h3>

                                <table className="protection-table">

                                    <thead>
                                        <tr>
                                            <th>Dispositivo</th>
                                            <th>IP</th>
                                            <th className="num-cell">Intentos</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        {
                                            summary.top_blocked_devices.length === 0 && (
                                                <tr>
                                                    <td colSpan={3} className="protection-empty">
                                                        Sin actividad bloqueada en este período.
                                                    </td>
                                                </tr>
                                            )
                                        }

                                        {
                                            summary.top_blocked_devices.map((row) => (
                                                <tr key={row.device_id}>
                                                    <td>{row.device_name}</td>
                                                    <td>{row.device_ip || "—"}</td>
                                                    <td className="num-cell">{formatPackets(row.attempts)}</td>
                                                </tr>
                                            ))
                                        }

                                    </tbody>

                                </table>

                            </div>

                        </div>

                        <div className="protection-card">

                            <h3>Actividad bloqueada reciente</h3>

                            <table className="protection-table">

                                <thead>
                                    <tr>
                                        <th>Hora</th>
                                        <th>Dominio</th>
                                        <th>Dispositivo</th>
                                        <th>IP de origen</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    {
                                        summary.recent_blocked.length === 0 && (
                                            <tr>
                                                <td colSpan={4} className="protection-empty">
                                                    Sin actividad reciente.
                                                </td>
                                            </tr>
                                        )
                                    }

                                    {
                                        summary.recent_blocked.map((row, index) => (
                                            <tr key={`${row.domain}-${row.queried_at}-${index}`}>
                                                <td>{formatDateTime(row.queried_at)}</td>
                                                <td className="domain-cell">{row.domain}</td>
                                                <td>{row.device_name}</td>
                                                <td>{row.client_ip}</td>
                                            </tr>
                                        ))
                                    }

                                </tbody>

                            </table>

                        </div>

                        <div className="protection-columns">

                            <RulesTable
                                title="Tráfico de evasión por regla"
                                rules={evasion.rules}
                                labels={EVASION_RULES}
                            />

                            <RulesTable
                                title="Bloqueo de servicios por regla"
                                rules={serviceBlock.rules}
                                labels={SERVICE_RULES}
                            />

                        </div>

                    </div>

                )
            }

        </div>

    );

}


export default Protection;
