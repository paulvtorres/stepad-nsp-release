import { useEffect, useState } from "react";

import { getNavigationSummary, exportNavigationSummary, getDevices } from "../../services/api";

import "./logs.css";


function toDateInputValue(date) {

    const y = date.getFullYear();

    const m = String(date.getMonth() + 1).padStart(2, "0");

    const d = String(date.getDate()).padStart(2, "0");

    return `${y}-${m}-${d}`;

}


function defaultStart() {

    return toDateInputValue(new Date());

}


function formatDateTime(value) {

    if (!value) return "-";

    const d = new Date(value);

    return d.toLocaleString();

}


function formatDuration(minutes) {

    if (!minutes || minutes <= 0) return "—";

    const h = Math.floor(minutes / 60);

    const m = minutes % 60;

    if (h > 0) return `${h} h ${m} min`;

    return `${m} min`;

}


function Logs() {

    const [rows, setRows] = useState([]);

    const [devices, setDevices] = useState([]);

    const [loading, setLoading] = useState(false);

    const [exporting, setExporting] = useState(false);

    const [startDate, setStartDate] = useState(defaultStart());

    const [endDate, setEndDate] = useState(toDateInputValue(new Date()));

    const [deviceId, setDeviceId] = useState("");

    const [domainFilter, setDomainFilter] = useState("");


    useEffect(() => {

        loadDevices();

        loadSummary();

    }, []);


    async function loadDevices() {

        try {

            const data = await getDevices();
            setDevices(data);

        } catch (error) {

            console.error(error);

        }

    }


    async function loadSummary() {

        setLoading(true);

        try {

            const data = await getNavigationSummary({
                start: startDate ? `${startDate}T00:00:00` : undefined,
                end: endDate ? `${endDate}T23:59:59` : undefined,
                deviceId: deviceId || undefined,
                domain: domainFilter || undefined
            });
            setRows(data);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    async function handleExport() {

        setExporting(true);

        try {

            const blob = await exportNavigationSummary({
                start: startDate ? `${startDate}T00:00:00` : undefined,
                end: endDate ? `${endDate}T23:59:59` : undefined,
                deviceId: deviceId || undefined,
                domain: domainFilter || undefined
            });

            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");

            link.href = url;

            link.download = `resumen-navegacion-${startDate || "inicio"}-${endDate || "hoy"}.xlsx`;

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        } catch (error) {

            console.error(error);

            alert("No se pudo exportar el resumen.");

        } finally {

            setExporting(false);

        }

    }


    const totalVisits = rows.reduce((sum, r) => sum + r.visit_count, 0);

    const totalBlocked = rows.reduce((sum, r) => sum + r.blocked_count, 0);

    const uniqueDevices = new Set(rows.map((r) => r.device_id)).size;

    const sortedRows = [...rows].sort(
        (a, b) => (b.active_minutes || 0) - (a.active_minutes || 0)
    );


    const deviceSummary = Object.values(
        rows.reduce((acc, r) => {

            const entry = acc[r.device_id] || (
                acc[r.device_id] = {
                    device_id: r.device_id,
                    device_name: r.device_name,
                    device_ip: r.device_ip,
                    queries: 0,
                    domains: {}
                }
            );

            entry.queries += r.visit_count;

            entry.domains[r.domain] = (
                entry.domains[r.domain] || 0
            ) + r.visit_count;

            return acc;

        }, {})
    ).map((d) => ({
        ...d,
        shortIp: (d.device_ip || "").split(".").pop(),
        top: Object.entries(d.domains)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 6)
            .map(([dom]) => dom.replace(/^www\./, ""))
            .join(", "),
    })).sort((a, b) => b.queries - a.queries);


    return (

        <div className="logs-container">

            <div className="logs-header">

                <h2>Navegación</h2>

                <p>
                    Resumen de actividad por equipo en el rango
                    seleccionado. El "tiempo activo" es estimado (minutos
                    con actividad de DNS) y ayuda a ver cuánto navegó cada
                    máquina y en qué sitios.
                </p>

            </div>

            <div className="logs-filters">

                <label>
                    Desde
                    <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                    />
                </label>

                <label>
                    Hasta
                    <input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                    />
                </label>

                <label>
                    Equipo
                    <select
                        value={deviceId}
                        onChange={(e) => setDeviceId(e.target.value)}
                    >
                        <option value="">Todos</option>
                        {
                            devices.map((device) => (
                                <option key={device.id} value={device.id}>
                                    {device.hostname || device.ip_address}
                                </option>
                            ))
                        }
                    </select>
                </label>

                <label>
                    Dominio contiene
                    <input
                        type="text"
                        placeholder="ej. youtube"
                        value={domainFilter}
                        onChange={(e) => setDomainFilter(e.target.value)}
                    />
                </label>

                <button
                    className="primary-button"
                    onClick={loadSummary}
                    disabled={loading}
                >
                    {loading ? "Cargando..." : "Filtrar"}
                </button>

                <button
                    className="export-button"
                    onClick={handleExport}
                    disabled={exporting}
                >
                    {exporting ? "Exportando..." : "Exportar a Excel"}
                </button>

            </div>

            <div className="logs-summary-cards">

                <div className="summary-card">
                    <span className="summary-value">{uniqueDevices}</span>
                    <span className="summary-label">Equipos con actividad</span>
                </div>

                <div className="summary-card">
                    <span className="summary-value">{totalVisits}</span>
                    <span className="summary-label">Consultas totales</span>
                </div>

                <div className="summary-card blocked">
                    <span className="summary-value">{totalBlocked}</span>
                    <span className="summary-label">Bloqueadas</span>
                </div>

            </div>


            <div className="table-card">

                <h3 className="device-summary-title">Resumen por equipo</h3>

                <table className="logs-table">

                    <thead>

                        <tr>
                            <th>Equipo</th>
                            <th>Consultas</th>
                            <th>Páginas principales</th>
                        </tr>

                    </thead>

                    <tbody>

                        {
                            deviceSummary.length === 0 && (
                                <tr>
                                    <td colSpan={3} className="empty-row">
                                        Sin actividad en el rango seleccionado.
                                    </td>
                                </tr>
                            )
                        }

                        {
                            deviceSummary.map((device) => (
                                <tr key={device.device_id}>

                                    <td>
                                        <strong>
                                            {device.device_name}
                                        </strong>
                                        <span className="logs-ip-suffix">
                                            ({device.shortIp})
                                        </span>
                                    </td>

                                    <td>
                                        {device.queries.toLocaleString()}
                                    </td>

                                    <td className="logs-top-domains">
                                        {device.top}
                                    </td>

                                </tr>
                            ))
                        }

                    </tbody>

                </table>

            </div>


            <div className="table-card">

                <table className="logs-table">

                    <thead>

                        <tr>
                            <th>Equipo</th>
                            <th>IP</th>
                            <th>Dominio</th>
                            <th>Visitas</th>
                            <th>Tiempo activo</th>
                            <th>Primera vez</th>
                            <th>Última vez</th>
                            <th>Bloqueadas</th>
                        </tr>

                    </thead>

                    <tbody>

                        {
                            rows.length === 0 && !loading && (
                                <tr>
                                    <td colSpan={8} className="empty-row">
                                        Sin actividad en el rango seleccionado.
                                    </td>
                                </tr>
                            )
                        }

                        {
                            sortedRows.map((row, index) => (

                                <tr key={`${row.device_id}-${row.domain}-${index}`}>

                                    <td>{row.device_name}</td>

                                    <td>{row.device_ip || "-"}</td>

                                    <td className="domain-cell">
                                        {row.domain}
                                        {
                                            row.blocked_count > 0 && (
                                                <span className="blocked-badge">
                                                    bloqueado {row.blocked_count}x
                                                </span>
                                            )
                                        }
                                    </td>

                                    <td>{row.visit_count}</td>

                                    <td className="active-time-cell">
                                        {formatDuration(row.active_minutes)}
                                    </td>

                                    <td>{formatDateTime(row.first_seen)}</td>

                                    <td>{formatDateTime(row.last_seen)}</td>

                                    <td>{row.blocked_count}</td>

                                </tr>

                            ))
                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}


export default Logs;
