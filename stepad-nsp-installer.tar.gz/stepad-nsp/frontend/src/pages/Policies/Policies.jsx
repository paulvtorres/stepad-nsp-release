import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

import { getPolicyAudit, getPolicyOverview, simulatePolicy } from "../../services/api";
import ActionButton from "../../components/ui/ActionButton";

import "./policies.css";


const ACTION_LABELS = {
    BLOCK: "BLOQUEADO",
    ALLOW: "PERMITIDO",
    NO_RULE: "SIN REGLA",
};


function ActionBadge({ action }) {
    return (
        <span className={`policy-action ${String(action || "NO_RULE").toLowerCase()}`}>
            {ACTION_LABELS[action] || action}
        </span>
    );
}


function PolicyCenter() {

    const [overview, setOverview] = useState(null);
    const [audit, setAudit] = useState(null);
    const [deviceId, setDeviceId] = useState("");
    const [domain, setDomain] = useState("");
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(true);
    const [simulating, setSimulating] = useState(false);
    const [error, setError] = useState("");

    async function load() {
        setLoading(true);
        setError("");
        try {
            const [data, auditData] = await Promise.all([
                getPolicyOverview(),
                getPolicyAudit().catch(() => null),
            ]);
            setOverview(data);
            setAudit(auditData);
            if (!deviceId && data?.devices?.length) {
                setDeviceId(String(data.devices[0].id));
            }
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudieron cargar las políticas.");
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        load();
    }, []);

    const selectedDevice = useMemo(
        () => (overview?.devices || []).find((item) => String(item.id) === String(deviceId)),
        [overview, deviceId],
    );

    async function simulate(event) {
        event.preventDefault();
        setError("");
        setResult(null);

        if (!deviceId || !domain.trim()) {
            setError("Selecciona un equipo e ingresa un dominio.");
            return;
        }

        setSimulating(true);
        try {
            const data = await simulatePolicy(Number(deviceId), domain.trim());
            if (data?.success === false) {
                setError(data.message || "No se pudo simular.");
            } else {
                setResult(data);
            }
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo simular.");
        } finally {
            setSimulating(false);
        }
    }

    return (
        <div className="policy-page">

            <header className="policy-hero">
                <div>
                    <span className="policy-eyebrow">RED Y SEGURIDAD</span>
                    <h1>Zonas y políticas</h1>
                    <p>
                        Una zona representa un segmento de red. Un grupo representa
                        un perfil de equipos. Aquí puedes entender qué regla manda y
                        probar un equipo/dominio antes de cambiar la red.
                    </p>
                </div>
                <div className="policy-hero-actions">
                    <Link className="policy-btn" to="/network/zones">Administrar zonas</Link>
                    <Link className="policy-btn" to="/groups">Administrar grupos</Link>
                </div>
            </header>

            {error && <div className="policy-banner error">{error}</div>}

            {overview?.warning && (
                <div className="policy-banner warning">
                    <strong>Importante:</strong> {overview.warning}
                </div>
            )}

            {audit && audit.count > 0 && (
                <section className="policy-panel policy-audit">
                    <div className="policy-panel-head">
                        <div>
                            <span className="policy-eyebrow">MODO SOMBRA</span>
                            <h2>Riesgos de política detectados</h2>
                        </div>
                        <span className="policy-pill">
                            {audit.critical ? `${audit.critical} críticos` : `${audit.warning} avisos`}
                        </span>
                    </div>
                    <p className="policy-muted">
                        Estos riesgos se calculan sin cambiar el DNS actual. Sirven
                        para preparar la migración a políticas por zona/grupo/equipo.
                    </p>
                    <div className="policy-risk-list">
                        {audit.risks.map((risk, index) => (
                            <div key={`${risk.title}-${index}`} className={`policy-risk ${risk.severity}`}>
                                <div>
                                    <strong>{risk.title}</strong>
                                    <p>{risk.detail}</p>
                                </div>
                                <Link to={risk.link}>Revisar</Link>
                            </div>
                        ))}
                    </div>
                </section>
            )}

            <section className="policy-stats">
                <div className="policy-stat">
                    <span>Zonas</span>
                    <strong>{overview?.zones?.length ?? "—"}</strong>
                    <small>Segmentos de red</small>
                </div>
                <div className="policy-stat">
                    <span>Grupos</span>
                    <strong>{overview?.groups?.length ?? "—"}</strong>
                    <small>Perfiles de equipos</small>
                </div>
                <div className="policy-stat">
                    <span>Equipos</span>
                    <strong>{overview?.devices?.length ?? "—"}</strong>
                    <small>Inventario disponible</small>
                </div>
                <div className="policy-stat">
                    <span>Zona por defecto</span>
                    <strong className="policy-stat-text">{overview?.default_zone || "—"}</strong>
                    <small>Nuevos equipos</small>
                </div>
            </section>

            <section className="policy-panel">
                <div className="policy-panel-head">
                    <div>
                        <span className="policy-eyebrow">SIMULADOR</span>
                        <h2>¿Qué pasaría con este equipo?</h2>
                    </div>
                    <span className="policy-pill">Sin aplicar cambios</span>
                </div>

                <form className="policy-sim-form" onSubmit={simulate}>
                    <label>
                        Equipo
                        <select value={deviceId} onChange={(event) => setDeviceId(event.target.value)}>
                            <option value="">Seleccionar equipo…</option>
                            {(overview?.devices || []).map((item) => (
                                <option key={item.id} value={item.id}>
                                    {item.name} · {item.zone_name} · {item.group_name}
                                </option>
                            ))}
                        </select>
                    </label>
                    <label>
                        Dominio
                        <input
                            value={domain}
                            onChange={(event) => setDomain(event.target.value)}
                            placeholder="youtube.com"
                            autoComplete="off"
                        />
                    </label>
                    <ActionButton type="submit" variant="primary" loading={simulating}>
                        Simular
                    </ActionButton>
                </form>

                {selectedDevice && (
                    <div className="policy-device-line">
                        <span>{selectedDevice.name}</span>
                        <span>{selectedDevice.zone_name}</span>
                        <span>{selectedDevice.group_name}</span>
                    </div>
                )}

                {result && (
                    <div className="policy-result">
                        <div className="policy-result-top">
                            <div>
                                <span className="policy-eyebrow">RESULTADO</span>
                                <h3>{result.domain}</h3>
                            </div>
                            <div className="policy-result-actions">
                                <div>
                                    <small>Política recomendada</small>
                                    <ActionBadge action={result.recommended_action} />
                                </div>
                                <div>
                                    <small>Aplicación actual</small>
                                    <ActionBadge action={result.current_action} />
                                </div>
                            </div>
                        </div>

                        <p className="policy-reason">{result.recommended_reason}</p>

                        {result.warnings?.length > 0 && (
                            <div className="policy-result-warning">
                                {result.warnings.map((warning) => <p key={warning}>{warning}</p>)}
                            </div>
                        )}

                        <div className="policy-evidence-grid">
                            <div>
                                <span className="policy-evidence-title">Equipo, zona y grupo</span>
                                <p>{result.device?.name} · {result.zone?.name || "Sin zona"} · {result.group?.name || "Sin grupo"}</p>
                            </div>
                            <div>
                                <span className="policy-evidence-title">Reglas que coinciden</span>
                                {result.matches?.length ? (
                                    result.matches.map((match) => (
                                        <p key={match.id}>
                                            <strong>{match.scope}</strong> · {match.action} · {match.domain}
                                            {match.permanent ? " · permanente" : ""}
                                        </p>
                                    ))
                                ) : (
                                    <p>Sin regla de dominio específica.</p>
                                )}
                            </div>
                            <div>
                                <span className="policy-evidence-title">Categorías</span>
                                {result.category_matches?.length ? (
                                    result.category_matches.map((item) => (
                                        <p key={item.key}>{item.name}{item.root ? " · raíz" : ""}</p>
                                    ))
                                ) : (
                                    <p>Sin categoría coincidente.</p>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </section>

            <section className="policy-panel">
                <div className="policy-panel-head">
                    <div>
                        <span className="policy-eyebrow">CÓMO DECIDE</span>
                        <h2>Precedencia de políticas</h2>
                    </div>
                    <Link className="policy-link" to="/security">Ver reglas globales →</Link>
                </div>
                <div className="policy-precedence">
                    {(overview?.precedence || []).map((item, index) => (
                        <div className="policy-precedence-row" key={item}>
                            <span>{index + 1}</span>
                            <strong>{item}</strong>
                        </div>
                    ))}
                </div>
            </section>

            {loading ? (
                <section className="policy-panel"><p className="policy-muted">Cargando zonas y grupos…</p></section>
            ) : (
                <>
                    <section className="policy-panel">
                        <div className="policy-panel-head">
                            <div>
                                <span className="policy-eyebrow">SEGMENTOS</span>
                                <h2>Zonas de red</h2>
                            </div>
                            <Link className="policy-link" to="/network/zones">Editar zonas →</Link>
                        </div>
                        <div className="policy-card-grid">
                            {(overview?.zones || []).map((zone) => (
                                <article key={zone.id} className={`policy-zone-card ${zone.is_default ? "default" : ""}`}>
                                    <div className="policy-zone-top">
                                        <strong>{zone.name}</strong>
                                        {zone.is_default && <span className="policy-tag">Default</span>}
                                    </div>
                                    <p>{zone.network_cidr} · gateway {zone.gateway_ip}</p>
                                    <div className="policy-zone-meta">
                                        <span>{zone.devices} equipos</span>
                                        <span>{zone.rules} reglas</span>
                                        {zone.vlan_id && <span>VLAN {zone.vlan_id}</span>}
                                    </div>
                                </article>
                            ))}
                        </div>
                    </section>

                    <section className="policy-panel">
                        <div className="policy-panel-head">
                            <div>
                                <span className="policy-eyebrow">PERFILES</span>
                                <h2>Grupos de equipos</h2>
                            </div>
                            <Link className="policy-link" to="/groups">Editar grupos →</Link>
                        </div>
                        <div className="policy-card-grid">
                            {(overview?.groups || []).map((group) => (
                                <article key={group.id} className={`policy-group-card ${group.is_default ? "default" : ""}`}>
                                    <div className="policy-zone-top">
                                        <strong>{group.name}</strong>
                                        {group.is_default && <span className="policy-tag">Default</span>}
                                    </div>
                                    <div className="policy-zone-meta">
                                        <span>{group.devices} equipos</span>
                                        <span>{group.rules} reglas</span>
                                        <span>{group.categories} categorías</span>
                                    </div>
                                </article>
                            ))}
                        </div>
                    </section>
                </>
            )}

            <footer className="policy-footer">
                Esta pantalla simula políticas; no modifica equipos ni reinicia servicios.
            </footer>
        </div>
    );
}


export default PolicyCenter;
