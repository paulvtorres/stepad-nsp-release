import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";

import {
    getVulnerabilityLatest,
    listVulnerabilityReports,
    listVulnerabilitySent,
    runVulnerabilityReport,
    downloadVulnerabilityReport,
    downloadVulnerabilitySent,
} from "../../services/api";
import { formatDateTime } from "../../utils/datetime";

import "./reports.css";


const SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"];

const SEVERITY_LABELS = {
    critical: "Crítico",
    high: "Alto",
    medium: "Medio",
    low: "Bajo",
    info: "Info",
};


function severityLabel(value) {
    return SEVERITY_LABELS[value] || value || "Info";
}


function countBySeverity(findings) {
    const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };

    for (const finding of findings || []) {
        const level = finding?.severity || "info";
        counts[level] = (counts[level] || 0) + 1;
    }

    return counts;
}


function reportButtons(report) {
    if (!report) return [];

    const base = report.replace(/-resumen$/, "");

    return [
        ["Resumen PDF", `${base}-resumen.pdf`],
        ["Técnico PDF", `${base}-tecnico.pdf`],
        ["Ver resumen", `${base}-resumen.html`],
        ["Ver técnico", `${base}-tecnico.html`],
        ["Excel resumen", `${base}-resumen.xlsx`],
        ["Excel técnico", `${base}-tecnico.xlsx`],
    ];
}

function FindingCard({ finding }) {

    return (
        <article className={`vuln-finding ${finding.severity || "info"}`}>
            <div className="vuln-finding-top">
                <span className={`vuln-severity ${finding.severity || "info"}`}>
                    {severityLabel(finding.severity)}
                </span>
                <strong>{finding.title}</strong>
            </div>

            {finding.detail && <p>{finding.detail}</p>}

            {finding.evidence && (
                <div className="vuln-evidence">
                    <span>Evidencia</span>
                    {finding.evidence}
                </div>
            )}

            {Array.isArray(finding.consequences) && finding.consequences.length > 0 && (
                <div className="vuln-consequences">
                    <strong>Consecuencias</strong>
                    <ul>
                        {finding.consequences.map((item) => (
                            <li key={item}>{item}</li>
                        ))}
                    </ul>
                </div>
            )}

            {finding.recommendation && (
                <div className="vuln-recommendation">
                    <span>Recomendación</span>
                    {finding.recommendation}
                </div>
            )}
        </article>
    );
}



export default function Reports() {

    const [reports, setReports] = useState([]);
    const [sent, setSent] = useState([]);
    const [latest, setLatest] = useState(null);
    const [running, setRunning] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);

    const load = useCallback(async () => {

        setLoading(true);
        setError(null);

        try {
            const [listing, sentList] = await Promise.all([
                listVulnerabilityReports(),
                listVulnerabilitySent(),
            ]);
            setReports(listing?.reports || []);
            setSent(sentList?.sent || []);

            try {
                setLatest(await getVulnerabilityLatest());
            } catch {
                setLatest(null);
            }
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setLoading(false);
        }

    }, []);

    useEffect(() => { load(); }, [load]);


    async function handleGenerate() {

        setRunning(true);
        setError(null);
        setNotice(null);

        try {
            const result = await runVulnerabilityReport(false);

            if (result?.success) {
                setNotice(
                    `Evaluación completada · score ${result.score} · ${result.hosts ?? 0} equipos`
                );
                await load();
            } else {
                setNotice(`No se pudo generar: ${result?.message || "error"}`);
            }
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setRunning(false);
        }
    }


    async function handleDownload(name, fromSent = false) {

        if (!name) return;

        try {
            const blob = fromSent
                ? await downloadVulnerabilitySent(name)
                : await downloadVulnerabilityReport(name);
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = name;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(url);
        } catch (err) {
            setError(err.message || String(err));
        }
    }


    async function handleView(name) {

        if (!name) return;

        try {
            const blob = await downloadVulnerabilityReport(name);
            const url = URL.createObjectURL(new Blob([blob], { type: "text/html" }));
            const opened = window.open(url, "_blank");

            if (!opened) {
                setError("Permite ventanas emergentes para ver el informe.");
            }

            setTimeout(() => URL.revokeObjectURL(url), 60000);
        } catch (err) {
            setError(err.message || String(err));
        }
    }


    const scan = latest?.available ? latest.scan : null;
    const bypass = latest?.bypass || [];
    const findings = [...(scan?.findings || [])]
        .filter((finding) => finding.type !== "NETWORK_BYPASS_DUAL_HOMED")
        .sort(
            (a, b) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity)
        );
    const counts = countBySeverity(findings);
    const latestFiles = latest?.report ? reportButtons(latest.report) : [];

    return (
        <div className="vuln-page">

            <header className="vuln-hero">
                <div className="vuln-hero-copy">
                    <span className="vuln-eyebrow">POSTURA DE SEGURIDAD</span>
                    <h1>Vulnerabilidades de la red</h1>
                    <p>
                        Evaluación no intrusiva de puertos, servicios, certificados
                        y exposición. Los hallazgos se priorizan por impacto.
                    </p>
                </div>

                <div className="vuln-hero-actions">
                    <button className="vuln-btn primary" onClick={handleGenerate} disabled={running}>
                        {running ? "Evaluando…" : "Generar evaluación"}
                    </button>
                    <Link className="vuln-btn" to="/settings?tab=vulnerabilidades">
                        Programar envío
                    </Link>
                </div>
            </header>

            {error && <div className="vuln-banner error">{error}</div>}
            {notice && <div className="vuln-banner ok">{notice}</div>}

            <section className={`vuln-panel ${bypass.length ? "vuln-panel-alert" : ""}`}>
                <div className="vuln-panel-head">
                    <div>
                        <span className="vuln-eyebrow">BYPASS DE CONTROL</span>
                        <h2>Equipos con posible doble salida</h2>
                    </div>
                    <span className={`vuln-count ${bypass.length ? "danger" : "ok"}`}>
                        {bypass.length ? `${bypass.length} por revisar` : "Sin evidencia"}
                    </span>
                </div>

                {bypass.length === 0 ? (
                    <p className="vuln-muted">
                        No hay evidencia en el inventario de un equipo con una
                        segunda salida fuera del NSP.
                    </p>
                ) : (
                    <div className="vuln-findings">
                        {bypass.map((finding, index) => (
                            <FindingCard key={`bypass-${index}`} finding={finding} />
                        ))}
                    </div>
                )}

                <p className="vuln-coverage-note">
                    Detección basada en inventario y redes controladas por el NSP.
                    Una segunda salida totalmente invisible para el NSP requiere
                    telemetría del endpoint o del switch.
                </p>
            </section>

            {loading ? (
                <section className="vuln-panel">
                    <p className="vuln-muted">Cargando última evaluación…</p>
                </section>
            ) : scan ? (
                <>
                    <section className="vuln-scoreboard">
                        <div className={`vuln-score ${scan.risk === "Crítico" ? "bad" : scan.risk === "Alto" ? "warn" : "ok"}`}>
                            <span>Score de exposición</span>
                            <strong>{scan.score}<small>/100</small></strong>
                            <em>Riesgo {scan.risk || "—"}</em>
                        </div>
                        <div className="vuln-metric">
                            <span>Equipos evaluados</span>
                            <strong>{scan.hosts_up ?? 0}</strong>
                            <small>{scan.inventory ?? 0} en inventario</small>
                        </div>
                        <div className="vuln-metric">
                            <span>Críticos</span>
                            <strong className="vuln-critical">{counts.critical}</strong>
                            <small>Requieren atención inmediata</small>
                        </div>
                        <div className="vuln-metric">
                            <span>Altos</span>
                            <strong className="vuln-high">{counts.high}</strong>
                            <small>Exposición relevante</small>
                        </div>
                        <div className="vuln-metric">
                            <span>Última evaluación</span>
                            <strong className="vuln-date">
                                {formatDateTime(scan.scanned_at, "—")}
                            </strong>
                            <small>{scan.target}</small>
                        </div>
                    </section>

                    <section className="vuln-panel">
                        <div className="vuln-panel-head">
                            <div>
                                <span className="vuln-eyebrow">HALLAZGOS</span>
                                <h2>Prioridades de la última evaluación</h2>
                            </div>
                            <span className="vuln-count">{findings.length} hallazgos</span>
                        </div>

                        {findings.length === 0 ? (
                            <p className="vuln-muted">
                                No se encontraron hallazgos en la última evaluación.
                            </p>
                        ) : (
                            <div className="vuln-findings">
                                {findings.slice(0, 30).map((finding, index) => (
                                    <FindingCard
                                        key={`${finding.type}-${index}`}
                                        finding={finding}
                                    />
                                ))}
                            </div>
                        )}
                    </section>

                    <section className="vuln-panel">
                        <div className="vuln-panel-head">
                            <div>
                                <span className="vuln-eyebrow">EVIDENCIA</span>
                                <h2>Informes de esta evaluación</h2>
                            </div>
                        </div>
                        <div className="vuln-file-actions">
                            {latestFiles.map(([label, name]) => (
                                <button
                                    key={name}
                                    className="vuln-btn"
                                    onClick={() => name.endsWith(".html")
                                        ? handleView(name)
                                        : handleDownload(name)}
                                >
                                    {label}
                                </button>
                            ))}
                        </div>
                    </section>
                </>
            ) : (
                <section className="vuln-panel vuln-empty">
                    <span className="vuln-eyebrow">SIN EVALUACIÓN</span>
                    <h2>Genera la primera evaluación</h2>
                    <p>
                        El NSP revisará la red interna, inventario, puertos y
                        servicios, y mostrará aquí los hallazgos priorizados.
                    </p>
                    <button className="vuln-btn primary" onClick={handleGenerate} disabled={running}>
                        {running ? "Evaluando…" : "Generar evaluación"}
                    </button>
                </section>
            )}

            <section className="vuln-panel">
                <div className="vuln-panel-head">
                    <div>
                        <span className="vuln-eyebrow">HISTORIAL</span>
                        <h2>Informes anteriores</h2>
                    </div>
                    <span className="vuln-count">{reports.length}</span>
                </div>

                {reports.length === 0 ? (
                    <p className="vuln-muted">Aún no hay informes generados.</p>
                ) : (
                    <div className="vuln-report-list">
                        {reports.map((report) => (
                            <div key={report.id} className="vuln-report-row">
                                <div>
                                    <strong>{formatDateTime(report.created_at)}</strong>
                                    <small>{report.id}</small>
                                </div>
                                <div className="vuln-file-actions compact">
                                    {report.summary_pdf && (
                                        <button className="vuln-btn tiny" onClick={() => handleDownload(report.summary_pdf)}>PDF resumen</button>
                                    )}
                                    {report.technical_pdf && (
                                        <button className="vuln-btn tiny" onClick={() => handleDownload(report.technical_pdf)}>PDF técnico</button>
                                    )}
                                    {report.summary_html && (
                                        <button className="vuln-btn tiny" onClick={() => handleView(report.summary_html)}>Resumen</button>
                                    )}
                                    {report.technical_html && (
                                        <button className="vuln-btn tiny" onClick={() => handleView(report.technical_html)}>Técnico</button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </section>

            <section className="vuln-panel">
                <div className="vuln-panel-head">
                    <div>
                        <span className="vuln-eyebrow">CORREOS</span>
                        <h2>Entregas registradas</h2>
                    </div>
                    <span className="vuln-count">{sent.length}</span>
                </div>

                {sent.length === 0 ? (
                    <p className="vuln-muted">Aún no se han enviado correos.</p>
                ) : (
                    <div className="vuln-report-list">
                        {sent.map((item) => (
                            <div key={item.id} className="vuln-report-row">
                                <div>
                                    <strong>{formatDateTime(item.sent_at)}</strong>
                                    <small>{item.to || "sin destinatario"} · {item.success ? "enviado" : "no enviado"}</small>
                                </div>
                                <div className="vuln-file-actions compact">
                                    {item.files?.["email.html"]?.file && (
                                        <button
                                            className="vuln-btn tiny"
                                            onClick={() => handleDownload(item.files["email.html"].file, true)}
                                        >
                                            Ver correo
                                        </button>
                                    )}
                                    {item.files?.["resumen.xlsx"]?.file && (
                                        <button
                                            className="vuln-btn tiny"
                                            onClick={() => handleDownload(item.files["resumen.xlsx"].file, true)}
                                        >
                                            Adjunto
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </section>

            <footer className="vuln-footer">
                Evaluación no intrusiva · no explota vulnerabilidades · detalle por equipo solo para administradores.
            </footer>

        </div>
    );
}
