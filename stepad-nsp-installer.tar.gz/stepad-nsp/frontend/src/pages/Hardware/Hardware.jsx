import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import { getHardware } from "../../services/api";

import "./hardware.css";


function formatUptime(seconds) {

    if (!seconds) return "—";

    const days = Math.floor(seconds / 86400);

    const hours = Math.floor((seconds % 86400) / 3600);

    const mins = Math.floor((seconds % 3600) / 60);

    if (days > 0) return `${days}d ${hours}h ${mins}m`;

    return `${hours}h ${mins}m`;

}


function Hardware() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [data, setData] = useState(null);

    const [error, setError] = useState(null);

    const [loading, setLoading] = useState(true);


    async function load() {

        setLoading(true);

        try {

            const info = await getHardware();

            setData(info);

            setError(null);

        } catch (err) {

            console.error(err);

            setError("No se pudo obtener la información del equipo.");

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        load();

        const interval = setInterval(load, 10000);

        return () => clearInterval(interval);

    }, []);


    if (loading && !data) {

        return <div className="hardware-loading">Cargando información del equipo...</div>;

    }


    if (error && !data) {

        return <div className="hardware-error">{error}</div>;

    }


    if (!data) {

        return null;

    }


    const memUsedPct = data.memory?.percent ?? 0;

    const memBarColor = memUsedPct > 90 ? "var(--danger)" : memUsedPct > 70 ? "var(--warning)" : "var(--success)";


    return (

        <div className="hardware-container">

            <div className="hardware-header">

                <h2>Equipo</h2>

                <p>

                    Características del servidor: placa, CPU, memoria,

                    tarjetas de red y discos.

                </p>

            </div>


            <div className="hardware-grid">

                <div className="hw-card hw-card-wide">

                    <h3>Requisitos del sistema</h3>

                    <table className="hw-table">

                        <thead>

                            <tr>

                                <th>Característica</th>

                                <th>Valor actual</th>

                                <th>Mínimo</th>

                                <th>Recomendado</th>

                                <th>Estado</th>

                            </tr>

                        </thead>

                        <tbody>

                            {
                                Object.entries(data.requirements || {}).map(([key, req]) => {

                                    const fmt = (val) => {
                                        if (val === null || val === undefined) return "—";
                                        if (key === "ram_mb") return `${val} MB`;
                                        if (key === "disk_free_gb") return `${val} GB`;
                                        if (key === "nic_speed_mbps") return `${val} Mbps`;
                                        return val;
                                    };

                                    const label = req.status === "ok"
                                        ? "✓ Cumple"
                                        : req.status === "warning"
                                            ? "⚠ Mejorable"
                                            : req.status === "critical"
                                                ? "✗ Bajo mínimo"
                                                : "—";

                                    return (
                                        <tr key={key}>
                                            <td>{req.label}</td>
                                            <td>{fmt(req.value)}</td>
                                            <td>{fmt(req.minimum)}</td>
                                            <td>{fmt(req.recommended)}</td>
                                            <td>
                                                <span className={`hw-req hw-req-${req.status}`}>
                                                    {label}
                                                </span>
                                            </td>
                                        </tr>
                                    );
                                })
                            }

                        </tbody>

                    </table>

                    <p className="hw-req-note">
                        {
                            Object.values(data.requirements || {}).some((r) => r.status === "critical")
                                ? "⚠ Hay características bajo el mínimo recomendado. Revisa el hardware."
                                : "El equipo cumple los requisitos del sistema."
                        }
                    </p>

                </div>

                <div className="hw-card hw-card-wide">

                    <h3>Servicios activados vs hardware</h3>

                    <table className="hw-table">

                        <thead>

                            <tr>

                                <th>Servicio</th>

                                <th>Estado</th>

                            </tr>

                        </thead>

                        <tbody>

                            {
                                (data.modules || []).map((module) => (
                                    <tr key={module.key}>
                                        <td>{module.name}</td>
                                        <td>
                                            <span className={`hw-req hw-req-${module.status}`}>
                                                {
                                                    module.status === "ok"
                                                        ? "✓ Cumple el mínimo"
                                                        : "✗ Hardware insuficiente"
                                                }
                                            </span>
                                            {
                                                module.missing && module.missing.length > 0 && (
                                                    <div className="hw-req-note">
                                                        {module.message}
                                                    </div>
                                                )
                                            }
                                        </td>
                                    </tr>
                                ))
                            }

                        </tbody>

                    </table>

                </div>

                <div className="hw-card">

                    <h3>💻 Sistema</h3>

                    <table className="hw-table">

                        <tbody>

                            <tr><td>Hostname</td><td>{data.hostname}</td></tr>

                            <tr><td>Sistema</td><td>{data.os}</td></tr>

                            <tr><td>Kernel</td><td>{data.kernel}</td></tr>

                            <tr><td>Plataforma</td><td>{data.platform}</td></tr>

                            <tr><td>Activo desde</td><td>{formatUptime(data.uptime_seconds)}</td></tr>

                        </tbody>

                    </table>

                </div>


                <div className="hw-card">

                    <h3>🖥️ CPU</h3>

                    <table className="hw-table">

                        <tbody>

                            <tr><td>Procesador</td><td>{data.cpu?.model}</td></tr>

                            <tr><td>Núcleos</td><td>{data.cpu?.cores} físicos / {data.cpu?.threads} hilos</td></tr>

                            <tr><td>Uso actual</td><td>{data.cpu?.usage_percent}%</td></tr>

                            <tr><td>Carga (1/5/15)</td><td>{(data.cpu?.load || []).join(" / ")}</td></tr>

                        </tbody>

                    </table>

                </div>


                <div className="hw-card">

                    <h3>🧠 Memoria</h3>

                    <table className="hw-table">

                        <tbody>

                            <tr><td>Total</td><td>{data.memory?.total_mb} MB</td></tr>

                            <tr><td>En uso</td><td>{data.memory?.used_mb} MB</td></tr>

                            <tr><td>Disponible</td><td>{data.memory?.available_mb} MB</td></tr>

                            <tr><td>Swap</td><td>{data.memory?.swap_used_mb} / {data.memory?.swap_total_mb} MB</td></tr>

                        </tbody>

                    </table>

                    <div className="hw-bar">

                        <div className="hw-bar-fill" style={{ width: `${memUsedPct}%`, background: memBarColor }} />

                    </div>

                    <div className="hw-bar-label">{memUsedPct}% en uso</div>

                </div>


                <div className="hw-card">

                    <h3>🔩 Placa</h3>

                    <table className="hw-table">

                        <tbody>

                            <tr><td>Fabricante</td><td>{data.motherboard?.board_vendor || "—"}</td></tr>

                            <tr><td>Modelo</td><td>{data.motherboard?.board_name || "—"}</td></tr>

                            <tr><td>Versión</td><td>{data.motherboard?.board_version || "—"}</td></tr>

                            <tr><td>Serial</td><td>{data.motherboard?.board_serial || "—"}</td></tr>

                            <tr><td>BIOS</td><td>{data.bios?.vendor || "—"} {data.bios?.version || ""}</td></tr>

                        </tbody>

                    </table>

                </div>


                <div className="hw-card hw-card-wide">

                    <h3>🔌 Tarjetas de red</h3>

                    <table className="hw-table">

                        <thead>

                            <tr>

                                <th>Interfaz</th>

                                <th>Tipo</th>

                                <th>Dirección MAC</th>

                                <th>Estado</th>

                                <th>Velocidad</th>

                                <th>IPs</th>

                            </tr>

                        </thead>

                        <tbody>

                            {(data.interfaces || []).map((iface) => (

                                <tr key={iface.name}>

                                    <td className="hw-mono">{iface.name}</td>

                                    <td>{iface.type}</td>

                                    <td className="hw-mono">{iface.mac || "—"}</td>

                                    <td>

                                        <span className={`hw-state ${iface.operstate === "up" ? "ok" : "off"}`}>

                                            {iface.operstate === "up" ? "Activa" : iface.operstate || "—"}

                                        </span>

                                    </td>

                                    <td>

                                        {iface.speed_mbps ? `${iface.speed_mbps} Mbps` : "—"}

                                    </td>

                                    <td className="hw-mono">{(iface.addresses || []).join(", ") || "—"}</td>

                                </tr>

                            ))}

                        </tbody>

                    </table>

                </div>


                <div className="hw-card hw-card-wide">

                    <h3>💾 Discos</h3>

                    <table className="hw-table">

                        <thead>

                            <tr>

                                <th>Dispositivo</th>

                                <th>Modelo</th>

                                <th>Tipo</th>

                                <th>Tamaño</th>

                            </tr>

                        </thead>

                        <tbody>

                            {(data.disks || []).map((disk) => (

                                <tr key={disk.name}>

                                    <td className="hw-mono">{disk.name}</td>

                                    <td>{disk.model || "—"}</td>

                                    <td>{disk.type}</td>

                                    <td>{disk.size_gb ? `${disk.size_gb} GB` : "—"}</td>

                                </tr>

                            ))}

                        </tbody>

                    </table>

                </div>


            </div>


            {!isAdmin && <p className="hw-note">Solo los administradores pueden ver la información completa del equipo.</p>}

        </div>

    );

}


export default Hardware;
