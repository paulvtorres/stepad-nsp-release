import { useCallback, useEffect, useRef, useState } from "react";

import { Link } from "react-router-dom";

import { getBandwidthLive } from "../../services/api";

import { formatClock } from "../../utils/datetime";

import "./bandwidth.css";


const POLL_MS = 2000;

const HISTORY_MAX = 1800;

const WINDOW_SECONDS = 3600;


function formatMbps(value) {

    const number = Number(value || 0);

    if (number >= 1000) {

        return number.toFixed(0);

    }

    if (number >= 100) {

        return number.toFixed(1);

    }

    return number.toFixed(2);

}


function niceCeiling(value) {

    const steps = [
        0.1, 0.5, 1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500,
        1000, 2000, 5000, 10000,
    ];

    for (const step of steps) {

        if (value <= step) {

            return step;

        }

    }

    return Math.ceil(value / 1000) * 1000;

}


function TrafficChart({ history, ceiling }) {

    const width = 900;
    const height = 220;

    const padLeft = 54;
    const padRight = 14;
    const padTop = 12;
    const padBottom = 24;

    const innerWidth = width - padLeft - padRight;
    const innerHeight = height - padTop - padBottom;

    const last = history.length ? history[history.length - 1].t : 0;

    const from = last - WINDOW_SECONDS;

    const x = (t) => padLeft + Math.min(
        1,
        Math.max(0, (t - from) / WINDOW_SECONDS)
    ) * innerWidth;

    const y = (value) => padTop + innerHeight - Math.min(
        1,
        Math.max(0, value / ceiling)
    ) * innerHeight;

    const line = (key) => history
        .map((point, index) => `${index === 0 ? "M" : "L"}${x(point.t).toFixed(1)},${y(point[key]).toFixed(1)}`)
        .join(" ");

    const area = (key) => {

        if (!history.length) {

            return "";

        }

        return `${line(key)} L${x(last).toFixed(1)},${(padTop + innerHeight).toFixed(1)} L${x(history[0].t).toFixed(1)},${(padTop + innerHeight).toFixed(1)} Z`;

    };

    const gridValues = [0.25, 0.5, 0.75, 1];

    const ticks = [-60, -45, -30, -15, 0];

    return (
        <svg
            className="bw-chart"
            viewBox={`0 0 ${width} ${height}`}
            role="img"
            aria-label="Consumo de ancho de banda en los últimos 60 minutos"
        >

            {gridValues.map((fraction) => (

                <g key={fraction}>

                    <line
                        x1={padLeft}
                        x2={width - padRight}
                        y1={y(ceiling * fraction)}
                        y2={y(ceiling * fraction)}
                        className="bw-chart-grid"
                    />

                    <text
                        x={padLeft - 8}
                        y={y(ceiling * fraction) + 4}
                        className="bw-chart-axis"
                        textAnchor="end"
                    >
                        {formatMbps(ceiling * fraction)}
                    </text>

                </g>

            ))}

            {ticks.map((minutes) => {

                const tickTime = last + minutes * 60;

                return (
                    <text
                        key={minutes}
                        x={x(tickTime)}
                        y={height - 6}
                        className="bw-chart-axis"
                        textAnchor={minutes === 0 ? "end" : "middle"}
                    >
                        {formatClock(new Date(tickTime * 1000))}
                    </text>
                );

            })}

            <path d={area("rx")} className="bw-chart-area-rx" />

            <path d={area("tx")} className="bw-chart-area-tx" />

            <path d={line("rx")} className="bw-chart-line-rx" />

            <path d={line("tx")} className="bw-chart-line-tx" />

            <text
                x={padLeft - 46}
                y={padTop + 4}
                className="bw-chart-unit"
            >
                Mbps
            </text>

        </svg>
    );

}


export default function Bandwidth() {

    const [data, setData] = useState(null);

    const [history, setHistory] = useState([]);

    const [error, setError] = useState("");

    const [paused, setPaused] = useState(false);

    const busy = useRef(false);


    const load = useCallback(async (includeHistory) => {

        if (busy.current) {

            return;

        }

        busy.current = true;

        try {

            const payload = await getBandwidthLive(includeHistory);

            setData(payload);

            setError("");

            const epoch = payload.epoch ?? Date.now() / 1000;

            const point = {
                t: epoch,
                rx: payload.wan?.rx_mbps ?? 0,
                tx: payload.wan?.tx_mbps ?? 0,
            };

            if (includeHistory) {

                const seeded = (payload.history || []).map((item) => ({
                    t: item.t,
                    rx: item.rx,
                    tx: item.tx,
                }));

                const lastSeeded = seeded.length
                    ? seeded[seeded.length - 1].t
                    : null;

                setHistory(
                    lastSeeded !== null && epoch <= lastSeeded
                        ? seeded
                        : [...seeded, point].slice(-HISTORY_MAX)
                );

            } else {

                setHistory((previous) => {

                    if (previous.length && previous[previous.length - 1].t === epoch) {

                        return previous;

                    }

                    return [...previous, point].slice(-HISTORY_MAX);

                });

            }

        } catch (requestError) {

            setError(
                requestError?.message || "No se pudo leer el ancho de banda."
            );

        } finally {

            busy.current = false;

        }

    }, []);


    useEffect(() => {

        let timer = null;

        const tick = () => {

            const visible = document.visibilityState === "visible";

            setPaused(!visible);

            if (visible) {

                load(false);

            }

        };

        // Al volver a la pestaña se re-siembra el histórico (recupera el
        // hueco). El indicador de pausa lo actualiza el propio tick.
        const onVisibility = () => {

            if (document.visibilityState === "visible") {

                load(true);

            }

        };

        // Carga inicial (en un callback para no encadenar renders).
        const kickoff = window.setTimeout(() => load(true), 0);

        timer = window.setInterval(tick, POLL_MS);

        document.addEventListener("visibilitychange", onVisibility);

        return () => {

            window.clearTimeout(kickoff);

            if (timer) {

                window.clearInterval(timer);

            }

            document.removeEventListener("visibilitychange", onVisibility);

        };

    }, [load]);


    const wan = data?.wan || {};

    const devices = data?.devices || [];

    const acctEnabled = data?.acct_enabled !== false;

    const ceiling = niceCeiling(
        Math.max(
            wan.peak_rx_mbps || 0,
            wan.peak_tx_mbps || 0,
            wan.rx_mbps || 0,
            wan.tx_mbps || 0,
            0.1
        )
    );

    const totalNow = (wan.rx_mbps || 0) + (wan.tx_mbps || 0);

    // La participación se mide sobre lo que consumen los equipos (no
    // sobre la WAN: el NSP también consume y las cifras no coinciden).
    const devicesTotal = (data?.devices_total_rx_mbps || 0)
        + (data?.devices_total_tx_mbps || 0);

    return (
        <div className="bw-container">

            <div className="bw-page-head">
                <div>
                    <h1>Ancho de banda</h1>
                    <p>
                        Consumo en tiempo real de la salida a Internet del NSP y
                        de cada equipo. Arriba ves la tasa de la WAN; abajo, qué
                        equipos están usando el enlace en este momento. Para el
                        volumen acumulado y los destinos, usá Egreso.
                    </p>
                </div>
                <Link className="bw-link" to="/egress">
                    Ver historial en Egreso →
                </Link>
            </div>

            <div className="bw-toolbar">
                <span className={`bw-live ${paused ? "paused" : ""}`}>
                    <span className="bw-live-dot" />
                    {paused ? "En pausa (pestaña oculta)" : "En vivo · cada 2 s"}
                </span>
                <span className="bw-updated">
                    {data?.timestamp
                        ? `Última muestra ${formatClock(new Date(data.timestamp))}`
                        : "Cargando…"}
                </span>
            </div>

            {error && <p className="bw-error">{error}</p>}

            <div className="bw-stats">

                <div className="bw-stat">
                    <span className="bw-stat-label">Bajada ahora</span>
                    <strong>{formatMbps(wan.rx_mbps)} <em>Mbps</em></strong>
                    <p>Descarga total por la WAN.</p>
                </div>

                <div className="bw-stat">
                    <span className="bw-stat-label">Subida ahora</span>
                    <strong>{formatMbps(wan.tx_mbps)} <em>Mbps</em></strong>
                    <p>Carga total por la WAN.</p>
                </div>

                <div className="bw-stat">
                    <span className="bw-stat-label">Pico (60 min)</span>
                    <strong>
                        {formatMbps(wan.peak_rx_mbps)}
                        <em> / {formatMbps(wan.peak_tx_mbps)} Mbps</em>
                    </strong>
                    <p>Máximo de bajada / subida observado.</p>
                </div>

                <div className="bw-stat">
                    <span className="bw-stat-label">Equipos activos</span>
                    <strong>{devices.length}</strong>
                    <p>
                        {totalNow > 0
                            ? `Total ahora: ${formatMbps(totalNow)} Mbps`
                            : "Sin tráfico relevante en este momento."}
                    </p>
                </div>

            </div>

            <section className="bw-section">
                <div className="bw-section-head">
                    <h2>Últimos 60 minutos</h2>
                    <div className="bw-legend">
                        <span className="bw-legend-item">
                            <span className="bw-swatch rx" /> Bajada
                        </span>
                        <span className="bw-legend-item">
                            <span className="bw-swatch tx" /> Subida
                        </span>
                    </div>
                </div>

                {history.length > 1 ? (
                    <TrafficChart history={history} ceiling={ceiling} />
                ) : (
                    <p className="bw-empty">Recolectando muestras…</p>
                )}

                <p className="bw-hint">
                    Interfaz WAN: <strong>{wan.interface || "—"}</strong>
                    {" · "}ventana de {data?.window_seconds ?? 10} s
                </p>
            </section>

            <section className="bw-section">
                <h2>Equipos con más consumo ahora</h2>

                {devices.length ? (
                    <div className="bw-table-wrap">
                        <table className="bw-table">
                            <thead>
                                <tr>
                                    <th>Equipo</th>
                                    <th className="bw-num">Bajada</th>
                                    <th className="bw-num">Subida</th>
                                    <th>Participación</th>
                                </tr>
                            </thead>
                            <tbody>
                                {devices.map((device) => {

                                    const share = devicesTotal > 0
                                        ? ((device.rx_mbps + device.tx_mbps) / devicesTotal) * 100
                                        : 0;

                                    return (
                                        <tr key={device.ip}>
                                            <td>
                                                <div className="bw-device-name">
                                                    {device.name || "Equipo sin nombre"}
                                                </div>
                                                <div className="bw-device-ip">{device.ip}</div>
                                            </td>
                                            <td className="bw-num">
                                                {formatMbps(device.rx_mbps)}
                                            </td>
                                            <td className="bw-num">
                                                {formatMbps(device.tx_mbps)}
                                            </td>
                                            <td>
                                                <div className="bw-share">
                                                    <div className="bw-share-bar">
                                                        <span
                                                            style={{
                                                                width: `${Math.min(100, share).toFixed(1)}%`,
                                                            }}
                                                        />
                                                    </div>
                                                    <span className="bw-share-value">
                                                        {share.toFixed(1)}%
                                                    </span>
                                                </div>
                                            </td>
                                        </tr>
                                    );

                                })}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p className="bw-empty">
                        Ningún equipo está usando el enlace en este momento.
                    </p>
                )}

                {!acctEnabled && (
                    <p className="bw-note">
                        La contabilidad por equipo no está activa. Se habilita
                        sola al arrancar el servicio (conntrack accounting); si
                        persiste, revisá <code>nf_conntrack_acct</code>.
                    </p>
                )}
            </section>

        </div>
    );

}
