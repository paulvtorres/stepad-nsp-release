import { useCallback, useEffect, useMemo, useState } from "react";

import {
    getEgressSummary,
    getEgressDestinations,
    getEgressDevices,
    getEgressNewDestinations,
    getEgressRecent,
} from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./egress.css";


const WINDOWS = [
    { label: "24 horas", hours: 24 },
    { label: "7 días", hours: 168 },
    { label: "30 días", hours: 720 },
];


const TABS = [
    { id: "destinations", label: "Destinos" },
    { id: "devices", label: "Equipos" },
    { id: "new", label: "Nuevos destinos" },
    { id: "recent", label: "Flujos recientes" },
];


function formatBytes(n) {

    const v = Number(n) || 0;

    if (v < 1024) {
        return `${v} B`;
    }

    const units = ["KB", "MB", "GB", "TB"];

    let x = v / 1024;

    let i = 0;

    while (x >= 1024 && i < units.length - 1) {
        x /= 1024;
        i += 1;
    }

    return `${x.toFixed(x >= 10 ? 1 : 2)} ${units[i]}`;

}


function Bar({ value, max }) {

    const pct = max > 0 ? Math.max(2, Math.round((value / max) * 100)) : 0;

    return (
        <div className="egress-bar-track">
            <div className="egress-bar-fill" style={{ width: `${pct}%` }} />
        </div>
    );

}


export default function Egress() {

    const [windowHours, setWindowHours] = useState(24);

    const [tab, setTab] = useState("destinations");

    const [summary, setSummary] = useState(null);

    const [destinations, setDestinations] = useState([]);

    const [devices, setDevices] = useState([]);

    const [newDests, setNewDests] = useState([]);

    const [recent, setRecent] = useState([]);

    const [search, setSearch] = useState("");

    const [loading, setLoading] = useState(true);

    const [updatedAt, setUpdatedAt] = useState(null);


    const load = useCallback(async () => {

        try {

            const [s, d, v, n, r] = await Promise.all([
                getEgressSummary(windowHours),
                getEgressDestinations(windowHours, 100),
                getEgressDevices(windowHours, 100),
                getEgressNewDestinations(windowHours, 30),
                getEgressRecent(windowHours, 150),
            ]);

            setSummary(s);

            setDestinations(d.items || []);

            setDevices(v.items || []);

            setNewDests(n.items || []);

            setRecent(r.items || []);

            setUpdatedAt(new Date());

        } catch {
            // silencioso: la pagina se sigue mostrando con lo ultimo que haya
        } finally {

            setLoading(false);

        }

    }, [windowHours]);


    useEffect(() => {

        setLoading(true);

        load();

        const timer = setInterval(load, 30000);

        return () => clearInterval(timer);

    }, [load]);


    const maxDestOut = useMemo(
        () => destinations.reduce((m, r) => Math.max(m, r.bytes_out), 0),
        [destinations]
    );

    const maxDevOut = useMemo(
        () => devices.reduce((m, r) => Math.max(m, r.bytes_out), 0),
        [devices]
    );


    const term = search.trim().toLowerCase();

    const filteredDestinations = useMemo(() => {

        if (!term) {
            return destinations;
        }

        return destinations.filter((r) =>
            `${r.dest_ip} ${r.country || ""} ${r.as_org || ""} ${r.asn || ""}`
                .toLowerCase()
                .includes(term)
        );

    }, [destinations, term]);

    const filteredDevices = useMemo(() => {

        if (!term) {
            return devices;
        }

        return devices.filter((r) =>
            `${r.src_ip} ${r.device_name || ""}`
                .toLowerCase()
                .includes(term)
        );

    }, [devices, term]);


    const hasData = (summary?.connections || 0) > 0;


    return (
        <div className="egress-container">

            <div className="egress-page-head">
                <h1>Egreso / Exfiltración</h1>
                <p>
                    Qué están subiendo tus equipos hacia Internet. El NSP mide el
                    volumen saliente por equipo y destino, marca los destinos
                    nuevos y resalta subidas anómalas: la señal típica de un
                    equipo comprometido enviando datos a un servidor externo
                    (C2, exfiltración). Con la puerta de entrada cerrada, esta es
                    la vía por la que realmente sale tu información.
                </p>
            </div>

            <div className="egress-toolbar">
                <div className="egress-periods">
                    {WINDOWS.map((period) => (
                        <button
                            key={period.hours}
                            type="button"
                            className={
                                `egress-period ${windowHours === period.hours ? "active" : ""}`
                            }
                            onClick={() => setWindowHours(period.hours)}
                        >
                            {period.label}
                        </button>
                    ))}
                </div>

                <div className="egress-toolbar-right">
                    <input
                        className="egress-search"
                        type="search"
                        placeholder="Buscar IP, país u organización…"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                    <span className="egress-updated">
                        {updatedAt
                            ? `Actualizado ${formatDateTime(updatedAt)}`
                            : "Cargando…"}
                    </span>
                </div>
            </div>

            {/* Estadisticas globales */}
            <section className="egress-section">
                <div className="egress-stats">

                    <div className="egress-stat">
                        <span className="egress-stat-label">Subido (salida)</span>
                        <strong>{formatBytes(summary?.bytes_out)}</strong>
                        <p>Datos enviados desde tus equipos a Internet.</p>
                    </div>

                    <div className="egress-stat">
                        <span className="egress-stat-label">Descargado (entrada)</span>
                        <strong>{formatBytes(summary?.bytes_in)}</strong>
                        <p>Datos recibidos por tus equipos desde Internet.</p>
                    </div>

                    <div className="egress-stat">
                        <span className="egress-stat-label">Conexiones</span>
                        <strong>{summary?.connections ?? 0}</strong>
                        <p>Flujos salientes observados en la ventana.</p>
                    </div>

                    <div className="egress-stat">
                        <span className="egress-stat-label">Destinos</span>
                        <strong>{summary?.destinations ?? 0}</strong>
                        <p>Servidores externos distintos contactados.</p>
                    </div>

                    <div className="egress-stat">
                        <span className="egress-stat-label">Equipos</span>
                        <strong>{summary?.devices ?? 0}</strong>
                        <p>Dispositivos internos con tráfico saliente.</p>
                    </div>

                </div>

                {!loading && !hasData && (
                    <p className="egress-empty">
                        Todavía no hay flujos salientes registrados en esta
                        ventana. El NSP empieza a medir el egreso a medida que
                        los equipos se comunican con Internet.
                    </p>
                )}
            </section>

            {/* Detalle por vista */}
            <section className="egress-section">

                <div className="egress-tabs">
                    {TABS.map((t) => (
                        <button
                            key={t.id}
                            type="button"
                            className={
                                `egress-tab ${tab === t.id ? "active" : ""}`
                            }
                            onClick={() => setTab(t.id)}
                        >
                            {t.label}
                            {t.id === "new" && newDests.length > 0 && (
                                <span className="egress-tab-count">
                                    {newDests.length}
                                </span>
                            )}
                        </button>
                    ))}
                </div>

                {tab === "destinations" && (
                    <>
                        <p className="egress-note">
                            Destinos externos ordenados por volumen subido. Una
                            subida muy superior a la bajada hacia un destino
                            desconocido es la principal señal de exfiltración.
                        </p>

                        {filteredDestinations.length === 0 ? (
                            <p className="egress-empty">Sin destinos todavía.</p>
                        ) : (
                            <div className="egress-table-wrap">
                                <table className="egress-table">
                                    <thead>
                                        <tr>
                                            <th>Destino</th>
                                            <th>País / ASN</th>
                                            <th>Organización</th>
                                            <th className="egress-num-cell">Subido</th>
                                            <th>Proporción</th>
                                            <th className="egress-num-cell">Bajado</th>
                                            <th className="egress-num-cell">Conex.</th>
                                            <th className="egress-num-cell">Equipos</th>
                                            <th>Último</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredDestinations.map((row) => (
                                            <tr key={row.dest_ip}>
                                                <td className="egress-ip-cell">
                                                    {row.dest_ip}
                                                    {row.app_proto && (
                                                        <span className="egress-proto">
                                                            {row.app_proto}
                                                        </span>
                                                    )}
                                                </td>
                                                <td>{row.country || "—"}</td>
                                                <td className="egress-org-cell" title={row.as_org || ""}>
                                                    {row.as_org || `AS${row.asn || "?"}`}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {formatBytes(row.bytes_out)}
                                                </td>
                                                <td className="egress-bar-cell">
                                                    <Bar
                                                        value={row.bytes_out}
                                                        max={maxDestOut}
                                                    />
                                                </td>
                                                <td className="egress-num-cell">
                                                    {formatBytes(row.bytes_in)}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.connections}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.devices}
                                                </td>
                                                <td>{formatDateTime(row.last_seen)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </>
                )}

                {tab === "devices" && (
                    <>
                        <p className="egress-note">
                            Volumen saliente por equipo interno. Mirá el número
                            de destinos y el volumen: un equipo que sube mucho a
                            pocos destinos nuevos merece una revisión.
                        </p>

                        {filteredDevices.length === 0 ? (
                            <p className="egress-empty">Sin equipos todavía.</p>
                        ) : (
                            <div className="egress-table-wrap">
                                <table className="egress-table">
                                    <thead>
                                        <tr>
                                            <th>Equipo</th>
                                            <th>IP</th>
                                            <th className="egress-num-cell">Subido</th>
                                            <th>Proporción</th>
                                            <th className="egress-num-cell">Bajado</th>
                                            <th className="egress-num-cell">Conex.</th>
                                            <th className="egress-num-cell">Destinos</th>
                                            <th>Último</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredDevices.map((row) => (
                                            <tr key={row.src_ip}>
                                                <td className="egress-ip-cell">
                                                    {row.device_name || "Desconocido"}
                                                </td>
                                                <td>{row.src_ip}</td>
                                                <td className="egress-num-cell">
                                                    {formatBytes(row.bytes_out)}
                                                </td>
                                                <td className="egress-bar-cell">
                                                    <Bar
                                                        value={row.bytes_out}
                                                        max={maxDevOut}
                                                    />
                                                </td>
                                                <td className="egress-num-cell">
                                                    {formatBytes(row.bytes_in)}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.connections}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.destinations}
                                                </td>
                                                <td>{formatDateTime(row.last_seen)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </>
                )}

                {tab === "new" && (
                    <>
                        <p className="egress-note">
                            Destinos contactados en esta ventana que no se habían
                            visto en los 30 días previos. Un destino nuevo con
                            subida alta es la señal más fuerte de un compromiso.
                        </p>

                        {newDests.length === 0 ? (
                            <p className="egress-empty">
                                No hay destinos nuevos. Buen indicio: el egreso
                                se mantiene dentro de lo conocido.
                            </p>
                        ) : (
                            <div className="egress-table-wrap">
                                <table className="egress-table">
                                    <thead>
                                        <tr>
                                            <th>Destino</th>
                                            <th>País / ASN</th>
                                            <th>Organización</th>
                                            <th className="egress-num-cell">Subido</th>
                                            <th className="egress-num-cell">Bajado</th>
                                            <th className="egress-num-cell">Conex.</th>
                                            <th className="egress-num-cell">Equipos</th>
                                            <th>Primera vez</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {newDests.map((row) => (
                                            <tr key={row.dest_ip}>
                                                <td className="egress-ip-cell">
                                                    {row.dest_ip}
                                                </td>
                                                <td>{row.country || "—"}</td>
                                                <td className="egress-org-cell" title={row.as_org || ""}>
                                                    {row.as_org || `AS${row.asn || "?"}`}
                                                </td>
                                                <td className="egress-num-cell highlight">
                                                    {formatBytes(row.bytes_out)}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {formatBytes(row.bytes_in)}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.connections}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.devices}
                                                </td>
                                                <td>{formatDateTime(row.first_seen)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </>
                )}

                {tab === "recent" && (
                    <>
                        <p className="egress-note">
                            Últimos flujos salientes registrados (equipo → destino:
                            puerto, protocolo y volumen).
                        </p>

                        {recent.length === 0 ? (
                            <p className="egress-empty">Sin flujos todavía.</p>
                        ) : (
                            <div className="egress-table-wrap">
                                <table className="egress-table">
                                    <thead>
                                        <tr>
                                            <th>Equipo</th>
                                            <th>Destino</th>
                                            <th>Puerto</th>
                                            <th>Proto</th>
                                            <th className="egress-num-cell">Subido</th>
                                            <th className="egress-num-cell">Bajado</th>
                                            <th className="egress-num-cell">Conex.</th>
                                            <th>Último</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {recent.map((row, idx) => (
                                            <tr key={`${row.src_ip}-${row.dest_ip}-${row.dest_port}-${idx}`}>
                                                <td className="egress-ip-cell">
                                                    {row.device_name || row.src_ip}
                                                </td>
                                                <td>
                                                    {row.dest_ip}
                                                    {row.country && (
                                                        <span className="egress-proto">
                                                            {row.country}
                                                        </span>
                                                    )}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.dest_port ?? "—"}
                                                </td>
                                                <td>{row.app_proto || "—"}</td>
                                                <td className="egress-num-cell">
                                                    {formatBytes(row.bytes_out)}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {formatBytes(row.bytes_in)}
                                                </td>
                                                <td className="egress-num-cell">
                                                    {row.connections}
                                                </td>
                                                <td>{formatDateTime(row.last_seen)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </>
                )}

            </section>

        </div>
    );

}
