import DomainRules from "./components/DomainRules";
import EncryptedDnsSecurity from "./components/EncryptedDnsSecurity";
import ContentCategories from "./components/ContentCategories";
import FirewallHardening from "./components/FirewallHardening";

import "./security.css";


function Security() {


    return (

        <div className="security-container">

            <h2>
                Gestión de seguridad
            </h2>

            <p className="security-description">

                Administra los bloqueos de la red en todas sus capas:
                dominios, DNS cifrado (DoT/DoH) y acceso por IP a servicios.

            </p>


            <EncryptedDnsSecurity />


            <ContentCategories />


            <DomainRules />


            <FirewallHardening />


        </div>

    );

}


export default Security;