import { useEffect, useState } from "react";

import { getSecurityPosture, setAuthorizedInbound } from "../../../services/api";

const SEV = {
    critical: { label: "Crítico" },
    high: { label: "Alto" },
    medium: { label: "Medio" },
    low: { label: "Bajo" },
    info: { label: "Información" },
};

export default function SecurityAdvisories() {

    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    async function load() {
        setLoading(true);
        setError(null);
        try {
            setData(await getSecurityPosture());
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => { load(); }, []);

    async function authorize(port) {
        const current = data?.authorized_inbound || [];
        const next = Array.from(new Set([...current, String(port)]));
        try {
            await setAuthorizedInbound(next);
        } catch (err) {
            setError(err.message || String(err));
        }
        await load();
    }

    const list = data?.advisories || [];

    return (
        <div className="sec-adv-card">
            <div className="sec-adv-head">
                <div>
                    <h3>Avisos de seguridad</h3>
                    <p className="sec-adv-sub">
                        Revisión proactiva de configuración y exposición del NSP.
                    </p>
                </div>
                <button
                    type="button"
                    className="sec-adv-refresh"
                    onClick={load}
                    disabled={loading}
                >
                    {loading ? "Analizando…" : "Actualizar"}
                </button>
            </div>

            {error && <p className="sec-adv-error">{error}</p>}

            {!loading && !error && list.length === 0 && (
                <div className="sec-adv-ok">
                    <span className="sec-adv-ok-icon">✓</span>
                    Sin observaciones. La postura de seguridad está correcta.
                </div>
            )}

            <ul className="sec-adv-list">
                {list.map((a, i) => {
                    const s = SEV[a.severity] || SEV.info;
                    const cls = "sec-adv-" + (SEV[a.severity] ? a.severity : "info");
                    return (
                        <li key={i} className={"sec-adv-item " + cls}>
                            <span className={"sec-adv-badge " + cls}>{s.label}</span>
                            <div className="sec-adv-body">
                                <strong>{a.title}</strong>
                                <p>{a.detail}</p>
                                {a.recommendation && (
                                    <p className="sec-adv-rec">
                                        <span>Recomendación:</span> {a.recommendation}
                                    </p>
                                )}
                                {a.action === "authorize_inbound" && (a.ports || []).length > 0 && (
                                    <div className="sec-adv-actions">
                                        {(a.ports || []).map((p) => (
                                            <button
                                                key={p}
                                                type="button"
                                                className="sec-adv-auth"
                                                onClick={() => authorize(p)}
                                            >
                                                Autorizar puerto {p}
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </li>
                    );
                })}
            </ul>

            <style>{`
                .sec-adv-card{background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:18px}
                .sec-adv-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}
                .sec-adv-head h3{margin:0;font-size:1.05rem}
                .sec-adv-sub{margin:2px 0 0;font-size:0.8rem;opacity:.7}
                .sec-adv-refresh{background:rgba(255,255,255,0.06);color:inherit;border:1px solid rgba(255,255,255,0.14);border-radius:8px;padding:6px 12px;cursor:pointer;font-size:0.82rem}
                .sec-adv-refresh:disabled{opacity:.6;cursor:default}
                .sec-adv-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:10px}
                .sec-adv-item{display:flex;gap:12px;padding:12px 14px;border-radius:10px;border:1px solid rgba(255,255,255,0.08);border-left-width:4px;background:rgba(255,255,255,0.02)}
                .sec-adv-badge{flex:0 0 auto;align-self:flex-start;font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;padding:3px 8px;border-radius:999px}
                .sec-adv-body strong{display:block;font-size:0.92rem;margin-bottom:3px}
                .sec-adv-body p{margin:0;font-size:0.82rem;opacity:.85;line-height:1.35}
                .sec-adv-rec{margin-top:5px !important;opacity:.95 !important}
                .sec-adv-rec span{font-weight:600;color:#93c5fd}
                .sec-adv-ok{display:flex;align-items:center;gap:10px;padding:14px;border-radius:10px;border:1px solid rgba(34,197,94,0.3);background:rgba(34,197,94,0.06);font-size:0.9rem}
                .sec-adv-ok-icon{color:#22c55e;font-weight:700;font-size:1.1rem}
                .sec-adv-error{padding:10px 12px;border-radius:8px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);font-size:0.85rem}
                .sec-adv-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
                .sec-adv-auth{background:rgba(59,130,246,0.15);border:1px solid rgba(59,130,246,0.4);color:#bfdbfe;border-radius:8px;padding:5px 10px;font-size:0.78rem;cursor:pointer}
                .sec-adv-auth:hover{background:rgba(59,130,246,0.28)}
                .sec-adv-critical{border-left-color:#dc2626}
                .sec-adv-critical .sec-adv-badge{background:rgba(220,38,38,0.18);color:#fca5a5;border:1px solid rgba(220,38,38,0.4)}
                .sec-adv-high{border-left-color:#ef4444}
                .sec-adv-high .sec-adv-badge{background:rgba(239,68,68,0.15);color:#fca5a5;border:1px solid rgba(239,68,68,0.35)}
                .sec-adv-medium{border-left-color:#f59e0b}
                .sec-adv-medium .sec-adv-badge{background:rgba(245,158,11,0.15);color:#fcd34d;border:1px solid rgba(245,158,11,0.35)}
                .sec-adv-low{border-left-color:#3b82f6}
                .sec-adv-low .sec-adv-badge{background:rgba(59,130,246,0.15);color:#93c5fd;border:1px solid rgba(59,130,246,0.35)}
                .sec-adv-info{border-left-color:#6b7280}
                .sec-adv-info .sec-adv-badge{background:rgba(156,163,175,0.15);color:#d1d5db;border:1px solid rgba(156,163,175,0.35)}
            `}</style>
        </div>
    );
}
