import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getContentCategories,
    getContentCategory,
    setCategoryEnabled,
    addCategoryDomain,
    removeCategoryDomain,
    refreshContentFeed
} from "../../../services/api";


function ContentCategories() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [categories, setCategories] = useState([]);

    const [expanded, setExpanded] = useState(null);

    const [detail, setDetail] = useState(null);

    const [newDomain, setNewDomain] = useState("");

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getContentCategories()

            .then((data) => {
                if (!cancelled) setCategories(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleRefreshFeed() {

        setBusy(true);

        try {

            const result = await refreshContentFeed("malware");

            alert(`Feed actualizado: ${result?.added ?? 0} dominios nuevos (${result?.total ?? 0} en total).`);

            const data = await getContentCategories();

            setCategories(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function loadDetail(key) {

        setExpanded(key);

        setNewDomain("");

        try {

            const data = await getContentCategory(key);

            setDetail(data);

        } catch (err) {

            setError(err.message);

        }

    }


    async function handleToggle(category) {

        setError(null);

        setBusy(true);

        try {

            await setCategoryEnabled(category.key, !category.enabled);

            const data = await getContentCategories();

            setCategories(data || []);

            if (expanded === category.key) {

                const d = await getContentCategory(category.key);

                setDetail(d);

            }

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleAddDomain() {

        if (!expanded || !newDomain.trim()) return;

        setError(null);

        setBusy(true);

        try {

            const d = await addCategoryDomain(expanded, newDomain.trim());

            setDetail(d);

            setNewDomain("");

            const data = await getContentCategories();

            setCategories(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRemoveDomain(domain) {

        if (!expanded) return;

        setError(null);

        setBusy(true);

        try {

            const d = await removeCategoryDomain(expanded, domain);

            setDetail(d);

            const data = await getContentCategories();

            setCategories(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="security-section">

            <h3>Filtrado por categoría</h3>

            <p className="security-description">

                Bloquea por categorías de contenido (redes sociales,
                juegos, apuestas...). Al activar una categoría se
                bloquean todos sus dominios al instante.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            <div className="category-list">

                {
                    categories.map((category) => (
                        <div key={category.key} className={`category-row ${category.enabled ? "on" : ""}`}>

                            <div className="category-head" onClick={() => loadDetail(category.key)}>

                                <div className="category-info">

                                    <span className="category-name">{category.name}</span>

                                    <span className="category-meta">
                                        {category.domains} dominios · {category.enabled ? "activa" : "inactiva"}
                                    </span>

                                </div>

                                {
                                    isAdmin && (
                                        <button
                                            className={`category-toggle ${category.enabled ? "on" : ""}`}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleToggle(category);
                                            }}
                                            disabled={busy}
                                        >
                                            {category.enabled ? "Desactivar" : "Activar"}
                                        </button>
                                    )
                                }

                                {
                                    isAdmin && category.key === "malware" && (
                                        <button
                                            className="category-refresh"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleRefreshFeed();
                                            }}
                                            disabled={busy}
                                            title="Actualizar dominios maliciosos/phishing"
                                        >
                                            Actualizar feed
                                        </button>
                                    )
                                }

                            </div>

                            {
                                expanded === category.key && detail && detail.key === category.key && (
                                    <div className="category-detail">

                                        <div className="category-domains">

                                            {
                                                detail.domains.map((domain) => (
                                                    <span key={domain} className="category-domain-chip">
                                                        {domain}
                                                        {
                                                            isAdmin && (
                                                                <button
                                                                    className="category-remove"
                                                                    onClick={() => handleRemoveDomain(domain)}
                                                                    disabled={busy}
                                                                    title="Quitar dominio"
                                                                >
                                                                    ✕
                                                                </button>
                                                            )
                                                        }
                                                    </span>
                                                ))
                                            }

                                        </div>

                                        {
                                            isAdmin && (
                                                <div className="category-add">
                                                    <input
                                                        type="text"
                                                        value={newDomain}
                                                        onChange={(e) => setNewDomain(e.target.value)}
                                                        placeholder="dominio.com"
                                                    />
                                                    <button
                                                        className="primary-button"
                                                        onClick={handleAddDomain}
                                                        disabled={busy || !newDomain.trim()}
                                                    >
                                                        Añadir dominio
                                                    </button>
                                                </div>
                                            )
                                        }

                                    </div>
                                )
                            }

                        </div>
                    ))
                }

            </div>

        </div>

    );

}


export default ContentCategories;
