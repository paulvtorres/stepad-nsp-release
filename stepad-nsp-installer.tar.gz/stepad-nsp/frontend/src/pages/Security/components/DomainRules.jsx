import { useEffect, useMemo, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getSecurityRules,
    createSecurityRule,
    deleteSecurityRule
} from "../../../services/api";

import "../security.css";

const QUICK_DOMAINS = [
    { label: "Facebook", value: "facebook.com" },
    { label: "Instagram", value: "instagram.com" },
    { label: "WhatsApp", value: "whatsapp.com" },
    { label: "TikTok", value: "tiktok.com" },
    { label: "YouTube", value: "youtube.com" },
    { label: "X (Twitter)", value: "x.com" },
    { label: "Twitch", value: "twitch.tv" },
    { label: "Netflix", value: "netflix.com" },
    { label: "Pornhub", value: "pornhub.com" },
    { label: "OnlyFans", value: "onlyfans.com" }
];

const TYPE_LABELS = {
    DOMAIN: "Dominio",
    IP: "IP",
    MAC: "MAC",
    URL: "URL",
    PORT: "Puerto"
};

const SCOPE_LABELS = {
    GLOBAL: "Toda la red",
    ZONE: "Zona",
    DEVICE: "Dispositivo"
};

const DOMAIN_PATTERN = /^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;

function normalizeDomain(raw) {
    let value = String(raw || "").trim().toLowerCase();

    if (!value) {
        return null;
    }

    value = value.replace(/^[a-z]+:\/\//, "");

    value = value.replace(/^\*\./, "");

    value = value.replace(/^www\./, "");

    value = value.split("/")[0];

    value = value.split("?")[0];

    value = value.split("#")[0];

    value = value.replace(/:[0-9]+$/, "");

    value = value.replace(/^\.+/, "");

    value = value.replace(/\.+$/, "");

    return value || null;
}

function parseDomains(raw) {
    const tokens = String(raw || "").split(/[\s,;]+/);

    const valid = [];

    const invalid = [];

    for (const token of tokens) {

        const value = normalizeDomain(token);

        if (!value) {
            continue;
        }

        if (DOMAIN_PATTERN.test(value)) {
            valid.push(value);
        }
        else {
            invalid.push(token.trim());
        }

    }

    return {
        valid: [...new Set(valid)],
        invalid: [...new Set(invalid)]
    };
}

function labelFor(value, labels) {
    return (value && labels[value]) || value || "—";
}

function DomainRules() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";


    const [domains, setDomains] = useState([]);

    const [loading, setLoading] = useState(true);

    const [adding, setAdding] = useState(false);

    const [input, setInput] = useState("");

    const [query, setQuery] = useState("");

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);


    useEffect(() => {
        loadRules();
    }, []);


    useEffect(() => {

        if (!notice) {
            return;
        }

        const timer = setTimeout(() => setNotice(null), 4000);

        return () => clearTimeout(timer);

    }, [notice]);


    async function loadRules() {

        try {

            const response = await getSecurityRules();

            setDomains(response || []);

            setError(null);

        }
        catch (error) {

            console.error("Error loading security rules", error);

            setError("No se pudo cargar la lista de dominios bloqueados.");

        }
        finally {

            setLoading(false);

        }

    }


    const parsed = useMemo(() => parseDomains(input), [input]);


    async function addDomains(values) {

        if (!values || values.length === 0) {
            return;
        }

        setAdding(true);

        setError(null);

        setNotice(null);

        let added = 0;

        let skipped = 0;

        try {

            for (const value of values) {

                const exists = domains.some(
                    rule => String(rule.value).toLowerCase() === value
                );

                if (exists) {
                    skipped += 1;
                    continue;
                }

                try {

                    await createSecurityRule(value);

                    added += 1;

                }
                catch (err) {

                    console.error(`Error creating rule for ${value}`, err);

                }

            }

            await loadRules();

            setInput("");

            if (added > 0) {

                setNotice(
                    added === 1
                        ? "Dominio bloqueado correctamente."
                        : `Se bloquearon ${added} dominios correctamente.`
                );

            }
            else if (skipped > 0) {

                setNotice("Esos dominios ya estaban bloqueados.");

            }

        }
        catch (error) {

            console.error("Error creating rules", error);

            setError("No se pudo agregar el dominio. Inténtalo de nuevo.");

        }
        finally {

            setAdding(false);

        }

    }


    async function removeDomain(rule) {

        const value = rule.value;

        if (!window.confirm(`¿Quieres dejar de bloquear "${value}"?`)) {
            return;
        }

        setError(null);

        setNotice(null);

        try {

            await deleteSecurityRule(rule.id);

            await loadRules();

            setNotice(`Se eliminó el bloqueo de "${value}".`);

        }
        catch (error) {

            console.error("Error deleting rule", error);

            setError("No se pudo eliminar el dominio. Inténtalo de nuevo.");

        }

    }


    const filteredDomains = useMemo(() => {

        const q = query.trim().toLowerCase();

        if (!q) {
            return domains;
        }

        return domains.filter(rule =>
            String(rule.value).toLowerCase().includes(q)
        );

    }, [domains, query]);


    return (

        <div className="domain-rules">

            <div className="security-header">

                <h3>
                    Bloqueo de dominios
                </h3>

            </div>


            <p className="security-description" style={{ marginTop: 0 }}>

                Escribe uno o varios dominios (separados por coma o por
                espacio) y pulsa "Bloquear". También puedes elegir un
                servicio popular de la lista rápida.

            </p>


            <div className="domain-input-row">

                {
                    isAdmin ? (
                        <>
                            <textarea
                                className="domain-input"
                                rows="2"
                                placeholder="facebook.com, tiktok.com, youtube.com ..."
                                value={input}
                                onChange={e => setInput(e.target.value)}
                                onKeyDown={e => {
                                    if (e.key === "Enter" && !e.shiftKey) {
                                        e.preventDefault();
                                        addDomains(parsed.valid);
                                    }
                                }}
                            />

                            <button
                                className="add-domain-button"
                                onClick={() => addDomains(parsed.valid)}
                                disabled={adding || parsed.valid.length === 0}
                            >

                                {adding ? "Bloqueando..." : `Bloquear${parsed.valid.length > 1 ? ` ${parsed.valid.length}` : ""}`}

                            </button>
                        </>
                    ) : (
                        <p className="domain-input-hint">
                            Vista de solo lectura: solo un administrador puede bloquear dominios.
                        </p>
                    )
                }

            </div>


            {
                parsed.invalid.length > 0 && (

                    <p className="domain-input-hint error">

                        No se pudo reconocer: {parsed.invalid.join(", ")}.

                    </p>

                )
            }


            {
                parsed.valid.length > 0 && parsed.invalid.length === 0 && (

                    <p className="domain-input-hint ok">

                        {parsed.valid.length === 1
                            ? `Se bloqueará: ${parsed.valid[0]}`
                            : `Se bloquearán ${parsed.valid.length} dominios.`}

                    </p>

                )
            }


            <div className="quick-domains">

                <span className="quick-domains-label">
                    Bloqueo rápido:
                </span>

                {
                    QUICK_DOMAINS.map(item => {

                        const already = domains.some(
                            rule => String(rule.value).toLowerCase() === item.value
                        );

                        return (

                            isAdmin && (
                                <button
                                    key={item.value}
                                    className={`quick-domain-chip ${already ? "blocked" : ""}`}
                                onClick={() => {
                                    if (already) {
                                        setNotice(`"${item.label}" ya está bloqueado.`);
                                    }
                                    else {
                                        addDomains([item.value]);
                                    }
                                }}
                                disabled={adding}
                            >

                                {item.label}

                            </button>
                            )
                        );

                    })
                }

            </div>


            {
                error && <p className="domain-rules-error">{error}</p>
            }


            {
                notice && <p className="domain-rules-notice">{notice}</p>
            }


            {
                loading && <p className="loading-message">Cargando reglas de bloqueo...</p>
            }


            {
                !loading && domains.length > 0 && (

                    <div className="domain-search-row">

                        <input
                            className="domain-search"
                            placeholder="Buscar dominio..."
                            value={query}
                            onChange={e => setQuery(e.target.value)}
                        />

                        <span className="domain-count">
                            {filteredDomains.length} de {domains.length}
                        </span>

                    </div>

                )
            }


            {
                !loading && (

                    <table className="domain-table">

                        <thead>

                            <tr>

                                <th>Dominio</th>

                                <th>Tipo</th>

                                <th>Alcance</th>

                                <th>Estado</th>

                                <th>Acción</th>

                            </tr>

                        </thead>

                        <tbody>

                            {
                                filteredDomains.length === 0 && domains.length === 0 && (

                                    <tr>

                                        <td colSpan="5" className="empty-state">

                                            Todavía no hay dominios bloqueados.
                                            Añade el primero con el formulario
                                            de arriba o elige uno de la lista rápida.

                                        </td>

                                    </tr>

                                )
                            }


                            {
                                filteredDomains.length === 0 && domains.length > 0 && (

                                    <tr>

                                        <td colSpan="5" className="empty-state">

                                            No hay resultados para "{query}".

                                        </td>

                                    </tr>

                                )
                            }


                            {
                                filteredDomains.map(rule => (

                                    <tr key={rule.id}>

                                        <td className="domain-name">

                                            {rule.value}

                                        </td>

                                        <td>
                                            {labelFor(rule.rule_type, TYPE_LABELS)}
                                        </td>

                                        <td>
                                            {labelFor(rule.scope, SCOPE_LABELS)}
                                        </td>

                                        <td>

                                            <span className={`rule-state ${rule.enabled ? "enabled" : "disabled"}`}>

                                                {rule.enabled ? "ACTIVO" : "INACTIVO"}

                                            </span>

                                        </td>

                                        <td>

                                            {
                                                isAdmin && (
                                                    <button
                                                        className="delete"
                                                        onClick={() => removeDomain(rule)}
                                                    >

                                                        Eliminar

                                                    </button>
                                                )
                                            }

                                        </td>

                                    </tr>

                                ))
                            }

                        </tbody>

                    </table>

                )
            }

        </div>

    );

}


export default DomainRules;
