import { useEffect, useState } from "react";

import { getNavigationSummary } from "../../services/api";

import "./topPages.css";


function toDateInputValue(date) {

    const y = date.getFullYear();

    const m = String(date.getMonth() + 1).padStart(2, "0");

    const d = String(date.getDate()).padStart(2, "0");

    return `${y}-${m}-${d}`;

}


function TopPages() {

    const [startDate, setStartDate] = useState(toDateInputValue(new Date()));

    const [endDate, setEndDate] = useState(toDateInputValue(new Date()));

    const [topPages, setTopPages] = useState([]);

    const [loading, setLoading] = useState(false);


    useEffect(() => {

        load();

        const timer = setInterval(load, 30000);

        return () => clearInterval(timer);

    }, [startDate, endDate]);


    async function load() {

        setLoading(true);

        try {

            const rows = await getNavigationSummary({
                start: startDate ? `${startDate}T00:00:00` : undefined,
                end: endDate ? `${endDate}T23:59:59` : undefined
            });

            const pages = Object.values(
                (rows || []).reduce((acc, r) => {

                    const domain = r.domain || "?";

                    const entry = acc[domain] || (
                        acc[domain] = {
                            domain,
                            visits: 0,
                            devices: new Set()
                        }
                    );

                    entry.visits += (r.visit_count || 0);

                    if (r.device_id) entry.devices.add(r.device_id);

                    return acc;

                }, {})
            ).map((p) => ({
                ...p,
                devices: p.devices.size,
            })).sort((a, b) => b.visits - a.visits);

            setTopPages(pages);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    return (

        <div className="toppages-container">

            <div className="toppages-header">

                <div>

                    <h2>Páginas más navegadas</h2>

                    <p>
                        Dominios más visitados en el rango de fechas seleccionado
                        (por defecto hoy), entre todos los equipos.
                    </p>

                </div>

                <div className="toppages-filters">

                    <label>
                        Desde
                        <input
                            type="date"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                        />
                    </label>

                    <label>
                        Hasta
                        <input
                            type="date"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                        />
                    </label>

                </div>

            </div>


            {
                !loading && topPages.length === 0 ? (
                    <p className="toppages-empty">Sin actividad en el rango seleccionado.</p>
                ) : (
                    <table className="toppages-table">

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Página (dominio)</th>
                                <th>Visitas</th>
                                <th>Equipos</th>
                            </tr>
                        </thead>

                        <tbody>

                            {
                                topPages.map((page, index) => (
                                    <tr key={page.domain}>

                                        <td>{index + 1}</td>

                                        <td className="toppages-domain">
                                            {page.domain}
                                        </td>

                                        <td>{page.visits.toLocaleString()}</td>

                                        <td>{page.devices}</td>

                                    </tr>
                                ))
                            }

                        </tbody>

                    </table>
                )
            }

        </div>

    );

}


export default TopPages;
