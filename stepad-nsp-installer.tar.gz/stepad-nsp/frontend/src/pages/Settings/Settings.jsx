import { useEffect, useRef, useState } from "react";

import ModulesSection from "./components/ModulesSection";

import {
    getTemporaryLanIpStatus,
    startTemporaryLanIp,
    revertTemporaryLanIp,
    mfaSetup,
    mfaConfirm,
    mfaDisable,
    getPortForwards,
    createPortForward,
    deletePortForward,
    getNotificationSettings,
    saveNotificationSettings,
    testNotification,
    sendNotificationNow,
    getBackupSettings,
    saveBackupSettings,
    getBackups,
    createBackup,
    downloadBackup,
    deleteBackup,
    uploadBackup,
    restoreBackup,
    getOrganizationSettings,
    saveOrganizationSettings,
    getSystemVersion,
    getSyslogSettings,
    saveSyslogSettings,
    testSyslog,
    getComplianceRetention,
    saveComplianceRetention,
    getLogsReview,
    saveLogsReview,
    markLogsReview,
    getConfigRevisions,
    captureConfigRevision,
    restoreConfigRevision,
    getUpdateStatus,
    runUpdate,
    getRemoteAdmin,
    setRemoteAdmin,
    getCloudSettings,
    saveCloudSettings,
    testCloudConnection,
    uploadCloudLogs,
    getDomainGroups,
    createDomainGroup,
    deleteDomainGroup,
    addDomainGroupDomain,
    removeDomainGroupDomain,
} from "../../services/api";

import { useAuth } from "../../auth/useAuth";

import "./settings.css";


function formatRemaining(seconds) {

    const minutes = Math.floor(seconds / 60);

    const secs = seconds % 60;

    return `${minutes}:${secs.toString().padStart(2, "0")}`;

}


function NetworkMaintenance() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState({ active: false });

    const [temporaryIp, setTemporaryIp] = useState("192.168.0.100");

    const [temporaryPrefix, setTemporaryPrefix] = useState(24);

    const [durationMinutes, setDurationMinutes] = useState(10);

    const [showConfirm, setShowConfirm] = useState(false);

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);

    const [cloudForm, setCloudForm] = useState({
        enabled: false,
        provider: "s3",
        endpoint: "",
        bucket: "",
        remote_path: "",
        host: "",
        user: "",
        access_key: "",
        secret_key: "",
        password: "",
        upload_hour: 3,
        upload_minute: 30,
        upload_days: 1
    });

    const [cloudMsg, setCloudMsg] = useState(null);

    const [cloudBusy, setCloudBusy] = useState(false);

    const pollRef = useRef(null);


    useEffect(() => {

        loadStatus();

        pollRef.current = setInterval(loadStatus, 5000);

        return () => clearInterval(pollRef.current);

    }, []);


    async function loadStatus() {

        try {

            const data = await getTemporaryLanIpStatus();

            setStatus(data);

        } catch (err) {

            console.error(err);

        }

    }


    async function handleConfirmStart() {

        setBusy(true);

        setError(null);

        try {

            await startTemporaryLanIp({
                temporary_ip: temporaryIp,
                temporary_prefix: Number(temporaryPrefix),
                duration_minutes: Number(durationMinutes)
            });

            setShowConfirm(false);

            await loadStatus();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRevertNow() {

        setBusy(true);

        setError(null);

        try {

            await revertTemporaryLanIp();

            await loadStatus();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Cambio temporal de IP LAN</h3>

            <p className="maintenance-hint">
                Cambia temporalmente la IP LAN del NSP para poder llegar a
                dispositivos que viven en otra subred -- por ejemplo, la
                IP de gestión por defecto de un switch (habitualmente
                distinta a tu red real). Uso típico: acceder al switch
                administrable para reconfigurarlo.
            </p>

            <div className="maintenance-warning">
                ⚠️ Mientras esté activo, <strong>toda la red se queda sin
                DHCP/DNS</strong> -- ningún dispositivo va a poder navegar
                hasta que termine el tiempo o lo reviertas manualmente.
                Avisa a los usuarios antes de activarlo.
            </div>

            {
                error && (
                    <div className="maintenance-error">
                        {error}
                    </div>
                )
            }

            {
                status.active ? (

                    <div className="maintenance-active">

                        <div className="countdown">

                            <span className="countdown-label">
                                Activo -- revierte en
                            </span>

                            <span className="countdown-time">
                                {formatRemaining(status.remaining_seconds)}
                            </span>

                        </div>

                        <div className="maintenance-active-details">
                            <div>
                                IP temporal: <strong>{status.temporary_ip}/{status.temporary_prefix}</strong>
                            </div>
                            <div>
                                Volverá a: <strong>{status.original_ip}/{status.original_prefix}</strong>
                            </div>
                        </div>

                        {
                            isAdmin && (
                                <button
                                    className="danger-button"
                                    onClick={handleRevertNow}
                                    disabled={busy}
                                >
                                    Revertir ahora
                                </button>
                            )
                        }

                    </div>

                ) : (

                    <div className="maintenance-form">

                        <div className="maintenance-form-grid">

                            <label>
                                IP temporal
                                <input
                                    type="text"
                                    value={temporaryIp}
                                    onChange={(e) => setTemporaryIp(e.target.value)}
                                    placeholder="ej. 192.168.0.100"
                                />
                            </label>

                            <label>
                                Prefijo (CIDR)
                                <input
                                    type="number"
                                    value={temporaryPrefix}
                                    onChange={(e) => setTemporaryPrefix(e.target.value)}
                                    min={8}
                                    max={30}
                                />
                            </label>

                            <label>
                                Duración (minutos, máx. 15)
                                <input
                                    type="number"
                                    value={durationMinutes}
                                    onChange={(e) => setDurationMinutes(e.target.value)}
                                    min={1}
                                    max={15}
                                />
                            </label>

                        </div>

                        {
                            isAdmin && (
                                <button
                                    className="primary-button"
                                    onClick={() => setShowConfirm(true)}
                                    disabled={!temporaryIp || busy}
                                >
                                    Activar cambio temporal
                                </button>
                            )
                        }

                    </div>

                )
            }

            {
                showConfirm && (

                    <div className="confirm-overlay">

                        <div className="confirm-dialog">

                            <h4>¿Confirmas el cambio?</h4>

                            <p>
                                La red va a quedar <strong>sin internet</strong> por
                                hasta <strong>{durationMinutes} minutos</strong>. La IP
                                LAN pasará de su valor actual a{" "}
                                <strong>{temporaryIp}/{temporaryPrefix}</strong>.
                            </p>

                            <p>
                                Se revierte sola al cumplirse el tiempo, incluso si
                                cierras esta pantalla o el backend se reinicia.
                            </p>

                            <div className="confirm-actions">

                                <button
                                    className="secondary-button"
                                    onClick={() => setShowConfirm(false)}
                                    disabled={busy}
                                >
                                    Cancelar
                                </button>

                                <button
                                    className="danger-button"
                                    onClick={handleConfirmStart}
                                    disabled={busy}
                                >
                                    {busy ? "Aplicando..." : "Sí, cortar la red y continuar"}
                                </button>

                            </div>

                        </div>

                    </div>

                )
            }

        </div>

    );

}


function MfaSection() {

    const { mfaEnabled, setMfaEnabled, mfaMandatory, user, setMfaSetupRequired } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const mfaBlocked = mfaMandatory && isAdmin;

    const [setup, setSetup] = useState(null);

    const [code, setCode] = useState("");

    const [currentPassword, setCurrentPassword] = useState("");

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);


    async function handleSetup() {

        setError(null);

        setBusy(true);

        try {

            const data = await mfaSetup();

            setSetup(data);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleConfirm() {

        setError(null);

        setBusy(true);

        try {

            await mfaConfirm(code.trim());

            setMfaEnabled(true);

            setMfaSetupRequired(false);

            setSetup(null);

            setCode("");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDisable() {

        setError(null);

        setBusy(true);

        try {

            await mfaDisable(currentPassword);

            setMfaEnabled(false);

            setCurrentPassword("");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Autenticación en dos pasos (MFA)</h3>

            <p className="maintenance-hint">

                Añade una segunda verificación con una app de autenticación

                (Google Authenticator, Authy, etc.) al iniciar sesión.

            </p>

            {error && (
                <div className="maintenance-error">
                    {error}
                </div>
            )}

            {mfaEnabled ? (

                <div className="mfa-active">

                    {
                        mfaBlocked && (
                            <p className="maintenance-warning">
                                <strong>MFA es obligatoria</strong> para las
                                cuentas de administrador: no puedes desactivarla.
                            </p>
                        )
                    }

                    <p>
                        <strong>MFA activada</strong> para{" "}
                        {user?.username}.
                    </p>

                    <label>
                        Contraseña actual para desactivar
                        <input
                            type="password"
                            value={currentPassword}
                            onChange={(e) =>
                                setCurrentPassword(e.target.value)
                            }
                            placeholder="••••••••"
                        />
                    </label>

                    <button
                        className="danger-button"
                        onClick={handleDisable}
                        disabled={busy || !currentPassword || mfaBlocked}
                    >
                        {busy ? "Desactivando..." : "Desactivar MFA"}
                    </button>

                </div>

            ) : setup ? (

                <div className="mfa-setup">

                    <p>
                        Escanea o introduce esta clave en tu app de
                        autenticación:
                    </p>

                    <div className="mfa-secret">
                        {setup.secret}
                    </div>

                    <details>

                        <summary>URI manual</summary>

                        <code>{setup.otpauth_uri}</code>

                    </details>

                    <label>
                        Código de verificación
                        <input
                            type="text"
                            inputMode="numeric"
                            value={code}
                            onChange={(e) => setCode(e.target.value)}
                            placeholder="123456"
                        />
                    </label>

                    <div className="confirm-actions">

                        <button
                            className="secondary-button"
                            onClick={() => setSetup(null)}
                            disabled={busy}
                        >
                            Cancelar
                        </button>

                        <button
                            className="primary-button"
                            onClick={handleConfirm}
                            disabled={busy || !code}
                        >
                            {busy ? "Verificando..." : "Confirmar y activar"}
                        </button>

                    </div>

                </div>

            ) : (

                <button
                    className="primary-button"
                    onClick={handleSetup}
                    disabled={busy}
                >
                    Activar MFA
                </button>

            )}

        </div>

    );

}


function PortForwardSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [forwards, setForwards] = useState([]);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);

    const [form, setForm] = useState({
        name: "",
        protocol: "tcp",
        external_port: "",
        internal_ip: "",
        internal_port: "",
        wan_interface: ""
    });


    async function load() {

        try {

            const data = await getPortForwards();

            setForwards(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        let cancelled = false;

        getPortForwards()

            .then((data) => {
                if (!cancelled) setForwards(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        getCloudSettings()

            .then((data) => {
                if (cancelled) return;
                setCloudForm({
                    enabled: data.enabled,
                    provider: data.provider,
                    endpoint: data.endpoint || "",
                    bucket: data.bucket || "",
                    remote_path: data.remote_path || "",
                    host: data.host || "",
                    user: data.user || "",
                    access_key: "",
                    secret_key: "",
                    password: "",
                    upload_hour: data.upload_hour,
                    upload_minute: data.upload_minute,
                    upload_days: data.upload_days
                });
            })

            .catch(() => {});

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleCreate() {

        setError(null);

        setBusy(true);

        try {

            await createPortForward({
                name: form.name,
                protocol: form.protocol,
                external_port: Number(form.external_port),
                internal_ip: form.internal_ip,
                internal_port: Number(form.internal_port),
                wan_interface: form.wan_interface.trim() || null,
                enabled: true
            });

            setForm({
                name: "",
                protocol: "tcp",
                external_port: "",
                internal_ip: "",
                internal_port: "",
                wan_interface: ""
            });

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDelete(id) {

        setError(null);

        setBusy(true);

        try {

            await deletePortForward(id);

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Reenvío de puertos (DMZ)</h3>

            <p className="maintenance-hint">

                Publica servicios de Internet hacia equipos de una zona
                (p. ej. una DMZ) redirigiendo un puerto del WAN a la IP
                interna de un host.

            </p>

            {error && (
                <div className="maintenance-error">
                    {error}
                </div>
            )}

            <ul className="schedules-list">

                {
                    loading && (
                        <li>Cargando reenvíos...</li>
                    )
                }

                {
                    !loading && forwards.length === 0 && (
                        <li>No hay reenvíos de puertos configurados.</li>
                    )
                }

                {
                    forwards.map((f) => (
                        <li key={f.id}>

                            <span>
                                <strong>{f.name}</strong>{" "}
                                — {f.protocol === "both" ? "TCP+UDP" : f.protocol.toUpperCase()}{" "}
                                {f.wan_interface ? `[${f.wan_interface}]` : "[todas las WAN]"}{" "}
                                {f.external_port} → {f.internal_ip}:{f.internal_port}
                                {" "}
                                <span className={`rule-state ${f.enabled ? "enabled" : "disabled"}`}>
                                    {f.enabled ? "ACTIVO" : "INACTIVO"}
                                </span>
                            </span>

                            {
                                isAdmin && (
                                    <button
                                        className="danger-button"
                                        onClick={() => handleDelete(f.id)}
                                        disabled={busy}
                                    >
                                        Eliminar
                                    </button>
                                )
                            }

                        </li>
                    ))
                }

            </ul>

            {
                isAdmin && (
                    <div className="schedule-form">

                        <input
                            type="text"
                            placeholder="Nombre (ej. servidor web DMZ)"
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                        />

                        <div className="schedule-row">

                            <label>
                                Protocolo
                                <select
                                    value={form.protocol}
                                    onChange={(e) => setForm({ ...form, protocol: e.target.value })}
                                >
                                    <option value="tcp">TCP</option>
                                    <option value="udp">UDP</option>
                                    <option value="both">TCP + UDP</option>
                                </select>
                            </label>

                            <label>
                                Puerto externo (WAN)
                                <input
                                    type="number"
                                    value={form.external_port}
                                    onChange={(e) => setForm({ ...form, external_port: e.target.value })}
                                    placeholder="ej. 443"
                                />
                            </label>

                        </div>

                        <div className="schedule-row">

                            <label>
                                IP interna del host
                                <input
                                    type="text"
                                    value={form.internal_ip}
                                    onChange={(e) => setForm({ ...form, internal_ip: e.target.value })}
                                    placeholder="ej. 192.168.60.10"
                                />
                            </label>

                            <label>
                                Puerto interno
                                <input
                                    type="number"
                                    value={form.internal_port}
                                    onChange={(e) => setForm({ ...form, internal_port: e.target.value })}
                                    placeholder="ej. 443"
                                />
                            </label>

                        </div>

                        <label>
                            Interfaz WAN (vacío = todas)
                            <input
                                type="text"
                                value={form.wan_interface}
                                onChange={(e) => setForm({ ...form, wan_interface: e.target.value })}
                                placeholder="ej. enp37s0 (opcional)"
                            />
                        </label>

                        <button
                            className="primary-button"
                            onClick={handleCreate}
                            disabled={
                                busy
                                || !form.name
                                || !form.external_port
                                || !form.internal_ip
                                || !form.internal_port
                            }
                        >
                            Añadir reenvío
                        </button>

                    </div>
                )
            }

        </div>

    );

}


function NotificationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        enabled: false,
        smtp_host: "",
        smtp_port: 587,
        smtp_user: "",
        smtp_password: "",
        from_email: "",
        to_emails: "",
        frequency: "daily",
        send_hour: 8,
        send_minute: 0
    });

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getNotificationSettings()

            .then((data) => {
                if (cancelled) return;
                setForm({
                    enabled: data.enabled,
                    smtp_host: data.smtp_host || "",
                    smtp_port: data.smtp_port || 587,
                    smtp_user: data.smtp_user || "",
                    smtp_password: "",
                    from_email: data.from_email || "",
                    to_emails: data.to_emails || "",
                    frequency: data.frequency || "daily",
                    send_hour: data.send_hour,
                    send_minute: data.send_minute
                });
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleCloudSave() {

        setError(null);
        setNotice(null);
        setCloudMsg(null);
        setCloudBusy(true);

        try {

            const payload = {
                enabled: cloudForm.enabled,
                provider: cloudForm.provider,
                endpoint: cloudForm.endpoint || null,
                bucket: cloudForm.bucket || null,
                remote_path: cloudForm.remote_path || null,
                host: cloudForm.host || null,
                user: cloudForm.user || null,
                upload_hour: Number(cloudForm.upload_hour),
                upload_minute: Number(cloudForm.upload_minute),
                upload_days: Number(cloudForm.upload_days)
            };

            if (cloudForm.access_key) payload.access_key = cloudForm.access_key;
            if (cloudForm.secret_key) payload.secret_key = cloudForm.secret_key;
            if (cloudForm.password) payload.password = cloudForm.password;

            await saveCloudSettings(payload);

            setCloudMsg("Configuración de nube guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setCloudBusy(false);

        }

    }


    async function handleCloudTest() {

        setError(null);
        setCloudMsg(null);
        setCloudBusy(true);

        try {

            const res = await testCloudConnection();

            setCloudMsg(res.message || (res.success ? "Conexión correcta." : "Error de conexión."));

        } catch (err) {

            setError(err.message);

        } finally {

            setCloudBusy(false);

        }

    }


    async function handleCloudUpload() {

        setError(null);
        setCloudMsg(null);
        setCloudBusy(true);

        try {

            const res = await uploadCloudLogs();

            setCloudMsg(res.message || "Subida completada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setCloudBusy(false);

        }

    }


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveNotificationSettings({
                enabled: form.enabled,
                smtp_host: form.smtp_host,
                smtp_port: Number(form.smtp_port),
                smtp_user: form.smtp_user,
                smtp_password: form.smtp_password || null,
                from_email: form.from_email,
                to_emails: form.to_emails,
                frequency: form.frequency,
                send_hour: Number(form.send_hour),
                send_minute: Number(form.send_minute)
            });

            setForm((previous) => ({
                ...previous,
                smtp_password: "",
                enabled: saved.enabled
            }));

            setNotice("Configuración de notificaciones guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleTest() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await testNotification();

            setNotice(result.message || "Correo de prueba enviado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSendNow() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await sendNotificationNow();

            setNotice(result.message || "Resumen enviado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Notificaciones por correo</h3>

            <p className="maintenance-hint">

                Envía el resumen de navegación (y alertas importantes)
                por correo de forma automática y periódica.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            <div className="vpn-form">

                <label className="checkbox-label">
                    <input
                        type="checkbox"
                        checked={form.enabled}
                        onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                    />
                    Notificaciones habilitadas
                </label>

                <div className="schedule-row">

                    <label>
                        Servidor SMTP
                        <input
                            type="text"
                            value={form.smtp_host}
                            onChange={(e) => setForm({ ...form, smtp_host: e.target.value })}
                            placeholder="ej. smtp.gmail.com"
                        />
                    </label>

                    <label>
                        Puerto
                        <input
                            type="number"
                            value={form.smtp_port}
                            onChange={(e) => setForm({ ...form, smtp_port: e.target.value })}
                            placeholder="587"
                        />
                    </label>

                </div>

                <div className="schedule-row">

                    <label>
                        Usuario SMTP (opcional)
                        <input
                            type="text"
                            value={form.smtp_user}
                            onChange={(e) => setForm({ ...form, smtp_user: e.target.value })}
                            placeholder="ej. notificaciones@empresa.com"
                        />
                    </label>

                    <label>
                        Contraseña SMTP
                        <input
                            type="password"
                            value={form.smtp_password}
                            onChange={(e) => setForm({ ...form, smtp_password: e.target.value })}
                            placeholder="•••••••• (vacío = no cambiar)"
                        />
                    </label>

                </div>

                <div className="schedule-row">

                    <label>
                        Correo remitente
                        <input
                            type="text"
                            value={form.from_email}
                            onChange={(e) => setForm({ ...form, from_email: e.target.value })}
                            placeholder="ej. nsp@empresa.com"
                        />
                    </label>

                    <label>
                        Destinatarios (separados por coma)
                        <input
                            type="text"
                            value={form.to_emails}
                            onChange={(e) => setForm({ ...form, to_emails: e.target.value })}
                            placeholder="ej. jefe@empresa.com, it@empresa.com"
                        />
                    </label>

                </div>

                <div className="schedule-row">

                    <label>
                        Frecuencia
                        <select
                            value={form.frequency}
                            onChange={(e) => setForm({ ...form, frequency: e.target.value })}
                        >
                            <option value="daily">Diaria</option>
                            <option value="weekly">Semanal</option>
                            <option value="monthly">Mensual</option>
                        </select>
                    </label>

                    <label>
                        Hora de envío
                        <input
                            type="time"
                            value={`${String(form.send_hour).padStart(2, "0")}:${String(form.send_minute).padStart(2, "0")}`}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setForm({ ...form, send_hour: Number(h), send_minute: Number(m) });
                            }}
                        />
                    </label>

                </div>

                <div className="confirm-actions">

                    <button
                        className="primary-button"
                        onClick={handleSave}
                        disabled={busy || !isAdmin}
                    >
                        {busy ? "Guardando..." : "Guardar configuración"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleTest}
                        disabled={busy || !isAdmin}
                    >
                        Enviar prueba
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleSendNow}
                        disabled={busy || !isAdmin}
                    >
                        Enviar resumen ahora
                    </button>

                </div>

            </div>

        </div>

    );

}


function DomainGroupsSection() {

    const [groups, setGroups] = useState([]);

    const [newName, setNewName] = useState("");

    const [newDomain, setNewDomain] = useState("");

    const [busy, setBusy] = useState(false);

    const [msg, setMsg] = useState(null);

    async function load() {

        try {

            setGroups(await getDomainGroups() || []);

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        }
    }

    useEffect(() => { load(); }, []);

    async function handleCreateGroup() {

        if (!newName.trim()) return;

        setBusy(true);

        try {

            await createDomainGroup(newName.trim());

            setNewName("");

            await load();

            setMsg("Grupo creado.");

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }
    }

    async function handleAddDomain(groupId) {

        if (!newDomain.trim()) return;

        setBusy(true);

        try {

            await addDomainGroupDomain(groupId, newDomain.trim());

            setNewDomain("");

            await load();

            setMsg("Dominio agregado.");

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }
    }

    async function handleRemoveDomain(groupId, domain) {

        if (!window.confirm(`¿Quitar ${domain} del grupo?`)) return;

        setBusy(true);

        try {

            await removeDomainGroupDomain(groupId, domain);

            await load();

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }
    }

    async function handleDeleteGroup(id, name) {

        if (!window.confirm(`¿Eliminar el grupo "${name}"?`)) return;

        setBusy(true);

        try {

            await deleteDomainGroup(id);

            await load();

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }
    }

    return (

        <div className="maintenance-panel">

            <h3>Grupos de dominios (padre → hijos)</h3>

            <p className="maintenance-hint">
                Al bloquear un dominio que pertenece a uno de estos grupos, se
                agregan automáticamente todos sus dominios. Agrégale los dominios
                nuevos que descubras (ej. un CDN que usa YouTube).
            </p>

            {msg && (
                <div className="notification-ok">{msg}</div>
            )}

            <div className="vpn-form" style={{ maxWidth: "100%" }}>

                <div className="schedule-row">
                    <label>
                        Nuevo grupo (ej. "HBO Max")
                        <input
                            type="text"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            placeholder="Nombre del grupo"
                        />
                    </label>
                    <button className="primary-button" onClick={handleCreateGroup} disabled={busy}>
                        Crear grupo
                    </button>
                </div>

                {groups.map((g) => (
                    <div key={g.id} className="vpn-form" style={{ maxWidth: "100%", border: "1px solid var(--border)", borderRadius: 8, padding: 12 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
                            <strong>{g.name}</strong>
                            <button className="secondary-button" onClick={() => handleDeleteGroup(g.id, g.name)} disabled={busy}>
                                Eliminar
                            </button>
                        </div>

                        {g.description && (
                            <p className="maintenance-hint">{g.description}</p>
                        )}

                        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, margin: "8px 0" }}>
                            {g.domains.map((d) => (
                                <span
                                    key={d}
                                    style={{
                                        background: "var(--panel-2)",
                                        border: "1px solid var(--border)",
                                        borderRadius: 6,
                                        padding: "2px 8px",
                                        fontSize: 12,
                                    }}
                                >
                                    {d}{" "}
                                    <button
                                        style={{ background: "none", border: "none", cursor: "pointer", color: "var(--danger)" }}
                                        onClick={() => handleRemoveDomain(g.id, d)}
                                        title="Quitar dominio"
                                    >
                                        ✕
                                    </button>
                                </span>
                            ))}
                            {g.domains.length === 0 && (
                                <span className="maintenance-hint">Sin dominios todavía.</span>
                            )}
                        </div>

                        <div className="schedule-row">
                            <input
                                type="text"
                                placeholder="agregar dominio (ej. cdn.hbo.com)"
                                value={newDomain}
                                onChange={(e) => setNewDomain(e.target.value)}
                                onKeyDown={(e) => { if (e.key === "Enter") handleAddDomain(g.id); }}
                            />
                            <button className="secondary-button" onClick={() => handleAddDomain(g.id)} disabled={busy}>
                                Agregar
                            </button>
                        </div>
                    </div>
                ))}

            </div>

        </div>
    );
}


function BackupSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        enabled: false,
        send_hour: 3,
        send_minute: 0,
        retention_count: 7,
        email_backup: false
    });

    const [backups, setBackups] = useState([]);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getBackupSettings()

            .then((data) => {
                if (cancelled) return;
                setForm({
                    enabled: data.enabled,
                    send_hour: data.send_hour,
                    send_minute: data.send_minute,
                    retention_count: data.retention_count,
                    email_backup: data.email_backup
                });
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        getBackups()

            .then((data) => {
                if (!cancelled) setBackups(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await saveBackupSettings({
                enabled: form.enabled,
                send_hour: Number(form.send_hour),
                send_minute: Number(form.send_minute),
                retention_count: Number(form.retention_count),
                email_backup: form.email_backup
            });

            setNotice("Configuración de copias guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleCreate() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await createBackup();

            if (result.success) {

                setNotice(`Copia creada: ${result.filename}`);

                const data = await getBackups();

                setBackups(data || []);

            } else {

                setError(result.message || "No se pudo crear la copia.");

            }

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDownload(filename) {

        try {

            const blob = await downloadBackup(filename);

            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");

            link.href = url;

            link.download = filename;

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        } catch (err) {

            setError(err.message);

        }

    }


    async function handleUpload(event) {

        const file = event.target.files && event.target.files[0];

        if (!file) return;

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await uploadBackup(file);

            setNotice(result.message || "Respaldo subido.");

            const data = await getBackups();

            setBackups(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

            event.target.value = "";

        }

    }


    async function handleRestore(filename) {

        const ok = window.confirm(
            `¿Restaurar el respaldo "${filename}"?\n\n` +
            "Se reemplazará la configuración y la base de datos actuales " +
            "por las del respaldo y el servicio se reiniciará."
        );

        if (!ok) return;

        setBusy(true);

        try {

            const result = await restoreBackup(filename);

            setNotice(result.message || "Restaurando...");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDelete(filename) {

        setError(null);

        setBusy(true);

        try {

            await deleteBackup(filename);

            const data = await getBackups();

            setBackups(data || []);

            setNotice("Copia eliminada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Copias de seguridad</h3>

            <p className="maintenance-hint">

                Genera automáticamente una copia de la configuración y
                la base de datos (para recuperación ante desastres) en
                el horario indicado.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            <div className="vpn-form">

                <label className="checkbox-label">
                    <input
                        type="checkbox"
                        checked={form.enabled}
                        onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                    />
                    Copias automáticas habilitadas
                </label>

                <label className="checkbox-label">
                    <input
                        type="checkbox"
                        checked={form.email_backup}
                        onChange={(e) => setForm({ ...form, email_backup: e.target.checked })}
                    />
                    Enviar respaldo cifrado por email (fuera del sitio)
                </label>

                <div className="schedule-row">

                    <label>
                        Hora de la copia
                        <input
                            type="time"
                            value={`${String(form.send_hour).padStart(2, "0")}:${String(form.send_minute).padStart(2, "0")}`}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setForm({ ...form, send_hour: Number(h), send_minute: Number(m) });
                            }}
                        />
                    </label>

                    <label>
                        Conservar (nº de copias)
                        <input
                            type="number"
                            value={form.retention_count}
                            onChange={(e) => setForm({ ...form, retention_count: e.target.value })}
                            min={1}
                            max={60}
                        />
                    </label>

                </div>

                <div className="confirm-actions">

                    <button
                        className="primary-button"
                        onClick={handleSave}
                        disabled={busy || !isAdmin}
                    >
                        {busy ? "Guardando..." : "Guardar configuración"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleCreate}
                        disabled={busy || !isAdmin}
                    >
                        Generar copia ahora
                    </button>

                </div>

            </div>

            <h3>Respaldo de logs en la nube</h3>

            <p className="maintenance-hint">
                Sube diariamente los logs (auditoría, alertas, Suricata) cifrados
                al almacenamiento en la nube del cliente (S3-compatible, SFTP o
                WebDAV) mediante rclone.
            </p>

            {cloudMsg && (
                <div className="notification-ok">{cloudMsg}</div>
            )}

            <div className="vpn-form">

                <label className="checkbox-label">
                    <input
                        type="checkbox"
                        checked={cloudForm.enabled}
                        onChange={(e) => setCloudForm({ ...cloudForm, enabled: e.target.checked })}
                    />
                    Subida automática habilitada
                </label>

                <label>
                    Proveedor
                    <select
                        value={cloudForm.provider}
                        onChange={(e) => setCloudForm({ ...cloudForm, provider: e.target.value })}
                    >
                        <option value="s3">S3-compatible (B2, Wasabi, R2, MinIO...)</option>
                        <option value="sftp">SFTP</option>
                        <option value="webdav">WebDAV</option>
                    </select>
                </label>

                {cloudForm.provider === "s3" ? (
                    <>
                        <label>
                            Endpoint (URL del servicio S3)
                            <input
                                type="text"
                                value={cloudForm.endpoint}
                                placeholder="https://s3.us-west-004.backblazeb2.com"
                                onChange={(e) => setCloudForm({ ...cloudForm, endpoint: e.target.value })}
                            />
                        </label>
                        <label>
                            Bucket
                            <input
                                type="text"
                                value={cloudForm.bucket}
                                placeholder="nombre-del-bucket"
                                onChange={(e) => setCloudForm({ ...cloudForm, bucket: e.target.value })}
                            />
                        </label>
                        <label>
                            Access Key ID
                            <input
                                type="text"
                                value={cloudForm.access_key}
                                placeholder="dejar vacío para conservar la actual"
                                onChange={(e) => setCloudForm({ ...cloudForm, access_key: e.target.value })}
                            />
                        </label>
                        <label>
                            Secret Access Key
                            <input
                                type="password"
                                value={cloudForm.secret_key}
                                placeholder="dejar vacío para conservar la actual"
                                onChange={(e) => setCloudForm({ ...cloudForm, secret_key: e.target.value })}
                            />
                        </label>
                    </>
                ) : (
                    <>
                        <label>
                            {cloudForm.provider === "sftp" ? "Servidor SFTP (host)" : "URL WebDAV"}
                            <input
                                type="text"
                                value={cloudForm.host}
                                placeholder="servidor.ejemplo.com"
                                onChange={(e) => setCloudForm({ ...cloudForm, host: e.target.value })}
                            />
                        </label>
                        <label>
                            Usuario
                            <input
                                type="text"
                                value={cloudForm.user}
                                onChange={(e) => setCloudForm({ ...cloudForm, user: e.target.value })}
                            />
                        </label>
                        <label>
                            Contraseña
                            <input
                                type="password"
                                value={cloudForm.password}
                                placeholder="dejar vacío para conservar la actual"
                                onChange={(e) => setCloudForm({ ...cloudForm, password: e.target.value })}
                            />
                        </label>
                    </>
                )}

                <label>
                    Carpeta remota (opcional)
                    <input
                        type="text"
                        value={cloudForm.remote_path}
                        placeholder="logs"
                        onChange={(e) => setCloudForm({ ...cloudForm, remote_path: e.target.value })}
                    />
                </label>

                <div className="schedule-row">
                    <label>
                        Hora de subida
                        <input
                            type="time"
                            value={`${String(cloudForm.upload_hour).padStart(2, "0")}:${String(cloudForm.upload_minute).padStart(2, "0")}`}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setCloudForm({ ...cloudForm, upload_hour: Number(h), upload_minute: Number(m) });
                            }}
                        />
                    </label>
                    <label>
                        Días a subir por vez
                        <input
                            type="number"
                            value={cloudForm.upload_days}
                            min={1}
                            max={7}
                            onChange={(e) => setCloudForm({ ...cloudForm, upload_days: e.target.value })}
                        />
                    </label>
                </div>

                <div className="confirm-actions">
                    <button className="primary-button" onClick={handleCloudSave} disabled={cloudBusy || !isAdmin}>
                        {cloudBusy ? "Guardando..." : "Guardar nube"}
                    </button>
                    <button className="secondary-button" onClick={handleCloudTest} disabled={cloudBusy || !isAdmin}>
                        Probar conexión
                    </button>
                    <button className="secondary-button" onClick={handleCloudUpload} disabled={cloudBusy || !isAdmin}>
                        Subir logs ahora
                    </button>
                </div>

            </div>

            <h3>Subir respaldo (cambio de equipo)</h3>

            <p className="maintenance-hint">
                Restaura en este equipo la configuración y base de datos desde
                un respaldo cifrado (.enc). Ideal para cambiar de máquina.
            </p>

            {
                isAdmin && (
                    <div className="confirm-actions" style={{ marginBottom: 16 }}>
                        <input
                            type="file"
                            accept=".enc"
                            onChange={handleUpload}
                            disabled={busy}
                        />
                    </div>
                )
            }

            <h3>Copia creadas</h3>

            {
                backups.length === 0 ? (
                    <p className="vpn-empty">Aún no hay copias de seguridad.</p>
                ) : (
                    <table className="vpn-table">

                        <thead>
                            <tr>
                                <th>Archivo</th>
                                <th>Tamaño</th>
                                <th>Fecha</th>
                                {isAdmin && <th>Acciones</th>}
                            </tr>
                        </thead>

                        <tbody>

                            {
                                backups.map((backup) => (
                                    <tr key={backup.name}>

                                        <td className="vpn-code">{backup.name}</td>

                                        <td>{(backup.size / 1024 / 1024).toFixed(2)} MB</td>

                                        <td>{new Date(backup.modified).toLocaleString("es-ES")}</td>

                                        {
                                            isAdmin && (
                                                <td>
                                                    <button
                                                        className="secondary-button small"
                                                        onClick={() => handleDownload(backup.name)}
                                                    >
                                                        Descargar
                                                    </button>
                                                    <button
                                                        className="primary-button small"
                                                        onClick={() => handleRestore(backup.name)}
                                                        disabled={busy}
                                                    >
                                                        Restaurar
                                                    </button>
                                                    <button
                                                        className="danger-button small"
                                                        onClick={() => handleDelete(backup.name)}
                                                        disabled={busy}
                                                    >
                                                        Eliminar
                                                    </button>
                                                </td>
                                            )
                                        }

                                    </tr>
                                ))
                            }

                        </tbody>

                    </table>
                )
            }

        </div>

    );

}


function OrganizationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        company_name: "",
        ruc: "",
        address: "",
        phone: "",
        email: "",
        city: "",
        country: ""
    });

    const [version, setVersion] = useState(null);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getOrganizationSettings()

            .then((data) => {
                if (cancelled) return;
                setForm({
                    company_name: data.company_name || "",
                    ruc: data.ruc || "",
                    address: data.address || "",
                    phone: data.phone || "",
                    email: data.email || "",
                    city: data.city || "",
                    country: data.country || ""
                });
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        getSystemVersion()

            .then((data) => {
                if (!cancelled) setVersion(data);
            })

            .catch(() => {});

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await saveOrganizationSettings(form);

            setNotice("Datos de la empresa guardados.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Datos de la empresa</h3>

            <p className="maintenance-hint">

                Estos datos se usan en los reportes exportados (Excel),
                los correos y cualquier documentación. Configúralos en la
                primera puesta en marcha.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            <div className="vpn-form">

                <div className="schedule-row">

                    <label>
                        Nombre de la empresa
                        <input
                            type="text"
                            value={form.company_name}
                            onChange={(e) => setForm({ ...form, company_name: e.target.value })}
                            placeholder="ej. Mi Empresa S.A.C."
                        />
                    </label>

                    <label>
                        RUC
                        <input
                            type="text"
                            value={form.ruc}
                            onChange={(e) => setForm({ ...form, ruc: e.target.value })}
                            placeholder="ej. 20123456789"
                        />
                    </label>

                </div>

                <label>
                    Dirección
                    <input
                        type="text"
                        value={form.address}
                        onChange={(e) => setForm({ ...form, address: e.target.value })}
                        placeholder="ej. Av. Principal 123"
                    />
                </label>

                <div className="schedule-row">

                    <label>
                        Teléfono
                        <input
                            type="text"
                            value={form.phone}
                            onChange={(e) => setForm({ ...form, phone: e.target.value })}
                            placeholder="ej. +51 999 999 999"
                        />
                    </label>

                    <label>
                        Correo de contacto
                        <input
                            type="text"
                            value={form.email}
                            onChange={(e) => setForm({ ...form, email: e.target.value })}
                            placeholder="ej. contacto@empresa.com"
                        />
                    </label>

                </div>

                <div className="schedule-row">

                    <label>
                        Ciudad
                        <input
                            type="text"
                            value={form.city}
                            onChange={(e) => setForm({ ...form, city: e.target.value })}
                            placeholder="ej. Lima"
                        />
                    </label>

                    <label>
                        País
                        <input
                            type="text"
                            value={form.country}
                            onChange={(e) => setForm({ ...form, country: e.target.value })}
                            placeholder="ej. Perú"
                        />
                    </label>

                </div>

                <div className="confirm-actions">

                    <button
                        className="primary-button"
                        onClick={handleSave}
                        disabled={busy || !isAdmin}
                    >
                        {busy ? "Guardando..." : "Guardar datos"}
                    </button>

                    {
                        version && (
                            <span className="vpn-version">
                                Versión {version.version}
                                {version.commit && version.commit !== "-" ? ` (${version.commit})` : ""}
                            </span>
                        )
                    }

                </div>

            </div>

        </div>

    );

}


function IntegrationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [syslog, setSyslog] = useState({
        enabled: false,
        server: "",
        port: 514,
        protocol: "udp"
    });

    const [retention, setRetention] = useState(90);

    const [reviewerEmail, setReviewerEmail] = useState("");

    const [reviewFreq, setReviewFreq] = useState(7);

    const [reviewLast, setReviewLast] = useState(null);

    const [reviewOverdue, setReviewOverdue] = useState(false);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getSyslogSettings()

            .then((data) => {
                if (cancelled) return;
                setSyslog({
                    enabled: data.enabled,
                    server: data.server || "",
                    port: data.port,
                    protocol: data.protocol || "udp"
                });
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        getComplianceRetention()

            .then((data) => {
                if (!cancelled) setRetention(data.log_retention_days);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        getLogsReview()

            .then((data) => {
                if (cancelled) return;
                setReviewerEmail(data.reviewer_email || "");
                setReviewFreq(data.frequency_days || 7);
                setReviewLast(data.last_review);
                setReviewOverdue(data.overdue);
            })

            .catch(() => {});

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleSaveSyslog() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveSyslogSettings({
                enabled: syslog.enabled,
                server: syslog.server,
                port: Number(syslog.port),
                protocol: syslog.protocol
            });

            setSyslog((previous) => ({
                ...previous,
                enabled: saved.enabled
            }));

            setNotice("Configuración SIEM guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleTestSyslog() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await testSyslog();

            setNotice(result.message || "Mensaje de prueba enviado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveRetention() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await saveComplianceRetention({
                log_retention_days: Number(retention)
            });

            setNotice("Retención de logs guardada (aplica al reiniciar el DNS).");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveReviewer() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveLogsReview({
                reviewer_email: reviewerEmail,
                frequency_days: Number(reviewFreq)
            });

            setReviewLast(saved.last_review);

            setReviewOverdue(saved.overdue);

            setNotice("Responsable de revisión guardado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleMarkReview() {

        setBusy(true);

        try {

            const saved = await markLogsReview();

            setReviewLast(saved.last_review);

            setReviewOverdue(saved.overdue);

            setNotice("Revisión de logs marcada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Integración SIEM (Syslog)</h3>

            <p className="maintenance-hint">

                Reenvía los eventos de seguridad a tu SOC / SIEM
                (Splunk, Elastic, Graylog...) por syslog.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            <div className="vpn-form">

                <label className="checkbox-label">
                    <input
                        type="checkbox"
                        checked={syslog.enabled}
                        onChange={(e) => setSyslog({ ...syslog, enabled: e.target.checked })}
                    />
                    Reenvío a SIEM habilitado
                </label>

                <div className="schedule-row">

                    <label>
                        Servidor syslog
                        <input
                            type="text"
                            value={syslog.server}
                            onChange={(e) => setSyslog({ ...syslog, server: e.target.value })}
                            placeholder="ej. 10.0.0.10"
                        />
                    </label>

                    <label>
                        Puerto
                        <input
                            type="number"
                            value={syslog.port}
                            onChange={(e) => setSyslog({ ...syslog, port: e.target.value })}
                            placeholder="514"
                        />
                    </label>

                    <label>
                        Protocolo
                        <select
                            value={syslog.protocol}
                            onChange={(e) => setSyslog({ ...syslog, protocol: e.target.value })}
                        >
                            <option value="udp">UDP</option>
                            <option value="tcp">TCP</option>
                        </select>
                    </label>

                </div>

                <div className="confirm-actions">

                    <button
                        className="primary-button"
                        onClick={handleSaveSyslog}
                        disabled={busy || !isAdmin}
                    >
                        {busy ? "Guardando..." : "Guardar"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleTestSyslog}
                        disabled={busy || !isAdmin}
                    >
                        Enviar prueba
                    </button>

                </div>

            </div>

            <h3>Retención de registros</h3>

            <p className="maintenance-hint">

                Días que se conservan los registros de navegación antes
                de purgarse (política de retención).

            </p>

            <div className="vpn-form">

                <div className="schedule-row">

                    <label>
                        Días de retención
                        <input
                            type="number"
                            value={retention}
                            onChange={(e) => setRetention(e.target.value)}
                            min={7}
                            max={730}
                        />
                    </label>

                </div>

                <div className="confirm-actions">

                    <button
                        className="primary-button"
                        onClick={handleSaveRetention}
                        disabled={busy || !isAdmin}
                    >
                        Guardar retención
                    </button>

                </div>

            </div>

            <h3>Responsable de revisión de logs</h3>

            <p className="maintenance-hint">

                Rol designado para revisar periódicamente los registros
                (idealmente diario; recordatorio configurable).

            </p>

            {
                reviewOverdue && (
                    <div className="hardening-overdue" style={{ marginBottom: 12 }}>
                        ⚠ Revisión de logs pendiente (más de {reviewFreq} días).
                    </div>
                )
            }

            <div className="vpn-form">

                <div className="schedule-row">

                    <label>
                        Correo del responsable
                        <input
                            type="text"
                            value={reviewerEmail}
                            onChange={(e) => setReviewerEmail(e.target.value)}
                            placeholder="admin@empresa.com"
                        />
                    </label>

                    <label>
                        Recordatorio cada (días)
                        <input
                            type="number"
                            min={1}
                            max={365}
                            value={reviewFreq}
                            onChange={(e) => setReviewFreq(e.target.value)}
                        />
                    </label>

                </div>

                {
                    reviewLast && (
                        <div className="maintenance-active-details">
                            Última revisión: {new Date(reviewLast).toLocaleString("es")}
                        </div>
                    )
                }

                <div className="confirm-actions">

                    <button
                        className="primary-button"
                        onClick={handleSaveReviewer}
                        disabled={busy || !isAdmin}
                    >
                        Guardar responsable
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleMarkReview}
                        disabled={busy || !isAdmin}
                    >
                        Marcar revisión
                    </button>

                </div>

            </div>

        </div>

    );

}


function RevisionSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [revisions, setRevisions] = useState([]);

    const [label, setLabel] = useState("");

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    function load() {

        getConfigRevisions()

            .then(setRevisions)

            .catch((err) => setError(err.message));

    }


    useEffect(() => {

        let cancelled = false;

        getConfigRevisions()

            .then((data) => {
                if (!cancelled) setRevisions(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleCapture() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await captureConfigRevision(label || "Revisión manual");

            setLabel("");

            load();

            setNotice("Revisión de configuración guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRestore(revision) {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const ok = window.confirm(
                `¿Restaurar la configuración a la revisión #${revision.id} ` +
                `("${revision.label}")? Se reemplazarán reglas, VPN, DMZ y ajustes.`
            );

            if (!ok) return;

            const result = await restoreConfigRevision(revision.id);

            setNotice(
                `Configuración restaurada (${(result.restored || []).join(", ")}).`
            );

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Revisión de configuración (rollback)</h3>

            <p className="maintenance-hint">

                Guarda una foto de la configuración actual y, si algo
                sale mal, restáurala. Restaura reglas de bloqueo, peers
                VPN, reenvíos (DMZ) y ajustes.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            {
                isAdmin && (
                    <div className="vpn-form">

                        <div className="schedule-row">

                            <label>
                                Etiqueta (opcional)
                                <input
                                    type="text"
                                    value={label}
                                    onChange={(e) => setLabel(e.target.value)}
                                    placeholder="ej. antes de cambiar filtrado"
                                />
                            </label>

                            <button
                                className="primary-button"
                                onClick={handleCapture}
                                disabled={busy}
                            >
                                Guardar revisión ahora
                            </button>

                        </div>

                    </div>
                )
            }

            <table className="vpn-table">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>Etiqueta</th>
                        <th>Usuario</th>
                        <th>Fecha</th>
                        {isAdmin && <th>Acciones</th>}
                    </tr>
                </thead>

                <tbody>

                    {
                        revisions.length === 0 && (
                            <tr><td colSpan={5} className="vpn-empty">Sin revisiones guardadas.</td></tr>
                        )
                    }

                    {
                        revisions.map((revision) => (
                            <tr key={revision.id}>

                                <td>#{revision.id}</td>

                                <td>{revision.label}</td>

                                <td>{revision.username || "—"}</td>

                                <td>{new Date(revision.created_at).toLocaleString("es-ES")}</td>

                                {
                                    isAdmin && (
                                        <td>
                                            <button
                                                className="secondary-button small"
                                                onClick={() => handleRestore(revision)}
                                                disabled={busy}
                                            >
                                                Restaurar
                                            </button>
                                        </td>
                                    )
                                }

                            </tr>
                        ))
                    }

                </tbody>

            </table>

        </div>

    );

}


function UpdateSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    function load() {

        getUpdateStatus()

            .then(setStatus)

            .catch((err) => setError(err.message));

    }


    useEffect(() => {

        let cancelled = false;

        getUpdateStatus()

            .then((data) => {
                if (!cancelled) setStatus(data);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleUpdate() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const ok = window.confirm(
                "¿Actualizar el software desde origin/main? " +
                "Se descargarán los cambios, se compilará el frontend " +
                "y se reiniciará el servicio."
            );

            if (!ok) return;

            const result = await runUpdate();

            setNotice(result.message || "Actualización iniciada.");

            setTimeout(load, 8000);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Actualizaciones</h3>

            <p className="maintenance-hint">

                Descarga la última versión disponible y la aplica
                automáticamente, conservando la configuración y los datos.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            {
                status && (
                    <div className="vpn-status-grid">

                        <div className="vpn-status-card">
                            <div className="vpn-status-label">Versión</div>
                            <div className="vpn-status-value">{status.version}</div>
                        </div>

                        <div className="vpn-status-card">
                            <div className="vpn-status-label">Última versión</div>
                            <div className="vpn-status-value">{status.latest_version || "—"}</div>
                        </div>

                        {
                            status.mode !== "package" && (
                                <>
                                    <div className="vpn-status-card">
                                        <div className="vpn-status-label">Commit actual</div>
                                        <div className="vpn-status-value vpn-code">{status.commit}</div>
                                    </div>

                                    <div className="vpn-status-card">
                                        <div className="vpn-status-label">Último en main</div>
                                        <div className="vpn-status-value vpn-code">{status.remote_commit}</div>
                                    </div>
                                </>
                            )
                        }

                        <div className={`vpn-status-card ${status.update_available ? "warn" : ""}`}>
                            <div className="vpn-status-label">Estado</div>
                            <div className="vpn-status-value">
                                {status.update_available
                                    ? "Actualización disponible"
                                    : "Al día"}
                            </div>
                        </div>

                    </div>
                )
            }

            {
                status && status.pending_commits && status.pending_commits.length > 0 && (
                    <div className="update-pending">
                        <h4>
                            Cambios pendientes ({status.pending_commits.length})
                        </h4>
                        <ul className="update-pending-list">
                            {
                                status.pending_commits.map((c) => (
                                    <li key={c.commit}>
                                        <span className="vpn-code">
                                            {c.commit.slice(0, 7)}
                                        </span>
                                        {" "}{c.message}
                                    </li>
                                ))
                            }
                        </ul>
                        <p className="maintenance-hint">
                            Revisa estos cambios antes de aplicar en producción
                            (pruebas en ambiente controlado).
                        </p>
                    </div>
                )
            }

            {
                isAdmin && (
                    <button
                        className="primary-button"
                        onClick={handleUpdate}
                        disabled={busy}
                    >
                        {busy ? "Actualizando..." : "Actualizar ahora"}
                    </button>
                )
            }

        </div>

    );

}


function RemoteAdminSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [enabled, setEnabled] = useState(null);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getRemoteAdmin()

            .then((data) => {
                if (!cancelled) setEnabled(data.enabled);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleToggle() {

        setError(null);

        setNotice(null);

        const next = !enabled;

        const ok = window.confirm(
            next
                ? "¿Exigir VPN para el acceso remoto? La web quedará "
                  + "accesible solo por LAN o VPN desde la WAN."
                : "¿Permitir la web desde la WAN (sin exigir VPN)? Menos seguro."
        );

        if (!ok) return;

        setBusy(true);

        try {

            const result = await setRemoteAdmin(next);

            setEnabled(result.enabled);

            setNotice(result.message || "Aplicado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Acceso remoto a la web</h3>

            <p className="maintenance-hint">

                Exige la VPN (WireGuard) para entrar a la web desde fuera
                de la red local. Con esto activado, la web solo se
                accede por LAN o por VPN.

            </p>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            {
                enabled == null && (
                    <p className="vpn-empty">Cargando...</p>
                )
            }

            {
                enabled != null && isAdmin && (
                    <div className="vpn-form">

                        <label className="checkbox-label">
                            <input
                                type="checkbox"
                                checked={enabled}
                                onChange={handleToggle}
                                disabled={busy}
                            />
                            Exigir VPN para acceso remoto (bloquear la web desde WAN)
                        </label>

                    </div>
                )
            }

        </div>

    );

}


function Settings() {

    const [tab, setTab] = useState("empresa");

    const TABS = [
        { key: "servicios", label: "Servicios" },
        { key: "empresa", label: "Empresa" },
        { key: "seguridad", label: "Seguridad" },
        { key: "notificaciones", label: "Notificaciones" },
        { key: "copias", label: "Copias y respaldos" },
        { key: "revision", label: "Revisión" },
        { key: "integracion", label: "Integraciones" },
        { key: "dmz", label: "Reenvíos (DMZ)" },
        { key: "mantenimiento", label: "Mantenimiento" },
        { key: "actualizaciones", label: "Actualizaciones" }
    ];


    return (

        <div className="settings-container">

            <h2>Ajustes y mantenimiento</h2>

            <div className="settings-tabs">

                {
                    TABS.map((item) => (
                        <button
                            key={item.key}
                            className={`settings-tab ${tab === item.key ? "active" : ""}`}
                            onClick={() => setTab(item.key)}
                        >
                            {item.label}
                        </button>
                    ))
                }

            </div>

            {
                tab === "servicios" && <ModulesSection />
            }

            {
                tab === "empresa" && <OrganizationSection />
            }

            {
                tab === "seguridad" && (
                    <>
                        <RemoteAdminSection />
                        <MfaSection />
                    </>
                )
            }

            {
                tab === "notificaciones" && <NotificationSection />
            }

            {
                tab === "copias" && <BackupSection />
            }

            {
                tab === "revision" && <RevisionSection />
            }

            {
                tab === "integracion" && <IntegrationSection />
            }

            {
                tab === "dmz" && <PortForwardSection />
            }

            {
                tab === "mantenimiento" && <NetworkMaintenance />
            }

            {
                tab === "actualizaciones" && <UpdateSection />
            }

            {
                tab === "dominios" && <DomainGroupsSection />
            }

        </div>

    );

}


export default Settings;
