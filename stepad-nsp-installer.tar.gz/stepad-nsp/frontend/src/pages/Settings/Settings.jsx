import { useState } from "react";
import { useSearchParams } from "react-router-dom";

import ModulesSection from "./components/ModulesSection";
import OrganizationSection from "./components/OrganizationSection";
import EmailSection from "./components/EmailSection";
import NavigationReportSection from "./components/NavigationReportSection";
import VulnerabilityReportSection from "./components/VulnerabilityReportSection";
import AlertNotificationSection from "./components/AlertNotificationSection";
import SecuritySection from "./components/SecuritySection";
import BackupSection from "./components/BackupSection";
import IntegrationSection from "./components/IntegrationSection";
import PortForwardSection from "./components/PortForwardSection";
import RevisionSection from "./components/RevisionSection";
import MaintenanceSection from "./components/MaintenanceSection";
import CapacitySection from "./components/CapacitySection";
import UpdateSection from "./components/UpdateSection";
import DomainGroupsSection from "./components/DomainGroupsSection";
import RetentionSection from "./components/RetentionSection";
import ScheduledTasksSection from "./components/ScheduledTasksSection";
import ContinuitySection from "./components/ContinuitySection";
import ActiveDirectorySection from "./components/ActiveDirectorySection";

import "./settings.css";

const SETTINGS_GROUPS = [
    {
        id: "general",
        label: "General",
        items: [
            { key: "empresa", label: "Empresa" },
            { key: "servicios", label: "Servicios" },
        ],
    },
    {
        id: "windows",
        label: "Windows Server",
        items: [
            { key: "directorio", label: "Active Directory" },
        ],
    },
    {
        id: "security",
        label: "Seguridad",
        items: [
            { key: "seguridad", label: "Seguridad" },
            { key: "alertas", label: "Notificaciones" },
        ],
    },
    {
        id: "email",
        label: "Correo y Reportes",
        items: [
            { key: "correo", label: "Correo" },
            { key: "navegacion", label: "Reportes de navegación" },
            { key: "vulnerabilidades", label: "Informe de vulnerabilidades" },
        ],
    },
    {
        id: "network",
        label: "Red",
        items: [
            { key: "dmz", label: "Reenvíos (DMZ)" },
            { key: "dominios", label: "Grupos de dominios" },
            { key: "mantenimiento", label: "Mantenimiento de red" },
        ],
    },
    {
        id: "system",
        label: "Sistema",
        items: [
            { key: "copias", label: "Copias de seguridad" },
            { key: "revision", label: "Revisión de configuraciones" },
            { key: "retencion", label: "Retención de datos" },
            { key: "capacidad", label: "Capacidad del servidor" },
            { key: "programado", label: "Tareas programadas" },
            { key: "continuidad", label: "Continuidad / DR" },
            { key: "integracion", label: "Integraciones" },
            { key: "actualizaciones", label: "Actualizaciones" },
        ],
    },
];

function Settings() {
    const [searchParams, setSearchParams] = useSearchParams();
    const [tab, setTab] = useState(() => searchParams.get("tab") || "empresa");

    function selectTab(key) {
        setTab(key);
        setSearchParams(key === "empresa" ? {} : { tab: key }, { replace: true });
    }

    const renderContent = () => {
        switch (tab) {
            case "servicios": return <ModulesSection />;
            case "empresa": return <OrganizationSection />;
            case "correo": return <EmailSection />;
            case "seguridad": return <SecuritySection />;
            case "directorio": return <ActiveDirectorySection />;
            case "navegacion": return <NavigationReportSection />;
            case "vulnerabilidades": return <VulnerabilityReportSection />;
            case "alertas": return <AlertNotificationSection />;
            case "copias": return <BackupSection />;
            case "revision": return <RevisionSection />;
            case "retencion": return <RetentionSection />;
            case "capacidad": return <CapacitySection />;
            case "programado": return <ScheduledTasksSection />;
            case "continuidad": return <ContinuitySection />;
            case "integracion": return <IntegrationSection />;
            case "dmz": return <PortForwardSection />;
            case "mantenimiento": return <MaintenanceSection />;
            case "dominios": return <DomainGroupsSection />;
            case "actualizaciones": return <UpdateSection />;
            default: return <OrganizationSection />;
        }
    };

    return (
        <div className="settings-container">
            <div className="settings-layout">
                <aside className="settings-sidebar">
                    <h2>Ajustes</h2>
                    {SETTINGS_GROUPS.map((group) => (
                        <div key={group.id} className="settings-group">
                            <div className="settings-group-label">{group.label}</div>
                            {group.items.map((item) => (
                                <button
                                    key={item.key}
                                    className={`settings-sidebar-item ${tab === item.key ? "active" : ""}`}
                                    onClick={() => selectTab(item.key)}
                                >
                                    {item.label}
                                </button>
                            ))}
                        </div>
                    ))}
                </aside>
                <main className="settings-content">
                    {renderContent()}
                </main>
            </div>
        </div>
    );
}

export default Settings;
