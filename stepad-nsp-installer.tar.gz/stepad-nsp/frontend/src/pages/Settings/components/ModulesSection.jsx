import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getModules,
    setModules
} from "../../../services/api";


function ModulesSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [modules, setModules] = useState([]);

    const [busy, setBusy] = useState(false);

    const [notice, setNotice] = useState(null);

    const [error, setError] = useState(null);


    useEffect(() => {

        let cancelled = false;

        getModules()

            .then((data) => {
                if (!cancelled) setModules(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleToggle(module) {

        const next = modules.map((m) =>
            m.key === module.key ? { ...m, enabled: !m.enabled } : m
        );

        const enabledKeys = next
            .filter((m) => m.enabled)
            .map((m) => m.key);

        setBusy(true);

        setError(null);

        setNotice(null);

        try {

            const saved = await setModules(enabledKeys);

            setModules(saved || next);

            setNotice("Servicios actualizados.");

        } catch (err) {

            setModules(modules);

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="maintenance-panel">

            <h3>Servicios activados</h3>

            <p className="maintenance-hint">

                Activa solo los servicios que el cliente contrató. El

                hardware se evalúa según los servicios ACTIVADOS (en la

                página Equipo se avisará si falta hardware mínimo).

            </p>

            {
                error && (
                    <div className="maintenance-error" style={{ marginBottom: 12 }}>
                        {error}
                    </div>
                )
            }

            {
                notice && (
                    <div className="notification-ok">{notice}</div>
                )
            }

            <div className="modules-list">

                {
                    modules.map((module) => (

                        <label key={module.key} className="module-item">

                            <input
                                type="checkbox"
                                checked={module.enabled}
                                disabled={busy || !isAdmin}
                                onChange={() => handleToggle(module)}
                            />

                            <div className="module-info">

                                <strong>{module.name}</strong>

                                <div className="module-meta">
                                    {module.description}
                                </div>

                                <div className="module-req">
                                    Requiere: mín. {module.min_cores} núcleos
                                    {" · "}{module.min_ram_mb / 1024} GB RAM
                                    {" · rec. "}{module.rec_cores} núcleos
                                    {" / "}{module.rec_ram_mb / 1024} GB
                                </div>

                            </div>

                        </label>

                    ))
                }

            </div>

        </div>

    );

}


export default ModulesSection;
