import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getRetentionSettings,
    saveRetentionSetting,
    runRetentionCleanup,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import { formatDateTime } from "../../../utils/datetime";

import "../settings.css";


const MONTHS = {
    30: "1 mes",
    60: "2 meses",
    90: "3 meses",
    120: "4 meses",
    150: "5 meses",
    180: "6 meses",
    270: "9 meses",
    365: "12 meses",
    0: "Ilimitado",
};


function daysLabel(days) {

    return MONTHS[days] || `${days} días`;
}


function RetentionSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [rows, setRows] = useState([]);

    const [draft, setDraft] = useState({});

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);

    const [loading, setLoading] = useState(true);


    function apply(data) {

        const list = data || [];

        setRows(list);

        setDraft(
            Object.fromEntries(list.map((row) => [row.key, row.retention_days]))
        );

    }


    useEffect(() => {

        let cancelled = false;

        getRetentionSettings()
            .then((data) => {
                if (!cancelled) apply(data);
            })
            .catch((err) => {
                if (!cancelled) setError(err.message);
            })
            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => {
            cancelled = true;
        };
    }, []);


    const changed = rows.filter(
        (row) => draft[row.key] !== undefined && draft[row.key] !== row.retention_days
    );


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            let latest = null;

            for (const row of changed) {

                latest = await saveRetentionSetting(row.key, {
                    retention_days: Number(draft[row.key]),
                });
            }

            if (latest) {

                const data = await getRetentionSettings();

                apply(data);

                setNotice(
                    "Retención guardada. La limpieza corre cada hora; usá «Ejecutar ahora» para aplicarla ya."
                );
            }

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRun() {

        if (!window.confirm(
            "Se borrarán los registros más antiguos que la retención configurada. Las alertas pendientes no se tocan. ¿Continuar?"
        )) {

            return;
        }

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await runRetentionCleanup() || {};

            const total = Object.values(result).reduce(
                (acc, value) => acc + Number(value || 0),
                0
            );

            const detail = Object.entries(result)
                .filter(([, value]) => Number(value) > 0)
                .map(([key, value]) => {
                    const row = rows.find((item) => item.key === key);
                    return `${row?.label || key}: ${Number(value).toLocaleString("es-AR")}`;
                })
                .join(" · ");

            setNotice(
                total > 0
                    ? `Limpieza ejecutada: ${total.toLocaleString("es-AR")} registro(s) eliminados. ${detail}`
                    : "Limpieza ejecutada: no había registros fuera de la retención."
            );

            apply(await getRetentionSettings());

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const totalRows = rows.reduce((acc, row) => acc + Number(row.rows || 0), 0);

    const oldest = rows
        .map((row) => row.oldest)
        .filter(Boolean)
        .sort()[0];


    return (

        <SettingsPanel
            title="Retención de datos"
            lead="Cuánto tiempo se conserva cada tipo de registro antes de borrarse automáticamente. Las alertas sin leer nunca se eliminan."
            badge="Limpieza cada hora"
            badgeVariant="ok"
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Registros almacenados"
                    value={totalRows.toLocaleString("es-AR")}
                    meta="En los tipos con retención"
                />

                <SettingsStatusCard
                    label="Más antiguo"
                    value={oldest ? formatDateTime(oldest) : "—"}
                    meta="Entre todos los tipos"
                />

                <SettingsStatusCard
                    label="Tipo de limpieza"
                    value="Automática"
                    meta="Cada hora, por lotes de 20.000"
                />

            </SettingsStatusGrid>

            <SettingsBlock
                title="Antigüedad por tipo de dato"
                hint="Elegí 1 a 12 meses o «Ilimitado» para conservar todo."
                first
            >

                {loading ? (
                    <p className="org-lead">Cargando…</p>
                ) : (
                    <div className="org-form-grid">

                        {rows.map((row) => (

                            <label key={row.key}>

                                {row.label}

                                <select
                                    value={draft[row.key] ?? row.retention_days}
                                    disabled={!isAdmin || busy}
                                    onChange={(e) => setDraft({
                                        ...draft,
                                        [row.key]: Number(e.target.value),
                                    })}
                                >

                                    {(row.options_days || []).map((days) => (

                                        <option key={days} value={days}>
                                            {daysLabel(days)}
                                        </option>

                                    ))}

                                </select>

                                <small>
                                    {row.description}
                                    {" · "}
                                    {Number(row.rows || 0).toLocaleString("es-AR")} registros
                                    {row.oldest
                                        ? ` · desde ${formatDateTime(row.oldest)}`
                                        : ""}
                                    {row.last_run_at
                                        ? ` · último borrado ${formatDateTime(row.last_run_at)} (${Number(row.last_deleted || 0).toLocaleString("es-AR")})`
                                        : ""}
                                </small>

                            </label>

                        ))}

                    </div>
                )}

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleSave}
                        disabled={!isAdmin || busy || changed.length === 0}
                    >
                        {busy ? "Guardando…" : "Guardar cambios"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleRun}
                        disabled={!isAdmin || busy}
                    >
                        Ejecutar ahora
                    </button>

                </SettingsActions>

            </SettingsBlock>

        </SettingsPanel>
    );
}


export default RetentionSection;
