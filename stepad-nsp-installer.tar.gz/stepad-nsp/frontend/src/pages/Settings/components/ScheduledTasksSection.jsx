import { useEffect, useState } from "react";

import {
    getScheduledTasks,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import { formatDateTime } from "../../../utils/datetime";

import "../settings.css";


const STATE_LABEL = {
    ok: "Al día",
    never: "Sin corridas",
    overdue: "Atrasada",
    disabled: "Desactivada",
};


const STATE_CLASS = {
    ok: "ok",
    never: "muted",
    overdue: "warn",
    disabled: "muted",
};


function ScheduledTasksSection() {

    const [data, setData] = useState({ tasks: [], resources: {} });

    const [error, setError] = useState(null);

    const [loading, setLoading] = useState(true);


    function load() {

        setLoading(true);

        getScheduledTasks()
            .then((result) => {
                setData(result || { tasks: [], resources: {} });
                setError(null);
            })
            .catch((err) => setError(err.message))
            .finally(() => setLoading(false));
    }


    useEffect(() => {

        load();

    }, []);


    const tasks = data.tasks || [];

    const resources = data.resources || {};

    const groups = tasks.reduce((acc, task) => {

        acc[task.group] = [...(acc[task.group] || []), task];

        return acc;

    }, {});


    const overdue = tasks.filter((task) => task.state === "overdue").length;

    const disabled = tasks.filter((task) => task.state === "disabled").length;


    return (

        <SettingsPanel
            title="Tareas programadas"
            lead="Qué corre solo, cuándo fue la última vez y cuándo toca la próxima. Si algo figura «Atrasada», revisá su ajuste."
            badge={overdue ? `${overdue} atrasada(s)` : "Todo al día"}
            badgeVariant={overdue ? "partial" : "complete"}
            error={error}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Tareas activas"
                    value={tasks.length - disabled}
                    meta={`${tasks.length} en total`}
                />

                <SettingsStatusCard
                    label="Atrasadas"
                    value={overdue}
                    meta="Requieren revisión"
                    variant={overdue ? "warn" : "ok"}
                />

                <SettingsStatusCard
                    label="Disco"
                    value={`${resources.disk_percent ?? "—"}%`}
                    meta={`${resources.disk_free_gb ?? "—"} GB libres`}
                    variant={
                        (resources.disk_percent ?? 0) >= 85 ? "warn" : "ok"
                    }
                />

            </SettingsStatusGrid>

            {Object.entries(groups).map(([group, items]) => (

                <SettingsBlock key={group} title={group}>

                    <div className="org-form-grid">

                        {items.map((task) => (

                            <label key={task.key}>

                                {task.label}

                                <span className={`org-badge ${STATE_CLASS[task.state] || ""}`}>
                                    {STATE_LABEL[task.state] || task.state}
                                </span>

                                <small>
                                    {task.enabled ? task.schedule : "desactivada"}
                                    {" · Última: "}
                                    {task.last_run ? formatDateTime(task.last_run) : "nunca"}
                                    {" · Próxima: "}
                                    {task.next_run ? formatDateTime(task.next_run) : "—"}
                                    {task.result ? ` · ${task.result}` : ""}
                                </small>

                            </label>

                        ))}

                    </div>

                </SettingsBlock>

            ))}

            {resources.journal_used_mb !== undefined && resources.journal_used_mb !== null && (
                <SettingsBlock title="Journal del sistema">
                    <p className="org-lead">
                        {resources.journal_used_mb} MB usados de {resources.journal_limit_mb} MB
                        (límite fijo; se recorta solo).
                    </p>
                </SettingsBlock>
            )}

            <SettingsActions>

                <button
                    className="secondary-button"
                    onClick={load}
                    disabled={loading}
                >
                    {loading ? "Actualizando…" : "Actualizar"}
                </button>

            </SettingsActions>

        </SettingsPanel>
    );
}


export default ScheduledTasksSection;
