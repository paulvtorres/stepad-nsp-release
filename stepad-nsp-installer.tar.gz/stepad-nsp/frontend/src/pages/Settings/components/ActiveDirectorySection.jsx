import { useEffect, useMemo, useState } from "react";

import { useAuth } from "../../../auth/useAuth";
import {
    deleteADMapping,
    getADLatest,
    getADSettings,
    saveADMapping,
    saveADSettings,
    syncADDirectory,
    testADConnection,
} from "../../../services/api";
import { formatDateTime } from "../../../utils/datetime";
import {
    SettingsActions,
    SettingsBlock,
    SettingsPanel,
    SettingsStatusCard,
    SettingsStatusGrid,
} from "./SettingsPanel";

import "../settings.css";


const EMPTY = {
    enabled: false,
    login_enabled: false,
    sync_interval_minutes: 15,
    domain_name: "",
    server: "",
    port: 636,
    use_ssl: true,
    verify_tls: true,
    base_dn: "",
    bind_dn: "",
    bind_password: "",
    user_filter: "(sAMAccountName={username})",
    group_filter: "(member={user_dn})",
    default_group_id: "",
};


function Step({ number, label, active, done }) {
    return (
        <div className={`ad-step ${active ? "active" : ""} ${done ? "done" : ""}`}>
            <span>{done ? "✓" : number}</span>
            <strong>{label}</strong>
        </div>
    );
}


export default function ActiveDirectorySection() {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState(EMPTY);
    const [groups, setGroups] = useState([]);
    const [status, setStatus] = useState(null);
    const [directory, setDirectory] = useState(null);
    const [mappingDrafts, setMappingDrafts] = useState({});
    const [busy, setBusy] = useState(false);
    const [testing, setTesting] = useState(false);
    const [syncing, setSyncing] = useState(false);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);


    function apply(data) {
        setForm({
            enabled: Boolean(data.enabled),
            login_enabled: Boolean(data.login_enabled),
            sync_interval_minutes: data.sync_interval_minutes || 15,
            domain_name: data.domain_name || "",
            server: data.server || "",
            port: data.port || 636,
            use_ssl: data.use_ssl !== false,
            verify_tls: data.verify_tls !== false,
            base_dn: data.base_dn || "",
            bind_dn: data.bind_dn || "",
            bind_password: "",
            user_filter: data.user_filter || "(sAMAccountName={username})",
            group_filter: data.group_filter || "(member={user_dn})",
            default_group_id: data.default_group_id || "",
        });
        setGroups(data.groups || []);
        setStatus(data);
    }


    async function load() {
        try {
            const [data, latest] = await Promise.all([
                getADSettings(),
                getADLatest().catch(() => null),
            ]);
            apply(data);
            if (latest?.success) {
                setDirectory(latest);
            }
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo cargar AD.");
        }
    }


    useEffect(() => {
        load();
    }, []);


    function setField(key, value) {
        setForm((prev) => ({ ...prev, [key]: value }));
    }


    async function save() {
        if (!isAdmin) return;
        setBusy(true);
        setError(null);
        setNotice(null);

        try {
            const payload = {
                ...form,
                port: Number(form.port) || 636,
                sync_interval_minutes: Number(form.sync_interval_minutes) || 15,
                default_group_id: form.default_group_id ? Number(form.default_group_id) : null,
                bind_password: form.bind_password || undefined,
            };
            const data = await saveADSettings(payload);
            apply(data);
            setNotice("Configuración AD guardada. Ahora puedes probar la conexión.");
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo guardar.");
        } finally {
            setBusy(false);
        }
    }


    async function test() {
        if (!isAdmin) return;
        setTesting(true);
        setError(null);
        setNotice(null);

        try {
            const result = await testADConnection();
            setNotice(result.message || (result.success ? "Conexión correcta." : "Conexión fallida."));
            await load();
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo probar.");
        } finally {
            setTesting(false);
        }
    }


    async function syncDirectory() {
        if (!isAdmin) return;
        setSyncing(true);
        setError(null);
        setNotice(null);

        try {
            const data = await syncADDirectory();
            if (data.success === false) {
                setError(data.message || "No se pudo leer AD.");
            } else {
                setDirectory(data);
                setNotice(
                    `Directorio actualizado: ${data.groups?.length || 0} grupos y `
                    + `${data.matched || 0} equipos coincidentes.`
                );
            }
            await load();
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo sincronizar AD.");
        } finally {
            setSyncing(false);
        }
    }


    async function mapGroup(adGroup) {
        const groupId = mappingDrafts[adGroup.dn];

        if (!groupId) {
            setError("Selecciona un grupo NSP para mapear.");
            return;
        }

        setBusy(true);
        setError(null);

        try {
            await saveADMapping({
                ad_group_dn: adGroup.dn,
                ad_group_name: adGroup.name,
                nsp_group_id: Number(groupId),
            });
            setNotice(`Grupo AD «${adGroup.name}» mapeado.`);
            await syncDirectory();
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo mapear.");
        } finally {
            setBusy(false);
        }
    }


    async function removeMapping(mappingId) {
        if (!window.confirm("¿Quitar este mapeo AD?")) return;
        setBusy(true);
        setError(null);

        try {
            await deleteADMapping(mappingId);
            setNotice("Mapeo eliminado.");
            await syncDirectory();
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo eliminar.");
        } finally {
            setBusy(false);
        }
    }


    const configured = Boolean(status?.configured);
    const enabled = Boolean(status?.enabled);
    const mappedCount = directory?.mappings?.length || 0;
    const adGroups = useMemo(() => directory?.groups || [], [directory]);
    const adComputers = useMemo(() => directory?.computers || [], [directory]);
    const stepOneDone = configured;
    const stepTwoDone = Boolean(status?.last_test_ok);
    const stepThreeDone = Boolean(directory?.success);
    const stepFourDone = mappedCount > 0;


    return (
        <SettingsPanel
            title="Windows Server · Active Directory"
            lead="Importa usuarios, equipos y grupos desde Windows Server. La conexión es de solo lectura y no modifica AD."
            badge={enabled ? "AD activo" : configured ? "Configurado" : "Sin configurar"}
            badgeVariant={enabled ? "complete" : configured ? "partial" : ""}
            error={error}
            notice={notice}
            className="ad-settings-panel"
        >
            <div className="ad-steps">
                <Step number="1" label="Conectar" active={!stepOneDone} done={stepOneDone} />
                <Step number="2" label="Verificar" active={stepOneDone && !stepTwoDone} done={stepTwoDone} />
                <Step number="3" label="Importar AD" active={stepTwoDone && !stepThreeDone} done={stepThreeDone} />
                <Step number="4" label="Mapear" active={stepThreeDone && !stepFourDone} done={stepFourDone} />
            </div>

            <SettingsStatusGrid>
                <SettingsStatusCard
                    label="Conexión AD"
                    value={enabled ? "Activa" : configured ? "Configurada, inactiva" : "Sin configurar"}
                    meta={status?.server || "Completa los datos del dominio"}
                    variant={enabled ? "complete" : configured ? "partial" : ""}
                />
                <SettingsStatusCard
                    label="Última prueba"
                    value={status?.last_test_ok === true ? "OK" : status?.last_test_ok === false ? "Falló" : "Sin probar"}
                    meta={status?.last_test_at ? formatDateTime(status.last_test_at) : "Pulsa Probar conexión"}
                    variant={status?.last_test_ok === true ? "complete" : status?.last_test_ok === false ? "partial" : ""}
                />
                <SettingsStatusCard
                    label="Última sincronización"
                    value={status?.last_sync_at ? formatDateTime(status.last_sync_at) : "Sin sincronizar"}
                    meta={status?.last_sync_ok === false ? status.last_sync_message : "Directorio de solo lectura"}
                />
                <SettingsStatusCard
                    label="Directorio"
                    value={`${adGroups.length} grupos`}
                    meta={`${adComputers.length} equipos AD · ${mappedCount} mapeos`}
                />
            </SettingsStatusGrid>

            <SettingsBlock
                title="1. Datos de conexión"
                hint="Usa LDAPS y una cuenta de servicio de solo lectura. La contraseña queda cifrada."
                first
            >
                <div className="org-form-grid">
                    <label>
                        Dominio
                        <input
                            value={form.domain_name}
                            onChange={(e) => setField("domain_name", e.target.value)}
                            placeholder="empresa.local"
                            autoComplete="off"
                        />
                    </label>
                    <label>
                        Servidor / controlador
                        <input
                            value={form.server}
                            onChange={(e) => setField("server", e.target.value)}
                            placeholder="dc01.empresa.local"
                            autoComplete="off"
                        />
                    </label>
                    <label>
                        Puerto
                        <input
                            type="number"
                            min="1"
                            max="65535"
                            value={form.port}
                            onChange={(e) => setField("port", e.target.value)}
                        />
                    </label>
                    <label>
                        Base DN
                        <input
                            value={form.base_dn}
                            onChange={(e) => setField("base_dn", e.target.value)}
                            placeholder="DC=empresa,DC=local"
                            autoComplete="off"
                        />
                    </label>
                    <label>
                        Usuario de enlace
                        <input
                            value={form.bind_dn}
                            onChange={(e) => setField("bind_dn", e.target.value)}
                            placeholder="CN=stepad,OU=Servicios,DC=empresa,DC=local"
                            autoComplete="off"
                        />
                    </label>
                    <label>
                        Contraseña
                        <input
                            type="password"
                            value={form.bind_password}
                            onChange={(e) => setField("bind_password", e.target.value)}
                            placeholder={status?.password_set ? "•••••••• (sin cambios)" : "Contraseña de enlace"}
                            autoComplete="new-password"
                        />
                    </label>
                </div>

                <div className="org-form-grid">
                    <label className="org-wide">
                        Filtro de usuarios
                        <input
                            value={form.user_filter}
                            onChange={(e) => setField("user_filter", e.target.value)}
                        />
                    </label>
                    <label className="org-wide">
                        Filtro de grupos
                        <input
                            value={form.group_filter}
                            onChange={(e) => setField("group_filter", e.target.value)}
                        />
                    </label>
                </div>

                <div className="org-form-grid">
                    <label>
                        Grupo NSP por defecto
                        <select
                            value={form.default_group_id}
                            onChange={(e) => setField("default_group_id", e.target.value)}
                        >
                            <option value="">Sin asignar</option>
                            {groups.map((group) => (
                                <option key={group.id} value={group.id}>{group.name}</option>
                            ))}
                        </select>
                    </label>
                    <label>
                        Estado de integración
                        <select
                            value={form.enabled ? "1" : "0"}
                            onChange={(e) => setField("enabled", e.target.value === "1")}
                        >
                            <option value="0">Desactivada</option>
                            <option value="1">Activa</option>
                        </select>
                    </label>
                    <label>
                        Sincronizar cada (min)
                        <input
                            type="number"
                            min="1"
                            max="1440"
                            value={form.sync_interval_minutes}
                            onChange={(e) => setField("sync_interval_minutes", e.target.value)}
                        />
                    </label>
                </div>

                <div className="ad-advanced-row">
                    <label className="ad-toggle-row">
                        <input
                            type="checkbox"
                            checked={form.use_ssl}
                            onChange={(e) => setField("use_ssl", e.target.checked)}
                        />
                        <span>
                            <strong>Usar LDAPS</strong>
                            <small>Recomendado para proteger credenciales.</small>
                        </span>
                    </label>
                    <label className="ad-toggle-row">
                        <input
                            type="checkbox"
                            checked={form.verify_tls}
                            onChange={(e) => setField("verify_tls", e.target.checked)}
                        />
                        <span>
                            <strong>Validar certificado TLS</strong>
                            <small>Desactiva solo para pruebas controladas.</small>
                        </span>
                    </label>
                    <label className="ad-toggle-row">
                        <input
                            type="checkbox"
                            checked={form.login_enabled}
                            onChange={(e) => setField("login_enabled", e.target.checked)}
                        />
                        <span>
                            <strong>Permitir login AD</strong>
                            <small>Para usuarios locales existentes.</small>
                        </span>
                    </label>
                </div>

                <div className="ad-notice">
                    <strong>Importante:</strong> el login AD no crea usuarios ni cambia roles.
                    Crea el usuario local con el mismo <code>sAMAccountName</code> y conserva
                    el admin local como acceso de emergencia.
                </div>
            </SettingsBlock>

            <SettingsActions>
                <button type="button" className="secondary-button" onClick={test} disabled={!isAdmin || testing}>
                    {testing ? "Probando…" : "Probar conexión"}
                </button>
                <button type="button" className="secondary-button" onClick={syncDirectory} disabled={!isAdmin || syncing}>
                    {syncing ? "Importando…" : "Importar desde AD"}
                </button>
                <button type="button" className="primary-button" onClick={save} disabled={!isAdmin || busy}>
                    {busy ? "Guardando…" : "Guardar configuración"}
                </button>
            </SettingsActions>

            <SettingsBlock
                title="2. Importar y mapear"
                hint="Después de importar, relaciona los grupos AD con los grupos del NSP. El mapeo todavía no aplica bloqueos automáticamente."
            >
                {!directory?.success ? (
                    <div className="ad-empty">
                        <span>Sin directorio cargado</span>
                        <p>Configura la conexión, pruébala y pulsa “Importar desde AD”.</p>
                    </div>
                ) : (
                    <>
                        <div className="ad-directory-summary">
                            <span>{adGroups.length} grupos AD</span>
                            <span>{adComputers.length} equipos AD</span>
                            <span>{directory.matched || 0} coinciden con el NSP</span>
                            <span>{mappedCount} mapeados</span>
                        </div>

                        {adGroups.length === 0 ? (
                            <p className="org-section-hint">No se encontraron grupos en la Base DN configurada.</p>
                        ) : (
                            <div className="ad-mapping-list">
                                {adGroups.map((adGroup) => {
                                    const mapped = (directory.mappings || []).find(
                                        (item) => item.ad_group_dn === adGroup.dn
                                    );

                                    return (
                                        <div key={adGroup.dn} className="ad-mapping-row">
                                            <div>
                                                <strong>{adGroup.name}</strong>
                                                <small>{adGroup.members} miembros · {adGroup.dn}</small>
                                            </div>
                                            {mapped ? (
                                                <div className="ad-mapping-current">
                                                    <span>{mapped.nsp_group}</span>
                                                    <button type="button" onClick={() => removeMapping(mapped.id)} disabled={busy}>
                                                        Quitar
                                                    </button>
                                                </div>
                                            ) : (
                                                <div className="ad-mapping-controls">
                                                    <select
                                                        value={mappingDrafts[adGroup.dn] || ""}
                                                        onChange={(e) => setMappingDrafts((prev) => ({
                                                            ...prev,
                                                            [adGroup.dn]: e.target.value,
                                                        }))}
                                                    >
                                                        <option value="">Grupo NSP…</option>
                                                        {groups.map((group) => (
                                                            <option key={group.id} value={group.id}>{group.name}</option>
                                                        ))}
                                                    </select>
                                                    <button type="button" onClick={() => mapGroup(adGroup)} disabled={busy}>
                                                        Mapear
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        )}

                        <details className="ad-computers">
                            <summary>Ver equipos AD ({adComputers.length})</summary>
                            <div className="ad-computer-list">
                                {adComputers.slice(0, 200).map((computer) => (
                                    <div key={computer.dn} className="ad-computer-row">
                                        <span>{computer.name || computer.hostname}</span>
                                        <small>
                                            {computer.matched_device
                                                ? `NSP: ${computer.matched_device}`
                                                : "Sin coincidencia en NSP"}
                                        </small>
                                        {computer.ad_groups?.length > 0 && (
                                            <small>{computer.ad_groups.join(", ")}</small>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </details>
                    </>
                )}
            </SettingsBlock>
        </SettingsPanel>
    );
}
