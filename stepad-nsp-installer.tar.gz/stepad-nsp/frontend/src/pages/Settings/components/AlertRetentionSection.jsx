import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";
import {
    getRetentionSettings,
    saveRetentionSetting,
} from "../../../services/api";
import { formatDateTime } from "../../../utils/datetime";

const OPTION_LABELS = {
    30: "1 mes",
    60: "2 meses",
    90: "3 meses",
    120: "4 meses",
    150: "5 meses",
    180: "6 meses",
    270: "9 meses",
    365: "12 meses",
    0: "No eliminar",
};

function AlertRetentionSection() {
    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";
    const [row, setRow] = useState(null);
    const [days, setDays] = useState(180);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    function apply(data) {
        const item = (data || []).find((entry) => entry.key === "alerts");

        setRow(item || null);

        if (item) setDays(item.retention_days);
    }

    useEffect(() => {
        let cancelled = false;

        getRetentionSettings()
            .then((data) => {
                if (!cancelled) apply(data);
            })
            .catch((err) => {
                if (!cancelled) setError(err.message);
            })
            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => {
            cancelled = true;
        };
    }, []);

    async function handleSave() {
        setError(null);
        setNotice(null);
        setSaving(true);

        try {
            await saveRetentionSetting("alerts", {
                retention_days: Number(days),
            });

            const data = await getRetentionSettings();

            apply(data);
            setNotice("Retención de alertas guardada.");
        } catch (err) {
            setError(err.message);
        } finally {
            setSaving(false);
        }
    }

    return (
        <div className="notify-section">
            <h4>Eliminación automática de alertas</h4>

            <p className="notify-lead">
                Las alertas <strong>leídas</strong> se eliminan automáticamente
                al cumplir el plazo. Las pendientes se conservan para no ocultar
                incidentes sin revisar.
            </p>

            {loading ? (
                <p className="notify-readonly">Cargando…</p>
            ) : row ? (
                <>
                    <div className="notify-form-grid">
                        <label>
                            Conservar alertas leídas
                            <select
                                value={days}
                                disabled={!isAdmin || saving}
                                onChange={(e) => setDays(Number(e.target.value))}
                            >
                                {(row.options_days || []).map((option) => (
                                    <option key={option} value={option}>
                                        {OPTION_LABELS[option] || `${option} días`}
                                    </option>
                                ))}
                            </select>
                            <span className="notify-field-hint">
                                {Number(row.rows || 0).toLocaleString("es-AR")} alertas guardadas
                                {row.last_run_at
                                    ? ` · último borrado ${formatDateTime(row.last_run_at)}`
                                    : ""}
                            </span>
                        </label>
                    </div>

                    {error && <div className="maintenance-error">{error}</div>}
                    {notice && <div className="notification-ok">{notice}</div>}

                    <div className="notify-actions">
                        <button
                            type="button"
                            className="primary-button"
                            onClick={handleSave}
                            disabled={!isAdmin || saving || days === row.retention_days}
                        >
                            {saving ? "Guardando…" : "Guardar retención"}
                        </button>
                    </div>
                </>
            ) : (
                <p className="org-warning-banner">
                    No se encontró la política de retención de alertas.
                </p>
            )}
        </div>
    );
}

export default AlertRetentionSection;
