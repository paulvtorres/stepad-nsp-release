import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getAlertNotificationSettings,
    saveAlertNotificationSettings,
    testCriticalAlertEmail,
} from "../../../services/api";
import AlertRetentionSection from "./AlertRetentionSection";

import "../settings.css";


function AlertNotificationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        alert_subject: "",
        alert_email_enabled: true,
        alert_emails: "",
        alert_cc_emails: "",
        alert_bcc_emails: "",
        alert_escalation_enabled: false,
        alert_escalation_minutes: 30,
        alert_escalation_emails: "",
        alert_escalation_cc_emails: "",
        alert_escalation_bcc_emails: "",
        security_dns_alert_enabled: true,
        security_dns_alert_emails: "",
        security_dns_alert_cc_emails: "",
        security_dns_alert_bcc_emails: "",
    });

    const [subjectDefaults, setSubjectDefaults] = useState({
        alert: "",
        alertVars: [],
    });

    const [status, setStatus] = useState({
        config_ready: false,
        config_issues: [],
        email_config_ready: false,
        email_provider_label: "",
        email_account: "",
    });

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [saving, setSaving] = useState(false);
    const [testing, setTesting] = useState(false);


    function applySettings(data) {

        setForm({
            alert_subject: data.alert_subject || "",
            alert_email_enabled: data.alert_email_enabled ?? true,
            alert_emails: data.alert_emails || "",
            alert_cc_emails: data.alert_cc_emails || "",
            alert_bcc_emails: data.alert_bcc_emails || "",
            alert_escalation_enabled: data.alert_escalation_enabled ?? false,
            alert_escalation_minutes: data.alert_escalation_minutes ?? 30,
            alert_escalation_emails: data.alert_escalation_emails || "",
            alert_escalation_cc_emails: data.alert_escalation_cc_emails || "",
            alert_escalation_bcc_emails: data.alert_escalation_bcc_emails || "",
            security_dns_alert_enabled: data.security_dns_alert_enabled ?? true,
            security_dns_alert_emails: data.security_dns_alert_emails || "",
            security_dns_alert_cc_emails: data.security_dns_alert_cc_emails || "",
            security_dns_alert_bcc_emails: data.security_dns_alert_bcc_emails || "",
        });

        setSubjectDefaults({
            alert: data.alert_subject_default || "",
            alertVars: data.alert_subject_variables || [],
        });

        setStatus({
            config_ready: Boolean(data.config_ready),
            config_issues: data.config_issues || [],
            email_config_ready: Boolean(data.email_config_ready),
            email_provider_label: data.email_provider_label || "",
            email_account: data.email_account || "",
        });

    }


    useEffect(() => {

        let cancelled = false;

        getAlertNotificationSettings()

            .then((data) => {
                if (!cancelled) applySettings(data);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    function payloadFrom(nextForm = form) {

        return {
            alert_subject: nextForm.alert_subject,
            alert_email_enabled: nextForm.alert_email_enabled,
            alert_emails: nextForm.alert_emails,
            alert_cc_emails: nextForm.alert_cc_emails,
            alert_bcc_emails: nextForm.alert_bcc_emails,
            alert_escalation_enabled: nextForm.alert_escalation_enabled,
            alert_escalation_minutes: Number(nextForm.alert_escalation_minutes),
            alert_escalation_emails: nextForm.alert_escalation_emails,
            alert_escalation_cc_emails: nextForm.alert_escalation_cc_emails,
            alert_escalation_bcc_emails: nextForm.alert_escalation_bcc_emails,
            security_dns_alert_enabled: nextForm.security_dns_alert_enabled,
            security_dns_alert_emails: nextForm.security_dns_alert_emails,
            security_dns_alert_cc_emails: nextForm.security_dns_alert_cc_emails,
            security_dns_alert_bcc_emails: nextForm.security_dns_alert_bcc_emails,
        };

    }


    async function handleCriticalTest() {
        setTesting(true);
        setError(null);
        setNotice(null);
        try {
            const result = await testCriticalAlertEmail();
            if (result?.success) {
                setNotice(result.message || "Correo de prueba enviado.");
            } else {
                setError(result?.message || "No se pudo enviar la prueba.");
            }
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo enviar la prueba.");
        } finally {
            setTesting(false);
        }
    }

    async function handleSave(nextForm) {

        const data = (
            nextForm
            && typeof nextForm === "object"
            && "alert_emails" in nextForm
        ) ? nextForm : form;

        setError(null);

        setNotice(null);

        setSaving(true);

        try {

            const saved = await saveAlertNotificationSettings(payloadFrom(data));

            applySettings(saved);

            setNotice("Configuración de alertas por correo guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setSaving(false);

        }

    }


    const alertRecipientCount = form.alert_emails
        .split(",")
        .map((email) => email.trim())
        .filter(Boolean).length;

    const dnsRecipientCount = form.security_dns_alert_emails
        .split(",")
        .map((email) => email.trim())
        .filter(Boolean).length;


    return (

        <div className="notify-panel">

            <div className="notify-header">

                <div>

                    <h3>Alertas por correo</h3>

                    <p className="notify-lead">

                        Correos <strong>inmediatos</strong> ante alertas
                        críticas del panel. No tienen horario ni frecuencia:
                        se envían en el momento del incidente. Es independiente
                        del reporte de navegación (pestaña{" "}
                        <strong>Navegación</strong>).

                    </p>

                </div>

            </div>


            <div style={{ margin: "8px 0 12px" }}>
                <button
                    type="button"
                    className="secondary-button"
                    onClick={handleCriticalTest}
                    disabled={testing || !isAdmin}
                >
                    {testing ? "Enviando prueba…" : "Probar alerta crítica por correo"}
                </button>
            </div>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}


            {
                !status.email_config_ready && (
                    <div className="org-warning-banner">
                        Configure la cuenta de correo en{" "}
                        <strong>Ajustes → Correo</strong> antes de activar
                        alertas por correo.
                    </div>
                )
            }


            <div className="notify-status-grid">

                <div className={`notify-status-card ${status.config_ready ? "ok" : "warn"}`}>
                    <span className="notify-status-label">Listo para alertar</span>
                    <strong>{status.config_ready ? "Sí" : "No"}</strong>
                    <span className="notify-status-meta">
                        {status.config_ready
                            ? `${alertRecipientCount} críticas, ${dnsRecipientCount} DNS`
                            : (status.config_issues || []).join(", ") || "Revise correo y destinatarios"}
                    </span>
                </div>

                <div className={`notify-status-card ${status.email_config_ready ? "ok" : "warn"}`}>
                    <span className="notify-status-label">Cuenta de correo</span>
                    <strong>{status.email_config_ready ? "Configurada" : "Pendiente"}</strong>
                    <span className="notify-status-meta">
                        {status.email_account
                            ? `${status.email_provider_label}: ${status.email_account}`
                            : "Ajustes → Correo"}
                    </span>
                </div>

            </div>


            <div className="notify-section notify-priority-section">

                <h4>
                    Alertas críticas del sistema
                    <span className="notify-priority-badge">Críticas</span>
                </h4>

                <p className="notify-lead">
                    IPS, caída de internet, DHCP, componentes caídos, etc.
                    Solo severidad <strong>crítica</strong>.
                </p>

                <div className="notify-form-grid">

                    <label className={`notify-master-toggle ${form.alert_email_enabled ? "on" : ""}`}>
                        <input
                            type="checkbox"
                            checked={form.alert_email_enabled}
                            disabled={!isAdmin || saving}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    alert_email_enabled: e.target.checked,
                                })
                            }
                        />
                        <span>
                            {form.alert_email_enabled ? "Activo" : "Inactivo"}
                        </span>
                    </label>

                    <label className="notify-wide">
                        Para
                        <input
                            type="text"
                            value={form.alert_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    alert_emails: e.target.value,
                                })
                            }
                            placeholder="ti@empresa.com, noc@empresa.com"
                        />
                    </label>

                    <label>
                        CC
                        <input
                            type="text"
                            value={form.alert_cc_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    alert_cc_emails: e.target.value,
                                })
                            }
                            placeholder="gerencia@empresa.com"
                        />
                    </label>

                    <label>
                        CCO
                        <input
                            type="text"
                            value={form.alert_bcc_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    alert_bcc_emails: e.target.value,
                                })
                            }
                            placeholder="auditoria@empresa.com"
                        />
                    </label>

                    <label className="notify-wide">
                        Asunto
                        <input
                            type="text"
                            value={form.alert_subject}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, alert_subject: e.target.value })
                            }
                            placeholder={subjectDefaults.alert}
                        />
                        <span className="notify-field-hint">
                            Variables: {(subjectDefaults.alertVars || [])
                                .map((v) => `{${v}}`)
                                .join(", ")}
                        </span>
                    </label>

                </div>

            </div>


            <div className="notify-section">

                <h4>Escalamiento de alertas críticas</h4>

                <p className="notify-lead">
                    Si una alerta crítica sigue sin resolverse, se envía a
                    esta lista después del tiempo configurado.
                </p>

                <div className="notify-form-grid">

                    <label className={`notify-master-toggle ${form.alert_escalation_enabled ? "on" : ""}`}>
                        <input
                            type="checkbox"
                            checked={form.alert_escalation_enabled}
                            disabled={!isAdmin || saving}
                            onChange={(e) => setForm({
                                ...form,
                                alert_escalation_enabled: e.target.checked,
                            })}
                        />
                        <span>{form.alert_escalation_enabled ? "Activo" : "Inactivo"}</span>
                    </label>

                    <label>
                        Minutos sin resolver
                        <input
                            type="number"
                            min={1}
                            max={1440}
                            value={form.alert_escalation_minutes}
                            disabled={!isAdmin}
                            onChange={(e) => setForm({
                                ...form,
                                alert_escalation_minutes: e.target.value,
                            })}
                        />
                    </label>

                    <label className="notify-wide">
                        Para
                        <input
                            type="text"
                            value={form.alert_escalation_emails}
                            disabled={!isAdmin}
                            onChange={(e) => setForm({
                                ...form,
                                alert_escalation_emails: e.target.value,
                            })}
                            placeholder="gerencia@empresa.com, noc@empresa.com"
                        />
                    </label>

                    <label>
                        CC
                        <input
                            type="text"
                            value={form.alert_escalation_cc_emails}
                            disabled={!isAdmin}
                            onChange={(e) => setForm({
                                ...form,
                                alert_escalation_cc_emails: e.target.value,
                            })}
                        />
                    </label>

                    <label>
                        CCO
                        <input
                            type="text"
                            value={form.alert_escalation_bcc_emails}
                            disabled={!isAdmin}
                            onChange={(e) => setForm({
                                ...form,
                                alert_escalation_bcc_emails: e.target.value,
                            })}
                        />
                    </label>

                </div>

            </div>


            <div className="notify-section notify-priority-section">

                <h4>
                    Alertas DNS — malware / phishing
                    <span className="notify-priority-badge">Críticas</span>
                </h4>

                <p className="notify-lead">
                    Intento repetido contra dominios bloqueados del feed.
                    Incluye script de diagnóstico de intrusos adjunto.
                </p>

                <div className="notify-form-grid">

                    <label className={`notify-master-toggle ${form.security_dns_alert_enabled ? "on" : ""}`}>
                        <input
                            type="checkbox"
                            checked={form.security_dns_alert_enabled}
                            disabled={!isAdmin || saving}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    security_dns_alert_enabled: e.target.checked,
                                })
                            }
                        />
                        <span>
                            {form.security_dns_alert_enabled ? "Activo" : "Inactivo"}
                        </span>
                    </label>

                    <label className="notify-wide">
                        Para
                        <input
                            type="text"
                            value={form.security_dns_alert_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    security_dns_alert_emails: e.target.value,
                                })
                            }
                            placeholder="ti@empresa.com, seguridad@empresa.com"
                        />
                    </label>

                    <label>
                        CC
                        <input
                            type="text"
                            value={form.security_dns_alert_cc_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    security_dns_alert_cc_emails: e.target.value,
                                })
                            }
                            placeholder="gerencia@empresa.com"
                        />
                    </label>

                    <label>
                        CCO
                        <input
                            type="text"
                            value={form.security_dns_alert_bcc_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    security_dns_alert_bcc_emails: e.target.value,
                                })
                            }
                            placeholder="auditoria@empresa.com"
                        />
                    </label>

                </div>

            </div>


            <AlertRetentionSection />

            <div className="notify-actions">

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={saving || !isAdmin}
                >
                    {saving ? "Guardando..." : "Guardar alertas"}
                </button>

            </div>

            {!isAdmin && (
                <p className="notify-readonly">Solo administradores pueden modificar esta sección.</p>
            )}

        </div>

    );

}


export default AlertNotificationSection;
