import { getToken } from "./authStorage";


const API_URL = "/api/v1";


export async function getCurrentUser() {


    const response = await fetch(

        `${API_URL}/auth/me`,

        {
            headers: {

                Authorization:
                    `Bearer ${getToken()}`

            }

        }

    );


    if (!response.ok) {

        throw new Error(
            "Error loading current user"
        );

    }


    return response.json();

}