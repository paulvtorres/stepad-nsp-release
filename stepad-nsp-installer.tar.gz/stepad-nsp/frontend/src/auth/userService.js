import { getToken } from "./authStorage";


const API_URL = "/api/v1";


export async function getCurrentUser() {


    const token = getToken();

    const response = await fetch(

        `${API_URL}/auth/me`,

        {
            // La sesión va en la cookie HttpOnly; el header solo se
            // envía si quedó un token legacy en localStorage.
            credentials: "same-origin",

            headers: token
                ? { Authorization: `Bearer ${token}` }
                : {}

        }

    );


    if (!response.ok) {

        throw new Error(
            "Error loading current user"
        );

    }


    return response.json();

}