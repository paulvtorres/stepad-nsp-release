export async function login(
    username,
    password
) {

    const response = await fetch(

        "/api/v1/auth/login",

        {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({

                username,
                password

            })

        }

    );

    const data = await response.json();

    if (!response.ok || !data.success) {

        throw new Error(

            data.message || "Login failed"

        );

    }

    return data;

}