import {
    useState,
    useEffect
} from "react";


import { AuthContext } from "./authContextStore";


import {
    getToken,
    saveToken,
    removeToken
} from "./authStorage";


import {
    getCurrentUser
} from "./userService";

import { subscribeAuthExpired } from "./authEvents";



export function AuthProvider({ children }) {


    const [token, setToken] = useState(
        getToken()
    );


    const [user, setUser] = useState(null);

    const [passwordExpired, setPasswordExpired] = useState(false);

    const [mfaEnabled, setMfaEnabled] = useState(false);

    const [mfaMandatory, setMfaMandatory] = useState(false);

    const [mfaSetupRequired, setMfaSetupRequired] = useState(false);



    useEffect(() => {


        async function loadUser() {


            if (!token) {

                return;

            }


            try {


                const response =
                    await getCurrentUser();


                setUser(
                    response.user
                );

                setPasswordExpired(
                    response.password_expired || false
                );

                setMfaEnabled(
                    response.mfa_enabled || false
                );

                setMfaMandatory(
                    response.mfa_mandatory || false
                );

                setMfaSetupRequired(
                    response.mfa_setup_required || false
                );


            }
            catch {

                logout();


            }


        }


        loadUser();


    }, [token]);


    useEffect(() => {

        return subscribeAuthExpired(() => {

            logout();

        });

    }, []);

    function login(accessToken) {


        saveToken(
            accessToken
        );


        setToken(
            accessToken
        );

    }



    function logout() {


        removeToken();

        setToken(null);

        setUser(null);

        setPasswordExpired(false);

        setMfaEnabled(false);

        setMfaMandatory(false);

        setMfaSetupRequired(false);

    }



    return (

        <AuthContext.Provider

            value={{

                token,

                user,

                passwordExpired,

                mfaEnabled,

                mfaMandatory,

                mfaSetupRequired,

                setMfaEnabled,

                setMfaSetupRequired,

                login,

                logout,

                isAuthenticated:
                    !!token

            }}

        >

            {children}

        </AuthContext.Provider>

    );

}
