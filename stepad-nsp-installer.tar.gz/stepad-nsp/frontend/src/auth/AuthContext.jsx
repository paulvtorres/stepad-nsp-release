import {
    useState,
    useEffect
} from "react";


import { AuthContext } from "./authContextStore";


import {
    hasSession,
    markSession,
    clearSession,
    removeToken
} from "./authStorage";


import {
    getCurrentUser
} from "./userService";

import { logoutRequest } from "./authService";

import { subscribeAuthExpired } from "./authEvents";



export function AuthProvider({ children }) {


    const [authenticated, setAuthenticated] = useState(
        hasSession()
    );


    const [user, setUser] = useState(null);

    const [passwordExpired, setPasswordExpired] = useState(false);

    const [mfaEnabled, setMfaEnabled] = useState(false);

    const [mfaMandatory, setMfaMandatory] = useState(false);

    const [mfaSetupRequired, setMfaSetupRequired] = useState(false);



    useEffect(() => {


        async function loadUser() {


            if (!authenticated) {

                return;

            }


            try {


                const response =
                    await getCurrentUser();


                setUser(
                    response.user
                );

                setPasswordExpired(
                    response.password_expired || false
                );

                setMfaEnabled(
                    response.mfa_enabled || false
                );

                setMfaMandatory(
                    response.mfa_mandatory || false
                );

                setMfaSetupRequired(
                    response.mfa_setup_required || false
                );


            }
            catch {

                logout();


            }


        }


        loadUser();


    }, [authenticated]);


    useEffect(() => {

        return subscribeAuthExpired(() => {

            logout();

        });

    }, []);

    function login() {

        // El token lo guarda el navegador en la cookie HttpOnly que
        // devuelve /auth/login: el JS nunca lo ve.
        markSession();

        setAuthenticated(true);

    }



    function logout() {


        removeToken();

        clearSession();

        setAuthenticated(false);

        // Invalidar también la cookie en el servidor (best-effort).
        logoutRequest().catch(() => {});

        setUser(null);

        setPasswordExpired(false);

        setMfaEnabled(false);

        setMfaMandatory(false);

        setMfaSetupRequired(false);

    }



    return (

        <AuthContext.Provider

            value={{

                user,

                passwordExpired,

                mfaEnabled,

                mfaMandatory,

                mfaSetupRequired,

                setMfaEnabled,

                setMfaSetupRequired,

                login,

                logout,

                isAuthenticated:
                    authenticated

            }}

        >

            {children}

        </AuthContext.Provider>

    );

}
