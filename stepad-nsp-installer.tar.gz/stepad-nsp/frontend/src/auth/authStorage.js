const TOKEN_KEY = "stepad_token";


export function saveToken(token) {

    localStorage.setItem(
        TOKEN_KEY,
        token
    );

}


export function getToken() {

    return localStorage.getItem(
        TOKEN_KEY
    );

}


export function removeToken() {

    localStorage.removeItem(
        TOKEN_KEY
    );

}


// La sesión vive en una cookie HttpOnly (no legible por JS). Esta bandera
// solo indica "había sesión iniciada" para no pedir login en cada carga;
// si la cookie expiró, la primera llamada a la API devuelve 401 y el
// AuthContext cierra la sesión.
const SESSION_KEY = "stepad_session_active";


export function markSession() {

    localStorage.setItem(
        SESSION_KEY,
        "1"
    );

}


export function clearSession() {

    localStorage.removeItem(
        SESSION_KEY
    );

}


export function hasSession() {

    return (
        localStorage.getItem(SESSION_KEY) === "1"
        || !!getToken()
    );

}


export function isAuthenticated() {

    return hasSession();

}