import { useState, useRef } from "react";

import { login as loginRequest } from "./authService";

import { loginMfa } from "../services/api";

import { useAuth } from "./useAuth";

import { useNavigate } from "react-router-dom";


function Login() {

    const [username, setUsername] = useState("");

    const [password, setPassword] = useState("");

    const [showPassword, setShowPassword] = useState(false);

    const [mfaToken, setMfaToken] = useState(null);

    const [mfaCode, setMfaCode] = useState("");

    const [error, setError] = useState(null);

    const codeRef = useRef(null);

    const { login } = useAuth();

    const navigate = useNavigate();


    function finish(result) {

        login(result.access_token);

        navigate(
            result.password_expired
                ? "/change-password"
                : result.mfa_setup_required
                    ? "/settings"
                    : "/"
        );

    }


    async function handleSubmit(event) {

        event.preventDefault();

        setError(null);

        if (mfaToken) {

            try {

                const result = await loginMfa(
                    mfaToken,
                    mfaCode.trim()
                );

                finish(result);

            } catch (error) {

                setError(error.message);

            }

            return;

        }

        try {

            const result = await loginRequest(
                username,
                password
            );

            if (result.mfa_required) {

                setMfaToken(result.mfa_token);

                setPassword("");

                setTimeout(
                    () => codeRef.current && codeRef.current.focus(),
                    0
                );

                return;

            }

            finish(result);

        } catch (error) {

            setError(error.message);

        }

    }


    return (

        <div className="login-container">

            <form
                className="login-form"
                onSubmit={handleSubmit}
            >

                <h2>STEPAD NSP</h2>

                <p className="login-subtitle">

                    Network Security Platform

                </p>

                {
                    !mfaToken ? (
                        <>
                            <div>

                                <label>
                                    Usuario
                                </label>

                                <input
                                    type="text"
                                    value={username}
                                    onChange={(e) =>
                                        setUsername(
                                            e.target.value
                                        )
                                    }
                                    autoFocus
                                />

                            </div>

                            <div>

                                <label>
                                    Contraseña
                                </label>

                                <div className="password-wrap">

                                    <input
                                        type={showPassword ? "text" : "password"}
                                        value={password}
                                        onChange={(e) =>
                                            setPassword(
                                                e.target.value
                                            )
                                        }
                                    />

                                    <button
                                        type="button"
                                        className="password-toggle"
                                        onClick={() =>
                                            setShowPassword(
                                                (shown) => !shown
                                            )
                                        }
                                        title={
                                            showPassword
                                                ? "Ocultar contraseña"
                                                : "Mostrar contraseña"
                                        }
                                        aria-label={
                                            showPassword
                                                ? "Ocultar contraseña"
                                                : "Mostrar contraseña"
                                        }
                                    >
                                        {
                                            showPassword ? (
                                                <svg
                                                    width="18"
                                                    height="18"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    stroke="currentColor"
                                                    strokeWidth="2"
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                >
                                                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                                                    <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                                                    <line x1="1" y1="1" x2="23" y2="23" />
                                                </svg>
                                            ) : (
                                                <svg
                                                    width="18"
                                                    height="18"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    stroke="currentColor"
                                                    strokeWidth="2"
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                >
                                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                                    <circle cx="12" cy="12" r="3" />
                                                </svg>
                                            )
                                        }
                                    </button>

                                </div>

                            </div>
                        </>
                    ) : (
                        <>
                            <p className="login-subtitle">

                                Introduce el código de tu app

                                de autenticación.

                            </p>

                            <div>

                                <label>
                                    Código de verificación
                                </label>

                                <input
                                    type="text"
                                    inputMode="numeric"
                                    value={mfaCode}
                                    onChange={(e) =>
                                        setMfaCode(
                                            e.target.value
                                        )
                                    }
                                    ref={codeRef}
                                    autoFocus
                                    placeholder="123456"
                                />

                            </div>
                        </>
                    )
                }

                {
                    error && (
                        <div className="users-error">
                            {error}
                        </div>
                    )
                }

                <button type="submit">

                    {mfaToken ? "Verificar" : "Iniciar sesión"}

                </button>

            </form>

        </div>

    );

}


export default Login;