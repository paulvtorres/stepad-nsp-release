import { useState, useRef } from "react";

import { login as loginRequest } from "./authService";

import { loginMfa } from "../services/api";

import { useAuth } from "./useAuth";

import { useNavigate } from "react-router-dom";


function Login() {

    const [username, setUsername] = useState("");

    const [password, setPassword] = useState("");

    const [mfaToken, setMfaToken] = useState(null);

    const [mfaCode, setMfaCode] = useState("");

    const [error, setError] = useState(null);

    const codeRef = useRef(null);

    const { login } = useAuth();

    const navigate = useNavigate();


    function finish(result) {

        login(result.access_token);

        navigate(
            result.password_expired
                ? "/change-password"
                : result.mfa_setup_required
                    ? "/settings"
                    : "/"
        );

    }


    async function handleSubmit(event) {

        event.preventDefault();

        setError(null);

        if (mfaToken) {

            try {

                const result = await loginMfa(
                    mfaToken,
                    mfaCode.trim()
                );

                finish(result);

            } catch (error) {

                setError(error.message);

            }

            return;

        }

        try {

            const result = await loginRequest(
                username,
                password
            );

            if (result.mfa_required) {

                setMfaToken(result.mfa_token);

                setPassword("");

                setTimeout(
                    () => codeRef.current && codeRef.current.focus(),
                    0
                );

                return;

            }

            finish(result);

        } catch (error) {

            setError(error.message);

        }

    }


    return (

        <div className="login-container">

            <form
                className="login-form"
                onSubmit={handleSubmit}
            >

                <h2>STEPAD NSP</h2>

                <p className="login-subtitle">

                    Network Security Platform

                </p>

                {
                    !mfaToken ? (
                        <>
                            <div>

                                <label>
                                    Usuario
                                </label>

                                <input
                                    type="text"
                                    value={username}
                                    onChange={(e) =>
                                        setUsername(
                                            e.target.value
                                        )
                                    }
                                    autoFocus
                                />

                            </div>

                            <div>

                                <label>
                                    Contraseña
                                </label>

                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) =>
                                        setPassword(
                                            e.target.value
                                        )
                                    }
                                />

                            </div>
                        </>
                    ) : (
                        <>
                            <p className="login-subtitle">

                                Introduce el código de tu app

                                de autenticación.

                            </p>

                            <div>

                                <label>
                                    Código de verificación
                                </label>

                                <input
                                    type="text"
                                    inputMode="numeric"
                                    value={mfaCode}
                                    onChange={(e) =>
                                        setMfaCode(
                                            e.target.value
                                        )
                                    }
                                    ref={codeRef}
                                    autoFocus
                                    placeholder="123456"
                                />

                            </div>
                        </>
                    )
                }

                {
                    error && (
                        <div className="users-error">
                            {error}
                        </div>
                    )
                }

                <button type="submit">

                    {mfaToken ? "Verificar" : "Iniciar sesión"}

                </button>

            </form>

        </div>

    );

}


export default Login;