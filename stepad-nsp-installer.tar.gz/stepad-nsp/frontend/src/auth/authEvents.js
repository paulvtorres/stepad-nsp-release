const listeners = [];

export function subscribeAuthExpired(callback) {

    listeners.push(callback);

    return () => {

        const index = listeners.indexOf(callback);

        if (index >= 0) {

            listeners.splice(index, 1);

        }

    };

}

export function notifyAuthExpired() {

    listeners.forEach(callback => callback());

}