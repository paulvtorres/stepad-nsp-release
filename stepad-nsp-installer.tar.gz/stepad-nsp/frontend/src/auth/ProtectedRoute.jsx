import { Navigate, Outlet } from "react-router-dom";

import { useAuth } from "./useAuth";


function ProtectedRoute() {


    const { isAuthenticated, passwordExpired, mfaSetupRequired } = useAuth();


    if (!isAuthenticated) {

        return (
            <Navigate
                to="/login"
                replace
            />
        );

    }

    if (passwordExpired) {

        return (
            <Navigate
                to="/change-password"
                replace
            />
        );

    }

    if (mfaSetupRequired) {

        return (
            <Navigate
                to="/settings"
                replace
            />
        );

    }

    return <Outlet />;

}


export default ProtectedRoute;