import { useState } from "react";

import { useNavigate } from "react-router-dom";

import { changePassword } from "../services/api";


const PASSWORD_POLICY = [
    { label: "Mínimo 8 caracteres", test: (v) => v.length >= 8 },
    { label: "Una letra mayúscula", test: (v) => /[A-Z]/.test(v) },
    { label: "Una letra minúscula", test: (v) => /[a-z]/.test(v) },
    { label: "Un número", test: (v) => /\d/.test(v) },
    { label: "Un carácter especial", test: (v) => /[^A-Za-z0-9]/.test(v) }
];


function ChangePassword() {

    const [form, setForm] = useState({
        current: "",
        password: "",
        confirm: ""
    });

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);

    const navigate = useNavigate();

    const setField = (field) => (e) =>
        setForm({ ...form, [field]: e.target.value });


    async function handleSubmit(event) {

        event.preventDefault();

        setError(null);

        if (form.password !== form.confirm) {

            setError("Las contraseñas no coinciden.");

            return;

        }

        const failedRules = PASSWORD_POLICY.filter(
            (rule) => !rule.test(form.password)
        );

        if (failedRules.length) {

            setError(
                "La contraseña debe cumplir: "
                + failedRules.map((rule) => rule.label).join(", ")
            );

            return;

        }

        setBusy(true);

        try {

            await changePassword(
                form.current,
                form.password
            );

            navigate("/");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="login-container">

            <form
                className="login-form"
                onSubmit={handleSubmit}
            >

                <h2>Cambiar contraseña</h2>

                <p className="login-subtitle">

                    Tu contraseña ha caducado o quieres renovarla.

                </p>

                <div>

                    <label>
                        Contraseña actual
                    </label>

                    <input
                        type="password"
                        value={form.current}
                        onChange={setField("current")}
                        placeholder="••••••••"
                    />

                </div>

                <div>

                    <label>
                        Nueva contraseña
                    </label>

                    <input
                        type="password"
                        value={form.password}
                        onChange={setField("password")}
                        placeholder="••••••••"
                    />

                </div>

                {
                    form.password && (
                        <ul className="password-rules">
                            {
                                PASSWORD_POLICY.map((rule) => {
                                    const ok = rule.test(form.password);
                                    return (
                                        <li
                                            key={rule.label}
                                            className={ok ? "rule-ok" : "rule-missing"}
                                        >
                                            {ok ? "✓" : "✗"} {rule.label}
                                        </li>
                                    );
                                })
                            }
                        </ul>
                    )
                }

                <div>

                    <label>
                        Repetir nueva contraseña
                    </label>

                    <input
                        type="password"
                        value={form.confirm}
                        onChange={setField("confirm")}
                        placeholder="••••••••"
                    />

                </div>

                {
                    error && (
                        <div className="users-error">
                            {error}
                        </div>
                    )
                }

                <button
                    type="submit"
                    disabled={busy}
                >

                    {busy ? "Guardando..." : "Cambiar contraseña"}

                </button>

            </form>

        </div>

    );

}


export default ChangePassword;
