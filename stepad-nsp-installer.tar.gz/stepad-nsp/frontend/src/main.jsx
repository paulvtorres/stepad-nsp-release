import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";

import "./styles/theme.css";
import "./index.css";
import "./components/layout/MainLayout.css";
import App from "./App";
import "./styles/login.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthProvider>

      <BrowserRouter>

        <App />

      </BrowserRouter>

    </AuthProvider>
  </React.StrictMode>
);