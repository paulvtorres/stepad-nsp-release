export const ScopeType = Object.freeze({
    GLOBAL: "GLOBAL",
    ZONE: "ZONE",
    DEVICE: "DEVICE",
});