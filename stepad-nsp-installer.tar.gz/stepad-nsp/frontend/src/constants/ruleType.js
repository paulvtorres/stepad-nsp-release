export const RuleType = Object.freeze({

    DOMAIN: "DOMAIN",

    IP: "IP",

    MAC: "MAC",

    URL: "URL",

    PORT: "PORT",

});