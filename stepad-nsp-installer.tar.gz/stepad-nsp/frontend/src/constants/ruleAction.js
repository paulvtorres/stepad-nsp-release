export const RuleAction = Object.freeze({

    BLOCK: "BLOCK",

    ALLOW: "ALLOW",

});