export { RuleAction } from "./ruleAction";
export { RuleType } from "./ruleType";
export { ScopeType } from "./scopeType";

export const INACTIVITY_TIMEOUT_MINUTES = 15;