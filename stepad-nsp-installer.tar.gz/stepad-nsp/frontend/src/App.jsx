import { Routes, Route } from "react-router-dom";

import MainLayout from "./components/layout/MainLayout";

import Dashboard from "./pages/Dashboard/Dashboard";
import Interfaces from "./pages/Network/Interfaces/Interfaces";
import Devices from "./pages/Network/Devices/Devices";
import DeviceDetails from "./pages/Network/Devices/DeviceDetails";
import Zones from "./pages/Network/Zones/Zones";
import Diagram from "./pages/Network/Diagram/Diagram";
import Security from "./pages/Security/Security";
import Vpn from "./pages/Vpn/Vpn";
import Groups from "./pages/Groups/Groups";
import Protection from "./pages/Protection/Protection";
import Logs from "./pages/Logs/Logs";

import LiveNavigation from "./pages/LiveNavigation/LiveNavigation";
import Audit from "./pages/Audit/Audit";

import Alerts from "./pages/Alerts/Alerts";
import Settings from "./pages/Settings/Settings";
import Users from "./pages/Users/Users";
import Hardware from "./pages/Hardware/Hardware";
import Monitoring from "./pages/Monitoring/Monitoring";

import Login from "./auth/Login";
import ChangePassword from "./auth/ChangePassword";
import ProtectedRoute from "./auth/ProtectedRoute";


function App() {

    return (

        <Routes>


            <Route
                path="/login"
                element={<Login />}
            />

            <Route
                path="/change-password"
                element={<ChangePassword />}
            />


            <Route
                element={<ProtectedRoute />}
            >

                <Route
                    path="/"
                    element={<MainLayout />}
                >

                    <Route
                        index
                        element={<Dashboard />}
                    />

                    <Route
                        path="network/interfaces"
                        element={<Interfaces />}
                    />

                    <Route
                        path="network/devices"
                        element={<Devices />}
                    />

                    <Route
                        path="groups"
                        element={<Groups />}
                    />

                    <Route
                        path="network/devices/:deviceId"
                        element={<DeviceDetails />}
                    />

                    <Route
                        path="network/zones"
                        element={<Zones />}
                    />

                    <Route
                        path="network/diagram"
                        element={<Diagram />}
                    />

                    <Route
                        path="security"
                        element={<Security />}
                    />

                    <Route
                        path="vpn"
                        element={<Vpn />}
                    />

                    <Route
                        path="protection"
                        element={<Protection />}
                    />

                    <Route
                        path="logs"
                        element={<Logs />}
                    />

                    <Route
                        path="live-navigation"
                        element={<LiveNavigation />}
                    />

                    <Route
                        path="audit"
                        element={<Audit />}
                    />

                    <Route
                        path="alerts"
                        element={<Alerts />}
                    />

                    <Route
                        path="settings"
                        element={<Settings />}
                    />

                    <Route
                        path="users"
                        element={<Users />}
                    />

                    <Route
                        path="hardware"
                        element={<Hardware />}
                    />

                    <Route
                        path="monitoring"
                        element={<Monitoring />}
                    />

                </Route>

            </Route>


        </Routes>

    );

}


export default App;