import { Suspense, lazy } from "react";

import { Routes, Route } from "react-router-dom";

import MainLayout from "./components/layout/MainLayout";

const Dashboard = lazy(() => import("./pages/Dashboard/Dashboard"));
const Interfaces = lazy(() => import("./pages/Network/Interfaces/Interfaces"));
const Dhcp = lazy(() => import("./pages/Network/Dhcp/Dhcp"));
const Devices = lazy(() => import("./pages/Network/Devices/Devices"));
const DeviceDetails = lazy(() => import("./pages/Network/Devices/DeviceDetails"));
const Zones = lazy(() => import("./pages/Network/Zones/Zones"));
const Diagram = lazy(() => import("./pages/Network/Diagram/Diagram"));
const Security = lazy(() => import("./pages/Security/Security"));
const Vpn = lazy(() => import("./pages/Vpn/Vpn"));
const Rustdesk = lazy(() => import("./pages/Rustdesk/Rustdesk"));
const Shares = lazy(() => import("./pages/Shares/Shares"));
const Backups = lazy(() => import("./pages/Backups/Backups"));
const SystemBackup = lazy(() => import("./pages/SystemBackup/SystemBackup"));
const LoadBalancing = lazy(() => import("./pages/LoadBalancing/LoadBalancing"));
const Groups = lazy(() => import("./pages/Groups/Groups"));
const Protection = lazy(() => import("./pages/Protection/Protection"));
const ExternalAttacks = lazy(() => import("./pages/ExternalAttacks/ExternalAttacks"));
const Egress = lazy(() => import("./pages/Egress/Egress"));
const Bandwidth = lazy(() => import("./pages/Bandwidth/Bandwidth"));
const Logs = lazy(() => import("./pages/Logs/Logs"));

const LiveNavigation = lazy(() => import("./pages/LiveNavigation/LiveNavigation"));
const Audit = lazy(() => import("./pages/Audit/Audit"));

const Alerts = lazy(() => import("./pages/Alerts/Alerts"));
const Quarantine = lazy(() => import("./pages/Quarantine/Quarantine"));

const TopPages = lazy(() => import("./pages/TopPages/TopPages"));
const Settings = lazy(() => import("./pages/Settings/Settings"));
const Users = lazy(() => import("./pages/Users/Users"));
const Hardware = lazy(() => import("./pages/Hardware/Hardware"));
const Monitoring = lazy(() => import("./pages/Monitoring/Monitoring"));
const SystemControl = lazy(() => import("./pages/SystemControl/SystemControl"));

import Login from "./auth/Login";
import ChangePassword from "./auth/ChangePassword";
import ProtectedRoute from "./auth/ProtectedRoute";


function App() {

    return (

        <Suspense
            fallback={
                <div className="app-loading">
                    Cargando…
                </div>
            }
        >

        <Routes>


            <Route
                path="/login"
                element={<Login />}
            />

            <Route
                path="/change-password"
                element={<ChangePassword />}
            />


            <Route
                element={<ProtectedRoute />}
            >

                <Route
                    path="/"
                    element={<MainLayout />}
                >

                    <Route
                        index
                        element={<Dashboard />}
                    />

                    <Route
                        path="network/interfaces"
                        element={<Interfaces />}
                    />

                    <Route
                        path="network/dhcp"
                        element={<Dhcp />}
                    />

                    <Route
                        path="network/devices"
                        element={<Devices />}
                    />

                    <Route
                        path="groups"
                        element={<Groups />}
                    />

                    <Route
                        path="network/devices/:deviceId"
                        element={<DeviceDetails />}
                    />

                    <Route
                        path="network/zones"
                        element={<Zones />}
                    />

                    <Route
                        path="network/diagram"
                        element={<Diagram />}
                    />

                    <Route
                        path="security"
                        element={<Security />}
                    />

                    <Route
                        path="vpn"
                        element={<Vpn />}
                    />

                    <Route
                        path="rustdesk"
                        element={<Rustdesk />}
                    />

                    <Route
                        path="shares"
                        element={<Shares />}
                    />

                    <Route
                        path="backups"
                        element={<Backups />}
                    />

                    <Route
                        path="system-backup"
                        element={<SystemBackup />}
                    />

                    <Route
                        path="load-balancing"
                        element={<LoadBalancing />}
                    />

                    <Route
                    />

                    <Route
                        path="protection"
                        element={<Protection />}
                    />

                    <Route
                        path="external-attacks"
                        element={<ExternalAttacks />}
                    />

                    <Route
                        path="egress"
                        element={<Egress />}
                    />

                    <Route
                        path="bandwidth"
                        element={<Bandwidth />}
                    />

                    <Route
                        path="logs"
                        element={<Logs />}
                    />

                    <Route
                        path="live-navigation"
                        element={<LiveNavigation />}
                    />

                    <Route
                        path="audit"
                        element={<Audit />}
                    />

                    <Route
                        path="alerts"
                        element={<Alerts />}
                    />

                    <Route
                        path="quarantine"
                        element={<Quarantine />}
                    />

                    <Route
                        path="top-pages"
                        element={<TopPages />}
                    />

                    <Route
                        path="settings"
                        element={<Settings />}
                    />

                    <Route
                        path="users"
                        element={<Users />}
                    />

                    <Route
                        path="hardware"
                        element={<Hardware />}
                    />

                    <Route
                        path="monitoring"
                        element={<Monitoring />}
                    />

                    <Route
                        path="account/password"
                        element={<ChangePassword />}
                    />

                    <Route
                        path="system-control"
                        element={<SystemControl />}
                    />

                </Route>

            </Route>


        </Routes>

        </Suspense>

    );

}


export default App;