import { useEffect, useState } from "react";
import { getInterfaceDiagnosis } from "../../services/api";


function NetworkDiagnosis({ refreshKey = 0 }) {

    const [diagnosis, setDiagnosis] = useState(null);


    useEffect(() => {

        async function loadDiagnosis() {

            try {

                const data = await getInterfaceDiagnosis();

                setDiagnosis(data);

            } catch (error) {

                console.error(error);

            }

        }


        loadDiagnosis();

    }, [refreshKey]);



    if (!diagnosis) {

        return (
            <p>
                Cargando diagnóstico...
            </p>
        );

    }



    return (

        <div>

            <h2>
                Estado de red
            </h2>


            <p>

                WAN:

                {
                    diagnosis.wan_detected
                    ? " 🟢 Detectada"
                    : " 🔴 No encontrada"
                }

            </p>


            <p>

                LAN:

                {
                    diagnosis.lan_detected
                    ? " 🟢 Detectada"
                    : " 🔴 No encontrada"
                }

            </p>



            <p>

                Estado del equipo:

                {
                    diagnosis.ready
                    ? " 🟢 Listo para configuración"
                    : " 🟡 Pendiente"
                }

            </p>



            {
                diagnosis.messages.length > 0 && (

                    <div>

                        <h3>
                            Observaciones
                        </h3>


                        {
                            diagnosis.messages.map(
                                (message, index) => (

                                    <p key={index}>
                                        ⚠️ {message}
                                    </p>

                                )
                            )
                        }

                    </div>

                )
            }


        </div>

    );

}


export default NetworkDiagnosis;