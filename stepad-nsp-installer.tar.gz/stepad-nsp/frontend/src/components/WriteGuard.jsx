import { useAuth } from "../auth/useAuth";


function WriteGuard({ children }) {

    const { user } = useAuth();

    if (user?.role !== "ADMIN") {

        return null;

    }

    return children;

}


export default WriteGuard;
