import { useEffect, useState } from "react";

import { Link, useNavigate } from "react-router-dom";

import { useAuth } from "../../auth/useAuth";

import { getPendingInterfaceActions } from "../../services/api";


function TopBar() {

    const navigate = useNavigate();


    const { user, logout } = useAuth();

    const [pendingInterfaces, setPendingInterfaces] = useState([]);

    const [now, setNow] = useState(new Date());

    useEffect(() => {

        const t = setInterval(() => setNow(new Date()), 1000);

        return () => clearInterval(t);

    }, []);


    useEffect(() => {

        async function checkPending() {

            try {

                const pending = await getPendingInterfaceActions();

                setPendingInterfaces(pending || []);

            } catch (error) {

                console.error(error);

            }

        }

        checkPending();

        const interval = setInterval(checkPending, 30000);

        return () => clearInterval(interval);

    }, []);



    return (

        <div className="topbar">


            <div className="brand">

                STEPAD NSP

            </div>



            <div className="status">

                Sistema en línea

                {
                    pendingInterfaces.length > 0 && (

                        <Link
                            to="/network/interfaces"
                            className="interface-alert-badge"
                            title="Hay tarjetas de red que necesitan tu atenci\u00f3n"
                        >

                            ⚠ {pendingInterfaces.length} tarjeta(s) de red requieren atención

                        </Link>

                    )
                }

            </div>



            <div
                className="topbar-clock"
                title="Hora del equipo (según su zona horaria)"
                style={{
                    fontSize: 13,
                    color: "var(--muted)",
                    marginRight: 12,
                    whiteSpace: "nowrap"
                }}
            >
                {now.toLocaleDateString("es-ES", { weekday: "short", day: "2-digit", month: "short" })}{" "}
                {now.toLocaleTimeString("es-ES")}
            </div>

            <div className="user-info">


                {
                    user && (

                        <>

                            <div className="user-identity">

                                <span className="user-name">
                                    {user.username}
                                </span>

                                <span className="user-role-badge">
                                    {user.role === "ADMIN" ? "Administrador" : "Operador"}
                                </span>

                            </div>


                            <div className="user-actions">

                                <button
                                    onClick={() => navigate("/change-password")}
                                >

                                    Cambiar contraseña

                                </button>


                                <button
                                    onClick={logout}
                                >

                                    Cerrar sesión

                                </button>

                            </div>

                        </>

                    )
                }


            </div>


        </div>

    );

}


export default TopBar;