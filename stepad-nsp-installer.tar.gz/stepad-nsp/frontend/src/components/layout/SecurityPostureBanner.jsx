import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import { getSecurityPosture } from "../../services/api";

const KEY = "nsp.posture.dismissed";

export default function SecurityPostureBanner() {

    const [data, setData] = useState(null);

    const [dismissed, setDismissed] = useState(() => {
        try { return sessionStorage.getItem(KEY) === "1"; } catch (e) { return false; }
    });

    useEffect(() => {
        let stop = false;
        async function load() {
            try {
                const d = await getSecurityPosture();
                if (!stop) setData(d);
            } catch (e) {
                /* silencioso */
            }
        }
        load();
        const timer = setInterval(load, 120000);
        return () => { stop = true; clearInterval(timer); };
    }, []);

    if (dismissed || !data) return null;

    const worst = data.worst;
    if (worst !== "critical" && worst !== "high") return null;

    const counts = data.counts || {};
    const n = (counts.critical || 0) + (counts.high || 0);
    const first = (data.advisories || [])[0] || {};

    return (
        <div className={"sec-posture-banner " + worst}>
            <span className="sec-posture-icon">⚠</span>
            <div className="sec-posture-text">
                <strong>Aviso de seguridad ({n}):</strong>{" "}
                {first.title || "Revisá la postura de seguridad del NSP."}
                {first.recommendation ? " — " + first.recommendation : ""}
            </div>
            <Link to="/security" className="sec-posture-link">Ver avisos</Link>
            <button
                type="button"
                className="sec-posture-close"
                title="Ocultar por esta sesión"
                onClick={() => {
                    setDismissed(true);
                    try { sessionStorage.setItem(KEY, "1"); } catch (e) { /* */ }
                }}
            >
                ×
            </button>
            <style>{`
                .sec-posture-banner{display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:10px;margin:8px 0 0;font-size:0.85rem;border:1px solid transparent}
                .sec-posture-banner .sec-posture-icon{font-size:1.1rem;line-height:1}
                .sec-posture-banner .sec-posture-text{flex:1;line-height:1.35}
                .sec-posture-banner.critical{background:rgba(220,38,38,0.12);border-color:rgba(220,38,38,0.35);color:#fecaca}
                .sec-posture-banner.high{background:rgba(239,68,68,0.10);border-color:rgba(239,68,68,0.30);color:#fecaca}
                .sec-posture-link{color:#93c5fd;text-decoration:none;font-weight:600;white-space:nowrap}
                .sec-posture-link:hover{text-decoration:underline}
                .sec-posture-close{background:transparent;border:none;color:inherit;font-size:1.2rem;line-height:1;cursor:pointer;opacity:.7}
                .sec-posture-close:hover{opacity:1}
            `}</style>
        </div>
    );
}
