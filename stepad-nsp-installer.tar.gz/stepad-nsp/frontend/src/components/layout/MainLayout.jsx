import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import TopBar from "./TopBar";
import IdleTimeout from "../IdleTimeout";
import OrgSetupBanner from "../OrgSetupBanner";
import { useAuth } from "../../auth/useAuth";

function MainLayout() {

    const { user } = useAuth();

    const location = useLocation();

    const navGroups = [
        {
            label: "Panel",
            items: [
                { to: "/", label: "Panel" },
                { to: "/logs", label: "Registro" },
                { to: "/audit", label: "Auditoría" },
                { to: "/hardware", label: "Equipo" },
                { to: "/monitoring", label: "Internet (WAN)" },
            ],
        },
        {
            label: "Red",
            items: [
                { to: "/network/interfaces", label: "Interfaces" },
                { to: "/network/devices", label: "Dispositivos" },
                { to: "/network/zones", label: "Zonas" },
                { to: "/network/diagram", label: "Diagrama" },
            ],
        },
        {
            label: "Seguridad",
            items: [
                { to: "/security", label: "Seguridad" },
                { to: "/protection", label: "Protección" },
                { to: "/vpn", label: "VPN" },
            ],
        },
        {
            label: "Administración",
            items: [
                { to: "/groups", label: "Grupos" },
                { to: "/settings", label: "Ajustes" },
                ...(user?.role === "ADMIN" ? [{ to: "/users", label: "Usuarios" }] : []),
            ],
        },
    ];

    function groupForPath(path) {
        if (path === "/") return "Panel";
        return navGroups.find(
            (group) => group.items.some(
                (item) => item.to !== "/" && path.startsWith(item.to)
            )
        )?.label || "Panel";
    }

    const [openGroups, setOpenGroups] = useState(
        () => new Set([groupForPath(location.pathname)])
    );

    useEffect(() => {
        setOpenGroups((prev) => {
            const next = new Set(prev);
            next.add(groupForPath(location.pathname));
            return next;
        });
    }, [location.pathname]);

    function toggleGroup(label) {
        setOpenGroups((prev) => {
            const next = new Set(prev);
            if (next.has(label)) {
                next.delete(label);
            } else {
                next.add(label);
            }
            return next;
        });
    }

    return (
        <IdleTimeout>
            <div className="layout">

                <aside className="sidebar">
                    <h2>STEPAD NSP</h2>

                    {navGroups.map((group) => (
                        <div key={group.label} className="nav-group">
                            <button
                                className="nav-group-title"
                                onClick={() => toggleGroup(group.label)}
                                type="button"
                            >
                                <span>{group.label}</span>
                                <span className="nav-group-chevron">
                                    {openGroups.has(group.label) ? "▾" : "▸"}
                                </span>
                            </button>

                            {
                                openGroups.has(group.label) && (
                                    group.items.map((item) => (
                                        <NavLink
                                            key={item.to}
                                            to={item.to}
                                            end={item.to === "/"}
                                        >
                                            {item.label}
                                        </NavLink>
                                    ))
                                )
                            }
                        </div>
                    ))}

                </aside>

                <div className="main-area">

                    <TopBar />

                    <main className="content">
                        <OrgSetupBanner />
                        <Outlet />
                    </main>

                </div>

            </div>
        </IdleTimeout>
    );
}

export default MainLayout;