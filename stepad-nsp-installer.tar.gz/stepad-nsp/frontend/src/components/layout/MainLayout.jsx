import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import TopBar from "./TopBar";
import IdleTimeout from "../IdleTimeout";
import OrgSetupBanner from "../OrgSetupBanner";
import { useAuth } from "../../auth/useAuth";

function MainLayout() {

    const { user } = useAuth();

    const location = useLocation();

    const [sidebarOpen, setSidebarOpen] = useState(false);

    // En movil el sidebar se cierra al navegar.
    useEffect(() => {

        setSidebarOpen(false);

    }, [location.pathname]);

    const navGroups = [
        {
            label: "Panel",
            items: [
                { to: "/", label: "Panel" },
                { to: "/logs", label: "Registro" },
                { to: "/live-navigation", label: "Navegación en vivo" },
                { to: "/alerts", label: "Alertas" },
                { to: "/top-pages", label: "Páginas más navegadas" },
                { to: "/audit", label: "Auditoría" },
                { to: "/hardware", label: "Equipo" },
                { to: "/monitoring", label: "Internet (WAN)" },
            ],
        },
        {
            label: "Red",
            items: [
                { to: "/network/interfaces", label: "Interfaces" },
                { to: "/network/devices", label: "Dispositivos" },
                { to: "/network/zones", label: "Zonas" },
                { to: "/network/diagram", label: "Diagrama" },
            ],
        },
        {
            label: "Seguridad",
            items: [
                { to: "/security", label: "Seguridad" },
                { to: "/protection", label: "Protección" },
                { to: "/vpn", label: "VPN" },
            ],
        },
        {
            label: "Administración",
            items: [
                { to: "/groups", label: "Grupos" },
                { to: "/settings", label: "Ajustes" },
                ...(user?.role === "ADMIN" ? [{ to: "/users", label: "Usuarios" }] : []),
            ],
        },
    ];

    function groupForPath(path) {
        if (path === "/") return "Panel";
        return navGroups.find(
            (group) => group.items.some(
                (item) => item.to !== "/" && path.startsWith(item.to)
            )
        )?.label || "Panel";
    }

    const [openGroups, setOpenGroups] = useState(
        () => new Set([groupForPath(location.pathname)])
    );

    useEffect(() => {
        setOpenGroups((prev) => {
            const next = new Set(prev);
            next.add(groupForPath(location.pathname));
            return next;
        });
    }, [location.pathname]);

    function toggleGroup(label) {
        setOpenGroups((prev) => {
            const next = new Set(prev);
            if (next.has(label)) {
                next.delete(label);
            } else {
                next.add(label);
            }
            return next;
        });
    }

    return (
        <IdleTimeout>
            <div className="layout">

                <button
                    className={`hamburger ${sidebarOpen ? "open" : ""}`}
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                    aria-label="Abrir menú"
                    type="button"
                >
                    <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                    >
                        <line x1="3" y1="6" x2="21" y2="6" />
                        <line x1="3" y1="12" x2="21" y2="12" />
                        <line x1="3" y1="18" x2="21" y2="18" />
                    </svg>
                </button>

                {
                    sidebarOpen && (
                        <div
                            className="sidebar-backdrop"
                            onClick={() => setSidebarOpen(false)}
                        />
                    )
                }

                <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
                    <h2>STEPAD NSP</h2>

                    {navGroups.map((group) => (
                        <div key={group.label} className="nav-group">
                            <button
                                className="nav-group-title"
                                onClick={() => toggleGroup(group.label)}
                                type="button"
                            >
                                <span>{group.label}</span>
                                <span className="nav-group-chevron">
                                    {openGroups.has(group.label) ? "▾" : "▸"}
                                </span>
                            </button>

                            {
                                openGroups.has(group.label) && (
                                    group.items.map((item) => (
                                        <NavLink
                                            key={item.to}
                                            to={item.to}
                                            end={item.to === "/"}
                                        >
                                            {item.label}
                                        </NavLink>
                                    ))
                                )
                            }
                        </div>
                    ))}

                </aside>

                <div className="main-area">

                    <TopBar />

                    <main className="content">
                        <OrgSetupBanner />
                        <Outlet />
                    </main>

                </div>

            </div>
        </IdleTimeout>
    );
}

export default MainLayout;