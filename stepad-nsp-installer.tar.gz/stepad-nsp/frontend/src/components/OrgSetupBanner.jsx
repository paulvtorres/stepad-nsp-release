import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import { getOrganizationSettings } from "../services/api";


function OrgSetupBanner() {

    const [configured, setConfigured] = useState(true);

    const [hidden, setHidden] = useState(false);


    useEffect(() => {

        let cancelled = false;

        getOrganizationSettings()

            .then((data) => {
                if (!cancelled) setConfigured(Boolean(data && data.configured));
            })

            .catch(() => {
                if (!cancelled) setConfigured(true);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    if (configured || hidden) {

        return null;

    }


    return (

        <div className="org-setup-banner">

            <span>

                Configura los datos de tu empresa (nombre, RUC) para que
                aparezcan en los reportes exportados y los correos.

            </span>

            <Link to="/settings">Configurar</Link>

            <button
                className="org-setup-close"
                onClick={() => setHidden(true)}
                title="Cerrar"
            >
                ✕
            </button>

        </div>

    );

}


export default OrgSetupBanner;
