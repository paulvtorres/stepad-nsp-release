import { useEffect, useRef } from "react";

import { useAuth } from "../auth/useAuth";

import { INACTIVITY_TIMEOUT_MINUTES } from "../constants";


const INACTIVITY_TIMEOUT_MS =
    (INACTIVITY_TIMEOUT_MINUTES || 15) * 60 * 1000;

const ACTIVITY_EVENTS = [
    "mousemove",
    "mousedown",
    "keydown",
    "touchstart",
    "scroll",
    "click"
];


function IdleTimeout({ children }) {

    const { logout } = useAuth();

    const logoutRef = useRef(logout);

    const timerRef = useRef(null);


    useEffect(() => {
        logoutRef.current = logout;
    });


    useEffect(() => {
        const reset = () => {
            if (timerRef.current) {
                clearTimeout(timerRef.current);
            }
            timerRef.current = setTimeout(
                () => logoutRef.current(),
                INACTIVITY_TIMEOUT_MS
            );
        };

        ACTIVITY_EVENTS.forEach((event) =>
            window.addEventListener(
                event,
                reset,
                { passive: true }
            )
        );

        reset();

        return () => {
            if (timerRef.current) {
                clearTimeout(timerRef.current);
            }
            ACTIVITY_EVENTS.forEach((event) =>
                window.removeEventListener(event, reset)
            );
        };
    }, []);

    return children;
}


export default IdleTimeout;