from backend.firewall.adapters.linux.linux_firewall_provider import (
    LinuxFirewallProvider,
)

from backend.dhcp.models.dhcp_diagnosis import (
    DhcpDiagnosis,
    DhcpCheck
)


class FirewallService:


    def __init__(self):

        self.provider = LinuxFirewallProvider()



    def get_status(self):

        return self.provider.get_status()



    def block_device(
        self,
        mac: str
    ):

        return self.provider.block_mac(
            mac
        )



    def unblock_device(
        self,
        mac: str
    ):

        return self.provider.unblock_mac(
            mac
        )



    def diagnose(self):

        checks = []

        healthy = True


        try:

            status = self.provider.get_status()


            backend_ok = status.backend != "NONE"


            checks.append(

                DhcpCheck(

                    name="Firewall Backend",

                    status="OK" if backend_ok else "FAILED",

                    message=status.backend,

                    action=(

                        None

                        if backend_ok

                        else "Install or configure firewall backend"

                    )

                )

            )


            if not backend_ok:

                healthy = False



            rules_ok = status.total_rules >= 0


            checks.append(

                DhcpCheck(

                    name="Firewall Rules",

                    status="OK" if rules_ok else "FAILED",

                    message=f"{status.total_rules} rules loaded",

                    action=None

                )

            )


        except Exception as e:


            healthy = False


            checks.append(

                DhcpCheck(

                    name="Firewall Status",

                    status="FAILED",

                    message=str(e),

                    action="Check firewall service"

                )

            )



        summary = "Firewall is running"


        for check in checks:

            if check.status == "FAILED":

                summary = check.message

                break



        return DhcpDiagnosis(

            healthy=healthy,

            summary=summary,

            checks=checks

        )