from backend.firewall.services.firewall_service import FirewallService


class FirewallDiagnosisService:


    def __init__(self):

        self.firewall_service = FirewallService()


    def diagnose(self):

        return self.firewall_service.diagnose()