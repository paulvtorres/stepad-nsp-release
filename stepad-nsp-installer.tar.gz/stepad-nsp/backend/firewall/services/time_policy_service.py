import subprocess

from sqlalchemy.orm import Session

from backend.network.zones.models.network_zone import NetworkZone
from backend.network.zones.models.schedule import Schedule
from backend.network.zones.repositories.schedule_repository import (
    ScheduleRepository
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.shared.logging.logger import logger


NFT_BIN = "/usr/sbin/nft"

ALL_DAYS = [
    "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday"
]


class TimePolicyService:
    """
    Enforces NetworkZone.enforce_time_cutoff using nftables' native
    time matching (meta day / meta hour) -- evaluated by the KERNEL
    per packet, not by any Python process watching the clock. This is
    why it's architecturally different from domain/RPZ schedules:
    there is no equivalent kernel-level mechanism for "is this
    particular domain name allowed right now", but for "cut all
    traffic from this IP outside these hours" there is, and it's both
    simpler and driftless compared to a polling approach.

    Re-sync triggers: zone created/updated, a device's
    is_company_asset flag changes, or a device changes zone. NOT on
    a periodic timer -- once written, the rule enforces itself.
    """

    def __init__(self):

        self.schedule_repository = ScheduleRepository()

        self.device_repository = DeviceRepository()


    def _run(self, args: list[str]):

        result = subprocess.run(
            args,
            capture_output=True,
            text=True
        )

        return {
            "success": result.returncode == 0,
            "stderr": result.stderr.strip()
        }


    def _set_name(self, zone: NetworkZone) -> str:

        return f"zone{zone.id}_assets"


    def _clear_zone_rules(self, zone: NetworkZone):
        """
        Removes any previously-written rules/set for this zone before
        rewriting -- avoids accumulating stale duplicate drop rules
        across repeated syncs (nft has no built-in "replace by tag"
        for individual rules the way it does for full chains).
        """

        set_name = self._set_name(zone)

        listing = subprocess.run(
            [NFT_BIN, "-a", "list", "chain", "inet", "stepad", "forward"],
            capture_output=True,
            text=True
        ).stdout

        for line in listing.splitlines():

            if set_name in line and "handle" in line:

                handle = line.split("handle")[1].strip()

                self._run([
                    NFT_BIN, "delete", "rule", "inet", "stepad", "forward",
                    "handle", handle
                ])

        self._run([NFT_BIN, "delete", "set", "inet", "stepad", set_name])


    def sync_zone(
        self,
        db: Session,
        zone: NetworkZone
    ):

        self._clear_zone_rules(zone)

        if not zone.enforce_time_cutoff:

            return {"success": True, "message": f"Zone {zone.id}: no time cutoff configured"}

        if not zone.time_cutoff_schedule_id:

            logger.warning(
                f"Zone {zone.id} has enforce_time_cutoff=True but no "
                "time_cutoff_schedule_id -- skipping, nothing to enforce."
            )

            return {"success": False, "message": "enforce_time_cutoff is True but no schedule is set"}

        schedule: Schedule = self.schedule_repository.find_by_id(
            db,
            zone.time_cutoff_schedule_id
        )

        if not schedule:

            logger.warning(
                f"Zone {zone.id} references missing schedule "
                f"{zone.time_cutoff_schedule_id} -- skipping."
            )

            return {"success": False, "message": "Referenced schedule not found"}

        company_devices = [

            device

            for device in self.device_repository.find_all(db)

            if device.zone_id == zone.id and device.is_company_asset

        ]

        if not company_devices:

            return {"success": True, "message": f"Zone {zone.id}: no company-asset devices to restrict"}

        set_name = self._set_name(zone)

        ips = ", ".join(device.ip_address for device in company_devices)

        self._run([
            NFT_BIN, "add", "set", "inet", "stepad", set_name,
            "{ type ipv4_addr; }"
        ])

        self._run([
            NFT_BIN, "add", "element", "inet", "stepad", set_name,
            "{ " + ips + " }"
        ])

        allowed_days = (
            {day.strip() for day in schedule.days_of_week.split(",") if day.strip()}
            if schedule.days_of_week
            else set(ALL_DAYS)
        )

        blocked_days = [day for day in ALL_DAYS if day not in allowed_days]

        results = []

        # Days entirely outside the allowed set: block all hours.
        if blocked_days:

            days_expr = "{ " + ", ".join(f'"{day}"' for day in blocked_days) + " }"

            results.append(self._run([
                NFT_BIN, "add", "rule", "inet", "stepad", "forward",
                "ip", "saddr", "@" + set_name,
                "meta", "day", days_expr,
                "drop"
            ]))

        # Within allowed days, block outside the start/end window.
        # Two separate rules (before start, after end) since nft's
        # hour range syntax matches a single contiguous interval --
        # this is the complement of that interval, not the interval
        # itself.
        if allowed_days and (schedule.start_time or schedule.end_time):

            allowed_days_expr = "{ " + ", ".join(f'"{day}"' for day in allowed_days) + " }"

            if schedule.start_time:

                results.append(self._run([
                    NFT_BIN, "add", "rule", "inet", "stepad", "forward",
                    "ip", "saddr", "@" + set_name,
                    "meta", "day", allowed_days_expr,
                    "meta", "hour", "<", schedule.start_time.strftime("%H:%M"),
                    "drop"
                ]))

            if schedule.end_time:

                results.append(self._run([
                    NFT_BIN, "add", "rule", "inet", "stepad", "forward",
                    "ip", "saddr", "@" + set_name,
                    "meta", "day", allowed_days_expr,
                    "meta", "hour", ">", schedule.end_time.strftime("%H:%M"),
                    "drop"
                ]))

        return {
            "success": all(r["success"] for r in results) if results else True,
            "message": f"Time cutoff applied to zone {zone.id} ({len(company_devices)} device(s))",
            "details": results
        }


    def sync_all_zones(
        self,
        db: Session,
        zones: list[NetworkZone]
    ):

        return {
            zone.id: self.sync_zone(db, zone)
            for zone in zones
        }
