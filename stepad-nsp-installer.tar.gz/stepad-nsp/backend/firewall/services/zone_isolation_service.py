import ipaddress
import subprocess

from sqlalchemy.orm import Session

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)


class ZoneIsolationService:
    """
    Limits lateral movement between zones (Requerimiento 2:
    segmentación de red / red de invitados aislada).

    For every ordered pair of distinct zones it installs a nftables
    rule in a dedicated `zone-isolation` chain (jumped to from the
    main `forward` chain) that DROPS traffic whose source is zone A's
    network and destination is zone B's network. Same-zone traffic,
    traffic to the firewall/gateway (DNS/DHCP) and traffic to the
    internet are untouched.

    Safe by construction when there are 0 or 1 zones (no pairs). The
    chain is flushed and rebuilt on every sync, so edits to a zone's
    network or adding/removing zones converge automatically. `clear`
    empties the chain to disable isolation without touching anything
    else.
    """

    def __init__(self):

        self.repository = NetworkZoneRepository()

    def _run(
        self,
        args: list[str]
    ):

        result = subprocess.run(
            ["/usr/sbin/nft", *args],
            capture_output=True,
            text=True
        )

        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip()
        }

    def _ensure_chain(
        self
    ):

        # Idempotent: table/chain creation errors out if they already
        # exist, which is fine.
        self._run(["add", "table", "inet", "stepad"])

        self._run(["add", "chain", "inet", "stepad", "zone-isolation"])

        # Wire the jump from the main forward chain exactly once.
        result = self._run([
            "list", "chain", "inet", "stepad", "forward"
        ])

        if "zone-isolation" not in result["stdout"]:

            self._run([
                "add", "rule", "inet", "stepad", "forward",
                "jump", "zone-isolation"
            ])

    def _flush(
        self
    ):

        self._run(["flush", "chain", "inet", "stepad", "zone-isolation"])

    def sync(
        self,
        db: Session
    ):

        zones = self.repository.find_all(db)

        networks = []

        for zone in zones:

            if not zone.network_cidr:

                continue

            try:

                networks.append((
                    zone.id,
                    ipaddress.ip_network(
                        zone.network_cidr,
                        strict=False
                    )
                ))

            except ValueError:

                continue

        self._ensure_chain()

        self._flush()

        pairs = 0

        skipped = 0

        for source_id, source_network in networks:

            for dest_id, dest_network in networks:

                if source_id == dest_id:

                    continue

                if source_network.overlaps(dest_network):

                    skipped += 1

                    continue

                result = self._run([
                    "add", "rule", "inet", "stepad", "zone-isolation",
                    "ip", "saddr", str(source_network),
                    "ip", "daddr", str(dest_network),
                    "drop"
                ])

                if result["success"]:

                    pairs += 1

        return {
            "success": True,
            "zones": len(networks),
            "pairs": pairs,
            "skipped": skipped
        }

    def clear(
        self,
        db: Session = None
    ):

        self._flush()

        return {"success": True}

    def status(
        self,
        db: Session = None
    ):

        result = self._run([
            "list", "chain", "inet", "stepad", "zone-isolation"
        ])

        drop_rules = result["stdout"].count("drop")

        return {
            "enabled": drop_rules > 0,
            "drop_rules": drop_rules
        }
