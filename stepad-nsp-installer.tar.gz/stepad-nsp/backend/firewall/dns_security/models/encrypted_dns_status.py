from dataclasses import dataclass


@dataclass
class EncryptedDnsStatus:

    enabled: bool

    backend: str

    blocklist_ips: int

    last_refreshed: str | None

    wan_interface: str | None

    # Every WAN interface the blocking rules currently exclude --
    # multi-WAN aware. wan_interface (above) stays as the primary for
    # frontend/back-compat.
    wan_interfaces: list[str] | None = None

    # Direct IP-range blocking of blocked services (Meta/Facebook).
    # These drop LAN->WAN connections to the service's own networks so
    # devices with cached DNS answers cannot reach it. Applied together
    # with the DoT/DoH rules on enable(); service_block_enabled tells
    # whether the drop rules are currently present in the firewall.
    service_ipv4_ranges: int = 0

    service_ipv6_ranges: int = 0

    service_block_enabled: bool = False

    message: str | None = None
