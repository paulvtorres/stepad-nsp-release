import json

from datetime import datetime

from backend.core.config.paths import (
    FIREWALL_DIR,
    ENCRYPTED_DNS_STATE_FILE
)

from backend.firewall.dns_security.adapters.linux.linux_encrypted_dns_provider import (
    LinuxEncryptedDnsProvider
)

from backend.firewall.dns_security.models.encrypted_dns_status import (
    EncryptedDnsStatus
)

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.shared.logging.logger import logger


class EncryptedDnsService:
    """
    Turns DoT/DoH blocking on and off, and remembers the choice
    across restarts the same way TemporaryLanService remembers an
    active LAN override -- a small JSON file under STEPAD_DIR, read
    back on boot by FirewallComponent so a reboot doesn't silently
    reopen the bypass an admin had closed.
    """

    def __init__(self):

        self.provider = LinuxEncryptedDnsProvider()

        self.interface_service = InterfaceService()


    def _get_wan_interfaces(self):

        interfaces = self.interface_service.get_wan_interfaces()

        return [interface.name for interface in interfaces]


    def _service_block_info(self):

        return self.provider.get_service_block_status()


    def _read_state(self):

        if not ENCRYPTED_DNS_STATE_FILE.exists():

            # Por defecto el bloqueo de DNS cifrado (DoH/DoT) y el de
            # servicios por IP quedan DESACTIVADOS: en una instalacion
            # nueva no se aplican hasta que el admin los active desde
            # la UI (al reiniciar no se re-activan solos).
            return {
                "enabled": False,
                "service_block_enabled": False,
                "last_refreshed": None
            }

        try:

            return json.loads(ENCRYPTED_DNS_STATE_FILE.read_text())

        except (json.JSONDecodeError, OSError):

            return {
                "enabled": False,
                "service_block_enabled": False,
                "last_refreshed": None
            }


    def _write_state(self, state: dict):

        FIREWALL_DIR.mkdir(parents=True, exist_ok=True)

        ENCRYPTED_DNS_STATE_FILE.write_text(json.dumps(state))


    def get_status(self) -> EncryptedDnsStatus:

        state = self._read_state()

        wan_interfaces = self._get_wan_interfaces()

        service_block = self._service_block_info()

        return EncryptedDnsStatus(
            enabled=state.get("enabled", False),
            backend="NFTABLES",
            blocklist_ips=self.provider.get_blocklist_size(),
            last_refreshed=state.get("last_refreshed"),
            wan_interface=wan_interfaces[0] if wan_interfaces else None,
            wan_interfaces=wan_interfaces,
            service_ipv4_ranges=service_block["ipv4_ranges"],
            service_ipv6_ranges=service_block["ipv6_ranges"],
            service_block_enabled=service_block["active"],
            enabled_persist=state.get("enabled_persist", False),
            service_block_persist=state.get("service_block_persist", False)
        )


    def enable(self, persist: bool = False):

        wan_interfaces = self._get_wan_interfaces()

        service_block = self._service_block_info()

        if not wan_interfaces:

            return EncryptedDnsStatus(
                enabled=False,
                backend="NFTABLES",
                blocklist_ips=self.provider.get_blocklist_size(),
                last_refreshed=None,
                wan_interface=None,
                wan_interfaces=[],
                service_ipv4_ranges=service_block["ipv4_ranges"],
                service_ipv6_ranges=service_block["ipv6_ranges"],
                service_block_enabled=service_block["active"],
                message=(
                    "No WAN interface detected -- configure network "
                    "interfaces before enabling encrypted DNS blocking."
                )
            )

        result = self.provider.enable(wan_interfaces)

        now = datetime.utcnow().isoformat()

        self._write_state({
            "enabled": result["success"],
            "service_block_enabled": result["success"],
            "enabled_persist": persist,
            "service_block_persist": persist,
            "last_refreshed": now
        })

        if result["success"]:

            logger.warning(
                f"Encrypted DNS (DoT/DoH) blocking ENABLED, WAN(s)={wan_interfaces}. "
                "LAN devices can no longer bypass domain blocking via "
                "encrypted resolvers on the known blocklist, and plaintext "
                "DNS is redirected to STEPAD's own resolver."
            )

        else:

            logger.error(
                f"Encrypted DNS blocking failed to enable: {result}"
            )

        return EncryptedDnsStatus(
            enabled=result["success"],
            backend="NFTABLES",
            blocklist_ips=self.provider.get_blocklist_size(),
            last_refreshed=now,
            wan_interface=wan_interfaces[0] if wan_interfaces else None,
            wan_interfaces=wan_interfaces,
            service_ipv4_ranges=service_block["ipv4_ranges"],
            service_ipv6_ranges=service_block["ipv6_ranges"],
            service_block_enabled=service_block["active"],
            enabled_persist=persist,
            service_block_persist=persist,
            message=None if result["success"] else "Failed to apply one or more firewall rules -- check logs."
        )


    def disable(self):

        result = self.provider.disable()

        self._write_state({
            "enabled": False,
            "service_block_enabled": False,
            "enabled_persist": False,
            "service_block_persist": False,
            "last_refreshed": datetime.utcnow().isoformat()
        })

        logger.warning(
            "Encrypted DNS (DoT/DoH) blocking DISABLED."
        )

        wan_interfaces = self._get_wan_interfaces()

        service_block = self._service_block_info()

        return EncryptedDnsStatus(
            enabled=False,
            backend="NFTABLES",
            blocklist_ips=self.provider.get_blocklist_size(),
            last_refreshed=datetime.utcnow().isoformat(),
            wan_interface=wan_interfaces[0] if wan_interfaces else None,
            wan_interfaces=wan_interfaces,
            service_ipv4_ranges=service_block["ipv4_ranges"],
            service_ipv6_ranges=service_block["ipv6_ranges"],
            service_block_enabled=service_block["active"],
            message=None if result["success"] else "Some rules could not be removed -- check logs."
        )


    def enable_service_block(self, persist: bool = False):

        wan_interfaces = self._get_wan_interfaces()

        service_block = self._service_block_info()

        if not wan_interfaces:

            return EncryptedDnsStatus(
                enabled=bool(self._read_state().get("enabled", False)),
                backend="NFTABLES",
                blocklist_ips=self.provider.get_blocklist_size(),
                last_refreshed=self._read_state().get("last_refreshed"),
                wan_interface=None,
                wan_interfaces=[],
                service_ipv4_ranges=service_block["ipv4_ranges"],
                service_ipv6_ranges=service_block["ipv6_ranges"],
                service_block_enabled=service_block["active"],
                message=(
                    "No WAN interface detected -- configure network "
                    "interfaces before blocking services by IP."
                )
            )

        result = self.provider.enable_service_block(wan_interfaces)

        state = self._read_state()

        state["service_block_enabled"] = result["success"]

        state["service_block_persist"] = persist

        state["last_refreshed"] = datetime.utcnow().isoformat()

        self._write_state(state)

        if result["success"]:

            logger.warning(
                f"Service-IP block (Meta/Facebook) ENABLED, WAN(s)={wan_interfaces}. "
                "LAN devices can no longer reach the blocked service ranges "
                "directly by IP."
            )

        else:

            logger.error(
                f"Service-IP block failed to enable: {result}"
            )

        return EncryptedDnsStatus(
            enabled=state.get("enabled", False),
            backend="NFTABLES",
            blocklist_ips=self.provider.get_blocklist_size(),
            last_refreshed=state["last_refreshed"],
            wan_interface=wan_interfaces[0] if wan_interfaces else None,
            wan_interfaces=wan_interfaces,
            service_ipv4_ranges=service_block["ipv4_ranges"],
            service_ipv6_ranges=service_block["ipv6_ranges"],
            service_block_enabled=result["success"],
            service_block_persist=persist,
            message=None if result["success"] else "Failed to apply the service-IP block -- check logs."
        )


    def disable_service_block(self):

        result = self.provider.disable_service_block()

        state = self._read_state()

        state["service_block_enabled"] = False

        state["service_block_persist"] = False

        state["last_refreshed"] = datetime.utcnow().isoformat()

        self._write_state(state)

        logger.warning(
            "Service-IP block (Meta/Facebook) DISABLED."
        )

        wan_interfaces = self._get_wan_interfaces()

        service_block = self._service_block_info()

        return EncryptedDnsStatus(
            enabled=state.get("enabled", False),
            backend="NFTABLES",
            blocklist_ips=self.provider.get_blocklist_size(),
            last_refreshed=state["last_refreshed"],
            wan_interface=wan_interfaces[0] if wan_interfaces else None,
            wan_interfaces=wan_interfaces,
            service_ipv4_ranges=service_block["ipv4_ranges"],
            service_ipv6_ranges=service_block["ipv6_ranges"],
            service_block_enabled=service_block["active"],
            message=None if result["success"] else "Some service-IP rules could not be removed -- check logs."
        )


    def refresh_blocklist(self):

        result = self.provider.refresh_blocklist()

        state = self._read_state()

        state["last_refreshed"] = datetime.utcnow().isoformat()

        self._write_state(state)

        return result


    def reapply_on_boot(self):
        """
        Called from FirewallComponent.start(). If an admin previously
        enabled encrypted-DNS blocking, nftables rules do NOT survive
        a reboot (they're runtime-only, same as the MAC-block chain),
        so this re-applies them. Best-effort -- a WAN interface that
        isn't up yet at boot just means we log and move on; the admin
        can re-enable from the UI once networking is ready.
        """

        state = self._read_state()

        wan_interfaces = self._get_wan_interfaces()

        if not wan_interfaces:

            logger.warning(
                "Encrypted DNS / service blocking was enabled before restart, but no "
                "WAN interface is detected yet -- not re-applying automatically."
            )

            return

        # Solo se re-aplica si el bloqueo estaba ACTIVO Y con persistencia
        # marcada. Sin "siempre activo tras reinicio", al reiniciar no se
        # re-activa (sesion no persistente).
        if state.get("enabled") and state.get("enabled_persist"):

            result = self.provider.enable(wan_interfaces)

            logger.info(
                f"Encrypted DNS blocking re-applied on boot: success={result['success']}"
            )

            return

        if (
            state.get("service_block_enabled")
            and state.get("service_block_persist")
        ):

            result = self.provider.enable_service_block(wan_interfaces)

            logger.info(
                f"Service-IP block re-applied on boot: success={result['success']}"
            )
