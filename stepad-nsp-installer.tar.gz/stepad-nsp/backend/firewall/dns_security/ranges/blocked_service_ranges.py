"""
IP ranges of "blocked services" that must be unreachable from LAN
devices REGARDLESS of what DNS they use.

WHY THIS EXISTS:
The DNS blocklist (RPZ) only stops devices that actually resolve
through STEPAD's recursor. A phone whose Facebook app cached the
domain -> IP answers while on another network comes back to the
STEPAD LAN and connects straight to those cached IPs -- the app
never issues a DNS query on the LAN, so RPZ never sees it, and the
app keeps working. The port-53 redirect and the DoT/DoH blocks
cannot help either: there is nothing to redirect or block.

Closing that hole requires dropping the *connections* to the service
itself. These ranges make the firewall drop, at the forward hook,
any LAN -> WAN packet whose destination is a known Facebook/Meta
network, so even a device with perfect cached DNS simply cannot
reach Facebook. This is what turns "blocks queries" into "blocks the
app".

WHAT'S IN THE LIST:
AS32934 (Meta Platforms, Inc. -- facebook.com, fbcdn.net, messenger,
instagram, WhatsApp's backend and the rest of the Meta estate all
announce under this ASN). Ranges were fetched from RIPE's
announced-prefixes API (https://stat.ripe.net/data/announced-prefixes/
data.json?resource=AS32934) on 2026-08-06 and CIDR-merged.

DELIBERATELY NOT BLOCKED:
AS54113 is Fastly, not Meta. Some CDN lookup tools surface it for
"facebook" because Facebook used to publish some edge content through
CDNs, but Fastly serves a huge fraction of the internet -- blocking
it would break far more than it would fix. Meta's own ranges below
cover the app's real endpoints (api/edge-mqtt/fbcdn/connect SDK).

REFRESH:
Prefixes drift slowly but they do drift. To refresh: hit the RIPE
API above for AS32934, CIDR-merge the result, and replace these two
lists. After updating, re-apply with the encrypted-DNS blocking
enabled (the "refresh blocklist" action re-populates the sets).
"""

META_FACEBOOK_IPV4 = [
    "31.13.24.0/21",
    "31.13.64.0/18",
    "45.64.40.0/22",
    "57.141.0.0/24",
    "57.141.2.0/24",
    "57.141.3.0/24",
    "57.141.4.0/24",
    "57.141.5.0/24",
    "57.141.6.0/24",
    "57.141.8.0/24",
    "57.141.10.0/24",
    "57.141.12.0/24",
    "57.141.13.0/24",
    "57.141.14.0/24",
    "57.141.16.0/24",
    "57.141.17.0/24",
    "57.141.18.0/24",
    "57.141.19.0/24",
    "57.141.20.0/24",
    "57.141.22.0/24",
    "57.141.24.0/24",
    "57.144.0.0/14",
    "66.220.144.0/20",
    "69.63.176.0/20",
    "69.171.224.0/19",
    "74.119.76.0/22",
    "102.132.96.0/20",
    "103.4.96.0/22",
    "129.134.0.0/17",
    "157.240.0.0/17",
    "157.240.192.0/18",
    "163.70.128.0/17",
    "163.77.132.0/23",
    "163.77.136.0/23",
    "173.252.64.0/19",
    "173.252.96.0/19",
    "179.60.192.0/22",
    "185.60.216.0/22",
    "185.89.216.0/22",
    "204.15.20.0/22",
]

META_FACEBOOK_IPV6 = [
    "2a03:2880::/32",
    "2620:0:1c00::/40",
]
