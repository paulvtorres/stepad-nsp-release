"""
Curated, hand-maintained list of IP addresses belonging to major
public DNS-over-HTTPS / DNS-over-TLS resolvers.

This is publicly documented information (each operator publishes
these addresses for people to configure their devices with) -- it's
the same data that ships in every DoH/DoT-aware firewall (pfSense,
OPNsense, pi-hole guides, etc).

WHY THIS LIST EXISTS:
Blocking port 853 (DoT) is airtight -- there's no legitimate reason
for a LAN device to reach ANY host on 853 once STEPAD is the
resolver. DoH is harder: it rides over ordinary tcp/443, so it's
indistinguishable from other HTTPS traffic without inspecting the
TLS ClientHello's SNI, which plain nftables can't do. The practical
middle ground -- also what most consumer/SMB firewalls without a DPI
engine do -- is to block 443 specifically to the small set of IPs
that the big public resolvers actually use.

KNOWN LIMITATION (make sure whoever operates STEPAD understands
this): a device pointed at a self-hosted or lesser-known DoH server
on an IP NOT in this list will NOT be blocked by rule (2) in
LinuxEncryptedDnsProvider. Combined with the DoT block and the
plaintext-DNS redirect, this closes the common/default bypasses
(browser "Secure DNS" dropdowns, Android Private DNS presets, iOS
DoH profiles using these providers) but is not a complete DoH
dragnet. Revisit if/when the project adds an SNI-aware inspection
component.

Update this list periodically -- providers occasionally add/rotate
anycast ranges.
"""

KNOWN_DOH_DOT_IPV4 = [

    # Cloudflare (1.1.1.1 / cloudflare-dns.com)
    "1.1.1.1",
    "1.0.0.1",

    # Google Public DNS (dns.google)
    "8.8.8.8",
    "8.8.4.4",

    # Quad9
    "9.9.9.9",
    "149.112.112.112",

    # OpenDNS / Cisco Umbrella
    "208.67.222.222",
    "208.67.220.220",

    # AdGuard DNS
    "94.140.14.14",
    "94.140.15.15",

    # CleanBrowsing
    "185.228.168.9",
    "185.228.169.9",

    # NextDNS anycast ranges (per-account resolver IDs sit behind
    # these, so the block is provider-wide rather than account-wide)
    "45.90.28.0/24",
    "45.90.30.0/24",

]

KNOWN_DOH_DOT_IPV6 = [

    # Cloudflare
    "2606:4700:4700::1111",
    "2606:4700:4700::1001",

    # Google Public DNS
    "2001:4860:4860::8888",
    "2001:4860:4860::8844",

    # Quad9
    "2620:fe::fe",
    "2620:fe::9",

    # OpenDNS / Cisco Umbrella
    "2620:119:35::35",
    "2620:119:53::53",

    # AdGuard DNS
    "2a10:50c0::ad1:ff",
    "2a10:50c0::ad2:ff",

]
