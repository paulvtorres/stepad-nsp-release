from abc import ABC, abstractmethod

from backend.firewall.models.firewall_interface import FirewallInterface


class FirewallInterfaceRepository(ABC):

    @abstractmethod
    def get_all(self) -> list[FirewallInterface]:
        pass

    @abstractmethod
    def save(self, firewall_interface: FirewallInterface):
        pass