from abc import ABC, abstractmethod

from backend.firewall.models.firewall_interface import FirewallInterface


class FirewallRepository(ABC):

    @abstractmethod
    def get_interfaces(self) -> list[FirewallInterface]:
        pass

    @abstractmethod
    def save_interface(self, interface: FirewallInterface):
        pass