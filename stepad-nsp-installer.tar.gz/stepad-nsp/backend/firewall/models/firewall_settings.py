from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class FirewallSettings(Base):

    __tablename__ = "firewall_settings"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True
    )


    hardening_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    last_review: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    # Revisión periódica de accesos administrativos (6 meses).
    last_access_review: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    # Ventana horaria (hora 0-23) en la que se permite el acceso
    # administrativo. NULL = sin restricción.
    admin_access_start_hour: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )

    admin_access_end_hour: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )
