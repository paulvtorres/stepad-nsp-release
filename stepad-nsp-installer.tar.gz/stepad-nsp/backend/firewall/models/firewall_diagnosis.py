from dataclasses import dataclass, field


@dataclass
class FirewallDiagnosis:

    backend: str

    enabled: bool

    running: bool

    ready: bool

    total_rules: int

    messages: list[str] = field(default_factory=list)

    recommendations: list[str] = field(default_factory=list)