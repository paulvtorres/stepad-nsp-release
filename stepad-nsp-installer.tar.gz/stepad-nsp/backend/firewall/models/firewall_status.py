from dataclasses import dataclass

from backend.core.lifecycle.component_status import ComponentStatus


@dataclass
class FirewallStatus:

    name: str

    backend: str

    status: ComponentStatus

    total_rules: int