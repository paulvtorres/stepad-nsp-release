from dataclasses import dataclass


@dataclass
class FirewallRule:

    id: int

    name: str

    enabled: bool