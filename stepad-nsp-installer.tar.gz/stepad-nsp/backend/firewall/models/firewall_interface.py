class FirewallInterfaceEntity(Base):

    __tablename__ = "firewall_interfaces"

    id = Column(Integer, primary_key=True)

    name = Column(String)

    ip = Column(String)

    mac = Column(String)

    role = Column(String)