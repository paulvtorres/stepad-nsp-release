from abc import ABC, abstractmethod

from backend.firewall.models.firewall_status import FirewallStatus


class FirewallProvider(ABC):


    @abstractmethod
    def get_status(self) -> FirewallStatus:
        pass



    @abstractmethod
    def block_mac(
        self,
        mac: str
    ):
        pass



    @abstractmethod
    def unblock_mac(
        self,
        mac: str
    ):
        pass