from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.firewall.adapters.linux.linux_firewall_provider import (
    LinuxFirewallProvider
)

from backend.firewall.dns_security.services.encrypted_dns_service import (
    EncryptedDnsService
)

from backend.shared.logging.logger import logger



class FirewallComponent(BaseComponent):


    name = "firewall"

    criticality = ComponentCriticality.IMPORTANT



    def __init__(self):

        self.provider = LinuxFirewallProvider()

        self.encrypted_dns_service = EncryptedDnsService()



    def start(self):

        logger.info(
            "FirewallComponent started."
        )


        result = self.provider.initialize()


        logger.info(
            f"Firewall initialization: {result}"
        )


        try:

            from backend.firewall.services.firewall_hardening_service import (
                FirewallHardeningService
            )

            hardening = FirewallHardeningService()

            settings = hardening.get_settings()

            if settings.get("hardening_enabled"):

                hardening.set_enabled(True)

                logger.info(
                    "Hardening deny-all aplicado en el arranque."
                )

            else:

                hardening.set_enabled(False)

        except Exception as error:

            logger.error(
                f"Fallo al sincronizar hardening: {error}"
            )


        try:

            self.encrypted_dns_service.reapply_on_boot()

        except Exception as error:

            logger.error(
                f"Failed to reapply encrypted DNS blocking on boot: {error}"
            )



    def stop(self):

        logger.info(
            "FirewallComponent stopped."
        )