import shutil
import subprocess

from backend.firewall.models.firewall_status import FirewallStatus
from backend.firewall.providers.firewall_provider import (
    FirewallProvider
)


class LinuxFirewallProvider(FirewallProvider):

    CHAIN = "inet stepad forward"

    def run_command(
        self,
        command
    ):

        result = subprocess.run(
            command,
            capture_output=True,
            text=True
        )

        return {

            "success": result.returncode == 0,

            "stdout": result.stdout.strip(),

            "stderr": result.stderr.strip()

        }

    def initialize(self):

        self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "table",
                "inet",
                "stepad"
            ]
        )

        result = self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "chain",
                "inet",
                "stepad",
                "forward",
                "{",
                "type", "filter", "hook", "forward", "priority", "0", ";",
                "policy", "accept", ";",
                "}"
            ]
        )

        # Si ya existe la cadena, nft devuelve error.
        # Eso no debe detener STEPAD.
        if not result["success"]:

            result = {
                "success": True,
                "message": "Firewall chain already initialized"
            }

        # Limpiar reglas de cola previas (idempotente): se borran las
        # reglas `queue` existentes para no acumular duplicados en cada
        # reinicio de la app.
        self._clean_queue_rules()

        # Enviar TODO el tráfico reenviado (ambas direcciones) a Suricata
        # via NFQUEUE 0. `bypass` = si Suricata no está leyendo la cola,
        # el tráfico sigue pasando (no se corta internet).
        #
        # IMPORTANTE: se cola en AMBAS direcciones (sin filtro de
        # interfaz). Antes solo se colaba lo saliente a WAN y Suricata
        # no veía el handshake TLS completo (ServerHello), por lo que el
        # SNI de los dominios bloqueados no matcheaba en vivo.
        self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "rule",
                "inet",
                "stepad",
                "forward",
                "queue",
                "num",
                "0",
                "bypass"
            ]
        )

        return result

    def _clean_queue_rules(self):
        result = self.run_command(
            [
                "/usr/sbin/nft",
                "-a",
                "list",
                "chain",
                "inet",
                "stepad",
                "forward"
            ]
        )
        if not result["success"]:
            return
        for line in result["stdout"].splitlines():
            if "queue" not in line or "handle" not in line:
                continue
            handle = line.split("handle")[1].strip().split()[0]
            self.run_command(
                [
                    "/usr/sbin/nft",
                    "delete",
                    "rule",
                    "inet",
                    "stepad",
                    "forward",
                    "handle",
                    handle
                ]
            )

    def get_status(self) -> FirewallStatus:

        from backend.core.lifecycle.component_status import (
            ComponentStatus
        )


        backend = "NONE"


        if shutil.which("nft"):

            backend = "NFTABLES"

        elif shutil.which("iptables"):

            backend = "IPTABLES"



        status = (

            ComponentStatus.RUNNING

            if backend != "NONE"

            else ComponentStatus.FAILED

        )


        return FirewallStatus(

            name="firewall",

            backend=backend,

            status=status,

            total_rules=0

        )

    def block_mac(
        self,
        mac: str
    ):

        # Verificar si la regla ya existe
        result = subprocess.run(

            [
                "/usr/sbin/nft",
                "list",
                "chain",
                "inet",
                "stepad",
                "forward"
            ],

            capture_output=True,

            text=True

        )

        for line in result.stdout.splitlines():

            if mac.lower() in line.lower():

                return {

                    "success": True,

                    "message": "Rule already exists"

                }

        # Agregar la regla únicamente si no existe
        return self.run_command(

            [

                "/usr/sbin/nft",

                "add",

                "rule",

                "inet",

                "stepad",

                "forward",

                "ether",

                "saddr",

                mac,

                "drop"

            ]

        )

    def unblock_mac(
        self,
        mac: str
    ):

        result = subprocess.run(

            [

                "/usr/sbin/nft",

                "-a",

                "list",

                "chain",

                "inet",

                "stepad",

                "forward"

            ],

            capture_output=True,

            text=True

        )

        handle = None

        for line in result.stdout.splitlines():

            if mac.lower() in line.lower():

                if "handle" in line:

                    handle = line.split("handle")[1].strip()

                    break

        if not handle:

            return {

                "success": False,

                "message": "Rule not found"

            }

        return self.run_command(

            [

                "/usr/sbin/nft",

                "delete",

                "rule",

                "inet",

                "stepad",

                "forward",

                "handle",

                handle

            ]

        )