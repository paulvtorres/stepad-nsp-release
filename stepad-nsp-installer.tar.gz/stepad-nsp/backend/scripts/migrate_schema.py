"""Aplica las migraciones de esquema con Alembic.

Uso (instalador o a mano):

    .venv/bin/python3 -m backend.scripts.migrate_schema

Marca la baseline si la base de datos es de una instalacion anterior a
Alembic y luego aplica `upgrade head`.
"""

from backend.core.database.schema_migrations import run_migrations


if __name__ == "__main__":

    run_migrations()
