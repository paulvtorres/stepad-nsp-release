from datetime import datetime, timedelta

from jose import jwt

from backend.core.config.settings import Settings


class JwtService:


    def create_token(
        self,
        user_id: int,
        username: str,
        role: str
    ) -> str:

        expire = datetime.utcnow() + timedelta(
            minutes=Settings.JWT_EXPIRE_MINUTES
        )

        payload = {
            "sub": username,
            "user_id": user_id,
            "role": role,
            "exp": expire
        }

        return jwt.encode(
            payload,
            Settings.JWT_SECRET,
            algorithm=Settings.JWT_ALGORITHM
        )


    def create_mfa_token(
        self,
        user_id: int,
        username: str
    ) -> str:

        expire = datetime.utcnow() + timedelta(
            minutes=5
        )

        payload = {
            "sub": username,
            "user_id": user_id,
            "purpose": "mfa",
            "exp": expire
        }

        return jwt.encode(
            payload,
            Settings.JWT_SECRET,
            algorithm=Settings.JWT_ALGORITHM
        )