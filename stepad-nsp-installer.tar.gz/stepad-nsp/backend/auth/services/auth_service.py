from sqlalchemy.orm import Session

from fastapi import HTTPException

from datetime import datetime, timedelta

import pyotp

from backend.users.services.user_service import UserService
from backend.users.security.password_hasher import PasswordHasher
from backend.users.security.password_policy import PasswordPolicy

from backend.auth.schemas.login_response import LoginResponse

from backend.auth.schemas.login_request import LoginRequest
from backend.auth.services.jwt_service import JwtService
from backend.audit.services.audit_service import AuditService

from backend.shared.constants.user_roles import UserRoles

from backend.core.config.settings import Settings

class AuthService:


    MAX_FAILED_ATTEMPTS = 3

    LOCKOUT_MINUTES = 30

    MFA_ISSUER = "STEPAD NSP"


    def __init__(self):

        self.user_service = UserService()

        self.password_hasher = PasswordHasher()
        self.jwt_service = JwtService()
        self.audit_service = AuditService()

    def is_password_expired(
        self,
        user
    ) -> bool:

        if user is None:

            return False

        changed_at = (
            user.password_changed_at
            or user.created_at
            or datetime.utcnow()
        )

        return (
            datetime.utcnow() - changed_at
        ) > timedelta(days=Settings.PASSWORD_MAX_AGE_DAYS)

    def change_password(
        self,
        db: Session,
        user_id: int,
        current_password: str,
        new_password: str
    ):

        user = self.user_service.repository.find_by_id(
            db,
            user_id
        )

        if user is None:

            raise HTTPException(
                status_code=404,
                detail="User not found"
            )

        if not self.password_hasher.verify(
            current_password,
            user.password_hash
        ):

            raise HTTPException(
                status_code=400,
                detail="Current password is incorrect"
            )

        policy_errors = PasswordPolicy.errors(
            new_password
        )

        if policy_errors:

            raise HTTPException(
                status_code=400,
                detail="Password must include "
                + ", ".join(policy_errors)
            )

        user.password_hash = self.password_hasher.hash(
            new_password
        )

        user.password_changed_at = datetime.utcnow()

        self.user_service.repository.update(
            db,
            user
        )

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="PASSWORD_CHANGED",
            resource="AUTH",
            description=f"User {user.username} changed their password"
        )

        return {
            "success": True,
            "message": "Password changed"
        }

    def is_mfa_setup_required(
        self,
        user
    ) -> bool:

        return bool(
            user is not None
            and Settings.MFA_REQUIRED_FOR_ADMINS
            and user.role == UserRoles.ADMIN
            and not user.mfa_enabled
        )

    def setup_mfa(
        self,
        db: Session,
        user_id: int
    ):

        user = self.user_service.repository.find_by_id(
            db,
            user_id
        )

        if user is None:

            raise HTTPException(
                status_code=404,
                detail="User not found"
            )

        secret = pyotp.random_base32()

        user.totp_secret = secret

        self.user_service.repository.update(db, user)

        uri = pyotp.TOTP(secret).provisioning_uri(
            name=user.username,
            issuer_name=self.MFA_ISSUER
        )

        return {
            "secret": secret,
            "otpauth_uri": uri
        }

    def confirm_mfa(
        self,
        db: Session,
        user_id: int,
        code: str
    ):

        user = self.user_service.repository.find_by_id(
            db,
            user_id
        )

        if user is None or not user.totp_secret:

            raise HTTPException(
                status_code=400,
                detail="MFA not set up"
            )

        if not pyotp.TOTP(user.totp_secret).verify(
            code,
            valid_window=1
        ):

            raise HTTPException(
                status_code=400,
                detail="Invalid verification code"
            )

        user.mfa_enabled = True

        self.user_service.repository.update(db, user)

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="MFA_ENABLED",
            resource="AUTH",
            description=f"User {user.username} enabled MFA"
        )

        return {"success": True, "message": "MFA enabled"}

    def disable_mfa(
        self,
        db: Session,
        user_id: int,
        current_password: str
    ):

        user = self.user_service.repository.find_by_id(
            db,
            user_id
        )

        if user is None:

            raise HTTPException(
                status_code=404,
                detail="User not found"
            )

        if (
            Settings.MFA_REQUIRED_FOR_ADMINS
            and user.role == UserRoles.ADMIN
        ):

            raise HTTPException(
                status_code=400,
                detail="MFA is mandatory for admin accounts and cannot be disabled"
            )

        if not self.password_hasher.verify(
            current_password,
            user.password_hash
        ):

            raise HTTPException(
                status_code=400,
                detail="Current password is incorrect"
            )

        user.totp_secret = None

        user.mfa_enabled = False

        self.user_service.repository.update(db, user)

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="MFA_DISABLED",
            resource="AUTH",
            description=f"User {user.username} disabled MFA"
        )

        return {"success": True, "message": "MFA disabled"}

    def complete_mfa_login(
        self,
        db: Session,
        mfa_token: str,
        code: str
    ) -> LoginResponse:

        from jose import jwt, JWTError

        try:

            payload = jwt.decode(
                mfa_token,
                Settings.JWT_SECRET,
                algorithms=[Settings.JWT_ALGORITHM]
            )

        except JWTError:

            return LoginResponse(
                success=False,
                message="Invalid MFA token"
            )

        if payload.get("purpose") != "mfa":

            return LoginResponse(
                success=False,
                message="Invalid MFA token"
            )

        user = self.user_service.repository.find_by_id(
            db,
            payload.get("user_id")
        )

        if user is None or not user.enabled:

            return LoginResponse(
                success=False,
                message="Invalid username or password"
            )

        if not user.totp_secret or not pyotp.TOTP(
            user.totp_secret
        ).verify(code, valid_window=1):

            return LoginResponse(
                success=False,
                message="Invalid verification code"
            )

        user.last_login_at = datetime.utcnow()

        self.user_service.repository.update(db, user)

        token = self.jwt_service.create_token(
            user.id,
            user.username,
            user.role
        )

        self.audit_service.create_log(
            db=db,
            user_id=user.id,
            action="USER_LOGIN",
            resource="AUTH",
            description=f"User {user.username} logged in (MFA)"
        )

        return LoginResponse(
            success=True,
            message="Login successful",
            access_token=token,
            token_type="bearer",
            password_expired=self.is_password_expired(user)
        )

    def login(
        self,
        db: Session,
        request: LoginRequest
    ) -> LoginResponse:

        user = self.user_service.find_by_username(
            db,
            request.username
        )

        if user is None:

            return LoginResponse(
                success=False,
                message="Invalid username or password"
            )


        if not user.enabled:

            return LoginResponse(
                success=False,
                message="User is disabled"
            )


        now = datetime.utcnow()

        # Restricción por horario del acceso administrativo (si está
        # configurada la ventana en Hardening).
        try:

            from backend.firewall.services.firewall_hardening_service import (
                FirewallHardeningService
            )

            if not FirewallHardeningService().admin_access_allowed():

                return LoginResponse(
                    success=False,
                    message="Acceso administrativo restringido por horario"
                )

        except Exception:

            pass

        if (
            user.locked_until is not None
            and user.locked_until > now
        ):

            remaining = int(
                (user.locked_until - now).total_seconds() // 60
            )

            return LoginResponse(
                success=False,
                message=(
                    f"Account locked. Try again in "
                    f"{remaining} minutes."
                )
            )


        if not self.password_hasher.verify(
            request.password,
            user.password_hash
        ):

            user.failed_attempts = (
                (user.failed_attempts or 0) + 1
            )

            locked = False

            if user.failed_attempts >= self.MAX_FAILED_ATTEMPTS:

                user.locked_until = now + timedelta(
                    minutes=self.LOCKOUT_MINUTES
                )

                user.failed_attempts = 0

                locked = True

            self.user_service.repository.update(db, user)

            self.audit_service.create_log(
                db=db,
                user_id=user.id,
                action="USER_LOGIN_FAILED",
                resource="AUTH",
                description=f"Failed login for {user.username}"
            )

            if locked:

                self.audit_service.create_log(
                    db=db,
                    user_id=user.id,
                    action="ACCOUNT_LOCKED",
                    resource="AUTH",
                    description=(
                        f"Account {user.username} locked for "
                        f"{self.LOCKOUT_MINUTES} minutes"
                    )
                )

            return LoginResponse(
                success=False,
                message="Invalid username or password"
            )


        user.failed_attempts = 0

        user.locked_until = None

        self.user_service.repository.update(db, user)


        if user.mfa_enabled:

            mfa_token = self.jwt_service.create_mfa_token(
                user.id,
                user.username
            )

            return LoginResponse(

                success=True,

                message="MFA code required",

                mfa_required=True,

                mfa_token=mfa_token

            )


        user.last_login_at = datetime.utcnow()

        self.user_service.repository.update(db, user)


        token = self.jwt_service.create_token(

            user.id,

            user.username,

            user.role

        )

        self.audit_service.create_log(

            db=db,

            user_id=user.id,

            action="USER_LOGIN",

            resource="AUTH",

            description=f"User {user.username} logged in"

        )

        return LoginResponse(

            success=True,

            message="Login successful",

            access_token=token,

            token_type="bearer",

            password_expired=self.is_password_expired(user),

            mfa_setup_required=self.is_mfa_setup_required(user)

        )