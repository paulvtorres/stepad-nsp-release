from pydantic import BaseModel


class LoginResponse(BaseModel):

    success: bool

    message: str

    access_token: str | None = None

    token_type: str | None = None

    password_expired: bool = False

    mfa_required: bool = False

    mfa_token: str | None = None

    mfa_setup_required: bool = False