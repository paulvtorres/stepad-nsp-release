from pydantic import BaseModel


class MfaCodeRequest(BaseModel):

    code: str


class MfaLoginRequest(BaseModel):

    mfa_token: str

    code: str


class DisableMfaRequest(BaseModel):

    current_password: str