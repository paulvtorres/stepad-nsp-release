from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from sqlalchemy.orm import Session

from jose import jwt, JWTError

from backend.core.config.settings import Settings

from backend.core.database.dependency import get_db

from backend.users.models.user import User

from backend.auth.security.session_cookie import (
    SESSION_COOKIE_NAME
)

from urllib.parse import urlparse


# auto_error=False: el token puede venir en la cookie de sesión, no solo
# en la cabecera Authorization (que se mantiene por compatibilidad).
security = HTTPBearer(auto_error=False)


def token_version_ok(payload: dict, user) -> bool:

    """Old tokens stop being valid after logout/revocation."""

    return int(payload.get("ver", 0) or 0) == int(
        getattr(user, "token_version", 0) or 0
    )


def user_claims(user) -> dict:

    """Identity and role ALWAYS from the current row (not the token)."""

    return {
        "user_id": user.id,
        "username": user.username,
        "role": user.role,
    }

SAFE_METHODS = ("GET", "HEAD", "OPTIONS", "TRACE")


def _session_token(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None
):

    """Devuelve (token, origen): cookie HttpOnly primero, cabecera después."""

    if request is not None:

        cookie = request.cookies.get(SESSION_COOKIE_NAME)

        if cookie:

            return cookie, "cookie"

    if credentials and credentials.credentials:

        return credentials.credentials, "header"

    return None, None


def _reject_cross_site(request: Request) -> None:

    """Defensa CSRF adicional para sesiones por cookie.

    SameSite=Lax ya impide que el navegador envíe la cookie en
    peticiones cross-site; además se valida Origin cuando viene (los
    navegadores siempre lo envían en POST/PUT/PATCH/DELETE cross-site).
    """

    if request is None or request.method in SAFE_METHODS:

        return

    origin = request.headers.get("origin")

    if not origin:

        return

    if urlparse(origin).netloc != (request.headers.get("host") or ""):

        raise HTTPException(
            status_code=403,
            detail="Origen no permitido"
        )


def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
    db: Session = Depends(get_db)
):

    token, source = _session_token(request, credentials)

    if not token:
        raise HTTPException(
            status_code=401,
            detail="Not authenticated"
        )

    if source == "cookie":

        _reject_cross_site(request)

    try:

        payload = jwt.decode(
            token,
            Settings.JWT_SECRET,
            algorithms=[
                Settings.JWT_ALGORITHM
            ]
        )

        username = payload.get("sub")


        if username is None:

            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        if payload.get("purpose") == "mfa":

            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        user_id = payload.get("user_id")


        user = db.get(User, user_id)

        if user is None or not user.enabled:

            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        if not token_version_ok(payload, user):

            raise HTTPException(
                status_code=401,
                detail="Session revoked"
            )

        return user_claims(user)


    except JWTError:

        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )


security_optional = HTTPBearer(auto_error=False)


def get_download_user(
    request: Request = None,
    credentials: HTTPAuthorizationCredentials | None = Depends(security_optional),
    db: Session = Depends(get_db)
):

    token = credentials.credentials if credentials else None

    if not token and request is not None:
        token = request.query_params.get("dl")

    if not token:
        raise HTTPException(
            status_code=401,
            detail="Not authenticated"
        )

    try:
        payload = jwt.decode(
            token,
            Settings.JWT_SECRET,
            algorithms=[Settings.JWT_ALGORITHM]
        )
    except JWTError:
        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )

    # Solo tokens emitidos para descarga (ver endpoint download-token).
    if payload.get("purpose") != "download":
        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )

    user = db.get(User, payload.get("user_id"))

    if user is None or not user.enabled:

        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )

    return user_claims(user)
