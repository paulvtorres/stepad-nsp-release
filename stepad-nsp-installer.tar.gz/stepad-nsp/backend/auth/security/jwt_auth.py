from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from sqlalchemy.orm import Session

from jose import jwt, JWTError

from backend.core.config.settings import Settings

from backend.core.database.dependency import get_db

from backend.users.models.user import User


security = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):

    token = credentials.credentials

    try:

        payload = jwt.decode(
            token,
            Settings.JWT_SECRET,
            algorithms=[
                Settings.JWT_ALGORITHM
            ]
        )

        username = payload.get("sub")

        role = payload.get("role")


        if username is None:

            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        if payload.get("purpose") == "mfa":

            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        user_id = payload.get("user_id")


        user = db.get(User, user_id)

        if user is None or not user.enabled:

            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        return {
            "user_id": user_id,
            "username": username,
            "role": role
        }


    except JWTError:

        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )
