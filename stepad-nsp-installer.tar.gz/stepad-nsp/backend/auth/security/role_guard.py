from fastapi import Depends, HTTPException

from backend.auth.security.jwt_auth import get_current_user


def require_role(required_role: str):

    def role_checker(
        current_user: dict = Depends(get_current_user)
    ):

        user_role = current_user.get("role")

        if user_role != required_role:

            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions"
            )

        return current_user

    return role_checker