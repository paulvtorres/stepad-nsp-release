"""Cookie de sesión (HttpOnly) para el panel.

Antes el JWT viajaba en el cuerpo del login y se guardaba en
localStorage: cualquier XSS podía robarlo. Ahora el navegador lo
mantiene en una cookie HttpOnly que JavaScript no puede leer.

- HttpOnly: no accesible desde JS.
- Secure: solo por HTTPS (el panel siempre sirve TLS).
- SameSite=Lax: no se envía en peticiones cross-site (mitiga CSRF).
- Path=/api: solo viaja a la API, no a los estáticos del panel.
"""

from fastapi import Request, Response


SESSION_COOKIE_NAME = "stepad_session"

SESSION_COOKIE_PATH = "/api"


def cookie_secure(request: Request) -> bool:

    if request is None:

        return True

    forwarded = (
        request.headers.get("x-forwarded-proto") or ""
    ).split(",")[0].strip().lower()

    scheme = (request.scope.get("scheme") or "").lower()

    return scheme == "https" or forwarded == "https"


def set_session_cookie(
    response: Response,
    request: Request,
    token: str,
    max_age: int
) -> None:

    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=token,
        max_age=max(1, int(max_age)),
        path=SESSION_COOKIE_PATH,
        httponly=True,
        secure=cookie_secure(request),
        samesite="lax",
    )


def clear_session_cookie(response: Response) -> None:

    response.delete_cookie(
        key=SESSION_COOKIE_NAME,
        path=SESSION_COOKIE_PATH,
    )
