from fastapi import APIRouter, Depends

from backend.auth.security.jwt_auth import get_current_user

from backend.monitoring.services.monitoring_service import (
    MonitoringService
)


router = APIRouter(
    prefix="/system",
    tags=["System"]
)

monitoring = MonitoringService()


@router.get("/monitoring")
def monitoring_status(
    current_user: dict = Depends(get_current_user)
):

    return monitoring.snapshot()
