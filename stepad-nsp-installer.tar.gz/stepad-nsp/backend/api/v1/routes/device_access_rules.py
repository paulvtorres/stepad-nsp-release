from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.rules.services.device_access_rule_service import (
    DeviceAccessRuleService
)

from backend.rules.schemas.create_rule_request import (
    CreateRuleRequest
)

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

router = APIRouter(
    prefix="/devices",
    tags=["Device Access Rules"]
)


service = DeviceAccessRuleService()


@router.get("/{device_id}/rules")
async def get_rules(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_rules(
        device_id,
        db
    )


@router.post("/{device_id}/rules")
async def create_rule(
    device_id: int,
    request: CreateRuleRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.create_rule(
        device_id=device_id,
        action=request.action,
        rule_type=request.rule_type,
        value=request.value,
        db=db
    )


@router.delete("/rules/{rule_id}")
async def delete_rule(
    rule_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete_rule(
        rule_id,
        db
    )