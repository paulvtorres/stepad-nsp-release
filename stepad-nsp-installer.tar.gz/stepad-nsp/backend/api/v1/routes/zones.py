from fastapi import APIRouter, Depends, HTTPException

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.network.zones.services.network_zone_service import (
    NetworkZoneService
)
from backend.network.zones.models.network_zone import NetworkZone
from backend.network.zones.schemas.create_zone_request import (
    CreateZoneRequest
)
from backend.network.zones.schemas.update_zone_request import (
    UpdateZoneRequest
)

from backend.rules.services.zone_rule_service import ZoneRuleService
from backend.rules.schemas.create_zone_rule_request import (
    CreateZoneRuleRequest
)

from backend.firewall.services.zone_isolation_service import (
    ZoneIsolationService
)


router = APIRouter(
    prefix="/zones",
    tags=["Zones"]
)


service = NetworkZoneService()

rule_service = ZoneRuleService()

isolation_service = ZoneIsolationService()



@router.get("/isolation")
def get_isolation_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return isolation_service.status(db)


@router.get("/")
def get_zones(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list_zones(db)



@router.post("/")
def create_zone(
    request: CreateZoneRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    zone = NetworkZone(
        name=request.name,
        description=request.description,
        vlan_id=request.vlan_id,
        physical_interface=request.physical_interface,
        interface_mac=request.interface_mac,
        network_cidr=request.network_cidr,
        gateway_ip=request.gateway_ip,
        dhcp_pool_start=request.dhcp_pool_start,
        dhcp_pool_end=request.dhcp_pool_end,
        is_default=request.is_default,
        enforce_time_cutoff=request.enforce_time_cutoff,
        time_cutoff_schedule_id=request.time_cutoff_schedule_id
    )

    return service.create_zone(db, zone)



@router.patch("/{zone_id}")
def update_zone(
    zone_id: int,
    request: UpdateZoneRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    zone = service.repository.find_by_id(db, zone_id)

    if not zone:

        raise HTTPException(status_code=404, detail="Zone not found")

    return service.update_zone(db, zone, request)



@router.delete("/{zone_id}")
def delete_zone(
    zone_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    zone = service.repository.find_by_id(db, zone_id)

    if not zone:

        raise HTTPException(status_code=404, detail="Zone not found")

    service.delete_zone(db, zone)

    return {"success": True}



@router.get("/{zone_id}/rules")
def get_zone_rules(
    zone_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return rule_service.get_zone_rules(db, zone_id)



@router.post("/{zone_id}/rules")
def create_zone_rule(
    zone_id: int,
    request: CreateZoneRuleRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    try:

        return rule_service.create_rule(db, zone_id, request)

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))



@router.delete("/rules/{rule_id}")
def delete_zone_rule(
    rule_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    rule_service.delete_rule(db, rule_id)

    return {"success": True}
