from fastapi import APIRouter, Depends

from backend.auth.security.jwt_auth import get_current_user

from backend.network.state.services.network_state_service import NetworkStateService


router = APIRouter(
    prefix="/network",
    tags=["Network"]
)


service = NetworkStateService()



@router.get("/state")
async def get_state(
    current_user: dict = Depends(get_current_user)
):

    return service.get_state()