from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.network.devices.services.device_service import DeviceService
from backend.api.schemas.update_device_request import UpdateDeviceRequest
from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles


router = APIRouter(
    prefix="/devices",
    tags=["Devices"],
)


service = DeviceService()


class DeleteDeviceRequest(BaseModel):

    reason: str = ""



@router.get("/")
async def get_devices(
    include_infra: bool = False,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    # Solo lee la base (rapido). El escaneo de red solo se ejecuta
    # con el endpoint POST /devices/scan. include_infra=True muestra
    # tambien impresoras/teléfonos IP/routers (ocultos por defecto).
    return service.get_all_devices(
        db,
        scan=False,
        include_infra=include_infra
    )



@router.get("/live-status")
async def live_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    # Ping ligero en paralelo (~1s) a las IPs conocidas. No descubre
    # nada, solo dice quien responde ahora -> luces verde/rojo en vivo.
    return service.get_live_status(
        db
    )


@router.post("/scan")
async def scan_devices(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    # Escaneo de red explicito (boton "Escanear red").
    return service.get_all_devices(
        db,
        scan=True
    )



@router.get("/{device_id}")
async def get_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_device(
        device_id,
        db
    )



@router.patch("/{device_id}")
async def update_device(
    device_id: int,
    request: UpdateDeviceRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.update_device(
        device_id,
        request,
        db
    )



@router.delete("/{device_id}")
async def delete_device(
    device_id: int,
    request: DeleteDeviceRequest | None = None,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    result = DeviceService().delete_device(
        device_id,
        db,
        user_id=current_user.get("user_id"),
        reason=((request.reason if request else "") or "").strip()
    )

    if not result.get("deleted"):

        raise HTTPException(
            status_code=404,
            detail="Dispositivo no encontrado"
        )

    return {"message": "Dispositivo eliminado"}


@router.post("/{device_id}/refresh")
async def refresh_device(
    device_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):

    device = service.refresh_device(
        device_id,
        db
    )

    if not device:

        raise HTTPException(
            status_code=404,
            detail="Dispositivo no encontrado"
        )

    return device


@router.post("/{device_id}/link/{primary_device_id}")
async def link_device(    device_id: int,
    primary_device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.link_devices(
        device_id,
        primary_device_id,
        db
    )



@router.delete("/{device_id}/link")
async def unlink_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.unlink_device(
        device_id,
        db
    )