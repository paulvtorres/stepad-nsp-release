import ipaddress

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.network.devices.services.device_service import DeviceService
from backend.api.schemas.update_device_request import UpdateDeviceRequest
from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles

from backend.shared.logging.logger import logger


router = APIRouter(
    prefix="/devices",
    tags=["Devices"],
)


service = DeviceService()


class DeleteDeviceRequest(BaseModel):

    reason: str = ""



def _annotate_ip_kind(devices):
    """Marca cada equipo con `ip_kind`: dhcp | reserved | static.

    Lee una sola vez el archivo de leases y la tabla ARP (unos pocos ms):
    si la IP del equipo no tiene lease y no es reserva pero el equipo esta
    presente, su IP es fija (configurada a mano).
    """

    try:

        from backend.core.config.paths import DNSMASQ_LEASES_FILE
        from backend.dhcp.domain.leases import read_leases
        from backend.dhcp.domain.neighbors import arp_mac_by_ip

        lease_by_mac = {
            lease.mac: lease.ip
            for lease in read_leases(DNSMASQ_LEASES_FILE)
        }

        try:

            with open("/proc/net/arp", encoding="utf-8", errors="replace") as file:

                arp = arp_mac_by_ip(file.read())

        except OSError:

            arp = {}

    except Exception as error:
        logger.debug("devices._annotate_ip_kind: %s", error)

        return devices

    if isinstance(devices, dict):

        items = devices.get("devices") or []

    elif isinstance(devices, list):

        items = devices

    else:

        return devices

    try:

        from backend.shared.config.config_service import ConfigService

        dhcp_cfg = ConfigService().get_dhcp_config() or {}

        pool_start = int(ipaddress.ip_address(dhcp_cfg.get("pool_start")))

        pool_end = int(ipaddress.ip_address(dhcp_cfg.get("pool_end")))

    except Exception as error:
        logger.debug("devices._annotate_ip_kind: %s", error)

        pool_start = pool_end = None

    def _inside_pool(value) -> bool:

        if pool_start is None:

            return False

        try:

            number = int(ipaddress.ip_address(value))

        except ValueError:

            return False

        return pool_start <= number <= pool_end

    def _value(item, key):

        if isinstance(item, dict):

            return item.get(key) or ""

        return getattr(item, key, "") or ""

    for device in items:

        mac = str(_value(device, "mac_address")).lower()

        ip = str(
            _value(device, "current_ip") or _value(device, "ip_address")
        )

        permanent = str(_value(device, "permanent_ip"))

        if permanent:

            kind = "reserved"

        elif mac and lease_by_mac.get(mac) == ip:

            kind = "dhcp"

        elif ip and ip in arp:

            # Fija DENTRO del pool = riesgo de choque (el DHCP puede
            # entregarla). Fuera del pool es normal.
            kind = "static" if _inside_pool(ip) else "static_out"

        else:

            kind = None

        if isinstance(device, dict):

            device["ip_kind"] = kind

        else:

            device.ip_kind = kind

    return devices


@router.get("/")
def get_devices(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    # Ruta sincrona (no "async def") a proposito: el cuerpo hace
    # varias queries bloqueantes (psycopg2) + lecturas de red seguidas
    # de forma sincrona. Con "async def" ese trabajo corre sobre el
    # UNICO event loop del proceso (esta API tiene un solo worker) y
    # bloquea TODA la API -- login, dashboard, todo -- mientras dura.
    # FastAPI ejecuta las rutas sincronas en un threadpool aparte, asi
    # que otras peticiones siguen respondiendo aunque esta tarde.
    #
    # Solo lee la base (rapido). El escaneo de red solo se ejecuta
    # con el endpoint POST /devices/scan. Lista todos los equipos
    # con IP en la LAN (incluye teléfonos IP, impresoras, routers).
    return _annotate_ip_kind(
        service.get_all_devices(
            db,
            scan=False,
        )
    )



@router.get("/live-status")
def live_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    # Sincrona por el mismo motivo que get_devices: hace ~N pings
    # bloqueantes por subproceso y no debe congelar el event loop.
    #
    # Ping ligero en paralelo (~1s) a las IPs conocidas. No descubre
    # nada, solo dice quien responde ahora -> luces verde/rojo en vivo.
    return service.get_live_status(
        db
    )


@router.post("/scan")
def scan_devices(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    # Escaneo de red explicito (boton "Escanear red"). Sincrona por
    # el mismo motivo: es la operacion mas pesada de todas (ARP +
    # DHCP + resolucion de hostnames).
    return _annotate_ip_kind(
        service.get_all_devices(
            db,
            scan=True
        )
    )



@router.get("/settings")
def get_device_settings(
    current_user: dict = Depends(get_current_user)
):
    from backend.shared.config.config_service import ConfigService
    cfg = ConfigService().get().get("devices_ui", {})
    return {"show_extra": cfg.get("show_extra", False)}


@router.put("/settings")
def update_device_settings(
    request: dict,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    from backend.shared.config.config_service import ConfigService
    svc = ConfigService()
    cfg = svc.get().get("devices_ui", {})
    if "show_extra" in request:
        cfg["show_extra"] = bool(request["show_extra"])
    svc.update_section("devices_ui", cfg)
    return {"show_extra": cfg.get("show_extra", False)}


@router.get("/ip-pool")
def get_ip_pool(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR))
):
    """Returns free IPs in the pool and IPs of offline devices."""
    import ipaddress
    from backend.shared.config.config_service import ConfigService
    from backend.network.devices.models.network_device import NetworkDevice

    config_svc = ConfigService()
    dhcp = config_svc.get_dhcp_config()

    pool_start = dhcp.get("pool_start", "192.168.1.20")
    pool_end = dhcp.get("pool_end", "192.168.1.150")
    exclusions = dhcp.get("excluded_ips", [])

    # Build set of excluded IPs
    excluded = set()
    for exc in exclusions:
        if "-" in str(exc):
            parts = str(exc).split("-")
            try:
                s = int(ipaddress.ip_address(parts[0].strip()))
                e = int(ipaddress.ip_address(parts[1].strip()))
                for i in range(s, e + 1):
                    excluded.add(str(ipaddress.ip_address(i)))
            except Exception as error:
                logger.debug("devices.get_ip_pool: %s", error)
        else:
            excluded.add(str(exc).strip())

    # Get all device IPs
    devices = db.query(NetworkDevice).filter(
        NetworkDevice.ip_address.isnot(None),
        NetworkDevice.mac_address.isnot(None),
    ).all()

    device_ips = {}
    offline_ips = []
    for d in devices:
        if d.ip_address:
            device_ips[d.ip_address] = {"id": d.id, "hostname": d.hostname or d.display_name or d.ip_address, "status": d.status}
            if d.status == "OFFLINE":
                offline_ips.append({"id": d.id, "ip": d.ip_address, "hostname": d.hostname or d.display_name or d.ip_address, "mac": d.mac_address})

    # Calculate free IPs
    try:
        start = int(ipaddress.ip_address(pool_start))
        end = int(ipaddress.ip_address(pool_end))
        free_ips = []
        for ip_int in range(start, end + 1):
            ip_str = str(ipaddress.ip_address(ip_int))
            if ip_str not in device_ips and ip_str not in excluded:
                free_ips.append(ip_str)
    except Exception as error:
        logger.debug("devices.get_ip_pool: %s", error)
        free_ips = []

    return {
        "pool_start": pool_start,
        "pool_end": pool_end,
        "total_pool": len(free_ips) + len(device_ips),
        "free_count": len(free_ips),
        "free_ips": free_ips,
        "offline_ips": offline_ips,
        "used_count": len(device_ips),
    }


@router.get("/export")
def export_devices(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    """Excel con los mismos datos que muestra la pantalla de Dispositivos."""

    from io import BytesIO

    from openpyxl import Workbook
    from openpyxl.styles import Font
    from openpyxl.utils import get_column_letter

    from backend.network.zones.models.network_zone import NetworkZone
    from backend.shared.utils.datetimes import format_ecuador_datetime

    zones = {zone.id: zone.name for zone in db.query(NetworkZone).all()}

    devices = _annotate_ip_kind(
        service.get_all_devices(db, scan=False)
    )

    kind_labels = {
        "dhcp": "DHCP",
        "reserved": "Reservada",
        "static": "Fija (en el pool)",
        "static_out": "Fija (fuera del pool)",
    }

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Dispositivos"

    headers = [
        "Nombre", "Hostname", "Tipo de dispositivo", "Sistema",
        "IP actual", "IP reservada", "MAC", "NICs adicionales",
        "Fabricante", "Estado", "Zona", "Grupo",
        "Tipo de IP", "Reservado", "Equipo de empresa", "Bloqueado",
        "Límite (kbps)", "Primera vez", "Última vez",
    ]
    sheet.append(headers)

    for cell in sheet[1]:
        cell.font = Font(bold=True)

    for device in devices:
        groups = ", ".join(
            (
                group.get("name")
                if isinstance(group, dict)
                else getattr(group, "name", "")
            )
            for group in (getattr(device, "groups", None) or [])
            if group
        )
        extra_nics = ", ".join(
            nic.get("mac_address") or ""
            for nic in (getattr(device, "linked_devices", None) or [])
            if nic.get("mac_address")
        )
        sheet.append([
            device.display_name or device.hostname or "Desconocido",
            device.hostname or "",
            device.device_type or "",
            getattr(device, "os_name", None) or "",
            device.ip_address or "",
            device.permanent_ip or "",
            device.mac_address or "",
            extra_nics,
            device.vendor or "",
            device.status or "",
            zones.get(device.zone_id, "") or "",
            groups,
            kind_labels.get(getattr(device, "ip_kind", ""), ""),
            "Sí" if (device.is_permanent or device.permanent_ip) else "No",
            "Sí" if device.is_company_asset else "No",
            "Sí" if device.blocked else "No",
            device.bandwidth_limit_kbps or "",
            format_ecuador_datetime(device.first_seen, ""),
            format_ecuador_datetime(device.last_seen, ""),
        ])

    for index, width in enumerate(
        [28, 22, 18, 14, 15, 15, 20, 24, 20, 10, 18, 22, 18, 10, 12, 10, 12, 18, 18],
        start=1,
    ):
        sheet.column_dimensions[get_column_letter(index)].width = width

    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions

    buffer = BytesIO()
    workbook.save(buffer)
    buffer.seek(0)

    return Response(
        content=buffer.getvalue(),
        media_type=(
            "application/vnd.openxmlformats-officedocument"
            ".spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                'attachment; filename="dispositivos-stepad.xlsx"'
            )
        },
    )


@router.get("/{device_id}/ip-history")
async def get_device_ip_history(
    device_id: int,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from sqlalchemy import or_
    from backend.network.devices.models.network_device import NetworkDevice
    from backend.network.devices.models.device_ip_history import (
        DeviceIpHistory,
    )
    from backend.shared.utils.datetimes import to_iso_utc

    device = service.repository.find_by_id(db, device_id)

    if not device:

        raise HTTPException(status_code=404, detail="Dispositivo no encontrado")

    query = db.query(DeviceIpHistory).filter(
        or_(
            DeviceIpHistory.device_id == device.id,
            DeviceIpHistory.mac_address == (device.mac_address or "").lower(),
        )
    )

    rows = (
        query.order_by(DeviceIpHistory.ended_at.desc())
        .limit(max(1, min(200, int(limit))))
        .all()
    )

    return {
        "device_id": device.id,
        "items": [
            {
                "id": row.id,
                "ip_address": row.ip_address,
                "mac_address": row.mac_address,
                "source": row.source,
                "started_at": to_iso_utc(row.started_at),
                "ended_at": to_iso_utc(row.ended_at),
            }
            for row in rows
        ],
    }


@router.get("/{device_id}")
async def get_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_device(
        device_id,
        db
    )



@router.patch("/{device_id}")
async def update_device(
    device_id: int,
    request: UpdateDeviceRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.update_device(
        device_id,
        request,
        db
    )



@router.delete("/{device_id}")
async def delete_device(
    device_id: int,
    request: DeleteDeviceRequest | None = None,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    result = DeviceService().delete_device(
        device_id,
        db,
        user_id=current_user.get("user_id"),
        reason=((request.reason if request else "") or "").strip()
    )

    if not result.get("deleted"):

        raise HTTPException(
            status_code=404,
            detail="Dispositivo no encontrado"
        )

    return {"message": "Dispositivo eliminado"}


@router.post("/{device_id}/refresh")
def refresh_device(
    device_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):

    # Sincrona: resuelve NetBIOS/mDNS/LLMNR y recorre leases DHCP de
    # forma bloqueante -- mismo motivo que los endpoints de arriba.
    device = service.refresh_device(
        device_id,
        db
    )

    if not device:

        raise HTTPException(
            status_code=404,
            detail="Dispositivo no encontrado"
        )

    return device


@router.post("/{device_id}/link/{primary_device_id}")
async def link_device(    device_id: int,
    primary_device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.link_devices(
        device_id,
        primary_device_id,
        db
    )



@router.delete("/{device_id}/link")
async def unlink_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.unlink_device(
        device_id,
        db
    )