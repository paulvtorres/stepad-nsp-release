from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.notifications.services.report_service import ReportService


router = APIRouter(
    prefix="/logs/navigation",
    tags=["Navigation Logs"]
)


repository = DnsQueryLogRepository()

report_service = ReportService()



@router.get("/summary")
def get_navigation_summary(
    start: datetime | None = Query(None),
    end: datetime | None = Query(None),
    device_id: int | None = Query(None),
    domain: str | None = Query(None),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    rows = repository.find_summary(
        db,
        start=start,
        end=end,
        device_id=device_id,
        domain_contains=domain
    )

    return [
        {
            "device_id": row.device_id,
            "device_name": (
                row.device_hostname
                or row.hostname
                or row.ip_address
                or "Desconocido"
            ),
            "device_ip": row.ip_address,
            "domain": row.domain,
            "visit_count": row.visit_count,
            "first_seen": _utc_aware(row.first_seen),
            "last_seen": _utc_aware(row.last_seen),
            "blocked_count": row.blocked_count or 0,
            "active_minutes": row.active_minutes or 0
        }
        for row in rows
    ]


def _utc_aware(value):
    """Los logs se guardan en UTC (naive); se marcan como UTC para que
    el frontend los convierta a la hora local del navegador."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


@router.get("/export")
def export_navigation_summary(
    start: datetime | None = Query(None),
    end: datetime | None = Query(None),
    device_id: int | None = Query(None),
    domain: str | None = Query(None),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    buffer = report_service.build_excel(
        db,
        start=start,
        end=end,
        device_id=device_id,
        domain=domain
    )

    return Response(
        content=buffer.getvalue(),
        media_type=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                "attachment; "
                "filename=resumen-navegacion.xlsx"
            )
        }
    )
