from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.network.interfaces.registry.services.interface_registry_admin_service import (
    InterfaceRegistryAdminService
)

from backend.network.interfaces.registry.schemas.assign_interface_role_request import (
    AssignInterfaceRoleRequest
)


router = APIRouter(
    prefix="/interfaces/registry",
    tags=["Interface Registry"],
)


service = InterfaceRegistryAdminService()



@router.get("/")
async def list_interfaces(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    # Lectura rapida (sin re-detectar cable): solo con el boton
    # "Rescanear" se hace el escaneo profundo.
    return service.list_interfaces(db, deep=False)



@router.post("/rescan")
async def rescan_interfaces(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list_interfaces(db, deep=True)



@router.get("/pending")
async def pending_actions(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Feeds the web notification banner: any interface awaiting a role
    assignment (new hardware detected) or marked missing (was
    assigned, no longer detected). Empty list means nothing needs
    the admin's attention.
    """

    interfaces = service.list_interfaces(db)

    return [

        entry for entry in interfaces

        if entry["status"] in ("pending_assignment", "missing")

    ]



@router.post("/compare-wan")
async def compare_wan(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.compare_wan()



@router.post("/{interface_id}/test-connectivity")
async def test_connectivity(
    interface_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.test_connectivity(db, interface_id)



@router.post("/{interface_id}/assign")
async def assign_interface(
    interface_id: int,
    request: AssignInterfaceRoleRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.assign(
        db,
        interface_id,
        request.role,
        request.display_name,
        request.priority
    )



@router.post("/{interface_id}/unassign")
async def unassign_interface(
    interface_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.unassign(db, interface_id)



@router.delete("/{interface_id}")
async def delete_interface(
    interface_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete(db, interface_id)
