from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.monitoring.services.wan_monitor_service import (
    WanMonitorService,
)
from backend.monitoring.schemas.wan_monitor import (
    WanMonitorSettingsRequest,
)


router = APIRouter(
    prefix="/wan-monitor",
    tags=["WAN Monitor"],
)

service = WanMonitorService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return service.get_settings(db)


@router.put("/settings")
def save_settings(
    request: WanMonitorSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.save_settings(db, request)


@router.get("/status")
def get_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return service.get_status(db)


@router.get("/history")
def get_history(
    hours: int = 24,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return service.get_history(db, max(1, min(720, hours)))


@router.post("/snapshot")
def snapshot_now(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.snapshot(db)
