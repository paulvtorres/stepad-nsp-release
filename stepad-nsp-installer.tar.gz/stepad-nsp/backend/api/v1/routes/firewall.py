from fastapi import APIRouter, Depends

from pydantic import BaseModel

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.firewall.services.firewall_service import FirewallService
from backend.firewall.services.firewall_diagnosis_service import (
    FirewallDiagnosisService,
)
from backend.firewall.services.firewall_hardening_service import (
    FirewallHardeningService,
)


class HardeningRequest(BaseModel):

    enabled: bool


class AccessWindowRequest(BaseModel):

    start_hour: int | None = None

    end_hour: int | None = None


router = APIRouter(
    prefix="/firewall",
    tags=["Firewall"],
)


diagnosis_service = FirewallDiagnosisService()

service = FirewallService()

hardening_service = FirewallHardeningService()



@router.get("/status")
async def get_status(current_user: dict = Depends(get_current_user)):

    return service.get_status()



@router.get("/diagnosis")
async def diagnosis(current_user: dict = Depends(get_current_user)):

    return diagnosis_service.diagnose()



@router.post("/devices/{mac}/block")
async def block_device(
    mac: str,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.block_device(
        mac
    )



@router.delete("/devices/{mac}/block")
async def unblock_device(
    mac: str,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.unblock_device(
        mac
    )


@router.get("/hardening")
async def get_hardening(
    current_user: dict = Depends(get_current_user)
):

    return hardening_service.get_settings()


@router.put("/hardening")
async def set_hardening(
    request: HardeningRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return hardening_service.set_enabled(request.enabled)


@router.post("/hardening/review")
async def mark_review(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return hardening_service.mark_review()


@router.post("/hardening/access-review")
async def mark_access_review(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return hardening_service.mark_access_review()


@router.put("/hardening/access-window")
async def save_access_window(
    request: AccessWindowRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return hardening_service.save_admin_access_window(
        request.start_hour,
        request.end_hour
    )