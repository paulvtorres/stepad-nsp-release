from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.organization.services.organization_service import (
    OrganizationService
)
from backend.organization.schemas.organization_settings import (
    OrganizationSettingsRequest
)


router = APIRouter(
    prefix="/organization",
    tags=["Organization"]
)

service = OrganizationService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_settings(db)


@router.put("/settings")
def save_settings(
    request: OrganizationSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_settings(db, request)
