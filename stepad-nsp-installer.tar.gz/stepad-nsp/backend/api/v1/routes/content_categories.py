from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.content.services.content_category_service import (
    ContentCategoryService
)

from backend.content.services.malware_feed_service import (
    MalwareFeedService
)

from pydantic import BaseModel


class CategoryEnabledRequest(BaseModel):

    enabled: bool


class CategoryDomainRequest(BaseModel):

    domain: str


router = APIRouter(
    prefix="/content-categories",
    tags=["Content Categories"]
)

service = ContentCategoryService()


@router.get("/")
def list_categories(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list(db)


@router.get("/{key}")
def category_detail(
    key: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.detail(db, key)


@router.put("/{key}/enabled")
def set_enabled(
    key: str,
    request: CategoryEnabledRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.set_enabled(
        db,
        key,
        request.enabled,
        user_id=current_user["user_id"]
    )


@router.post("/{key}/domains")
def add_domain(
    key: str,
    request: CategoryDomainRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.add_domain(
        db,
        key,
        request.domain,
        user_id=current_user["user_id"]
    )


@router.delete("/{key}/domains/{domain}")
def remove_domain(
    key: str,
    domain: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.remove_domain(
        db,
        key,
        domain,
        user_id=current_user["user_id"]
    )


@router.post("/{key}/refresh")
def refresh_feed(
    key: str,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    if key != "malware":

        return {
            "success": False,
            "message": "Solo la categoría malware tiene feed automático"
        }

    return MalwareFeedService().refresh()
