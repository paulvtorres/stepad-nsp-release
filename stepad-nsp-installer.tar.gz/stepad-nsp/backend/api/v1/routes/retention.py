from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.core.database.dependency import get_db
from backend.retention.services.retention_service import RetentionService
from backend.shared.constants.user_roles import UserRoles


router = APIRouter(prefix="/retention", tags=["retention"])

service = RetentionService()


class RetentionUpdate(BaseModel):

    retention_days: int

    enabled: bool | None = None


@router.get("")
def list_retention(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return service.list_settings(db)


@router.put("/{data_type}")
def save_retention(
    data_type: str,
    request: RetentionUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    try:

        return service.set_retention(
            db,
            data_type,
            request.retention_days,
            request.enabled,
        )

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))


@router.post("/run")
def run_cleanup(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.run(db)
