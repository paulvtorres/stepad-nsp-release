from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from pydantic import BaseModel

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.config_revisions.services.config_revision_service import (
    ConfigRevisionService
)


class CaptureRequest(BaseModel):

    label: str | None = None


router = APIRouter(
    prefix="/config-revisions",
    tags=["Config Revisions"]
)

service = ConfigRevisionService()


@router.get("/")
def list_revisions(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list(db)


@router.post("/capture")
def capture_revision(
    request: CaptureRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.capture(
        db,
        user_id=current_user["user_id"],
        label=request.label or ""
    )


@router.get("/{revision_id}")
def revision_detail(
    revision_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.detail(db, revision_id)


@router.post("/{revision_id}/restore")
def restore_revision(
    revision_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.restore(
        db,
        revision_id,
        user_id=current_user["user_id"]
    )
