from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Query

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.firewall.dns_security.adapters.linux.linux_encrypted_dns_provider import (
    LinuxEncryptedDnsProvider
)


router = APIRouter(
    prefix="/protection",
    tags=["Protection"]
)


dns_repo = DnsQueryLogRepository()

device_repo = DeviceRepository()

provider = LinuxEncryptedDnsProvider()


EVASION_KEYS = (
    "dot_udp",
    "dot_tcp",
    "doh_v4",
    "doh_v6",
    "doh_v4_quic",
    "doh_v6_quic"
)

SERVICE_KEYS = (
    "service_block_v4",
    "service_block_v6"
)


def _sum_packets(counters, keys):

    return sum(
        counters.get(key, {}).get("packets", 0)
        for key in keys
    )


def _sum_bytes(counters, keys):

    return sum(
        counters.get(key, {}).get("bytes", 0)
        for key in keys
    )


@router.get("/summary")
def get_protection_summary(
    hours: int = Query(24, ge=1, le=168),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    start = datetime.utcnow() - timedelta(hours=hours)

    week_ago = datetime.utcnow() - timedelta(days=7)

    dns = dns_repo.find_totals(
        db,
        start=start
    )

    top_domains = dns_repo.top_blocked_domains(
        db,
        start=start,
        limit=10
    )

    top_devices = dns_repo.top_blocked_devices(
        db,
        start=start,
        limit=10
    )

    recent = dns_repo.recent_blocked(
        db,
        start=start,
        limit=15
    )

    new_devices = device_repo.count_new_since(
        db,
        since=week_ago
    )

    counters = provider.get_counters()

    return {
        "window_hours": hours,
        "dns": {
            "total": dns["total"],
            "blocked": dns["blocked"]
        },
        "evasion": {
            "packets": _sum_packets(counters, EVASION_KEYS),
            "bytes": _sum_bytes(counters, EVASION_KEYS),
            "rules": {
                key: counters.get(key)
                for key in EVASION_KEYS
            }
        },
        "service_block": {
            "packets": _sum_packets(counters, SERVICE_KEYS),
            "bytes": _sum_bytes(counters, SERVICE_KEYS),
            "rules": {
                key: counters.get(key)
                for key in SERVICE_KEYS
            }
        },
        "top_blocked_domains": [
            {
                "domain": row.domain,
                "attempts": row.attempts,
                "last_seen": row.last_seen
            }
            for row in top_domains
        ],
        "top_blocked_devices": [
            {
                "device_id": row.device_id,
                "device_name": row.hostname or row.ip_address or "Desconocido",
                "device_ip": row.ip_address,
                "attempts": row.attempts
            }
            for row in top_devices
        ],
        "recent_blocked": [
            {
                "domain": row.domain,
                "client_ip": row.client_ip,
                "device_name": row.hostname or "Desconocido",
                "queried_at": row.queried_at
            }
            for row in recent
        ],
        "new_devices_7d": new_devices
    }
