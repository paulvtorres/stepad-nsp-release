
from fastapi import APIRouter, Depends

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles

from backend.bandwidth.services.bandwidth_service import (
    BandwidthService
)

from backend.bandwidth.services.live_traffic_service import (
    live_traffic_service
)


router = APIRouter(
    prefix="/bandwidth",
    tags=["Bandwidth"]
)

service = BandwidthService()


@router.get("/status")
def bandwidth_status(
    current_user: dict = Depends(get_current_user)
):

    return service.apply()


@router.get("/live")
def bandwidth_live(
    history: int = 0,
    current_user: dict = Depends(get_current_user)
):

    return live_traffic_service.snapshot(
        include_history=bool(history)
    )


@router.post("/apply")
def apply_bandwidth(
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.apply()
