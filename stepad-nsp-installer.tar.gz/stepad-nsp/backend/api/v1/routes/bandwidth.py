import subprocess

from fastapi import APIRouter, Depends

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles

from backend.bandwidth.services.bandwidth_service import (
    BandwidthService
)


router = APIRouter(
    prefix="/bandwidth",
    tags=["Bandwidth"]
)

service = BandwidthService()


@router.get("/status")
def bandwidth_status(
    current_user: dict = Depends(get_current_user)
):

    return service.apply()


@router.post("/apply")
def apply_bandwidth(
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.apply()
