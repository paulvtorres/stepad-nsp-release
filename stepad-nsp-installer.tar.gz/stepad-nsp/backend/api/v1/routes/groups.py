from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from pydantic import BaseModel

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.groups.services.group_service import GroupService


class CreateGroupRequest(BaseModel):

    name: str

    description: str | None = None


class UpdateGroupRequest(BaseModel):

    name: str | None = None

    description: str | None = None

    is_default: bool | None = None

    bandwidth_limit_kbps: int | None = None


class GroupRuleRequest(BaseModel):

    action: str

    domain: str


class GroupCategoriesRequest(BaseModel):

    keys: list[str] = []


router = APIRouter(
    prefix="/groups",
    tags=["Groups"]
)

service = GroupService()

_UNSET = object()


@router.get("/")
def list_groups(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list_groups(db)


@router.post("/")
def create_group(
    request: CreateGroupRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.create_group(
        db,
        name=request.name,
        description=request.description,
        user_id=current_user["user_id"]
    )


@router.patch("/{group_id}")
def update_group(
    group_id: int,
    request: UpdateGroupRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.update_group(
        db,
        group_id,
        name=request.name,
        description=request.description,
        is_default=request.is_default,
        bandwidth_limit_kbps=(
            request.bandwidth_limit_kbps
            if "bandwidth_limit_kbps" in request.model_fields_set
            else _UNSET
        ),
        user_id=current_user["user_id"]
    )


@router.delete("/{group_id}")
def delete_group(
    group_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete_group(db, group_id, current_user["user_id"])


@router.get("/{group_id}/devices")
def group_devices(
    group_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.group_devices(db, group_id)


@router.put("/{group_id}/devices/{device_id}")
def add_device(
    group_id: int,
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.add_device(
        db,
        group_id,
        device_id,
        current_user["user_id"]
    )


@router.delete("/{group_id}/devices/{device_id}")
def remove_device(
    group_id: int,
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.remove_device(
        db,
        group_id,
        device_id,
        current_user["user_id"]
    )


@router.get("/{group_id}/rules")
def list_rules(
    group_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list_rules(db, group_id)


@router.post("/{group_id}/rules")
def add_rule(
    group_id: int,
    request: GroupRuleRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.add_rule(
        db,
        group_id,
        action=request.action,
        domain=request.domain,
        user_id=current_user["user_id"]
    )


@router.delete("/rules/{rule_id}")
def delete_rule(
    rule_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete_rule(db, rule_id, current_user["user_id"])


@router.get("/{group_id}/categories")
def group_categories(
    group_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.group_categories(db, group_id)


@router.put("/{group_id}/categories")
def set_group_categories(
    group_id: int,
    request: GroupCategoriesRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.set_group_categories(
        db,
        group_id,
        request.keys,
        current_user["user_id"]
    )
