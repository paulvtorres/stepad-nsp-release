from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.notifications.services.notification_service import (
    NotificationService
)
from backend.notifications.schemas.notification_settings import (
    NotificationSettingsRequest
)


router = APIRouter(
    prefix="/notifications",
    tags=["Notifications"]
)

service = NotificationService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_settings(db)


@router.put("/settings")
def save_settings(
    request: NotificationSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_settings(db, request)


@router.post("/test")
def send_test(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.send_test(db)


@router.post("/send-now")
def send_now(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.send_report(db)
