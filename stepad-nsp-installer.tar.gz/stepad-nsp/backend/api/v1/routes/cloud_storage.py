from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.backups.services.cloud_storage_service import (
    CloudStorageService
)
from backend.backups.schemas.cloud_storage_settings import (
    CloudStorageSettingsRequest
)


router = APIRouter(
    prefix="/cloud-storage",
    tags=["Cloud Storage"]
)

service = CloudStorageService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_settings(db)


@router.put("/settings")
def save_settings(
    request: CloudStorageSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_settings(db, request)


@router.post("/test")
def test_connection(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.test_connection(db)


@router.post("/upload")
def upload_now(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.upload_logs(db, force=True)
