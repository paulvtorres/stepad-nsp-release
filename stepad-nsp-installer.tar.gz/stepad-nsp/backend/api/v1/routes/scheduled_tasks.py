from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.auth.security.jwt_auth import get_current_user
from backend.core.database.dependency import get_db
from backend.maintenance.services.scheduled_tasks_service import (
    ScheduledTasksService,
)


router = APIRouter(prefix="/maintenance", tags=["maintenance"])


@router.get("/scheduled")
def scheduled(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return ScheduledTasksService().status(db)
