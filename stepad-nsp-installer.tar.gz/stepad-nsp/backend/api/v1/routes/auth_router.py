from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session

from backend.auth.schemas.login_request import LoginRequest
from backend.auth.schemas.change_password import ChangePasswordRequest
from backend.auth.schemas.mfa_schemas import (
    MfaCodeRequest,
    MfaLoginRequest,
    DisableMfaRequest
)
from backend.auth.services.auth_service import AuthService
from backend.auth.services.brute_force_protection import brute_force_protection

from backend.core.database.dependency import get_db
from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles
from backend.auth.security.session_cookie import (
    set_session_cookie,
    clear_session_cookie,
)
from backend.users.models.user import User

from backend.core.config.settings import Settings

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"]
)

service = AuthService()


def _token_from(result):

    """El servicio devuelve un LoginResponse (Pydantic); se acepta dict también."""

    if isinstance(result, dict):

        return result.get("access_token")

    return getattr(result, "access_token", None)


def _set_cookie_if_token(
    response: Response,
    req: Request,
    result
) -> None:

    """Si el login devolvió un token, lo deja también en cookie HttpOnly."""

    token = _token_from(result)

    if not token:

        return

    set_session_cookie(
        response,
        req,
        token,
        Settings.JWT_EXPIRE_MINUTES * 60
    )


@router.post("/login")
def login(
    request: LoginRequest,
    response: Response,
    db: Session = Depends(get_db),
    req: Request = None,
):
    client_ip = req.client.host if req else "unknown"

    if brute_force_protection.is_blocked(client_ip):
        return {
            "success": False,
            "message": "IP bloqueada temporalmente por intentos excesivos. Intente mas tarde.",
            "access_token": None,
        }

    result = service.login(db, request)

    if isinstance(result, dict) and not result.get("success", True):
        brute_force_protection.record_failed_attempt(client_ip)

    if isinstance(result, dict) and result.get("success", True):
        brute_force_protection.record_successful_login(client_ip)

    _set_cookie_if_token(response, req, result)

    return result


@router.post("/sessions/revoke-all")
def revoke_all_sessions(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    users = db.query(User).all()

    for user in users:

        user.token_version = int(user.token_version or 0) + 1

    db.commit()

    return {"success": True, "revoked": len(users)}


@router.post("/logout")
def logout(
    response: Response,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    # Revocacion en servidor: invalida TODOS los tokens emitidos para el
    # usuario (no solo borra la cookie de este navegador).
    user = db.get(User, current_user.get("user_id"))

    if user is not None:

        user.token_version = int(user.token_version or 0) + 1

        db.commit()

    clear_session_cookie(response)

    return {"success": True}

@router.post("/change-password")
def change_password(
    request: ChangePasswordRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.change_password(
        db=db,
        user_id=current_user["user_id"],
        current_password=request.current_password,
        new_password=request.new_password
    )

@router.post("/login/mfa")
def login_mfa(
    request: MfaLoginRequest,
    response: Response,
    req: Request = None,
    db: Session = Depends(get_db)
):

    result = service.complete_mfa_login(
        db=db,
        mfa_token=request.mfa_token,
        code=request.code
    )

    # El segundo factor también emite la sesión: misma cookie HttpOnly.
    token = _token_from(result)

    if token:

        set_session_cookie(
            response,
            req,
            token,
            Settings.JWT_EXPIRE_MINUTES * 60
        )

    return result

@router.post("/mfa/setup")
def mfa_setup(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.setup_mfa(
        db=db,
        user_id=current_user["user_id"]
    )

@router.post("/mfa/confirm")
def mfa_confirm(
    request: MfaCodeRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.confirm_mfa(
        db=db,
        user_id=current_user["user_id"],
        code=request.code
    )

@router.post("/mfa/disable")
def mfa_disable(
    request: DisableMfaRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.disable_mfa(
        db=db,
        user_id=current_user["user_id"],
        current_password=request.current_password
    )

@router.get("/me")
def get_me(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):

    user = db.get(User, current_user["user_id"])

    return {
        "authenticated": True,
        "user": current_user,
        "password_expired": service.is_password_expired(
            user
        ),
        "mfa_enabled": user.mfa_enabled if user else False,
        "mfa_setup_required": service.is_mfa_setup_required(
            user
        ),
        "mfa_mandatory": Settings.MFA_REQUIRED_FOR_ADMINS
    }