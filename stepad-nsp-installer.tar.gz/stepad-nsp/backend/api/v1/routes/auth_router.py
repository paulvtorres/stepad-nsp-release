from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.auth.schemas.login_request import LoginRequest
from backend.auth.schemas.change_password import ChangePasswordRequest
from backend.auth.schemas.mfa_schemas import (
    MfaCodeRequest,
    MfaLoginRequest,
    DisableMfaRequest
)
from backend.auth.services.auth_service import AuthService

from backend.core.database.dependency import get_db
from backend.auth.security.jwt_auth import get_current_user
from backend.users.models.user import User

from backend.core.config.settings import Settings

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"]
)

service = AuthService()


@router.post("/login")
def login(
    request: LoginRequest,
    db: Session = Depends(get_db)
):

    return service.login(
        db,
        request
    )

@router.post("/change-password")
def change_password(
    request: ChangePasswordRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.change_password(
        db=db,
        user_id=current_user["user_id"],
        current_password=request.current_password,
        new_password=request.new_password
    )

@router.post("/login/mfa")
def login_mfa(
    request: MfaLoginRequest,
    db: Session = Depends(get_db)
):

    return service.complete_mfa_login(
        db=db,
        mfa_token=request.mfa_token,
        code=request.code
    )

@router.post("/mfa/setup")
def mfa_setup(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.setup_mfa(
        db=db,
        user_id=current_user["user_id"]
    )

@router.post("/mfa/confirm")
def mfa_confirm(
    request: MfaCodeRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.confirm_mfa(
        db=db,
        user_id=current_user["user_id"],
        code=request.code
    )

@router.post("/mfa/disable")
def mfa_disable(
    request: DisableMfaRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.disable_mfa(
        db=db,
        user_id=current_user["user_id"],
        current_password=request.current_password
    )

@router.get("/me")
def get_me(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):

    user = db.get(User, current_user["user_id"])

    return {
        "authenticated": True,
        "user": current_user,
        "password_expired": service.is_password_expired(
            user
        ),
        "mfa_enabled": user.mfa_enabled if user else False,
        "mfa_setup_required": service.is_mfa_setup_required(
            user
        ),
        "mfa_mandatory": Settings.MFA_REQUIRED_FOR_ADMINS
    }