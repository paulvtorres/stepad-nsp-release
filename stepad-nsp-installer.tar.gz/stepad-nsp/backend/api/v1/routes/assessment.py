"""Authorized vulnerability assessment endpoints."""

from fastapi import APIRouter, Depends, HTTPException

from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles

router = APIRouter(
    prefix="/assessment",
    tags=["assessment"],
    dependencies=[Depends(require_role(UserRoles.ADMIN))],
)


@router.post("/network")
def start_network(payload: dict, current_user: dict = Depends(require_role(UserRoles.ADMIN))):
    from backend.assessment.services.network_assessment_service import (
        NetworkAssessmentService,
    )

    user_id = current_user.get("id") if isinstance(current_user, dict) else None
    return NetworkAssessmentService().start(
        (payload or {}).get("cidr", ""),
        bool((payload or {}).get("authorized")),
        user_id,
    )


@router.get("/network")
def list_networks():
    from backend.assessment.services.network_assessment_service import (
        NetworkAssessmentService,
    )

    return {"assessments": NetworkAssessmentService().list()}


@router.get("/network/{assessment_id}")
def get_network(assessment_id: str):
    from backend.assessment.services.network_assessment_service import (
        NetworkAssessmentService,
    )

    result = NetworkAssessmentService().get(assessment_id)
    if result is None:
        raise HTTPException(404, "Evaluación no encontrada.")
    return result


@router.post("/self")
def self_audit():
    from backend.assessment.services.self_assessment_service import (
        SelfAssessmentService,
    )

    return SelfAssessmentService().run()
