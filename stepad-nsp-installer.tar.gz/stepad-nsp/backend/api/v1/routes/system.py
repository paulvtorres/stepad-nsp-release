import subprocess
import threading

from pathlib import Path

from fastapi import APIRouter, Depends

from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.core.lifecycle.services.system_status_service import SystemStatusService

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.shared.constants.app_version import git_commit, installed_version


class ModulesRequest(BaseModel):

    enabled_keys: list[str] = []


class PowerRequest(BaseModel):

    confirm: bool = False


class MonitoringSettingsRequest(BaseModel):

    cpu_threshold: int | None = None
    ram_threshold: int | None = None
    disk_threshold: int | None = None
    window_minutes: int | None = None
    disk_free_min_gb: int | None = None
    rogue_dhcp_scan_enabled: bool | None = None
    rogue_dhcp_scan_minutes: int | None = None
    device_archive_days: int | None = None


from backend.system.services.update_service import (
    update_status,
    start_update
)

from backend.shared.logging.logger import logger
from backend.shared.datetime_utils import utcnow
from datetime import timedelta


router = APIRouter(
    prefix="/system",
    tags=["System"]
)


service = SystemStatusService()

ENV_FILE = Path("/etc/stepad/stepad.env")

REMOTE_ADMIN_KEY = "STEPAD_VPN_REQUIRE_REMOTE_ADMIN"


def _read_env() -> dict:

    values = {}

    if ENV_FILE.exists():

        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():

            line = line.strip()

            if not line or "=" not in line or line.startswith("#"):

                continue

            key, value = line.split("=", 1)

            values[key.strip()] = value.strip().strip("\"'")

    return values


def _write_env_value(
    key: str,
    value: str
):

    values = _read_env()

    values[key] = value

    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)

    ENV_FILE.write_text(
        "\n".join(f"{k}={v}" for k, v in values.items()) + "\n",
        encoding="utf-8"
    )

    ENV_FILE.chmod(0o600)


def _restart_in_background():

    def run():

        subprocess.run(
            ["systemctl", "restart", "stepad-nsp"],
            timeout=60
        )

    thread = threading.Thread(target=run, daemon=True)

    thread.start()


class RemoteAdminRequest(BaseModel):

    enabled: bool


@router.get("/status")
def status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return service.get_status(db)


@router.get("/database-health")
def database_health(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    from backend.monitoring.services.database_health_service import (
        DatabaseHealthService,
    )

    return DatabaseHealthService().get(db)


@router.get("/operational-health")
def operational_health(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    from backend.monitoring.services.operational_health_service import (
        OperationalHealthService,
    )

    return OperationalHealthService().get(db)


@router.get("/navigation-status")
def navigation_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return _navigation_status(db)


def _navigation_status(db: Session) -> dict:
    """
    Estado de la navegacion: internet, DHCP operativo, DNS resolviendo,
    listener activo, NAT, IPS y disco.
    El Panel lo muestra con un mensaje verde "Navegación OK".
    """

    from backend.monitoring.services.navigation_health_service import (
        NavigationHealthService,
    )

    report = NavigationHealthService().inspect(db)

    stats = _navigation_log_stats(db)

    return {
        "ok": report["ok"],
        "message": (
            "Navegación OK"
            if report["ok"] else "Navegación con problemas"
        ),
        "checks": report["checks"],
        "log_stats": stats,
    }


def _navigation_log_stats(db: Session) -> dict:

    from datetime import datetime, timedelta

    from sqlalchemy import func

    from backend.dns.logging.models.dns_query_log import DnsQueryLog

    from backend.dns.logging.models.sni_log import SniLog

    try:

        now = utcnow()

        since_24h = now - timedelta(hours=24)

        dns_total = db.query(func.count(DnsQueryLog.id)).scalar() or 0

        dns_24h = (
            db.query(func.count(DnsQueryLog.id))
            .filter(DnsQueryLog.queried_at >= since_24h)
            .scalar()
        ) or 0

        dns_devices_24h = (
            db.query(func.count(func.distinct(DnsQueryLog.device_id)))
            .filter(
                DnsQueryLog.queried_at >= since_24h,
                DnsQueryLog.device_id.isnot(None),
            )
            .scalar()
        ) or 0

        sni_total = db.query(func.count(SniLog.id)).scalar() or 0

        sni_24h = (
            db.query(func.count(SniLog.id))
            .filter(SniLog.created_at >= since_24h)
            .scalar()
        ) or 0

        latest_dns = (
            db.query(func.max(DnsQueryLog.queried_at))
            .scalar()
        )

        return {
            "dns_total": dns_total,
            "dns_last_24h": dns_24h,
            "dns_devices_last_24h": dns_devices_24h,
            "dns_latest_at": (
                latest_dns.isoformat() + "Z"
                if latest_dns else None
            ),
            "sni_total": sni_total,
            "sni_last_24h": sni_24h,
        }

    except Exception as error:

        logger.warning(
            "No se pudieron leer estadisticas de navegacion: %s",
            error,
        )

        return {}


@router.get("/capacity-history")
def capacity_history(
    hours: int = 6,
    limit: int = 120,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    from backend.monitoring.models.resource_sample import ResourceSample
    from backend.shared.utils.datetimes import to_iso_utc

    hours = max(1, min(168, int(hours)))
    limit = max(1, min(500, int(limit)))
    since = utcnow() - timedelta(hours=hours)

    rows = (
        db.query(ResourceSample)
        .filter(ResourceSample.created_at >= since)
        .order_by(ResourceSample.created_at.desc())
        .limit(limit)
        .all()
    )

    return {
        "hours": hours,
        "items": [
            {
                "created_at": to_iso_utc(row.created_at),
                "cpu_percent": row.cpu_percent,
                "ram_percent": row.ram_percent,
                "disk_percent": row.disk_percent,
                "load_1": row.load_1,
            }
            for row in reversed(rows)
        ],
    }


@router.get("/monitoring-settings")
def get_monitoring_settings(
    current_user: dict = Depends(get_current_user)
):

    from backend.shared.config.config_service import ConfigService

    return ConfigService().get().get("monitoring", {})


@router.put("/monitoring-settings")
def put_monitoring_settings(
    request: MonitoringSettingsRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.shared.config.config_service import ConfigService

    service = ConfigService()
    current = dict(service.get().get("monitoring", {}) or {})

    for key, value in (
        ("cpu_threshold", request.cpu_threshold),
        ("ram_threshold", request.ram_threshold),
        ("disk_threshold", request.disk_threshold),
    ):
        if value is not None:
            current[key] = max(50, min(100, int(value)))

    if request.window_minutes is not None:
        current["window_minutes"] = max(1, min(60, int(request.window_minutes)))

    if request.disk_free_min_gb is not None:
        current["disk_free_min_gb"] = max(1, min(1000, int(request.disk_free_min_gb)))

    if request.rogue_dhcp_scan_enabled is not None:
        current["rogue_dhcp_scan_enabled"] = bool(request.rogue_dhcp_scan_enabled)

    if request.rogue_dhcp_scan_minutes is not None:
        current["rogue_dhcp_scan_minutes"] = max(5, min(120, int(request.rogue_dhcp_scan_minutes)))

    if request.device_archive_days is not None:
        current["device_archive_days"] = max(1, min(365, int(request.device_archive_days)))

    service.update_section("monitoring", current)
    return current


@router.get("/version")
def version(
    current_user: dict = Depends(get_current_user)
):

    return {
        "version": installed_version(),
        "commit": git_commit()
    }


@router.get("/update-status")
def update_status_endpoint(
    current_user: dict = Depends(get_current_user)
):

    return update_status()


@router.post("/update")
def update(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return start_update()


@router.get("/remote-admin")
def get_remote_admin(
    current_user: dict = Depends(get_current_user)
):

    value = _read_env().get(REMOTE_ADMIN_KEY, "true")

    return {"enabled": value.lower() in ("1", "true", "yes")}


@router.post("/remote-admin")
def set_remote_admin(
    request: RemoteAdminRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    value = "true" if request.enabled else "false"

    _write_env_value(REMOTE_ADMIN_KEY, value)

    logger.info(
        f"Remote-admin policy set to {value}; restarting to apply."
    )

    _restart_in_background()

    return {
        "success": True,
        "enabled": request.enabled,
        "message": (
            "Política aplicada. El servicio se está reiniciando; "
            "la web vuelve en unos segundos."
        )
    }


@router.post("/restart")
def restart(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    _restart_in_background()

    return {
        "success": True,
        "message": "Reiniciando servicios... (la web vuelve en unos segundos)"
    }


def _power_in_background(action: str):

    def run():

        try:

            import time

            time.sleep(2)

            subprocess.run(
                ["systemctl", action],
                timeout=30
            )

        except Exception as error:
            logger.debug("system.run: %s", error)
    threading.Thread(
        target=run,
        daemon=True
    ).start()


@router.post("/reboot")
def reboot_machine(
    request: PowerRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    if not request.confirm:

        return {
            "success": False,
            "message": "Se requiere confirmación (confirm: true)"
        }

    _power_in_background("reboot")

    return {
        "success": True,
        "message": "Reiniciando el equipo... (vuelve en unos minutos)"
    }


@router.post("/shutdown")
def shutdown_machine(
    request: PowerRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    if not request.confirm:

        return {
            "success": False,
            "message": "Se requiere confirmación (confirm: true)"
        }

    _power_in_background("poweroff")

    return {
        "success": True,
        "message": "Apagando el equipo..."
    }


@router.get("/hardware")
def hardware(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.system.services.hardware_service import (
        HardwareService
    )

    from backend.system.services.module_service import ModuleService

    enabled_req = ModuleService().enabled_requirements(db)

    return HardwareService().get_hardware_info(
        enabled_requirements=enabled_req
    )


@router.get("/modules")
def get_modules(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.system.services.module_service import ModuleService

    return ModuleService().get_modules(db)


@router.put("/modules")
def set_modules(
    request: ModulesRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.system.services.module_service import ModuleService

    return ModuleService().set_modules(db, request.enabled_keys)