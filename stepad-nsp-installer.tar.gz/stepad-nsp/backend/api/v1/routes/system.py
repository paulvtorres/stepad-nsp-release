import re
import subprocess
import threading

from pathlib import Path

from fastapi import APIRouter, Depends

from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.core.lifecycle.services.system_status_service import SystemStatusService

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.shared.constants.app_version import APP_VERSION, git_commit, installed_version


class ModulesRequest(BaseModel):

    enabled_keys: list[str] = []


class PowerRequest(BaseModel):

    confirm: bool = False


from backend.system.services.update_service import (
    update_status,
    start_update
)

from backend.shared.logging.logger import logger


router = APIRouter(
    prefix="/system",
    tags=["System"]
)


service = SystemStatusService()

ENV_FILE = Path("/etc/stepad/stepad.env")

REMOTE_ADMIN_KEY = "STEPAD_VPN_REQUIRE_REMOTE_ADMIN"


def _read_env() -> dict:

    values = {}

    if ENV_FILE.exists():

        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():

            line = line.strip()

            if not line or "=" not in line or line.startswith("#"):

                continue

            key, value = line.split("=", 1)

            values[key.strip()] = value.strip().strip("\"'")

    return values


def _write_env_value(
    key: str,
    value: str
):

    values = _read_env()

    values[key] = value

    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)

    ENV_FILE.write_text(
        "\n".join(f"{k}={v}" for k, v in values.items()) + "\n",
        encoding="utf-8"
    )

    ENV_FILE.chmod(0o600)


def _restart_in_background():

    def run():

        subprocess.run(
            ["systemctl", "restart", "stepad-nsp"],
            timeout=60
        )

    thread = threading.Thread(target=run, daemon=True)

    thread.start()


class RemoteAdminRequest(BaseModel):

    enabled: bool


@router.get("/status")
def status(
    current_user: dict = Depends(get_current_user)
):

    return service.get_status()


@router.get("/version")
def version(
    current_user: dict = Depends(get_current_user)
):

    return {
        "version": installed_version(),
        "commit": git_commit()
    }


@router.get("/update-status")
def update_status_endpoint(
    current_user: dict = Depends(get_current_user)
):

    return update_status()


@router.post("/update")
def update(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return start_update()


@router.get("/remote-admin")
def get_remote_admin(
    current_user: dict = Depends(get_current_user)
):

    value = _read_env().get(REMOTE_ADMIN_KEY, "true")

    return {"enabled": value.lower() in ("1", "true", "yes")}


@router.post("/remote-admin")
def set_remote_admin(
    request: RemoteAdminRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    value = "true" if request.enabled else "false"

    _write_env_value(REMOTE_ADMIN_KEY, value)

    logger.info(
        f"Remote-admin policy set to {value}; restarting to apply."
    )

    _restart_in_background()

    return {
        "success": True,
        "enabled": request.enabled,
        "message": (
            "Política aplicada. El servicio se está reiniciando; "
            "la web vuelve en unos segundos."
        )
    }


@router.post("/restart")
def restart(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    _restart_in_background()

    return {
        "success": True,
        "message": "Reiniciando servicios... (la web vuelve en unos segundos)"
    }


def _power_in_background(action: str):

    def run():

        try:

            import time

            time.sleep(2)

            subprocess.run(
                ["systemctl", action],
                timeout=30
            )

        except Exception:

            pass

    threading.Thread(
        target=run,
        daemon=True
    ).start()


@router.post("/reboot")
def reboot_machine(
    request: PowerRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    if not request.confirm:

        return {
            "success": False,
            "message": "Se requiere confirmación (confirm: true)"
        }

    _power_in_background("reboot")

    return {
        "success": True,
        "message": "Reiniciando el equipo... (vuelve en unos minutos)"
    }


@router.post("/shutdown")
def shutdown_machine(
    request: PowerRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    if not request.confirm:

        return {
            "success": False,
            "message": "Se requiere confirmación (confirm: true)"
        }

    _power_in_background("poweroff")

    return {
        "success": True,
        "message": "Apagando el equipo..."
    }


@router.get("/hardware")
def hardware(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.system.services.hardware_service import (
        HardwareService
    )

    from backend.system.services.module_service import ModuleService

    enabled_req = ModuleService().enabled_requirements(db)

    return HardwareService().get_hardware_info(
        enabled_requirements=enabled_req
    )


@router.get("/modules")
def get_modules(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.system.services.module_service import ModuleService

    return ModuleService().get_modules(db)


@router.put("/modules")
def set_modules(
    request: ModulesRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.system.services.module_service import ModuleService

    return ModuleService().set_modules(db, request.enabled_keys)
