from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.auth.security.role_guard import require_role
from backend.users.models.user import UserRoles
from backend.core.database.dependency import get_db
from backend.network.services.load_balancing_service import load_balancing_service


router = APIRouter(
    prefix="/load-balancing",
    tags=["load-balancing"],
)


@router.get("/status")
def get_status(
    db: Session = Depends(get_db),
    user=Depends(require_role(UserRoles.ADMIN)),
):
    return load_balancing_service.get_status(db)


@router.get("/interfaces")
def get_interfaces(
    db: Session = Depends(get_db),
    user=Depends(require_role(UserRoles.ADMIN)),
):
    return {"interfaces": load_balancing_service.get_wan_interfaces(db)}


@router.post("/configure")
def configure(
    config: dict,
    db: Session = Depends(get_db),
    user=Depends(require_role(UserRoles.ADMIN)),
):
    return load_balancing_service.configure(db, config)
