from fastapi import APIRouter, Depends, Query

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.alerts.services.alert_service import AlertService


router = APIRouter(
    prefix="/alerts",
    tags=["Alerts"]
)

service = AlertService()


@router.get("/")
def list_alerts(
    limit: int = Query(50, ge=1, le=200),
    unread_only: bool = Query(False),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return {
        "alerts": service.list(db, limit=limit, unread_only=unread_only),
        "unread": service.unread_count(db)
    }


@router.get("/unread-count")
def unread_count(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return {"unread": service.unread_count(db)}


@router.post("/{alert_id}/read")
def mark_read(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.mark_read(db, alert_id)


@router.post("/read-all")
def mark_all_read(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.mark_all_read(db)
