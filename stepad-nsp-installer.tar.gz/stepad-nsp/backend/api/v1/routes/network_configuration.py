from fastapi import APIRouter, Depends

from pydantic import BaseModel

from backend.network.configuration.services.interface_configuration_service import InterfaceConfigurationService
from backend.network.configuration.services.network_topology_check_service import NetworkTopologyCheckService
from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

router = APIRouter(

    prefix="/network",

    tags=["Network Configuration"]

)


service = InterfaceConfigurationService()

topology_service = NetworkTopologyCheckService()


class LanSegmentRequest(BaseModel):

    gateway: str

    netmask: str


@router.get("/topology-check")
def topology_check(
    current_user: dict = Depends(get_current_user)
):

    return topology_service.check()


@router.post("/lan/set")
def set_lan(
    request: LanSegmentRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return topology_service.set_lan_segment(
        request.gateway,
        request.netmask
    )



@router.post("/lan/config-test")
async def configure_lan_test(

    current_user: dict = Depends(require_role(UserRoles.ADMIN))

):

    return service.configure_lan_default()