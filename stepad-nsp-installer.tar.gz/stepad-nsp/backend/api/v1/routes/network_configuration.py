from fastapi import APIRouter, Depends, HTTPException

from pydantic import BaseModel

from backend.network.configuration.services.interface_configuration_service import InterfaceConfigurationService
from backend.network.configuration.services.network_topology_check_service import NetworkTopologyCheckService
from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

router = APIRouter(

    prefix="/network",

    tags=["Network Configuration"]

)


service = InterfaceConfigurationService()

topology_service = NetworkTopologyCheckService()


class LanSegmentRequest(BaseModel):

    network: str

    pool_start: str | None = None

    pool_end: str | None = None

    excluded_ips: list[str] = []


@router.get("/topology-check")
def topology_check(
    current_user: dict = Depends(get_current_user)
):

    return topology_service.check()


@router.post("/lan/set")
def set_lan(
    request: LanSegmentRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    try:

        return topology_service.set_lan_segment(
            request.network,
            request.pool_start,
            request.pool_end,
            request.excluded_ips
        )

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))



@router.post("/lan/config-test")
async def configure_lan_test(

    current_user: dict = Depends(require_role(UserRoles.ADMIN))

):

    return service.configure_lan_default()