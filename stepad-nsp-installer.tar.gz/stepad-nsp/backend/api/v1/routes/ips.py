import subprocess

from pathlib import Path

from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.ips.services.suricata_alert_ingest import EVE_LOG


router = APIRouter(
    prefix="/ips",
    tags=["IPS"]
)


RULES_FILE = Path("/var/lib/suricata/rules/suricata.rules")


def _suricata_running():

    try:

        result = subprocess.run(
            ["pgrep", "-f", "suricata -D"],
            capture_output=True,
            text=True,
            timeout=5
        )

        return bool(result.stdout.strip())

    except Exception:

        return False


def _rules_count():

    try:

        if not RULES_FILE.exists():

            return 0

        count = 0

        for line in RULES_FILE.read_text(
            encoding="utf-8",
            errors="ignore"
        ).splitlines():

            stripped = line.strip()

            if not stripped or stripped.startswith("#"):

                continue

            count += 1

        return count

    except Exception:

        return 0


@router.get("/status")
def ips_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.alerts.models.alert import Alert

    from datetime import datetime, timedelta

    since = datetime.utcnow() - timedelta(hours=24)

    alerts_24h = (
        db.query(Alert)
        .filter(
            Alert.alert_type == "suricata",
            Alert.created_at >= since
        )
        .count()
    )

    return {
        "enabled": True,
        "suricata_running": _suricata_running(),
        "rules_loaded": _rules_count(),
        "alerts_last_24h": alerts_24h,
        "eve_log": str(EVE_LOG),
        "eve_log_size": EVE_LOG.stat().st_size if EVE_LOG.exists() else 0,
    }
