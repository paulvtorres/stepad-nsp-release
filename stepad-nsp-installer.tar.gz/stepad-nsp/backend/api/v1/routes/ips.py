import ipaddress
import subprocess

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException

from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.ips.services.suricata_alert_ingest import EVE_LOG

from backend.ips.services.threat_response_service import (
    threat_response_service
)

from backend.ips.services.attack_response_service import (
    attack_response_service
)

from backend.ips.services.geoip_service import geoip_service

from backend.shared.logging.logger import logger
from backend.shared.datetime_utils import utcnow


class ThreatResponseRequest(BaseModel):

    quarantine_enabled: bool | None = None

    c2_block_enabled: bool | None = None

    ips_fail_closed: bool | None = None

    auto_block_inbound: bool | None = None


class AttackSettingsRequest(BaseModel):

    auto_block_inbound: bool | None = None

    block_p2p: bool | None = None


class BlockIpRequest(BaseModel):

    reason: str | None = ""


router = APIRouter(
    prefix="/ips",
    tags=["IPS"]
)


RULES_FILE = Path("/var/lib/suricata/rules/suricata.rules")


def _suricata_running():

    try:

        result = subprocess.run(
            ["pgrep", "-f", "suricata -D"],
            capture_output=True,
            text=True,
            timeout=5
        )

        return bool(result.stdout.strip())

    except Exception as error:
        logger.debug("ips._suricata_running: %s", error)

        return False


def _rules_count():

    try:

        if not RULES_FILE.exists():

            return 0

        count = 0

        for line in RULES_FILE.read_text(
            encoding="utf-8",
            errors="ignore"
        ).splitlines():

            stripped = line.strip()

            if not stripped or stripped.startswith("#"):

                continue

            count += 1

        return count

    except Exception as error:
        logger.debug("ips._rules_count: %s", error)

        return 0


@router.get("/status")
def ips_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.alerts.models.alert import Alert

    from datetime import datetime, timedelta

    since = utcnow() - timedelta(hours=24)

    alerts_24h = (
        db.query(Alert)
        .filter(
            Alert.alert_type == "suricata",
            Alert.created_at >= since
        )
        .count()
    )

    return {
        "enabled": True,
        "suricata_running": _suricata_running(),
        "rules_loaded": _rules_count(),
        "alerts_last_24h": alerts_24h,
        "eve_log": str(EVE_LOG),
        "eve_log_size": EVE_LOG.stat().st_size if EVE_LOG.exists() else 0,
    }


@router.get("/threat-response")
def get_threat_response(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return threat_response_service.get_settings(db)


@router.put("/threat-response")
def update_threat_response(
    request: ThreatResponseRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return threat_response_service.update_settings(
        db,
        request.quarantine_enabled,
        request.c2_block_enabled,
        request.ips_fail_closed,
        auto_block_inbound=request.auto_block_inbound,
    )


@router.post("/threat-intel/refresh")
def refresh_threat_intel(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.ips.services.threat_intel_service import (
        threat_intel_service,
    )

    return threat_intel_service.sync()


@router.get("/malware-events")
def malware_events(
    limit: int = 10,
    device: str = "",
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    events = threat_response_service.list_malware_events(
        db,
        limit=max(1, min(limit, 50)),
        device=(device or "").strip() or None,
    )

    return {"events": events}


@router.get("/security-posture")
def security_posture(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.ips.services.security_posture_service import (
        security_posture_service,
    )

    return security_posture_service.get_posture(db)


class AuthorizedInboundRequest(BaseModel):

    ports: list[str] = []


@router.get("/authorized-inbound")
def get_authorized_inbound(
    current_user: dict = Depends(get_current_user)
):

    from backend.ips.services.security_posture_service import (
        security_posture_service,
    )

    return {"ports": security_posture_service.get_authorized_inbound()}


@router.put("/authorized-inbound")
def set_authorized_inbound(
    request: AuthorizedInboundRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.ips.services.security_posture_service import (
        security_posture_service,
    )

    return {
        "ports": security_posture_service.set_authorized_inbound(request.ports)
    }


@router.get("/quarantine")
def list_quarantine(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return threat_response_service.list_quarantined(db)


@router.get("/quarantine/count")
def quarantine_count(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    data = threat_response_service.list_quarantined(db)

    return {"count": data["count"]}


@router.post("/quarantine/{device_id}/release")
def release_quarantine(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return threat_response_service.release_quarantine(
        db,
        device_id,
        actor=current_user.get("username"),
    )


# ----------------------------------------------------------------------
# Ataques externos: ajustes, registro e investigacion
# ----------------------------------------------------------------------

def _attack_window_since(window: int):

    from datetime import datetime, timedelta

    hours = max(1, min(int(window), 720))

    return utcnow() - timedelta(hours=hours)


def _geo_for(ip: str):

    return geoip_service.enrich(ip)


def _classify(signature, category):
    from backend.ips.services.alert_classify import classify

    return classify(signature, category)


SERVICE_PORTS = {
    22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995,
    3389, 8080, 8443, 21115, 21116, 21117, 21118, 21119,
}


def _direction(source, dst_port):
    """Dirección real del flujo.

    'inbound'  = se inició desde Internet hacia nosotros (ataca un puerto
                 de servicio nuestro, NO efímero) -> ataque externo real.
    'outbound' = es la respuesta a una conexión SALIENTE nuestra (el destino
                 es un puerto efímero que eligió nuestro equipo) -> no es un
                 ataque entrante.
    """

    if source == "wan":
        return "inbound"

    try:
        port = int(dst_port)
    except (TypeError, ValueError):
        return "outbound"

    if port in SERVICE_PORTS or (0 < port < 1024):
        return "inbound"

    return "outbound"


@router.get("/attack/summary")
def attack_summary(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from datetime import datetime, timedelta

    from backend.ips.models.inbound_attack_event import InboundAttackEvent

    from backend.firewall.models.wan_probe_event import WanProbeEvent


    geoip_service.ensure_dataset()

    since24 = utcnow() - timedelta(hours=24)

    inbound_24h = (
        db.query(InboundAttackEvent)
        .filter(InboundAttackEvent.last_seen >= since24)
        .count()
    )

    wan_24h = (
        db.query(WanProbeEvent)
        .filter(WanProbeEvent.last_seen >= since24)
        .count()
    )

    from sqlalchemy import and_, func, or_

    wan_hits_24h = int(
        db.query(func.coalesce(func.sum(WanProbeEvent.hit_count), 0))
        .filter(WanProbeEvent.last_seen >= since24)
        .scalar()
        or 0
    )

    low_service = or_(
        InboundAttackEvent.dst_port.in_(SERVICE_PORTS),
        and_(
            InboundAttackEvent.dst_port.isnot(None),
            InboundAttackEvent.dst_port > 0,
            InboundAttackEvent.dst_port < 1024,
        ),
    )

    inbound_real_24h = (
        db.query(InboundAttackEvent)
        .filter(InboundAttackEvent.last_seen >= since24)
        .filter(low_service)
        .count()
    )

    real_inbound_24h = wan_24h + inbound_real_24h
    other_flows_24h = max(0, inbound_24h - inbound_real_24h)

    hardening = {"enabled": None, "applied": None}

    try:

        from backend.firewall.services.firewall_hardening_service import (
            FirewallHardeningService,
        )

        hardening_data = FirewallHardeningService().get_settings()

        hardening = {
            "enabled": hardening_data.get("hardening_enabled"),
            "applied": hardening_data.get("applied"),
        }

    except Exception as error:
        logger.debug("ips.attack_summary: %s", error)
    return {
        "auto_block_inbound": attack_response_service.get_auto_block(db),
        "block_p2p": attack_response_service.get_block_p2p(),
        "suricata_running": _suricata_running(),
        "rules_loaded": _rules_count(),
        "hardening": hardening,
        "geo": geoip_service.meta,
        "blocked": attack_response_service.list_blocked(db),
        "inbound_events_24h": inbound_24h,
        "wan_probes_24h": wan_24h,
        "wan_hits_24h": wan_hits_24h,
        "real_inbound_24h": real_inbound_24h,
        "other_flows_24h": other_flows_24h,
    }


@router.put("/attack/settings")
def update_attack_settings(
    request: AttackSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    result = {}

    if getattr(request, "auto_block_inbound", None) is not None:

        result.update(
            attack_response_service.set_auto_block(db, request.auto_block_inbound)
        )

    if getattr(request, "block_p2p", None) is not None:

        result.update(
            attack_response_service.set_block_p2p(request.block_p2p)
        )

    if not result:

        return {
            "auto_block_inbound": attack_response_service.get_auto_block(db),
            "block_p2p": attack_response_service.get_block_p2p(),
        }

    return result


@router.get("/attack/events")
def attack_events(
    window: int = 24,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.ips.models.inbound_attack_event import InboundAttackEvent

    from backend.firewall.models.wan_probe_event import WanProbeEvent

    from backend.ips.models.attack_blocked_ip import AttackBlockedIp

    from backend.shared.utils.datetimes import to_iso_utc

    since = _attack_window_since(window)

    cap = max(1, min(limit, 500))

    inbound = (
        db.query(InboundAttackEvent)
        .filter(InboundAttackEvent.last_seen >= since)
        .order_by(InboundAttackEvent.last_seen.desc())
        .limit(cap)
        .all()
    )

    probes = (
        db.query(WanProbeEvent)
        .filter(WanProbeEvent.last_seen >= since)
        .order_by(WanProbeEvent.last_seen.desc())
        .limit(cap)
        .all()
    )

    blocked_ips = {
        row.ip
        for row in db.query(AttackBlockedIp).all()
    }

    items = []

    for row in inbound:

        item = _geo_for(row.src_ip)

        kind, kind_label, sev = _classify(row.signature, row.category)

        items.append({
            "source": "ips",
            "src_ip": row.src_ip,
            **item,
            "src_port": row.src_port,
            "dst_port": row.dst_port,
            "protocol": row.protocol,
            "direction": _direction("ips", row.dst_port),
            "signature": row.signature,
            "category": row.category,
            "kind": kind,
            "kind_label": kind_label,
            "severity": sev,
            "severity_raw": row.severity,
            "hit_count": row.hit_count,
            "first_seen": to_iso_utc(row.first_seen),
            "last_seen": to_iso_utc(row.last_seen),
            "blocked": row.src_ip in blocked_ips,
        })

    for row in probes:

        item = _geo_for(row.src_ip)

        items.append({
            "source": "wan",
            "src_ip": row.src_ip,
            **item,
            "src_port": None,
            "dst_port": row.dst_port,
            "protocol": row.protocol,
            "direction": "inbound",
            "signature": None,
            "category": None,
            "severity": "warning",
            "hit_count": row.hit_count,
            "first_seen": to_iso_utc(row.first_seen),
            "last_seen": to_iso_utc(row.last_seen),
            "blocked": row.src_ip in blocked_ips,
        })

    items.sort(key=lambda item: item["last_seen"], reverse=True)

    return {
        "window_hours": int(window),
        "count": len(items),
        "items": items[:cap],
    }


@router.get("/attack/ip/{target_ip}")
def attack_ip_detail(
    target_ip: str,
    window: int = 168,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.ips.models.inbound_attack_event import InboundAttackEvent

    from backend.firewall.models.wan_probe_event import WanProbeEvent

    from backend.shared.utils.datetimes import to_iso_utc

    try:

        ipaddress.ip_address(target_ip)

    except ValueError:

        raise HTTPException(
            status_code=400,
            detail="IP invalida",
        )

    since = _attack_window_since(window)

    inbound = (
        db.query(InboundAttackEvent)
        .filter(
            InboundAttackEvent.src_ip == target_ip,
            InboundAttackEvent.last_seen >= since,
        )
        .order_by(InboundAttackEvent.last_seen.desc())
        .limit(100)
        .all()
    )

    probes = (
        db.query(WanProbeEvent)
        .filter(
            WanProbeEvent.src_ip == target_ip,
            WanProbeEvent.last_seen >= since,
        )
        .order_by(WanProbeEvent.last_seen.desc())
        .limit(100)
        .all()
    )

    blocked = attack_response_service.is_blocked(db, target_ip)

    return {
        "ip": target_ip,
        "geo": _geo_for(target_ip),
        "blocked": {
            "blocked": blocked is not None,
            "rule_source": blocked.rule_source if blocked else None,
            "reason": blocked.reason if blocked else None,
            "created_by": blocked.created_by if blocked else None,
            "created_at": (
                to_iso_utc(blocked.created_at)
                if blocked
                else None
            ),
        },
        "inbound_events": [
            {
                "id": row.id,
                "src_port": row.src_port,
                "dst_port": row.dst_port,
                "protocol": row.protocol,
                "signature": row.signature,
                "category": row.category,
                "severity": row.severity,
                "hit_count": row.hit_count,
                "last_seen": to_iso_utc(row.last_seen),
            }
            for row in inbound
        ],
        "wan_probes": [
            {
                "id": row.id,
                "dst_port": row.dst_port,
                "protocol": row.protocol,
                "chain": row.chain,
                "hit_count": row.hit_count,
                "last_seen": to_iso_utc(row.last_seen),
            }
            for row in probes
        ],
        "totals": {
            "inbound": len(inbound),
            "wan_probes": len(probes),
        },
    }


@router.post("/attack/ip/{target_ip}/block")
def block_attack_ip(
    target_ip: str,
    request: BlockIpRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    result = attack_response_service.block(
        db,
        target_ip,
        source="manual",
        reason=(request.reason or "")[:200],
        actor=current_user.get("username"),
    )

    if not result["success"]:

        raise HTTPException(
            status_code=400,
            detail=result["message"],
        )

    return result


@router.post("/attack/ip/{target_ip}/unblock")
def unblock_attack_ip(
    target_ip: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return attack_response_service.unblock(
        db,
        target_ip,
        actor=current_user.get("username"),
    )

# ---------------------------------------------------------------------------
# Egreso / Exfiltracion  (panel de salidas a Internet)
# ---------------------------------------------------------------------------


def _egress_since(hours: int):
    from datetime import datetime, timedelta

    hours = max(1, min(int(hours), 720))

    return utcnow() - timedelta(hours=hours), hours


@router.get("/egress/summary")
def egress_summary(
    hours: int = 24,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from sqlalchemy import distinct, func

    from backend.ips.models.egress_flow_stat import EgressFlowStat

    since, hours = _egress_since(hours)

    row = (
        db.query(
            func.coalesce(func.sum(EgressFlowStat.bytes_out), 0),
            func.coalesce(func.sum(EgressFlowStat.bytes_in), 0),
            func.coalesce(func.sum(EgressFlowStat.connections), 0),
            func.count(distinct(EgressFlowStat.dest_ip)),
            func.count(distinct(EgressFlowStat.src_ip)),
        )
        .filter(EgressFlowStat.last_seen >= since)
        .one()
    )

    return {
        "window_hours": hours,
        "bytes_out": int(row[0] or 0),
        "bytes_in": int(row[1] or 0),
        "connections": int(row[2] or 0),
        "destinations": int(row[3] or 0),
        "devices": int(row[4] or 0),
    }


@router.get("/egress/destinations")
def egress_destinations(
    hours: int = 24,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from sqlalchemy import distinct, func

    from backend.ips.models.egress_flow_stat import EgressFlowStat

    from backend.shared.utils.datetimes import to_iso_utc

    since, hours = _egress_since(hours)

    cap = max(1, min(int(limit), 500))

    sum_out = func.coalesce(func.sum(EgressFlowStat.bytes_out), 0)
    sum_in = func.coalesce(func.sum(EgressFlowStat.bytes_in), 0)
    sum_conn = func.coalesce(func.sum(EgressFlowStat.connections), 0)

    rows = (
        db.query(
            EgressFlowStat.dest_ip,
            func.max(EgressFlowStat.country),
            func.max(EgressFlowStat.asn),
            func.max(EgressFlowStat.as_org),
            sum_out,
            sum_in,
            sum_conn,
            func.count(distinct(EgressFlowStat.src_ip)),
            func.max(EgressFlowStat.last_seen),
            func.string_agg(
                distinct(EgressFlowStat.app_proto), ", "
            ),
        )
        .filter(EgressFlowStat.last_seen >= since)
        .group_by(EgressFlowStat.dest_ip)
        .order_by(sum_out.desc())
        .limit(cap)
        .all()
    )

    items = []

    for row in rows:
        items.append({
            "dest_ip": row[0],
            "country": row[1],
            "asn": row[2],
            "as_org": row[3],
            "bytes_out": int(row[4] or 0),
            "bytes_in": int(row[5] or 0),
            "connections": int(row[6] or 0),
            "devices": int(row[7] or 0),
            "last_seen": to_iso_utc(row[8]),
            "app_proto": row[9],
        })

    return {
        "window_hours": hours,
        "count": len(items),
        "items": items,
    }


@router.get("/egress/devices")
def egress_devices(
    hours: int = 24,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from sqlalchemy import distinct, func

    from backend.ips.models.egress_flow_stat import EgressFlowStat

    from backend.shared.utils.datetimes import to_iso_utc

    since, hours = _egress_since(hours)

    cap = max(1, min(int(limit), 500))

    sum_out = func.coalesce(func.sum(EgressFlowStat.bytes_out), 0)
    sum_in = func.coalesce(func.sum(EgressFlowStat.bytes_in), 0)
    sum_conn = func.coalesce(func.sum(EgressFlowStat.connections), 0)

    rows = (
        db.query(
            EgressFlowStat.src_ip,
            func.max(EgressFlowStat.device_name),
            sum_out,
            sum_in,
            sum_conn,
            func.count(distinct(EgressFlowStat.dest_ip)),
            func.max(EgressFlowStat.last_seen),
        )
        .filter(EgressFlowStat.last_seen >= since)
        .group_by(EgressFlowStat.src_ip)
        .order_by(sum_out.desc())
        .limit(cap)
        .all()
    )

    items = []

    for row in rows:
        items.append({
            "src_ip": row[0],
            "device_name": row[1],
            "bytes_out": int(row[2] or 0),
            "bytes_in": int(row[3] or 0),
            "connections": int(row[4] or 0),
            "destinations": int(row[5] or 0),
            "last_seen": to_iso_utc(row[6]),
        })

    return {
        "window_hours": hours,
        "count": len(items),
        "items": items,
    }


@router.get("/egress/new-destinations")
def egress_new_destinations(
    hours: int = 24,
    baseline_days: int = 30,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from datetime import timedelta

    from sqlalchemy import distinct, func

    from backend.ips.models.egress_flow_stat import EgressFlowStat

    from backend.shared.utils.datetimes import to_iso_utc

    since, hours = _egress_since(hours)

    baseline_days = max(1, min(int(baseline_days), 365))

    baseline = since - timedelta(days=baseline_days)

    in_window = {
        row[0]
        for row in db.query(distinct(EgressFlowStat.dest_ip))
        .filter(EgressFlowStat.last_seen >= since)
        .all()
    }

    prior = {
        row[0]
        for row in db.query(distinct(EgressFlowStat.dest_ip))
        .filter(EgressFlowStat.last_seen < since)
        .filter(EgressFlowStat.last_seen >= baseline)
        .all()
    }

    new_hosts = in_window - prior

    if not new_hosts:
        return {
            "window_hours": hours,
            "baseline_days": baseline_days,
            "count": 0,
            "items": [],
        }

    cap = max(1, min(int(limit), 500))

    sum_out = func.coalesce(func.sum(EgressFlowStat.bytes_out), 0)
    sum_in = func.coalesce(func.sum(EgressFlowStat.bytes_in), 0)
    sum_conn = func.coalesce(func.sum(EgressFlowStat.connections), 0)

    rows = (
        db.query(
            EgressFlowStat.dest_ip,
            func.max(EgressFlowStat.country),
            func.max(EgressFlowStat.asn),
            func.max(EgressFlowStat.as_org),
            sum_out,
            sum_in,
            sum_conn,
            func.count(distinct(EgressFlowStat.src_ip)),
            func.min(EgressFlowStat.first_seen),
            func.max(EgressFlowStat.last_seen),
        )
        .filter(EgressFlowStat.last_seen >= since)
        .filter(EgressFlowStat.dest_ip.in_(new_hosts))
        .group_by(EgressFlowStat.dest_ip)
        .order_by(sum_out.desc())
        .limit(cap)
        .all()
    )

    items = []

    for row in rows:
        items.append({
            "dest_ip": row[0],
            "country": row[1],
            "asn": row[2],
            "as_org": row[3],
            "bytes_out": int(row[4] or 0),
            "bytes_in": int(row[5] or 0),
            "connections": int(row[6] or 0),
            "devices": int(row[7] or 0),
            "first_seen": to_iso_utc(row[8]),
            "last_seen": to_iso_utc(row[9]),
        })

    return {
        "window_hours": hours,
        "baseline_days": baseline_days,
        "count": len(items),
        "items": items,
    }


@router.get("/egress/recent")
def egress_recent(
    hours: int = 24,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.ips.models.egress_flow_stat import EgressFlowStat

    from backend.shared.utils.datetimes import to_iso_utc

    since, hours = _egress_since(hours)

    cap = max(1, min(int(limit), 500))

    rows = (
        db.query(EgressFlowStat)
        .filter(EgressFlowStat.last_seen >= since)
        .order_by(EgressFlowStat.last_seen.desc())
        .limit(cap)
        .all()
    )

    items = []

    for row in rows:
        items.append({
            "src_ip": row.src_ip,
            "device_name": row.device_name,
            "dest_ip": row.dest_ip,
            "dest_port": row.dest_port,
            "app_proto": row.app_proto,
            "country": row.country,
            "asn": row.asn,
            "as_org": row.as_org,
            "bytes_out": int(row.bytes_out or 0),
            "bytes_in": int(row.bytes_in or 0),
            "connections": int(row.connections or 0),
            "first_seen": to_iso_utc(row.first_seen),
            "last_seen": to_iso_utc(row.last_seen),
        })

    return {
        "window_hours": hours,
        "count": len(items),
        "items": items,
    }