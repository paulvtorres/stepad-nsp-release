from datetime import datetime

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.siem.services.compliance_service import ComplianceService
from backend.siem.routes.schemas import ComplianceSettingsRequest
from backend.siem.routes.schemas import LogsReviewRequest


router = APIRouter(
    prefix="/reports",
    tags=["Reports"]
)

service = ComplianceService()


@router.get("/compliance")
def compliance_report(
    start: datetime | None = Query(None),
    end: datetime | None = Query(None),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    buffer = service.build_excel(db, start=start, end=end)

    return Response(
        content=buffer.getvalue(),
        media_type=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                "attachment; "
                "filename=reporte-cumplimiento.xlsx"
            )
        }
    )


@router.get("/compliance/retention")
def get_retention(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_retention(db)


@router.put("/compliance/retention")
def save_retention(
    request: ComplianceSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_retention(db, request)


@router.get("/compliance/logs-review")
def get_logs_review(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_logs_review(db)


@router.put("/compliance/logs-review")
def save_logs_review(
    request: LogsReviewRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_logs_review(
        db,
        email=request.reviewer_email,
        frequency_days=request.frequency_days
    )


@router.post("/compliance/logs-review/mark")
def mark_logs_review(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.mark_logs_review(db)
