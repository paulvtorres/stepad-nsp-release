from fastapi import APIRouter, Depends, HTTPException

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.network.zones.models.schedule import Schedule
from backend.network.zones.repositories.schedule_repository import (
    ScheduleRepository
)
from backend.network.zones.schemas.create_schedule_request import (
    CreateScheduleRequest
)


router = APIRouter(
    prefix="/schedules",
    tags=["Schedules"]
)


repository = ScheduleRepository()



@router.get("/")
def get_schedules(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return repository.find_all(db)



@router.post("/")
def create_schedule(
    request: CreateScheduleRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    schedule = Schedule(
        name=request.name,
        days_of_week=request.days_of_week,
        start_time=request.start_time,
        end_time=request.end_time,
        start_date=request.start_date,
        end_date=request.end_date
    )

    return repository.save(db, schedule)



@router.delete("/{schedule_id}")
def delete_schedule(
    schedule_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    schedule = repository.find_by_id(db, schedule_id)

    if not schedule:

        raise HTTPException(status_code=404, detail="Schedule not found")

    repository.delete(db, schedule)

    return {"success": True}
