from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.siem.services.syslog_service import SyslogService
from backend.siem.routes.schemas import SyslogSettingsRequest


router = APIRouter(
    prefix="/integration",
    tags=["Integration"]
)

service = SyslogService()


@router.get("/syslog")
def get_syslog(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_settings(db)


@router.put("/syslog")
def save_syslog(
    request: SyslogSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_settings(db, request)


@router.post("/syslog/test")
def test_syslog(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.test(db)
