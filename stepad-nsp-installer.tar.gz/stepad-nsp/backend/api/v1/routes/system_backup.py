"""Endpoints de system backup para la API."""

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

from backend.auth.security.role_guard import require_role
from backend.users.models.user import UserRoles
from backend.backups.services.system_backup_service import system_backup_service
from backend.backups.services.replacement_service import ReplacementService


router = APIRouter(
    prefix="/system-backup",
    tags=["system-backup"],
)


@router.get("/status")
def get_status(user=Depends(require_role(UserRoles.ADMIN))):
    return system_backup_service.get_status()


@router.get("/config")
def get_config(user=Depends(require_role(UserRoles.ADMIN))):
    return system_backup_service.get_config()


@router.put("/config")
def update_config(config: dict, user=Depends(require_role(UserRoles.ADMIN))):
    system_backup_service.save_config(config)
    return {"success": True}


@router.post("/create")
def create_backup(reason: str = "manual", user=Depends(require_role(UserRoles.ADMIN))):
    return system_backup_service.create_backup(reason=reason)


@router.get("/snapshots")
def list_snapshots(user=Depends(require_role(UserRoles.ADMIN))):
    return {"snapshots": system_backup_service.list_snapshots()}


@router.post("/restore")
def restore(snapshot_id: str = "latest", user=Depends(require_role(UserRoles.ADMIN))):
    return system_backup_service.restore(snapshot_id=snapshot_id)


@router.get("/usb")
def detect_usb(user=Depends(require_role(UserRoles.ADMIN))):
    usb = system_backup_service.detect_usb()
    return {"usb_path": usb, "available": usb is not None}


@router.post("/replacement/export")
def export_replacement(
    payload: dict,
    user=Depends(require_role(UserRoles.ADMIN)),
):
    """Guided machine replacement: encrypted bundle (DB + secrets + config)."""
    passphrase = (payload or {}).get("passphrase") or ""
    path, name = ReplacementService().create_bundle(passphrase)
    return FileResponse(
        path,
        filename=name,
        media_type="application/octet-stream",
        background=BackgroundTask(path.unlink, missing_ok=True),
    )


@router.post("/verify-restore")
def verify_system_restore(
    user=Depends(require_role(UserRoles.ADMIN)),
):
    """Restore the latest system backup into a temp DB (sanity check)."""
    from backend.backups.services.system_restore_verification_service import (
        SystemRestoreVerificationService,
    )

    return SystemRestoreVerificationService().run()


@router.get("/rollback-points")
def rollback_points(user=Depends(require_role(UserRoles.ADMIN))):
    from backend.backups.services.rollback_integrity_service import (
        RollbackIntegrityService,
    )

    return RollbackIntegrityService().status()


@router.post("/rollback-points/verify")
def verify_rollback_points(user=Depends(require_role(UserRoles.ADMIN))):
    from backend.backups.services.rollback_integrity_service import (
        RollbackIntegrityService,
    )

    return RollbackIntegrityService().run()
