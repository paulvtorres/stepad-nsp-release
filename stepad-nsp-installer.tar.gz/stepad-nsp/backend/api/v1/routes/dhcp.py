from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from backend.dhcp.services.dhcp_service import DhcpService
from backend.dhcp.services.dhcp_lease_service import DhcpLeaseService
from backend.dhcp.services.dhcp_log_service import DhcpLogService
from backend.dhcp.services.dhcp_reservation_cleanup_service import (
    DhcpReservationCleanupService,
    MAX_CLEANUP_DAYS,
    MIN_CLEANUP_DAYS,
)
from backend.dhcp.services.dhcp_pool_stats_service import DhcpPoolStatsService
from backend.dhcp.services.dhcp_alert_service import DhcpAlertService
from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles

from backend.shared.logging.logger import logger


router = APIRouter(
    prefix="/dhcp",
    tags=["DHCP"]
)


service = DhcpService()

lease_service = DhcpLeaseService()

log_service = DhcpLogService()

cleanup_service = DhcpReservationCleanupService()

pool_stats_service = DhcpPoolStatsService()

alert_service = DhcpAlertService()


class ExclusionsRequest(BaseModel):

    ips: list[str] = []
    pool_start: str | None = None
    pool_end: str | None = None


class CleanupSettingsRequest(BaseModel):

    enabled: bool | None = None

    days: int | None = Field(
        default=None,
        ge=MIN_CLEANUP_DAYS,
        le=MAX_CLEANUP_DAYS,
    )

    run_time: str | None = Field(
        default=None,
        description="Hora diaria local HH:MM (ej. 03:00)",
        max_length=5,
    )

    run_hour: int | None = Field(default=None, ge=0, le=23)

    run_minute: int | None = Field(default=None, ge=0, le=59)

    protect_infrastructure: bool | None = None


class CleanupRunRequest(BaseModel):

    dry_run: bool = False

    days: int | None = Field(
        default=None,
        ge=MIN_CLEANUP_DAYS,
        le=MAX_CLEANUP_DAYS,
    )

    protect_infrastructure: bool | None = None


class AlertSettingsRequest(BaseModel):

    service_alert_enabled: bool | None = None

    scheduled_check_enabled: bool | None = None

    run_time: str | None = Field(default=None, max_length=5)

    run_hour: int | None = Field(default=None, ge=0, le=23)

    run_minute: int | None = Field(default=None, ge=0, le=59)

    pool_low_alert_enabled: bool | None = None

    pool_low_threshold: int | None = Field(default=None, ge=1, le=500)

    # Destinatarios PROPIOS de este aviso (independiente de Alertas).
    pool_low_alert_emails: str | None = Field(default=None, max_length=2000)

    # Liberar IPs sin uso cuando el pool cruza el umbral.
    pool_reclaim_enabled: bool | None = None

    pool_reclaim_days: int | None = Field(default=None, ge=1, le=365)

    pool_auto_expand_enabled: bool | None = None

    pool_auto_expand_max: str | None = Field(default=None, max_length=45)

    pool_auto_expand_step: int | None = Field(default=None, ge=1, le=254)


class AlertRunRequest(BaseModel):

    force_email: bool = False


@router.get("/config")
async def config(
    current_user: dict = Depends(get_current_user)
):

    return service.get_default_config()



@router.get("/exclusions")
async def exclusions(
    current_user: dict = Depends(get_current_user)
):

    return service.get_exclusions()



@router.post("/exclusions")
async def set_exclusions(
    request: ExclusionsRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    try:

        return service.set_exclusions(request.ips, pool_start=request.pool_start, pool_end=request.pool_end)

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))



@router.get("/leases")
async def leases(
    current_user: dict = Depends(get_current_user)
):

    return lease_service.list_leases()



@router.get("/diagnosis")
async def diagnosis(
    current_user: dict = Depends(get_current_user)
):

    return service.diagnose()



@router.get("/status")
async def status(
    current_user: dict = Depends(get_current_user)
):

    result = service.get_status()

    try:

        from backend.dhcp.reconciler import get_dhcp_reconciler

        result["reconcile"] = get_dhcp_reconciler().status()

    except Exception as error:
        logger.debug("dhcp.status: %s", error)

        pass

    return result



@router.get("/health")
async def health(
    current_user: dict = Depends(get_current_user)
):
    from backend.dhcp.services.dhcp_health_service import DhcpHealthService
    hs = DhcpHealthService()
    return hs.inspect()


@router.post("/restart")
async def restart_dhcp(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    """
    Reinicia solo el proceso dnsmasq (DHCP/DNS local), sin tocar
    otros servicios del NSP.
    """

    result = service.reload()

    if result.get("success") is False:

        raise HTTPException(
            status_code=500,
            detail=result.get("message") or "No se pudo reiniciar DHCP.",
        )

    return {
        "success": True,
        "message": "DHCP reiniciado.",
        "service": result,
    }



@router.post("/apply")
async def apply_dhcp(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    """
    Reescribe reservas + config DHCP y reinicia dnsmasq.
    """

    result = service.apply_config()

    if not result.get("success"):

        raise HTTPException(
            status_code=500,
            detail=result.get("message") or "No se pudo reaplicar DHCP.",
        )

    return {
        "success": True,
        "message": "DHCP reaplicado (reservas y configuración).",
        **result,
    }



@router.get("/logs")
async def dhcp_logs(
    lines: int = Query(200, ge=1, le=1000),
    search: str | None = Query(None, max_length=120),
    current_user: dict = Depends(get_current_user)
):

    return log_service.tail(lines=lines, search=search)



@router.get("/cleanup")
async def get_cleanup_settings(
    current_user: dict = Depends(get_current_user)
):

    settings = cleanup_service.get_settings()
    candidates = cleanup_service.list_candidates()

    return {
        **settings,
        "pending_count": len(candidates),
        "pending": candidates[:50],
    }



@router.put("/cleanup")
async def put_cleanup_settings(
    request: CleanupSettingsRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    try:

        settings = cleanup_service.update_settings(
            enabled=request.enabled,
            days=request.days,
            run_time=request.run_time,
            run_hour=request.run_hour,
            run_minute=request.run_minute,
            protect_infrastructure=request.protect_infrastructure,
        )

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))

    candidates = cleanup_service.list_candidates()

    return {
        **settings,
        "pending_count": len(candidates),
        "pending": candidates[:50],
        "message": "Programación de limpieza guardada.",
    }



@router.post("/cleanup/run")
async def run_cleanup(
    request: CleanupRunRequest | None = None,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    body = request or CleanupRunRequest()

    try:

        return cleanup_service.run_cleanup(
            dry_run=body.dry_run,
            days=body.days,
            protect_infrastructure=body.protect_infrastructure,
            user_id=current_user.get("user_id"),
        )

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))




@router.post("/cleanup/clean-all")
async def clean_all_offline(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    return cleanup_service.run_clean_all_offline()


@router.post("/sync-ips")
async def sync_ips_with_leases(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    """Sincroniza las IPs de la base con ARP y los leases DHCP.

    Delega en el servicio: una sola implementacion (antes esta ruta tenia
    su propia copia que BORRABA la IP de los equipos apagados y dejaba el
    reporte en blanco).
    """

    from backend.dhcp.services.dhcp_service import DhcpService

    return DhcpService().sync_device_ips()


@router.get("/connected-ips")
async def connected_ips(
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):

    return service.connected_ips()


@router.get("/pool-stats")
async def pool_stats(
    current_user: dict = Depends(get_current_user)
):

    return pool_stats_service.get_stats()



@router.get("/alerts")
async def get_alert_settings(
    current_user: dict = Depends(get_current_user)
):

    settings = alert_service.get_settings()
    problems = alert_service.collect_problems()

    return {
        **settings,
        "healthy": len(problems) == 0,
        "problems": problems,
        "problem_count": len(problems),
    }



@router.put("/alerts")
async def put_alert_settings(
    request: AlertSettingsRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    try:

        settings = alert_service.update_settings(
            service_alert_enabled=request.service_alert_enabled,
            scheduled_check_enabled=request.scheduled_check_enabled,
            run_time=request.run_time,
            run_hour=request.run_hour,
            run_minute=request.run_minute,
            pool_low_alert_enabled=request.pool_low_alert_enabled,
            pool_low_threshold=request.pool_low_threshold,
            pool_low_alert_emails=request.pool_low_alert_emails,
            pool_reclaim_enabled=request.pool_reclaim_enabled,
            pool_reclaim_days=request.pool_reclaim_days,
            pool_auto_expand_enabled=request.pool_auto_expand_enabled,
            pool_auto_expand_max=request.pool_auto_expand_max,
            pool_auto_expand_step=request.pool_auto_expand_step,
        )

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))

    problems = alert_service.collect_problems()

    return {
        **settings,
        "healthy": len(problems) == 0,
        "problems": problems,
        "problem_count": len(problems),
        "message": "Programación de alertas DHCP guardada.",
    }



@router.post("/alerts/check")
async def run_alert_check(
    request: AlertRunRequest | None = None,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    body = request or AlertRunRequest()

    return alert_service.run_check(
        send_email=True,
        force_email=body.force_email,
    )