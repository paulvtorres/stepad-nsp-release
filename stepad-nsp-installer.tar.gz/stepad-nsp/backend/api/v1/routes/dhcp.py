from fastapi import APIRouter, Depends

from backend.dhcp.services.dhcp_service import DhcpService
from backend.dhcp.services.dhcp_lease_service import DhcpLeaseService
from backend.auth.security.jwt_auth import get_current_user


router = APIRouter(
    prefix="/dhcp",
    tags=["DHCP"]
)


service = DhcpService()

lease_service = DhcpLeaseService()


@router.get("/config")
async def config(
    current_user: dict = Depends(get_current_user)
):

    return service.get_default_config()



@router.get("/leases")
async def leases(
    current_user: dict = Depends(get_current_user)
):

    return lease_service.list_leases()



@router.get("/diagnosis")
async def diagnosis(
    current_user: dict = Depends(get_current_user)
):

    return service.diagnose()



@router.get("/status")
async def status(
    current_user: dict = Depends(get_current_user)
):

    return service.get_status()