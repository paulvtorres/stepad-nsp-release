from fastapi import APIRouter, Depends

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.dns.services.domain_service import (
    DomainService
)


router = APIRouter(
    prefix="/dns",
    tags=["DNS"]
)


service = DomainService()


@router.post("/restart")
def restart_dns(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.restart()


@router.get("/diagnosis")
async def diagnosis(
    current_user: dict = Depends(get_current_user)
):

    return service.diagnose()