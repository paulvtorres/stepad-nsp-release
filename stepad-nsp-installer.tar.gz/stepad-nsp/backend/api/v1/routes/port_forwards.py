from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.nat.services.port_forward_service import PortForwardService
from backend.api.schemas.port_forward_request import PortForwardRequest


router = APIRouter(
    prefix="/port-forwards",
    tags=["Port Forwards"]
)

service = PortForwardService()


@router.get("/")
def list_port_forwards(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list_forwards(db)


@router.post("/")
def create_port_forward(
    request: PortForwardRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.create(db, request)


@router.patch("/{forward_id}")
def update_port_forward(
    forward_id: int,
    request: PortForwardRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.update(db, forward_id, request)


@router.delete("/{forward_id}")
def delete_port_forward(
    forward_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete(db, forward_id)
