from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import (
    get_current_user
)

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.rules.services.global_rule_service import (
    GlobalRuleService
)

from backend.rules.schemas.create_global_rule_request import (
    CreateGlobalRuleRequest
)


router = APIRouter(
    prefix="/security/rules",
    tags=["Security Rules"]
)


service = GlobalRuleService()



@router.get("/")
def get_rules(
    db:Session = Depends(get_db),
    current_user:dict = Depends(get_current_user)
):

    return service.get_domain_rules(
        db
    )



@router.post("/")
def create_rule(
    request:CreateGlobalRuleRequest,
    db:Session = Depends(get_db),
    current_user:dict = Depends(require_role(UserRoles.ADMIN))
):

    from fastapi import HTTPException

    try:

        return service.create_rule(
            request,
            db
        )

    except ValueError as error:

        raise HTTPException(
            status_code=400,
            detail=str(error)
        )



@router.delete("/{rule_id}")
def delete_rule(
    rule_id:int,
    db:Session = Depends(get_db),
    current_user:dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete_rule(
        rule_id,
        db
    )