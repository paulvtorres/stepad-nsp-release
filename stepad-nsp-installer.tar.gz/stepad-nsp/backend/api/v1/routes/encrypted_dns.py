from fastapi import APIRouter, Depends
from pydantic import BaseModel

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.firewall.dns_security.services.encrypted_dns_service import (
    EncryptedDnsService
)


router = APIRouter(
    prefix="/firewall/encrypted-dns",
    tags=["Encrypted DNS"],
)


service = EncryptedDnsService()


class BlockEnableRequest(BaseModel):

    # True = "siempre activo tras reinicio" (se re-aplica en boot).
    persist: bool = False


@router.get("/status")
async def get_status(current_user: dict = Depends(get_current_user)):

    return service.get_status()



@router.post("/enable")
async def enable(
    request: BlockEnableRequest = BlockEnableRequest(),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.enable(persist=request.persist)



@router.post("/disable")
async def disable(current_user: dict = Depends(require_role(UserRoles.ADMIN))):

    return service.disable()


@router.post("/service-block/enable")
async def enable_service_block(
    request: BlockEnableRequest = BlockEnableRequest(),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.enable_service_block(persist=request.persist)


@router.post("/service-block/disable")
async def disable_service_block(current_user: dict = Depends(require_role(UserRoles.ADMIN))):

    return service.disable_service_block()



@router.post("/refresh-blocklist")
async def refresh_blocklist(current_user: dict = Depends(require_role(UserRoles.ADMIN))):

    return service.refresh_blocklist()
