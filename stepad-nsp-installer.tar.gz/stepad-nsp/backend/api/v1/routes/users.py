from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.users.services.user_service import UserService

from backend.api.schemas.user import UserResponse

from backend.api.schemas.create_user import CreateUserRequest

from backend.api.schemas.update_user_role import (
    UpdateUserRoleRequest
)

from backend.api.schemas.update_user_status import (
    UpdateUserStatusRequest
)

router = APIRouter(
    prefix="/users",
    tags=["Users"]
)

service = UserService()


@router.get(
    "/",
    response_model=list[UserResponse]
)
def get_users(
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.get_users(db)

@router.post(
    "/",
    response_model=UserResponse
)
def create_user(
    request: CreateUserRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.create_user(
        db=db,

        username=request.username,

        password=request.password,

        role=request.role,

        created_by=current_user["user_id"]
    )

@router.put(
    "/{user_id}/role",
    response_model=UserResponse
)
def change_role(
    user_id: int,
    request: UpdateUserRoleRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.change_role(
        db=db,
        user_id=user_id,
        role=request.role,
        changed_by=current_user["user_id"]
    )

@router.put(
    "/{user_id}/status",
    response_model=UserResponse
)
def change_status(
    user_id: int,
    request: UpdateUserStatusRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(
        require_role(UserRoles.ADMIN)
    )
):

    return service.change_status(
        db=db,
        user_id=user_id,
        enabled=request.enabled,
        changed_by=current_user["user_id"]
    )