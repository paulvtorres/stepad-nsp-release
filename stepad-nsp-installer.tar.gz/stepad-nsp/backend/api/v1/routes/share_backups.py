from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse

from sqlalchemy.orm import Session

from backend.api.schemas.shares_request import (
    CreateBackupJobRequest,
    UpdateBackupJobRequest,
)
from backend.core.database.dependency import get_db
from backend.auth.security.jwt_auth import get_download_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles
from backend.shares.services.share_backup_service import get_share_backup_service

from backend.shared.logging.logger import logger
from backend.shared.datetime_utils import utcnow


router = APIRouter(
    prefix="/shares/backups",
    tags=["Network Disk Backups"],
)

service = get_share_backup_service()


def _get_job(job_id: int):
    job = service._find_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
    return job


@router.get("")
def list_backups(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    # Limpiar dispositivos stale antes de listar respaldos
    from backend.storage.services.disk_service import disk_service
    disk_service.cleanup_stale_mounts()
    data = service.list_jobs(db)
    # Auto-reparación (dinámica, no por-máquina): si alguna bóveda local
    # REGISTRADA falta en el listado (p. ej. su partición de respaldo quedó
    # desmontada o su sondeo live falló transitoriamente tras un update), se
    # remontan las bóvedas por demanda y se reintenta UNA vez. Así una
    # programación ligada a una partición de respaldo nunca desaparece de la
    # UI sin un reinicio manual.
    local_vaults = [v for v in data.get("vaults") if "/stepad-network/" not in v.get("path", "")]
    missing_local = False
    if local_vaults:
        try:
            from backend.shares.models.network_share_volume import NetworkShareVolume
            from backend.shares.services.share_backup_service import VOLUME_RESERVED_NAME
            present = {str(v["path"]).rstrip("/") for v in local_vaults}
            for vol in db.query(NetworkShareVolume).all():
                mp = str(getattr(vol, "mountpoint", "") or "").rstrip("/")
                if not mp or "/mnt/stepad-network/" in mp:
                    continue
                expected = mp + "/" + VOLUME_RESERVED_NAME
                if expected not in present:
                    missing_local = True
                    break
        except Exception as error:
            logger.debug("share_backups.list_backups: %s", error)
            missing_local = False
    if missing_local or not local_vaults:
        service._ensure_backup_vaults_mounted()
        data = service.list_jobs(db)
    return data


@router.get("/errors")
def backup_errors(
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    """Baúl de errores actuales de respaldos y reporte de estado."""
    return service.error_vault()


@router.get("/restore-active")
def get_reste_active(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    """Restauración en curso a nivel global (para el indicador persistente)."""
    return service.active_restore() or None


@router.get("/restores")
def list_restores(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    """Bitácora de restauraciones (para mostrar interrupciones tras un
    reinicio/corte y poder Reintentar o Limpiar)."""
    return {"restores": service.list_restores()}


@router.get("/space-check")
def space_check(
    source: str = Query(default=""),
    destination: str = Query(default=""),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    """Indica si el origen cabe en el espacio libre del destino elegido."""
    return service.space_check(source, destination)


@router.post("", status_code=201)
def create_backup(
    request: CreateBackupJobRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.create_job(request, db)


@router.delete("/{job_id}")
def delete_backup(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Elimina SOLO la programación de este respaldo (conserva los datos
    ya respaldados en la partición). Para borrar también el repositorio se
    usa delete_job_and_repo con confirmación."""
    service.delete_job(job_id)
    return {"success": True, "message": "Programación de respaldo eliminada."}


@router.put("/{job_id}")
def update_backup(
    job_id: int,
    request: UpdateBackupJobRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.update_job(job_id, request, db)


@router.post("/{job_id}/run")
def run_backup_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    _get_job(job_id)
    return service.run_backup(job_id)


@router.post("/{job_id}/skip")
def skip_backup_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Pausa el job y lo deja correr recién en la próxima hora programada."""
    _get_job(job_id)
    return service.skip_to_next_slot(job_id)


@router.post("/{job_id}/stop")
def stop_backup_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Cancela el respaldo en curso (no avanza last_backup_at)."""
    _get_job(job_id)
    return service.stop_backup(job_id)


@router.get("/{job_id}/history")
def get_backup_history(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    """Bitácora de corridas del job (éxito/fallo, mensaje, duración)."""
    _get_job(job_id)
    return {"history": service.job_history(job_id)}


@router.get("/{job_id}/progress")
def get_backup_progress(
    job_id: int,
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    """Progreso del respaldo en curso."""
    return service.get_progress(job_id)


@router.get("/{job_id}/snapshots")
def list_snapshots(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR)),
):
    _get_job(job_id)
    return {"snapshots": service.list_snapshots(job_id)}


@router.get("/{job_id}/snapshots/{snapshot_id}/files")
def list_snapshot_files(
    job_id: int,
    snapshot_id: str,
    prefix: str = "",
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    _get_job(job_id)
    return service.list_files(job_id, snapshot_id, prefix)


@router.post("/{job_id}/snapshots/{snapshot_id}/download-token")
def issue_download_token(
    job_id: int,
    snapshot_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Emite un token de descarga de corta vida (2 min). La URL de descarga
    se puede abrir directo en el navegador con ?dl=<token>: Chrome muestra
    la barra de descarga y transmite en vivo (sin blob que espera TODO)."""
    _get_job(job_id)
    from datetime import datetime, timedelta
    from jose import jwt
    from backend.core.config.settings import Settings
    payload = {
        "sub": current_user.get("username"),
        "user_id": current_user.get("user_id"),
        "role": current_user.get("role"),
        "purpose": "download",
        "exp": utcnow() + timedelta(minutes=2),
    }
    dl = jwt.encode(payload, Settings.JWT_SECRET, algorithm=Settings.JWT_ALGORITHM)
    return {"token": dl, "expires_in_seconds": 120}


@router.get("/{job_id}/snapshots/{snapshot_id}/download")
def download_snapshot_path(
    job_id: int,
    snapshot_id: str,
    path: str = "/",
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_download_user),
):
    _get_job(job_id)
    is_dir, stream = service.download(job_id, snapshot_id, path)
    last = path.strip("/").split("/")[-1] if path.strip("/") else ""
    name = (last or "restauracion").strip()
    if is_dir:
        filename = f"{name or 'carpeta'}.tar"
        media_type = "application/x-tar"
    else:
        filename = name
        media_type = "application/octet-stream"
    return StreamingResponse(
        stream,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


@router.get("/{job_id}/snapshots/{snapshot_id}/download-all")
def download_snapshot_full(
    job_id: int,
    snapshot_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_download_user),
):
    """Deshabilitado: descargar TODO el snapshot como .tar satuaba CPU/disco/
    memoria y era causa de bloqueo del sistema. Usar «Explorar y descargar»."""
    raise HTTPException(status_code=403, detail="Descargar todo el snapshot fue deshabilitado. Usa «Explorar y descargar» para bajar archivos/carpetas específicos.")


@router.post("/{job_id}/prune")
def prune_backups(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    _get_job(job_id)
    return service.prune(job_id)

@router.post("/{job_id}/restore")
def restore_backup(
    job_id: int,
    snapshot_id: str = Query(...),
    target: str = Query(default=""),
    clean: bool = Query(default=False),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Restaura COMPLETA una versión (snapshot) a su carpeta origen o a
    un destino elegido, con la estructura tal cual quedó. `clean`: vacía
    el destino antes (restauración idéntica a la foto)."""
    _get_job(job_id)
    return service.restore_snapshot(
        job_id,
        snapshot_id=snapshot_id,
        target=target or None,
        clean=bool(clean),
    )


@router.get("/{job_id}/restore-status")
def restore_status(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Estado de la restauración en curso/reciente (progreso o resultado)."""
    return service.restore_status(job_id)


@router.post("/{job_id}/restore/cancel")
def restore_cancel(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Cancela la restauración en curso (mata restic restore) y la marca
    como interrumpida en la bitácora."""
    return service.cancel_restore(job_id)


@router.post("/{job_id}/restore/cleanup")
def restore_cleanup(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Borra los restos (`.stepad-restore.tmp`) de una restauración
    interrumpida, conservando lo restaurado a la raíz del destino."""
    return service.cleanup_restore(job_id)


@router.post("/{job_id}/restore/retry")
def restore_retry(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Reintenta la última restauración registrada (misma versión y destino)."""
    return service.retry_restore(job_id)