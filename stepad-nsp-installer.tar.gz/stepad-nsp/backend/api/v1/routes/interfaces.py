from fastapi import APIRouter, Depends

from backend.auth.security.jwt_auth import get_current_user

from backend.network.interfaces.services.interface_service import InterfaceService
from backend.network.interfaces.services.interface_diagnosis_service import InterfaceDiagnosisService


router = APIRouter(
    prefix="/interfaces",
    tags=["Interfaces"],
)


service = InterfaceService()

diagnosis_service = InterfaceDiagnosisService()



@router.get("/")
async def get_interfaces(
    current_user: dict = Depends(get_current_user)
):

    return service.list_interfaces()



@router.get("/diagnosis")
async def get_diagnosis(
    current_user: dict = Depends(get_current_user)
):

    return diagnosis_service.diagnose()