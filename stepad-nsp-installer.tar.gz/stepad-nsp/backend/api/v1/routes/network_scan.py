"""API para escaneo de shares de red."""
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles
from backend.shares.services.network_scan import NetworkShareScanner

router = APIRouter(
    prefix="/shares/network",
    tags=["Network Share Discovery"],
)

scanner = NetworkShareScanner()


class ShareTestRequest(BaseModel):
    host: str
    share: str
    user: str = ""
    password: str = Field(default="", repr=False)


class ShareListRequest(BaseModel):
    host: str
    user: str = ""
    password: str = Field(default="", repr=False)


class ShareBrowseRequest(BaseModel):
    host: str
    share: str
    path: str = ""
    user: str = ""
    password: str = Field(default="", repr=False)


@router.get("/scan")
def scan_network(
    subnet: str = "192.168.100.0/24",
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Escanea la LAN buscando shares SMB."""
    results = scanner.scan_lan(subnet)
    return {
        "success": True,
        "subnet": subnet,
        "hosts": results,
        "total_hosts": len(results),
        "total_shares": sum(len(h["shares"]) for h in results),
    }


@router.post("/test")
def test_share_connection(
    payload: ShareTestRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Prueba conexión a un share específico.

    Credenciales en el CUERPO (nunca en la URL): así no quedan en logs
    de acceso, historial del navegador ni proxies.
    """
    result = scanner.test_connection(
        payload.host, payload.share, payload.user, payload.password
    )
    return result


@router.post("/list-shares")
def list_shares_with_credentials(
    payload: ShareListRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Lista shares SMB de un host usando credenciales."""
    shares = scanner.list_shares_with_auth(
        payload.host, payload.user, payload.password
    )
    return {
        "success": True,
        "host": payload.host,
        "shares": shares,
        "total": len(shares),
    }


@router.post("/browse")
def browse_share_content(
    payload: ShareBrowseRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    """Navega el contenido de un share SMB."""
    items = scanner.browse_share(
        payload.host, payload.share, payload.path,
        payload.user, payload.password,
    )
    return {
        "success": True,
        "host": payload.host,
        "share": payload.share,
        "path": payload.path,
        "items": items,
        "total": len(items),
    }
