from datetime import datetime

from fastapi import APIRouter, Depends, Query

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.audit.repositories.audit_repository import AuditRepository
from backend.users.models.user import User


router = APIRouter(
    prefix="/audit",
    tags=["Audit"]
)

repository = AuditRepository()


@router.get("/")
def list_audit(
    action: str | None = Query(None),
    resource: str | None = Query(None),
    start: datetime | None = Query(None),
    end: datetime | None = Query(None),
    limit: int = Query(200, ge=1, le=500),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    rows = repository.find_filtered(
        db,
        action=action,
        resource=resource,
        start=start,
        end=end,
        limit=limit
    )

    result = []

    for row in rows:

        username = None

        if row.user_id:

            user = db.get(User, row.user_id)

            username = user.username if user else None

        result.append({
            "id": row.id,
            "action": row.action,
            "resource": row.resource,
            "description": row.description,
            "user_id": row.user_id,
            "username": username,
            "created_at": row.created_at.isoformat()
        })

    return result
