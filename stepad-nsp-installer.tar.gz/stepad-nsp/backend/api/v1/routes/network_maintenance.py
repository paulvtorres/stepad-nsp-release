from fastapi import APIRouter, Depends, HTTPException

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.network.configuration.services.temporary_lan_service import (
    temporary_lan_service
)

from backend.api.schemas.temporary_lan_ip_request import (
    TemporaryLanIpRequest
)


router = APIRouter(
    prefix="/network/maintenance",
    tags=["Network Maintenance"]
)



@router.get("/temporary-lan-ip")
def get_temporary_lan_ip_status(
    current_user: dict = Depends(get_current_user)
):

    return temporary_lan_service.get_status()



@router.post("/temporary-lan-ip")
def start_temporary_lan_ip(
    request: TemporaryLanIpRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    result = temporary_lan_service.start_temporary_ip(
        request.temporary_ip,
        request.temporary_prefix,
        request.duration_minutes
    )

    if not result["success"]:

        raise HTTPException(status_code=400, detail=result["message"])

    return result



@router.post("/temporary-lan-ip/revert")
def revert_temporary_lan_ip(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return temporary_lan_service.revert()
