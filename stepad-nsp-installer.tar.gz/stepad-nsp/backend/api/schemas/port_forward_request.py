from pydantic import BaseModel


class PortForwardRequest(BaseModel):

    name: str

    protocol: str = "tcp"

    external_port: int

    internal_ip: str

    internal_port: int

    wan_interface: str | None = None

    enabled: bool = True
