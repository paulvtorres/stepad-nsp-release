from pydantic import BaseModel, ConfigDict

from datetime import datetime


class UserResponse(BaseModel):

    model_config = ConfigDict(
        from_attributes=True
    )

    id: int
    username: str
    role: str
    enabled: bool
    last_login_at: datetime | None = None
    password_changed_at: datetime | None = None