from typing import Optional

from pydantic import BaseModel, Field


class ConnectTailscaleRequest(BaseModel):

    auth_key: str


class CreateTailscaleShareRequest(BaseModel):

    capacity: int = Field(default=1, ge=1, le=10000)

    email: Optional[str] = None


class SetTailscaleApiKeyRequest(BaseModel):

    api_key: str
