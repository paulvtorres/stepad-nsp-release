from typing import Literal

from pydantic import BaseModel, Field


class UpdateShareSettingsRequest(BaseModel):

    enabled: bool | None = None

    share_root: str | None = None

    workgroup: str | None = None

    server_name: str | None = None


class AssignShareDiskRequest(BaseModel):

    device: str


class FormatShareDiskRequest(BaseModel):

    device: str

    # Must be exactly FORMATEAR to proceed.
    confirm: str

    assign: bool = False

    whole_disk: bool = False


class DeletePartitionRequest(BaseModel):

    device: str

    # Must be exactly ELIMINAR to proceed.
    confirm: str


class PauseIntegrityRequest(BaseModel):

    hours: float = 2


class CreatePartitionRequest(BaseModel):

    disk: str

    # Size in GB; omit / null with use_remaining=True to take free space.
    size_gb: float | None = None

    use_remaining: bool = False

    # share | backup
    role: str = "share"

    label: str | None = None


class ResizePartitionRequest(BaseModel):

    device: str

    # Nuevo tamaño en GB. None => crecer hasta usar el espacio libre contiguo.
    new_size_gb: float | None = None

    # Must be exactly ELIMINAR (el usuario asume el riesgo, sobre todo al reducir).
    confirm: str


class MountVolumeRequest(BaseModel):
    device: str
    name: str


class CreateShareFolderRequest(BaseModel):

    name: str

    volume_id: int

    folder_name: str | None = None

    description: str | None = None


class FolderGroupGrant(BaseModel):

    group_id: int

    access_mode: str = Field(default="read")


class SetFolderGroupsRequest(BaseModel):

    groups: list[FolderGroupGrant] = Field(default_factory=list)


class SetFolderSharedRequest(BaseModel):

    shared: bool


class SetFolderBackupPolicyRequest(BaseModel):

    # "off" (no schedule) | "times" (N backups a day) | "on_change" (on change).
    mode: Literal["off", "times", "on_change"]

    times_per_day: int = Field(default=1, ge=1, le=24)

    retention: int = Field(default=7, ge=1, le=365)


class GroupFolderGrant(BaseModel):

    folder_id: int

    access_mode: str = Field(default="read")


class SetGroupFoldersRequest(BaseModel):

    folders: list[GroupFolderGrant] = Field(default_factory=list)


class GroupVolumeGrant(BaseModel):

    volume_id: int

    access_mode: str = Field(default="read")


class SetGroupVolumesRequest(BaseModel):

    volumes: list[GroupVolumeGrant] = Field(default_factory=list)


class CreateBackupJobRequest(BaseModel):

    name: str | None = None

    source_path: str

    # Carpeta privada «Respaldo» de una unidad donde se guardan las copias.
    # Si se omite, se usa la de la unidad que contiene el origen.
    destination_path: str | None = None

    enabled: bool = True

    # "daily" (schedule_hour:minute) | "interval" (interval_minutes)
    # | "on_change" (backup when files change).
    schedule_mode: Literal["daily", "interval", "on_change"] = "daily"

    schedule_hour: int = 2

    schedule_minute: int = 0

    # Multiple daily times ["HH:MM","HH:MM"]. Overrides schedule_hour/minute
    # in "daily" mode.
    schedule_times: list[str] | None = None

    interval_minutes: int | None = None

    retention_count: int = 7

    prune_free_pct: int = 15

    # SMB credentials for network shares (//host/share)
    smb_user: str | None = None
    smb_password: str | None = None


class UpdateBackupJobRequest(BaseModel):

    name: str | None = None

    source_path: str | None = None

    # Solo informativo en updates: el destino no se puede cambiar una vez
    # creado el respaldo (el repo de restic ya vive en esa carpeta).
    destination_path: str | None = None

    enabled: bool | None = None

    schedule_mode: Literal["daily", "interval", "on_change"] | None = None

    schedule_hour: int | None = None

    schedule_minute: int | None = None

    schedule_times: list[str] | None = None

    interval_minutes: int | None = None

    retention_count: int | None = None

    prune_free_pct: int | None = None

    # SMB credentials for network shares (//host/share)
    smb_user: str | None = None
    smb_password: str | None = None