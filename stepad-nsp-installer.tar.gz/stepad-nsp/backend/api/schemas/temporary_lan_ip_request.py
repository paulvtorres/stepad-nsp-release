from pydantic import BaseModel, field_validator


class TemporaryLanIpRequest(BaseModel):

    temporary_ip: str

    temporary_prefix: int = 24

    duration_minutes: int = 15


    @field_validator("duration_minutes")
    @classmethod
    def validate_duration(cls, value):

        if value <= 0 or value > 15:

            raise ValueError("duration_minutes must be between 1 and 15")

        return value
