from pydantic import BaseModel

from backend.shared.constants.user_roles import UserRoles


class UpdateUserRoleRequest(BaseModel):

    role: str