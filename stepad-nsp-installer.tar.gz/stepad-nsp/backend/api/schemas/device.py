from pydantic import BaseModel


class DeviceResponse(BaseModel):
    id: int
    hostname: str
    ip: str
    vendor: str
    status: str