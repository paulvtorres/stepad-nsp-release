from pydantic import BaseModel

class BlockRule(BaseModel):
    device_id: str
    domain: str
    enabled: bool = True