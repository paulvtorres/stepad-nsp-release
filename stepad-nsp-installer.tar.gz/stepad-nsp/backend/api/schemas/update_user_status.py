from pydantic import BaseModel


class UpdateUserStatusRequest(BaseModel):

    enabled: bool