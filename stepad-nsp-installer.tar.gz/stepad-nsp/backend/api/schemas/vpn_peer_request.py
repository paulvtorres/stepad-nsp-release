from pydantic import BaseModel


class CreateVpnPeerRequest(BaseModel):

    name: str

    client_note: str | None = None

    expires_at: str | None = None


class UpdateVpnPeerRequest(BaseModel):

    name: str | None = None

    client_note: str | None = None

    expires_at: str | None = None

    enabled: bool | None = None
