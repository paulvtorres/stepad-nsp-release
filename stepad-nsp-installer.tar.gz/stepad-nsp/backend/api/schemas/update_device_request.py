from pydantic import BaseModel


class UpdateDeviceRequest(BaseModel):

    zone_id: int | None = None

    is_company_asset: bool | None = None

    display_name: str | None = None

    bandwidth_limit_kbps: int | None = None
    is_permanent: bool | None = None
    ip_address: str | None = None
    blocked: bool | None = None
    permanent_ip: str | None = None
