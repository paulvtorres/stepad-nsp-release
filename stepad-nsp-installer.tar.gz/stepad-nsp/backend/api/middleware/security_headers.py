"""
Cabeceras de seguridad para todas las respuestas del NSP.

La UI es una SPA servida por el mismo proceso que la API, sin recursos
externos (fuentes/CDN) y sin WebSockets. El CSP se arma con esa forma:

- script-src 'self': el bundle de Vite es un módulo externo; no hay
  scripts inline.
- style-src 'unsafe-inline': React usa atributos style para estilos
  dinámicos.
- img/media/frame blob:: las vistas previas del explorador de archivos
  y las descargas usan URL.createObjectURL().
- connect-src 'self': toda la API es del mismo origen.

HSTS se agrega solo cuando la request llegó por HTTPS, para no romper
accesos HTTP locales durante una instalación.
"""

from starlette.requests import Request

CSP = (
    "default-src 'self'; "
    "base-uri 'self'; "
    "object-src 'none'; "
    "frame-ancestors 'none'; "
    "form-action 'self'; "
    "script-src 'self'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob:; "
    "font-src 'self' data:; "
    "media-src 'self' blob:; "
    "frame-src blob:; "
    "connect-src 'self'"
)

PERMISSIONS_POLICY = "geolocation=(), microphone=(), camera=()"


def apply_security_headers(request: Request, response) -> None:
    headers = response.headers
    headers.setdefault("X-Content-Type-Options", "nosniff")
    headers.setdefault("X-Frame-Options", "DENY")
    headers.setdefault("Referrer-Policy", "no-referrer")
    headers.setdefault("Permissions-Policy", PERMISSIONS_POLICY)
    headers.setdefault("Content-Security-Policy", CSP)

    if request.url.scheme == "https":
        headers.setdefault(
            "Strict-Transport-Security",
            "max-age=31536000"
        )


def register_security_headers(app):
    @app.middleware("http")
    async def add_security_headers(request: Request, call_next):
        response = await call_next(request)
        apply_security_headers(request, response)
        return response
