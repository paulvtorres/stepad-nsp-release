from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.lifecycle.component_status import ComponentStatus

from backend.api.app import create_app

from backend.core.config.settings import Settings

from backend.shared.logging.logger import logger

from backend.shared.runtime import runtime

from backend.vpn.services.tls_helper import ensure_self_signed_cert

import socket
import sys


class ApiComponent(BaseComponent):

    name = "api"
    criticality = ComponentCriticality.CRITICAL

    def __init__(self):
        self.app = create_app()

    def _check_port_available(self, port: int):
        """
        Fails fast with a clear diagnostic instead of letting uvicorn
        raise a raw "[Errno 98] Address already in use" traceback.
        By far the most common cause of this on STEPAD: the systemd
        service (stepad-nsp.service, Restart=always) is already
        running in the background, and this is a second, manually
        launched instance competing for the same port.

        SO_REUSEADDR is deliberately ENABLED here: a socket left in
        TIME_WAIT by the previous process must NOT be treated as a
        conflict -- with Restart=always, that false positive would
        crash-loop the service for up to ~60s after every restart.
        A genuinely active listener still fails bind() regardless,
        so a real second-instance conflict is caught all the same.
        """

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        try:

            sock.bind(("0.0.0.0", port))

        except OSError:

            logger.error(
                f"Port {port} is still in use even after checking for "
                f"a stale STEPAD instance -- something ELSE is using "
                f"it (STEPAD only ever runs one instance of itself; "
                f"see single_instance_guard). Check with: "
                f"'ss -ltnp | grep {port}' to identify what's holding it."
            )

            sys.exit(1)

        finally:

            sock.close()

    def start(self):
        logger.info("ApiComponent started.")

        tls_ready = ensure_self_signed_cert(
            Settings.WEB_TLS_CERT,
            Settings.WEB_TLS_KEY
        )

        web_port = (
            Settings.WEB_TLS_PORT
            if tls_ready
            else Settings.API_PORT
        )

        self._check_port_available(web_port)

        from backend.network.configuration.services.temporary_lan_service import (
            temporary_lan_service
        )

        temporary_lan_service.start_watchdog()

        # uvicorn.run() blocks for the whole lifetime of the API, so
        # the "set RUNNING" that ComponentLifecycleManager does after
        # component.start() returns can never run for this component.
        # Mark it explicitly before uvicorn takes over, or the panel
        # would report the API as "starting" forever.
        runtime.set(
            self.name,
            ComponentStatus.RUNNING.value
        )

        import uvicorn

        if tls_ready:

            logger.info(
                f"API serving HTTPS on port {web_port}."
            )

            uvicorn.run(
                self.app,
                host="0.0.0.0",
                port=web_port,
                ssl_certfile=Settings.WEB_TLS_CERT,
                ssl_keyfile=Settings.WEB_TLS_KEY
            )

        else:

            logger.warning(
                "TLS not available -- serving plain HTTP on "
                f"port {web_port}. Fix TLS certificate generation."
            )

            uvicorn.run(
                self.app,
                host="0.0.0.0",
                port=web_port
            )

    def stop(self):
        logger.info("ApiComponent stopped.")