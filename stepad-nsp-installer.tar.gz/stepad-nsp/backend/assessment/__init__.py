"""Authorized network/self vulnerability assessment (no exploitation)."""
