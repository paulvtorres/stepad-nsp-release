"""Authorized, bounded TCP assessment of a private network.

Connect scan only (no exploitation, no brute force, no payloads), max /24,
short timeouts and limited concurrency. Results are JSON files under
/var/lib/stepad/assessments (0600).
"""

import json
import os
import socket
import ssl
import threading
import uuid

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from backend.assessment.services import findings, scope
from backend.shared.datetime_utils import utcnow
from sqlalchemy.exc import SQLAlchemyError

from backend.shared.errors import ValidationError
from backend.shared.logging.logger import logger

ASSESSMENT_DIR = Path(
    os.environ.get("STEPAD_ASSESSMENT_DIR", "/var/lib/stepad/assessments")
)
DEFAULT_PORTS = [
    21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 993, 995,
    1433, 3306, 3389, 5432, 5900, 8080, 8291, 8443,
]
MAX_WORKERS = 128
TIMEOUT = 0.7

_LOCK = threading.Lock()
_JOBS: dict = {}


def _tcp_open(host: str, port: int, timeout: float = TIMEOUT) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _tls_findings(host: str, port: int) -> list[dict]:
    try:
        pem = ssl.get_server_certificate((host, port), timeout=4)
        from cryptography import x509

        cert = x509.load_pem_x509_certificate(pem.encode("utf-8"))
        expiry = getattr(cert, "not_valid_after_utc", None)
        if expiry is None:
            expiry = cert.not_valid_after.replace(tzinfo=timezone.utc)
        expired = expiry <= datetime.now(timezone.utc)
        self_signed = cert.issuer == cert.subject
        return findings.tls_finding(expired, self_signed)
    except (OSError, ValueError) as error:
        logger.debug("assessment tls %s:%s: %s", host, port, error)
        return []


def _save(record: dict) -> None:
    try:
        ASSESSMENT_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
        path = ASSESSMENT_DIR / f"network-{record['id']}.json"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        os.replace(tmp, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    except OSError as error:
        logger.warning("No pude guardar la evaluación: %s", error)


def _update(assessment_id: str, **fields) -> None:
    with _LOCK:
        record = _JOBS.get(assessment_id)
        if record is None:
            return
        record.update(fields)
        _save(record)


def _run(assessment_id: str, network, ports: list[int]) -> None:
    all_findings = []
    hosts_result = []
    try:
        targets = scope.hosts(network)
        pairs = [(host, port) for host in targets for port in ports]

        def probe(pair):
            host, port = pair
            return host, port, _tcp_open(host, port)

        open_by_host: dict = {}
        done = 0
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            for host, port, is_open in executor.map(probe, pairs):
                done += 1
                if is_open:
                    open_by_host.setdefault(host, []).append(port)
                if done % 200 == 0:
                    _update(assessment_id, progress=round(done * 100 / len(pairs)))

        for host, open_ports in open_by_host.items():
            host_findings = []
            for port in open_ports:
                item = findings.port_finding(port)
                if item:
                    item = dict(item, port=port)
                    host_findings.append(item)
            for port in open_ports:
                if port in (443, 8443):
                    tls_items = _tls_findings(host, port)
                    for item in tls_items:
                        item["port"] = port
                    host_findings.extend(tls_items)
            if host_findings:
                all_findings.extend(host_findings)
            hosts_result.append(
                {
                    "ip": host,
                    "open_ports": sorted(open_ports),
                    "findings": host_findings,
                }
            )

        hosts_result.sort(key=lambda item: (-len(item["findings"]), item["ip"]))
        result = {
            "hosts_up": len(hosts_result),
            "hosts": hosts_result,
            "findings": all_findings,
            "score": findings.score(all_findings),
            "worst": findings.worst(all_findings),
            "status": "done",
            "finished_at": utcnow().isoformat(),
            "progress": 100,
        }
        _update(assessment_id, **result)
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as error:
        logger.exception("assessment failed: %s", error)
        _update(
            assessment_id,
            status="failed",
            error=str(error)[:300],
            finished_at=utcnow().isoformat(),
        )


class NetworkAssessmentService:

    def start(self, cidr: str, authorized: bool, user_id=None) -> dict:
        network = scope.validate_scope(cidr, authorized)
        assessment_id = uuid.uuid4().hex[:12]
        record = {
            "id": assessment_id,
            "type": "network",
            "target": str(network),
            "status": "running",
            "progress": 0,
            "started_at": utcnow().isoformat(),
            "finished_at": None,
            "score": None,
            "worst": None,
            "hosts_up": 0,
            "hosts": [],
            "findings": [],
            "authorized": True,
        }
        with _LOCK:
            _JOBS[assessment_id] = record
        _save(record)
        self._audit(user_id, str(network))
        threading.Thread(
            target=_run,
            args=(assessment_id, network, DEFAULT_PORTS),
            name=f"assessment-{assessment_id}",
            daemon=True,
        ).start()
        return record

    @staticmethod
    def _audit(user_id, target: str) -> None:
        try:
            from backend.audit.services.audit_service import AuditService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()
            try:
                AuditService().create_log(
                    db,
                    user_id,
                    "NETWORK_ASSESSMENT",
                    "security",
                    f"Evaluación autorizada de red: {target}",
                )
            finally:
                db.close()
        except (
            ImportError, SQLAlchemyError, OSError, ValueError, KeyError,
            TypeError,
        ) as error:
            logger.warning("No pude auditar la evaluación: %s", error)

    def get(self, assessment_id: str) -> dict | None:
        with _LOCK:
            record = _JOBS.get(assessment_id)
        if record is not None:
            return record
        path = ASSESSMENT_DIR / f"network-{assessment_id}.json"
        try:
            return json.loads(path.read_text("utf-8"))
        except (OSError, ValueError):
            return None

    def list(self) -> list[dict]:
        items = []
        try:
            for path in sorted(
                ASSESSMENT_DIR.glob("network-*.json"),
                key=lambda item: item.stat().st_mtime,
                reverse=True,
            )[:20]:
                data = json.loads(path.read_text("utf-8"))
                items.append(
                    {
                        key: data.get(key)
                        for key in (
                            "id", "target", "status", "score", "worst",
                            "started_at", "finished_at", "hosts_up",
                        )
                    }
                )
        except (OSError, ValueError) as error:
            logger.debug("assessment list: %s", error)
        return items
