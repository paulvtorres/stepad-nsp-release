"""Self-audit of the NSP: posture checks using existing state."""

import os
import socket
import ssl
import subprocess

from datetime import datetime, timezone
from pathlib import Path

from backend.assessment.services import findings
from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger
from backend.shared.errors import ValidationError

CHECK_WEIGHTS = {"critical": 25, "high": 15, "medium": 7, "low": 3}


def _tls_local() -> tuple[bool, bool]:
    try:
        pem = ssl.get_server_certificate(("127.0.0.1", 8443), timeout=4)
        from cryptography import x509

        cert = x509.load_pem_x509_certificate(pem.encode("utf-8"))
        expiry = getattr(cert, "not_valid_after_utc", None)
        if expiry is None:
            expiry = cert.not_valid_after.replace(tzinfo=timezone.utc)
        return expiry <= datetime.now(timezone.utc), cert.issuer == cert.subject
    except (OSError, ValueError):
        return False, False


def _ssh_all_interfaces() -> bool | None:
    try:
        result = subprocess.run(
            ["ss", "-ltnH", "sport = :22"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        for line in result.stdout.splitlines():
            parts = line.split()
            if len(parts) >= 4:
                local = parts[3]
                if local.startswith("0.0.0.0:") or local.startswith("[::]:"):
                    return True
        return False
    except (OSError, subprocess.SubprocessError):
        return None


class SelfAssessmentService:

    def run(self) -> dict:
        checks = []

        def add(check_id, title, ok, severity, detail, recommendation):
            checks.append(
                {
                    "id": check_id,
                    "title": title,
                    "ok": bool(ok),
                    "severity": severity,
                    "detail": detail,
                    "recommendation": recommendation,
                }
            )

        exposed = _ssh_all_interfaces()
        add(
            "SSH_WAN",
            "SSH expuesto en todas las interfaces",
            exposed is False,
            "high",
            "sshd escucha en 0.0.0.0/[::] (puerto 22)."
            if exposed else "sshd escucha en direcciones concretas.",
            "Escucha SSH solo en LAN/VPN y cierra 22 en WAN.",
        )

        try:
            from backend.firewall.services.firewall_hardening_service import (
                FirewallHardeningService,
            )

            settings = FirewallHardeningService().get_settings()
            add(
                "FIREWALL_HARDENING",
                "Endurecimiento del firewall",
                bool(settings.get("hardening_enabled")),
                "high",
                "El hardening deny-all está desactivado."
                if not settings.get("hardening_enabled")
                else "Hardening activo.",
                "Activa el hardening de firewall.",
            )
        except (ImportError, OSError, ValueError) as error:
            logger.debug("self-audit firewall: %s", error)

        try:
            from backend.backups.services.system_backup_service import (
                system_backup_service,
            )

            status = system_backup_service.cached_status()
            healthy = system_backup_service_healthy(status)
            add(
                "SYSTEM_BACKUP",
                "Respaldo del sistema reciente",
                healthy,
                "high",
                f"Último: {status.get('last_backup') or 'nunca'}.",
                "Revisa el destino y el scheduler del respaldo del sistema.",
            )
            verify = status.get("restore_verify") or {}
            add(
                "SYSTEM_RESTORE",
                "Restauración del sistema verificada",
                bool(verify.get("success")),
                "medium",
                verify.get("message") or "sin verificaciones",
                "Ejecuta 'Verificar ahora' en Respaldo del sistema.",
            )
        except (ImportError, OSError, ValueError) as error:
            logger.debug("self-audit system backup: %s", error)

        try:
            from backend.audit.services.audit_chain_check_service import (
                AuditChainCheckService,
            )

            state = AuditChainCheckService().status()
            add(
                "AUDIT_CHAIN",
                "Cadena de auditoría íntegra",
                bool(state.get("ok")),
                "high",
                state.get("message") or "sin verificaciones",
                "Verifica la integridad desde Auditoría.",
            )
        except (ImportError, OSError, ValueError) as error:
            logger.debug("self-audit audit chain: %s", error)

        expired, self_signed = _tls_local()
        add(
            "TLS_CERT",
            "Certificado web válido",
            not expired and not self_signed,
            "medium",
            "Certificado vencido" if expired
            else "Certificado autofirmado" if self_signed
            else "Certificado vigente",
            "Instala/renueva un certificado de confianza.",
        )

        failed = [item for item in checks if not item["ok"]]
        penalty = sum(
            CHECK_WEIGHTS.get(item.get("severity"), 0) for item in failed
        )
        from backend.shared.datetime_utils import utcnow as _utcnow

        return {
            "type": "self",
            "checked_at": _utcnow().isoformat(),
            "score": max(0, 100 - penalty),
            "worst": findings.worst(
                [item for item in failed if item.get("severity")]
            ),
            "checks": checks,
            "findings": failed,
        }


def system_backup_service_healthy(status: dict) -> bool:
    last = status.get("last_backup")
    if not last:
        return False
    try:
        parsed = datetime.fromisoformat(str(last).replace("Z", "+00:00"))
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
        return (utcnow() - parsed).total_seconds() <= 48 * 3600
    except (TypeError, ValueError):
        return False
