"""Heurísticas de equipos con más de una salida de red.

No intenta adivinar desde una sola firma. Solo marca un equipo cuando el
inventario del NSP tiene evidencia de dos interfaces/IPs distintas y al
menos una de ellas cae fuera de las redes que el NSP controla.
"""

from __future__ import annotations

import ipaddress

from collections import defaultdict


GENERIC_HOSTNAMES = {
    "",
    "android",
    "debian",
    "desktop",
    "iphone",
    "ipad",
    "laptop",
    "localhost",
    "pc",
    "raspberrypi",
    "unknown",
    "windows",
}

GENERIC_PREFIXES = (
    "android-",
    "desktop-",
    "iphone-",
    "laptop-",
    "windows-",
)


CONSEQUENCES = [
    "La segunda interfaz puede navegar sin filtrado DNS/RPZ, IPS ni cuarentena del NSP.",
    "El equipo puede evadir bloqueos y generar actividad fuera de la visibilidad del NSP.",
    "La cuarentena por MAC solo cubre la interfaz conectada al NSP; la salida directa sigue activa.",
    "Si se usa como puente o ICS, puede exponer la LAN o crear rutas y bucles no controlados.",
]

RECOMMENDATION = (
    "Deja una sola salida: router del proveedor → WAN del NSP → LAN. "
    "Desconecta la segunda interfaz o úsala en una red aislada sin gateway "
    "ni DNS propios. Revisa rutas y puertas de enlace del equipo."
)


def _hostname(value: str | None) -> str:
    return (value or "").strip().lower()


def _is_generic_hostname(value: str) -> bool:
    if not value or value in GENERIC_HOSTNAMES:
        return True
    return value.startswith(GENERIC_PREFIXES)


def _device_ips(device: dict) -> set[str]:
    result = set()

    for field in ("current_ip", "assigned_ip", "ip_address", "last_ip"):
        value = str(device.get(field) or "").strip()

        if not value or value == "0.0.0.0":
            continue

        try:
            ipaddress.ip_address(value)
        except ValueError:
            continue

        result.add(value)

    return result


def _inside(ip: str, networks) -> bool:
    try:
        address = ipaddress.ip_address(ip)
    except ValueError:
        return False

    return any(address in network for network in networks)


def _finding(group: list[dict], linked: bool, inside: list[str], outside: list[str]) -> dict:
    label = (
        next(
            (
                device.get("display_name") or device.get("hostname")
                for device in group
                if device.get("display_name") or device.get("hostname")
            ),
            "Equipo sin nombre",
        )
        or "Equipo sin nombre"
    )

    pairs = []
    seen = set()

    for device in group:
        for ip in sorted(_device_ips(device)):
            key = (device.get("mac_address"), ip)
            if key in seen:
                continue
            seen.add(key)
            pairs.append(
                f"{device.get('mac_address') or 'MAC desconocida'} → {ip}"
            )

    evidence = "; ".join(pairs)
    affected = sorted(set(inside) | set(outside))

    return {
        "type": "NETWORK_BYPASS_DUAL_HOMED",
        "severity": "critical" if linked else "high",
        "title": f"Posible bypass de red: {label}",
        "detail": (
            "El equipo tiene más de una interfaz/IP y al menos una está "
            "fuera de las redes controladas por el NSP. "
            f"Interfaces: {evidence}."
        ),
        "evidence": evidence,
        "recommendation": RECOMMENDATION,
        "consequences": CONSEQUENCES,
        "confidence": "alta" if linked else "media",
        "affected_ips": affected,
        "devices": [
            {
                "id": device.get("id"),
                "hostname": device.get("hostname") or "",
                "display_name": device.get("display_name") or "",
                "mac_address": device.get("mac_address") or "",
                "ips": sorted(_device_ips(device)),
                "linked_to_id": device.get("linked_to_id"),
            }
            for device in group
        ],
    }


def detect(devices: list[dict], cidrs: list[str]) -> list[dict]:
    """Return one finding per multi-interface group with an outside IP."""

    networks = []

    for cidr in cidrs or []:
        try:
            networks.append(ipaddress.ip_network(str(cidr), strict=False))
        except ValueError:
            continue

    if not networks or len(devices) < 2:
        return []

    by_id = {
        device.get("id"): device
        for device in devices
        if device.get("id") is not None
    }
    grouped_ids = set()
    findings = []

    linked_groups = defaultdict(list)

    for device in devices:
        parent_id = device.get("linked_to_id")
        if parent_id is not None:
            linked_groups[parent_id].append(device)

    for parent_id, children in linked_groups.items():
        group = list(children)

        if parent_id in by_id:
            group.insert(0, by_id[parent_id])

        linked_ids = {
            item.get("id")
            for item in group
            if item.get("id") is not None
        }
        grouped_ids.update(linked_ids)

        if len({item.get("mac_address") for item in group}) < 2:
            continue

        ips = set().union(*(_device_ips(item) for item in group))

        if len(ips) < 2:
            continue

        inside = [ip for ip in ips if _inside(ip, networks)]
        outside = [ip for ip in ips if not _inside(ip, networks)]

        if inside and outside:
            findings.append(_finding(group, True, inside, outside))

    by_hostname = defaultdict(list)

    for device in devices:
        if device.get("id") in grouped_ids:
            continue

        name = _hostname(device.get("hostname") or device.get("display_name"))

        if not _is_generic_hostname(name):
            by_hostname[name].append(device)

    for name, group in by_hostname.items():
        if len({item.get("mac_address") for item in group}) < 2:
            continue

        ips = set().union(*(_device_ips(item) for item in group))

        if len(ips) < 2:
            continue

        inside = [ip for ip in ips if _inside(ip, networks)]
        outside = [ip for ip in ips if not _inside(ip, networks)]

        if inside and outside:
            findings.append(_finding(group, False, inside, outside))

    return findings
