"""Scope validation: private IPv4 only, bounded size, explicit consent."""

import ipaddress

from backend.shared.errors import ValidationError

MAX_HOSTS = 256
MAX_PREFIX = 24

PRIVATE = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("100.64.0.0/10"),
)


def validate_scope(cidr: str, authorized: bool) -> ipaddress.IPv4Network:
    if not authorized:
        raise ValidationError(
            "Debes confirmar que tienes autorización escrita del cliente."
        )
    try:
        network = ipaddress.ip_network((cidr or "").strip(), strict=False)
    except ValueError as error:
        raise ValidationError(f"CIDR inválido: {error}")
    if network.version != 4:
        raise ValidationError("Solo se admite IPv4.")
    if not any(network.subnet_of(private) for private in PRIVATE):
        raise ValidationError(
            "El alcance debe ser una red privada (10/8, 172.16/12, "
            "192.168/16 o 100.64/10). No se escanean direcciones públicas."
        )
    if network.prefixlen < MAX_PREFIX:
        raise ValidationError(
            f"Alcance demasiado grande: máximo /{MAX_PREFIX} ({MAX_HOSTS} IPs)."
        )
    return network


def hosts(network: ipaddress.IPv4Network) -> list[str]:
    if network.prefixlen == 32:
        return [str(network.network_address)]
    return [str(host) for host in network.hosts()][:MAX_HOSTS]
