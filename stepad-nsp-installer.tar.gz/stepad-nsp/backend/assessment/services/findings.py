"""Port/TLS findings and scoring (pure)."""

WEIGHTS = {"critical": 25, "high": 15, "medium": 7, "low": 3, "info": 0}

PORT_RULES = {
    21: ("high", "FTP expuesto", "Usa SFTP/FTPS y restringe el acceso."),
    23: ("critical", "Telnet expuesto", "Deshabilita Telnet; usa SSH."),
    445: ("high", "SMB expuesto", "Restringe SMB a la LAN y deshabilita SMBv1."),
    3389: ("high", "RDP expuesto", "Limita RDP a VPN y activa NLA."),
    5900: ("high", "VNC expuesto", "Limita VNC a VPN; usa contraseña fuerte."),
    8291: ("high", "Winbox/MikroTik expuesto", "Limita 8291 a la LAN/VPN."),
    1433: ("critical", "SQL Server expuesto", "No expongas bases a la LAN."),
    3306: ("critical", "MySQL expuesto", "Escucha solo en localhost/VPN."),
    5432: ("critical", "PostgreSQL expuesto", "Escucha solo en localhost/VPN."),
    27017: ("critical", "MongoDB expuesto", "Escucha solo en localhost/VPN."),
    80: ("medium", "HTTP sin cifrar", "Redirige a HTTPS y evita logins por HTTP."),
    8080: ("medium", "HTTP alternativo sin cifrar", "Usa HTTPS."),
}


def port_finding(port: int) -> dict | None:
    rule = PORT_RULES.get(port)
    if not rule:
        return None
    severity, title, recommendation = rule
    return {
        "type": f"PORT_{port}",
        "severity": severity,
        "title": title,
        "detail": f"Puerto TCP {port} abierto.",
        "recommendation": recommendation,
    }


def tls_finding(expired: bool, self_signed: bool) -> list[dict]:
    findings = []
    if expired:
        findings.append(
            {
                "type": "TLS_EXPIRED",
                "severity": "high",
                "title": "Certificado TLS vencido",
                "detail": "El certificado HTTPS está vencido.",
                "recommendation": "Renueva el certificado (Let's Encrypt o interno).",
            }
        )
    if self_signed:
        findings.append(
            {
                "type": "TLS_SELF_SIGNED",
                "severity": "medium",
                "title": "Certificado TLS autofirmado",
                "detail": "El certificado no es de una CA de confianza.",
                "recommendation": "Instala un certificado de una CA confiable.",
            }
        )
    return findings


def score(findings: list[dict]) -> int:
    penalty = sum(WEIGHTS.get(item.get("severity"), 0) for item in findings)
    return max(0, 100 - penalty)


def worst(findings: list[dict]) -> str:
    order = ["critical", "high", "medium", "low", "info"]
    present = {item.get("severity") for item in findings}
    for level in order:
        if level in present:
            return level
    return "info"
