from fastapi import HTTPException

from datetime import datetime

from sqlalchemy.orm import Session

from backend.users.models.user import User

from backend.shared.constants.user_roles import UserRoles

from backend.users.repositories.user_repository import (
UserRepository
)

from backend.users.security.password_hasher import PasswordHasher

from backend.users.security.password_policy import PasswordPolicy

from backend.audit.services.audit_service import AuditService

class UserService:

    def __init__(self):
        self.repository = UserRepository()
        self.password_hasher = PasswordHasher()
        self.audit_service = AuditService()
    def create_admin(
        self,
        db: Session,
        username: str,
        password_hash: str
    ):
        existing = self.repository.find_by_username(
            db,
            username
        )
        if existing:
            return existing
        user = User(
            username=username,
            password_hash=password_hash,
            role=UserRoles.ADMIN,
            enabled=True,
            password_changed_at=datetime.utcnow()
        )
        return self.repository.save(
            db,
            user
        )
    def find_by_username(
        self,
        db: Session,
        username: str
    ):
        return self.repository.find_by_username(
            db,
            username
        )
    def get_users(
        self,
        db: Session
    ):
        return self.repository.find_all(db)
    def create_user(
        self,
        db: Session,
        username: str,
        password: str,
        role: str,
        created_by: int
    ):
        existing = self.repository.find_by_username(
            db,
            username
        )
        if existing:
            return existing

        policy_errors = PasswordPolicy.errors(password)

        if policy_errors:

            raise HTTPException(
                status_code=400,
                detail="Password must include "
                + ", ".join(policy_errors)
            )

        user = User(
            username=username,
            password_hash=self.password_hasher.hash(
                password
            ),
            role=role,
            enabled=True,
            password_changed_at=datetime.utcnow()
        )
        saved_user = self.repository.save(
            db,
            user
        )
        self.audit_service.create_log(
            db=db,
            user_id=created_by,
            action="USER_CREATED",
            resource="USER",
            description=f"Created user {saved_user.username}"
        )
        return saved_user
    def change_role(
        self,
        db: Session,
        user_id: int,
        role: str,
        changed_by: int
    ):
        user = self.repository.find_by_id(
            db,
            user_id
        )
        if user is None:
            raise HTTPException(
                status_code=404,
                detail="User not found"
            )
        user.role = role
        updated_user = self.repository.update(
            db,
            user
        )
        self.audit_service.create_log(
            db=db,
            user_id=changed_by,
            action="USER_ROLE_CHANGED",
            resource="USER",
            description=f"Changed role of {updated_user.username} to {role}"
        )
        return updated_user
    def change_status(
        self,
        db: Session,
        user_id: int,
        enabled: bool,
        changed_by: int
    ):
        user = self.repository.find_by_id(
            db,
            user_id
        )
        if user is None:
            raise HTTPException(
                status_code=404,
                detail="User not found"
            )
        user.enabled = enabled
        updated_user = self.repository.update(
            db,
            user
        )
        self.audit_service.create_log(
            db=db,
            user_id=changed_by,
            action="USER_STATUS_CHANGED",
            resource="USER",
            description=f"Changed status of {updated_user.username} to {enabled}"
        )
        return updated_user