from sqlalchemy import String, Boolean, DateTime, Integer
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.constants.user_roles import UserRoles


class User(Base):

    __tablename__ = "users"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    username: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        unique=True
    )


    password_hash: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )


    role: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default=UserRoles.ADMIN
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    failed_attempts: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0
    )


    locked_until: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    password_changed_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    last_login_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    totp_secret: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True
    )


    mfa_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
