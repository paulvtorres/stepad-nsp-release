import re


class PasswordPolicy:

    MIN_LENGTH = 8

    RULES = [

        (
            "a lowercase letter",
            re.compile(r"[a-z]")
        ),

        (
            "an uppercase letter",
            re.compile(r"[A-Z]")
        ),

        (
            "a number",
            re.compile(r"\d")
        ),

        (
            "a special character",
            re.compile(r"[^A-Za-z0-9]")
        ),

    ]

    @classmethod
    def errors(
        cls,
        password: str
    ) -> list[str]:

        missing = []

        if len(password) < cls.MIN_LENGTH:

            missing.append(f"at least {cls.MIN_LENGTH} characters")

        for label, pattern in cls.RULES:

            if not pattern.search(password):

                missing.append(label)

        return missing
