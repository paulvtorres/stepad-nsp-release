from sqlalchemy.orm import Session

from backend.users.models.user import User


class UserRepository:


    def find_by_username(
        self,
        db: Session,
        username: str
    ):

        return (
            db.query(User)
            .filter(
                User.username == username
            )
            .first()
        )


    def save(
        self,
        db: Session,
        user: User
    ):

        db.add(user)

        db.commit()

        db.refresh(user)

        return user

    def find_all(
        self,
        db: Session
    ):

        return (
            db.query(User)
            .all()
        )    

    def find_by_id(

        self,

        db: Session,

        user_id: int

    ):

        return (

            db.query(User)

            .filter(

                User.id == user_id

            )

            .first()

        )    

    def update(
        self,
        db: Session,
        user: User
    ):

        db.commit()

        db.refresh(user)

        return user    