from pydantic import BaseModel


class CloudStorageSettingsRequest(BaseModel):

    enabled: bool | None = None

    provider: str | None = None

    endpoint: str | None = None

    bucket: str | None = None

    remote_path: str | None = None

    # only sent when the operator wants to change them; None keeps the
    # previously stored (encrypted) values.
    access_key: str | None = None

    secret_key: str | None = None

    host: str | None = None

    user: str | None = None

    password: str | None = None

    upload_hour: int | None = None

    upload_minute: int | None = None

    upload_days: int | None = None
