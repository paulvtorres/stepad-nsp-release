from sqlalchemy.orm import Session

from backend.backups.models.backup_settings import BackupSettings


class BackupSettingsRepository:

    def get(
        self,
        db: Session
    ) -> BackupSettings:

        settings = db.get(BackupSettings, 1)

        if settings is None:

            settings = BackupSettings(id=1)

            db.add(settings)

            db.commit()

            db.refresh(settings)

        return settings

    def save(
        self,
        db: Session,
        settings: BackupSettings
    ):

        db.commit()

        db.refresh(settings)

        return settings
