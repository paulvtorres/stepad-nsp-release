"""Integrity checks for update rollback points.

Each point is `<version>-<ts>.app.tar.gz` plus `<stem>.db.sql.gz` (and
version/meta sidecars). Verifying means listing the tar and testing the
gzip; a corrupt point would make a rollback fail when it is needed most.
"""

import gzip
import json
import os
import subprocess
import threading

from datetime import datetime, timedelta
from pathlib import Path

from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger

ROLLBACK_DIR = Path(
    os.environ.get("STEPAD_ROLLBACK_DIR", "/var/lib/stepad/rollback")
)
STATE_PATH = os.environ.get(
    "STEPAD_ROLLBACK_STATE",
    "/etc/stepad/rollback_integrity.json",
)
INTERVAL_DAYS = 7
ALERT_TYPE = "ROLLBACK_POINT_CORRUPT"


def point_files(app_path: Path) -> dict:
    stem = str(app_path)[: -len(".app.tar.gz")]
    return {
        "app": app_path,
        "db": Path(stem + ".db.sql.gz"),
        "version": Path(stem + ".version"),
        "meta": Path(stem + ".meta"),
    }


def check_point(app_path: Path) -> dict:
    files = point_files(app_path)
    name = app_path.name[: -len(".app.tar.gz")]
    errors = []

    try:
        result = subprocess.run(
            ["tar", "-tzf", str(files["app"])],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=300,
        )
        if result.returncode != 0:
            errors.append(
                "tar: " + (result.stderr or b"").decode(errors="replace").strip()[:200]
            )
    except (OSError, subprocess.SubprocessError) as error:
        errors.append(f"tar: {error}")

    if not files["db"].is_file():
        errors.append("falta el volcado de base de datos")
    else:
        try:
            result = subprocess.run(
                ["gzip", "-t", str(files["db"])],
                capture_output=True,
                timeout=600,
            )
            if result.returncode != 0:
                errors.append(
                    "gzip: "
                    + (result.stderr or b"").decode(errors="replace").strip()[:200]
                )
        except (OSError, subprocess.SubprocessError) as error:
            errors.append(f"gzip: {error}")

    version = name.split("-2")[0]
    try:
        if files["version"].is_file():
            version = files["version"].read_text("utf-8").strip() or version
    except OSError:
        pass

    created = None
    try:
        created = datetime.fromtimestamp(
            files["app"].stat().st_mtime
        ).isoformat(timespec="seconds")
    except OSError:
        pass

    return {
        "name": name,
        "version": version,
        "ok": not errors,
        "error": "; ".join(errors)[:500],
        "created_at": created,
        "app_size": files["app"].stat().st_size if files["app"].is_file() else 0,
        "db_size": files["db"].stat().st_size if files["db"].is_file() else 0,
    }


def list_points(directory: Path = ROLLBACK_DIR) -> list[dict]:
    try:
        apps = sorted(
            directory.glob("*.app.tar.gz"),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        return []
    return [check_point(path) for path in apps]


class RollbackIntegrityService:

    def __init__(self, state_path: str | None = None, directory: Path | None = None):
        self.state_path = state_path or STATE_PATH
        self.directory = directory or ROLLBACK_DIR
        self._lock = threading.Lock()

    def status(self) -> dict:
        try:
            with open(self.state_path, encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                return data
        except (OSError, ValueError) as error:
            logger.debug("rollback_integrity.status: %s", error)
        return {}

    def should_run(self) -> bool:
        last_raw = self.status().get("last_run_at")
        if not last_raw:
            return True
        try:
            last = datetime.fromisoformat(last_raw)
        except ValueError:
            return True
        return utcnow() - last > timedelta(days=INTERVAL_DAYS)

    def _save(self, data: dict) -> None:
        try:
            tmp = f"{self.state_path}.tmp"
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, indent=2)
            os.replace(tmp, self.state_path)
            try:
                os.chmod(self.state_path, 0o600)
            except OSError:
                pass
        except OSError as error:
            logger.warning("No pude guardar la integridad de rollback: %s", error)

    def run(self, alert: bool = True) -> dict:
        if not self._lock.acquire(blocking=False):
            return {"ok": False, "message": "verificación en curso"}
        try:
            return self._run_locked(alert)
        finally:
            self._lock.release()

    def _run_locked(self, alert: bool) -> dict:
        points = list_points(self.directory)
        broken = [point for point in points if not point["ok"]]
        result = {
            "ok": not broken,
            "count": len(points),
            "broken": [point["name"] for point in broken],
            "points": points,
            "message": (
                "sin puntos de retorno"
                if not points
                else (
                    f"{len(points)} punto(s) íntegros"
                    if not broken
                    else f"{len(broken)} punto(s) dañados"
                )
            ),
            "last_run_at": utcnow().isoformat(),
        }
        self._save(result)
        if alert and broken:
            try:
                from backend.alerts.services.alert_service import AlertService
                from backend.core.database.session import SessionLocal

                db = SessionLocal()
                try:
                    AlertService().create(
                        db,
                        alert_type=ALERT_TYPE,
                        severity="critical",
                        title="Punto de retorno de actualización dañado",
                        message=(
                            "Estos rollback points no se podrían restaurar: "
                            + ", ".join(result["broken"])
                            + ". Crea un respaldo/actualización nuevo."
                        )[:500],
                    )
                    db.commit()
                finally:
                    db.close()
            except (ImportError, OSError, ValueError, KeyError, TypeError) as error:
                logger.warning("No pude alertar rollback dañado: %s", error)
        return result
