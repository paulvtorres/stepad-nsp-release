"""Health rules for the SYSTEM backup (pure, testable).

Returns alert descriptors; the component creates them. Thresholds:
- enabled + last successful backup older than 48h -> overdue
- destination filesystem below 10% free -> disk low
"""

from datetime import datetime, timedelta, timezone

OVERDUE_HOURS = 48
MIN_FREE_PCT = 10.0


def _naive_utc(value):
    if not value:
        return None
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    if value.tzinfo is not None:
        value = value.astimezone(timezone.utc).replace(tzinfo=None)
    return value


def evaluate(status: dict, now: datetime, free_pct: float | None = None) -> list[dict]:
    issues = []
    if not status:
        return issues
    enabled = bool(status.get("enabled")) and bool(
        status.get("schedule_enabled")
    )
    if not enabled:
        return issues

    last = _naive_utc(status.get("last_backup"))
    if last is None:
        issues.append(
            {
                "type": "SYSTEM_BACKUP_OVERDUE",
                "severity": "critical",
                "title": "Respaldo del sistema: ninguno registrado",
                "message": "El respaldo automático está activo pero no hay "
                "ninguna versión. Revisa el destino (USB/nube/espacio).",
            }
        )
    else:
        age = (now - last).total_seconds()
        if age > OVERDUE_HOURS * 3600:
            hours = int(age // 3600)
            issues.append(
                {
                    "type": "SYSTEM_BACKUP_OVERDUE",
                    "severity": "critical",
                    "title": "Respaldo del sistema atrasado",
                    "message": f"El último respaldo del sistema tiene "
                    f"{hours} h (umbral {OVERDUE_HOURS} h). Revisa el "
                    "destino y el scheduler.",
                }
            )

    if free_pct is not None and free_pct < MIN_FREE_PCT:
        issues.append(
            {
                "type": "SYSTEM_BACKUP_DISK_LOW",
                "severity": "warning",
                "title": "Poco espacio para el respaldo del sistema",
                "message": f"Queda {free_pct:.1f}% libre en el destino del "
                f"respaldo (mínimo {MIN_FREE_PCT:.0f}%).",
            }
        )

    return issues
