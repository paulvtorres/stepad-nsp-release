"""Periodic proof that the SYSTEM backup (PostgreSQL + config) restores.

Takes the latest system-backup snapshot, extracts the SQL dump and loads
it into a temporary database, checks a sanity table count and drops it.
Never touches the live database. Skips (without alert) when there is no
destination configured/available.
"""

import gzip
import json
import os
import shutil
import subprocess
import tempfile
import threading

from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy.exc import SQLAlchemyError

from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger

STATE_PATH = os.environ.get(
    "STEPAD_SYSTEM_RESTORE_STATE",
    "/etc/stepad/system_backup_verify.json",
)

CHECK_DB = "stepad_sys_restore_check"
DUMP_PATH = "/tmp/stepad-sys-backup-db.sql.gz"
MIN_TABLES = 20
INTERVAL_DAYS = 30
ALERT_TYPE = "SYSTEM_BACKUP_RESTORE_CHECK"


class SystemRestoreVerificationService:

    def __init__(self, state_path: str | None = None):
        self.state_path = state_path or STATE_PATH
        self._lock = threading.Lock()

    def status(self) -> dict:
        try:
            with open(self.state_path, encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                return data
        except (OSError, ValueError) as error:
            logger.debug("system_restore_verification.status: %s", error)
        return {}

    def should_run(self) -> bool:
        last_raw = self.status().get("last_run_at")
        if not last_raw:
            return True
        try:
            last = datetime.fromisoformat(last_raw)
        except ValueError:
            return True
        return utcnow() - last > timedelta(days=INTERVAL_DAYS)

    def _save(self, data: dict) -> None:
        try:
            tmp = f"{self.state_path}.tmp"
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, indent=2)
            os.replace(tmp, self.state_path)
            try:
                os.chmod(self.state_path, 0o600)
            except OSError:
                pass
        except OSError as error:
            logger.warning("No pude guardar la verificación del sistema: %s", error)

    @staticmethod
    def _env() -> dict:
        values = dict(os.environ)
        try:
            for line in Path("/etc/stepad/stepad.env").read_text(
                encoding="utf-8"
            ).splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                values.setdefault(key.strip(), value.strip().strip("'").strip('"'))
        except OSError as error:
            logger.debug("system_restore_verification._env: %s", error)
        return values

    def _latest_snapshot(self, service) -> dict | None:
        repo = service._get_repo_path()
        if not repo:
            return None
        result = subprocess.run(
            [
                "sudo", "restic", "snapshots", "--latest", "1", "--json",
                "--repo", repo, *service._password_args(),
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(
                (result.stderr or "restic snapshots falló").strip()[:300]
            )
        rows = json.loads(result.stdout or "[]")
        return rows[-1] if rows else None

    def run(self, alert: bool = True) -> dict:
        if not self._lock.acquire(blocking=False):
            return {"success": False, "message": "verificación en curso"}
        try:
            return self._run_locked(alert)
        finally:
            self._lock.release()

    def _run_locked(self, alert: bool) -> dict:
        from backend.backups.services.system_backup_service import (
            SystemBackupService,
        )

        started = utcnow()
        service = SystemBackupService()
        repo = service._get_repo_path()

        if not repo:
            result = {
                "success": False,
                "skipped": True,
                "message": "sin destino de respaldo del sistema",
                "last_run_at": started.isoformat(),
            }
            self._save(result)
            return result

        dump = None

        try:
            service._ensure_repo(repo)
            snapshot = self._latest_snapshot(service)
            if snapshot is None:
                result = {
                    "success": False,
                    "skipped": True,
                    "message": "sin versiones del respaldo del sistema",
                    "last_run_at": started.isoformat(),
                }
                self._save(result)
                return result

            snapshot_id = snapshot.get("id") or snapshot.get("short_id")
            if DUMP_PATH not in (snapshot.get("paths") or []):
                result = {
                    "success": False,
                    "message": "la última versión no contiene el dump de PostgreSQL",
                    "snapshot": snapshot_id,
                    "last_run_at": started.isoformat(),
                }
                self._save(result)
                if alert:
                    self._alert(result["message"])
                return result

            handle, dump_name = tempfile.mkstemp(suffix=".sql.gz")
            os.close(handle)
            dump = Path(dump_name)
            with open(dump, "wb") as target:
                proc = subprocess.run(
                    [
                        "sudo", "restic", "dump", snapshot_id, DUMP_PATH,
                        "--repo", repo, *service._password_args(),
                    ],
                    stdout=target,
                    stderr=subprocess.PIPE,
                    timeout=1800,
                )
            if proc.returncode != 0:
                raise RuntimeError(
                    "no se pudo extraer el dump: "
                    + (proc.stderr or b"").decode(errors="replace")[:300]
                )

            env = self._env()
            db_user = env.get("DB_USER", "stepad_app")
            db_host = env.get("DB_HOST", "127.0.0.1")
            db_port = env.get("DB_PORT", "5432")

            subprocess.run(
                ["runuser", "-u", "postgres", "--", "dropdb", "--if-exists", CHECK_DB],
                capture_output=True,
                timeout=60,
            )
            created = subprocess.run(
                ["runuser", "-u", "postgres", "--", "createdb", "-O", db_user, CHECK_DB],
                capture_output=True,
                timeout=60,
            )
            if created.returncode != 0:
                raise RuntimeError(
                    "no se pudo crear la base temporal: "
                    + (created.stderr or b"").decode(errors="replace").strip()[:200]
                )

            psql = subprocess.Popen(
                [
                    "psql", "-h", db_host, "-p", db_port, "-U", db_user,
                    "-q", "-v", "ON_ERROR_STOP=1", "-d", CHECK_DB,
                ],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                env={**os.environ, "PGPASSWORD": env.get("DB_PASSWORD", "")},
            )
            try:
                with gzip.open(dump, "rb") as source:
                    shutil.copyfileobj(source, psql.stdin, length=1024 * 1024)
                psql.stdin.close()
            except OSError:
                psql.kill()
                raise

            stderr = psql.stderr.read()
            psql.wait(timeout=1800)
            if psql.returncode != 0:
                raise RuntimeError(
                    "psql no pudo cargar el dump: "
                    + (stderr or b"").decode(errors="replace").strip()[:300]
                )

            counted = subprocess.run(
                [
                    "runuser", "-u", "postgres", "--", "psql",
                    "-tAc",
                    "select count(*) from information_schema.tables "
                    "where table_schema='public'",
                    "-d", CHECK_DB,
                ],
                capture_output=True,
                text=True,
                timeout=60,
            )
            tables = int((counted.stdout or "0").strip() or 0)
            if tables < MIN_TABLES:
                raise RuntimeError(
                    f"la base restaurada solo tiene {tables} tablas "
                    f"(esperadas >= {MIN_TABLES})"
                )

            elapsed = (utcnow() - started).total_seconds()
            result = {
                "success": True,
                "message": "respaldo del sistema restaurado y verificado",
                "snapshot": snapshot_id,
                "tables": tables,
                "duration_seconds": round(elapsed, 1),
                "last_run_at": utcnow().isoformat(),
            }
            self._save(result)
            logger.info(
                "Verificación del respaldo del sistema OK (%s): %s tablas, %.1fs",
                snapshot_id, tables, elapsed,
            )
            return result

        except (OSError, ValueError, KeyError, TypeError, RuntimeError) as error:
            result = {
                "success": False,
                "message": str(error)[:300],
                "last_run_at": utcnow().isoformat(),
            }
            self._save(result)
            logger.warning("Verificación del respaldo del sistema FALLÓ: %s", error)
            if alert:
                self._alert(result["message"])
            return result

        finally:
            try:
                subprocess.run(
                    ["runuser", "-u", "postgres", "--", "dropdb", "--if-exists", CHECK_DB],
                    capture_output=True,
                    timeout=60,
                )
            except (OSError, subprocess.SubprocessError):
                pass
            if dump is not None:
                try:
                    dump.unlink()
                except OSError:
                    pass

    @staticmethod
    def _alert(message: str) -> None:
        try:
            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()
            try:
                AlertService().create(
                    db,
                    alert_type=ALERT_TYPE,
                    severity="critical",
                    title="No se pudo verificar el respaldo del sistema",
                    message=(message or "")[:500],
                )
                db.commit()
            finally:
                db.close()
        except (
            ImportError, SQLAlchemyError, OSError, ValueError, KeyError,
            TypeError,
        ) as error:
            logger.warning(
                "No pude crear la alerta de verificación del sistema: %s", error
            )
