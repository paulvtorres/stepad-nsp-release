"""Replacement bundle format (pure helpers).

A bundle is a tar.gz encrypted with a user passphrase that carries:
  manifest.json, database.sql.gz, etc/stepad.env, etc/config.yaml
"""

from datetime import datetime

from backend.shared.datetime_utils import utcnow

FORMAT = "stepad-replacement/1"

REQUIRED_FILES = (
    "manifest.json",
    "database.sql.gz",
    "etc/stepad.env",
)


def build_manifest(version: str, hostname: str, db_name: str, files: dict, now=None) -> dict:
    return {
        "format": FORMAT,
        "version": version or "",
        "created_at": (now or utcnow()).isoformat(timespec="seconds"),
        "hostname": hostname or "",
        "database": db_name or "",
        "files": dict(files),
    }


def validate_manifest(data) -> dict:
    if not isinstance(data, dict):
        raise ValueError("manifest inválido")
    if data.get("format") != FORMAT:
        raise ValueError("formato de paquete no soportado")
    if not data.get("version"):
        raise ValueError("falta la versión en el manifest")
    files = data.get("files")
    if not isinstance(files, dict):
        raise ValueError("falta la lista de archivos")
    return data


def bundle_filename(version: str, now=None) -> str:
    stamp = (now or utcnow()).strftime("%Y%m%d-%H%M")
    safe = (version or "unknown").replace("/", "_")
    return f"stepad-replacement-{safe}-{stamp}.enc"
