from sqlalchemy import String, Boolean, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime
from backend.shared.datetime_utils import utcnow

from backend.core.database.base import Base


class CloudStorageSettings(Base):

    __tablename__ = "cloud_storage_settings"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    # master switch for the scheduled cloud log upload.
    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    # rclone provider type: s3 (S3-compatible), sftp, webdav.
    provider: Mapped[str] = mapped_column(
        String(30),
        default="s3"
    )


    # S3-compatible endpoint (e.g. https://s3.us-west-004.backblazeb2.com)
    endpoint: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # S3 bucket (required for s3 provider).
    bucket: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # optional folder inside the bucket / remote directory.
    remote_path: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # credentials are stored AES-256 encrypted (STEPAD_BACKUP_KEY).
    access_key: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    secret_key: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # SFTP/WebDAV host or URL, user and password (sftp/webdav).
    host: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    user: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    password: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    upload_hour: Mapped[int] = mapped_column(
        Integer,
        default=3
    )


    upload_minute: Mapped[int] = mapped_column(
        Integer,
        default=30
    )


    # how many days of logs to send per run (previous days).
    upload_days: Mapped[int] = mapped_column(
        Integer,
        default=1
    )


    last_upload_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    last_upload_result: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # Subida del respaldo de configuracion/BD (independiente de los logs).
    backup_upload_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    backup_remote_path: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    backup_retention_count: Mapped[int] = mapped_column(
        Integer,
        default=7
    )


    backup_last_upload_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    backup_last_result: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utcnow,
        onupdate=utcnow
    )
