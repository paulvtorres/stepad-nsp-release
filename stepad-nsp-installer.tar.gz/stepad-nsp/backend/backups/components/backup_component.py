from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.backups.services.backup_service import BackupService
from backend.backups.services.cloud_storage_service import CloudStorageService

from backend.shared.logging.logger import logger


class BackupComponent(BaseComponent):

    name = "backups"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.service = BackupService()

    def start(self):

        logger.info("BackupComponent started.")

        self.service.start_scheduler()

        CloudStorageService().start_scheduler()

    def stop(self):

        logger.info("BackupComponent stopped.")
