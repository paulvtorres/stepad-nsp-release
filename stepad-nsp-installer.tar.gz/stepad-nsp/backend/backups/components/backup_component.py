import threading
import time

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.backups.services.backup_service import BackupService
from backend.backups.services.cloud_storage_service import CloudStorageService
from backend.backups.services.system_backup_service import (
    system_backup_service
)

from backend.shared.logging.logger import logger


class BackupComponent(BaseComponent):

    name = "backups"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.service = BackupService()

    def health_check(self) -> bool:
        try:
            thread = getattr(self.service, "_scheduler_thread", None)
            return bool(thread and thread.is_alive())

        except Exception as error:
            logger.warning("BackupComponent health_check: %s", error)
            return False

    def start(self):

        logger.info("BackupComponent started.")

        self.service.start_scheduler()

        # Monthly proof that the latest backup is restorable (temp DB).
        try:

            from backend.backups.services.restore_verification_service import (
                RestoreVerificationService,
            )
            from backend.audit.services.audit_chain_check_service import (
                AuditChainCheckService,
            )

            self._verify = RestoreVerificationService()

            self._audit_check = AuditChainCheckService()

            from backend.backups.services.system_restore_verification_service import (
                SystemRestoreVerificationService,
            )

            self._sys_verify = SystemRestoreVerificationService()

            from backend.backups.services.rollback_integrity_service import (
                RollbackIntegrityService,
            )

            self._rollback_check = RollbackIntegrityService()

            threading.Thread(
                target=self._verify_loop,
                name="restore-verify",
                daemon=True,
            ).start()

        except Exception as error:

            logger.warning(
                "No se pudo iniciar la verificación de respaldos: %s", error
            )

        CloudStorageService().start_scheduler()

        try:
            from backend.reports.services.vulnerability_report_service import (
                VulnerabilityReportService,
            )

            VulnerabilityReportService().start_scheduler()
        except (ImportError, OSError, ValueError) as error:
            logger.warning(
                "No se pudo iniciar el informe de vulnerabilidades: %s", error
            )

        # Respaldo automático de la configuración del NSP (config + postgres)
        # programado según system-backup-config.json (por defecto 03:00).
        try:
            system_backup_service.start_scheduler()
        except Exception as error:
            logger.warning(
                "No se pudo iniciar el scheduler de respaldo del sistema: %s",
                error,
            )

    def _verify_loop(self):

        # Give the system time to settle after boot, then check daily and
        # run the verification once a month.
        time.sleep(600)

        while True:

            try:

                if self._verify.should_run():

                    self._verify.run()

                if getattr(self, "_audit_check", None) and self._audit_check.should_run():

                    self._audit_check.run()

                if getattr(self, "_sys_verify", None) and self._sys_verify.should_run():

                    self._sys_verify.run()

                self._system_backup_health()

                if getattr(self, "_rollback_check", None) and self._rollback_check.should_run():

                    self._rollback_check.run()

            except Exception as error:

                logger.warning(
                    "Verificación de respaldo falló al ejecutarse: %s", error
                )

            time.sleep(86400)

    def _system_backup_health(self) -> None:

        """Daily alerts: system backup overdue or destination almost full."""

        try:

            import shutil
            from pathlib import Path

            from backend.backups.services import backup_health
            from backend.backups.services.system_backup_service import (
                system_backup_service,
            )
            from backend.shared.datetime_utils import utcnow

            status = system_backup_service.get_status()

            free_pct = None

            repo = system_backup_service._get_repo_path()

            if repo and Path(repo).exists():

                usage = shutil.disk_usage(repo)

                if usage.total:

                    free_pct = round(100 * usage.free / usage.total, 1)

            issues = backup_health.evaluate(status, utcnow(), free_pct)

            if not issues:

                return

            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                for issue in issues:

                    AlertService().create(
                        db,
                        alert_type=issue["type"],
                        severity=issue["severity"],
                        title=issue["title"],
                        message=issue["message"],
                    )

                db.commit()

            finally:

                db.close()

        except (ImportError, OSError, ValueError, KeyError, TypeError) as error:

            logger.warning("Salud del respaldo del sistema: %s", error)

    def stop(self):

        logger.info("BackupComponent stopped.")

        try:
            system_backup_service.stop_scheduler()
        except Exception as error:
            logger.debug("backup_component.stop: %s", error)