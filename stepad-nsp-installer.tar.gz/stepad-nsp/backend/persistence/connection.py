from sqlalchemy import create_engine


DATABASE_URL = (
    "postgresql://stepad:stepad@localhost:5432/stepad"
)


engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
)