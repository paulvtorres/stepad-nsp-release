from sqlalchemy import Column, Integer, String

from backend.persistence.database import Base


class FirewallInterfaceEntity(Base):

    __tablename__ = "firewall_interfaces"


    id = Column(
        Integer,
        primary_key=True,
        index=True
    )


    name = Column(
        String(50),
        nullable=False
    )


    ip = Column(
        String(50)
    )


    mac = Column(
        String(50)
    )


    status = Column(
        String(20)
    )


    role = Column(
        String(20),
        default="UNKNOWN"
    )