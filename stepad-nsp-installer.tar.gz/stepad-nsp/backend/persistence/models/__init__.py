from backend.persistence.models.firewall_interface_entity import (
    FirewallInterfaceEntity
)