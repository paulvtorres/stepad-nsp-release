from sqlalchemy.orm import sessionmaker

from backend.persistence.connection import engine


SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)