from pydantic import BaseModel

from backend.shared.enums.rule_action import RuleAction


class CreateZoneRuleRequest(BaseModel):

    action: RuleAction

    rule_type: str

    value: str

    enabled: bool = True

    schedule_id: int | None = None
