from pydantic import BaseModel
from backend.shared.enums.rule_action import RuleAction


class CreateGlobalRuleRequest(BaseModel):

    action: RuleAction

    rule_type: str

    value: str

    enabled: bool = True

    # Only meaningful for BLOCK: makes this un-overridable by any
    # zone's ALLOW rule (e.g. adult content). Defaults False so
    # existing behavior (everything overridable) is unchanged unless
    # explicitly opted in.
    is_permanent: bool = False

    schedule_id: int | None = None