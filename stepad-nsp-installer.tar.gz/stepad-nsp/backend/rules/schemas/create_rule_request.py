from pydantic import BaseModel


class CreateRuleRequest(BaseModel):

    action: str

    rule_type: str

    value: str