from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.rules.services.rule_bootstrap_service import (
    RuleBootstrapService
)

from backend.core.database.session import SessionLocal

from backend.shared.logging.logger import logger



class RulesComponent(BaseComponent):


    name = "rules"

    criticality = ComponentCriticality.IMPORTANT



    def __init__(self):

        self.service = RuleBootstrapService()



    def health_check(self) -> bool:
        try:
            import subprocess

            result = subprocess.run(
                ["/usr/sbin/nft", "list", "chain", "inet", "stepad", "forward"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            return result.returncode == 0

        except Exception as error:
            logger.warning("RulesComponent health_check: %s", error)
            return False

    def start(self):

        logger.info(
            "RulesComponent started."
        )


        db = SessionLocal()


        try:

            result = self.service.apply_active_rules(
                db
            )


            logger.info(
                f"Rules restored: {result}"
            )


        finally:

            db.close()



    def stop(self):

        logger.info(
            "RulesComponent stopped."
        )