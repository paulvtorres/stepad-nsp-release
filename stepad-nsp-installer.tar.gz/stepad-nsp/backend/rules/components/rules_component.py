from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.rules.services.rule_bootstrap_service import (
    RuleBootstrapService
)

from backend.core.database.session import SessionLocal

from backend.shared.logging.logger import logger



class RulesComponent(BaseComponent):


    name = "rules"

    criticality = ComponentCriticality.IMPORTANT



    def __init__(self):

        self.service = RuleBootstrapService()



    def start(self):

        logger.info(
            "RulesComponent started."
        )


        db = SessionLocal()


        try:

            result = self.service.apply_active_rules(
                db
            )


            logger.info(
                f"Rules restored: {result}"
            )


        finally:

            db.close()



    def stop(self):

        logger.info(
            "RulesComponent stopped."
        )