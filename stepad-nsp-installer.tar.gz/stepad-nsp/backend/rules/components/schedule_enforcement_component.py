from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.rules.services.schedule_enforcement_service import (
    ScheduleEnforcementService
)

from backend.shared.logging.logger import logger


class ScheduleEnforcementComponent(BaseComponent):

    name = "schedule_enforcement"

    criticality = ComponentCriticality.OPTIONAL


    def __init__(self):

        self.service = ScheduleEnforcementService()


    def start(self):

        self.service.start()

        logger.info(
            "ScheduleEnforcementComponent started "
            "(re-syncing global + zone domain policies every 60s)."
        )


    def stop(self):

        self.service.stop()

        logger.info("ScheduleEnforcementComponent stopped.")
