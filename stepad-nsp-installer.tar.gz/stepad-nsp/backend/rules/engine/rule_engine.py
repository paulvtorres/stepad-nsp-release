from backend.firewall.services.firewall_service import (
    FirewallService
)

from backend.dns.services.domain_service import (
    DomainService
)

from backend.dns.factory import (
    get_dns_provider
)


class RuleEngine:


    def __init__(self):

        self.firewall = FirewallService()

        # Same provider instance as GlobalRuleService's DomainService
        # (see factory.get_dns_provider) so a domain rule change
        # results in exactly ONE dnsmasq restart, not two.
        self.domain_service = DomainService(get_dns_provider())


    def apply(
        self,
        rule,
        db=None
    ):

        if rule.action.upper() != "BLOCK":

            return {
                "success": False,
                "message": "Action not supported"
            }


        if rule.rule_type.upper() == "MAC":

            return self.firewall.block_device(
                rule.value
            )


        if rule.rule_type.upper() == "DOMAIN":

            if db is None:

                return {
                    "success": False,
                    "message": "Database session required"
                }

            result = self.domain_service.synchronize(
                db
            )

            # A new/changed GLOBAL domain rule (especially an
            # is_permanent one) can change what every zone is
            # allowed to override -- re-sync all zones too.
            self.domain_service.synchronize_all_zones(
                db
            )

            return result


        if rule.rule_type.upper() == "PORT":

            return {
                "success": False,
                "message": "PORT blocking not implemented"
            }


        return {
            "success": False,
            "message": "Unknown rule type"
        }


    def remove(
        self,
        rule,
        db=None
    ):

        if rule.rule_type.upper() == "MAC":

            return self.firewall.unblock_device(
                rule.value
            )


        if rule.rule_type.upper() == "DOMAIN":

            if db is None:

                return {
                    "success": False,
                    "message": "Database session required"
                }

            return self.domain_service.synchronize(
                db
            )


        return {
            "success": False,
            "message": "Rule removal not supported"
        }