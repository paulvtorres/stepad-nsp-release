from sqlalchemy.orm import Session

from backend.rules.models.device_access_rule import DeviceAccessRule

from backend.shared.enums import (
    RuleType,
    ScopeType,
)


class DeviceAccessRuleRepository:

    def find_all_by_device(
        self,
        db: Session,
        device_id: int
    ):

        return (
            db.query(DeviceAccessRule)
            .filter(
                DeviceAccessRule.device_id == device_id
            )
            .all()
        )


    def find_by_id(
        self,
        db: Session,
        rule_id: int
    ):

        return (
            db.query(DeviceAccessRule)
            .filter(
                DeviceAccessRule.id == rule_id
            )
            .first()
        )

    def find_global_domains(
        self,
        db: Session
    ):

        return (

            db.query(DeviceAccessRule)

            .filter(
                DeviceAccessRule.rule_type == RuleType.DOMAIN,
                DeviceAccessRule.enabled.is_(True),
                DeviceAccessRule.scope == ScopeType.GLOBAL
            )

            .all()

        )

    def find_global_domain(
        self,
        db: Session,
        value: str
    ):

        return (

            db.query(DeviceAccessRule)

            .filter(
                DeviceAccessRule.scope == ScopeType.GLOBAL,
                DeviceAccessRule.rule_type == RuleType.DOMAIN,
                DeviceAccessRule.value == value
            )

            .first()

        )


    def find_zone_domains(
        self,
        db: Session,
        zone_id: int
    ):

        return (

            db.query(DeviceAccessRule)

            .filter(
                DeviceAccessRule.rule_type == RuleType.DOMAIN,
                DeviceAccessRule.enabled.is_(True),
                DeviceAccessRule.scope == ScopeType.ZONE,
                DeviceAccessRule.zone_id == zone_id
            )

            .all()

        )


    def find_zone_domain(
        self,
        db: Session,
        zone_id: int,
        value: str
    ):

        return (

            db.query(DeviceAccessRule)

            .filter(
                DeviceAccessRule.scope == ScopeType.ZONE,
                DeviceAccessRule.zone_id == zone_id,
                DeviceAccessRule.rule_type == RuleType.DOMAIN,
                DeviceAccessRule.value == value
            )

            .first()

        )


    def find_permanent_global_domain(
        self,
        db: Session,
        value: str
    ):

        return (

            db.query(DeviceAccessRule)

            .filter(
                DeviceAccessRule.scope == ScopeType.GLOBAL,
                DeviceAccessRule.rule_type == RuleType.DOMAIN,
                DeviceAccessRule.is_permanent.is_(True),
                DeviceAccessRule.value == value
            )

            .first()

        )


    def save(
        self,
        db: Session,
        rule: DeviceAccessRule
    ):

        db.add(rule)

        db.commit()

        db.refresh(rule)

        return rule


    def update(
        self,
        db: Session,
        rule: DeviceAccessRule
    ):

        db.commit()

        db.refresh(rule)

        return rule


    def delete(
        self,
        db: Session,
        rule: DeviceAccessRule
    ):

        db.delete(rule)

        db.commit()
