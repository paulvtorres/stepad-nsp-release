from sqlalchemy.orm import Session

from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.rules.engine.rule_engine import RuleEngine

from backend.dns.services.domain_service import DomainService
from backend.dns.factory import get_dns_provider


class RuleBootstrapService:


    def __init__(self):

        self.engine = RuleEngine()

        # Same provider instance as RuleEngine's own DomainService --
        # see get_dns_provider()'s docstring for why sharing it
        # matters (one recursor reload, not several).
        self.domain_service = DomainService(get_dns_provider())


    def apply_active_rules(
        self,
        db: Session
    ):

        rules = (
            db.query(DeviceAccessRule)
            .filter(
                DeviceAccessRule.enabled == True
            )
            .all()
        )


        results = []

        domain_rule_seen = False


        for rule in rules:

            if rule.rule_type.upper() == "DOMAIN":

                # synchronize()/synchronize_all_zones() always
                # recompute the FULL active domain set from the DB,
                # not just this one rule -- applying every DOMAIN
                # rule individually here would reload the recursor
                # once per rule for an identical end result. Defer
                # to a single sync after the loop instead.
                domain_rule_seen = True

                results.append({
                    "rule_id": rule.id,
                    "rule_type": "DOMAIN",
                    "deferred": True
                })

                continue

            result = self.engine.apply(
                rule,
                db
            )

            results.append(
                result
            )


        if domain_rule_seen:

            domain_result = self.domain_service.synchronize(db)

            zones_result = self.domain_service.synchronize_all_zones(db)

            results.append({
                "rule_type": "DOMAIN",
                "global_sync": domain_result,
                "zones_sync": zones_result
            })

        return results