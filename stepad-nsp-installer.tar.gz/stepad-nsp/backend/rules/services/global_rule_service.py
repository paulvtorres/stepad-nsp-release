from sqlalchemy.orm import Session

from backend.rules.models.device_access_rule import (
    DeviceAccessRule
)

from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository
)

from backend.rules.engine.rule_engine import (
    RuleEngine
)

class GlobalRuleService:


    def __init__(self):

        self.repository = DeviceAccessRuleRepository()

        self.engine = RuleEngine()



    def get_domain_rules(
        self,
        db: Session
    ):

        return (

            db.query(DeviceAccessRule)

            .filter(
                DeviceAccessRule.scope == "GLOBAL",
                DeviceAccessRule.rule_type == "DOMAIN"
            )

            .all()

        )



    def create_rule(
        self,
        request,
        db: Session
    ):
        value = request.value.strip().lower()

        # Expansión padre -> hijos (ej. youtube.com tambien bloquea
        # googlevideo.com, ytimg.com...).
        from backend.content.services.domain_group_service import (
            DomainGroupService
        )

        action_value = getattr(
            request.action, "value", request.action
        )

        if (
            action_value == "BLOCK"
            and getattr(request, "rule_type", "DOMAIN") == "DOMAIN"
        ):

            domains = DomainGroupService().expand_domains(db, value)

        else:

            domains = [value]

        saved = None

        for d in domains:

            existing = self.repository.find_global_domain(db, d)

            if existing:

                if saved is None:

                    saved = existing

                continue

            action_value = getattr(request.action, "value", request.action)
            protected = action_value == "BLOCK"

            rule = DeviceAccessRule(
                device_id=None,
                action=request.action,
                rule_type=request.rule_type,
                value=d,
                scope="GLOBAL",
                enabled=request.enabled,
                is_permanent=protected or getattr(request, "is_permanent", False),
                is_protected=protected,
                protection_reason=(
                    "Bloqueo manual protegido" if protected else None
                ),
                schedule_id=getattr(request, "schedule_id", None)
            )

            r = self.repository.save(db, rule)

            if saved is None:

                saved = r

        self.engine.apply(
            saved,
            db
        )

        return saved



    def unlock_rule(self, rule_id: int, db: Session):
        rule = self.repository.find_by_id(db, rule_id)

        if not rule:
            return None

        rule.is_protected = False
        rule.is_permanent = False
        rule.protection_reason = None
        self.repository.save(db, rule)
        self.engine.domain_service.synchronize(db)
        self.engine.domain_service.synchronize_all_zones(db)
        return rule

    def delete_rule(
        self,
        rule_id:int,
        db:Session
    ):


        rule = self.repository.find_by_id(
            db,
            rule_id
        )


        if not rule:

            return None

        if getattr(rule, "is_protected", False):

            from fastapi import HTTPException

            raise HTTPException(
                status_code=409,
                detail=(
                    "Esta regla es un bloqueo manual protegido. "
                    "Usa «Desbloquear» antes de eliminarla."
                ),
            )


        # Capture what the engine needs BEFORE deleting: the row's
        # ORM attributes expire after commit, and domain sync must
        # run AFTER the delete so the removed domain is excluded
        # from the regenerated blocklist (querying GLOBAL domains
        # before the delete would still include the one being
        # removed).
        rule_type = rule.rule_type

        value = rule.value


        self.repository.delete(
            db,
            rule
        )


        if rule_type == "MAC":

            self.engine.firewall.unblock_device(value)

        elif rule_type == "DOMAIN":

            self.engine.domain_service.synchronize(db)

            self.engine.domain_service.synchronize_all_zones(db)

        return True
