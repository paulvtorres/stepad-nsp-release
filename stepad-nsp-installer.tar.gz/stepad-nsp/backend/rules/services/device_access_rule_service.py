from sqlalchemy.orm import Session

from backend.rules.models.device_access_rule import DeviceAccessRule

from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository,
)

from backend.rules.engine.rule_engine import RuleEngine


class DeviceAccessRuleService:


    def __init__(self):

        self.repository = DeviceAccessRuleRepository()

        self.rule_engine = RuleEngine()


    def get_rules(
        self,
        device_id: int,
        db: Session
    ):

        return self.repository.find_all_by_device(
            db,
            device_id
        )


    def create_rule(
        self,
        device_id: int,
        action: str,
        rule_type: str,
        value: str,
        db: Session
    ):

        rule = DeviceAccessRule(

            device_id=device_id,

            action=action,

            rule_type=rule_type,

            value=value,

            enabled=True

        )


        saved_rule = self.repository.save(
            db,
            rule
        )


        self.rule_engine.apply(
            saved_rule,
            db
        )


        return saved_rule


    def delete_rule(
        self,
        rule_id: int,
        db: Session
    ):

        rule = self.repository.find_by_id(
            db,
            rule_id
        )


        if not rule:
            return None


        self.rule_engine.remove(
            rule,
            db
        )


        self.repository.delete(
            db,
            rule
        )


        return True