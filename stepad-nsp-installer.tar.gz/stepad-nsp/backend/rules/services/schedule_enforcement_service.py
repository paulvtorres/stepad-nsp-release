import threading
import time

from backend.core.database.session import SessionLocal
from backend.dns.services.domain_service import DomainService
from backend.dns.factory import get_dns_provider

from backend.shared.logging.logger import logger


CHECK_INTERVAL_SECONDS = 60


class ScheduleEnforcementService:

    def __init__(self):

        self.domain_service = DomainService(get_dns_provider())

        self._stop_event = threading.Event()

        self._thread = None


    def _tick(self):

        db = SessionLocal()

        try:

            self.domain_service.synchronize(db)

            self.domain_service.synchronize_all_zones(db)

        except Exception:

            # A schedule tick must never crash the background thread --
            # log and try again next interval rather than silently
            # stopping enforcement until the next restart.
            logger.exception(
                "ScheduleEnforcementService: error during scheduled re-sync"
            )

        finally:

            db.close()


    def _run_loop(self):

        while not self._stop_event.is_set():

            self._tick()

            self._stop_event.wait(CHECK_INTERVAL_SECONDS)


    def start(self):

        if self._thread and self._thread.is_alive():

            return

        self._stop_event.clear()

        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name="schedule-enforcement"
        )

        self._thread.start()


    def stop(self):

        self._stop_event.set()
