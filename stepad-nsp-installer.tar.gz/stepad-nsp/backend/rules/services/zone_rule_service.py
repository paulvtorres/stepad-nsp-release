from sqlalchemy.orm import Session

from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository
)

from backend.dns.services.domain_service import DomainService
from backend.dns.factory import get_dns_provider

from backend.shared.enums import RuleAction, RuleType, ScopeType


class ZoneRuleService:

    def __init__(self):

        self.repository = DeviceAccessRuleRepository()

        # Same shared provider instance as everything else -- see
        # the factory.get_dns_provider() comment elsewhere for why.
        self.domain_service = DomainService(get_dns_provider())


    def get_zone_rules(
        self,
        db: Session,
        zone_id: int
    ):

        return self.repository.find_zone_domains(db, zone_id)


    def create_rule(
        self,
        db: Session,
        zone_id: int,
        request
    ):

        value = request.value.strip().lower()

        if request.rule_type == RuleType.DOMAIN and request.action == RuleAction.ALLOW:

            permanent_block = self.repository.find_permanent_global_domain(
                db,
                value
            )

            if permanent_block:

                raise ValueError(

                    f"'{value}' is a permanent global block and cannot be "
                    "allowed for any zone."

                )

        existing = self.repository.find_zone_domain(db, zone_id, value)

        if existing:

            raise ValueError(f"A rule for '{value}' already exists in this zone.")

        rule = DeviceAccessRule(

            zone_id=zone_id,

            scope=ScopeType.ZONE,

            action=request.action,

            rule_type=request.rule_type,

            value=request.value,

            enabled=request.enabled,

            schedule_id=request.schedule_id

        )

        saved = self.repository.save(db, rule)

        if request.rule_type == RuleType.DOMAIN:

            self.domain_service.synchronize_zone(db, zone_id)

        return saved


    def delete_rule(
        self,
        db: Session,
        rule_id: int
    ):

        rule = self.repository.find_by_id(db, rule_id)

        if not rule:

            return None

        zone_id = rule.zone_id

        rule_type = rule.rule_type

        self.repository.delete(db, rule)

        if rule_type == RuleType.DOMAIN and zone_id:

            # Delete-before-sync, same ordering fix as
            # GlobalRuleService.delete_rule -- querying the zone's
            # rules before the commit would still include the one
            # just removed.
            self.domain_service.synchronize_zone(db, zone_id)

        return True
