"""Friendly policy overview and simulator built on existing rules.

Phase 1 deliberately does not change DNS enforcement. It exposes the
recommended policy precedence and compares it with what the current
group/zone DNS actually applies, so the gap is visible before Phase 2.
"""

from __future__ import annotations

from sqlalchemy import func
from sqlalchemy.orm import Session

from backend.content.models.content_category import (
    CategoryDomain,
    ContentCategory,
    GroupCategory,
)
from backend.content.services.content_category_service import ROOT_CATEGORY_KEYS
from backend.groups.models.device_group import DeviceGroup, GroupDevice
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.zones.models.network_zone import NetworkZone
from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.shared.datetime_utils import utcnow
from backend.shared.enums import RuleAction
from backend.network.zones.repositories.schedule_repository import ScheduleRepository


def _normalize(value: str | None) -> str:
    return (value or "").strip().lower().rstrip(".")


def _suffixes(domain: str) -> set[str]:
    labels = _normalize(domain).split(".")

    return {
        ".".join(labels[index:])
        for index in range(len(labels) - 1)
    }


def _domain_matches(domain: str, candidate: str) -> bool:
    domain = _normalize(domain)
    candidate = _normalize(candidate)

    if candidate.startswith("*."):
        candidate = candidate[2:]

    return bool(
        domain
        and candidate
        and (domain == candidate or domain.endswith("." + candidate))
    )


def _active(rule: DeviceAccessRule, db: Session, schedules: dict) -> bool:
    if not rule.enabled:
        return False

    if not rule.schedule_id:
        return True

    schedule = schedules.get(rule.schedule_id)

    if schedule is None:
        schedule = ScheduleRepository().find_by_id(db, rule.schedule_id)
        schedules[rule.schedule_id] = schedule

    return bool(schedule and schedule.is_active_now(utcnow()))


def _rule_label(rule: DeviceAccessRule) -> str:
    return {
        "GLOBAL": "Global",
        "ZONE": "Zona",
        "GROUP": "Grupo",
        "DEVICE": "Equipo",
    }.get(rule.scope, rule.scope)


class PolicyService:

    def overview(self, db: Session) -> dict:
        zones = db.query(NetworkZone).all()
        groups = db.query(DeviceGroup).all()
        devices = db.query(NetworkDevice).all()

        device_by_zone: dict[int, int] = {}
        device_by_group: dict[int, int] = {}

        for device in devices:
            if device.zone_id is not None:
                device_by_zone[device.zone_id] = device_by_zone.get(device.zone_id, 0) + 1

        memberships = db.query(GroupDevice).all()

        for membership in memberships:
            device_by_group[membership.group_id] = device_by_group.get(membership.group_id, 0) + 1

        group_by_device = {
            membership.device_id: membership.group_id
            for membership in memberships
        }

        zone_rules = dict(
            db.query(DeviceAccessRule.zone_id, func.count(DeviceAccessRule.id))
            .filter(
                DeviceAccessRule.scope == "ZONE",
                DeviceAccessRule.enabled.is_(True),
            )
            .group_by(DeviceAccessRule.zone_id)
            .all()
        )

        group_rules = dict(
            db.query(DeviceAccessRule.group_id, func.count(DeviceAccessRule.id))
            .filter(
                DeviceAccessRule.scope == "GROUP",
                DeviceAccessRule.enabled.is_(True),
            )
            .group_by(DeviceAccessRule.group_id)
            .all()
        )

        group_categories = dict(
            db.query(GroupCategory.group_id, func.count(GroupCategory.id))
            .group_by(GroupCategory.group_id)
            .all()
        )

        device_items = [
            {
                "id": device.id,
                "name": (
                    device.display_name
                    or device.hostname
                    or device.current_ip
                    or device.ip_address
                    or device.mac_address
                ),
                "ip": device.current_ip or device.ip_address,
                "zone_id": device.zone_id,
                "zone_name": next(
                    (zone.name for zone in zones if zone.id == device.zone_id),
                    "Sin zona",
                ),
                "group_id": group_by_device.get(device.id),
                "group_name": next(
                    (
                        group.name
                        for group in groups
                        if group.id == group_by_device.get(device.id)
                    ),
                    "Sin grupo",
                ),
            }
            for device in sorted(
                devices,
                key=lambda item: (
                    (item.display_name or item.hostname or item.ip_address or "").lower()
                ),
            )
        ]

        return {
            "generated_at": utcnow().isoformat(),
            "default_zone": next((z.name for z in zones if z.is_default), None),
            "precedence": [
                "Bloqueos de seguridad permanentes",
                "Excepción por equipo",
                "Regla de grupo",
                "Regla de zona",
                "Regla global",
                "Sin regla específica",
            ],
            "zones": [
                {
                    "id": zone.id,
                    "name": zone.name,
                    "is_default": bool(zone.is_default),
                    "network_cidr": zone.network_cidr,
                    "gateway_ip": zone.gateway_ip,
                    "vlan_id": zone.vlan_id,
                    "devices": device_by_zone.get(zone.id, 0),
                    "rules": zone_rules.get(zone.id, 0),
                }
                for zone in sorted(zones, key=lambda item: (not item.is_default, item.name.lower()))
            ],
            "groups": [
                {
                    "id": group.id,
                    "name": group.name,
                    "is_default": bool(group.is_default),
                    "devices": device_by_group.get(group.id, 0),
                    "rules": group_rules.get(group.id, 0),
                    "categories": group_categories.get(group.id, 0),
                }
                for group in sorted(groups, key=lambda item: (not item.is_default, item.name.lower()))
            ],
            "devices": device_items,
            "warning": (
                "La política de zona y las excepciones por equipo todavía no se "
                "aplican al DNS de grupo. El simulador muestra la política "
                "recomendada y la aplicación actual."
            ),
        }

    def audit(self, db: Session) -> dict:
        """Shadow audit: risks that will matter when zone enforcement is on."""

        zones = {zone.id: zone for zone in db.query(NetworkZone).all()}
        groups = {group.id: group for group in db.query(DeviceGroup).all()}
        devices = db.query(NetworkDevice).all()
        memberships = db.query(GroupDevice).all()

        member_group = {
            row.device_id: row.group_id
            for row in memberships
        }

        zone_rules = (
            db.query(DeviceAccessRule)
            .filter(
                DeviceAccessRule.scope == "ZONE",
                DeviceAccessRule.enabled.is_(True),
                DeviceAccessRule.rule_type == "DOMAIN",
            )
            .all()
        )
        group_rules = (
            db.query(DeviceAccessRule)
            .filter(
                DeviceAccessRule.scope == "GROUP",
                DeviceAccessRule.enabled.is_(True),
                DeviceAccessRule.rule_type == "DOMAIN",
            )
            .all()
        )

        group_categories = {
            row.group_id
            for row in db.query(GroupCategory).all()
        }

        devices_by_group = {}
        devices_by_zone = {}

        for device in devices:
            group_id = member_group.get(device.id)

            if group_id is not None:
                devices_by_group.setdefault(group_id, []).append(device)

            if device.zone_id is not None:
                devices_by_zone.setdefault(device.zone_id, []).append(device)

        risks = []

        for group_id, members in devices_by_group.items():
            group = groups.get(group_id)

            if group is None:
                continue

            member_zones = sorted({
                device.zone_id for device in members
                if device.zone_id is not None
            })

            if len(member_zones) > 1:
                risks.append({
                    "severity": "warning",
                    "title": f"Grupo «{group.name}» cruza varias zonas",
                    "detail": (
                        "El DNS del grupo es compartido; dos equipos del mismo "
                        "grupo en zonas distintas no pueden tener políticas de "
                        "zona diferentes en la arquitectura actual."
                    ),
                    "link": "/policies",
                })

            has_group_policy = any(
                rule.group_id == group_id for rule in group_rules
            ) or group_id in group_categories

            if has_group_policy and member_zones:
                for zone_id in member_zones:
                    zone = zones.get(zone_id)

                    if zone is None:
                        continue

                    zone_specific = [
                        rule for rule in zone_rules if rule.zone_id == zone_id
                    ]

                    if zone_specific:
                        risks.append({
                            "severity": "warning",
                            "title": f"Grupo «{group.name}» y zona «{zone.name}» tienen reglas",
                            "detail": (
                                "El DNS de grupo no aplica hoy las reglas de la "
                                "zona. La política simulada puede no coincidir "
                                "con el bloqueo real."
                            ),
                            "link": "/policies",
                        })

        for device in devices:
            if device.zone_id is None:
                risks.append({
                    "severity": "warning",
                    "title": f"Equipo sin zona: {device.hostname or device.current_ip or device.id}",
                    "detail": "No hereda políticas de segmento.",
                    "link": "/network/devices",
                })

            if device.id not in member_group:
                risks.append({
                    "severity": "warning",
                    "title": f"Equipo sin grupo: {device.hostname or device.current_ip or device.id}",
                    "detail": "No hereda políticas de contenido.",
                    "link": "/groups",
                })

        zone_action = {
            (rule.zone_id, rule.value): rule.action
            for rule in zone_rules
        }
        group_action = {
            (rule.group_id, rule.value): rule.action
            for rule in group_rules
        }

        for (zone_id, domain), zone_act in zone_action.items():
            for (group_id, group_domain), group_act in group_action.items():
                if domain != group_domain or zone_act == group_act:
                    continue

                zone = zones.get(zone_id)
                group = groups.get(group_id)

                if not zone or not group:
                    continue

                risks.append({
                    "severity": "critical",
                    "title": f"Conflicto de política en {domain}",
                    "detail": (
                        f"Zona «{zone.name}» dice {zone_act}; grupo "
                        f"«{group.name}» dice {group_act}. Hoy el DNS de grupo "
                        "puede imponer una acción distinta."
                    ),
                    "link": "/policies",
                })

        unique = []
        seen = set()

        for risk in risks:
            key = (risk["severity"], risk["title"], risk["detail"])

            if key not in seen:
                seen.add(key)
                unique.append(risk)

        return {
            "count": len(unique),
            "critical": sum(1 for item in unique if item["severity"] == "critical"),
            "warning": sum(1 for item in unique if item["severity"] == "warning"),
            "risks": unique[:60],
        }

    def simulate(self, db: Session, device_id: int, domain: str) -> dict:
        device = db.query(NetworkDevice).filter(NetworkDevice.id == device_id).first()

        if device is None:
            return {"success": False, "message": "Equipo no encontrado."}

        domain = _normalize(domain)

        if not domain or "." not in domain:
            return {"success": False, "message": "Dominio inválido."}

        zone = (
            db.query(NetworkZone).filter(NetworkZone.id == device.zone_id).first()
            if device.zone_id is not None
            else None
        )
        membership = (
            db.query(GroupDevice)
            .filter(GroupDevice.device_id == device.id)
            .order_by(GroupDevice.id.asc())
            .first()
        )
        group = (
            db.query(DeviceGroup).filter(DeviceGroup.id == membership.group_id).first()
            if membership
            else None
        )

        schedules: dict = {}
        rules = (
            db.query(DeviceAccessRule)
            .filter(
                DeviceAccessRule.enabled.is_(True),
                DeviceAccessRule.rule_type == "DOMAIN",
            )
            .all()
        )
        matching = []

        for rule in rules:
            if not _domain_matches(domain, rule.value):
                continue

            if rule.scope == "GLOBAL":
                scope_match = True
            elif rule.scope == "ZONE":
                scope_match = bool(zone and rule.zone_id == zone.id)
            elif rule.scope == "GROUP":
                scope_match = bool(group and rule.group_id == group.id)
            elif rule.scope == "DEVICE":
                scope_match = rule.device_id == device.id
            else:
                scope_match = False

            if not scope_match:
                continue

            if not _active(rule, db, schedules):
                continue

            matching.append({
                "id": rule.id,
                "scope": _rule_label(rule),
                "action": rule.action.upper(),
                "domain": rule.value,
                "source": rule.source,
                "protected": bool(getattr(rule, "is_protected", False)),
                "permanent": bool(rule.is_permanent),
            })

        category_matches = self._category_matches(db, group, domain)

        recommended, reason = self._decision(matching, category_matches)
        current, current_reason = self._current_decision(
            matching,
            category_matches,
            group,
        )

        warnings = []

        if group and (zone or any(item["scope"] == "Equipo" for item in matching)):
            warnings.append(
                "La política de zona/equipo no se aplica actualmente al DNS "
                "de grupo; se muestra como recomendación."
            )

        return {
            "success": True,
            "device": {
                "id": device.id,
                "name": (
                    device.display_name
                    or device.hostname
                    or device.current_ip
                    or device.ip_address
                    or device.mac_address
                ),
                "ip": device.current_ip or device.ip_address,
            },
            "zone": (
                {"id": zone.id, "name": zone.name, "is_default": zone.is_default}
                if zone
                else None
            ),
            "group": (
                {"id": group.id, "name": group.name, "is_default": group.is_default}
                if group
                else None
            ),
            "domain": domain,
            "recommended_action": recommended,
            "recommended_reason": reason,
            "current_action": current,
            "current_reason": current_reason,
            "matches": matching,
            "category_matches": category_matches,
            "warnings": warnings,
        }

    def _category_matches(self, db: Session, group, domain: str) -> list[dict]:
        candidates = _suffixes(domain)

        category_ids = {
            row.id
            for row in db.query(ContentCategory)
            .filter(ContentCategory.enabled.is_(True))
            .all()
        }

        if group is not None:
            category_ids |= {
                row.category_id
                for row in db.query(GroupCategory)
                .filter(GroupCategory.group_id == group.id)
                .all()
            }

        if not category_ids or not candidates:
            return []

        rows = (
            db.query(CategoryDomain.domain, ContentCategory.key, ContentCategory.name)
            .join(ContentCategory, ContentCategory.id == CategoryDomain.category_id)
            .filter(
                CategoryDomain.category_id.in_(category_ids),
                CategoryDomain.domain.in_(candidates),
            )
            .all()
        )

        return [
            {
                "key": row[1],
                "name": row[2],
                "domain": row[0],
                "root": row[1] in ROOT_CATEGORY_KEYS,
            }
            for row in rows
        ]

    @staticmethod
    def _decision(matches: list[dict], categories: list[dict]) -> tuple[str, str]:
        if any(item["permanent"] and item["action"] == "BLOCK" for item in matches):
            return "BLOCK", "Bloqueo permanente de seguridad."

        if any(item["root"] for item in categories):
            return "BLOCK", "Categoría de seguridad de raíz."

        for scope in ("Equipo", "Grupo", "Zona"):
            scoped = [item for item in matches if item["scope"] == scope]

            if any(item["action"] == "BLOCK" for item in scoped):
                return "BLOCK", f"Regla de {scope.lower()}."

            if any(item["action"] == "ALLOW" for item in scoped):
                return "ALLOW", f"Permiso explícito de {scope.lower()}."

        if any(item["action"] == "BLOCK" for item in matches):
            return "BLOCK", "Regla global."

        if any(item["action"] == "ALLOW" for item in matches):
            return "ALLOW", "Permiso global."

        if categories:
            return "BLOCK", "Dominio incluido en una categoría activa."

        return "NO_RULE", "Sin regla específica."

    @staticmethod
    def _current_decision(matches: list[dict], categories: list[dict], group) -> tuple[str, str]:
        if any(item["permanent"] and item["action"] == "BLOCK" for item in matches):
            return "BLOCK", "Bloqueo permanente de seguridad."

        if any(item["root"] for item in categories):
            return "BLOCK", "Categoría de seguridad de raíz."

        if group is None:
            scoped = [item for item in matches if item["scope"] in ("Zona", "Global")]
            label = "Zona/global"
        else:
            scoped = [item for item in matches if item["scope"] in ("Grupo", "Global")]
            label = "Grupo/global (DNS de grupo)"

        if any(item["action"] == "BLOCK" for item in scoped):
            return "BLOCK", f"Regla {label}."

        if any(item["action"] == "ALLOW" for item in scoped):
            return "ALLOW", f"Permiso {label}."

        if categories:
            return "BLOCK", "Categoría aplicada por el DNS actual."

        return "NO_RULE", "Sin regla específica aplicada."


policy_service = PolicyService()
