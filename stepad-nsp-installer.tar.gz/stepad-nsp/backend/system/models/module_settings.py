from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class ModuleSetting(Base):

    __tablename__ = "module_settings"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    module_key: Mapped[str] = mapped_column(
        String(50),
        unique=True,
        nullable=False
    )


    # False = módulo desactivado para este cliente.
    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
