"""Registro de arranques del NSP (para distinguir reinicios propios de
caidas).

Se registra CADA arranque en el log de auditoria, diferenciando:

  - Reinicio del SERVICIO stepad-nsp (la maquina no se reinicio):
    boton "Reiniciar servicios". Accion SYSTEM_BOOT_SERVICE.
  - Arranque LIMPIO (apagado normal previo, marcador presente):
    accion SYSTEM_BOOT.
  - Reinicio BRUSCO (corte de energia, crash o apagado forzado, sin
    marcador): accion ABNORMAL_REBOOT + alerta.

El marcador lo escribe un servicio de systemd al apagarse de forma
normal (/etc/stepad/.clean_shutdown).
"""

import os
import time

from pathlib import Path

import psutil

from backend.core.database.session import SessionLocal
from backend.audit.services.audit_service import AuditService
from backend.alerts.services.alert_service import AlertService
from backend.shared.logging.logger import logger


MARKER = Path("/etc/stepad/.clean_shutdown")


class RebootTracker:

    @staticmethod
    def record_boot() -> dict:
        """Registra el tipo de arranque. Devuelve {'clean': True/False}."""

        db = SessionLocal()

        try:

            # Reinicio del SERVICIO (no de la maquina): la maquina lleva
            # arriba mas tiempo que el proceso del NSP.
            try:

                boot = psutil.boot_time()

                proc_start = psutil.Process(os.getpid()).create_time()

                if boot < proc_start - 180:

                    AuditService().create_log(
                        db,
                        user_id=None,
                        action="SYSTEM_BOOT_SERVICE",
                        resource="System",
                        description=(
                            "Reinicio del servicio stepad-nsp "
                            "(la maquina NO se reinicio)."
                        ),
                    )

                    logger.info(
                        "Arranque: reinicio del servicio "
                        "(la maquina no se reinicio)."
                    )

                    return {"clean": True, "service_restart": True}

            except Exception as error:

                logger.error(f"RebootTracker uptime check failed: {error}")

            if MARKER.exists():

                MARKER.unlink(missing_ok=True)

                AuditService().create_log(
                    db,
                    user_id=None,
                    action="SYSTEM_BOOT",
                    resource="System",
                    description=(
                        "Arranque limpio del NSP "
                        "(apagado normal previo)."
                    ),
                )

                logger.info(
                    "Ultimo apagado: limpio (marca de apagado presente)."
                )

                return {"clean": True}

            # Sin marca = reinicio brusco.
            try:

                AuditService().create_log(
                    db,
                    user_id=None,
                    action="ABNORMAL_REBOOT",
                    resource="System",
                    description=(
                        "REINICIO BRUSCO detectado (sin apagado limpio): "
                        "corte de energia, crash o apagado forzado."
                    ),
                )

            except Exception as error:

                logger.error(
                    f"No se pudo registrar el reinicio en auditoria: {error}"
                )

            try:

                AlertService().create(
                    db,
                    alert_type="system",
                    severity="warning",
                    title="Reinicio brusco detectado",
                    message=(
                        "El NSP arranco sin apagado limpio previo "
                        "(corte de energia o crash)."
                    ),
                )

            except Exception as error:

                logger.error(
                    f"No se pudo crear la alerta de reinicio: {error}"
                )

            logger.warning(
                "Reinicio brusco detectado (sin apagado limpio)."
            )

            return {"clean": False}

        finally:

            db.close()
