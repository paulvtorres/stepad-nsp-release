"""Deteccion de reinicios repentinos del NSP.

Tecnica del marcador de apagado limpio: un servicio de systemd escribe
/etc/stepad/.clean_shutdown cuando el sistema se apaga de forma normal
(ExecStop en shutdown.target/reboot.target). Al arrancar, si la marca
existe hubo apagado limpio; si falta, el equipo se reinicio de golpe
(corte de energia, crash o apagado forzado) y se registra en auditoria
y en el feed de alertas.
"""

from pathlib import Path

from backend.core.database.session import SessionLocal
from backend.audit.services.audit_service import AuditService
from backend.alerts.services.alert_service import AlertService
from backend.shared.logging.logger import logger


MARKER = Path("/etc/stepad/.clean_shutdown")


class RebootTracker:

    @staticmethod
    def record_boot() -> dict:
        """Registra el tipo de arranque. Devuelve {'clean': True/False}."""

        db = SessionLocal()

        try:

            if MARKER.exists():

                MARKER.unlink(missing_ok=True)

                logger.info(
                    "Ultimo apagado: limpio (marca de apagado presente)."
                )

                return {"clean": True}

            # Sin marca = reinicio repentino.
            try:

                AuditService().create_log(
                    db,
                    user_id=None,
                    action="ABNORMAL_REBOOT",
                    resource="System",
                    description=(
                        "Reinicio repentino detectado: la maquina no se "
                        "apago de forma limpia (corte de energia, crash "
                        "o apagado forzado)."
                    ),
                )

            except Exception as error:

                logger.error(
                    f"No se pudo registrar el reinicio en auditoria: {error}"
                )

            try:

                AlertService().create(
                    db,
                    alert_type="system",
                    severity="warning",
                    title="Reinicio repentino detectado",
                    message=(
                        "El NSP arranco sin apagado limpio previo "
                        "(corte de energia o crash)."
                    ),
                )

            except Exception as error:

                logger.error(
                    f"No se pudo crear la alerta de reinicio: {error}"
                )

            logger.warning(
                "Reinicio repentino detectado (sin apagado limpio)."
            )

            return {"clean": False}

        finally:

            db.close()
