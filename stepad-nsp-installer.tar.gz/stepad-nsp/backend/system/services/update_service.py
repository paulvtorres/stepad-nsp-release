import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import threading
import urllib.request

from pathlib import Path

from backend.shared.constants.app_version import (
    APP_VERSION,
    REPO_DIR,
)
from backend.shared.logging.logger import logger

UPDATE_SCRIPT = REPO_DIR / "update.sh"
RELEASE_REPO = "paulvtorres/stepad-nsp-release"
PUBLIC_KEY_PATH = REPO_DIR / "scripts" / "update-signing.pub.pem"


def _git(*args: str) -> str:

    try:

        result = subprocess.run(
            [
                "git", "-C", str(REPO_DIR),
                "-c", f"safe.directory={REPO_DIR}",
                *args,
            ],
            capture_output=True,
            text=True,
            timeout=15,
        )

        return result.stdout.strip()

    except Exception as error:
        logger.debug("update_service._git: %s", error)

        return ""


def _is_git_install() -> bool:

    return (REPO_DIR / ".git").exists()


def _installed_version() -> str:

    try:

        marker = Path("/etc/stepad/version")

        if marker.exists():

            value = marker.read_text().strip()

            if value:

                return value

    except Exception as error:
        logger.debug("update_service._installed_version: %s", error)
    return APP_VERSION


def _latest_release() -> dict:
    """
    Resuelve la última versión publicada en stepad-nsp-release/main.

    El flujo de producción sube manualmente stepad-nsp-installer.tar.gz
    al branch main (no GitHub Releases). get-stepad.sh y este servicio
    leen la misma URL.
    """

    version_url = (
        f"https://raw.githubusercontent.com/{RELEASE_REPO}/main/VERSION"
    )

    installer_url = (
        f"https://raw.githubusercontent.com/{RELEASE_REPO}/main/"
        "stepad-nsp-installer.tar.gz"
    )

    try:

        request = urllib.request.Request(
            version_url,
            headers={"User-Agent": "STEPAD-NSP/1.0"},
        )

        with urllib.request.urlopen(request, timeout=15) as response:

            tag = response.read().decode("utf-8", errors="ignore").strip()

        if not tag:

            return {}

        return {"tag": tag, "url": installer_url}

    except Exception as error:

        logger.warning(
            f"No se pudo consultar la versión en {RELEASE_REPO}/main: {error}"
        )

        return {}


def _normalize(version: str) -> str:

    return version.strip().lstrip("v")


def _verify_signature(archive: Path, signature: Path) -> bool:
    """Verifica la firma Ed25519 del instalador con la clave pública."""

    if not PUBLIC_KEY_PATH.exists():

        logger.error(
            f"Firma de actualización: falta la clave pública "
            f"{PUBLIC_KEY_PATH}."
        )

        return False

    try:

        result = subprocess.run(
            [
                "openssl", "pkeyutl", "-verify", "-pubin",
                "-inkey", str(PUBLIC_KEY_PATH), "-rawin",
                "-in", str(archive), "-sigfile", str(signature),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

    except Exception as error:

        logger.exception(
            f"Firma de actualización: error al verificar: {error}"
        )

        return False

    if result.returncode != 0:

        logger.error(
            "Firma de actualización INVÁLIDA: "
            f"{(result.stderr or result.stdout or '').strip()[:300]}"
        )

        return False

    return True


def update_status() -> dict:

    installed = _installed_version()

    git_mode = _is_git_install()

    if git_mode:

        try:

            subprocess.run(
                [
                    "git", "-C", str(REPO_DIR),
                    "-c", f"safe.directory={REPO_DIR}",
                    "fetch", "origin",
                ],
                capture_output=True,
                text=True,
                timeout=20,
            )

        except Exception as error:
            logger.debug("update_service.update_status: %s", error)
        head = _git("rev-parse", "HEAD")

        remote = _git("rev-parse", "origin/main")

        pending = []

        if head and remote and head != remote:

            log = _git(
                "log", "--oneline", "-30",
                f"{head}..origin/main",
            )

            for line in log.splitlines():

                line = line.strip()

                if not line:

                    continue

                parts = line.split(" ", 1)

                pending.append({
                    "commit": parts[0] if parts else "",
                    "message": parts[1] if len(parts) > 1 else "",
                })

        latest = _latest_release()

        return {
            "version": installed,
            "commit": head or "-",
            "remote_commit": remote or "-",
            "latest_version": latest.get("tag", ""),
            "update_available": bool(
                head and remote and head != remote
            ) or (
                latest.get("tag")
                and _normalize(installed) != _normalize(latest["tag"])
            ),
            "pending_commits": pending,
            "mode": "git",
        }

    # Instalación por paquete: comparar versión instalada vs última.
    latest = _latest_release()

    update_available = bool(
        latest.get("tag")
        and _normalize(installed) != _normalize(latest["tag"])
    )

    return {
        "version": installed,
        "commit": "-",
        "remote_commit": "-",
        "latest_version": latest.get("tag", ""),
        "update_available": update_available,
        "pending_commits": [],
        "mode": "package",
    }


def start_update() -> dict:

    def run():

        try:

            if _is_git_install():

                result = subprocess.run(
                    ["bash", UPDATE_SCRIPT],
                    capture_output=True,
                    text=True,
                    timeout=600,
                )

                if result.returncode != 0:

                    logger.error(
                        "update.sh falló "
                        f"(rc={result.returncode}): "
                        f"{(result.stderr or result.stdout or '').strip()[:500]}"
                    )

            else:

                _update_package()

        except Exception as error:

            logger.exception(f"Fallo la actualización: {error}")

    thread = threading.Thread(
        target=run,
        daemon=True,
        name="stepad-update",
    )

    thread.start()

    return {
        "success": True,
        "message": "Actualización iniciada en segundo plano.",
    }


def _update_package():

    """Actualización asistida para instalaciones por paquete."""

    try:

        info = _latest_release()

        if not info.get("url"):

            logger.error(
                "No se pudo resolver la última versión para actualizar."
            )
            return

        app_dir = Path.cwd()

        logger.info(f"Actualizando por paquete en {app_dir}...")

        archive = Path("/tmp/stepad-update.tar.gz")
        signature = Path("/tmp/stepad-update.tar.gz.sig")

        urllib.request.urlretrieve(info["url"], str(archive))
        urllib.request.urlretrieve(info["url"] + ".sig", str(signature))

        # Fail-closed: nunca ejecutar install.sh de un paquete sin firma.
        if not _verify_signature(archive, signature):

            logger.error(
                "Actualización RECHAZADA: el instalador no tiene una "
                "firma válida. No se modificó nada."
            )

            return

        extract_dir = "/tmp/stepad-update-pkg"

        shutil.rmtree(extract_dir, ignore_errors=True)

        extract_dir = Path(extract_dir)

        # filter="data" impide path traversal, rutas absolutas y
        # dispositivos especiales dentro del tarball.
        with tarfile.open(archive, "r:gz") as tar:

            tar.extractall(extract_dir, filter="data")

        pkg = (extract_dir / "stepad-nsp").resolve()

        if extract_dir.resolve() not in pkg.parents:

            logger.error(
                "Paquete de actualización inválido "
                "(ruta fuera del staging)."
            )

            return

        if not (pkg / "install.sh").exists():

            logger.error("Paquete de actualización inválido.")
            return

        # La config de red/DHCP es de esta máquina: el paquete trae un
        # config.yaml genérico. Sin este respaldo, copiar el paquete
        # encima pisaba WAN/LAN en cada update desde la UI.
        # Vive en /etc/stepad (fuera del repo); la ruta del repo se
        # conserva solo para instalaciones viejas.
        live_config = Path("/etc/stepad/config.yaml")
        legacy_config = (
            app_dir / "backend" / "shared" / "config" / "config.yaml"
        )

        if not live_config.exists() and legacy_config.exists():

            live_config = legacy_config

        config_backup = None

        if live_config.exists():

            fd, tmp_name = tempfile.mkstemp(
                prefix="stepad-config-",
                suffix=".yaml",
            )

            os.close(fd)

            config_backup = Path(tmp_name)

            shutil.copy2(live_config, config_backup)

        def restore_config():

            if config_backup is None or not config_backup.exists():

                return

            shutil.copy2(config_backup, live_config)

            try:

                os.chown(
                    live_config,
                    os.stat(app_dir).st_uid,
                    os.stat(app_dir).st_gid,
                )

            except OSError:

                pass

            config_backup.unlink(missing_ok=True)

            logger.info(
                "config.yaml de esta máquina restaurado tras el update."
            )

        # Sobrescribir el código nuevo sobre la carpeta actual de la app.
        try:

            for entry in pkg.iterdir():

                target = app_dir / entry.name

                if entry.is_dir():

                    shutil.copytree(entry, target, dirs_exist_ok=True)

                else:

                    shutil.copy2(entry, target)

        finally:

            # Aunque falle una copia a mitad de camino, la config de esta
            # máquina vuelve a quedar en su lugar antes de salir.
            restore_config()

        env = dict(os.environ)

        env["STEPAD_UPDATE"] = "1"

        subprocess.run(
            ["bash", str(app_dir / "install.sh")],
            env=env,
            timeout=900,
        )

    except Exception as error:

        logger.exception(
            f"Fallo la actualización por paquete: {error}"
        )