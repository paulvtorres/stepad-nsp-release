from pydantic import BaseModel


class WanMonitorSettingsRequest(BaseModel):

    enabled: bool | None = None

    interval_seconds: int | None = None

    ping_targets: str | None = None

    http_enabled: bool | None = None

    http_url: str | None = None

    alert_threshold: int | None = None

    retention_days: int | None = None
