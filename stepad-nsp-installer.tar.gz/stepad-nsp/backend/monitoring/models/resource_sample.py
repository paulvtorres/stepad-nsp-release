from sqlalchemy import DateTime, Float, Integer
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


class ResourceSample(Base):

    __tablename__ = "resource_samples"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    cpu_percent: Mapped[float] = mapped_column(Float, nullable=False)

    ram_percent: Mapped[float] = mapped_column(Float, nullable=False)

    disk_percent: Mapped[float] = mapped_column(Float, nullable=False)

    load_1: Mapped[float] = mapped_column(Float, nullable=False, default=0)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, nullable=False, index=True
    )
