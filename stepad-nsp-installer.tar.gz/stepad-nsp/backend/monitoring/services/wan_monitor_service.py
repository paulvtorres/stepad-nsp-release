import re
import subprocess
import threading
import time
import urllib.request

from datetime import datetime, timedelta

from pathlib import Path

from sqlalchemy import func
from sqlalchemy import delete as sa_delete
from sqlalchemy.orm import Session

from backend.monitoring.models.wan_monitor import (
    WanMonitorSettings,
    WanMonitorSample,
)
from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger

PING_BIN = "/bin/ping"
ETHTOOL_BIN = "/usr/sbin/ethtool"
NET_DEV = Path("/proc/net/dev")


class WanMonitorService:

    def __init__(self):

        self._scheduler_thread = None
        self._stop = False
        self._prev_counters: dict[str, tuple[int, int]] = {}
        self._fail_counts: dict[str, int] = {}
        self._alerted_down: set[str] = set()


    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self._get_or_create(db)

        return {
            "enabled": settings.enabled,
            "interval_seconds": settings.interval_seconds,
            "ping_targets": settings.ping_targets,
            "http_enabled": settings.http_enabled,
            "http_url": settings.http_url,
            "alert_threshold": settings.alert_threshold,
            "retention_days": settings.retention_days,
        }


    def save_settings(
        self,
        db: Session,
        request
    ) -> dict:

        settings = self._get_or_create(db)

        if request.enabled is not None:
            settings.enabled = request.enabled
        if request.interval_seconds is not None:
            settings.interval_seconds = max(
                15, min(3600, request.interval_seconds)
            )
        if request.ping_targets is not None:
            settings.ping_targets = request.ping_targets.strip()
        if request.http_enabled is not None:
            settings.http_enabled = request.http_enabled
        if request.http_url is not None:
            settings.http_url = request.http_url.strip()
        if request.alert_threshold is not None:
            settings.alert_threshold = max(
                1, min(60, request.alert_threshold)
            )
        if request.retention_days is not None:
            settings.retention_days = max(
                1, min(365, request.retention_days)
            )

        db.add(settings)
        db.commit()
        db.refresh(settings)

        return self.get_settings(db)


    # ------------------------------------------------------------------
    # Probes
    # ------------------------------------------------------------------

    def _get_wan_interfaces(self, db: Session) -> list[str]:

        try:

            from backend.network.interfaces.registry.models.managed_interface import (
                ManagedInterface,
            )

            rows = (
                db.query(ManagedInterface)
                .filter(
                    func.lower(ManagedInterface.role) == "wan"
                )
                .all()
            )

            names = []
            for row in rows:
                name = (row.last_seen_name or "").strip()
                if name:
                    names.append(name)

            return names

        except Exception as error:

            logger.warning(f"No se pudo leer interfaces WAN: {error}")
            return []


    def _probe_ping(self, target: str) -> dict:

        result = subprocess.run(
            [
                PING_BIN, "-c", "2", "-W", "1", target,
            ],
            capture_output=True,
            text=True,
            timeout=6
        )

        out = result.stdout

        loss = 100.0
        latency = None

        m = re.search(r"(\d+(?:\.\d+)?)% packet loss", out)
        if m:
            loss = float(m.group(1))

        m = re.search(
            r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)/",
            out,
        )
        if m:
            latency = float(m.group(1))

        ok = (loss < 100.0) and result.returncode == 0

        return {
            "ok": ok,
            "latency_ms": latency,
            "packet_loss": loss,
        }


    def _probe_http(self, url: str) -> bool:

        try:

            request = urllib.request.Request(
                url,
                headers={"User-Agent": "STEPAD-NSP/1.0"},
                method="GET",
            )

            with urllib.request.urlopen(request, timeout=6) as response:

                return response.status < 400

        except Exception:

            return False


    def _link_status(self, ifname: str) -> dict:

        speed = None
        up = False

        try:

            result = subprocess.run(
                [ETHTOOL_BIN, ifname],
                capture_output=True,
                text=True,
                timeout=6,
            )

            out = result.stdout

            m = re.search(r"Link detected:\s*(yes|no)", out)
            if m:
                up = m.group(1) == "yes"

            m = re.search(r"Speed:\s*(\d+)Mb/s", out)
            if m:
                speed = int(m.group(1))

        except Exception:

            pass

        if not up:

            # fallback: a real NIC reports "UP" from the kernel even
            # when ethtool is unavailable or misreports the carrier.
            try:

                result = subprocess.run(
                    ["ip", "-br", "link", "show", ifname],
                    capture_output=True,
                    text=True,
                    timeout=6,
                )

                out = result.stdout

                m = re.search(r"\s+(UP|DOWN)\s+", out)
                if m:
                    up = m.group(1) == "UP"

            except Exception:
                pass

        return {"up": up, "speed_mbps": speed}


    def _read_counters(self, ifname: str) -> tuple[int, int]:

        try:

            for line in NET_DEV.read_text().splitlines():

                if not line.strip().startswith(ifname + ":"):
                    continue

                parts = line.split(":")
                fields = parts[1].split()

                rx = int(fields[0])
                tx = int(fields[8])

                return rx, tx

        except Exception:
            pass

        return 0, 0


    # ------------------------------------------------------------------
    # Snapshot
    # ------------------------------------------------------------------

    def snapshot(self, db: Session) -> list[dict]:

        settings = self._get_or_create(db)

        targets = [
            t.strip()
            for t in settings.ping_targets.split(",")
            if t.strip()
        ]

        results = []

        for ifname in self._get_wan_interfaces(db):

            link = self._link_status(ifname)

            best_ping = {
                "ok": False,
                "latency_ms": None,
                "packet_loss": 100.0,
            }

            for target in targets:

                probe = self._probe_ping(target)

                if probe["ok"] and (
                    best_ping["latency_ms"] is None
                    or (
                        probe["latency_ms"] is not None
                        and probe["latency_ms"] < best_ping["latency_ms"]
                    )
                ):
                    best_ping = probe

                if probe["ok"] and not best_ping["ok"]:
                    best_ping = probe

            if not best_ping["ok"] and targets:
                best_ping["packet_loss"] = 100.0

            http_ok = (
                self._probe_http(settings.http_url)
                if settings.http_enabled
                else None
            )

            rx, tx = self._read_counters(ifname)

            prev = self._prev_counters.get(ifname)

            if prev is not None:

                if rx < prev[0]:
                    prev = (0, 0)
                if tx < prev[1]:
                    prev = (0, 0)

                interval = max(1, settings.interval_seconds)

                rx_rate = (rx - prev[0]) * 8 / interval
                tx_rate = (tx - prev[1]) * 8 / interval

            else:

                rx_rate = 0.0
                tx_rate = 0.0

            self._prev_counters[ifname] = (rx, tx)

            sample = WanMonitorSample(
                interface=ifname,
                timestamp=datetime.utcnow(),
                link_up=link["up"],
                link_speed_mbps=link["speed_mbps"],
                ping_ok=best_ping["ok"],
                latency_ms=best_ping["latency_ms"],
                packet_loss=best_ping["packet_loss"],
                http_ok=http_ok,
                rx_bps=rx_rate,
                tx_bps=tx_rate,
            )

            db.add(sample)
            db.commit()

            self._evaluate(sample, db)

            results.append(self._serialize(sample))

        self._prune(db, settings.retention_days)

        return results


    def _evaluate(self, sample: WanMonitorSample, db: Session):

        up = sample.link_up and sample.ping_ok and (
            sample.http_ok is not False
        )

        key = sample.interface

        if up:

            self._fail_counts[key] = 0

            if key in self._alerted_down:

                self._alerted_down.discard(key)
                self._notify(
                    "Internet restaurado",
                    f"El servicio de internet en {key} volvió a estar "
                    f"operativo ({self._fmt_latency(sample)})."
                )

            return

        self._fail_counts[key] = self._fail_counts.get(key, 0) + 1

        settings = self._get_or_create(db)

        if (
            key not in self._alerted_down
            and self._fail_counts[key] >= settings.alert_threshold
        ):

            self._alerted_down.add(key)

            self._notify(
                "FALLO de internet (WAN)",
                f"Se perdió el servicio de internet en la interfaz "
                f"{key}. "
                f"Enlace: {'OK' if sample.link_up else 'CAÍDO'}, "
                f"ping: {'OK' if sample.ping_ok else 'fallando'}, "
                f"http: {sample.http_ok}."
            )


    def _notify(self, subject: str, body: str):

        try:

            from backend.notifications.services.email_service import (
                EmailService,
            )
            from backend.notifications.repositories.notification_settings_repository import (
                NotificationSettingsRepository,
            )

            db = SessionLocal()

            try:

                settings = NotificationSettingsRepository().get(db)

                if settings:

                    EmailService().send_html(
                        settings,
                        f"STEPAD NSP - {subject}",
                        f"<p>{body}</p>",
                    )

            finally:

                db.close()

        except Exception as error:

            logger.error(f"No se pudo notificar monitoreo WAN: {error}")


    # ------------------------------------------------------------------
    # Queries for the dashboard
    # ------------------------------------------------------------------

    def get_status(self, db: Session) -> dict:

        interfaces = self._get_wan_interfaces(db)

        latest = {}

        for ifname in interfaces:

            sample = (
                db.query(WanMonitorSample)
                .filter(WanMonitorSample.interface == ifname)
                .order_by(WanMonitorSample.timestamp.desc())
                .first()
            )

            latest[ifname] = self._serialize(sample) if sample else None

        return {
            "interfaces": latest,
            "settings": self.get_settings(db),
        }


    def get_history(
        self,
        db: Session,
        hours: int = 24,
    ) -> dict:

        start = datetime.utcnow() - timedelta(hours=hours)

        interfaces = self._get_wan_interfaces(db)

        series = {}

        for ifname in interfaces:

            rows = (
                db.query(WanMonitorSample)
                .filter(
                    WanMonitorSample.interface == ifname,
                    WanMonitorSample.timestamp >= start,
                )
                .order_by(WanMonitorSample.timestamp)
                .all()
            )

            series[ifname] = [
                {
                    "t": row.timestamp.isoformat(),
                    "latency_ms": row.latency_ms,
                    "packet_loss": row.packet_loss,
                    "rx_bps": row.rx_bps,
                    "tx_bps": row.tx_bps,
                    "up": row.link_up and row.ping_ok,
                }
                for row in rows
            ]

        return series


    def _serialize(self, sample: WanMonitorSample) -> dict:

        return {
            "interface": sample.interface,
            "timestamp": sample.timestamp.isoformat(),
            "link_up": sample.link_up,
            "link_speed_mbps": sample.link_speed_mbps,
            "ping_ok": sample.ping_ok,
            "latency_ms": sample.latency_ms,
            "packet_loss": sample.packet_loss,
            "http_ok": sample.http_ok,
            "rx_bps": sample.rx_bps,
            "tx_bps": sample.tx_bps,
        }


    def _fmt_latency(self, sample: WanMonitorSample) -> str:

        if sample.latency_ms is None:
            return "latencia no disponible"

        return f"latencia {sample.latency_ms:.0f} ms"


    def _prune(self, db: Session, retention_days: int):

        cutoff = datetime.utcnow() - timedelta(days=retention_days)

        db.execute(
            sa_delete(WanMonitorSample).where(
                WanMonitorSample.timestamp < cutoff
            )
        )

        db.commit()


    # ------------------------------------------------------------------
    # Scheduler
    # ------------------------------------------------------------------

    def _scheduler_loop(self):

        logger.info("WAN monitor scheduler started.")

        while not self._stop:

            db = SessionLocal()

            try:

                settings = self._get_or_create(db)

                if settings.enabled:

                    self.snapshot(db)

            except Exception as error:

                logger.exception(f"WAN monitor error: {error}")

            finally:

                db.close()

            interval = self._safe_interval()

            for _ in range(interval):
                if self._stop:
                    break
                time.sleep(1)


    def _safe_interval(self) -> int:

        db = SessionLocal()

        try:

            settings = self._get_or_create(db)

            return max(15, settings.interval_seconds)

        finally:

            db.close()


    def start_scheduler(self):

        if self._scheduler_thread is not None:
            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="wan-monitor-scheduler",
        )

        self._scheduler_thread.start()


    def stop(self):

        self._stop = True


    def _get_or_create(self, db: Session) -> WanMonitorSettings:

        settings = db.query(WanMonitorSettings).first()

        if settings is None:

            settings = WanMonitorSettings()
            db.add(settings)
            db.commit()
            db.refresh(settings)

        return settings

