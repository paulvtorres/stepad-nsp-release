import os
import time

from pathlib import Path

import psutil

from backend.shared.logging.logger import logger


class MonitoringService:

    def snapshot(
        self
    ) -> dict:

        cpu = psutil.cpu_percent(interval=0.5)

        memory = psutil.virtual_memory()

        disk = psutil.disk_usage("/")

        uptime = time.time() - psutil.boot_time()

        return {
            "cpu_percent": round(cpu, 1),
            "ram_percent": round(memory.percent, 1),
            "ram_used": memory.used,
            "ram_total": memory.total,
            "ram_available": memory.available,
            "cpu_cores": psutil.cpu_count(logical=True) or 1,
            "disk_percent": round(disk.percent, 1),
            "disk_used": disk.used,
            "disk_total": disk.total,
            "uptime_seconds": int(uptime),
            "load_avg": [round(x, 2) for x in os.getloadavg()],
            "temperature_c": self._temperature()
        }

    def top_processes(self, limit: int = 5) -> list[dict]:
        """Procesos con más CPU, para explicar una alerta."""

        import subprocess

        try:
            result = subprocess.run(
                [
                    "ps", "-eo", "pid,pcpu,pmem,comm",
                    "--sort=-pcpu", "--no-headers",
                ],
                capture_output=True,
                text=True,
                timeout=3,
            )
            rows = []
            for line in result.stdout.splitlines()[:max(1, int(limit))]:
                parts = line.split(None, 3)
                if len(parts) < 4:
                    continue
                rows.append({
                    "pid": int(parts[0]),
                    "cpu": float(parts[1]),
                    "mem": float(parts[2]),
                    "name": parts[3].strip(),
                })
            return rows
        except (OSError, ValueError, subprocess.SubprocessError):
            return []

    def _temperature(self) -> float | None:

        try:

            for path in Path("/sys/class/thermal").glob("thermal_zone*/temp"):

                raw = path.read_text().strip()

                if raw.isdigit():

                    return round(int(raw) / 1000, 1)

        except Exception as error:
            logger.debug("monitoring_service._temperature: %s", error)
        return None