import os
import time

from pathlib import Path

import psutil


class MonitoringService:

    def snapshot(
        self
    ) -> dict:

        cpu = psutil.cpu_percent(interval=0.5)

        memory = psutil.virtual_memory()

        disk = psutil.disk_usage("/")

        uptime = time.time() - psutil.boot_time()

        return {
            "cpu_percent": round(cpu, 1),
            "ram_percent": round(memory.percent, 1),
            "ram_used": memory.used,
            "ram_total": memory.total,
            "disk_percent": round(disk.percent, 1),
            "disk_used": disk.used,
            "disk_total": disk.total,
            "uptime_seconds": int(uptime),
            "load_avg": [round(x, 2) for x in os.getloadavg()],
            "temperature_c": self._temperature()
        }

    def _temperature(self) -> float | None:

        try:

            for path in Path("/sys/class/thermal").glob("thermal_zone*/temp"):

                raw = path.read_text().strip()

                if raw.isdigit():

                    return round(int(raw) / 1000, 1)

        except Exception:

            pass

        return None
