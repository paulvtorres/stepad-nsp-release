import threading
import time

from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.database.session import SessionLocal

from backend.shared.runtime import runtime

from backend.alerts.services.alert_service import AlertService
from backend.monitoring.services.monitoring_service import MonitoringService
from backend.monitoring.services.wan_monitor_service import WanMonitorService

from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.network.devices.models.network_device import NetworkDevice

from backend.shared.logging.logger import logger


class MonitoringComponent(BaseComponent):

    name = "monitoring"

    criticality = ComponentCriticality.IMPORTANT

    BLOCKED_SPIKE_THRESHOLD = 50

    NEW_DEVICE_WINDOW_MINUTES = 10


    def __init__(self):

        self.monitoring = MonitoringService()

        self.alert_service = AlertService()

        self._thread = None

        self._stop = False

        self._started_at = None

        # cooldown: key -> last alert timestamp. Cleared when the
        # condition resolves so a new occurrence alerts again.
        self._cooldown = {}

    def _should_alert(
        self,
        key: str,
        cooldown_seconds: int = 0
    ) -> bool:

        last = self._cooldown.get(key)

        if last is None:

            return True

        return (time.time() - last) >= cooldown_seconds

    def _mark(
        self,
        key: str
    ):

        self._cooldown[key] = time.time()

    def _clear(
        self,
        key: str
    ):

        self._cooldown.pop(key, None)

    def _check_resources(
        self,
        db: Session
    ):

        snap = self.monitoring.snapshot()

        for key, threshold, alert_type, severity, title in [
            ("cpu", 90, "RESOURCE_CPU", "critical",
             f"CPU al {snap['cpu_percent']}%"),
            ("ram", 90, "RESOURCE_RAM", "critical",
             f"Memoria al {snap['ram_percent']}%"),
            ("disk", 90, "RESOURCE_DISK", "warning",
             f"Disco al {snap['disk_percent']}%"),
        ]:

            value = {
                "cpu": snap["cpu_percent"],
                "ram": snap["ram_percent"],
                "disk": snap["disk_percent"],
            }[key]

            ckey = f"resource-{key}"

            if value >= threshold:

                if self._should_alert(ckey, 1800):

                    self.alert_service.create(
                        db,
                        alert_type,
                        severity,
                        title,
                        f"Umbral superado: {title}. "
                        f"Carga: {snap['load_avg']}."
                    )

                    self._mark(ckey)

            else:

                self._clear(ckey)

    def _check_blocked_spike(
        self,
        db: Session
    ):

        since = datetime.utcnow() - timedelta(minutes=5)

        count = (
            db.query(DnsQueryLog.id)
            .filter(
                DnsQueryLog.blocked.is_(True),
                DnsQueryLog.queried_at >= since
            )
            .count()
        )

        if count >= self.BLOCKED_SPIKE_THRESHOLD:

            if self._should_alert("blocked-spike", 1800):

                self.alert_service.create(
                    db,
                    "BLOCKED_SPIKE",
                    "warning",
                    f"{count} consultas bloqueadas en los últimos 5 minutos",
                    "Posible intento de acceso a sitios bloqueados."
                )

                self._mark("blocked-spike")

    def _check_new_devices(
        self,
        db: Session
    ):

        since = datetime.utcnow() - timedelta(
            minutes=self.NEW_DEVICE_WINDOW_MINUTES
        )

        devices = (
            db.query(NetworkDevice)
            .filter(NetworkDevice.first_seen >= since)
            .all()
        )

        for device in devices:

            key = f"new-device-{device.id}"

            if self._should_alert(key):

                self.alert_service.create(
                    db,
                    "NEW_DEVICE",
                    "info",
                    f"Nuevo dispositivo: "
                    f"{device.hostname or device.mac_address or device.ip_address}",
                    (
                        f"Se conectó un dispositivo nuevo "
                        f"({device.ip_address or 'sin IP'})"
                    )
                )

                self._mark(key)

    def _check_components(
        self,
        db: Session
    ):

        # Gracia de arranque: no alertar por componentes "no activos"
        # durante el boot (aun estan levantandose).
        started = getattr(self, "_started_at", None)

        if started and (time.time() - started) < 180:

            return

        states = runtime.all()

        for name, state in states.items():

            key = f"component-{name}"

            if state.get("status") != "running":

                if self._should_alert(key, 1800):

                    self.alert_service.create(
                        db,
                        "COMPONENT_DOWN",
                        "critical",
                        f"Componente {name} no está activo",
                        state.get("error") or "El componente no está en ejecución."
                    )

                    self._mark(key)

            else:

                self._clear(key)

    def _scan(
        self
    ):

        db = SessionLocal()

        try:

            self._check_resources(db)

            self._check_blocked_spike(db)

            self._check_new_devices(db)

            self._check_components(db)

            # Descubrimiento periodico de dispositivos: mantiene el
            # estado ONLINE/OFFLINE actualizado sin tener que pulsar
            # "Escanear red" (cada ~5 min, con el barrido de subred).
            self._discovery_counter = getattr(
                self, "_discovery_counter", 0
            ) + 1

            if self._discovery_counter >= 10:

                self._discovery_counter = 0

                try:

                    from backend.network.devices.services.device_discovery_service import (
                        DeviceDiscoveryService
                    )

                    DeviceDiscoveryService().synchronize(db)

                except Exception as error:

                    logger.warning(
                        f"Discovery periodico fallo: {error}"
                    )

        except Exception as error:

            logger.exception(f"Monitoring scan error: {error}")

        finally:

            db.close()

    def _loop(
        self
    ):

        logger.info("Monitoring component started.")

        while not self._stop:

            try:

                self._scan()

            except Exception:

                pass

            time.sleep(30)

    def start(self):

        logger.info("MonitoringComponent started.")

        # Periodo de gracia al arranque: durante los primeros minutos el
        # sistema sigue levantando componentes (api/content arrancan al
        # final) y NO deben generarse alertas falsas COMPONENT_DOWN.
        self._started_at = time.time()

        self._thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name="monitoring-scanner"
        )

        self._thread.start()

        self.wan_monitor = WanMonitorService()
        self.wan_monitor.start_scheduler()

    def stop(self):

        self._stop = True

        logger.info("MonitoringComponent stopped.")
