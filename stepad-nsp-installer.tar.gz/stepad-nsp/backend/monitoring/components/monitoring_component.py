import threading
import time

from collections import deque

from datetime import datetime, timedelta
from backend.shared.datetime_utils import utcnow

from sqlalchemy import func
from sqlalchemy.orm import Session

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.database.session import SessionLocal

from backend.shared.runtime import runtime

from backend.alerts.models.alert import Alert
from backend.alerts.services.alert_service import AlertService
from backend.monitoring.services.monitoring_service import MonitoringService
from backend.monitoring.services.wan_monitor_service import WanMonitorService
from backend.monitoring.services.security_dns_alert_service import (
    SecurityDnsAlertService
)

from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.utils.mac import is_locally_administered

from backend.shared.logging.logger import logger


class MonitoringComponent(BaseComponent):

    name = "monitoring"

    criticality = ComponentCriticality.IMPORTANT

    BLOCKED_SPIKE_THRESHOLD = 200

    NEW_DEVICE_WINDOW_MINUTES = 10

    # Nombres legibles para las alertas de salud de red, en lugar del
    # código interno (p.ej. "suricata" o "zones_dns").
    NAV_LABELS = {
        "internet": "salida a Internet",
        "dhcp": "servidor DHCP",
        "dns": "resolución de nombres (DNS)",
        "log_listener": "registro de navegación",
        "forwarding": "enrutamiento hacia Internet (NAT)",
        "suricata": "protección de intrusos (IPS)",
        "disk": "espacio en disco",
        "zones_dns": "DNS de las zonas de red",
        "conflicto": "conflictos de direcciones de red",
        "postgres": "base de datos PostgreSQL",
        "tailscale": "acceso remoto Tailscale",
    }


    def __init__(self):

        self.monitoring = MonitoringService()

        self.alert_service = AlertService()

        self.security_dns_alerts = SecurityDnsAlertService()

        from backend.config_revisions.services.golden_config_service import (
            golden_config_service,
        )
        self.golden_config = golden_config_service

        from backend.dns.services.dns_threat_detection_service import (
            dns_threat_detection_service,
        )
        self.dns_threats = dns_threat_detection_service

        self._thread = None

        self._stop = False

        self._started_at = None

        # cooldown: key -> last alert timestamp. Cleared when the
        # condition resolves so a new occurrence alerts again.
        self._cooldown = {}

        # Ventana de capacidad: 30 muestras cada ~30 s; se exige que
        # haya al menos 20 (~10 min) para alertar por CPU/RAM.
        # Se redimensiona según la ventana configurada (máx. 60 min).
        self._resource_samples = {
            "cpu": deque(maxlen=120),
            "ram": deque(maxlen=120),
            "disk": deque(maxlen=120),
        }

    @staticmethod
    def _p95(values):

        ordered = sorted(values)

        if not ordered:

            return 0.0

        index = min(
            len(ordered) - 1,
            max(0, int(round(len(ordered) * 0.95)) - 1),
        )

        return ordered[index]

    def _should_alert(
        self,
        key: str,
        cooldown_seconds: int = 0
    ) -> bool:

        last = self._cooldown.get(key)

        if last is None:

            return True

        return (time.time() - last) >= cooldown_seconds

    def _mark(
        self,
        key: str
    ):

        self._cooldown[key] = time.time()

    def _clear(
        self,
        key: str
    ):

        self._cooldown.pop(key, None)

    def _check_resources(
        self,
        db: Session
    ):

        snap = self.monitoring.snapshot()

        try:

            from backend.shared.config.config_service import ConfigService

            settings = ConfigService().get().get("monitoring", {}) or {}

        except Exception:

            settings = {}

        window_minutes = max(1, min(60, int(settings.get("window_minutes", 10) or 10)))
        required_samples = max(1, window_minutes * 2)
        disk_free_min_gb = max(0, float(settings.get("disk_free_min_gb", 5) or 5))

        for key, threshold, alert_type, severity, title in [
            ("cpu", int(settings.get("cpu_threshold", 90) or 90), "RESOURCE_CPU", "critical", "CPU alta"),
            ("ram", int(settings.get("ram_threshold", 90) or 90), "RESOURCE_RAM", "critical", "Memoria alta"),
            ("disk", int(settings.get("disk_threshold", 90) or 90), "RESOURCE_DISK", "warning", "Disco alto"),
        ]:

            value = {
                "cpu": snap["cpu_percent"],
                "ram": snap["ram_percent"],
                "disk": snap["disk_percent"],
            }[key]

            samples = self._resource_samples[key]
            samples.append(value)

            try:

                from backend.monitoring.models.resource_sample import (
                    ResourceSample,
                )

                if db is not None and key == "cpu":

                    db.add(
                        ResourceSample(
                            cpu_percent=float(snap["cpu_percent"]),
                            ram_percent=float(snap["ram_percent"]),
                            disk_percent=float(snap["disk_percent"]),
                            load_1=float((snap.get("load_avg") or [0])[0]),
                        )
                    )
                    db.commit()

            except Exception as error:

                logger.debug("monitoring: no se guardó muestra: %s", error)

            # CPU/RAM: capacidad sostenida, no picos. Con 10 muestras
            # (~5 min) ya se puede estimar; el p95 exige que el consumo
            # alto se mantenga.
            measured = (
                self._p95(samples)
                if key in ("cpu", "ram") and len(samples) >= required_samples
                else value
            )

            ckey = f"resource-{key}"

            capacity_exceeded = measured >= threshold

            if key == "disk":

                capacity_exceeded = (
                    measured >= threshold
                    or float(snap.get("disk_free_gb", 999999)) <= disk_free_min_gb
                )

            if capacity_exceeded:

                if self._should_alert(ckey, 1800):

                    if key == "cpu":

                        detail = (
                            f"Capacidad sostenida: CPU p95 {measured}% "
                            "en la ventana reciente. "
                            f"Carga: {snap['load_avg']} "
                            f"({snap['cpu_cores']} núcleos). "
                            "Procesos con más CPU: "
                            + ", ".join(
                                f"{item['name']} ({item['cpu']}%)"
                                for item in self.monitoring.top_processes()
                            )
                            + ". Si se mantiene, el hardware puede no "
                            "alcanzar para la carga actual."
                        )

                    elif key == "ram":

                        detail = (
                            f"Capacidad sostenida: memoria p95 {measured}% "
                            "en la ventana reciente. "
                            f"Disponible: {snap['ram_available']} bytes; "
                            f"swap: {snap.get('swap_percent', 0)}%. "
                            "Si hay swap alto o el sistema se vuelve lento, "
                            "el hardware puede no alcanzar."
                        )

                    else:

                        detail = (
                            f"Disco al {value}% "
                            f"({snap.get('disk_free_gb', '?')} GB libres). "
                            "Liberar espacio, mover respaldos o ampliar disco."
                        )

                    self.alert_service.create(
                        db,
                        alert_type,
                        severity,
                        title,
                        detail,
                    )

                    self._mark(ckey)

            else:

                self._clear(ckey)
                self.alert_service.resolve(db, alert_type, title)

    def _check_blocked_spike(
        self,
        db: Session
    ):

        since = utcnow() - timedelta(minutes=5)

        count = (
            db.query(DnsQueryLog.id)
            .filter(
                DnsQueryLog.blocked.is_(True),
                DnsQueryLog.queried_at >= since
            )
            .count()
        )

        if count >= self.BLOCKED_SPIKE_THRESHOLD:

            if self._should_alert("blocked-spike", 3600):

                self.alert_service.create(
                    db,
                    "BLOCKED_SPIKE",
                    "warning",
                    f"{count} consultas bloqueadas en los últimos 5 minutos",
                    "Posible intento de acceso a sitios bloqueados."
                )

                self._mark("blocked-spike")

    def _check_new_devices(
        self,
        db: Session
    ):

        since = utcnow() - timedelta(
            minutes=self.NEW_DEVICE_WINDOW_MINUTES
        )

        devices = (
            db.query(NetworkDevice)
            .filter(NetworkDevice.first_seen >= since)
            .all()
        )

        for device in devices:

            # A randomized MAC (phone privacy) changes on every
            # conexion: alertar por el generaria un "nuevo dispositivo"
            # day for the same phone. It is not stable inventory.
            if is_locally_administered(device.mac_address):

                continue

            key = f"new-device-{device.id}"

            title = (
                f"Nuevo dispositivo: "
                f"{device.hostname or device.mac_address or device.ip_address}"
            )

            # Una sola alerta por dispositivo al día. Sin esto, mientras
            # first_seen permanece en la ventana de 10 minutos el escaneo
            # (cada 30s) volvía a alertar y llenaba el panel de INFO.
            already = (
                db.query(Alert.id)
                .filter(
                    Alert.alert_type == "NEW_DEVICE",
                    Alert.title == title,
                    Alert.created_at >= utcnow() - timedelta(hours=24),
                )
                .first()
            )

            if already:
                continue

            if self._should_alert(key):

                self.alert_service.create(
                    db,
                    "NEW_DEVICE",
                    "info",
                    title,
                    (
                        f"Se conectó un dispositivo nuevo "
                        f"({device.ip_address or 'sin IP'})"
                    )
                )

                self._mark(key)

    def _check_components(
        self,
        db: Session
    ):

        # Gracia de arranque: no alertar por componentes "no activos"
        # durante el boot (aun estan levantandose).
        started = getattr(self, "_started_at", None)

        # 5 min de gracia: el arranque completo (incluida la API) puede
        # tardar varios minutos y no es una falla.
        if started and (time.time() - started) < 300:

            return

        states = runtime.all()

        streaks = getattr(self, "_down_streaks", None)

        if streaks is None:

            streaks = {}

            self._down_streaks = streaks

        for name, state in states.items():

            key = f"component-{name}"

            status = state.get("status")

            if status in ("starting", "stopping"):

                continue

            if status != "running":

                # Debe seguir caido en el siguiente chequeo (60 s) para
                # alertar: evita alertas por reinicios/transiciones.
                streaks[key] = streaks.get(key, 0) + 1

                if streaks[key] < 2:

                    continue

                if self._should_alert(key, 1800):

                    self.alert_service.create(
                        db,
                        "COMPONENT_DOWN",
                        "critical",
                        f"Componente {name} no está activo",
                        state.get("error") or "El componente no está en ejecución."
                    )

                    self._mark(key)

            else:

                streaks.pop(key, None)

                self._clear(key)

    def _check_dhcp(
        self,
        db: Session,
    ):

        started = getattr(self, "_started_at", None)

        if started and (time.time() - started) < 180:

            return

        try:

            from backend.dhcp.services.dhcp_health_service import (
                DhcpHealthService,
            )

            health = getattr(self, "_dhcp_health", None)

            if health is None:

                health = DhcpHealthService()

                self._dhcp_health = health

            health.ensure_healthy(db)

        except Exception as error:

            logger.warning("Chequeo DHCP fallo: %s", error)

    def _check_static_ips(
        self,
        db: Session
    ):

        now = time.monotonic()

        if now - getattr(self, "_static_check_at", 0) < 600:

            return

        self._static_check_at = now

        try:

            from backend.dhcp.services.dhcp_pool_stats_service import (
                DhcpPoolStatsService,
            )

            stats = DhcpPoolStatsService().get_stats()

        except Exception as error:

            logger.warning(f"Static IP check failed: {error}")

            return

        for item in stats.get("static_in_pool", []) or []:

            key = f"static-in-pool-{item.get('ip')}"

            if not self._should_alert(key, 86400):

                continue

            label = item.get("hostname") or item.get("mac") or item.get("ip")

            self.alert_service.create(
                db,
                "DHCP_STATIC_IN_POOL",
                "warning",
                f"IP fija dentro del pool: {item.get('ip')}",
                f"«{label}» usa {item.get('ip')} dentro del rango DHCP sin "
                "reserva; puede chocar con una asignación automática. "
                "Cambiá la IP del equipo, excluila del pool o creá una reserva.",
            )

            self._mark(key)

    def _check_share_space(
        self,
        db: Session
    ):

        now = time.monotonic()

        if now - getattr(self, "_share_space_at", 0) < 1800:

            return

        self._share_space_at = now

        try:

            import os
            import shutil

            from pathlib import Path

            bases = (
                Path("/mnt/stepad-network"),
                Path("/mnt/stepad-share"),
            )

            for base in bases:

                if not base.is_dir():

                    continue

                for mount in base.iterdir():

                    if not os.path.ismount(mount):

                        continue

                    try:

                        usage = shutil.disk_usage(mount)

                    except OSError:

                        continue

                    percent = round(usage.used * 100 / usage.total)

                    key = f"share-space-{mount}"

                    if percent >= 85:

                        if self._should_alert(key, 86400):

                            free_gb = round(usage.free / (1024 ** 3), 1)

                            self.alert_service.create(
                                db,
                                "SHARE_DISK_HEALTH",
                                "warning",
                                f"Recurso casi lleno: {mount}",
                                f"{percent}% usado · {free_gb} GB libres. "
                                "Liberar espacio para no cortar respaldos.",
                            )

                            self._mark(key)

                    else:

                        self._clear(key)

        except Exception as error:

            logger.warning(f"Share space check failed: {error}")

    @staticmethod
    def ssh_exposure(
        wan_addresses,
        listen_addresses,
    ) -> list:

        """Listening addresses that expose SSH to the WAN or all networks."""

        exposed = []

        for address in listen_addresses:

            if address in ("0.0.0.0", "::", "*", "[::]"):

                exposed.append(address)

            elif address in wan_addresses:

                exposed.append(address)

        return exposed

    def _check_ssh_security(
        self,
        db: Session
    ):

        now = time.monotonic()

        if now - getattr(self, "_ssh_check_at", 0) < 600:

            return

        self._ssh_check_at = now

        try:

            import subprocess

            from backend.shared.config.config_loader import config

            network = config.get("network") or {}

            wan = (
                network.get("wan_interface")
                or config.get("wan_interface")
                or ""
            ).strip()

            wan_addresses = set()

            if wan:

                out = subprocess.run(
                    ["ip", "-o", "-4", "addr", "show", "dev", wan],
                    capture_output=True,
                    text=True,
                    timeout=10,
                ).stdout

                for line in out.splitlines():

                    parts = line.split()

                    if len(parts) >= 4:

                        wan_addresses.add(parts[3].split("/")[0])

            listeners = subprocess.run(
                ["ss", "-ltn"],
                capture_output=True,
                text=True,
                timeout=10,
            ).stdout

            ssh_listen = []

            for line in listeners.splitlines():

                parts = line.split()

                if len(parts) < 4 or not parts[3].endswith(":22"):

                    continue

                address = parts[3].rsplit(":", 1)[0]

                ssh_listen.append(
                    address.strip("[]") if address.startswith("[") else address
                )

            # With ListenAddress set to real IPs, "0.0.0.0" disappears.
            exposed = self.ssh_exposure(wan_addresses, ssh_listen)

            if exposed:

                if self._should_alert("ssh-exposed", 6 * 3600):

                    self.alert_service.create(
                        db,
                        "SSH_EXPOSED_WAN",
                        "critical",
                        "SSH expuesto en la WAN",
                        "sshd escucha en "
                        + ", ".join(sorted(set(exposed)))
                        + ". Restringilo a LAN/Tailscale.",
                    )

                    self._mark("ssh-exposed")

            else:

                self._clear("ssh-exposed")

            # Weak posture: password auth enabled (recommend SSH keys).
            try:

                effective = subprocess.run(
                    ["sshd", "-T"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                ).stdout

                password_auth = "passwordauthentication yes" in effective.lower()
                root_login = "permitrootlogin yes" in effective.lower()

            except Exception:

                password_auth = False
                root_login = False

            if password_auth or root_login:

                if self._should_alert("ssh-password-auth", 7 * 86400):

                    self.alert_service.create(
                        db,
                        "SSH_PASSWORD_AUTH",
                        "critical",
                        "SSH con contraseña habilitada",
                        "Se recomienda migrar a claves SSH y deshabilitar "
                        "PasswordAuthentication (y PermitRootLogin).",
                    )

                    self._mark("ssh-password-auth")

        except Exception as error:

            logger.warning(f"SSH security check failed: {error}")

    def _check_delivery_channels(self, db: Session):
        """Avisa cuando la SALIDA de alertas falla.

        Si los correos o los webhooks no se entregan, el NSP "alerta" a nadie
        sin saberlo. Se mira la bandeja persistente: filas fallidas (24 h) o
        pendientes hace mas de 30 minutos. Cada aviso sale por el OTRO canal:
        si falla el correo es `warning` (queda en el panel y sale por
        webhook); si fallan los webhooks es `critical` (llega por correo).
        Se resuelve solo al normalizarse.
        """

        try:

            from datetime import timedelta

            from backend.integrations.models.webhook import WebhookDelivery
            from backend.notifications.models.email_outbox import EmailOutbox
            from backend.shared.datetime_utils import utcnow

            now = utcnow()

            stale, day = now - timedelta(minutes=30), now - timedelta(hours=24)

            channels = (
                (
                    "email",
                    EmailOutbox,
                    "EMAIL_DELIVERY_FAILING",
                    "warning",
                    "Correo: hay notificaciones sin entregar",
                    "Revisá Ajustes → Correo (SMTP, destinatarios).",
                ),
                (
                    "webhook",
                    WebhookDelivery,
                    "WEBHOOK_DELIVERY_FAILING",
                    "critical",
                    "Webhooks: hay entregas sin completar",
                    "Revisá Integraciones → Webhooks (URL, red, destino).",
                ),
            )

            for name, model, alert_type, severity, title, hint in channels:

                key = f"delivery-{name}"

                failed = (
                    db.query(model)
                    .filter(model.status == "failed", model.created_at >= day)
                    .count()
                )

                stuck = (
                    db.query(model)
                    .filter(model.status == "pending", model.created_at <= stale)
                    .count()
                )

                if failed or stuck:

                    last = self._cooldown.get(key)

                    if last and time.time() - last < 600:

                        continue

                    recent = (
                        db.query(model)
                        .filter(model.last_error.isnot(None))
                        .order_by(model.id.desc())
                        .first()
                    )

                    detail = f" Último error: {recent.last_error}" if recent else ""

                    self.alert_service.create(
                        db,
                        alert_type,
                        severity,
                        title,
                        f"{failed} fallidas en 24 h y {stuck} pendientes hace "
                        f"más de 30 min.{detail[:300]} {hint}",
                    )

                    self._mark(key)

                elif self._cooldown.get(key):

                    self.alert_service.resolve(db, alert_type)

                    self._clear(key)

        except Exception as error:

            logger.warning(f"Delivery channel check failed: {error}")

    def _check_heartbeat(self, db: Session):

        try:

            from backend.monitoring.services.heartbeat_service import (
                HeartbeatService,
            )

            HeartbeatService().tick(db)

        except Exception as error:

            logger.warning(f"Heartbeat check failed: {error}")

    def _check_backup(
        self,
        db: Session
    ):

        try:

            from backend.backups.repositories.backup_settings_repository import (
                BackupSettingsRepository
            )

            from backend.backups.services.backup_service import backup_overdue

            from backend.shared.utils.datetimes import now_ecuador

            settings = BackupSettingsRepository().get(db)

            if not settings or not settings.enabled:

                self._clear("backup-overdue")

                return

            now = now_ecuador()

            if backup_overdue(
                settings.last_backup_at,
                now,
                settings.send_hour,
                settings.send_minute,
            ):

                if self._should_alert("backup-overdue", 6 * 3600):

                    last = (
                        settings.last_backup_at.isoformat(timespec="minutes")
                        if settings.last_backup_at
                        else "nunca"
                    )

                    self.alert_service.create(
                        db,
                        "BACKUP_OVERDUE",
                        "warning",
                        "Respaldo automático atrasado",
                        f"El respaldo diario no corre (última: {last}). "
                        f"Revisá Ajustes → Copias de seguridad.",
                    )

                    self._mark("backup-overdue")

            else:

                self._clear("backup-overdue")

        except Exception as error:

            logger.warning(f"Backup check failed: {error}")

    def _check_navigation(
        self,
        db: Session,
    ):

        started = getattr(self, "_started_at", None)

        if started and (time.time() - started) < 180:

            return

        try:

            from backend.monitoring.services.navigation_health_service import (
                NavigationHealthService,
            )

            report = NavigationHealthService().inspect(db)

            critical_keys = {
                "dhcp",
                "dns",
                "forwarding",
                "suricata",
                "zones_dns",
                "postgres",
            }

            for key, check in report["checks"].items():

                ckey = f"navigation-{key}"

                if check.get("ok"):

                    self._clear(ckey)

                    continue

                if not self._should_alert(ckey, 1800):

                    continue

                severity = (
                    "critical"
                    if key in critical_keys
                    else "warning"
                )

                label = self.NAV_LABELS.get(key, key)

                title = f"Problema en {label}"

                self.alert_service.create(
                    db,
                    "NAVIGATION_HEALTH",
                    severity,
                    title,
                    check.get("detail") or label,
                )

                self._mark(ckey)

        except Exception as error:

            logger.warning("Chequeo navegación fallo: %s", error)

    CLIENT_NAVIGATION_ALERT = "CLIENT_NAVIGATION_STALL"

    def _check_dns_activity(self, db: Session):

        """Detect abnormal DNS volume without changing traffic."""

        now = utcnow()
        recent = (
            db.query(func.count(DnsQueryLog.id))
            .filter(DnsQueryLog.queried_at >= now - timedelta(minutes=5))
            .scalar()
            or 0
        )
        baseline = (
            db.query(func.count(DnsQueryLog.id))
            .filter(
                DnsQueryLog.queried_at >= now - timedelta(minutes=30),
                DnsQueryLog.queried_at < now - timedelta(minutes=5),
            )
            .scalar()
            or 0
        )

        expected = baseline / 5.0
        key = "dns-activity-spike"

        if recent >= 1000 and recent > expected * 4:

            if self._should_alert(key, 1800):

                self.alert_service.create(
                    db,
                    "DNS_ACTIVITY_SPIKE",
                    "warning",
                    "Pico anómalo de consultas DNS",
                    (
                        f"{recent} consultas en los últimos 5 min; "
                        f"referencia de 30 min: {baseline}."
                    ),
                )

                self._mark(key)

            return

        if recent > 0:

            self._clear(key)

            try:

                self.alert_service.resolve(
                    db,
                    "DNS_ACTIVITY_SPIKE",
                    "Pico anómalo de consultas DNS",
                )

            except Exception as error:

                logger.debug("No se pudo resolver pico DNS: %s", error)


    def _check_client_navigation(self, db: Session):

        """Detect a sudden stop of client DNS activity.

        The NSP can be healthy (WAN + DNS responding) while clients stop
        browsing because of an AP/switch/client issue. This watchdog only
        fires on a clear drop: there was real activity in the last 30 min
        and now there are zero client queries for 5 min.
        """

        started = getattr(self, "_started_at", None)

        if started and (time.time() - started) < 180:
            return

        now = utcnow()
        since_5 = now - timedelta(minutes=5)
        since_30 = now - timedelta(minutes=30)

        recent = (
            db.query(func.count(DnsQueryLog.id))
            .filter(DnsQueryLog.queried_at >= since_5)
            .scalar()
            or 0
        )

        baseline = (
            db.query(func.count(DnsQueryLog.id))
            .filter(DnsQueryLog.queried_at >= since_30)
            .scalar()
            or 0
        )

        online = (
            db.query(func.count(NetworkDevice.id))
            .filter(NetworkDevice.presence_status == "ONLINE")
            .scalar()
            or 0
        )

        key = "client-navigation-stall"

        if recent == 0 and baseline >= 100 and online >= 5:

            if self._should_alert(key, 1800):

                self.alert_service.create(
                    db,
                    self.CLIENT_NAVIGATION_ALERT,
                    "warning",
                    "Sin navegación de clientes",
                    (
                        f"No hay consultas DNS de clientes en 5 min; "
                        f"había {baseline} en los últimos 30 min y "
                        f"{online} equipos online. Revisar AP/switch/DHCP."
                    ),
                )

                self._mark(key)

            return

        if recent > 0:

            self._clear(key)

            try:

                self.alert_service.resolve(
                    db,
                    self.CLIENT_NAVIGATION_ALERT,
                    "Sin navegación de clientes",
                )

            except Exception as error:

                logger.debug(
                    "No se pudo resolver alerta de navegación de clientes: %s",
                    error,
                )

    def _scan(
        self
    ):

        db = SessionLocal()

        try:

            self._check_resources(db)

            self._check_blocked_spike(db)

            self.security_dns_alerts.check(db)

            self._check_new_devices(db)

            self._check_components(db)

            self._check_dhcp(db)

            self._check_static_ips(db)

            self._check_share_space(db)

            self._check_ssh_security(db)

            self._check_backup(db)

            self._check_delivery_channels(db)

            self._check_heartbeat(db)

            self._check_navigation(db)

            self._check_client_navigation(db)

            self._check_dns_activity(db)

            try:
                self.dns_threats.check(db)
            except Exception as error:
                logger.warning("DNS threat detection: %s", error)

            try:
                self.golden_config.check(db)
            except Exception as error:
                logger.warning("Golden config check: %s", error)

            # Descubrimiento periodico de dispositivos: mantiene el
            # estado ONLINE/OFFLINE actualizado sin tener que pulsar
            # "Escanear red" (cada ~5 min, con el barrido de subred).
            self._discovery_counter = getattr(
                self, "_discovery_counter", 0
            ) + 1

            if self._discovery_counter >= 10:

                self._discovery_counter = 0

                try:

                    from backend.network.devices.services.device_discovery_service import (
                        DeviceDiscoveryService
                    )

                    DeviceDiscoveryService().synchronize(db, deep=False)

                except Exception as error:

                    logger.warning(
                        f"Discovery periodico fallo: {error}"
                    )

                # Auto-sync of the last known IP from ARP/leases each cycle.
                # It used to call "clean all offline", which wiped the last
                # IP of every powered-off device.
                try:

                    from backend.dhcp.services.dhcp_service import DhcpService

                    DhcpService().sync_device_ips()

                except Exception as error:

                    logger.warning(f"Auto sync-ips error: {error}")

                # Ensure backup scheduler is running (singleton)
                try:

                    from backend.shares.services.share_backup_service import get_share_backup_service

                    backup_svc = get_share_backup_service()
                    if not backup_svc._thread or not backup_svc._thread.is_alive():
                        backup_svc.start_scheduler()
                        logger.info("Share backup scheduler started from monitor")

                except Exception as error:

                    logger.warning(f"Backup scheduler start error: {error}")

        except Exception as error:

            logger.exception(f"Monitoring scan error: {error}")

        finally:

            db.close()

    def _loop(
        self
    ):

        logger.info("Monitoring component started.")

        while not self._stop:

            try:

                self._scan()

            except Exception as error:
                logger.debug("monitoring_component._loop: %s", error)
            time.sleep(30)

    def health_check(self) -> bool:
        try:
            return bool(self._thread and self._thread.is_alive())

        except Exception as error:
            logger.warning("MonitoringComponent health_check: %s", error)
            return False

    def start(self):

        logger.info("MonitoringComponent started.")

        # Periodo de gracia al arranque: durante los primeros minutos el
        # sistema sigue levantando componentes (api/content arrancan al
        # final) y NO deben generarse alertas falsas COMPONENT_DOWN.
        self._started_at = time.time()

        if not (self._thread and self._thread.is_alive()):

            self._thread = threading.Thread(
                target=self._loop,
                daemon=True,
                name="monitoring-scanner"
            )

            self._thread.start()

        self.wan_monitor = WanMonitorService()
        self.wan_monitor.start_scheduler()

        # Monitor de discos USB: alerta si se desconecta uno montado
        from backend.core.health.usb_monitor import usb_monitor
        usb_monitor.start()

    def stop(self):

        self._stop = True

        logger.info("MonitoringComponent stopped.")