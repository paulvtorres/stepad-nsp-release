import threading
import time

from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.database.session import SessionLocal

from backend.shared.runtime import runtime

from backend.alerts.models.alert import Alert
from backend.alerts.services.alert_service import AlertService
from backend.monitoring.services.monitoring_service import MonitoringService
from backend.monitoring.services.wan_monitor_service import WanMonitorService
from backend.monitoring.services.security_dns_alert_service import (
    SecurityDnsAlertService
)

from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.utils.mac import is_locally_administered

from backend.shared.logging.logger import logger


class MonitoringComponent(BaseComponent):

    name = "monitoring"

    criticality = ComponentCriticality.IMPORTANT

    BLOCKED_SPIKE_THRESHOLD = 200

    NEW_DEVICE_WINDOW_MINUTES = 10

    # Nombres legibles para las alertas de salud de red, en lugar del
    # código interno (p.ej. "suricata" o "zones_dns").
    NAV_LABELS = {
        "internet": "salida a Internet",
        "dhcp": "servidor DHCP",
        "dns": "resolución de nombres (DNS)",
        "log_listener": "registro de navegación",
        "forwarding": "enrutamiento hacia Internet (NAT)",
        "suricata": "protección de intrusos (IPS)",
        "disk": "espacio en disco",
        "zones_dns": "DNS de las zonas de red",
        "conflicto": "conflictos de direcciones de red",
    }


    def __init__(self):

        self.monitoring = MonitoringService()

        self.alert_service = AlertService()

        self.security_dns_alerts = SecurityDnsAlertService()

        self._thread = None

        self._stop = False

        self._started_at = None

        # cooldown: key -> last alert timestamp. Cleared when the
        # condition resolves so a new occurrence alerts again.
        self._cooldown = {}

    def _should_alert(
        self,
        key: str,
        cooldown_seconds: int = 0
    ) -> bool:

        last = self._cooldown.get(key)

        if last is None:

            return True

        return (time.time() - last) >= cooldown_seconds

    def _mark(
        self,
        key: str
    ):

        self._cooldown[key] = time.time()

    def _clear(
        self,
        key: str
    ):

        self._cooldown.pop(key, None)

    def _check_resources(
        self,
        db: Session
    ):

        snap = self.monitoring.snapshot()

        for key, threshold, alert_type, severity, title in [
            ("cpu", 90, "RESOURCE_CPU", "critical",
             f"CPU al {snap['cpu_percent']}%"),
            ("ram", 90, "RESOURCE_RAM", "critical",
             f"Memoria al {snap['ram_percent']}%"),
            ("disk", 90, "RESOURCE_DISK", "warning",
             f"Disco al {snap['disk_percent']}%"),
        ]:

            value = {
                "cpu": snap["cpu_percent"],
                "ram": snap["ram_percent"],
                "disk": snap["disk_percent"],
            }[key]

            ckey = f"resource-{key}"

            if value >= threshold:

                if self._should_alert(ckey, 1800):

                    self.alert_service.create(
                        db,
                        alert_type,
                        severity,
                        title,
                        f"Umbral superado: {title}. "
                        f"Carga: {snap['load_avg']}."
                    )

                    self._mark(ckey)

            else:

                self._clear(ckey)

    def _check_blocked_spike(
        self,
        db: Session
    ):

        since = datetime.utcnow() - timedelta(minutes=5)

        count = (
            db.query(DnsQueryLog.id)
            .filter(
                DnsQueryLog.blocked.is_(True),
                DnsQueryLog.queried_at >= since
            )
            .count()
        )

        if count >= self.BLOCKED_SPIKE_THRESHOLD:

            if self._should_alert("blocked-spike", 3600):

                self.alert_service.create(
                    db,
                    "BLOCKED_SPIKE",
                    "warning",
                    f"{count} consultas bloqueadas en los últimos 5 minutos",
                    "Posible intento de acceso a sitios bloqueados."
                )

                self._mark("blocked-spike")

    def _check_new_devices(
        self,
        db: Session
    ):

        since = datetime.utcnow() - timedelta(
            minutes=self.NEW_DEVICE_WINDOW_MINUTES
        )

        devices = (
            db.query(NetworkDevice)
            .filter(NetworkDevice.first_seen >= since)
            .all()
        )

        for device in devices:

            # Un MAC aleatorio (privacidad de celulares) cambia en cada
            # conexion: alertar por el generaria un "nuevo dispositivo"
            # cada dia para el mismo telefono. No es inventario estable.
            if is_locally_administered(device.mac_address):

                continue

            key = f"new-device-{device.id}"

            title = (
                f"Nuevo dispositivo: "
                f"{device.hostname or device.mac_address or device.ip_address}"
            )

            # Una sola alerta por dispositivo al día. Sin esto, mientras
            # first_seen permanece en la ventana de 10 minutos el escaneo
            # (cada 30s) volvía a alertar y llenaba el panel de INFO.
            already = (
                db.query(Alert.id)
                .filter(
                    Alert.alert_type == "NEW_DEVICE",
                    Alert.title == title,
                    Alert.created_at >= datetime.utcnow() - timedelta(hours=24),
                )
                .first()
            )

            if already:
                continue

            if self._should_alert(key):

                self.alert_service.create(
                    db,
                    "NEW_DEVICE",
                    "info",
                    title,
                    (
                        f"Se conectó un dispositivo nuevo "
                        f"({device.ip_address or 'sin IP'})"
                    )
                )

                self._mark(key)

    def _check_components(
        self,
        db: Session
    ):

        # Gracia de arranque: no alertar por componentes "no activos"
        # durante el boot (aun estan levantandose).
        started = getattr(self, "_started_at", None)

        # 5 min de gracia: el arranque completo (incluida la API) puede
        # tardar varios minutos y no es una falla.
        if started and (time.time() - started) < 300:

            return

        states = runtime.all()

        streaks = getattr(self, "_down_streaks", None)

        if streaks is None:

            streaks = {}

            self._down_streaks = streaks

        for name, state in states.items():

            key = f"component-{name}"

            status = state.get("status")

            if status in ("starting", "stopping"):

                continue

            if status != "running":

                # Debe seguir caido en el siguiente chequeo (60 s) para
                # alertar: evita alertas por reinicios/transiciones.
                streaks[key] = streaks.get(key, 0) + 1

                if streaks[key] < 2:

                    continue

                if self._should_alert(key, 1800):

                    self.alert_service.create(
                        db,
                        "COMPONENT_DOWN",
                        "critical",
                        f"Componente {name} no está activo",
                        state.get("error") or "El componente no está en ejecución."
                    )

                    self._mark(key)

            else:

                streaks.pop(key, None)

                self._clear(key)

    def _check_dhcp(
        self,
        db: Session,
    ):

        started = getattr(self, "_started_at", None)

        if started and (time.time() - started) < 180:

            return

        try:

            from backend.dhcp.services.dhcp_health_service import (
                DhcpHealthService,
            )

            health = getattr(self, "_dhcp_health", None)

            if health is None:

                health = DhcpHealthService()

                self._dhcp_health = health

            health.ensure_healthy(db)

        except Exception as error:

            logger.warning("Chequeo DHCP fallo: %s", error)

    def _check_static_ips(
        self,
        db: Session
    ):

        now = time.monotonic()

        if now - getattr(self, "_static_check_at", 0) < 600:

            return

        self._static_check_at = now

        try:

            from backend.dhcp.services.dhcp_pool_stats_service import (
                DhcpPoolStatsService,
            )

            stats = DhcpPoolStatsService().get_stats()

        except Exception as error:

            logger.warning(f"Chequeo de IPs fijas fallo: {error}")

            return

        for item in stats.get("static_in_pool", []) or []:

            key = f"static-in-pool-{item.get('ip')}"

            if not self._should_alert(key, 86400):

                continue

            label = item.get("hostname") or item.get("mac") or item.get("ip")

            self.alert_service.create(
                db,
                "DHCP_STATIC_IN_POOL",
                "warning",
                f"IP fija dentro del pool: {item.get('ip')}",
                f"«{label}» usa {item.get('ip')} dentro del rango DHCP sin "
                "reserva; puede chocar con una asignación automática. "
                "Cambiá la IP del equipo, excluila del pool o creá una reserva.",
            )

            self._mark(key)

    def _check_share_space(
        self,
        db: Session
    ):

        now = time.monotonic()

        if now - getattr(self, "_share_space_at", 0) < 1800:

            return

        self._share_space_at = now

        try:

            import os
            import shutil

            from pathlib import Path

            bases = (
                Path("/mnt/stepad-network"),
                Path("/mnt/stepad-share"),
            )

            for base in bases:

                if not base.is_dir():

                    continue

                for mount in base.iterdir():

                    if not os.path.ismount(mount):

                        continue

                    try:

                        usage = shutil.disk_usage(mount)

                    except OSError:

                        continue

                    percent = round(usage.used * 100 / usage.total)

                    key = f"share-space-{mount}"

                    if percent >= 85:

                        if self._should_alert(key, 86400):

                            free_gb = round(usage.free / (1024 ** 3), 1)

                            self.alert_service.create(
                                db,
                                "SHARE_DISK_HEALTH",
                                "warning",
                                f"Recurso casi lleno: {mount}",
                                f"{percent}% usado · {free_gb} GB libres. "
                                "Liberar espacio para no cortar respaldos.",
                            )

                            self._mark(key)

                    else:

                        self._clear(key)

        except Exception as error:

            logger.warning(f"Chequeo de espacio en recursos fallo: {error}")

    def _check_backup(
        self,
        db: Session
    ):

        try:

            from backend.backups.repositories.backup_settings_repository import (
                BackupSettingsRepository
            )

            from backend.backups.services.backup_service import backup_overdue

            from backend.shared.utils.datetimes import now_ecuador

            settings = BackupSettingsRepository().get(db)

            if not settings or not settings.enabled:

                self._clear("backup-overdue")

                return

            now = now_ecuador()

            if backup_overdue(
                settings.last_backup_at,
                now,
                settings.send_hour,
                settings.send_minute,
            ):

                if self._should_alert("backup-overdue", 6 * 3600):

                    last = (
                        settings.last_backup_at.isoformat(timespec="minutes")
                        if settings.last_backup_at
                        else "nunca"
                    )

                    self.alert_service.create(
                        db,
                        "BACKUP_OVERDUE",
                        "warning",
                        "Respaldo automático atrasado",
                        f"El respaldo diario no corre (última: {last}). "
                        f"Revisá Ajustes → Copias de seguridad.",
                    )

                    self._mark("backup-overdue")

            else:

                self._clear("backup-overdue")

        except Exception as error:

            logger.warning(f"Chequeo de respaldo fallo: {error}")

    def _check_navigation(
        self,
        db: Session,
    ):

        started = getattr(self, "_started_at", None)

        if started and (time.time() - started) < 180:

            return

        try:

            from backend.monitoring.services.navigation_health_service import (
                NavigationHealthService,
            )

            report = NavigationHealthService().inspect(db)

            critical_keys = {
                "dhcp",
                "dns",
                "forwarding",
                "suricata",
                "zones_dns",
            }

            for key, check in report["checks"].items():

                ckey = f"navigation-{key}"

                if check.get("ok"):

                    self._clear(ckey)

                    continue

                if not self._should_alert(ckey, 1800):

                    continue

                severity = (
                    "critical"
                    if key in critical_keys
                    else "warning"
                )

                label = self.NAV_LABELS.get(key, key)

                title = f"Problema en {label}"

                self.alert_service.create(
                    db,
                    "NAVIGATION_HEALTH",
                    severity,
                    title,
                    check.get("detail") or label,
                )

                self._mark(ckey)

        except Exception as error:

            logger.warning("Chequeo navegación fallo: %s", error)

    def _scan(
        self
    ):

        db = SessionLocal()

        try:

            self._check_resources(db)

            self._check_blocked_spike(db)

            self.security_dns_alerts.check(db)

            self._check_new_devices(db)

            self._check_components(db)

            self._check_dhcp(db)

            self._check_static_ips(db)

            self._check_share_space(db)

            self._check_backup(db)

            self._check_navigation(db)

            # Descubrimiento periodico de dispositivos: mantiene el
            # estado ONLINE/OFFLINE actualizado sin tener que pulsar
            # "Escanear red" (cada ~5 min, con el barrido de subred).
            self._discovery_counter = getattr(
                self, "_discovery_counter", 0
            ) + 1

            if self._discovery_counter >= 10:

                self._discovery_counter = 0

                try:

                    from backend.network.devices.services.device_discovery_service import (
                        DeviceDiscoveryService
                    )

                    DeviceDiscoveryService().synchronize(db, deep=False)

                except Exception as error:

                    logger.warning(
                        f"Discovery periodico fallo: {error}"
                    )

                # Auto-sync de la IP conocida desde ARP/leases cada ciclo.
                # Antes se llamaba a "clean all offline", que borraba la
                # ultima IP de todos los equipos apagados.
                try:

                    from backend.dhcp.services.dhcp_service import DhcpService

                    DhcpService().sync_device_ips()

                except Exception as error:

                    logger.warning(f"Auto sync-ips error: {error}")

                # Ensure backup scheduler is running (singleton)
                try:

                    from backend.shares.services.share_backup_service import get_share_backup_service

                    backup_svc = get_share_backup_service()
                    if not backup_svc._thread or not backup_svc._thread.is_alive():
                        backup_svc.start_scheduler()
                        logger.info("Share backup scheduler started from monitor")

                except Exception as error:

                    logger.warning(f"Backup scheduler start error: {error}")

        except Exception as error:

            logger.exception(f"Monitoring scan error: {error}")

        finally:

            db.close()

    def _loop(
        self
    ):

        logger.info("Monitoring component started.")

        while not self._stop:

            try:

                self._scan()

            except Exception as error:
                logger.debug("monitoring_component._loop: %s", error)
            time.sleep(30)

    def start(self):

        logger.info("MonitoringComponent started.")

        # Periodo de gracia al arranque: durante los primeros minutos el
        # sistema sigue levantando componentes (api/content arrancan al
        # final) y NO deben generarse alertas falsas COMPONENT_DOWN.
        self._started_at = time.time()

        self._thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name="monitoring-scanner"
        )

        self._thread.start()

        self.wan_monitor = WanMonitorService()
        self.wan_monitor.start_scheduler()

        # Monitor de discos USB: alerta si se desconecta uno montado
        from backend.core.health.usb_monitor import usb_monitor
        usb_monitor.start()

    def stop(self):

        self._stop = True

        logger.info("MonitoringComponent stopped.")