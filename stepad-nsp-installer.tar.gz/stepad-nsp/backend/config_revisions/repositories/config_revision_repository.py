from sqlalchemy.orm import Session

from backend.config_revisions.models.config_revision import (
    ConfigRevision
)


class ConfigRevisionRepository:

    def save(
        self,
        db: Session,
        revision: ConfigRevision
    ):

        db.add(revision)

        db.commit()

        db.refresh(revision)

        return revision

    def find_all(
        self,
        db: Session
    ):

        return (
            db.query(ConfigRevision)
            .order_by(ConfigRevision.id.desc())
            .all()
        )

    def find_by_id(
        self,
        db: Session,
        revision_id: int
    ):

        return db.get(ConfigRevision, revision_id)
