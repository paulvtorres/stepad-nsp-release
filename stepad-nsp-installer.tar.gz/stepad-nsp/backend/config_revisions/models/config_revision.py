from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class ConfigRevision(Base):

    __tablename__ = "config_revisions"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    label: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )


    # JSON snapshot of the configuration.
    data: Mapped[str] = mapped_column(
        Text,
        nullable=False
    )


    created_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id"),
        nullable=True
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
