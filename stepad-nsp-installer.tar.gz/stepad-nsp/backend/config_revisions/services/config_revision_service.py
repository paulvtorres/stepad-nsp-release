import json

from sqlalchemy.orm import Session

from fastapi import HTTPException

from backend.config_revisions.models.config_revision import ConfigRevision
from backend.config_revisions.repositories.config_revision_repository import (
    ConfigRevisionRepository
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)
from backend.network.zones.models.network_zone import NetworkZone
from backend.nat.models.port_forward import PortForward
from backend.vpn.models.vpn_peer import VpnPeer
from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.notifications.models.notification_settings import (
    NotificationSettings
)
from backend.backups.models.backup_settings import BackupSettings
from backend.siem.models.syslog_settings import SyslogSettings
from backend.siem.models.compliance_settings import ComplianceSettings
from backend.organization.models.organization_settings import (
    OrganizationSettings
)

from backend.vpn.services.vpn_service import VpnService
from backend.nat.services.port_forward_service import PortForwardService
from backend.rules.engine.rule_engine import RuleEngine
from backend.audit.services.audit_service import AuditService

from backend.shared.logging.logger import logger


# Entities that are safe to restore live (no fragile FKs). Zones are
# captured for visibility but NOT restored automatically -- they are
# disruptive; use a full backup for that.
RESTORABLE_TABLES = [
    PortForward,
    VpnPeer,
    DeviceAccessRule,
    NotificationSettings,
    BackupSettings,
    SyslogSettings,
    ComplianceSettings,
    OrganizationSettings,
]


def _rows_as_dicts(model, db):
    rows = db.query(model).all()
    result = []
    for row in rows:
        result.append({
            column.name: getattr(row, column.name)
            for column in model.__table__.columns
        })
    return result


class ConfigRevisionService:

    def __init__(self):

        self.repository = ConfigRevisionRepository()

        self.audit_service = AuditService()

        self.zone_repo = NetworkZoneRepository()

    def capture(
        self,
        db: Session,
        user_id: int | None,
        label: str = ""
    ) -> dict:

        snapshot = {
            "zones": _rows_as_dicts(NetworkZone, db),
        }

        for model in RESTORABLE_TABLES:

            key = model.__tablename__

            snapshot[key] = _rows_as_dicts(model, db)

        revision = ConfigRevision(
            label=label or f"Revisión de configuración",
            data=json.dumps(
                snapshot,
                default=str,
                ensure_ascii=False
            ),
            created_by=user_id
        )

        saved = self.repository.save(db, revision)

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="CONFIG_REVISION_CREATED",
            resource="CONFIG",
            description=(
                f"Configuración guardada como revisión "
                f"#{saved.id}"
            )
        )

        return {
            "id": saved.id,
            "label": saved.label,
            "created_at": saved.created_at.isoformat()
        }

    def list(
        self,
        db: Session
    ):

        from backend.users.models.user import User

        result = []

        for revision in self.repository.find_all(db):

            username = None

            if revision.created_by:

                user = db.get(User, revision.created_by)

                username = user.username if user else None

            result.append({
                "id": revision.id,
                "label": revision.label,
                "created_by": revision.created_by,
                "username": username,
                "created_at": revision.created_at.isoformat()
            })

        return result

    def detail(
        self,
        db: Session,
        revision_id: int
    ):

        revision = self.repository.find_by_id(db, revision_id)

        if revision is None:

            raise HTTPException(
                status_code=404,
                detail="Revision not found"
            )

        return {
            "id": revision.id,
            "label": revision.label,
            "created_at": revision.created_at.isoformat(),
            "data": json.loads(revision.data)
        }

    def restore(
        self,
        db: Session,
        revision_id: int,
        user_id: int | None
    ) -> dict:

        revision = self.repository.find_by_id(db, revision_id)

        if revision is None:

            raise HTTPException(
                status_code=404,
                detail="Revision not found"
            )

        snapshot = json.loads(revision.data)

        restored = []

        for model in RESTORABLE_TABLES:

            key = model.__tablename__

            rows = snapshot.get(key, [])

            if not rows:

                continue

            if model in (NotificationSettings, BackupSettings,
                         SyslogSettings, ComplianceSettings,
                         OrganizationSettings):

                # Single-row settings: keep the row, overwrite fields.
                settings = db.get(model, 1)

                if settings is None:

                    settings = model(id=1)

                    db.add(settings)

                for column in model.__table__.columns:

                    if column.name in ("id", "updated_at"):
                        continue

                    value = rows[0].get(column.name)

                    setattr(settings, column.name, value)

            else:

                # Replace the table with the revision's rows.
                db.query(model).delete()

                for row_data in rows:

                    values = {
                        column.name: row_data.get(column.name)
                        for column in model.__table__.columns
                        if column.name in row_data
                    }

                    db.add(model(**values))

            restored.append(key)

        db.commit()

        # Re-apply live systems.
        try:

            VpnService().sync(db)

        except Exception as error:

            logger.warning(f"VPN re-sync after restore failed: {error}")

        try:

            PortForwardService().sync(db)

        except Exception as error:

            logger.warning(
                f"Port-forward re-sync after restore failed: {error}"
            )

        try:

            engine = RuleEngine()

            engine.domain_service.synchronize(db)

            engine.domain_service.synchronize_all_zones(db)

        except Exception as error:

            logger.warning(f"Domain re-sync after restore failed: {error}")

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="CONFIG_REVISION_RESTORED",
            resource="CONFIG",
            description=(
                f"Configuración restaurada desde la revisión "
                f"#{revision.id} ({', '.join(restored)})"
            )
        )

        return {
            "success": True,
            "restored": restored
        }
