from backend.infrastructure.network.adapters.linux.linux_interface_provider import (
    LinuxInterfaceProvider
)

from backend.shared.config.config_service import (
    ConfigService
)


class SetupService:


    def __init__(self):

        self.provider = LinuxInterfaceProvider()

        self.config_service = ConfigService()



    def list_interfaces(self):

        return self.provider.list_interfaces()



    def save_network_configuration(

        self,

        wan_interface: str,

        lan_interface: str

    ):

        self.config_service.update_section(

            "network",

            {

                "initialized": True,

                "wan_interface": wan_interface,

                "lan_interface": lan_interface

            }

        )