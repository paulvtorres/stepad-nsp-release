"""Reconciliador DHCP: el ÚNICO escritor del estado de dnsmasq.

Tres fuentes de verdad, una sola salida:

    config.yaml   -> segmento (pool, gateway, lease, exclusiones)
    base de datos -> reservas por equipo y rangos de zona/grupo
    leases        -> observado (lo que dnsmasq tiene prestado)

`apply()` recalcula el estado deseado con la capa `domain/`, escribe
`dnsmasq.conf` y `reservations.conf` de forma ATÓMICA, valida con
`dnsmasq --test` y solo reinicia el proceso si el contenido cambió.

Reglas de la capa:

- Nadie fuera de aquí escribe esos dos archivos ni reinicia dnsmasq.
- Es idempotente: llamarlo N veces seguidas no reinicia nada si no hay
  cambios (un reinicio de dnsmasq corta DHCP/DNS unos segundos).
- Si la validación falla, restaura el contenido anterior y NO reinicia.
- Si el pool queda casi agotado, lo reporta (el panel lo muestra) para
  que el operador revise los equipos conectados antes de que alguno quede
  sin IP. El pool es FIJO: nunca se amplía solo.
"""

from __future__ import annotations

import hashlib
import ipaddress
import threading

from datetime import datetime, timedelta, timezone
from backend.shared.datetime_utils import utcnow
from pathlib import Path

from backend.dhcp.reconciler_alerts import PoolAlertsMixin
from backend.dhcp.reconciler_reclaim import LeaseReclaimMixin
from backend.dhcp.domain.pool import (
    build_pool_spec,
    ip_to_int,
    pool_stats,
    range_pool_status,
)
from backend.dhcp.domain.conflicts import find_conflicts
from backend.dhcp.domain.reclaim import select_reclaimable
from backend.dhcp.domain.leases import parse_leases, read_leases
from backend.dhcp.domain.neighbors import arp_mac_by_ip
from backend.dhcp.services.dhcp_lease_owners import known_dhcp_macs_by_ip
from backend.shared.logging.logger import logger


# Cuántas direcciones libres se consideran "pocas" para avisar.
POOL_LOW_ABSOLUTE = 5

POOL_LOW_RATIO = 0.05


def _digest(*texts: str) -> str:

    sha = hashlib.sha256()

    for text in texts:

        sha.update(text.encode("utf-8", "replace"))

    return sha.hexdigest()


def read_arp_table() -> dict[str, str]:
    """{ip: mac} de la tabla ARP (único punto de IO de vecinos)."""

    try:

        with open("/proc/net/arp", encoding="utf-8", errors="replace") as file:

            return arp_mac_by_ip(file.read())

    except OSError:

        return {}


class DhcpReconciler(PoolAlertsMixin, LeaseReclaimMixin):

    def __init__(
        self,
        config_builder,
        reservations_builder,
        provider,
        reservation_provider,
        process_manager,
        config_path: Path,
        reservations_path: Path,
        alert_notifier=None,
        alert_resolver=None,
        email_notifier=None,
        threshold_provider=None,
        config_service=None,
        neighbor_verifier=None,
        leases_path: Path = Path("/var/lib/misc/dnsmasq.leases"),
        zones_provider=None,
        release_provider=None,
    ):

        self._config_builder = config_builder

        self._reservations_builder = reservations_builder

        self._provider = provider

        self._reservation_provider = reservation_provider

        self._process = process_manager

        self._config_path = Path(config_path)

        self._reservations_path = Path(reservations_path)

        self._last_good_config_path = Path(str(config_path) + ".last-good")

        self._last_good_reservations_path = Path(str(reservations_path) + ".last-good")

        self._start_failures = 0

        self._no_address_until = float("-inf")

        self._alert_notifier = alert_notifier or self._default_alert

        self._alert_resolver = alert_resolver or self._default_resolve

        self._email_notifier = email_notifier

        # Confirma contra la red (ping + ARP) las IPs sospechosas.
        self._neighbor_verifier = neighbor_verifier or self._verify_neighbors

        # Umbral configurado (panel). Inyectable para tests.
        self._threshold_provider = threshold_provider or self._configured_threshold

        self._config_service = config_service

        self._leases_path = Path(leases_path)

        # Rangos DHCP de las zonas (VLAN / 2da LAN). Inyectable para tests.
        self._zones_provider = zones_provider or self._default_zones

        # `dhcp_release` (dnsmasq-utils); None => se crea al primer uso.
        self._release_provider = release_provider

        # True si el último reciclaje editó el archivo de leases y dnsmasq
        # debe reiniciarse para recargarlo.
        self._reclaim_reload_needed = True

        # Estado de alertas por zona: {nombre: {"low": bool, "exhausted": bool}}
        self._zone_state: dict[str, dict[str, bool]] = {}

        # Racha de conflictos por IP: se remedia solo lo persistente
        # (un ARP viejo de un cambio de IP no debe sacar una IP del pool).
        self._conflict_first_seen: dict[str, datetime] = {}

        self._conflict_streaks: dict[str, int] = {}

        self._lock = threading.Lock()

        self._last_digest: str | None = None

        self._last_config_digest: str | None = None

        self._last_reservations_digest: str | None = None

        self._state = {
            "last_apply_at": None,
            "last_ok": None,
            "last_error": None,
            "applies": 0,
            "restarts": 0,
            "skipped": 0,
            "pool_low": False,
            "pool_exhausted": False,
            "conflicts": 0,
            "conflicts_signature": "",
            "reclaimed_total": 0,
            "reclaimed_last": 0,
        }

        self._pool_samples: list[tuple[float, int]] = []

    # ------------------------------------------------------------------
    # Alertas de capacidad
    # ------------------------------------------------------------------


    def _check_conflicts(self, config, reservations) -> list[dict]:

        """Conflictos de IP (lease vs ARP / estaticas dentro del pool).

        Se avisa UNA vez por conjunto de conflictos: si cambian, se avisa
        de nuevo (el titulo incluye las IPs para no quedar pegado al viejo).
        """

        arp = read_arp_table()

        if not arp:

            # Sin vecinos no hay conflicto posible: si habia uno, ya paso.
            if self._state.get("conflicts_signature"):

                self._state["conflicts"] = 0

                self._state["conflicts_signature"] = ""

                self._resolve_alerts("DHCP_IP_CONFLICT", "DHCP_STATIC_IN_POOL")

            return []

        reserved = [item.get("ip") for item in reservations if item.get("ip")]

        conflicts = find_conflicts(
            read_leases(self._leases_path),
            arp,
            reserved,
            config.pool_start,
            config.pool_end,
            known_dhcp_macs_by_ip(),
        )

        conflicts = self._confirm_conflicts(conflicts)

        signature = ",".join(
            f"{item.kind}:{item.ip}" for item in conflicts
        )

        self._state["conflicts"] = len(conflicts)

        if not conflicts and self._state.get("conflicts_signature"):

            self._resolve_alerts("DHCP_IP_CONFLICT", "DHCP_STATIC_IN_POOL")

        if conflicts and signature != self._state.get("conflicts_signature"):

            real = [item for item in conflicts if item.kind == "lease_mismatch"]

            if real:

                detalles = "; ".join(
                    f"{item.ip}: lease {item.lease_mac} pero responde {item.arp_mac}"
                    for item in real[:4]
                )

                self._alert_notifier(
                    "DHCP_IP_CONFLICT",
                    "critical",
                    "DHCP: IP duplicada en la red (%d)" % len(real),
                    (
                        f"{detalles}. Un equipo usa una IP estatica dentro "
                        "del pool DHCP: reservala en Dispositivos o cambiala "
                        "fuera del pool (" + f"{config.pool_start}-{config.pool_end}" + ")."
                    ),
                )

            statics = [
                item for item in conflicts if item.kind == "static_in_pool"
            ]

            if statics:

                detalles = "; ".join(
                    f"{item.ip} ({item.arp_mac})" for item in statics[:6]
                )

                self._alert_notifier(
                    "DHCP_STATIC_IN_POOL",
                    "warning",
                    "DHCP: equipo con IP fija dentro del pool (%d)"
                    % len(statics),
                    (
                        f"{detalles}. STEPAD excluye esa IP del pool para "
                        "que ningun otro equipo la reciba. Reservala en "
                        "Dispositivos o muevela fuera del rango "
                        f"{config.pool_start}-{config.pool_end}."
                    ),
                )

            logger.warning(
                "DHCP: %d conflicto(s) de IP detectados (%s)",
                len(conflicts),
                signature,
            )

        self._state["conflicts_signature"] = signature

        self._remediate_conflicts(conflicts)

        return [item.to_dict() for item in conflicts]

    def _confirm_conflicts(self, conflicts):
        """Descarta conflictos FANTASMA antes de actuar.

        /proc/net/arp conserva entradas de equipos que ya se fueron (el
        kernel no purga STALE con pocas entradas). Tomarlas por IP fija
        excluiria IPs de equipos ausentes y encogeria el pool para
        siempre. Cada IP sospechosa se sondea (ping -> ARP) y solo cuenta
        si responde AHORA con la misma MAC. Si no se puede verificar, se
        protege la IP: es mas barato que provocar una colision.
        """

        if not conflicts:

            return conflicts

        ips = list(dict.fromkeys(item.ip for item in conflicts))[:64]

        try:

            reachable = self._neighbor_verifier(ips) or {}

        except Exception as error:

            logger.debug("DhcpReconciler: sin verificar conflictos: %s", error)

            return conflicts

        return [
            item
            for item in conflicts
            if (reachable.get(item.ip) or "").lower() == item.arp_mac.lower()
        ]

    @staticmethod
    def _verify_neighbors(ips) -> dict[str, str]:
        """ip -> mac de los vecinos que responden ahora (tras un ping)."""

        import subprocess

        from backend.network.devices.domain.presence import parse_neigh
        from backend.network.devices.services.device_presence_service import (
            DevicePresenceService,
        )

        wanted = set(ips)

        DevicePresenceService._probe(list(wanted))

        proc = subprocess.run(
            ["ip", "neigh", "show"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        return {
            entry.ip: entry.mac
            for entry in parse_neigh(proc.stdout)
            if entry.reachable and entry.ip in wanted
        }

    def _get_config_service(self):

        if self._config_service is None:

            from backend.shared.config.config_service import ConfigService

            self._config_service = ConfigService()

        return self._config_service

    def _remediate_conflicts(self, conflicts) -> None:

        """Excluye temporalmente IPs en conflicto persistente.

        Persistente = visto durante al menos 10 minutos, no dos applies
        seguidos. La exclusión automática caduca (7 días por defecto) y
        nunca se mezcla con las exclusiones manuales del operador.
        """

        now = datetime.now(timezone.utc)

        real = {

            item.ip: item

            for item in conflicts

            if item.kind in ("lease_mismatch", "static_in_pool")

        }

        for ip in list(self._conflict_first_seen):

            if ip not in real:

                self._conflict_first_seen.pop(ip, None)

        for ip in real:

            self._conflict_first_seen.setdefault(ip, now)

        # Una IP estática dentro del pool se protege de inmediato.
        # Esperar 10 minutos deja una ventana real de colisión.
        static_immediate = {
            item.ip
            for item in conflicts
            if item.kind == "static_in_pool"
        }

        persistent = sorted(

            ip

            for ip, first_seen in self._conflict_first_seen.items()

            if (
                (now - first_seen).total_seconds() >= 600
                or ip in static_immediate
            )

        )

        self._state["auto_excluded"] = persistent

        try:

            service = self._get_config_service()

            config = dict(service.get_dhcp_config() or {})

            manual = list(config.get("excluded_ips") or [])

            days = max(1, min(365, int(config.get("auto_exclusion_days") or 7)))

            keep = []

            changed = False

            existing = {}
            known = known_dhcp_macs_by_ip()
            known_macs = {
                mac.lower()
                for macs in known.values()
                for mac in macs
            }
            arp_now = read_arp_table()

            for item in config.get("auto_excluded_ips") or []:

                if not isinstance(item, dict):

                    changed = True

                    continue

                try:

                    until = datetime.fromisoformat(str(item.get("until") or "").replace("Z", "+00:00"))

                except ValueError:

                    changed = True

                    continue

                if until > now:

                    ip = str(item.get("ip") or "")
                    arp_mac = (arp_now.get(ip) or "").lower()

                    if ip not in real and (
                        ip in known or arp_mac in known_macs
                    ):

                        changed = True
                        continue

                    keep.append(item)

                    existing[ip] = item

                else:

                    changed = True

            added = []

            for ip in persistent:

                if ip in manual:

                    continue

                if ip in existing:

                    existing[ip]["until"] = (now + timedelta(days=days)).isoformat()

                else:

                    item = {

                        "ip": ip,

                        "until": (now + timedelta(days=days)).isoformat(),

                        "reason": "Conflicto DHCP persistente",

                    }

                    keep.append(item)

                    existing[ip] = item

                    added.append(ip)

            if added or changed or (
                config.get("auto_excluded_ips") is not None
                and config.get("auto_excluded_ips") != keep
            ):

                config["auto_excluded_ips"] = keep

                service.update_section("dhcp", config)

                self._state["auto_exclusions_changed"] = True

                if added:

                    logger.warning(
                        "DHCP: IPs en conflicto excluidas temporalmente: %s", added
                    )

        except Exception as error:

            logger.warning(
                "DHCP: no se pudieron actualizar exclusiones automáticas: %s", error
            )


    # ------------------------------------------------------------------
    # Estado
    # ------------------------------------------------------------------

    def status(self) -> dict:

        return dict(self._state)

    def _record(self, **values) -> None:

        self._state.update(values)

        self._state["last_apply_at"] = utcnow().isoformat()

    # ------------------------------------------------------------------
    # Escritura atómica
    # ------------------------------------------------------------------

    def _write_atomic(self, path: Path, content: str) -> None:

        path.parent.mkdir(parents=True, exist_ok=True)

        tmp = path.with_suffix(path.suffix + ".tmp")

        tmp.write_text(content, encoding="utf-8")

        tmp.replace(path)

    def _restore(self, path: Path, previous: str | None) -> None:

        if previous is None:

            return

        try:

            self._write_atomic(path, previous)

        except OSError as error:

            logger.error("DHCP: no se pudo restaurar %s: %s", path, error)

    # ------------------------------------------------------------------
    # Reconciliación
    # ------------------------------------------------------------------

    def apply(self, force: bool = False) -> dict:

        with self._lock:

            return self._apply_locked(force=force)

    def _apply_locked(self, force: bool) -> dict:

        # Candado compartido con el resto del appliance: evita que otro
        # servicio (p. ej. LAN temporal) reinicie dnsmasq en medio de la
        # reescritura de la configuracion.
        from backend.shared.runtime.resource_locks import resource_locks

        with resource_locks.dnsmasq:

            return self._apply_serialized(force=force)

    def _apply_serialized(self, force: bool) -> dict:

        self._state["applies"] += 1

        previous_config = self._read(self._config_path)

        previous_reservations = self._read(self._reservations_path)

        try:

            config = self._config_builder()

        except Exception as error:

            logger.error(
                "DHCP: no se pudo calcular la configuración; se conserva la actual: %s",
                error,
            )

            service_result = self._ensure_current_service()

            self._record(
                last_ok=bool(service_result.get("success")),
                last_error=str(error),
            )

            return {
                "success": bool(service_result.get("success")),
                "fallback": "config_builder",
                "error": str(error),
                "service": service_result,
            }

        if config is None:

            self._record(last_ok=False, last_error="LAN no asignada")

            return {"success": False, "message": "LAN not detected"}

        reservations_error = None

        try:

            reservations = self._reservations_builder()

        except Exception as error:

            # Si la BD falla, NO se debe dejar dnsmasq caído. Se conserva
            # reservations.conf actual y se sigue con config/validación.
            logger.error(
                "DHCP: no se pudieron calcular reservas; se reutiliza el archivo actual: %s",
                error,
            )

            reservations = None

            reservations_error = str(error)

        try:

            config_result = self._provider.write_config(config)

            if reservations is None:

                reservations_result = {
                    "success": False,
                    "reused": True,
                    "error": reservations_error,
                }

            else:

                reservations_result = self._reservation_provider.write_reservations(
                    reservations
                )

                skipped = (reservations_result or {}).get("skipped") or []

                if skipped:

                    self._alert_notifier(
                        "DHCP_RESERVATION_INVALID",
                        "warning",
                        "DHCP: reservas omitidas por datos inválidos (%d)"
                        % len(skipped),
                        "; ".join(
                            f"{item.get('mac')} → {item.get('ip')}: "
                            f"{item.get('reason')}"
                            for item in skipped[:5]
                        )
                        + ". El resto de las reservas se aplicó normalmente.",
                    )

        except Exception as error:

            logger.error("DHCP: fallo al escribir la configuración: %s", error)

            self._restore(self._config_path, previous_config)

            self._restore(self._reservations_path, previous_reservations)

            self._record(last_ok=False, last_error=str(error))

            return {"success": False, "error": str(error)}

        new_config = self._read(self._config_path) or ""

        new_reservations = self._read(self._reservations_path) or ""

        digest = _digest(new_config, new_reservations)

        config_digest = _digest(new_config)

        reservations_digest = _digest(new_reservations)

        first_apply = self._last_config_digest is None

        # Tras un reinicio del panel no hay hash en memoria. Comparar
        # contra los archivos que ya estaban en disco evita reiniciar
        # dnsmasq a los 5 minutos si la configuración no cambió.
        config_changed = (
            new_config != (previous_config or "")
            if first_apply
            else config_digest != self._last_config_digest
        )

        reservations_changed = (
            new_reservations != (previous_reservations or "")
            if first_apply
            else reservations_digest != self._last_reservations_digest
        )

        running = bool(self._process.status().get("running"))

        conflicts = self._check_conflicts(config, reservations or [])

        if self._state.pop("auto_exclusions_changed", False):

            # La exclusión se acaba de escribir en ConfigService. Hay
            # que reconstruir la config para que dnsmasq la reciba en
            # ESTE ciclo, no en el siguiente.
            try:

                config = self._config_builder()

                if config is None:

                    raise ValueError("LAN no asignada")

                config_result = self._provider.write_config(config)
                new_config = self._read(self._config_path) or ""
                config_digest = _digest(new_config)
                digest = _digest(new_config, new_reservations)
                config_changed = True

            except Exception as error:

                logger.error(
                    "DHCP: no se pudo aplicar la exclusión inmediata: %s",
                    error,
                )
                self._restore(self._config_path, previous_config)
                self._restore(self._reservations_path, previous_reservations)
                self._record(last_ok=False, last_error=str(error))
                return {
                    "success": False,
                    "error": "auto exclusion refresh failed",
                }

        static_ips = [
            item["ip"]
            for item in conflicts
            if item.get("kind") == "static_in_pool"
        ]

        pool = self._pool_status(config, reservations, static_ips)

        self._notify_pool(pool)

        # Auto-reclamacion: SOLO cuando el pool cruzo el umbral.
        reclaimed = self._reclaim_if_needed(pool, config=config)

        # El respaldo detiene y arranca dnsmasq: el estado leído arriba pudo
        # quedar viejo aunque no se haya liberado nada (p. ej. si el arranque
        # falló). Se relee SIEMPRE para que, si quedó caído, este mismo ciclo
        # lo arranque en vez de esperar al siguiente.
        running = bool(self._process.status().get("running"))

        if reclaimed:

            pool = self._pool_status(config, reservations, static_ips)

            self._notify_pool(pool)

            # Si se editó el archivo (respaldo), reiniciar para recargarlo.
            # Con `dhcp_release` dnsmasq ya quedó al día: sin reinicio.
            if self._reclaim_reload_needed:

                force = True

        if (
            not force
            and running
            and digest == self._last_digest
        ):

            self._state["skipped"] += 1

            self._record(last_ok=True, last_error=None)

            return {
                "success": True,
                "changed": False,
                "skipped": True,
                "reservations": reservations_result,
                "config": config_result,
                "service": self._process.status(),
                "pool": pool,
            }

        try:

            validation = self._provider.validate()

        except Exception as error:

            validation = {"success": False, "error": f"validación falló: {error}"}

        if not validation.get("success", True):

            logger.error(
                "DHCP: configuración inválida, se restaura la anterior: %s",
                validation.get("message") or validation,
            )

            self._restore(self._config_path, previous_config)

            self._restore(self._reservations_path, previous_reservations)

            self._record(
                last_ok=False,
                last_error=(
                    validation.get("error")
                    or validation.get("output")
                    or "validación falló"
                ),
            )

            return {
                "success": False,
                "changed": False,
                "error": "invalid config",
                "validation": validation,
            }

        changed = digest != self._last_digest

        # Solo la configuración (pool/interfaz/zonas) exige reinicio.
        # Las reservas van por dhcp-hostsfile y se recargan con SIGHUP.
        if not running:

            service_result = self._process.start()

        elif force or config_changed:

            service_result = self._process.restart()

        elif reservations_changed:

            reloader = getattr(self._process, "reload", None)

            service_result = (
                reloader()
                if reloader is not None
                else {"success": False, "error": "reload no disponible"}
            )

            if not service_result.get("success"):

                service_result = self._process.restart()

        else:

            service_result = {"success": True, "pid": None, "message": "sin cambios"}

        if service_result.get("success"):

            self._start_failures = 0

            self._save_last_good()

        else:

            self._start_failures += 1

            if self._start_failures >= 2 and self._restore_last_good():

                logger.warning(
                    "DHCP: arranque falló %s veces; restaurando última configuración buena",
                    self._start_failures,
                )

                service_result = self._process.restart()

                if service_result.get("success"):

                    self._start_failures = 0

        if changed:

            self._state["restarts"] += 1

        self._last_digest = digest

        self._last_config_digest = config_digest

        self._last_reservations_digest = reservations_digest

        self._record(last_ok=bool(service_result.get("success")), last_error=None)

        logger.info(
            "DHCP reconciliado: %d reservas, %d libres, reinicio=%s",
            len(reservations or []),
            pool.get("free", -1),
            changed,
        )

        return {
            "success": bool(service_result.get("success")),
            "changed": True,
            "reservations": reservations_result,
            "config": config_result,
            "service": service_result,
            "pool": pool,
        }

    def _read(self, path: Path) -> str | None:

        try:

            return path.read_text(encoding="utf-8")

        except OSError:

            return None

    def _ensure_current_service(self) -> dict:
        """Arranca con los archivos actuales si la BD falla al construir."""

        status = self._process.status()

        if status.get("running"):

            return {"success": True, "running": True, "pid": status.get("pid"), "fallback": True}

        return self._process.start()

    def _save_last_good(self) -> None:
        config = self._read(self._config_path)

        reservations = self._read(self._reservations_path)

        if config is None or reservations is None:

            return

        try:

            self._write_atomic(self._last_good_config_path, config)

            self._write_atomic(self._last_good_reservations_path, reservations)

        except OSError as error:

            logger.warning("DHCP: no se pudo guardar última configuración buena: %s", error)

    def _restore_last_good(self) -> bool:
        config = self._read(self._last_good_config_path)

        reservations = self._read(self._last_good_reservations_path)

        if config is None or reservations is None:

            return False

        try:

            self._write_atomic(self._config_path, config)

            self._write_atomic(self._reservations_path, reservations)

            return True

        except OSError as error:

            logger.error("DHCP: no se pudo restaurar última configuración buena: %s", error)

            return False


    def _configured_threshold(self) -> int:

        try:

            from backend.shared.config.config_service import ConfigService

            return int(
                (ConfigService().get_dhcp_config() or {}).get(
                    "pool_low_threshold"
                )
                or 0
            )

        except Exception as error:
            logger.debug("reconciler._configured_threshold: %s", error)

            return 0

    def _pool_status(self, config, reservations, static_ips=()) -> dict:

        """Libres del pool + aviso si queda poco (para el panel)."""

        try:

            dhcp = {
                "pool_start": config.pool_start,
                "pool_end": config.pool_end,
                "netmask": config.netmask,
                "lease_time": config.lease_time,
                "excluded_ips": list(config.excluded_ips or []),
                "group_ip_start": config.group_ip_start,
                "group_ip_end": config.group_ip_end,
            }

            reserved = [
                item.get("ip")
                for item in reservations
                if item.get("ip")
            ]

            spec = build_pool_spec(dhcp, reserved)

            leases = read_leases(self._leases_path)

            stats = pool_stats(spec, leases, online_macs=set(), static_ips=static_ips)

            free = stats["free"]

            try:

                configured = int(self._threshold_provider() or 0)

            except Exception as error:
                logger.debug("reconciler._pool_status: %s", error)

                configured = 0

            threshold = (
                configured
                if configured > 0
                else max(
                    POOL_LOW_ABSOLUTE,
                    int(len(spec.dynamic) * POOL_LOW_RATIO),
                )
            )

            low = free < threshold

            if low:

                logger.warning(
                    "DHCP: quedan %d direcciones libres de %d dinámicas "
                    "(umbral %d). Se liberan leases sin uso; si no alcanza, se avisa.",
                    free,
                    len(spec.dynamic),
                    threshold,
                )

            return {
                "free": free,
                "threshold": threshold,
                "low": low,
                "static": stats.get("static", 0),
                "start": spec.start,
                "end": spec.end,
                "dynamic": len(spec.dynamic),
                "comfort": min(
                    len(spec.dynamic),
                    max(threshold * 2, int(len(spec.dynamic) * 0.15)),
                ),
                "zones": self._zone_pools(spec, reservations, leases),
            }

        except Exception as error:

            logger.debug("DhcpReconciler: no pude calcular el pool: %s", error)

            return {}

    def _default_zones(self) -> list[dict]:
        """Rangos DHCP de cada zona, leídos de la base."""

        from backend.core.database.session import SessionLocal
        from backend.network.zones.models.network_zone import NetworkZone

        db = SessionLocal()

        try:

            return [
                {
                    "id": zone.id,
                    "name": zone.name,
                    "start": zone.dhcp_pool_start,
                    "end": zone.dhcp_pool_end,
                    "netmask": str(
                        ipaddress.ip_network(
                            zone.network_cidr, strict=False
                        ).netmask
                    ),
                }
                for zone in db.query(NetworkZone).all()
            ]

        finally:

            db.close()

    def _zone_pools(self, main_spec, reservations, leases) -> list[dict]:
        """Capacidad de cada zona cuyo rango NO está dentro del pool principal.

        Antes solo se vigilaba el pool principal: si se llenaba el rango de
        una VLAN no había alerta ni reciclaje. Una zona cuyo rango ya está
        contenido en el principal se omite (sería contarla dos veces).
        """

        try:

            zones = self._zones_provider() or []

        except Exception as error:

            logger.debug("DhcpReconciler: sin zonas para vigilar: %s", error)

            return []

        reserved = [
            item.get("ip") for item in reservations if item.get("ip")
        ]

        result: list[dict] = []

        seen: set[tuple[int, int]] = set()

        for zone in zones:

            try:

                start = ip_to_int(zone.get("start"))
                end = ip_to_int(zone.get("end"))

                if start is None or end is None or end < start:

                    continue

                if main_spec.start <= start and end <= main_spec.end:

                    continue

                if (start, end) in seen:

                    continue

                seen.add((start, end))

                spec = build_pool_spec(
                    {
                        "pool_start": zone.get("start"),
                        "pool_end": zone.get("end"),
                        "netmask": zone.get("netmask"),
                    },
                    reserved,
                )

                status = range_pool_status(
                    spec,
                    leases,
                    absolute=POOL_LOW_ABSOLUTE,
                    ratio=POOL_LOW_RATIO,
                    cap_ratio=0.5,
                )

                status["name"] = str(zone.get("name") or f"zona-{zone.get('id')}")

                result.append(status)

            except Exception as error:

                logger.debug(
                    "DhcpReconciler: zona %s no evaluable: %s",
                    zone.get("name"),
                    error,
                )

        return result


_reconciler: DhcpReconciler | None = None


def get_dhcp_reconciler() -> DhcpReconciler:
    """Instancia única (el proceso es uno solo)."""

    global _reconciler

    if _reconciler is not None:

        return _reconciler

    from backend.core.config.paths import (
        DNSMASQ_CONFIG,
        RESERVATIONS_CONFIG,
    )
    from backend.core.dnsmasq.process_manager import dnsmasq_process_manager
    from backend.dhcp.providers.dnsmasq_reservation_provider import (
        DnsmasqReservationProvider,
    )
    from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider
    from backend.dhcp.services.dhcp_reservation_service import (
        DhcpReservationService,
    )
    from backend.dhcp.services.dhcp_pool_email_service import (
        DhcpPoolEmailService,
    )
    from backend.dhcp.services.dhcp_service import DhcpService

    dhcp_service = DhcpService()

    pool_email = DhcpPoolEmailService()

    _reconciler = DhcpReconciler(
        config_builder=dhcp_service.get_default_config,
        reservations_builder=DhcpReservationService().collect,
        provider=LinuxDhcpProvider(),
        reservation_provider=DnsmasqReservationProvider(),
        process_manager=dnsmasq_process_manager,
        config_path=DNSMASQ_CONFIG,
        reservations_path=RESERVATIONS_CONFIG,
        email_notifier=pool_email.notify,
    )

    return _reconciler
