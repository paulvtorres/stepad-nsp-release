"""Reconciliador DHCP: el ÚNICO escritor del estado de dnsmasq.

Tres fuentes de verdad, una sola salida:

    config.yaml   -> segmento (pool, gateway, lease, exclusiones)
    base de datos -> reservas por equipo y rangos de zona/grupo
    leases        -> observado (lo que dnsmasq tiene prestado)

`apply()` recalcula el estado deseado con la capa `domain/`, escribe
`dnsmasq.conf` y `reservations.conf` de forma ATÓMICA, valida con
`dnsmasq --test` y solo reinicia el proceso si el contenido cambió.

Reglas de la capa:

- Nadie fuera de aquí escribe esos dos archivos ni reinicia dnsmasq.
- Es idempotente: llamarlo N veces seguidas no reinicia nada si no hay
  cambios (un reinicio de dnsmasq corta DHCP/DNS unos segundos).
- Si la validación falla, restaura el contenido anterior y NO reinicia.
- Si el pool queda casi agotado, lo reporta (el panel lo muestra) para
  que el operador amplíe el segmento antes de que los equipos fallen.
"""

from __future__ import annotations

import hashlib
import threading

from datetime import datetime
from pathlib import Path

from backend.dhcp.domain.pool import build_pool_spec, pool_stats
from backend.dhcp.domain.conflicts import find_conflicts
from backend.dhcp.domain.leases import read_leases
from backend.dhcp.domain.neighbors import arp_mac_by_ip
from backend.shared.logging.logger import logger


# Cuántas direcciones libres se consideran "pocas" para avisar.
POOL_LOW_ABSOLUTE = 5

POOL_LOW_RATIO = 0.05


def _digest(*texts: str) -> str:

    sha = hashlib.sha256()

    for text in texts:

        sha.update(text.encode("utf-8", "replace"))

    return sha.hexdigest()


def read_arp_table() -> dict[str, str]:
    """{ip: mac} de la tabla ARP (único punto de IO de vecinos)."""

    try:

        with open("/proc/net/arp", encoding="utf-8", errors="replace") as file:

            return arp_mac_by_ip(file.read())

    except OSError:

        return {}


class DhcpReconciler:

    def __init__(
        self,
        config_builder,
        reservations_builder,
        provider,
        reservation_provider,
        process_manager,
        config_path: Path,
        reservations_path: Path,
        alert_notifier=None,
        email_notifier=None,
        threshold_provider=None,
        config_service=None,
    ):

        self._config_builder = config_builder

        self._reservations_builder = reservations_builder

        self._provider = provider

        self._reservation_provider = reservation_provider

        self._process = process_manager

        self._config_path = Path(config_path)

        self._reservations_path = Path(reservations_path)

        self._alert_notifier = alert_notifier or self._default_alert

        self._email_notifier = email_notifier

        # Umbral configurado (panel). Inyectable para tests.
        self._threshold_provider = threshold_provider or self._configured_threshold

        self._config_service = config_service

        # Racha de conflictos por IP: se remedia solo lo persistente
        # (un ARP viejo de un cambio de IP no debe sacar una IP del pool).
        self._conflict_streaks: dict[str, int] = {}

        self._lock = threading.Lock()

        self._last_digest: str | None = None

        self._state = {
            "last_apply_at": None,
            "last_ok": None,
            "last_error": None,
            "applies": 0,
            "restarts": 0,
            "skipped": 0,
            "pool_low": False,
            "conflicts": 0,
            "conflicts_signature": "",
        }

    # ------------------------------------------------------------------
    # Alertas de capacidad
    # ------------------------------------------------------------------

    def _default_alert(self, alert_type, severity, title, message) -> None:

        try:

            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                AlertService().create(
                    db,
                    alert_type=alert_type,
                    severity=severity,
                    title=title[:120],
                    message=message[:500],
                )

                db.commit()

            finally:

                db.close()

        except Exception as error:

            logger.warning("DHCP: no se pudo crear la alerta %s: %s", alert_type, error)

    def _notify_by_email(self, kind: str, pool: dict, was_low: bool, low: bool) -> None:

        if self._email_notifier is None:

            return

        try:

            self._email_notifier(
                kind,
                int(pool.get("free") or 0),
                int(pool.get("threshold") or 0),
            )

        except Exception as error:

            logger.warning("DHCP: no se pudo enviar el aviso por correo: %s", error)

    def _check_conflicts(self, config, reservations) -> list[dict]:

        """Conflictos de IP (lease vs ARP / estaticas dentro del pool).

        Se avisa UNA vez por conjunto de conflictos: si cambian, se avisa
        de nuevo (el titulo incluye las IPs para no quedar pegado al viejo).
        """

        arp = read_arp_table()

        if not arp:

            return []

        reserved = [item.get("ip") for item in reservations if item.get("ip")]

        conflicts = find_conflicts(
            read_leases("/var/lib/misc/dnsmasq.leases"),
            arp,
            reserved,
            config.pool_start,
            config.pool_end,
        )

        signature = ",".join(
            f"{item.kind}:{item.ip}" for item in conflicts
        )

        self._state["conflicts"] = len(conflicts)

        if conflicts and signature != self._state.get("conflicts_signature"):

            real = [item for item in conflicts if item.kind == "lease_mismatch"]

            if real:

                detalles = "; ".join(
                    f"{item.ip}: lease {item.lease_mac} pero responde {item.arp_mac}"
                    for item in real[:4]
                )

                self._alert_notifier(
                    "DHCP_IP_CONFLICT",
                    "critical",
                    "DHCP: IP duplicada en la red (%d)" % len(real),
                    (
                        f"{detalles}. Un equipo usa una IP estatica dentro "
                        "del pool DHCP: reservala en Dispositivos o cambiala "
                        "fuera del pool (.20-.149)."
                    ),
                )

            logger.warning(
                "DHCP: %d conflicto(s) de IP detectados (%s)",
                len(conflicts),
                signature,
            )

        self._state["conflicts_signature"] = signature

        self._remediate_conflicts(conflicts)

        return [item.to_dict() for item in conflicts]

    def _get_config_service(self):

        if self._config_service is None:

            from backend.shared.config.config_service import ConfigService

            self._config_service = ConfigService()

        return self._config_service

    def _remediate_conflicts(self, conflicts) -> None:

        """IPs en conflicto PERSISTENTE: se excluyen del pool.

        Un conflicto que se repite en dos reconciliaciones seguidas no es
        un ARP transitorio: hay dos equipos con la misma IP. Se excluye la
        direccion para que dnsmasq no la entregue nunca mas; el equipo que
        la tomo recibe otra en su proxima renovacion.
        """

        real = {
            item.ip: item
            for item in conflicts
            if item.kind == "lease_mismatch"
        }

        self._conflict_streaks = {
            ip: self._conflict_streaks.get(ip, 0) + 1 for ip in real
        }

        persistent = sorted(
            ip for ip, streak in self._conflict_streaks.items() if streak >= 2
        )

        if not persistent:

            return

        try:

            service = self._get_config_service()

            config = dict(service.get_dhcp_config() or {})

            exclusions = list(config.get("excluded_ips") or [])

            added = [ip for ip in persistent if ip not in exclusions]

            if not added:

                return

            config["excluded_ips"] = exclusions + added

            service.update_section("dhcp", config)

            logger.warning(
                "DHCP: IPs en conflicto excluidas del pool: %s", added
            )

            self._state["auto_excluded"] = added

        except Exception as error:

            logger.warning(
                "DHCP: no se pudieron excluir las IPs en conflicto: %s", error
            )

    def _notify_pool(self, pool: dict) -> None:

        """Alerta al AGOTARSE el pool y aviso cuando se recupera.

        Solo en las transiciones: una condicion que persiste no genera
        ruido (la alerta existente se mantiene viva).
        """

        if not pool:

            return

        was_low = bool(self._state.get("pool_low"))

        low = bool(pool.get("low"))

        if low and not was_low:

            self._notify_by_email("low", pool, was_low, low)

            self._alert_notifier(
                "DHCP_POOL_LOW",
                "warning",
                "DHCP: pool de IPs casi agotado",
                (
                    f"Quedan {pool.get('free')} direcciones libres "
                    f"(umbral {pool.get('threshold')}). Los equipos nuevos "
                    "pueden quedarse sin IP. Ampliá el pool (pool_end), "
                    "liberá reservas que no se usen o reducí el lease_time."
                ),
            )

        elif was_low and not low:

            self._notify_by_email("recovered", pool, was_low, low)

            self._alert_notifier(
                "DHCP_POOL_RECOVERED",
                "info",
                "DHCP: el pool de IPs tiene espacio nuevamente",
                (
                    f"Direcciones libres: {pool.get('free')} "
                    f"(umbral {pool.get('threshold')})."
                ),
            )

        self._state["pool_low"] = low

    # ------------------------------------------------------------------
    # Estado
    # ------------------------------------------------------------------

    def status(self) -> dict:

        return dict(self._state)

    def _record(self, **values) -> None:

        self._state.update(values)

        self._state["last_apply_at"] = datetime.utcnow().isoformat()

    # ------------------------------------------------------------------
    # Escritura atómica
    # ------------------------------------------------------------------

    def _write_atomic(self, path: Path, content: str) -> None:

        path.parent.mkdir(parents=True, exist_ok=True)

        tmp = path.with_suffix(path.suffix + ".tmp")

        tmp.write_text(content, encoding="utf-8")

        tmp.replace(path)

    def _restore(self, path: Path, previous: str | None) -> None:

        if previous is None:

            return

        try:

            self._write_atomic(path, previous)

        except OSError as error:

            logger.error("DHCP: no se pudo restaurar %s: %s", path, error)

    # ------------------------------------------------------------------
    # Reconciliación
    # ------------------------------------------------------------------

    def apply(self, force: bool = False) -> dict:

        with self._lock:

            return self._apply_locked(force=force)

    def _apply_locked(self, force: bool) -> dict:

        # Candado compartido con el resto del appliance: evita que otro
        # servicio (p. ej. LAN temporal) reinicie dnsmasq en medio de la
        # reescritura de la configuracion.
        from backend.shared.runtime.resource_locks import resource_locks

        with resource_locks.dnsmasq:

            return self._apply_serialized(force=force)

    def _apply_serialized(self, force: bool) -> dict:

        self._state["applies"] += 1

        config = self._config_builder()

        if config is None:

            self._record(last_ok=False, last_error="LAN no asignada")

            return {"success": False, "message": "LAN not detected"}

        reservations = self._reservations_builder()

        previous_config = self._read(self._config_path)

        previous_reservations = self._read(self._reservations_path)

        try:

            config_result = self._provider.write_config(config)

            reservations_result = self._reservation_provider.write_reservations(
                reservations
            )

        except Exception as error:

            logger.error("DHCP: fallo al escribir la configuración: %s", error)

            self._restore(self._config_path, previous_config)

            self._restore(self._reservations_path, previous_reservations)

            self._record(last_ok=False, last_error=str(error))

            return {"success": False, "error": str(error)}

        new_config = self._read(self._config_path) or ""

        new_reservations = self._read(self._reservations_path) or ""

        digest = _digest(new_config, new_reservations)

        running = bool(self._process.status().get("running"))

        conflicts = self._check_conflicts(config, reservations)

        static_ips = [
            item["ip"]
            for item in conflicts
            if item.get("kind") == "static_in_pool"
        ]

        pool = self._pool_status(config, reservations, static_ips)

        self._notify_pool(pool)

        if (
            not force
            and running
            and digest == self._last_digest
        ):

            self._state["skipped"] += 1

            self._record(last_ok=True, last_error=None)

            return {
                "success": True,
                "changed": False,
                "skipped": True,
                "reservations": reservations_result,
                "config": config_result,
                "service": self._process.status(),
                "pool": pool,
            }

        validation = self._provider.validate()

        if not validation.get("success", True):

            logger.error(
                "DHCP: configuración inválida, se restaura la anterior: %s",
                validation.get("message") or validation,
            )

            self._restore(self._config_path, previous_config)

            self._restore(self._reservations_path, previous_reservations)

            self._record(
                last_ok=False,
                last_error=(
                    validation.get("error")
                    or validation.get("output")
                    or "validación falló"
                ),
            )

            return {
                "success": False,
                "changed": False,
                "error": "invalid config",
                "validation": validation,
            }

        changed = digest != self._last_digest

        # Si ya estaba corriendo hay que REINICIAR (start() sobre un
        # proceso vivo no recarga la config); si estaba caido, arrancar.
        service_result = (
            self._process.restart() if running else self._process.start()
        )

        if changed:

            self._state["restarts"] += 1

        self._last_digest = digest

        self._record(last_ok=bool(service_result.get("success")), last_error=None)

        logger.info(
            "DHCP reconciliado: %d reservas, %d libres, reinicio=%s",
            len(reservations),
            pool.get("free", -1),
            changed,
        )

        return {
            "success": bool(service_result.get("success")),
            "changed": True,
            "reservations": reservations_result,
            "config": config_result,
            "service": service_result,
            "pool": pool,
        }

    def _read(self, path: Path) -> str | None:

        try:

            return path.read_text(encoding="utf-8")

        except OSError:

            return None

    def _configured_threshold(self) -> int:

        try:

            from backend.shared.config.config_service import ConfigService

            return int(
                (ConfigService().get_dhcp_config() or {}).get(
                    "pool_low_threshold"
                )
                or 0
            )

        except Exception:

            return 0

    def _pool_status(self, config, reservations, static_ips=()) -> dict:

        """Libres del pool + aviso si queda poco (para el panel)."""

        try:

            dhcp = {
                "pool_start": config.pool_start,
                "pool_end": config.pool_end,
                "netmask": config.netmask,
                "lease_time": config.lease_time,
                "excluded_ips": list(config.excluded_ips or []),
                "group_ip_start": config.group_ip_start,
                "group_ip_end": config.group_ip_end,
            }

            reserved = [
                item.get("ip")
                for item in reservations
                if item.get("ip")
            ]

            spec = build_pool_spec(dhcp, reserved)

            leases = read_leases("/var/lib/misc/dnsmasq.leases")

            stats = pool_stats(spec, leases, online_macs=set(), static_ips=static_ips)

            free = stats["free"]

            try:

                configured = int(self._threshold_provider() or 0)

            except Exception:

                configured = 0

            threshold = (
                configured
                if configured > 0
                else max(
                    POOL_LOW_ABSOLUTE,
                    int(len(spec.dynamic) * POOL_LOW_RATIO),
                )
            )

            low = free < threshold

            if low:

                logger.warning(
                    "DHCP: quedan %d direcciones libres de %d dinámicas "
                    "(umbral %d). Ampliá el pool o liberá reservas.",
                    free,
                    len(spec.dynamic),
                    threshold,
                )

            return {
                "free": free,
                "threshold": threshold,
                "low": low,
                "static": stats.get("static", 0),
            }

        except Exception as error:

            logger.debug("DhcpReconciler: no pude calcular el pool: %s", error)

            return {}


_reconciler: DhcpReconciler | None = None


def get_dhcp_reconciler() -> DhcpReconciler:
    """Instancia única (el proceso es uno solo)."""

    global _reconciler

    if _reconciler is not None:

        return _reconciler

    from backend.core.config.paths import (
        DNSMASQ_CONFIG,
        RESERVATIONS_CONFIG,
    )
    from backend.core.dnsmasq.process_manager import dnsmasq_process_manager
    from backend.dhcp.providers.dnsmasq_reservation_provider import (
        DnsmasqReservationProvider,
    )
    from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider
    from backend.dhcp.services.dhcp_reservation_service import (
        DhcpReservationService,
    )
    from backend.dhcp.services.dhcp_pool_email_service import (
        DhcpPoolEmailService,
    )
    from backend.dhcp.services.dhcp_service import DhcpService

    dhcp_service = DhcpService()

    pool_email = DhcpPoolEmailService()

    _reconciler = DhcpReconciler(
        config_builder=dhcp_service.get_default_config,
        reservations_builder=DhcpReservationService().collect,
        provider=LinuxDhcpProvider(),
        reservation_provider=DnsmasqReservationProvider(),
        process_manager=dnsmasq_process_manager,
        config_path=DNSMASQ_CONFIG,
        reservations_path=RESERVATIONS_CONFIG,
        email_notifier=pool_email.notify,
    )

    return _reconciler
