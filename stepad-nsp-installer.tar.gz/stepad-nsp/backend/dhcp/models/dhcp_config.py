from dataclasses import dataclass, field


@dataclass
class DhcpConfig:

    interface: str

    network: str

    netmask: str

    gateway: str

    dns_server: str

    pool_start: str

    pool_end: str

    lease_time: str

    # IPs que el DHCP no debe entregar nunca (dispositivos con IP estatica).
    excluded_ips: list[str] = field(default_factory=list)