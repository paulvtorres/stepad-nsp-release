from dataclasses import dataclass


@dataclass
class DhcpConfig:

    interface: str

    network: str

    netmask: str

    gateway: str

    dns_server: str

    pool_start: str

    pool_end: str

    lease_time: str