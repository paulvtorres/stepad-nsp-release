from dataclasses import dataclass


@dataclass
class DhcpLease:

    expires_at: int

    mac: str

    ip: str

    hostname: str | None