from dataclasses import dataclass, field


@dataclass
class DhcpCheck:

    name: str

    status: str

    message: str

    action: str | None = None


@dataclass
class DhcpDiagnosis:

    healthy: bool

    summary: str

    checks: list[DhcpCheck] = field(default_factory=list)