from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.dhcp.services.dhcp_service import DhcpService
from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider

from backend.shared.logging.logger import logger

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)


class DhcpComponent(BaseComponent):

    name = "dhcp"

    criticality = ComponentCriticality.IMPORTANT


    def __init__(self):

        self.service = DhcpService()

        self.provider = LinuxDhcpProvider()
        self.reservation_service = DhcpReservationService()

        self.process = None

        

    def start(self):

        logger.info(
            "DhcpComponent started."
        )

        result = self.service.apply_config()

        if result.get("success"):

            self.process = result.get("service", {}).get("pid")



    def stop(self):

        logger.info(
            "Stopping DHCP service."
        )


        result = self.provider.stop()


        logger.info(
            f"DHCP stopped: {result}"
        )