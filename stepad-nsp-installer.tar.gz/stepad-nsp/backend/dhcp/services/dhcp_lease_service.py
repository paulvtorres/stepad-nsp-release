from backend.dhcp.providers.dnsmasq_lease_provider import DnsmasqLeaseProvider


class DhcpLeaseService:


    def __init__(self):

        self.provider = DnsmasqLeaseProvider()


    def list_leases(self):

        return self.provider.list_leases()