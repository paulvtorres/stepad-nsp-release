import ipaddress
import logging
import time
from pathlib import Path

from datetime import datetime, timedelta, timezone

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.session import SessionLocal
from backend.dhcp.domain.leases import read_leases
from backend.dhcp.domain.neighbors import arp_mac_by_ip
from backend.network.devices.services.device_classifier import DeviceClassifier
from backend.shared.datetime_utils import utcnow

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.groups.repositories.device_group_repository import (
    DeviceGroupRepository
)

from backend.dhcp.providers.dnsmasq_reservation_provider import (
    DnsmasqReservationProvider
)


logger = logging.getLogger(__name__)


class DhcpReservationService:


    def __init__(self):

        self.provider = DnsmasqReservationProvider()

        self.zone_repository = NetworkZoneRepository()

        self.group_repository = DeviceGroupRepository()



    def _deduplicate_by_ip(self, devices):
        """
        Un mismo ip_address puede quedar guardado en mas de un
        dispositivo cuando dnsmasq reasigna la direccion a un equipo
        nuevo pero el registro viejo (ya OFFLINE) nunca se actualiza.
        Escribir dos "dhcp-host" con la misma IP hace que dnsmasq
        rechace el archivo completo y el servicio de DHCP/DNS no
        arranca. Nos quedamos con un solo dispositivo por IP:
        preferimos el que esta ONLINE y, en caso de empate, el visto
        mas recientemente.
        """

        best_by_ip = {}

        for device in devices:

            # Se deduplica por la IP RESERVADA (lo que se escribe como
            # dhcp-host), no por ip_address: exigir ip_address descartaba
            # a los equipos apagados (ip_address vacia) y su reserva
            # desaparecia del archivo.
            reserved_ip = device.permanent_ip

            if not reserved_ip:
                continue

            current = best_by_ip.get(reserved_ip)

            if current is None or self._is_more_current(device, current):
                best_by_ip[reserved_ip] = device

        return list(best_by_ip.values())

    def _is_more_current(self, candidate, current):

        candidate_online = candidate.status == "ONLINE"

        current_online = current.status == "ONLINE"

        if candidate_online != current_online:

            return candidate_online

        return (
            (candidate.last_seen or datetime.min)
            > (current.last_seen or datetime.min)
        )

    @staticmethod
    def _naive_utc(value):
        if value is None:
            return None
        if value.tzinfo is not None:
            return value.astimezone(timezone.utc).replace(tzinfo=None)
        return value

    def _active_ip_owners(self) -> dict[str, str]:
        """IP -> MAC que realmente la usa ahora (lease vigente o ARP).

        Una reserva es una preferencia: si otra MAC ya tiene esa IP, no
        se escribe como dhcp-host en esta ronda. Así el equipo reservado
        recibe una IP libre en vez de quedarse sin dirección.
        """
        now = int(time.time())
        owners: dict[str, str] = {}
        for lease in read_leases(DNSMASQ_LEASES_FILE):
            if lease.infinite or lease.expires_at > now:
                owners[lease.ip] = lease.mac.lower()
        try:
            arp = arp_mac_by_ip(Path("/proc/net/arp").read_text(encoding="utf-8"))
        except OSError:
            arp = {}
        owners.update({ip: mac.lower() for ip, mac in arp.items()})
        return owners

    def stale_reservations(self) -> list[dict]:
        """Reservas que ya no se publican por equipo offline antiguo."""

        from backend.shared.config.config_service import ConfigService

        dhcp = ConfigService().get_dhcp_config() or {}

        if not dhcp.get("reservation_cleanup_enabled", True):
            return []

        days = max(
            3,
            min(
                180,
                int(dhcp.get("reservation_cleanup_days", 14) or 14),
            ),
        )

        cutoff = utcnow() - timedelta(days=days)

        owners = self._active_ip_owners()

        db = SessionLocal()

        try:

            rows = (
                db.query(NetworkDevice)
                .filter(NetworkDevice.permanent_ip.isnot(None))
                .all()
            )

            result = []

            for device in rows:

                if getattr(device, "is_permanent", False):
                    continue

                if DeviceClassifier.is_infrastructure(
                    getattr(device, "device_type", None)
                ):
                    continue

                if not getattr(device, "last_seen", None):
                    continue

                last_seen = self._naive_utc(device.last_seen)

                if last_seen >= cutoff:
                    continue

                if owners.get(device.permanent_ip):
                    continue

                result.append(
                    {
                        "id": device.id,
                        "hostname": device.hostname,
                        "mac": device.mac_address,
                        "ip": device.permanent_ip,
                        "last_seen": last_seen.isoformat() + "Z",
                    }
                )

            return result

        finally:

            db.close()

    def collect(self):
        """Reservas deseadas segun la base de datos (sin escribir nada).

        Es la entrada del reconciliador DHCP: la base de datos es la
        fuente de verdad del estado deseado.
        """

        db = SessionLocal()

        try:

            devices = (

                db.query(NetworkDevice)

                .filter(
                    NetworkDevice.mac_address.isnot(None),
                    NetworkDevice.blocked == False,
                )

                .all()

            )

            devices = self._deduplicate_by_ip(devices)
            ip_owners = self._active_ip_owners()

            from backend.shared.config.config_service import ConfigService
            from backend.groups.constants.group_dns_ip_reserve import (
                is_group_dns_alias_ip,
            )

            dhcp_config = ConfigService().get_dhcp_config() or {}

            gateway = dhcp_config.get("gateway") or "192.168.1.1"

            cleanup_enabled = bool(
                dhcp_config.get("reservation_cleanup_enabled", True)
            )

            cleanup_days = max(
                3,
                min(
                    180,
                    int(
                        dhcp_config.get("reservation_cleanup_days", 14)
                        or 14
                    ),
                ),
            )

            stale_cutoff = utcnow() - timedelta(days=cleanup_days)

            stale_released = 0

            zones_by_id = {
                zone.id: zone
                for zone in self.zone_repository.find_all(db)
            }

            # Mapa device_id -> grupo DNS (para tag set:grpN dentro de la
            # reserva, en vez de depender de dhcp-host duplicados en
            # groups_dns.conf que rompen la asignación de IP).
            groups = self.group_repository.find_all(db)

            group_ids_by_device: dict[int, list[int]] = {}

            for group in groups:

                for device_id in self.group_repository.device_ids(
                    db, group.id
                ):

                    group_ids_by_device.setdefault(device_id, []).append(
                        group.id
                    )

            default_group_id = None

            for group in groups:

                if bool(getattr(group, "is_default", False)):

                    default_group_id = group.id

                    break

            reservations = []


            for device in devices:

                # FUENTE UNICA DE VERDAD: una reserva existe SOLO cuando el
                # usuario marco permanent_ip (reserva explícita). Los demás
                # dispositivos con IP dinamica NO se escriben como
                # dhcp-host: deben seguir cayendo en el pool dinamico del
                # DHCP. Antes se emitia dhcp-host para cualquiera con IP,
                # lo que sacaba IPs usadas del pool y generaba
                # desincronizaciones base<>archivo.
                if not device.permanent_ip:
                    continue

                # OJO: NO exigir device.ip_address. Los equipos apagados
                # tienen ip_address vacia (se limpia al no verlos por
                # ARP/lease) y su reserva desaparecia del archivo: la IP
                # quedaba excluida del pool (sin dhcp-host que la sirviera)
                # y el equipo, al encender, no podia tomarla y terminaba
                # usando la IP de otro equipo.
                reserved_ip = device.permanent_ip

                if is_group_dns_alias_ip(reserved_ip, gateway):
                    # Nunca publicar dhcp-host sobre IPs de alias de grupo.
                    continue

                owner = ip_owners.get(reserved_ip)

                device_mac = (device.mac_address or "").lower()

                if owner and owner != device_mac:
                    logger.warning(
                        "Reserva %s (%s) ocupada por %s; se usará IP dinámica "
                        "para no dejar el equipo sin red.",
                        reserved_ip,
                        device.mac_address,
                        owner,
                    )
                    continue

                if (
                    cleanup_enabled
                    and not owner
                    and not getattr(device, "is_permanent", False)
                    and not DeviceClassifier.is_infrastructure(
                        getattr(device, "device_type", None)
                    )
                    and getattr(device, "last_seen", None) is not None
                    and self._naive_utc(device.last_seen) < stale_cutoff
                ):
                    stale_released += 1
                    continue

                zone = zones_by_id.get(device.zone_id)

                # The default zone's dhcp-range is deliberately left
                # untagged (see NetworkZoneService._regenerate_zone_dhcp)
                # so brand-new, not-yet-reserved devices always have
                # somewhere to land -- reservations into it don't need
                # a tag either. Every other zone requires its tag so
                # dnsmasq's multinetting picks the right range when
                # zones share one physical wire (IP aliasing, no VLAN).
                zone_tag = (
                    f"zone{zone.id}"
                    if zone and not zone.is_default
                    else None
                )

                # Tag del grupo DNS (grpN). Un dispositivo pertenece a
                # UN SOLO grupo DNS: si el default coincide, se usa como
                # fallback; un grupo especifico (no default) siempre gana.
                device_groups = group_ids_by_device.get(device.id, [])

                group_tag = None

                for gid in device_groups:

                    if gid == default_group_id:

                        continue

                    group_tag = f"grp{gid}"

                    break

                if group_tag is None and default_group_id in device_groups:

                    group_tag = f"grp{default_group_id}"

                # IMPORTANTE: las reservas NO fijan hostname. Si se
                # escribe el nombre aquí, dnsmasq lo impone en el lease
                # por encima del que la máquina declara por DHCP y el
                # nombre queda congelado para siempre aunque el equipo
                # se renombre. El nombre debe venir siempre del cliente.
                reservations.append(

                    {
                        "mac": device.mac_address,

                        "ip": reserved_ip,

                        "hostname": "",

                        "zone_tag": zone_tag,

                        "group_tag": group_tag,

                    }

                )


            if stale_released:
                logger.info(
                    "DHCP: %d reserva(s) de equipos offline > %d días "
                    "no publicadas; IPs disponibles para el pool.",
                    stale_released,
                    cleanup_days,
                )

            # Orden determinista (IP, MAC): el reconciliador compara el
            # contenido para no reiniciar dnsmasq sin cambios.
            def _key(item):

                try:

                    return (0, int(ipaddress.ip_address(item["ip"])), item["mac"])

                except ValueError:

                    return (1, 0, item["mac"])

            return sorted(reservations, key=_key)


        finally:

            db.close()

    def synchronize(self):
        """Compatibilidad: aplica el estado deseado via reconciliador.

        El unico escritor de `reservations.conf`/`dnsmasq.conf` y el unico
        que reinicia dnsmasq es `DhcpReconciler`.
        """

        from backend.dhcp.reconciler import get_dhcp_reconciler

        result = get_dhcp_reconciler().apply()

        reservations = result.get("reservations") or {}

        return (
            reservations
            if isinstance(reservations, dict)
            else {"success": True, "total": len(reservations)}
        )