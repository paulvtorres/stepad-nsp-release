import logging

from datetime import datetime

from backend.core.database.session import SessionLocal

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.groups.repositories.device_group_repository import (
    DeviceGroupRepository
)

from backend.dhcp.providers.dnsmasq_reservation_provider import (
    DnsmasqReservationProvider
)


logger = logging.getLogger(__name__)


class DhcpReservationService:


    def __init__(self):

        self.provider = DnsmasqReservationProvider()

        self.zone_repository = NetworkZoneRepository()

        self.group_repository = DeviceGroupRepository()



    def _deduplicate_by_ip(self, devices):
        """
        Un mismo ip_address puede quedar guardado en mas de un
        dispositivo cuando dnsmasq reasigna la direccion a un equipo
        nuevo pero el registro viejo (ya OFFLINE) nunca se actualiza.
        Escribir dos "dhcp-host" con la misma IP hace que dnsmasq
        rechace el archivo completo y el servicio de DHCP/DNS no
        arranca. Nos quedamos con un solo dispositivo por IP:
        preferimos el que esta ONLINE y, en caso de empate, el visto
        mas recientemente.
        """

        best_by_ip = {}

        for device in devices:

            # Se deduplica por la IP RESERVADA (lo que se escribe como
            # dhcp-host), no por ip_address: exigir ip_address descartaba
            # a los equipos apagados (ip_address vacia) y su reserva
            # desaparecia del archivo.
            reserved_ip = device.permanent_ip

            if not reserved_ip:
                continue

            current = best_by_ip.get(reserved_ip)

            if current is None or self._is_more_current(device, current):
                best_by_ip[reserved_ip] = device

        return list(best_by_ip.values())

    def _is_more_current(self, candidate, current):

        candidate_online = candidate.status == "ONLINE"

        current_online = current.status == "ONLINE"

        if candidate_online != current_online:

            return candidate_online

        return (
            (candidate.last_seen or datetime.min)
            > (current.last_seen or datetime.min)
        )

    def collect(self):
        """Reservas deseadas segun la base de datos (sin escribir nada).

        Es la entrada del reconciliador DHCP: la base de datos es la
        fuente de verdad del estado deseado.
        """

        db = SessionLocal()

        try:

            devices = (

                db.query(NetworkDevice)

                .filter(
                    NetworkDevice.mac_address.isnot(None),
                    NetworkDevice.blocked == False,
                )

                .all()

            )

            devices = self._deduplicate_by_ip(devices)

            from backend.shared.config.config_service import ConfigService
            from backend.groups.constants.group_dns_ip_reserve import (
                is_group_dns_alias_ip,
            )

            gateway = (
                ConfigService().get_dhcp_config().get("gateway")
                or "192.168.1.1"
            )

            zones_by_id = {
                zone.id: zone
                for zone in self.zone_repository.find_all(db)
            }

            # Mapa device_id -> grupo DNS (para tag set:grpN dentro de la
            # reserva, en vez de depender de dhcp-host duplicados en
            # groups_dns.conf que rompen la asignación de IP).
            groups = self.group_repository.find_all(db)

            group_ids_by_device: dict[int, list[int]] = {}

            for group in groups:

                for device_id in self.group_repository.device_ids(
                    db, group.id
                ):

                    group_ids_by_device.setdefault(device_id, []).append(
                        group.id
                    )

            default_group_id = None

            for group in groups:

                if bool(getattr(group, "is_default", False)):

                    default_group_id = group.id

                    break

            reservations = []


            for device in devices:

                # FUENTE UNICA DE VERDAD: una reserva existe SOLO cuando el
                # usuario marco permanent_ip (reserva explícita). Los demás
                # dispositivos con IP dinamica NO se escriben como
                # dhcp-host: deben seguir cayendo en el pool dinamico del
                # DHCP. Antes se emitia dhcp-host para cualquiera con IP,
                # lo que sacaba IPs usadas del pool y generaba
                # desincronizaciones base<>archivo.
                if not device.permanent_ip:
                    continue

                # OJO: NO exigir device.ip_address. Los equipos apagados
                # tienen ip_address vacia (se limpia al no verlos por
                # ARP/lease) y su reserva desaparecia del archivo: la IP
                # quedaba excluida del pool (sin dhcp-host que la sirviera)
                # y el equipo, al encender, no podia tomarla y terminaba
                # usando la IP de otro equipo.
                reserved_ip = device.permanent_ip

                if is_group_dns_alias_ip(reserved_ip, gateway):
                    # Nunca publicar dhcp-host sobre IPs de alias de grupo.
                    continue

                zone = zones_by_id.get(device.zone_id)

                # The default zone's dhcp-range is deliberately left
                # untagged (see NetworkZoneService._regenerate_zone_dhcp)
                # so brand-new, not-yet-reserved devices always have
                # somewhere to land -- reservations into it don't need
                # a tag either. Every other zone requires its tag so
                # dnsmasq's multinetting picks the right range when
                # zones share one physical wire (IP aliasing, no VLAN).
                zone_tag = (
                    f"zone{zone.id}"
                    if zone and not zone.is_default
                    else None
                )

                # Tag del grupo DNS (grpN). Un dispositivo pertenece a
                # UN SOLO grupo DNS: si el default coincide, se usa como
                # fallback; un grupo especifico (no default) siempre gana.
                device_groups = group_ids_by_device.get(device.id, [])

                group_tag = None

                for gid in device_groups:

                    if gid == default_group_id:

                        continue

                    group_tag = f"grp{gid}"

                    break

                if group_tag is None and default_group_id in device_groups:

                    group_tag = f"grp{default_group_id}"

                # IMPORTANTE: las reservas NO fijan hostname. Si se
                # escribe el nombre aquí, dnsmasq lo impone en el lease
                # por encima del que la máquina declara por DHCP y el
                # nombre queda congelado para siempre aunque el equipo
                # se renombre. El nombre debe venir siempre del cliente.
                reservations.append(

                    {
                        "mac": device.mac_address,

                        "ip": reserved_ip,

                        "hostname": "",

                        "zone_tag": zone_tag,

                        "group_tag": group_tag,

                    }

                )


            return reservations


        finally:

            db.close()

    def synchronize(self):
        """Compatibilidad: aplica el estado deseado via reconciliador.

        El unico escritor de `reservations.conf`/`dnsmasq.conf` y el unico
        que reinicia dnsmasq es `DhcpReconciler`.
        """

        from backend.dhcp.reconciler import get_dhcp_reconciler

        result = get_dhcp_reconciler().apply()

        reservations = result.get("reservations") or {}

        return (
            reservations
            if isinstance(reservations, dict)
            else {"success": True, "total": len(reservations)}
        )