from backend.core.database.session import SessionLocal

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.dhcp.providers.dnsmasq_reservation_provider import (
    DnsmasqReservationProvider
)


class DhcpReservationService:


    def __init__(self):

        self.provider = DnsmasqReservationProvider()

        self.zone_repository = NetworkZoneRepository()



    def synchronize(self):

        db = SessionLocal()

        try:

            devices = (

                db.query(NetworkDevice)

                .filter(
                    NetworkDevice.mac_address.isnot(None)
                )

                .all()

            )

            zones_by_id = {
                zone.id: zone
                for zone in self.zone_repository.find_all(db)
            }

            reservations = []


            for device in devices:


                if not device.ip_address:

                    continue


                zone = zones_by_id.get(device.zone_id)

                # The default zone's dhcp-range is deliberately left
                # untagged (see NetworkZoneService._regenerate_zone_dhcp)
                # so brand-new, not-yet-reserved devices always have
                # somewhere to land -- reservations into it don't need
                # a tag either. Every other zone requires its tag so
                # dnsmasq's multinetting picks the right range when
                # zones share one physical wire (IP aliasing, no VLAN).
                zone_tag = (
                    f"zone{zone.id}"
                    if zone and not zone.is_default
                    else None
                )

                # IMPORTANTE: las reservas NO fijan hostname. Si se
                # escribe el nombre aquí, dnsmasq lo impone en el lease
                # por encima del que la máquina declara por DHCP y el
                # nombre queda congelado para siempre aunque el equipo
                # se renombre. El nombre debe venir siempre del cliente.
                reservations.append(

                    {
                        "mac": device.mac_address,

                        "ip": device.ip_address,

                        "hostname": "",

                        "zone_tag": zone_tag

                    }

                )


            return self.provider.write_reservations(
                reservations
            )


        finally:

            db.close()