
from backend.dhcp.providers.linux_dhcp_provider import (
    LinuxDhcpProvider
)


class DhcpProcessService:

    def __init__(self):

        self.provider = LinuxDhcpProvider()


    def start(self):

        return self.provider.start()


    def stop(self):

        return self.provider.stop()


    def status(self):

        return self.provider.status()


    def restart(self):

        # Un solo escritor: el reconciliador reescribe, valida y reinicia.
        from backend.dhcp.services.dhcp_apply import apply_dhcp_change

        result = apply_dhcp_change(force=True)

        return {
            "success": result.get("success", False),
            "pid": (result.get("service") or {}).get("pid"),
            "message": "dnsmasq reconciliado",
        }