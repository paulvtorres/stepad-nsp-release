from backend.core.dnsmasq.process_manager import (
    dnsmasq_process_manager
)

from backend.dhcp.providers.linux_dhcp_provider import (
    LinuxDhcpProvider
)


class DhcpProcessService:

    def __init__(self):

        self.provider = LinuxDhcpProvider()


    def start(self):

        return self.provider.start()


    def stop(self):

        return self.provider.stop()


    def status(self):

        return self.provider.status()


    def restart(self):

        return dnsmasq_process_manager.restart()