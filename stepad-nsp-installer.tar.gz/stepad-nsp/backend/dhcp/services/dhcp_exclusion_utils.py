"""Compatibilidad: la lógica vive en `backend.dhcp.domain.exclusions`.

Se mantiene este módulo para no romper imports existentes (providers,
servicios y tests). No agregar lógica aquí: la fuente es la capa de
dominio.
"""

from backend.dhcp.domain.exclusions import (  # noqa: F401
    expand_token,
    normalize_exclusions,
    excluded_addresses,
)

__all__ = [
    "expand_token",
    "normalize_exclusions",
    "excluded_addresses",
]
