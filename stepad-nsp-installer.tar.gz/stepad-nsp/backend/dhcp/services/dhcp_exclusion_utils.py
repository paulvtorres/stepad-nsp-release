"""Utilidades para las IPs excluidas del DHCP.

Formato aceptado por cada entrada:
  - IP individual:    192.168.60.150
  - Rango IP-IP:      192.168.60.150-192.168.60.160

Se guarda en config.yaml en forma compacta (token tal cual), y se
expande solo al generar el dhcp-range de dnsmasq.
"""

import ipaddress


def expand_token(token: str) -> list[int]:
    """Convierte un token (IP o rango) en la lista de direcciones enteras."""

    token = token.strip()

    if not token:
        return []

    if "-" in token:

        start_raw, end_raw = token.split("-", 1)

        start_raw = start_raw.strip()

        end_raw = end_raw.strip()

        if not start_raw or not end_raw:

            raise ValueError(f"Rango inválido: {token}")

        try:

            start = int(ipaddress.ip_address(start_raw))

            end = int(ipaddress.ip_address(end_raw))

        except ValueError as error:

            raise ValueError(f"Rango inválido: {token}") from error

        if end < start:

            raise ValueError(f"Rango invertido: {token}")

        return list(range(start, end + 1))

    try:

        return [int(ipaddress.ip_address(token))]

    except ValueError as error:

        raise ValueError(f"IP excluida inválida: {token}") from error


def normalize_exclusions(
    tokens: list[str],
    network: str,
    netmask: str,
    gateway: str
) -> list[str]:
    """Valida y normaliza la lista de exclusiones dentro del segmento."""

    net = ipaddress.ip_network(
        f"{network}/{netmask}",
        strict=False
    )

    gateway_int = int(ipaddress.ip_address(gateway))

    normalized = []

    seen = set()

    for raw in tokens or []:

        token = str(raw).strip()

        if not token:

            continue

        expanded = expand_token(token)

        for address_int in expanded:

            if ipaddress.ip_address(address_int) not in net:

                raise ValueError(
                    f"{token} no está dentro del segmento {net}"
                )

            if address_int == gateway_int:

                raise ValueError(
                    f"{token} incluye el gateway del NSP (.1), "
                    "no puede excluirse"
                )

        if token not in seen:

            seen.add(token)

            normalized.append(token)

    return normalized


def excluded_addresses(tokens: list[str]) -> set[int]:
    """Expande todos los tokens en el conjunto de direcciones enteras."""

    result = set()

    for token in tokens or []:

        result.update(expand_token(token))

    return result
