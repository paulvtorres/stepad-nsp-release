"""Estadísticas del segmento DHCP para el panel.

Antes sumaba `ip_address` de la base de datos: como esa IP se conserva
cuando el equipo se apaga (para el reporte), el panel marcaba "ocupadas"
direcciones que dnsmasq ya no tiene prestadas y el "libre" salía mal
(1 libre cuando había ~25).

Ahora todo sale de la capa de dominio:

- `build_pool_spec`: capacidad dinámica (pool menos exclusiones/reservas).
- `read_leases`: lo que dnsmasq tiene prestado AHORA.
- `pool_stats`: online / offline / libres con invariante
  online + offline + free == total.
"""

from __future__ import annotations

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.session import SessionLocal
from backend.dhcp.domain.leases import read_leases
from backend.dhcp.domain.neighbors import parse_arp
from backend.dhcp.domain.pool import build_pool_spec, ip_to_int, pool_stats
from backend.groups.constants.group_dns_ip_reserve import (
    free_group_ip_count,
    group_ip_capacity,
)
from backend.groups.models.device_group import DeviceGroup
from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.config.config_service import ConfigService
from backend.shared.logging.logger import logger



def online_macs_now() -> set[str]:
    """MACs presentes en la tabla ARP (equipos en linea ahora mismo)."""

    try:

        with open("/proc/net/arp", encoding="utf-8", errors="replace") as file:

            return set(parse_arp(file.read()))

    except OSError as error:

        logger.debug("dhcp_pool_stats_service: ARP ilegible: %s", error)

        return set()


class DhcpPoolStatsService:

    def __init__(self):

        self.config_service = ConfigService()

    def get_stats(self) -> dict:

        dhcp = self.config_service.get_dhcp_config() or {}

        reserved_ips: list[str] = []

        known_macs: set[str] = set()

        group_used_ips: set[str] = set()

        db = SessionLocal()

        try:

            for mac, permanent_ip in db.query(
                NetworkDevice.mac_address,
                NetworkDevice.permanent_ip,
            ).all():

                mac = (mac or "").lower()

                if mac:

                    known_macs.add(mac)

                if permanent_ip:

                    reserved_ips.append(permanent_ip)

            group_used_ips = {
                alias
                for (alias,) in db.query(DeviceGroup.dns_alias_ip).filter(
                    DeviceGroup.dns_alias_ip.isnot(None)
                ).all()
                if alias
            }

        finally:

            db.close()

        spec = build_pool_spec(dhcp, reserved_ips)

        online_macs = online_macs_now()

        leases = read_leases(DNSMASQ_LEASES_FILE)

        stats = pool_stats(spec, leases, online_macs)

        # Reserva de alias de grupos (subrango separado del pool).
        try:

            group_total = group_ip_capacity(dhcp)

        except Exception as error:

            logger.warning("dhcp_pool_stats_service: capacidad de grupos: %s", error)

            group_total = 0

        try:

            group_free = free_group_ip_count(group_used_ips, dhcp)

            group_used = max(0, group_total - group_free)

        except Exception as error:

            logger.debug("dhcp_pool_stats_service.get_stats: %s", error)

            group_used = min(group_total, len(group_used_ips))

            group_free = max(0, group_total - group_used)

        leases_not_in_db = len(
            {
                lease.ip
                for lease in leases
                if lease.mac not in known_macs
                and spec.start <= (ip_to_int(lease.ip) or -1) <= spec.end
            }
        )

        return {
            "gateway": dhcp.get("gateway"),
            "pool_start": dhcp.get("pool_start"),
            "pool_end": dhcp.get("pool_end"),
            "group_ip_start": dhcp.get("group_ip_start"),
            "group_ip_end": dhcp.get("group_ip_end"),
            "devices": {
                "total": stats["total"],
                "dynamic": stats["dynamic"],
                "leased": stats["leased"],
                "online": stats["online"],
                "offline": stats["offline"],
                "reserved": stats["reserved"],
                "free": stats["free"],
            },
            "groups": {
                "total": group_total,
                "used": group_used,
                "free": group_free,
            },
            "overall": {
                "total": stats["total"] + group_total,
                "used": stats["online"] + stats["offline"] + group_used,
                "online": stats["online"],
                "offline": stats["offline"],
                "free": stats["free"] + group_free,
            },
            "dnsmasq_leases": len(leases),
            "leases_not_in_db": leases_not_in_db,
        }
