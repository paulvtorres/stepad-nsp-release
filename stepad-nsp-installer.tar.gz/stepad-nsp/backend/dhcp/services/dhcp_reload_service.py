from backend.dhcp.services.dhcp_process_service import (
    DhcpProcessService
)


class DhcpReloadService:


    def __init__(self):

        self.process_service = DhcpProcessService()


    def reload(self):

        return self.process_service.restart()
