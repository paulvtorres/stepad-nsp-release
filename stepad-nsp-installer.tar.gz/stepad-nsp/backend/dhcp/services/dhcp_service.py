from backend.dhcp.models.dhcp_config import (
    DhcpConfig
)

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.shared.config.config_service import (
    ConfigService
)

from backend.dhcp.services.dhcp_diagnosis_service import (

    DhcpDiagnosisService

)

from backend.dhcp.services.dhcp_process_service import (

    DhcpProcessService

)

from backend.dhcp.services.dhcp_reload_service import (
    DhcpReloadService
)

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)

from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider

from backend.core.dnsmasq.process_manager import dnsmasq_process_manager

from backend.shared.logging.logger import logger

class DhcpService:


    def __init__(self):

        self.interface_service = InterfaceService()

        self.config_service = ConfigService()
        self.diagnosis_service = DhcpDiagnosisService()
        self.process_service = DhcpProcessService()
        self.reload_service = DhcpReloadService()
        self.reservation_service = DhcpReservationService()
        self.provider = LinuxDhcpProvider()

    def get_default_config(self):

        lan = self.interface_service.get_primary_lan()

        if lan is None:

            return None


        config = self.config_service.get_dhcp_config()


        return DhcpConfig(

            interface=lan.name,

            network=config["network"],

            netmask=config["netmask"],

            gateway=config["gateway"],

            dns_server=config["dns_server"],

            pool_start=config["pool_start"],

            pool_end=config["pool_end"],

            lease_time=config["lease_time"],

            excluded_ips=list(
                config.get("excluded_ips") or []
            )

        )


    def get_exclusions(self):

        config = self.config_service.get_dhcp_config()

        return list(config.get("excluded_ips") or [])


    def set_exclusions(
        self,
        ips: list[str]
    ):
        """Guarda las IPs que el DHCP no debe asignar y reaplica DHCP."""
        config = self.config_service.get_dhcp_config()

        exclusions = self._validate_exclusions(
            ips,
            network=config.get("network"),
            netmask=config.get("netmask"),
            gateway=config.get("gateway")
        )

        config["excluded_ips"] = exclusions

        self.config_service.update_section("dhcp", config)

        result = self.apply_config()

        return {
            "success": result.get("success", False),
            "excluded_ips": exclusions,
            "dhcp": result
        }


    def _validate_exclusions(
        self,
        ips: list[str],
        network: str,
        netmask: str,
        gateway: str
    ):
        from backend.dhcp.services.dhcp_exclusion_utils import (
            normalize_exclusions
        )

        return normalize_exclusions(
            ips,
            network,
            netmask,
            gateway
        )


    def apply_config(self):
        """
        The one place that makes dnsmasq actually match "what LAN is
        currently assigned". Used at boot (DhcpComponent.start()) AND
        live, right when a LAN role gets assigned through the web UI
        (see InterfaceRegistryService._sync_config_cache) -- without
        the live path, assigning LAN only moved the IP onto the
        interface; dnsmasq itself stayed down until the next full
        STEPAD restart, which isn't the behavior anyone assigning a
        role from the UI would expect.

        Safe to call with no LAN assigned: returns immediately without
        writing anything or touching dnsmasq (see get_default_config).
        """

        reservation_result = self.reservation_service.synchronize()

        config = self.get_default_config()

        if config is None:

            logger.error(
                "DHCP configuration not available. LAN not detected."
            )

            return {"success": False, "message": "LAN not detected"}

        write_result = self.provider.write_config(config)

        if dnsmasq_process_manager.status().get("running"):

            start_result = dnsmasq_process_manager.restart()

        else:

            start_result = self.provider.start()

        logger.info(
            f"DHCP applied -- reservations: {reservation_result}, "
            f"config: {write_result}, service: {start_result}"
        )

        return {

            "success": write_result.get("success", False) and start_result.get("success", False),

            "reservations": reservation_result,

            "config": write_result,

            "service": start_result

        }


    def get_status(self):

        return self.process_service.status()
    
    def diagnose(self):

        return self.diagnosis_service.diagnose()
    
    def reload(self):

        return self.reload_service.reload()
    