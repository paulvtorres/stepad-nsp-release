
from backend.dhcp.models.dhcp_config import (
    DhcpConfig
)

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.shared.config.config_service import (
    ConfigService
)

from backend.dhcp.services.dhcp_diagnosis_service import (

    DhcpDiagnosisService

)

from backend.dhcp.services.dhcp_process_service import (

    DhcpProcessService

)

from backend.dhcp.services.dhcp_reload_service import (
    DhcpReloadService
)

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)

from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider


from backend.shared.logging.logger import logger


def next_device_ip(device, real_ip):
    """IP que debe quedar en el equipo segun lease/ARP, o None si no cambia.

    - Con lease/ARP: manda esa IP (el lease es la asignacion real).
    - Sin lease/ARP (equipo apagado): NO se borra la ultima IP conocida
      (el reporte quedaba en blanco). Si nunca tuvo IP y tiene reserva, se
      usa la reservada como esperada.
    """

    if real_ip:

        return real_ip if device.ip_address != real_ip else None

    if not device.ip_address:

        expected = (device.permanent_ip or "").strip()

        if expected:

            return expected

    return None


class DhcpService:


    def __init__(self):

        self.interface_service = InterfaceService()

        self.config_service = ConfigService()
        self.diagnosis_service = DhcpDiagnosisService()
        self.process_service = DhcpProcessService()
        self.reload_service = DhcpReloadService()
        self.reservation_service = DhcpReservationService()
        self.provider = LinuxDhcpProvider()

    def get_default_config(self):

        lan = self.interface_service.get_primary_lan()

        if lan is None:

            return None


        config = self.config_service.get_dhcp_config()

        gateway = config["gateway"]

        from backend.groups.constants.group_dns_ip_reserve import (
            group_ip_bounds,
            group_ip_capacity,
            merge_group_dns_exclusions,
            validate_pool_against_group_reserve,
        )

        exclusions = merge_group_dns_exclusions(
            list(config.get("excluded_ips") or []),
            gateway,
        )

        # Las reservas NO se agregan aqui: el reconciliador las escribe
        # como `dhcp-host` y dnsmasq excluye esas direcciones del rango
        # automaticamente. Antes se hacian las DOS cosas (dhcp-host +
        # exclusion en config); al borrar una reserva, su IP quedaba
        # excluida para siempre y el pool se encogia sin motivo.
        try:
            validate_pool_against_group_reserve(
                config["pool_start"],
                config["pool_end"],
                gateway,
            )
        except ValueError as error:
            logger.warning(
                f"DHCP pool vs reserva de grupos: {error}"
            )

        try:
            g_first, g_last = group_ip_bounds(config)
            group_start = str(g_first)
            group_end = str(g_last)
            group_count = group_ip_capacity(config)
        except Exception as error:
            logger.debug("dhcp_service.get_default_config: %s", error)
            group_start = config.get("group_ip_start")
            group_end = config.get("group_ip_end")
            group_count = config.get("group_ip_count")

        return DhcpConfig(

            interface=lan.name,

            network=config["network"],

            netmask=config["netmask"],

            gateway=gateway,

            dns_server=config["dns_server"],

            pool_start=config["pool_start"],

            pool_end=config["pool_end"],

            lease_time=config["lease_time"],

            # Siempre incluye el subrango de grupos (p. ej. .10-.19)
            # para alias DNS — el DHCP no puede entregarlos a equipos.
            excluded_ips=exclusions,

            group_ip_start=group_start,

            group_ip_end=group_end,

            group_ip_count=group_count,

        )


    def get_exclusions(self):

        config = self.config_service.get_dhcp_config()

        from backend.groups.constants.group_dns_ip_reserve import (
            merge_group_dns_exclusions,
        )

        return merge_group_dns_exclusions(
            list(config.get("excluded_ips") or []),
            config.get("gateway") or "192.168.1.1",
        )


    def set_exclusions(
        self,
        ips: list[str],
        pool_start: str | None = None,
        pool_end: str | None = None,
    ):
        """Guarda las IPs que el DHCP no debe asignar y reaplica DHCP."""
        config = self.config_service.get_dhcp_config()

        from backend.groups.constants.group_dns_ip_reserve import (
            merge_group_dns_exclusions,
        )

        exclusions = self._validate_exclusions(
            ips,
            network=config.get("network"),
            netmask=config.get("netmask"),
            gateway=config.get("gateway")
        )

        # La reserva de alias de grupos no es opcional.
        exclusions = merge_group_dns_exclusions(
            exclusions,
            config.get("gateway") or "192.168.1.1",
        )

        config["excluded_ips"] = exclusions

        self.config_service.update_section("dhcp", config)

        result = self.apply_config()

        return {
            "success": result.get("success", False),
            "excluded_ips": exclusions,
            "dhcp": result
        }


    def _validate_exclusions(
        self,
        ips: list[str],
        network: str,
        netmask: str,
        gateway: str
    ):
        from backend.dhcp.services.dhcp_exclusion_utils import (
            normalize_exclusions
        )

        return normalize_exclusions(
            ips,
            network,
            netmask,
            gateway
        )


    def migrate_infinite_lease(self) -> None:
        """Pasa `lease_time` de 'infinite' a '24h' (una sola vez).

        Un lease infinito nunca se renueva ni expira: un equipo que quedo
        con la IP de otro no la suelta jamas y el dueno legitimo de la
        reserva se queda sin direccion. Con 24 h dnsmasq puede rechazar la
        renovacion (NAK) y el equipo re-pide, tomando su reserva.
        """

        try:

            config = self.config_service.get_dhcp_config()

            if str(config.get("lease_time") or "").strip().lower() != "infinite":

                return

            config["lease_time"] = "24h"

            self.config_service.update_section("dhcp", config)

            logger.warning(
                "DHCP: lease_time 'infinite' migrado a '24h' (los leases "
                "infinitos impiden liberar IPs y tomar reservas)."
            )

        except Exception as error:

            logger.warning("No se pudo migrar lease_time: %s", error)

    def apply_config(self):
        """
        The one place that makes dnsmasq actually match "what LAN is
        currently assigned". Used at boot (DhcpComponent.start()) AND
        live, right when a LAN role gets assigned through the web UI
        (see InterfaceRegistryService._sync_config_cache) -- without
        the live path, assigning LAN only moved the IP onto the
        interface; dnsmasq itself stayed down until the next full
        STEPAD restart, which isn't the behavior anyone assigning a
        role from the UI would expect.

        Safe to call with no LAN assigned: returns immediately without
        writing anything or touching dnsmasq (see get_default_config).
        """

        self.migrate_infinite_lease()

        # Un solo escritor: el reconciliador calcula el estado deseado,
        # escribe atómicamente, valida y solo reinicia si cambió.
        from backend.dhcp.reconciler import get_dhcp_reconciler

        return get_dhcp_reconciler().apply(force=True)

    def get_status(self):

        return self.process_service.status()
    
    def diagnose(self):

        return self.diagnosis_service.diagnose()
    
    def reload(self):

        return self.reload_service.reload()

    def sync_device_ips(self) -> dict:
        """Sincroniza ip_address de dispositivos con ARP/leases DHCP.

        Así, cuando un equipo renueva y toma su IP reservada, ip_address se
        actualiza solo y las referencias (Samba, ancho de banda, grupos) que
        usan ip_address cambian automáticamente a la reservada."""
        from backend.core.database.session import SessionLocal
        from backend.network.devices.models.network_device import NetworkDevice

        arp_ips = {}
        try:
            with open("/proc/net/arp") as f:
                for line in f.readlines()[1:]:
                    parts = line.split()
                    if len(parts) >= 4 and parts[2] != "0x0":
                        ip = parts[0]
                        mac = parts[3].lower()
                        if mac != "00:00:00:00:00:00":
                            arp_ips[mac] = ip
        except Exception as error:
            logger.debug("dhcp_service.sync_device_ips: %s", error)
        # Parser unico (capa de dominio): mismo resultado en panel, sync y
        # diagnosis.
        from backend.core.config.paths import DNSMASQ_LEASES_FILE
        from backend.dhcp.domain.leases import by_mac, read_leases

        lease_ips = {
            mac: lease.ip
            for mac, lease in by_mac(read_leases(DNSMASQ_LEASES_FILE)).items()
        }
        # El LEASE manda: es la asignación real del DHCP. ARP solo sirve
        # como respaldo para equipos con IP fija (sin lease).
        real_ips = {**arp_ips, **lease_ips}

        db = SessionLocal()
        try:
            devices = (
                db.query(NetworkDevice)
                .filter(NetworkDevice.mac_address.isnot(None))
                .all()
            )
            updated = 0
            cleared = 0
            for device in devices:
                mac = (device.mac_address or "").lower()
                real_ip = real_ips.get(mac)
                next_ip = next_device_ip(device, real_ip)
                if next_ip is not None:
                    device.ip_address = next_ip
                    updated += 1
            db.commit()
            return {
                "success": True,
                "updated": updated,
                "cleared": cleared,
                "arp_count": len(arp_ips),
                "lease_count": len(lease_ips),
            }
        finally:
            db.close()
    
