
from backend.dhcp.models.dhcp_config import (
    DhcpConfig
)

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.shared.config.config_service import (
    ConfigService
)

from backend.dhcp.services.dhcp_diagnosis_service import (

    DhcpDiagnosisService

)

from backend.dhcp.services.dhcp_process_service import (

    DhcpProcessService

)

from backend.dhcp.services.dhcp_reload_service import (
    DhcpReloadService
)

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)

from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider


from backend.shared.logging.logger import logger

from backend.shared.datetime_utils import utcnow


def next_device_ip(device, real_ip):
    """IP que debe quedar en el equipo segun lease/ARP, o None si no cambia.

    - Con lease/ARP: manda esa IP (el lease es la asignacion real).
    - Sin lease/ARP (equipo apagado): NO se borra la ultima IP conocida
      (el reporte quedaba en blanco). Si nunca tuvo IP y tiene reserva, se
      usa la reservada como esperada.
    """

    if real_ip:

        return real_ip if device.ip_address != real_ip else None

    if not device.ip_address:

        expected = (device.permanent_ip or "").strip()

        if expected:

            return expected

    return None


class DhcpService:


    def __init__(self):

        self.interface_service = InterfaceService()

        self.config_service = ConfigService()
        self.diagnosis_service = DhcpDiagnosisService()
        self.process_service = DhcpProcessService()
        self.reload_service = DhcpReloadService()
        self.reservation_service = DhcpReservationService()
        self.provider = LinuxDhcpProvider()

    def diagnostics_readonly(self) -> dict:
        """Diagnóstico DHCP sin tocar configuración, pool ni servicio."""

        import ipaddress
        from datetime import datetime, timezone
        from pathlib import Path

        from backend.core.config.paths import DNSMASQ_LOG_FILE
        from backend.dhcp.services.dhcp_health_service import DhcpHealthService
        from backend.dhcp.services.dhcp_pool_stats_service import DhcpPoolStatsService

        config = self.config_service.get_dhcp_config() or {}

        health = DhcpHealthService().inspect()

        pool = DhcpPoolStatsService().get_stats()

        auto_entries = list(config.get("auto_excluded_ips") or [])

        now = datetime.now(timezone.utc)

        active_auto = []

        expired_auto = []

        for item in auto_entries:

            if not isinstance(item, dict):

                continue

            until = str(item.get("until") or "").replace("Z", "+00:00")

            try:

                parsed = datetime.fromisoformat(until)

                if parsed.tzinfo is None:

                    parsed = parsed.replace(tzinfo=timezone.utc)

            except ValueError:

                expired_auto.append(item)

                continue

            (active_auto if parsed > now else expired_auto).append(item)

        duplicates = []

        zones_overlap = []

        stale_reservations = []

        inactive_leases = []

        try:

            from backend.core.database.session import SessionLocal
            from backend.network.devices.models.network_device import NetworkDevice
            from backend.network.zones.models.network_zone import NetworkZone

            db = SessionLocal()

            try:

                from sqlalchemy import func

                rows = (
                    db.query(
                        NetworkDevice.ip_address,
                        func.count(NetworkDevice.id),
                    )
                    .filter(NetworkDevice.ip_address.isnot(None))
                    .filter(func.trim(NetworkDevice.ip_address) != "")
                    .group_by(NetworkDevice.ip_address)
                    .having(func.count(NetworkDevice.id) > 1)
                    .all()
                )

                duplicates = [
                    {"ip": ip, "count": int(count)}
                    for ip, count in rows
                ]

                try:

                    start = int(ipaddress.ip_address(config["pool_start"]))

                    end = int(ipaddress.ip_address(config["pool_end"]))

                except (KeyError, ValueError):

                    start = end = 0

                for zone in db.query(NetworkZone).all():

                    if not zone.is_default:

                        continue

                    try:

                        z_start = int(ipaddress.ip_address(zone.dhcp_pool_start))

                        z_end = int(ipaddress.ip_address(zone.dhcp_pool_end))

                    except ValueError:

                        continue

                    if (start, end) == (z_start, z_end):

                        continue

                    if start and z_start <= end and start <= z_end:

                        zones_overlap.append(
                            {
                                "zone": zone.name,
                                "zone_pool": f"{zone.dhcp_pool_start}-{zone.dhcp_pool_end}",
                                "main_pool": f"{config.get('pool_start')}-{config.get('pool_end')}",
                            }
                        )

            finally:

                db.close()

        except Exception as error:

            logger.debug("dhcp_service.diagnostics_readonly: %s", error)

        try:

            stale_reservations = self.reservation_service.stale_reservations()

        except Exception as error:

            logger.debug("dhcp_service.stale_reservations: %s", error)

        try:

            import time

            from backend.core.config.paths import DNSMASQ_LEASES_FILE
            from backend.dhcp.domain.leases import read_leases
            from backend.dhcp.reconciler import read_arp_table

            arp_ips = set(read_arp_table())

            now_ts = int(time.time())

            for lease in read_leases(DNSMASQ_LEASES_FILE):

                if lease.ip in arp_ips:
                    continue

                inactive_leases.append(
                    {
                        "ip": lease.ip,
                        "mac": lease.mac,
                        "hostname": lease.hostname,
                        "expires_in_minutes": (
                            None
                            if lease.infinite
                            else max(0, int((lease.expires_at - now_ts) / 60))
                        ),
                    }
                )

        except Exception as error:

            logger.debug("dhcp_service.inactive_leases: %s", error)

        naks = 0

        no_address = 0

        try:

            path = Path(DNSMASQ_LOG_FILE)

            with path.open("rb") as handle:

                handle.seek(0, 2)

                size = handle.tell()

                handle.seek(max(0, size - 200_000))

                text = handle.read().decode("utf-8", errors="replace")

            tail = text.splitlines()[-1000:]

            for line in tail:

                low = line.lower()

                if "dhcpnak" in low:

                    naks += 1

                if "ninguna dirección disponible" in low or "no address available" in low:

                    no_address += 1

        except OSError:

            pass

        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "health": health,
            "pool": {
                "free": (pool.get("devices") or {}).get("free"),
                "leased": (pool.get("devices") or {}).get("leased"),
                "reserved": (pool.get("devices") or {}).get("reserved"),
                "conflicts": len(pool.get("static_in_pool") or []),
            },
            "auto_exclusions": {
                "active": active_auto,
                "expired": expired_auto,
            },
            "duplicates": duplicates,
            "zones_overlap": zones_overlap,
            "stale_reservations": stale_reservations,
            "inactive_leases": inactive_leases,
            "log_tail": {
                "lines": 1000,
                "naks": naks,
                "no_address": no_address,
            },
        }

    def connected_ips(self) -> dict:
        """Listado temporal autoritativo: ARP + lease + reserva + conflicto."""

        import ipaddress

        from backend.core.config.paths import DNSMASQ_LEASES_FILE
        from backend.dhcp.domain.conflicts import find_conflicts
        from backend.dhcp.domain.leases import read_leases
        from backend.dhcp.domain.neighbors import arp_mac_by_ip

        config = self.config_service.get_dhcp_config() or {}

        try:

            leases = read_leases(DNSMASQ_LEASES_FILE)

        except Exception:

            leases = []

        try:

            with open("/proc/net/arp", encoding="utf-8", errors="replace") as file:

                arp = arp_mac_by_ip(file.read())

        except OSError:

            arp = {}

        devices = []

        try:

            from backend.core.database.session import SessionLocal
            from backend.network.devices.models.network_device import NetworkDevice

            db = SessionLocal()

            try:

                devices = db.query(
                    NetworkDevice.ip_address,
                    NetworkDevice.mac_address,
                    NetworkDevice.hostname,
                    NetworkDevice.display_name,
                    NetworkDevice.status,
                    NetworkDevice.permanent_ip,
                ).all()

            finally:

                db.close()

        except Exception as error:

            logger.debug("dhcp_service.connected_ips: %s", error)

        by_ip = {}

        for ip, mac, hostname, display_name, status, permanent_ip in devices:

            if not ip:

                continue

            by_ip[ip] = {
                "mac": (mac or "").lower(),
                "hostname": hostname or display_name or "",
                "device_status": status,
                "reserved": bool(permanent_ip),
                "permanent_ip": permanent_ip or "",
            }

        rows = {}

        def row_for(ip):

            if ip not in rows:

                rows[ip] = {
                    "ip": ip,
                    "mac": "",
                    "hostname": "",
                    "online": False,
                    "source": [],
                    "leased": False,
                    "reserved": False,
                    "lease_expires_at": None,
                    "conflict": None,
                }

            return rows[ip]

        for item in leases:

            row = row_for(item.ip)

            row["leased"] = True

            row["mac"] = row["mac"] or item.mac.lower()

            row["hostname"] = row["hostname"] or (item.hostname or "")

            row["lease_expires_at"] = (
                "infinite" if item.infinite else item.expires_at
            )

            row["source"].append("DHCP")

        for ip, mac in arp.items():

            row = row_for(ip)

            row["online"] = True

            row["mac"] = row["mac"] or mac.lower()

            row["source"].append("ARP")

        for ip, info in by_ip.items():

            row = row_for(ip)

            row["reserved"] = bool(info["reserved"])

            row["hostname"] = row["hostname"] or info["hostname"]

            if info["reserved"]:

                row["source"].append("Reserva")

        reserved = [info["permanent_ip"] for info in by_ip.values() if info["permanent_ip"]]

        conflicts = find_conflicts(
            leases,
            arp,
            reserved,
            config.get("pool_start"),
            config.get("pool_end"),
        )

        conflict_by_ip = {item.ip: item.kind for item in conflicts}

        for ip, row in rows.items():

            row["conflict"] = conflict_by_ip.get(ip)

            row["online"] = bool(row["online"])

            row["source"] = "+".join(dict.fromkeys(row["source"])) or "Desconocido"

        def sort_key(row):

            try:

                return (0, int(ipaddress.ip_address(row["ip"])))

            except ValueError:

                return (1, row["ip"])

        ordered = sorted(rows.values(), key=sort_key)

        return {
            "generated_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
            "pool_start": config.get("pool_start"),
            "pool_end": config.get("pool_end"),
            "total": len(ordered),
            "online": sum(1 for row in ordered if row["online"]),
            "leased": sum(1 for row in ordered if row["leased"]),
            "reserved": sum(1 for row in ordered if row["reserved"]),
            "conflicts": sum(1 for row in ordered if row["conflict"]),
            "rows": ordered,
        }

    def get_default_config(self):

        lan = self.interface_service.get_primary_lan()

        if lan is None:

            return None


        config = self.config_service.get_dhcp_config()

        gateway = config["gateway"]

        from backend.groups.constants.group_dns_ip_reserve import (
            group_ip_bounds,
            group_ip_capacity,
            merge_group_dns_exclusions,
            validate_pool_against_group_reserve,
        )

        exclusions = merge_group_dns_exclusions(
            list(config.get("excluded_ips") or [])
            + self._auto_excluded_ips(config),
            gateway,
        )

        # Las reservas NO se agregan aqui: el reconciliador las escribe
        # como `dhcp-host` y dnsmasq excluye esas direcciones del rango
        # automaticamente. Antes se hacian las DOS cosas (dhcp-host +
        # exclusion en config); al borrar una reserva, su IP quedaba
        # excluida para siempre y el pool se encogia sin motivo.
        try:
            validate_pool_against_group_reserve(
                config["pool_start"],
                config["pool_end"],
                gateway,
            )
        except ValueError as error:
            logger.warning(
                f"DHCP pool vs reserva de grupos: {error}"
            )

        try:
            g_first, g_last = group_ip_bounds(config)
            group_start = str(g_first)
            group_end = str(g_last)
            group_count = group_ip_capacity(config)
        except Exception as error:
            logger.debug("dhcp_service.get_default_config: %s", error)
            group_start = config.get("group_ip_start")
            group_end = config.get("group_ip_end")
            group_count = config.get("group_ip_count")

        return DhcpConfig(

            interface=lan.name,

            network=config["network"],

            netmask=config["netmask"],

            gateway=gateway,

            dns_server=config["dns_server"],

            pool_start=config["pool_start"],

            pool_end=config["pool_end"],

            lease_time=config["lease_time"],

            # Siempre incluye el subrango de grupos (p. ej. .10-.19)
            # para alias DNS — el DHCP no puede entregarlos a equipos.
            excluded_ips=exclusions,

            group_ip_start=group_start,

            group_ip_end=group_end,

            group_ip_count=group_count,

        )


    def _auto_excluded_ips(self, config) -> list[str]:
        """Exclusiones temporales de conflictos aún vigentes."""

        from datetime import datetime, timezone

        now = datetime.now(timezone.utc)

        result = []

        for item in config.get("auto_excluded_ips") or []:

            if not isinstance(item, dict):

                continue

            ip = str(item.get("ip") or "").strip()

            until = str(item.get("until") or "").strip()

            if not ip or not until:

                continue

            try:

                parsed = datetime.fromisoformat(until.replace("Z", "+00:00"))

                if parsed.tzinfo is None:

                    parsed = parsed.replace(tzinfo=timezone.utc)

                if parsed > now:

                    result.append(ip)

            except ValueError:

                continue

        return result

    def get_exclusions(self):

        config = self.config_service.get_dhcp_config()

        from backend.groups.constants.group_dns_ip_reserve import (
            merge_group_dns_exclusions,
        )

        return merge_group_dns_exclusions(
            list(config.get("excluded_ips") or []),
            config.get("gateway") or "192.168.1.1",
        )


    def set_exclusions(
        self,
        ips: list[str],
        pool_start: str | None = None,
        pool_end: str | None = None,
    ):
        """Guarda las IPs que el DHCP no debe asignar y reaplica DHCP."""
        config = self.config_service.get_dhcp_config()

        from backend.groups.constants.group_dns_ip_reserve import (
            merge_group_dns_exclusions,
        )

        exclusions = self._validate_exclusions(
            ips,
            network=config.get("network"),
            netmask=config.get("netmask"),
            gateway=config.get("gateway")
        )

        # La reserva de alias de grupos no es opcional.
        exclusions = merge_group_dns_exclusions(
            exclusions,
            config.get("gateway") or "192.168.1.1",
        )

        config["excluded_ips"] = exclusions

        self.config_service.update_section("dhcp", config)

        result = self.apply_config()

        return {
            "success": result.get("success", False),
            "excluded_ips": exclusions,
            "dhcp": result
        }


    def _validate_exclusions(
        self,
        ips: list[str],
        network: str,
        netmask: str,
        gateway: str
    ):
        from backend.dhcp.domain.exclusions import normalize_exclusions

        return normalize_exclusions(
            ips,
            network,
            netmask,
            gateway
        )


    def auto_expand_pool_if_enabled(self) -> dict:
        """Amplia pool_end solo si el operador lo habilito explicitamente."""

        import ipaddress

        config = dict(self.config_service.get_dhcp_config() or {})

        if not config.get("pool_auto_expand_enabled", False):

            return {"success": True, "expanded": False, "reason": "disabled"}

        maximum_raw = str(config.get("pool_auto_expand_max") or "").strip()

        if not maximum_raw:

            return {"success": True, "expanded": False, "reason": "sin maximo"}

        try:

            network = ipaddress.ip_network(
                f"{config['network']}/{config['netmask']}", strict=False
            )

            current_end = ipaddress.ip_address(config["pool_end"])

            maximum = ipaddress.ip_address(maximum_raw)

            if maximum not in network or maximum == network.broadcast_address:

                return {"success": False, "expanded": False, "reason": "maximo invalido"}

            step = max(1, min(254, int(config.get("pool_auto_expand_step") or 10)))

            threshold = max(1, int(config.get("pool_low_threshold") or 10))

        except (KeyError, ValueError) as error:

            return {"success": False, "expanded": False, "reason": str(error)}

        from backend.dhcp.services.dhcp_pool_stats_service import (
            DhcpPoolStatsService,
        )

        stats = DhcpPoolStatsService().get_stats()

        free = int((stats.get("devices") or {}).get("free") or 0)

        if free > threshold:

            return {"success": True, "expanded": False, "reason": "pool suficiente", "free": free}

        new_end = min(current_end + step, maximum)

        if new_end <= current_end:

            return {"success": True, "expanded": False, "reason": "pool en maximo", "free": free}

        old_end = config["pool_end"]

        config["pool_end"] = str(new_end)

        self.config_service.update_section("dhcp", config)

        result = self.apply_config()

        if not result.get("success"):

            config["pool_end"] = old_end

            self.config_service.update_section("dhcp", config)

            return {"success": False, "expanded": False, "reason": "apply fallo", "result": result}

        try:

            from backend.core.database.session import SessionLocal
            from backend.alerts.services.alert_service import AlertService

            db = SessionLocal()

            try:

                AlertService().create(
                    db,
                    alert_type="DHCP_POOL_EXPANDED",
                    severity="info",
                    title="Pool DHCP ampliado automáticamente",
                    message=(
                        f"El pool pasó de {old_end} a {new_end} porque quedaban "
                        f"{free} IP(s) libres (umbral {threshold})."
                    ),
                )

                db.commit()

            finally:

                db.close()

        except Exception as error:

            logger.warning("No se pudo alertar ampliación DHCP: %s", error)

        logger.warning(
            "DHCP: pool ampliado automáticamente de %s a %s (libres=%s)",
            old_end, new_end, free,
        )

        return {"success": True, "expanded": True, "old_end": old_end, "new_end": str(new_end), "free": free}

    def migrate_infinite_lease(self) -> None:
        """Pasa `lease_time` de 'infinite' a '24h' (una sola vez).

        Un lease infinito nunca se renueva ni expira: un equipo que quedo
        con la IP de otro no la suelta jamas y el dueno legitimo de la
        reserva se queda sin direccion. Con 24 h dnsmasq puede rechazar la
        renovacion (NAK) y el equipo re-pide, tomando su reserva.
        """

        try:

            config = self.config_service.get_dhcp_config()

            if str(config.get("lease_time") or "").strip().lower() != "infinite":

                return

            config["lease_time"] = "24h"

            self.config_service.update_section("dhcp", config)

            logger.warning(
                "DHCP: lease_time 'infinite' migrado a '24h' (los leases "
                "infinitos impiden liberar IPs y tomar reservas)."
            )

        except Exception as error:

            logger.warning("No se pudo migrar lease_time: %s", error)

    def apply_config(self):
        """
        The one place that makes dnsmasq actually match "what LAN is
        currently assigned". Used at boot (DhcpComponent.start()) AND
        live, right when a LAN role gets assigned through the web UI
        (see InterfaceRegistryService._sync_config_cache) -- without
        the live path, assigning LAN only moved the IP onto the
        interface; dnsmasq itself stayed down until the next full
        STEPAD restart, which isn't the behavior anyone assigning a
        role from the UI would expect.

        Safe to call with no LAN assigned: returns immediately without
        writing anything or touching dnsmasq (see get_default_config).
        """

        self.migrate_infinite_lease()

        # Un solo escritor: el reconciliador calcula el estado deseado,
        # escribe atómicamente, valida y solo reinicia si cambió.
        from backend.dhcp.reconciler import get_dhcp_reconciler

        return get_dhcp_reconciler().apply(force=True)

    def get_status(self):

        return self.process_service.status()
    
    def diagnose(self):

        return self.diagnosis_service.diagnose()
    
    def reload(self):

        return self.reload_service.reload()

    def sync_device_ips(self) -> dict:
        """Sincroniza ip_address de dispositivos con ARP/leases DHCP.

        Así, cuando un equipo renueva y toma su IP reservada, ip_address se
        actualiza solo y las referencias (Samba, ancho de banda, grupos) que
        usan ip_address cambian automáticamente a la reservada."""
        from backend.core.database.session import SessionLocal
        from backend.network.devices.models.network_device import NetworkDevice

        arp_ips = {}
        try:
            with open("/proc/net/arp") as f:
                for line in f.readlines()[1:]:
                    parts = line.split()
                    if len(parts) >= 4 and parts[2] != "0x0":
                        ip = parts[0]
                        mac = parts[3].lower()
                        if mac != "00:00:00:00:00:00":
                            arp_ips[mac] = ip
        except Exception as error:
            logger.debug("dhcp_service.sync_device_ips: %s", error)
        # Parser unico (capa de dominio): mismo resultado en panel, sync y
        # diagnosis.
        from backend.core.config.paths import DNSMASQ_LEASES_FILE
        from backend.dhcp.domain.leases import by_mac, read_leases

        lease_ips = {
            mac: lease.ip
            for mac, lease in by_mac(read_leases(DNSMASQ_LEASES_FILE)).items()
        }
        # El LEASE manda: es la asignación real del DHCP. ARP solo sirve
        # como respaldo para equipos con IP fija (sin lease).
        real_ips = {**arp_ips, **lease_ips}

        db = SessionLocal()
        try:
            devices = (
                db.query(NetworkDevice)
                .filter(NetworkDevice.mac_address.isnot(None))
                .all()
            )
            updated = 0
            cleared = 0
            for device in devices:
                mac = (device.mac_address or "").lower()
                real_ip = real_ips.get(mac)
                next_ip = next_device_ip(device, real_ip)
                if next_ip is not None:
                    device.ip_address = next_ip
                    updated += 1
            db.commit()
            return {
                "success": True,
                "updated": updated,
                "cleared": cleared,
                "arp_count": len(arp_ips),
                "lease_count": len(lease_ips),
            }
        finally:
            db.close()
    
