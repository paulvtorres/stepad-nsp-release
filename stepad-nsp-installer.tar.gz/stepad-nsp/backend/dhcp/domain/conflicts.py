"""Conflictos de direccionamiento: mismo IP en dos equipos.

Dos casos:

- `lease_mismatch`: una IP con lease DHCP la responde OTRA MAC en la LAN.
  Es un conflicto real (el dueño del lease no recibe sus respuestas).
  Pasa cuando un equipo usa una IP estatica dentro del pool.
- `static_in_pool`: una IP del pool la usa un equipo que no tiene lease ni
  reserva. Todavia no hay conflicto, pero dnsmasq puede entregarla a otro
  equipo en cualquier momento.

Funciones puras: reciben leases, tabla ARP y reservas.
"""

from __future__ import annotations

import ipaddress

from dataclasses import dataclass


@dataclass(frozen=True)
class Conflict:

    kind: str  # "lease_mismatch" | "static_in_pool"
    ip: str
    lease_mac: str | None
    arp_mac: str

    def to_dict(self) -> dict:

        return {
            "kind": self.kind,
            "ip": self.ip,
            "lease_mac": self.lease_mac,
            "arp_mac": self.arp_mac,
        }


def find_conflicts(
    leases,
    arp_mac_by_ip: dict[str, str],
    reserved_ips,
    pool_start: str | None,
    pool_end: str | None,
) -> list[Conflict]:
    """Detecta conflictos reales y estaticas dentro del pool."""

    lease_mac_by_ip = {lease.ip: lease.mac for lease in leases}

    reserved = set(reserved_ips or ())

    try:

        start = int(ipaddress.ip_address(pool_start))

        end = int(ipaddress.ip_address(pool_end))

    except (TypeError, ValueError):

        start = end = 0

    conflicts: list[Conflict] = []

    for ip, arp_mac in (arp_mac_by_ip or {}).items():

        lease_mac = lease_mac_by_ip.get(ip)

        if lease_mac and lease_mac != arp_mac:

            conflicts.append(
                Conflict("lease_mismatch", ip, lease_mac, arp_mac)
            )

            continue

        if lease_mac or ip in reserved:

            continue

        try:

            value = int(ipaddress.ip_address(ip))

        except ValueError:

            continue

        if start and start <= value <= end:

            conflicts.append(
                Conflict("static_in_pool", ip, None, arp_mac)
            )

    conflicts.sort(
        key=lambda item: (item.kind != "lease_mismatch", int(ipaddress.ip_address(item.ip)))
    )

    return conflicts
