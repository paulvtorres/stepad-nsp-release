"""Clasificación de eventos del log de dnsmasq (pura)."""

from __future__ import annotations

import re

_MAC_RE = re.compile(r"([0-9a-f]{2}(?::[0-9a-f]{2}){5})", re.IGNORECASE)


def log_has_no_address(text: str) -> bool:

    low = (text or "").lower()

    return (
        "no address available" in low
        or "ninguna dirección disponible" in low
    )


def mac_from_log(text: str) -> str:

    match = _MAC_RE.search(text or "")

    return match.group(1).lower() if match else ""
