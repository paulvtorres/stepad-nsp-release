"""Clasificación de eventos del log de dnsmasq (pura)."""

from __future__ import annotations

import re

_MAC_RE = re.compile(r"([0-9a-f]{2}(?::[0-9a-f]{2}){5})", re.IGNORECASE)


def log_has_no_address(text: str) -> bool:

    low = (text or "").lower()

    return (
        "no address available" in low
        or "ninguna dirección disponible" in low
    )


def mac_from_log(text: str) -> str:

    match = _MAC_RE.search(text or "")

    return match.group(1).lower() if match else ""


_DHCP_IFACE_RE = re.compile(r"DHCP[A-Z]+\(([^)\s]+)\)", re.IGNORECASE)


def no_address_events(text: str) -> list[dict]:
    """Eventos «no address available» del log: [{mac, interface}] (pura).

    dnsmasq escribe `DHCPDISCOVER(enp3s0) aa:bb:.. no address available`: la
    interfaz entre paréntesis dice por qué red pidió el equipo, y por tanto
    qué pool (principal o de una zona) se quedó sin IPs. Se lee de LA línea
    del evento, no del primer MAC del fragmento (que podía ser de otro evento).
    """

    events: list[dict] = []

    for line in (text or "").splitlines():

        if not log_has_no_address(line):

            continue

        match = _DHCP_IFACE_RE.search(line)

        events.append(
            {
                "mac": mac_from_log(line),
                "interface": match.group(1) if match else "",
            }
        )

    return events
