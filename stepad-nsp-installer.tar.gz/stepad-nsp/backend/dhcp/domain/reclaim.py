"""Liberación automática de leases viejos cuando el pool se agota.

Solo se liberan direcciones que NO pueden estar en uso:

- su equipo esta OFFLINE segun la presencia (sin ARP/DNS/ping recientes;
  el ARP crudo no sirve: el kernel conserva entradas de equipos ausentes),
- no son reservas (permanent_ip),
- su equipo se vio por última vez antes del corte (N días).

Funciones puras: reciben los datos y devuelven qué IPs liberar.
"""

from __future__ import annotations

from datetime import datetime, timedelta


# Orden de reciclaje: primero lo que menos probablemente vuelve. SOLO ordena
# entre candidatos ya elegibles (OFFLINE, sin reserva, no infraestructura,
# pasada la ventana de inactividad): nunca vuelve elegible a un equipo.
TIER_TRANSIENT = 0  # sin nombre y MAC aleatoria o visita de una sola vez
TIER_RECENT = 1  # sin nombre, conocido hace poco
TIER_UNNAMED = 2  # sin nombre, conocido hace días (o sin datos)
TIER_NAMED = 3  # el admin le puso nombre
TIER_COMPANY = 4  # activo de la empresa

SHORT_VISIT = timedelta(hours=1)

RECENT_DEVICE = timedelta(days=3)


def is_random_mac(mac: str | None) -> bool:
    """MAC «administrada localmente» (bit 0x02 del primer byte).

    Es lo que usan los celulares con dirección privada/aleatoria (cambia por
    red o con el tiempo) y también algunas VMs: no identifica un equipo fijo.
    """

    try:

        parts = (mac or "").strip().split(":")

        if len(parts) != 6:

            return False

        return bool(int(parts[0], 16) & 0x02)

    except ValueError:

        return False


def reclaim_tier(mac: str | None, meta: dict) -> int:
    """Qué tan probable es que el equipo vuelva (0 = lo menos probable)."""

    if meta.get("company"):

        return TIER_COMPANY

    if meta.get("named"):

        return TIER_NAMED

    first = meta.get("first_seen")

    last = meta.get("last_seen")

    span = (last - first) if (first and last) else None

    if is_random_mac(mac) or (span is not None and span < SHORT_VISIT):

        return TIER_TRANSIENT

    if span is not None and span < RECENT_DEVICE:

        return TIER_RECENT

    return TIER_UNNAMED


def select_reclaimable(
    leases,
    arp_ips,
    meta_by_mac,
    cutoff,
    limit: int | None = None,
    max_tier: int | None = None,
) -> list[str]:
    """IPs de leases liberables.

    `meta_by_mac`: {mac: {"last_seen": datetime|None, "permanent": str}}
    `cutoff`: fecha/hora; los equipos vistos antes se consideran inactivos.
    """

    arp_ips = set(arp_ips or ())

    candidates = []

    for lease in leases:

        if lease.ip in arp_ips:

            continue

        meta = (meta_by_mac or {}).get(lease.mac)

        if not meta:

            # Sin registro en la base no se puede demostrar inactividad.
            continue

        if (meta.get("permanent") or "").strip():

            continue

        if meta.get("protected"):

            continue

        # La presencia (ARP + DNS + ping, ver DevicePresenceService) manda:
        # solo se libera a un equipo OFFLINE. PROBABLE/UNKNOWN no se tocan.
        # Sin el dato (tests/compat) se asume OFFLINE.
        if (meta.get("presence") or "OFFLINE") != "OFFLINE":

            continue

        last_seen = meta.get("last_seen")

        if last_seen is None or last_seen >= cutoff:

            continue

        tier = reclaim_tier(lease.mac, meta)

        # Limpieza anticipada: solo equipos que casi seguro no vuelven.
        if max_tier is not None and tier > max_tier:

            continue

        candidates.append(
            (
                tier,
                last_seen,
                lease.ip,
                lease.mac,
            )
        )

    candidates.sort(
        key=lambda item: (
            item[0],
            item[1] or datetime.min,
            item[2],
        )
    )

    result = [item[2] for item in candidates]

    if limit is not None:

        return result[: max(0, int(limit))]

    return result
