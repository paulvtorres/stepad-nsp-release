"""Pronóstico de agotamiento del pool (puro, sin IO).

Una serie es una lista de (epoch_segundos, ips_libres). Se ajusta una recta por
mínimos cuadrados y no solo «primera vs última»: el reciclaje hace dientes de
sierra (el pool baja, se liberan IPs, sube) y comparar dos puntos subestima o
sobrestima según dónde caigan.
"""

from __future__ import annotations

WINDOW_SECONDS = 3600

MIN_GAP_SECONDS = 60

MAX_POINTS = 240

MIN_POINTS = 4

MIN_SPAN_SECONDS = 300

MIN_RATE_PER_HOUR = 1.0


def prune(samples, now: float, window: float = WINDOW_SECONDS) -> list[tuple[float, int]]:
    """Descarta lo viejo (y lo del futuro: reloj atrasado) y limita el tamaño."""

    kept = [
        (float(stamp), int(free))
        for stamp, free in samples or ()
        if 0 <= now - float(stamp) <= window
    ]

    return kept[-MAX_POINTS:]


def append_sample(samples, now: float, free: int, min_gap: float = MIN_GAP_SECONDS):
    """Agrega una muestra, como máximo una cada `min_gap` segundos."""

    series = list(samples or [])

    if series and now - series[-1][0] < min_gap:

        return series

    series.append((float(now), int(free)))

    return series


def forecast(
    samples,
    free: int,
    min_points: int = MIN_POINTS,
    min_span: float = MIN_SPAN_SECONDS,
    min_rate: float = MIN_RATE_PER_HOUR,
) -> dict | None:
    """{rate (IPs/hora), eta_hours, points} si el consumo es sostenido.

    None si no hay datos suficientes, el pool no baja o baja menos de
    `min_rate` IPs/hora (ruido).
    """

    series = list(samples or [])

    if len(series) < min_points:

        return None

    stamps = [item[0] for item in series]

    span = stamps[-1] - stamps[0]

    if span < min_span:

        return None

    mean_t = sum(stamps) / len(stamps)

    mean_f = sum(item[1] for item in series) / len(series)

    variance = sum((t - mean_t) ** 2 for t in stamps)

    if variance <= 0:

        return None

    covariance = sum(
        (t - mean_t) * (item[1] - mean_f) for t, item in zip(stamps, series)
    )

    rate = -(covariance / variance) * 3600  # IPs por hora que se consumen

    if rate < min_rate:

        return None

    return {
        "rate": rate,
        "eta_hours": max(0, int(free)) / rate,
        "points": len(series),
    }
