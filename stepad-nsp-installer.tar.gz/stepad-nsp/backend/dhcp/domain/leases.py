"""Leases de dnsmasq: una sola implementación de parseo.

Formato de `/var/lib/misc/dnsmasq.leases` (una línea por lease):

    <expira_epoch> <mac> <ip> <hostname> <client-id>

`expira_epoch == 0` significa lease infinito.

Capa de dominio: `parse_leases` es pura y `read_leases` es el único
punto de IO. Cualquier módulo que necesite leases pasa por aquí (antes
había tres parseos distintos con reglas diferentes).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Lease:

    expires_at: int
    mac: str
    ip: str
    hostname: str | None = None

    @property
    def infinite(self) -> bool:

        return self.expires_at == 0


def parse_leases(text: str) -> list[Lease]:
    """Parsea el contenido del archivo de leases (puro)."""

    leases: list[Lease] = []

    for line in text.splitlines():

        parts = line.split()

        if len(parts) < 3:

            continue

        try:

            expires_at = int(parts[0])

        except ValueError:

            continue

        mac = parts[1].strip().lower()

        ip = parts[2].strip()

        if not mac or not ip:

            continue

        hostname = None

        if len(parts) >= 4 and parts[3] not in ("*", ""):

            hostname = parts[3]

        leases.append(
            Lease(
                expires_at=expires_at,
                mac=mac,
                ip=ip,
                hostname=hostname,
            )
        )

    return leases


def dedupe_pairs(leases: list[Lease]) -> list[Lease]:
    """Un lease por (mac, ip); si hay hostname, se prefiere ese registro."""

    unique: dict[tuple[str, str], Lease] = {}

    for lease in leases:

        key = (lease.mac, lease.ip)

        if key not in unique or lease.hostname:

            unique[key] = lease

    return list(unique.values())


def read_leases(path: str | Path) -> list[Lease]:
    """Lee el archivo de leases. Devuelve [] si no existe o no se puede."""

    try:

        text = Path(path).read_text(encoding="utf-8", errors="replace")

    except (FileNotFoundError, OSError):

        return []

    return dedupe_pairs(parse_leases(text))


def by_mac(leases: list[Lease]) -> dict[str, Lease]:
    """Mapa mac -> lease (el último gana)."""

    result: dict[str, Lease] = {}

    for lease in leases:

        result[lease.mac] = lease

    return result


def ips(leases: list[Lease]) -> set[str]:

    return {lease.ip for lease in leases}
