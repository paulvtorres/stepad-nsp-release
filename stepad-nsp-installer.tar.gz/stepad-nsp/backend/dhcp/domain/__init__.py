"""Capa de dominio del DHCP: cálculo puro, sin IO ni base de datos.

Contrato de la capa:

- `exclusions`: qué direcciones no puede entregar dnsmasq.
- `leases`: parseo único de `/var/lib/misc/dnsmasq.leases`.
- `pool`: rangos dinámicos, capacidad y estadísticas del segmento.

Regla de arquitectura: TODO cálculo que se muestre en el panel o que se
escriba en `dnsmasq.conf` sale de estas funciones. Los servicios solo
cargan datos (DB / archivos) y orquestan; los providers solo escriben.
Así el panel no puede divergir del DHCP real.
"""
