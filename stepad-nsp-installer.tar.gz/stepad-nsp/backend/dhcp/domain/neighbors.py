"""Vecinos (ARP): presencia real de un equipo en la LAN ahora mismo.

Un lease puede sobrevivir horas a que el equipo se apague (24 h), así que
para "en línea" no sirve el lease ni el estado guardado en la base: se
mira la tabla ARP del kernel, que es la presencia efectiva.
"""

from __future__ import annotations


def parse_arp(text: str) -> dict[str, str]:
    """Devuelve {mac: ip} de las entradas ARP resueltas (flags != 0x0)."""

    result: dict[str, str] = {}

    for line in text.splitlines()[1:]:

        parts = line.split()

        if len(parts) < 4:

            continue

        ip, flags, mac = parts[0], parts[2], parts[3].lower()

        if flags == "0x0" or mac == "00:00:00:00:00:00":

            continue

        result[mac] = ip

    return result


def arp_mac_by_ip(text: str) -> dict[str, str]:
    """{ip: mac} solo de entradas resueltas (no FAILED/INCOMPLETE)."""

    return {ip: mac for mac, ip in parse_arp(text).items()}
