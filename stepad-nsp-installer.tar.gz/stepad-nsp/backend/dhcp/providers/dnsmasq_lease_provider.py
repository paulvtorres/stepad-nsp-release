from backend.core.config.paths import DNSMASQ_LEASES_FILE

from backend.dhcp.domain.leases import read_leases

from backend.dhcp.models.dhcp_lease import DhcpLease


class DnsmasqLeaseProvider:

    LEASE_FILE = DNSMASQ_LEASES_FILE

    def list_leases(self):
        """Leases actuales (parseo y dedupe en la capa de dominio)."""

        return [
            DhcpLease(
                expires_at=lease.expires_at,
                mac=lease.mac,
                ip=lease.ip,
                hostname=lease.hostname,
            )
            for lease in read_leases(self.LEASE_FILE)
        ]
