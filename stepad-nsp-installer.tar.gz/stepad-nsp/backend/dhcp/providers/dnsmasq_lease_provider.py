from backend.dhcp.models.dhcp_lease import DhcpLease
from backend.core.config.paths import (
    DNSMASQ_LEASES_FILE
)

class DnsmasqLeaseProvider:


    LEASE_FILE = DNSMASQ_LEASES_FILE


    def list_leases(self):

        leases = []


        try:

            with open(self.LEASE_FILE, "r") as file:

                for line in file:

                    parts = line.split()


                    if len(parts) < 4:
                        continue

                    hostname = None if parts[3] == "*" else parts[3]
                    leases.append(

                        DhcpLease(

                            expires_at=int(parts[0]),

                            mac=parts[1],

                            ip=parts[2],

                            hostname = hostname

                        )

                    )


        except FileNotFoundError:

            return []

        unique = {}

        for lease in leases:

            key = (
                lease.mac,
                lease.ip
            )

            if (
                key not in unique
                or lease.hostname
            ):
                unique[key] = lease


        return list(unique.values())
