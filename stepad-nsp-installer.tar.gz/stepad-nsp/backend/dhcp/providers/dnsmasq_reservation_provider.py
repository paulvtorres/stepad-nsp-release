from pathlib import Path

from backend.core.config.paths import (
    DOMAINS_CONFIG,
    RESERVATIONS_CONFIG 
)


class DnsmasqReservationProvider:


    def write_reservations(
        self,
        reservations: list[dict]
    ):

        DOMAINS_CONFIG.parent.mkdir(

            parents=True,

            exist_ok=True

        )


        with open(
            RESERVATIONS_CONFIG,
            "w"
        ) as file:


            for reservation in reservations:

                # set:zoneN lets dnsmasq route this device into its
                # zone's dhcp-range (see
                # NetworkZoneService._regenerate_zone_dhcp) even when
                # several zones share one physical wire via IP
                # aliasing -- with a real VLAN sub-interface the tag
                # is redundant with dnsmasq's own per-interface
                # matching, but harmless either way.
                tag = reservation.get("zone_tag")

                tag_part = f"set:{tag}," if tag else ""

                file.write(

                    f"dhcp-host="
                    f"{reservation['mac']},"
                    f"{tag_part}"
                    f"{reservation['ip']},"
                    f"{reservation.get('hostname','')}\n"

                )


        return {

            "success": True,

            "file": str(
                RESERVATIONS_CONFIG
            ),

            "total": len(reservations)

        }