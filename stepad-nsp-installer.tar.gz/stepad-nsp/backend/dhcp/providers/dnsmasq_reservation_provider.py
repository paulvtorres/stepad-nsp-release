import ipaddress
import os
import re
import subprocess
import tempfile

from pathlib import Path


from backend.core.config.paths import (
    DOMAINS_CONFIG,
    RESERVATIONS_CONFIG 
)


class DnsmasqReservationProvider:

    DNSMASQ_BIN = "/usr/sbin/dnsmasq"

    def _validate_with_dnsmasq(self, content: str) -> None:

        """Valida las líneas de reserva con el parser real de dnsmasq.

        ``dnsmasq --test`` no lee ``dhcp-hostsfile``; convertir cada
        línea a ``dhcp-host=`` en un archivo temporal sí la valida.
        """

        with tempfile.NamedTemporaryFile(
            "w",
            suffix=".conf",
            prefix="stepad-reservations-",
            delete=False,
            encoding="utf-8",
        ) as handle:

            handle.write("port=0\nno-resolv\n")

            for line in content.splitlines():

                if line.strip():

                    handle.write(f"dhcp-host={line}\n")

            validation_path = Path(handle.name)

        try:

            result = subprocess.run(
                [
                    self.DNSMASQ_BIN,
                    "--test",
                    "--conf-file=" + str(validation_path),
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:

                detail = (result.stderr or result.stdout or "syntax error").strip()

                raise ValueError(
                    f"dnsmasq rechazó las reservas: {detail}"
                )

        finally:

            validation_path.unlink(missing_ok=True)

    def write_reservations(
        self,
        reservations: list[dict]
    ):

        DOMAINS_CONFIG.parent.mkdir(

            parents=True,

            exist_ok=True

        )


        mac_re = re.compile(r"^[0-9a-f]{2}(:[0-9a-f]{2}){5}$")
        seen_macs = set()
        seen_ips = set()
        tmp = RESERVATIONS_CONFIG.with_suffix(RESERVATIONS_CONFIG.suffix + ".tmp")

        with open(
            tmp,
            "w"
        ) as file:


            for reservation in reservations:

                mac = str(reservation.get("mac") or "").strip().lower()
                ip = str(reservation.get("ip") or "").strip()

                if not mac_re.match(mac):
                    raise ValueError(f"Reserva con MAC inválida: {mac!r}")

                try:
                    ipaddress.ip_address(ip)
                except ValueError as error:
                    raise ValueError(
                        f"Reserva con IP inválida: {ip!r}"
                    ) from error

                if mac in seen_macs:
                    raise ValueError(f"Reserva con MAC duplicada: {mac}")

                if ip in seen_ips:
                    raise ValueError(f"Reserva con IP duplicada: {ip}")

                seen_macs.add(mac)
                seen_ips.add(ip)

                # set:zoneN lets dnsmasq route this device into its
                # zone's dhcp-range (see
                # NetworkZoneService._regenerate_zone_dhcp) even when
                # several zones share one physical wire via IP
                # aliasing -- with a real VLAN sub-interface the tag
                # is redundant with dnsmasq's own per-interface
                # matching, but harmless either way.
                tags = []

                zone_tag = reservation.get("zone_tag")

                if zone_tag:

                    tags.append(f"set:{zone_tag}")

                # set:grpN associa el equipo a su grupo DNS. Se escribe
                # AQUI (dentro de la reserva) y NO como dhcp-host aparte
                # en groups_dns.conf: un dhcp-host duplicado sin IP le
                # dice a dnsmasq "no asignes IP a esta MAC" y rompe las
                # reservas (ninguna dirección disponible).
                group_tag = reservation.get("group_tag")

                if group_tag:

                    tags.append(f"set:{group_tag}")

                tag_part = ",".join(tags)

                if tag_part:

                    tag_part += ","

                # Formato de dhcp-hostsfile: MAC,IP,... (sin "dhcp-host=").
                file.write(

                    f"{reservation['mac']},"
                    f"{tag_part}"
                    f"{reservation['ip']},"
                    f"{reservation.get('hostname','')}\n"

                )

        content = tmp.read_text(encoding="utf-8")

        self._validate_with_dnsmasq(content)

        os.replace(tmp, RESERVATIONS_CONFIG)


        return {

            "success": True,

            "file": str(
                RESERVATIONS_CONFIG
            ),

            "total": len(reservations)

        }