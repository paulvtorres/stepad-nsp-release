import subprocess

from backend.core.config.paths import (
    DNSMASQ_CONFIG,
    DOMAINS_CONFIG,
    RESERVATIONS_CONFIG,
    DNSMASQ_PID_FILE,
    ZONES_DHCP_CONFIG,
    DNS_DIR
)

from backend.core.config.settings import Settings

from backend.core.dnsmasq.process_manager import (
    dnsmasq_process_manager
)

from backend.dhcp.models.dhcp_config import DhcpConfig


class LinuxDhcpProvider:


    CONFIG_PATH = DNSMASQ_CONFIG


    DNSMASQ_BIN = "/usr/sbin/dnsmasq"



    def write_config(
        self,
        config: DhcpConfig
    ):

        # DNS can be delegated to another engine (PowerDNS + RPZ).
        # PowerDNS listens on 127.0.0.1 only, so dnsmasq must still
        # answer clients on the LAN gateway and forward upstream.
        dns_delegated = Settings.DNS_ENGINE != "dnsmasq"


        if dns_delegated:
            dns_section = """
# DNS delegated to external DNS engine
port=0
"""

        else:

            dns_section = f"""
server=1.1.1.1

server=8.8.8.8

domain-needed

bogus-priv

# Domain Rules

conf-file={DOMAINS_CONFIG}
"""


        content = f"""# STEPAD DHCP Configuration

interface={config.interface}

bind-interfaces

dhcp-range={config.pool_start},{config.pool_end},{config.netmask},{config.lease_time}

dhcp-option=3,{config.gateway}

dhcp-option=6,{config.dns_server}

pid-file={DNSMASQ_PID_FILE}

{dns_section}

# DHCP Reservations

conf-file={RESERVATIONS_CONFIG}

# Network Zones

conf-file={ZONES_DHCP_CONFIG}

# Group DNS assignment (per-department DNS)

conf-file={DNS_DIR / "groups_dns.conf"}
"""

        # dnsmasq errors if a conf-file is missing -- make sure the
        # group DNS file exists even when there are no groups yet.
        groups_conf = DNS_DIR / "groups_dns.conf"

        groups_conf.parent.mkdir(parents=True, exist_ok=True)

        if not groups_conf.exists():

            groups_conf.write_text(
                "# Auto-generated group DNS assignment\n"
            )


        # dnsmasq requires included configuration files to exist
        # before startup.
        ZONES_DHCP_CONFIG.parent.mkdir(
            parents=True,
            exist_ok=True
        )


        if not ZONES_DHCP_CONFIG.exists():

            ZONES_DHCP_CONFIG.write_text("")


        self.CONFIG_PATH.parent.mkdir(
            parents=True,
            exist_ok=True
        )


        self.CONFIG_PATH.write_text(
            content
        )


        return {
            "success": True,
            "config": str(self.CONFIG_PATH)
        }



    def start(self):

        # Centralized process management. All DHCP lifecycle actions
        # use the same dnsmasq process manager.
        return dnsmasq_process_manager.start()



    def stop(self):

        return dnsmasq_process_manager.stop()



    def status(self):

        return dnsmasq_process_manager.status()



    def validate(self):

        result = subprocess.run(
            [
                self.DNSMASQ_BIN,
                "--test",
                "--conf-file=" + str(self.CONFIG_PATH)
            ],
            capture_output=True,
            text=True
        )


        return {
            "success": result.returncode == 0,
            "output": result.stdout.strip(),
            "error": result.stderr.strip()
        }