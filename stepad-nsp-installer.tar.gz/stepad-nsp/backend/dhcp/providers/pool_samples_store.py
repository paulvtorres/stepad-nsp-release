"""Muestras de ocupación del pool, en disco.

Antes vivían solo en memoria: al reiniciar el NSP se perdían y el aviso de
tendencia tardaba otra hora en poder calcularse. Es un archivo pequeño y de
mejor esfuerzo: si no se puede leer o escribir, el pronóstico sigue con lo que
haya en memoria.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from backend.shared.logging.logger import logger


class PoolSamplesStore:

    VERSION = 1

    def __init__(self, path=None):

        if path is None:

            from backend.core.config.paths import DHCP_POOL_SAMPLES

            path = DHCP_POOL_SAMPLES

        self.path = Path(path)

    def load(self) -> dict[str, list[tuple[float, int]]]:

        try:

            raw = json.loads(self.path.read_text(encoding="utf-8"))

            pools = raw.get("pools", {}) if isinstance(raw, dict) else {}

            result: dict[str, list[tuple[float, int]]] = {}

            for name, series in pools.items():

                result[str(name)] = [
                    (float(item[0]), int(item[1]))
                    for item in series
                    if isinstance(item, (list, tuple)) and len(item) == 2
                ]

            return result

        except FileNotFoundError:

            return {}

        except (OSError, ValueError, TypeError, AttributeError) as error:

            logger.debug("PoolSamplesStore: archivo ilegible, se ignora: %s", error)

            return {}

    def save(self, samples: dict[str, list[tuple[float, int]]]) -> bool:

        payload = {
            "version": self.VERSION,
            "pools": {
                name: [[stamp, free] for stamp, free in series]
                for name, series in samples.items()
                if series
            },
        }

        temp = self.path.with_suffix(self.path.suffix + ".tmp")

        try:

            self.path.parent.mkdir(parents=True, exist_ok=True)

            temp.write_text(json.dumps(payload), encoding="utf-8")

            os.replace(temp, self.path)

            return True

        except OSError as error:

            logger.debug("PoolSamplesStore: no se pudo guardar: %s", error)

            try:

                temp.unlink()

            except OSError:

                pass

            return False
