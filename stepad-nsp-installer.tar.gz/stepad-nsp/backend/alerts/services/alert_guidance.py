"""Guia practica en lenguaje claro para las alertas del IPS.

Cada alerta tecnica de Suricata se traduce a: que significa de verdad
y que acciones tomar, para que un administrador sin conocimientos de
seguridad sepa como actuar sin ayuda externa.
"""


def alert_guidance(title: str | None, message: str | None):

    text = f"{title or ''} {message or ''}".lower()

    if any(
        k in text
        for k in ("trojan", "malware", "botnet", "ransomware", "banking")
    ):

        return {
            "tipo": "Posible malware",
            "explicacion": (
                "Se detecto actividad de software malicioso en este "
                "equipo (trojan, botnet, ransomware, robo de datos). "
                "Puede estar comprometido y conectandose a un servidor "
                "de control."
            ),
            "acciones": [
                "Aisla el equipo YA pulsando 'Aislar equipo' para cortar "
                "su comunicacion.",
                "Escanea con antivirus completo y actualizado.",
                "Cambia las contrasenas usadas desde ese equipo.",
                "No lo conectes a la red hasta estar seguro de que esta "
                "limpio.",
            ],
        }

    if any(
        k in text
        for k in (
            "command and control", "c2", "cnc", "callback",
            "malware cnc", "c2 server",
        )
    ):

        return {
            "tipo": "Comunicacion con servidor de control (C2)",
            "explicacion": (
                "El equipo se esta comunicando con un servidor de mando "
                "y control, tipico de malware que recibe ordenes o "
                "exfiltra datos."
            ),
            "acciones": [
                "Aisla el equipo pulsando 'Aislar equipo' de inmediato.",
                "Investiga que proceso se conecta a esa IP/destino.",
                "Escanea con antivirus y revisa procesos en ejecucion.",
                "Revisa si hubo exfiltracion de datos sensibles.",
            ],
        }

    if any(
        k in text
        for k in (
            "componente", "no pudo recuperarse", "monitoring", "usb_monitor",
            "servicio caído", "servicio caido",
        )
    ):

        return {
            "tipo": "Componente del NSP con fallo",
            "explicacion": (
                "Un servicio interno del NSP falló o no pudo recuperarse. "
                "Puede afectar DHCP, DNS, monitoreo o el panel."
            ),
            "acciones": [
                "Revisá el nombre del componente en el detalle.",
                "Verificá que DHCP siga entregando IPs.",
                "Si es un componente de red/DNS/IPS, revisá los servicios del sistema.",
                "Si se repite, reiniciá el NSP en una ventana controlada.",
                "Confirmá en Alertas que la alerta se haya resuelto.",
            ],
        }

    if any(
        k in text
        for k in (
            "cpu al", "cpu alta", "umbral superado: cpu",
            "memoria al", "umbral superado: memoria",
            "disco al", "umbral superado: disco",
        )
    ):

        return {
            "tipo": "Recurso del servidor al límite",
            "explicacion": (
                "El servidor está usando más del umbral de CPU, memoria "
                "o disco. Puede ser un escaneo de red, Suricata, una "
                "actualización o un proceso que quedó colgado. Si se "
                "mantiene, DHCP/DNS y el panel pueden volverse lentos."
            ),
            "acciones": [
                "Revisá los procesos con más CPU en el detalle de la alerta.",
                "Si aparece un escaneo de red o una actualización en curso, esperá a que termine.",
                "Si el proceso que más consume es el NSP o Suricata y sigue así, reiniciá el servicio afectado.",
                "Si es un proceso desconocido, revisá su ruta y no lo dejes ejecutándose.",
                "Confirmá que DHCP sigue entregando IPs y que el panel responde.",
            ],
        }

    if any(
        k in text
        for k in (
            "dhcp",
            "dnsmasq",
            "no reciben ip",
            "pedidos de ip",
        )
    ):

        return {
            "tipo": "Fallo del DHCP",
            "explicacion": (
                "El servidor que entrega IPs a los equipos de la red "
                "se detuvo o se quedó bloqueado. Sin DHCP, PCs y "
                "teléfonos no entran a Internet al conectar."
            ),
            "acciones": [
                "Compruebe si los equipos recuperan IP (desconectar y "
                "volver a conectar la red, o ipconfig /renew).",
                "En el NSP, el sistema intenta reiniciar DHCP solo.",
                "Si persiste, revise que no haya otro DHCP (p. ej. "
                "Deco en modo router) en la misma red.",
            ],
        }

    if any(
        k in text
        for k in ("exploit", "attack", "intrusion", "sql injection", "overflow", "scan")
    ):

        return {
            "tipo": "Intento de ataque o explotacion",
            "explicacion": (
                "Se detecto un intento de ataque o explotacion "
                "relacionado con este equipo (puede ser un equipo de la "
                "red intentando atacar, o un equipo bajo ataque)."
            ),
            "acciones": [
                "Revisa si el equipo origen realiza el ataque (comprometido) "
                "o si es victima del mismo.",
                "Si el equipo origen es interno, aisla y escanea.",
                "Actualiza sistemas y aplicaciones (parches).",
                "Revisa el destino reportado para confirmar el vector.",
            ],
        }

    return {
        "tipo": "Alerta de seguridad",
        "explicacion": (
            "El IPS detecto actividad que coincide con una firma de "
            "seguridad. Revisa el detalle y el equipo origen."
        ),
        "acciones": [
            "Revisa el equipo indicado y su actividad.",
            "Si la alerta es critica o se repite, aísla el equipo y "
            "escanea con antivirus.",
            "Si crees que es un falso positivo, puedes marcarla como "
            "leida y seguir monitoreando.",
        ],
    }
