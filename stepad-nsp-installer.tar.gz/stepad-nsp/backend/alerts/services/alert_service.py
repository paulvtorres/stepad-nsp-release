from sqlalchemy.orm import Session

from backend.alerts.models.alert import Alert
from backend.alerts.repositories.alert_repository import AlertRepository


class AlertService:

    # Audit actions that deserve an alert, with severity.
    SEVERITY = {
        "ACCOUNT_LOCKED": "critical",
        "USER_LOGIN_FAILED": "warning",
        "USER_CREATED": "warning",
        "USER_STATUS_CHANGED": "warning",
        "PASSWORD_CHANGED": "info",
        "MFA_ENABLED": "info",
        "MFA_DISABLED": "warning",
        "VPN_PEER_CREATED": "info",
        "VPN_PEER_UPDATED": "info",
        "VPN_PEER_DELETED": "warning",
        "VPN_PEER_EXPIRED": "warning",
        "PORT_FORWARD_CREATED": "info",
        "PORT_FORWARD_DELETED": "warning",
        "DEVICE_BLOCKED": "warning",
        "DEVICE_UNBLOCKED": "info",
        "RULE_CREATED": "info",
        "RULE_DELETED": "warning",
        "ZONE_CREATED": "info",
        "ZONE_DELETED": "warning",
        "ENCRYPTED_DNS_ENABLED": "info",
        "ENCRYPTED_DNS_DISABLED": "warning",
    }

    def __init__(self):

        self.repository = AlertRepository()

    def create(
        self,
        db: Session,
        alert_type: str,
        severity: str,
        title: str,
        message: str = ""
    ):

        alert = Alert(
            alert_type=alert_type,
            severity=severity,
            title=title,
            message=message or title
        )

        return self.repository.create(db, alert)

    def list(
        self,
        db: Session,
        limit: int = 50,
        unread_only: bool = False
    ):

        alerts = self.repository.list(
            db,
            limit=limit,
            unread_only=unread_only
        )

        return [
            {
                "id": alert.id,
                "type": alert.alert_type,
                "severity": alert.severity,
                "title": alert.title,
                "message": alert.message,
                "read": alert.read,
                "created_at": alert.created_at.isoformat()
            }
            for alert in alerts
        ]

    def unread_count(
        self,
        db: Session
    ):

        return self.repository.unread_count(db)

    def mark_read(
        self,
        db: Session,
        alert_id: int
    ):

        alert = self.repository.mark_read(db, alert_id)

        if alert is None:

            return {"success": False, "message": "Alert not found"}

        return {"success": True}

    def mark_all_read(
        self,
        db: Session
    ):

        self.repository.mark_all_read(db)

        return {"success": True}
