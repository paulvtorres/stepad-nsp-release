from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class Alert(Base):

    __tablename__ = "alerts"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    alert_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False
    )


    # info | warning | critical
    severity: Mapped[str] = mapped_column(
        String(10),
        nullable=False,
        default="info"
    )


    title: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )


    message: Mapped[str] = mapped_column(
        String(500),
        nullable=False
    )


    read: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
