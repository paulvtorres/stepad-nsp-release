from sqlalchemy.orm import Session

from backend.alerts.models.alert import Alert


class AlertRepository:

    MAX_ALERTS = 500

    def create(
        self,
        db: Session,
        alert: Alert
    ):

        db.add(alert)

        db.commit()

        db.refresh(alert)

        # Keep the table bounded.
        stale = (
            db.query(Alert.id)
            .order_by(Alert.id.desc())
            .offset(self.MAX_ALERTS)
            .all()
        )

        if stale:

            oldest_keep = stale[-1][0]

            db.query(Alert).filter(Alert.id < oldest_keep).delete(
                synchronize_session=False
            )

            db.commit()

        return alert

    def list(
        self,
        db: Session,
        limit: int = 50,
        unread_only: bool = False
    ):

        query = db.query(Alert)

        if unread_only:

            query = query.filter(Alert.read.is_(False))

        return (
            query
            .order_by(Alert.id.desc())
            .limit(limit)
            .all()
        )

    def unread_count(
        self,
        db: Session
    ):

        return (
            db.query(Alert.id)
            .filter(Alert.read.is_(False))
            .count()
        )

    def mark_read(
        self,
        db: Session,
        alert_id: int
    ):

        alert = db.get(Alert, alert_id)

        if alert is None:

            return None

        alert.read = True

        db.commit()

        db.refresh(alert)

        return alert

    def mark_all_read(
        self,
        db: Session
    ):

        db.query(Alert).filter(Alert.read.is_(False)).update(
            {Alert.read: True},
            synchronize_session=False
        )

        db.commit()
