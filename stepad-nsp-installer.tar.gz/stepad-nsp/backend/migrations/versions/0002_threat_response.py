"""respuesta ante amenazas (malware)

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-15 14:44:00.000000

Tablas del sistema de respuesta automatica ante malware/C2:
- malware_events: registro de detecciones clasificadas como malware.
- threat_response_settings: interruptores de cuarentena y bloqueo C2.

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('malware_events',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('src_ip', sa.String(length=64), nullable=False),
    sa.Column('src_mac', sa.String(length=32), nullable=True),
    sa.Column('device_id', sa.Integer(), nullable=True),
    sa.Column('device_name', sa.String(length=255), nullable=True),
    sa.Column('dst_ip', sa.String(length=64), nullable=False),
    sa.Column('dst_port', sa.String(length=16), nullable=True),
    sa.Column('signature', sa.String(length=255), nullable=False),
    sa.Column('category', sa.String(length=128), nullable=True),
    sa.Column('severity', sa.String(length=16), nullable=False),
    sa.Column('quarantined', sa.Boolean(), nullable=False),
    sa.Column('c2_blocked', sa.Boolean(), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_table('threat_response_settings',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('quarantine_enabled', sa.Boolean(), nullable=False),
    sa.Column('c2_block_enabled', sa.Boolean(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )


def downgrade() -> None:
    op.drop_table('threat_response_settings')
    op.drop_table('malware_events')
