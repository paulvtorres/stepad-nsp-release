"""Separate last known IP

Revision ID: 0046
Revises: 0045
Create Date: 2026-11-12 16:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0046"
down_revision = "0045"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_devices",
        sa.Column("last_ip", sa.String(length=45), nullable=False, server_default=""),
    )
    op.execute(
        "UPDATE network_devices SET last_ip = COALESCE(ip_address, '')"
    )


def downgrade() -> None:
    op.drop_column("network_devices", "last_ip")
