"""Colapsar alertas duplicadas (una condicion persistente generaba una
alerta nueva cada 30 min, inundando la pantalla).

Revision ID: 0037
Revises: 0036
Create Date: 2026-10-19 00:00:00.000000
"""
from alembic import op


revision = "0037"
down_revision = "0036"
branch_labels = None
depends_on = None


# Tipos que representan una CONDICION de estado (periodica). Para estos
# basta una sola entrada viva por (tipo, titulo).
PERIODIC_TYPES = (
    "NAVIGATION_HEALTH",
    "DHCP_HEALTH",
    "BOOT_HEALTH_NFTABLES",
    "BOOT_HEALTH_PROCESS",
    "BOOT_HEALTH_PORTS",
    "BOOT_HEALTH_SCHEMA",
    "RESOURCE_CPU",
    "RESOURCE_RAM",
    "RESOURCE_DISK",
    "HARDENING_DEGRADED",
    "SHARE_DISK_HEALTH",
    "BACKUP_FAILING",
    "BACKUP_DEST_MISSING",
    "SOURCE_MISSING",
    "SYSTEM_BACKUP_FAILED",
)


def upgrade() -> None:

    # 1) Duplicados exactos (mismo tipo, titulo y mensaje): dejar el mas
    #    reciente.
    op.execute(
        """
        DELETE FROM alerts a
        USING alerts b
        WHERE a.alert_type = b.alert_type
          AND a.title = b.title
          AND a.message = b.message
          AND a.id < b.id
        """
    )

    # 2) Condiciones de estado: una sola entrada por (tipo, titulo),
    #    aunque el mensaje varie un poco entre repeticiones.
    types = ", ".join(f"'{t}'" for t in PERIODIC_TYPES)

    op.execute(
        f"""
        DELETE FROM alerts a
        USING alerts b
        WHERE a.alert_type = b.alert_type
          AND a.title = b.title
          AND a.id < b.id
          AND a.alert_type IN ({types})
        """
    )


def downgrade() -> None:
    # Limpieza de datos: no es reversible.
    pass
