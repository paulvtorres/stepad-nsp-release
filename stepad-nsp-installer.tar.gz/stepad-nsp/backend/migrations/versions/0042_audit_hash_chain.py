"""Audit hash chain (tamper-evident log)

Revision ID: 0042
Revises: 0041
Create Date: 2026-11-07 17:20:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0042"
down_revision = "0041"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "audit_logs",
        sa.Column("prev_hash", sa.String(length=64), nullable=True),
    )
    op.add_column(
        "audit_logs",
        sa.Column("entry_hash", sa.String(length=64), nullable=True),
    )
    op.create_index(
        "ix_audit_logs_entry_hash", "audit_logs", ["entry_hash"]
    )


def downgrade() -> None:
    op.drop_index("ix_audit_logs_entry_hash", table_name="audit_logs")
    op.drop_column("audit_logs", "entry_hash")
    op.drop_column("audit_logs", "prev_hash")
