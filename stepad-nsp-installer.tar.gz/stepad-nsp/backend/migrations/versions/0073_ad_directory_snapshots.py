"""Scheduled AD directory snapshots.

Revision ID: 0073
Revises: 0072
"""
from alembic import op
import sqlalchemy as sa


revision = "0073"
down_revision = "0072"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "ad_settings",
        sa.Column("sync_interval_minutes", sa.Integer(), nullable=False, server_default="15"),
    )
    op.add_column("ad_settings", sa.Column("last_sync_at", sa.DateTime(), nullable=True))
    op.add_column("ad_settings", sa.Column("last_sync_ok", sa.Boolean(), nullable=True))
    op.add_column("ad_settings", sa.Column("last_sync_message", sa.String(512), nullable=True))
    op.create_table(
        "ad_directory_snapshots",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("success", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("message", sa.Text(), nullable=False, server_default=""),
        sa.Column("data", sa.Text(), nullable=False, server_default="{}"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("ad_directory_snapshots")
    op.drop_column("ad_settings", "last_sync_message")
    op.drop_column("ad_settings", "last_sync_ok")
    op.drop_column("ad_settings", "last_sync_at")
    op.drop_column("ad_settings", "sync_interval_minutes")
