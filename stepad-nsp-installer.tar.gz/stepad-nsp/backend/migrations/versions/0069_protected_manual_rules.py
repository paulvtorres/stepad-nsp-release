"""Protect manual blocking rules.

Revision ID: 0069
Revises: 0068
Create Date: 2026-11-27 16:30:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0069"
down_revision = "0068"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "device_access_rules",
        sa.Column(
            "is_protected",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )
    op.add_column(
        "device_access_rules",
        sa.Column("protection_reason", sa.String(length=255), nullable=True),
    )
    op.execute(
        """
        UPDATE device_access_rules
        SET is_protected = true,
            is_permanent = true,
            protection_reason = 'Bloqueo manual protegido'
        WHERE source = 'manual' AND action = 'BLOCK'
        """
    )


def downgrade() -> None:
    op.drop_column("device_access_rules", "protection_reason")
    op.drop_column("device_access_rules", "is_protected")
