"""Egress flow stats (panel de Egreso / Exfiltracion)

Revision ID: 0036
Revises: 0035
Create Date: 2026-10-17 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0036"
down_revision = "0035"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "egress_flow_stats",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("bucket_hour", sa.DateTime(), nullable=False),
        sa.Column("src_ip", sa.String(length=64), nullable=False),
        sa.Column("device_id", sa.Integer(), nullable=True),
        sa.Column("device_name", sa.String(length=255), nullable=True),
        sa.Column("dest_ip", sa.String(length=64), nullable=False),
        sa.Column("dest_port", sa.Integer(), nullable=True),
        sa.Column("app_proto", sa.String(length=32), nullable=True),
        sa.Column("country", sa.String(length=8), nullable=True),
        sa.Column("asn", sa.String(length=16), nullable=True),
        sa.Column("as_org", sa.String(length=255), nullable=True),
        sa.Column(
            "bytes_out", sa.BigInteger(), nullable=False, server_default="0"
        ),
        sa.Column(
            "bytes_in", sa.BigInteger(), nullable=False, server_default="0"
        ),
        sa.Column(
            "connections", sa.Integer(), nullable=False, server_default="0"
        ),
        sa.Column("first_seen", sa.DateTime(), nullable=False),
        sa.Column("last_seen", sa.DateTime(), nullable=False),
        sa.UniqueConstraint(
            "bucket_hour",
            "src_ip",
            "dest_ip",
            "dest_port",
            "app_proto",
            name="uq_egress_flow_stat",
        ),
    )

    op.create_index(
        "ix_egress_flow_stats_hour",
        "egress_flow_stats",
        ["bucket_hour"],
    )
    op.create_index(
        "ix_egress_flow_stats_dest",
        "egress_flow_stats",
        ["dest_ip"],
    )
    op.create_index(
        "ix_egress_flow_stats_src",
        "egress_flow_stats",
        ["src_ip"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_egress_flow_stats_src", table_name="egress_flow_stats"
    )
    op.drop_index(
        "ix_egress_flow_stats_dest", table_name="egress_flow_stats"
    )
    op.drop_index(
        "ix_egress_flow_stats_hour", table_name="egress_flow_stats"
    )
    op.drop_table("egress_flow_stats")
