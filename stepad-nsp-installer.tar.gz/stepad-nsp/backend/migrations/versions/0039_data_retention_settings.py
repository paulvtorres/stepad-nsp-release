"""Data retention per type (1..12 months / unlimited)

Revision ID: 0039
Revises: 0038
Create Date: 2026-10-30 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0039"
down_revision = "0038"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "data_retention_settings",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("data_type", sa.String(length=64), nullable=False),
        sa.Column(
            "retention_days", sa.Integer(), nullable=False,
            server_default="90",
        ),
        sa.Column(
            "enabled", sa.Boolean(), nullable=False,
            server_default=sa.true(),
        ),
        sa.Column("last_run_at", sa.DateTime(), nullable=True),
        sa.Column(
            "last_deleted", sa.Integer(), nullable=False,
            server_default="0",
        ),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.UniqueConstraint("data_type", name="uq_retention_data_type"),
    )
    op.create_index(
        "ix_data_retention_settings_data_type",
        "data_retention_settings",
        ["data_type"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_data_retention_settings_data_type",
        table_name="data_retention_settings",
    )
    op.drop_table("data_retention_settings")
