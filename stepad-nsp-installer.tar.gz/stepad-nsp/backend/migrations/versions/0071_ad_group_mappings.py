"""AD group mappings.

Revision ID: 0071
Revises: 0070
"""
from alembic import op
import sqlalchemy as sa


revision = "0071"
down_revision = "0070"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "ad_group_mappings",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("ad_group_dn", sa.String(512), nullable=False),
        sa.Column("ad_group_name", sa.String(255), nullable=False, server_default=""),
        sa.Column("nsp_group_id", sa.Integer(), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["nsp_group_id"], ["device_groups.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("ad_group_dn"),
    )


def downgrade() -> None:
    op.drop_table("ad_group_mappings")
