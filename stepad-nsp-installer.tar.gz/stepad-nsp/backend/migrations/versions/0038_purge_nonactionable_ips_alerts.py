"""Purgar alertas IPS no accionables (informativas / de politica).

El clasificador (alert_classify) decide que solo malware/exploit/dos/recon/
suspicious generan alerta. Alertas IPS antiguas de tipo "other"/"policy"
(ruido: STUN, STREAM, INFO de user-agents, etc.) se arrastran y ensucian la
pantalla de Alertas. Aqui se purgan.

Revision ID: 0038
Revises: 0037
Create Date: 2026-10-19 00:00:01.000000
"""
import sqlalchemy as sa
from alembic import op

from backend.ips.services.alert_classify import (
    classify,
    NOTIFY_KINDS,
)


revision = "0038"
down_revision = "0037"
branch_labels = None
depends_on = None


def upgrade() -> None:

    connection = op.get_bind()

    rows = connection.execute(
        sa.text(
            "SELECT id, title, message FROM alerts "
            "WHERE alert_type = 'suricata'"
        )
    ).fetchall()

    to_delete = []

    for alert_id, title, message in rows:

        signature = (title or "").replace("IPS:", "").strip()

        category = ""

        if message and "|" in message:

            parts = message.split("|")

            if len(parts) >= 2:

                category = parts[1].strip()

        kind, _label, _severity = classify(signature, category)

        if kind not in NOTIFY_KINDS:

            to_delete.append(alert_id)

    if not to_delete:

        return

    connection.execute(
        sa.text("DELETE FROM alerts WHERE id = ANY(:ids)"),
        {"ids": to_delete},
    )


def downgrade() -> None:
    # Limpieza de datos: no es reversible.
    pass
