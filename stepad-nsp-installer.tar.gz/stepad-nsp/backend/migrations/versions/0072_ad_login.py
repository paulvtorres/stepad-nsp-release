"""Optional LDAP login for existing local users.

Revision ID: 0072
Revises: 0071
"""
from alembic import op
import sqlalchemy as sa


revision = "0072"
down_revision = "0071"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "ad_settings",
        sa.Column(
            "login_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )


def downgrade() -> None:
    op.drop_column("ad_settings", "login_enabled")
