"""Presence observations and last/current IP separation

Revision ID: 0045
Revises: 0044
Create Date: 2026-11-12 15:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0045"
down_revision = "0044"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_devices",
        sa.Column("current_ip", sa.String(length=45), nullable=False, server_default=""),
    )
    op.add_column(
        "network_devices",
        sa.Column("presence_status", sa.String(length=20), nullable=False, server_default="UNKNOWN"),
    )
    op.add_column(
        "network_devices",
        sa.Column("presence_source", sa.String(length=20), nullable=True),
    )
    op.add_column(
        "network_devices",
        sa.Column("presence_at", sa.DateTime(), nullable=True),
    )
    op.add_column(
        "network_devices",
        sa.Column("ip_conflict", sa.Boolean(), nullable=False, server_default=sa.false()),
    )
    op.create_index(
        "ix_network_devices_current_ip", "network_devices", ["current_ip"]
    )
    # La IP observada puede repetirse: el conflicto debe poder verse.
    op.execute("DROP INDEX IF EXISTS ux_network_devices_active_ip")

    op.create_table(
        "device_ip_observations",
        sa.Column("id", sa.Integer(), primary_key=True, nullable=False),
        sa.Column("mac_address", sa.String(length=17), nullable=False),
        sa.Column("ip_address", sa.String(length=45), nullable=False),
        sa.Column("source", sa.String(length=20), nullable=False),
        sa.Column("observed_at", sa.DateTime(), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=True),
    )
    op.create_index(
        "ix_device_ip_observations_mac_address",
        "device_ip_observations",
        ["mac_address"],
    )
    op.create_index(
        "ix_device_ip_observations_ip_address",
        "device_ip_observations",
        ["ip_address"],
    )
    op.create_index(
        "ix_device_ip_observations_source",
        "device_ip_observations",
        ["source"],
    )
    op.create_index(
        "ix_device_ip_observations_observed_at",
        "device_ip_observations",
        ["observed_at"],
    )


def downgrade() -> None:
    op.drop_table("device_ip_observations")
    op.drop_index("ix_network_devices_current_ip", table_name="network_devices")
    op.drop_column("network_devices", "ip_conflict")
    op.drop_column("network_devices", "presence_at")
    op.drop_column("network_devices", "presence_source")
    op.drop_column("network_devices", "presence_status")
    op.drop_column("network_devices", "current_ip")
