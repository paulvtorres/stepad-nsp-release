"""Device IP history

Revision ID: 0043
Revises: 0042
Create Date: 2026-11-12 12:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0043"
down_revision = "0042"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "device_ip_history",
        sa.Column("id", sa.Integer(), primary_key=True, nullable=False),
        sa.Column("device_id", sa.Integer(), nullable=True),
        sa.Column("mac_address", sa.String(length=17), nullable=True),
        sa.Column("ip_address", sa.String(length=45), nullable=False),
        sa.Column("source", sa.String(length=30), nullable=True),
        sa.Column("started_at", sa.DateTime(), nullable=True),
        sa.Column("ended_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(
            ["device_id"], ["network_devices.id"], ondelete="SET NULL"
        ),
    )
    op.create_index(
        "ix_device_ip_history_device_id",
        "device_ip_history",
        ["device_id"],
    )
    op.create_index(
        "ix_device_ip_history_ip_address",
        "device_ip_history",
        ["ip_address"],
    )


def downgrade() -> None:
    op.drop_index("ix_device_ip_history_ip_address", table_name="device_ip_history")
    op.drop_index("ix_device_ip_history_device_id", table_name="device_ip_history")
    op.drop_table("device_ip_history")
