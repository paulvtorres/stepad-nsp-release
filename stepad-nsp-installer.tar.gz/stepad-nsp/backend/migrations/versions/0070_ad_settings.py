"""AD/LDAP settings.

Revision ID: 0070
Revises: 0069
Create Date: 2026-11-27 18:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0070"
down_revision = "0069"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "ad_settings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("domain_name", sa.String(255), nullable=False, server_default=""),
        sa.Column("server", sa.String(255), nullable=False, server_default=""),
        sa.Column("port", sa.Integer(), nullable=False, server_default="636"),
        sa.Column("use_ssl", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("verify_tls", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("base_dn", sa.String(512), nullable=False, server_default=""),
        sa.Column("bind_dn", sa.String(512), nullable=False, server_default=""),
        sa.Column("bind_password", sa.String(1024), nullable=True),
        sa.Column("user_filter", sa.String(255), nullable=False, server_default="(sAMAccountName={username})"),
        sa.Column("group_filter", sa.String(255), nullable=False, server_default="(member={user_dn})"),
        sa.Column("default_group_id", sa.Integer(), nullable=True),
        sa.Column("last_test_at", sa.DateTime(), nullable=True),
        sa.Column("last_test_ok", sa.Boolean(), nullable=True),
        sa.Column("last_test_message", sa.String(512), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["default_group_id"], ["device_groups.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("ad_settings")
