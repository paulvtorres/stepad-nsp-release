"""Unique active IP per device

Revision ID: 0044
Revises: 0043
Create Date: 2026-11-12 13:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0044"
down_revision = "0043"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Si aún quedan duplicados, conservar el dueño más probable antes de
    # crear el índice: reserva > ONLINE > último visto > id más alto.
    op.execute(
        """
        WITH ranked AS (
            SELECT id,
                   ROW_NUMBER() OVER (
                       PARTITION BY ip_address
                       ORDER BY
                           CASE WHEN permanent_ip = ip_address THEN 0 ELSE 1 END,
                           CASE WHEN status = 'ONLINE' THEN 0 ELSE 1 END,
                           last_seen DESC NULLS LAST,
                           id DESC
                   ) AS rn
            FROM network_devices
            WHERE ip_address IS NOT NULL AND ip_address <> ''
        )
        UPDATE network_devices AS device
        SET ip_address = ''
        FROM ranked
        WHERE device.id = ranked.id AND ranked.rn > 1
        """
    )

    op.create_index(
        "ux_network_devices_active_ip",
        "network_devices",
        ["ip_address"],
        unique=True,
        postgresql_where=sa.text("ip_address <> ''"),
    )


def downgrade() -> None:
    op.drop_index(
        "ux_network_devices_active_ip",
        table_name="network_devices",
    )
