import os

from logging.config import fileConfig

from pathlib import Path

from alembic import context

from sqlalchemy import engine_from_config, pool


# systemd ya inyecta las variables del entorno; si se ejecuta alembic a
# mano (o desde el instalador) sin el EnvironmentFile, las cargamos desde
# /etc/stepad/stepad.env para que la URL se resuelva igual que la app.
ENV_FILE = Path("/etc/stepad/stepad.env")

if "DB_PASSWORD" not in os.environ and ENV_FILE.exists():

    try:

        for line in ENV_FILE.read_text().splitlines():

            line = line.strip()

            if line and not line.startswith("#") and "=" in line:

                key, _, value = line.partition("=")

                os.environ.setdefault(key, value)

    except Exception:

        pass


config = context.config

if config.config_file_name is not None:

    fileConfig(config.config_file_name)


# Registra TODOS los modelos en Base.metadata y toma la URL real
# (mismo secreto y soporte de socket Unix que la aplicacion).
from backend.core.database import models_registry  # noqa: F401
from backend.core.database.base import Base  # noqa: E402
from backend.core.database.connection import DATABASE_URL  # noqa: E402

target_metadata = Base.metadata

config.set_main_option(
    "sqlalchemy.url",
    DATABASE_URL.replace("%", "%%")
)


def run_migrations_offline():

    url = config.get_main_option("sqlalchemy.url")

    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():

        context.run_migrations()


def run_migrations_online():

    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
        )

        with context.begin_transaction():

            context.run_migrations()


if context.is_offline_mode():

    run_migrations_offline()

else:

    run_migrations_online()
