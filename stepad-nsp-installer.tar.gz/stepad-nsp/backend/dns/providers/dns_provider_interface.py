from typing import Protocol, runtime_checkable
from pathlib import Path


@runtime_checkable
class DnsProviderInterface(Protocol):
    """
    Contract every DNS/domain-blocking engine must satisfy.

    Swapping the blocking engine (dnsmasq -> a custom resolver ->
    anything else) means writing one new class that implements this
    Protocol and pointing the factory (backend/dns/factory.py) at it.
    No other module should import a concrete provider directly.
    """

    def generate_domains_config(
        self,
        domains: list[str]
    ) -> None:
        """Persist the blocked-domains list in whatever format the engine needs."""
        ...

    def reload(self) -> dict:
        """
        Apply the current domains config to the running engine.
        Must return {"success": bool, "message": str, ...}.
        """
        ...

    def get_status(self) -> dict:
        """Must return {"running": bool, "pid": int | None}."""
        ...

    def clear(self) -> None:
        """Remove all blocked domains."""
        ...



    #

    # Dashboard / Diagnosis

    #

    def get_configuration_path(self) -> Path:

        ...

    def get_domains_count(self) -> int:

        ...