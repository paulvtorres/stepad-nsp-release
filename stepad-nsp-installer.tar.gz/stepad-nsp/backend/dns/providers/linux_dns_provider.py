from backend.core.config.paths import (
    DOMAINS_CONFIG
)

from backend.core.dnsmasq.process_manager import (
    dnsmasq_process_manager
)


class LinuxDnsProvider:
    """
    dnsmasq-backed implementation of DnsProviderInterface.
    """

    def generate_domains_config(
        self,
        domains: list[str]
    ):

        DOMAINS_CONFIG.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        with open(
            DOMAINS_CONFIG,
            "w"
        ) as file:

            for domain in sorted(set(domains)):

                if not domain:
                    continue

                file.write(
                    f"address=/{domain}/0.0.0.0\n"
                )

                # Opcional para bloquear IPv6 también
                file.write(
                    f"address=/{domain}/::\n"
                )


    def reload(self):
        # address=/domain/IP entries are loaded via conf-file at
        # dnsmasq startup and are NOT re-read on SIGHUP (confirmed in
        # dnsmasq's own man page: SIGHUP reloads /etc/hosts,
        # /etc/ethers, --dhcp-hostsfile, --dhcp-optsfile and
        # --addn-hosts only -- never the config file itself). A full
        # restart is the only way to apply newly added/removed
        # blocked domains.
        return dnsmasq_process_manager.restart()


    def get_status(self):

        return dnsmasq_process_manager.status()


    def clear(self):

        self.generate_domains_config([])
