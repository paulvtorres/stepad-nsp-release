import subprocess
import time

import psutil

from backend.core.config.paths import ZONES_DIR
from backend.network.zones.models.network_zone import NetworkZone
from backend.shared.logging.logger import logger


PDNS_RECURSOR_BIN = "/usr/sbin/pdns_recursor"

REC_CONTROL_BIN = "/usr/bin/rec_control"

RPZ_TTL_SECONDS = 300

START_CHECK_DELAY_SECONDS = 0.5

SOCKET_WAIT_TIMEOUT_SECONDS = 20

SOCKET_WAIT_POLL_SECONDS = 0.5


class ZonePdnsProvider:

    def __init__(
        self,
        zone: NetworkZone
    ):

        self.zone = zone

        self.zone_dir = ZONES_DIR / str(zone.id)

        self.rpz_zone_file = self.zone_dir / "blocked_domains.rpz"

        self.lua_config_file = self.zone_dir / "rpz.lua"

        self.recursor_yml = self.zone_dir / "recursor.yml"

        self.pid_file = self.zone_dir / "pdns.pid"

        self.zone_name = f"stepad-zone-{zone.id}"


    def bootstrap(self):

        self.zone_dir.mkdir(parents=True, exist_ok=True)

        lua_content = (
            f'rpzFile("{self.rpz_zone_file}", '
            f'{{defpol=Policy.NXDOMAIN, policyName="{self.zone_name}"}})\n'
        )

        self.lua_config_file.write_text(lua_content)

        if not self.rpz_zone_file.exists():

            self.generate_domains_config([])

        prefix_length = self.zone.network_cidr.split("/")[-1]

        network = self.zone.network_cidr

        recursor_yml_content = (
            "dnssec:\n"
            "  validation: 'validate'\n\n"
            "logging:\n"
            "  loglevel: 4\n"
            "  quiet: false\n"
            "  protobuf_servers:\n"
            "    - address: '127.0.0.1:4242'\n\n"
            "incoming:\n"
            "  listen:\n"
            f"    - {self.zone.gateway_ip}\n"
            "  allow_from:\n"
            "    - 127.0.0.1\n"
            f"    - {network}\n\n"
            "recursor:\n"
            f"  lua_config_file: '{self.lua_config_file}'\n"
        )

        self.recursor_yml.write_text(recursor_yml_content)


    def generate_domains_config(
        self,
        domains: list[str]
    ):

        self.rpz_zone_file.parent.mkdir(parents=True, exist_ok=True)

        serial = int(time.time())

        lines = [
            "$TTL " + str(RPZ_TTL_SECONDS),
            f"@ SOA localhost. root.localhost. ({serial} 3600 600 604800 {RPZ_TTL_SECONDS})",
            "  NS localhost.",
            ""
        ]

        for domain in sorted(set(
            domain.strip().lower()
            for domain in domains
            if domain and domain.strip()
        )):

            lines.append(f"{domain}. CNAME .")
            lines.append(f"*.{domain}. CNAME .")

        self.rpz_zone_file.write_text("\n".join(lines) + "\n")


    def _find_pid(self):

        if self.pid_file.exists():

            try:

                pid = int(self.pid_file.read_text().strip())

                if psutil.pid_exists(pid):

                    return pid

            except ValueError:

                pass

        for process in psutil.process_iter(["pid", "name", "cmdline"]):

            if process.info["name"] != "pdns_recursor":
                continue

            cmdline = " ".join(process.info.get("cmdline") or [])

            if str(self.zone_dir) in cmdline:

                return process.info["pid"]

        return None


    def start(self):

        if self._find_pid():

            return {"success": True, "message": "Zone resolver already running"}

        process = subprocess.Popen(
            [
                PDNS_RECURSOR_BIN,
                "--daemon=no",
                "--write-pid=no",
                f"--config-dir={self.zone_dir}",
                f"--socket-dir={self.zone_dir}"
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        time.sleep(START_CHECK_DELAY_SECONDS)

        if process.poll() is not None:

            _, stderr = process.communicate()

            logger.error(f"Zone {self.zone.id} resolver failed to start: {stderr.strip()}")

            return {"success": False, "error": stderr.strip()}

        self.pid_file.write_text(str(process.pid))

        return {"success": True, "pid": process.pid}


    def stop(self):

        pid = self._find_pid()

        if not pid:

            return {"success": True, "message": "Not running"}

        try:

            psutil.Process(pid).terminate()

        except psutil.NoSuchProcess:

            pass

        if self.pid_file.exists():

            self.pid_file.unlink()

        return {"success": True}


    def reload(self):

        socket_path = self.zone_dir / "pdns_recursor.controlsocket"

        waited = 0.0

        while not socket_path.exists() and waited < SOCKET_WAIT_TIMEOUT_SECONDS:

            time.sleep(SOCKET_WAIT_POLL_SECONDS)

            waited += SOCKET_WAIT_POLL_SECONDS

        if not socket_path.exists():

            message = (
                f"Zone {self.zone.id}: control socket never appeared "
                f"({socket_path}) -- its pdns_recursor process is "
                "likely not running (see start())."
            )

            logger.error(message)

            return {"success": False, "error": message}

        result = subprocess.run(
            [
                REC_CONTROL_BIN,
                f"--socket-dir={self.zone_dir}",
                "reload-lua-config"
            ],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:

            # El RPZ ya esta cargado, pero pdns-recursor sigue sirviendo
            # respuestas POSITIVAS cacheadas de antes del bloqueo hasta
            # que expiren sus TTLs. Se vacia la cache para que el bloqueo
            # aplique al instante (dominios recien bloqueados -> NXDOMAIN).
            subprocess.run(
                [
                    REC_CONTROL_BIN,
                    f"--socket-dir={self.zone_dir}",
                    "flush-cache"
                ],
                capture_output=True,
                text=True,
                timeout=15,
            )

            return {"success": True, "message": f"Zone {self.zone.id} RPZ reloaded"}  # noqa: E501

        logger.error(
            f"Zone {self.zone.id} reload-lua-config failed: {result.stderr.strip()}"
        )

        return {"success": False, "error": result.stderr.strip()}


    def get_status(self):

        pid = self._find_pid()

        return {"running": pid is not None, "pid": pid}
