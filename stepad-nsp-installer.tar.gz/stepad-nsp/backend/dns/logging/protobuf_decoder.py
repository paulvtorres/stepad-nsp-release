import struct


WIRE_VARINT = 0
WIRE_64BIT = 1
WIRE_LENGTH_DELIMITED = 2
WIRE_32BIT = 5


# Field numbers from pdns/dnsmessage.proto (PBDNSMessage), top level
FIELD_TYPE = 1
FIELD_MESSAGE_ID = 2
FIELD_FROM = 6              # client IP, raw bytes (4 or 16)
FIELD_TIME_SEC = 9
FIELD_QUESTION = 12         # embedded DNSQuestion message
FIELD_RESPONSE = 13         # embedded DNSResponse message

# DNSQuestion sub-fields
QUESTION_FIELD_QNAME = 1

# DNSResponse sub-fields
RESPONSE_FIELD_RCODE = 1
RESPONSE_FIELD_APPLIED_POLICY = 3
RESPONSE_FIELD_APPLIED_POLICY_HIT = 9
RESPONSE_FIELD_APPLIED_POLICY_KIND = 10

# PBDNSMessage.Type enum
TYPE_QUERY = 1
TYPE_RESPONSE = 2

# PBDNSMessage.DNSResponse.PolicyKind enum -- NXDOMAIN/NODATA/Drop all
# mean "this was blocked by RPZ" for our purposes.
POLICY_KIND_NO_ACTION = 1
POLICY_KIND_DROP = 2
POLICY_KIND_NXDOMAIN = 3
POLICY_KIND_NODATA = 4
POLICY_KIND_TRUNCATE = 5
POLICY_KIND_CUSTOM = 6

BLOCKED_POLICY_KINDS = {
    POLICY_KIND_DROP,
    POLICY_KIND_NXDOMAIN,
    POLICY_KIND_NODATA,
    POLICY_KIND_CUSTOM
}


def read_varint(data: bytes, pos: int) -> tuple[int, int]:
    """Returns (value, new_pos)."""

    result = 0

    shift = 0

    while True:

        byte = data[pos]

        pos += 1

        result |= (byte & 0x7F) << shift

        if not (byte & 0x80):

            break

        shift += 7

    return result, pos


def walk_fields(data: bytes):
    """
    Generic protobuf field walker. Yields (field_number, wire_type,
    value) for every top-level field in `data`. `value` is an int for
    varint/32/64-bit fields, or raw bytes for length-delimited fields
    (the caller decides whether those bytes are a string, a nested
    message, or something else -- that's exactly what makes this
    genuinely schema-agnostic).
    """

    pos = 0

    length = len(data)

    while pos < length:

        tag, pos = read_varint(data, pos)

        field_number = tag >> 3

        wire_type = tag & 0x7

        if wire_type == WIRE_VARINT:

            value, pos = read_varint(data, pos)

            yield field_number, wire_type, value

        elif wire_type == WIRE_64BIT:

            value = data[pos:pos + 8]

            pos += 8

            yield field_number, wire_type, value

        elif wire_type == WIRE_LENGTH_DELIMITED:

            field_len, pos = read_varint(data, pos)

            value = data[pos:pos + field_len]

            pos += field_len

            yield field_number, wire_type, value

        elif wire_type == WIRE_32BIT:

            value = data[pos:pos + 4]

            pos += 4

            yield field_number, wire_type, value

        else:

            # Unknown/unsupported wire type -- can't safely skip
            # without knowing its length, stop here rather than
            # risk misreading the rest of the buffer as garbage.
            return


def decode_ip_bytes(raw: bytes) -> str | None:

    if len(raw) == 4:

        return ".".join(str(b) for b in raw)

    if len(raw) == 16:

        import ipaddress

        return str(ipaddress.ip_address(raw))

    return None


def decode_pbdns_message(data: bytes) -> dict:
    """
    Extracts only the fields the navigation log needs. Returns a dict
    that's always safe to inspect with .get() -- any field PowerDNS
    didn't set (e.g. a plain query message has no `response`) is
    simply absent, never raises.
    """

    result = {}

    for field_number, wire_type, value in walk_fields(data):

        if field_number == FIELD_TYPE:

            result["type"] = value

        elif field_number == FIELD_FROM:

            result["client_ip"] = decode_ip_bytes(value)

        elif field_number == FIELD_TIME_SEC:

            result["time_sec"] = value

        elif field_number == FIELD_MESSAGE_ID:

            result["message_id"] = value.hex()

        elif field_number == FIELD_QUESTION:

            for q_field, _, q_value in walk_fields(value):

                if q_field == QUESTION_FIELD_QNAME:

                    result["qname"] = q_value.decode("utf-8", errors="replace")

        elif field_number == FIELD_RESPONSE:

            response = {}

            for r_field, _, r_value in walk_fields(value):

                if r_field == RESPONSE_FIELD_RCODE:

                    response["rcode"] = r_value

                elif r_field == RESPONSE_FIELD_APPLIED_POLICY:

                    response["applied_policy"] = r_value.decode("utf-8", errors="replace")

                elif r_field == RESPONSE_FIELD_APPLIED_POLICY_HIT:

                    response["applied_policy_hit"] = r_value.decode("utf-8", errors="replace")

                elif r_field == RESPONSE_FIELD_APPLIED_POLICY_KIND:

                    response["applied_policy_kind"] = r_value

            result["response"] = response

    return result


def read_framed_message(sock_file) -> bytes | None:
    """
    Reads one length-prefixed PBDNSMessage from a buffered socket
    file object. Returns None on clean EOF (peer closed the
    connection between messages, not mid-frame).
    """

    length_prefix = sock_file.read(2)

    if not length_prefix or len(length_prefix) < 2:

        return None

    (length,) = struct.unpack("!H", length_prefix)

    payload = sock_file.read(length)

    if len(payload) < length:

        return None

    return payload
