from sqlalchemy import String, DateTime, Integer, Boolean, ForeignKey, Index
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class DnsQueryLog(Base):

    __tablename__ = "dns_query_logs"

    __table_args__ = (
        Index("ix_dns_query_logs_device_time", "device_id", "queried_at"),
        Index("ix_dns_query_logs_domain", "domain"),
    )


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    queried_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False
    )

    client_ip: Mapped[str] = mapped_column(
        String(45),
        nullable=False
    )

    # Best-effort resolution of client_ip -> device at write time,
    # using whatever the device inventory says THAT ip belonged to
    # right then. NULL if no match (unknown device, or the IP was
    # never seen in the device table).
    device_id: Mapped[int | None] = mapped_column(
        ForeignKey("network_devices.id"),
        nullable=True
    )

    # Nombre de la maquina al momento de escribir el log, desnormalizado
    # de forma que sobreviva aunque el dispositivo se elimine despues
    # (asi el historial de navegacion conserva el nombre del equipo).
    device_hostname: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    domain: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )

    blocked: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )

    policy_hit: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )
