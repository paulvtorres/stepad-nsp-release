import socketserver
import threading
import time

from datetime import datetime, timedelta

from backend.dns.logging.protobuf_decoder import (
    read_framed_message,
    decode_pbdns_message,
    TYPE_RESPONSE,
    BLOCKED_POLICY_KINDS
)

from backend.dns.logging.navigation_filters import (
    is_effective_navigation_domain,
)

from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.core.database.session import SessionLocal
from backend.retention.services.retention_service import RetentionService

from backend.network.devices.models.network_device import NetworkDevice

from backend.shared.logging.logger import logger


LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = 4242

FLUSH_INTERVAL_SECONDS = 3
DEVICE_CACHE_REFRESH_SECONDS = 30

DEFAULT_RETENTION_DAYS = 90
RETENTION_CHECK_INTERVAL_SECONDS = 3600


class DnsQueryLogListener:

    def __init__(self):

        self._buffer = []

        self._buffer_lock = threading.Lock()

        self._device_ip_map = {}

        self._device_ip_map_lock = threading.Lock()

        self._repository = DnsQueryLogRepository()

        self._server = None

        self._started = False

        self._last_message_at: float | None = None


    def _refresh_device_cache(self):

        db = SessionLocal()

        try:

            devices = db.query(NetworkDevice).all()

            new_map = {
                device.ip_address: (device.id, device.hostname)
                for device in devices
                if device.ip_address
            }

            with self._device_ip_map_lock:

                self._device_ip_map = new_map

        except Exception as error:

            logger.error(f"DNS query log: failed to refresh device cache: {error}")

        finally:

            db.close()


    def _resolve_device(self, client_ip: str | None):

        if not client_ip:

            return None, None

        with self._device_ip_map_lock:

            return self._device_ip_map.get(
                client_ip,
                (None, None)
            )


    def _resolve_device_id(self, client_ip: str | None):

        device_id, _ = self._resolve_device(client_ip)

        return device_id


    def enqueue(self, decoded: dict):

        if decoded.get("type") != TYPE_RESPONSE:

            return

        qname = decoded.get("qname")

        if not qname:

            return

        response = decoded.get("response", {})

        policy_kind = response.get("applied_policy_kind")

        blocked = policy_kind in BLOCKED_POLICY_KINDS

        domain = qname.rstrip(".")

        # OJO: un intento BLOQUEADO por politica RPZ tambien puede venir
        # con rcode NXDOMAIN (asi responde la politica de bloqueo) --
        # por eso el descarte de NXDOMAIN es SOLO para los NO bloqueados
        # (dominio realmente inexistente: tipeo, subdominio fantasma,
        # no es navegacion real). Si se aplicara tambien a los
        # bloqueados, ningun intento bloqueado llegaria a guardarse y
        # el panel de Proteccion, la hoja "Intentos bloqueados" del
        # reporte, el reporte de cumplimiento y la alerta de "pico de
        # bloqueos" quedarian siempre en cero (asi estuvo roto desde el
        # 16/ago hasta este fix: se dejo de registrar TODO bloqueo, no
        # solo excluirlo de la navegacion).
        if not blocked and response.get("rcode") == 3:  # NXDOMAIN

            return

        if not is_effective_navigation_domain(domain):

            return

        time_sec = decoded.get("time_sec")

        queried_at = (
            datetime.utcfromtimestamp(time_sec)
            if time_sec
            else datetime.utcnow()
        )

        record = DnsQueryLog(
            queried_at=queried_at,
            client_ip=decoded.get("client_ip") or "unknown",
            device_id=self._resolve_device_id(decoded.get("client_ip")),
            device_hostname=self._resolve_device(
                decoded.get("client_ip")
            )[1],
            domain=domain,
            blocked=blocked,
            policy_hit=response.get("applied_policy_hit")
        )

        with self._buffer_lock:

            self._buffer.append(record)


    def _flush_loop(self):

        while True:

            time.sleep(FLUSH_INTERVAL_SECONDS)

            with self._buffer_lock:

                if not self._buffer:

                    continue

                pending = self._buffer

                self._buffer = []

            for record in pending:

                if record.device_id is None and record.client_ip:

                    device_id, hostname = self._resolve_device(
                        record.client_ip
                    )

                    record.device_id = device_id

                    if hostname and not record.device_hostname:

                        record.device_hostname = hostname

            db = SessionLocal()

            try:

                self._repository.save_many(db, pending)

            except Exception as error:

                logger.error(f"DNS query log: failed to flush {len(pending)} records: {error}")

            finally:

                db.close()


    def _device_cache_loop(self):

        while True:

            self._refresh_device_cache()

            time.sleep(DEVICE_CACHE_REFRESH_SECONDS)


    def _retention_loop(self, retention_days: int):

        while True:

            time.sleep(RETENTION_CHECK_INTERVAL_SECONDS)

            db = SessionLocal()

            try:

                days = RetentionService().days_for(
                    db, "dns_logs", fallback=retention_days
                )

                if days <= 0:

                    continue

                cutoff = datetime.utcnow() - timedelta(days=days)

                deleted = self._repository.delete_older_than(db, cutoff)

                if deleted:

                    logger.info(
                        f"DNS query log: pruned {deleted} record(s) older than {days} days"
                    )

            except Exception as error:

                logger.error(f"DNS query log: retention cleanup failed: {error}")

            finally:

                db.close()


    def start(self, retention_days: int = DEFAULT_RETENTION_DAYS):

        if self._started:

            return

        self._started = True

        listener = self

        class Handler(socketserver.BaseRequestHandler):

            def handle(self):

                sock_file = self.request.makefile("rb")

                try:

                    while True:

                        payload = read_framed_message(sock_file)

                        if payload is None:

                            break

                        listener._last_message_at = time.time()

                        try:

                            decoded = decode_pbdns_message(payload)

                            listener.enqueue(decoded)

                        except Exception as error:

                            logger.error(f"DNS query log: failed to decode message: {error}")

                except (ConnectionResetError, BrokenPipeError):

                    pass

                finally:

                    sock_file.close()

        try:

            class _ReusableServer(socketserver.ThreadingTCPServer):

                allow_reuse_address = True

            # Reintenta el bind: tras reiniciar el servicio puede haber
            # sockets en TIME_WAIT/CLOSE_WAIT de pdns_recursor que aun
            # no se liberan. SO_REUSEADDR + reintentos lo resuelven.
            server = None

            for _attempt in range(5):

                try:

                    server = _ReusableServer(
                        (LISTEN_HOST, LISTEN_PORT),
                        Handler
                    )

                    break

                except OSError:

                    time.sleep(2)

            if server is None:

                raise OSError(
                    f"port {LISTEN_PORT} in use after 5 attempts"
                )

            self._server = server

        except OSError:

            logger.error(
                f"DNS query log: port {LISTEN_PORT} is still in use "
                f"even after retries -- query logging will not be "
                f"available this run."
            )
            self._started = False

            return False


        self._server.daemon_threads = True

        threading.Thread(target=self._server.serve_forever, daemon=True).start()

        threading.Thread(target=self._flush_loop, daemon=True).start()

        threading.Thread(target=self._device_cache_loop, daemon=True).start()

        threading.Thread(
            target=self._retention_loop,
            args=(retention_days,),
            daemon=True
        ).start()

        logger.info(
            f"DNS query log listener started on {LISTEN_HOST}:{LISTEN_PORT} "
            f"(retention: {retention_days} days)"
        )

        return True

    def is_started(self) -> bool:

        return self._started

    def last_message_at(self) -> float | None:

        return self._last_message_at


dns_query_log_listener = DnsQueryLogListener()
