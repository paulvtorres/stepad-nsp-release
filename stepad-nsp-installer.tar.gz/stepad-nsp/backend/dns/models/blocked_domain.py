from dataclasses import dataclass


@dataclass
class BlockedDomain:

    domain: str