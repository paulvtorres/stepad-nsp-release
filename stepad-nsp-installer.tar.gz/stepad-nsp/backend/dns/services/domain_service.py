from datetime import datetime

from sqlalchemy.orm import Session

from backend.dns.providers.dns_provider_interface import (
    DnsProviderInterface
)

from backend.dns.providers.zone_pdns_provider import ZonePdnsProvider

from backend.dns.factory import (
    get_dns_provider
)

from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.network.zones.repositories.schedule_repository import (
    ScheduleRepository
)

from backend.shared.enums import ScopeType, RuleAction

from backend.dhcp.models.dhcp_diagnosis import (
    DhcpDiagnosis,
    DhcpCheck
)


class DomainService:


    def __init__(
        self,
        provider: DnsProviderInterface = None
    ):

        # Depends on the interface, not a concrete class. Defaults to
        # the shared singleton from the factory so that every service
        # (DomainService, GlobalRuleService, RuleEngine, ...) talks to
        # the SAME provider instance instead of restarting dnsmasq
        # once per instance per change.
        self.provider = provider or get_dns_provider()

        self.repository = DeviceAccessRuleRepository()

        self.zone_repository = NetworkZoneRepository()

        self.schedule_repository = ScheduleRepository()



    def _is_rule_active_now(
        self,
        db: Session,
        rule,
        now: datetime
    ) -> bool:

        if not rule.schedule_id:

            return True

        schedule = self.schedule_repository.find_by_id(
            db,
            rule.schedule_id
        )

        if not schedule:

            return True

        return schedule.is_active_now(now)



    def synchronize(
        self,
        db: Session
    ):
        """
        The GLOBAL (default zone / no-zone-system) blocklist.
        Unchanged behavior for anyone not using NetworkZone yet --
        this keeps working exactly as before.
        """

        now = datetime.utcnow()

        rules = self.repository.find_global_domains(db)

        domains = [

            rule.value.strip().lower()

            for rule in rules

            if rule.value and self._is_rule_active_now(db, rule, now)

        ]

        self.provider.generate_domains_config(domains)

        return self.provider.reload()



    def synchronize_zone(
        self,
        db: Session,
        zone_id: int
    ):
        """
        Computes the effective domain blocklist for ONE zone and
        pushes it to that zone's own PowerDNS instance.

        Merge order (see the is_permanent design discussion):
          1. Permanent global blocks -- ALWAYS included, no zone can
             override these (e.g. adult content).
          2. Default global blocks -- included UNLESS this zone has
             an explicit ALLOW for that same value (e.g. a
             "Contabilidad" zone allowed onto specific banking/social
             sites that are blocked everywhere else by default).
          3. The zone's own additional BLOCK rules -- always added,
             on top of the above.

        Each rule is only counted if active right now, per its
        optional Schedule (see Schedule.is_active_now). No schedule
        attached = always active, identical to today's behavior.
        """

        now = datetime.utcnow()

        zone = self.zone_repository.find_by_id(db, zone_id)

        if not zone:

            return {"success": False, "message": f"Zone {zone_id} not found"}

        all_global = self.repository.find_global_domains(db)

        permanent_blocks = {

            rule.value.strip().lower()

            for rule in all_global

            if rule.is_permanent
            and rule.action == RuleAction.BLOCK
            and self._is_rule_active_now(db, rule, now)

        }

        default_blocks = {

            rule.value.strip().lower()

            for rule in all_global

            if not rule.is_permanent
            and rule.action == RuleAction.BLOCK
            and self._is_rule_active_now(db, rule, now)

        }

        zone_rules = self.repository.find_zone_domains(db, zone_id)

        zone_allows = {

            rule.value.strip().lower()

            for rule in zone_rules

            if rule.action == RuleAction.ALLOW
            and self._is_rule_active_now(db, rule, now)

        }

        zone_blocks = {

            rule.value.strip().lower()

            for rule in zone_rules

            if rule.action == RuleAction.BLOCK
            and self._is_rule_active_now(db, rule, now)

        }

        # Permanent blocks are unioned in LAST and never subtracted --
        # this is what makes them un-overridable regardless of what a
        # zone's ALLOW rules say.
        effective = (default_blocks - zone_allows) | zone_blocks | permanent_blocks

        pdns = ZonePdnsProvider(zone)

        pdns.generate_domains_config(list(effective))

        return pdns.reload()



    def synchronize_all_zones(
        self,
        db: Session
    ):

        results = {}

        for zone in self.zone_repository.find_all(db):

            results[zone.id] = self.synchronize_zone(db, zone.id)

        return results



    def get_status(self):

        return self.provider.get_status()



    def diagnose(self):

        checks = []

        healthy = True

        #
        # Configuration file
        #

        config = self.provider.get_configuration_path()

        config_exists = config.exists()

        checks.append(

            DhcpCheck(

                name="RPZ Configuration",

                status="OK" if config_exists else "FAILED",

                message=str(config),

                action=(
                    None
                    if config_exists
                    else "Generate RPZ configuration"
                )

            )

        )

        if not config_exists:

            healthy = False

        #
        # Blocked domains
        #

        domains_count = self.provider.get_domains_count()

        checks.append(

            DhcpCheck(

                name="Blocked Domains",

                status="INFO" if domains_count == 0 else "OK",

                message=f"{domains_count} domains configured",

                action=(
                    "Create domain blocking rules"
                    if domains_count == 0
                    else None
                )

            )

        )

        #
        # DNS process
        #

        status = self.get_status()

        running = status["running"]

        checks.append(

            DhcpCheck(

                name="DNS Process",

                status="OK" if running else "FAILED",

                message=(
                    f"DNS running PID {status['pid']}"
                    if running
                    else "DNS stopped"
                ),

                action=(
                    None
                    if running
                    else "Start DNS service"
                )

            )

        )

        if not running:

            healthy = False

        summary = (
            "DNS service is running"
            if running
            else "DNS service is stopped"
        )

        return DhcpDiagnosis(

            healthy=healthy,

            summary=summary,

            checks=checks

        )
