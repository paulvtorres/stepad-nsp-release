from sqlalchemy.orm import Session

from backend.siem.models.syslog_settings import SyslogSettings
from backend.siem.models.compliance_settings import ComplianceSettings


class SyslogSettingsRepository:

    def get(
        self,
        db: Session
    ) -> SyslogSettings:

        settings = db.get(SyslogSettings, 1)

        if settings is None:

            settings = SyslogSettings(id=1)

            db.add(settings)

            db.commit()

            db.refresh(settings)

        return settings

    def save(
        self,
        db: Session,
        settings: SyslogSettings
    ):

        db.commit()

        db.refresh(settings)

        return settings


class ComplianceSettingsRepository:

    def get(
        self,
        db: Session
    ) -> ComplianceSettings:

        settings = db.get(ComplianceSettings, 1)

        if settings is None:

            settings = ComplianceSettings(id=1)

            db.add(settings)

            db.commit()

            db.refresh(settings)

        return settings

    def save(
        self,
        db: Session,
        settings: ComplianceSettings
    ):

        db.commit()

        db.refresh(settings)

        return settings
