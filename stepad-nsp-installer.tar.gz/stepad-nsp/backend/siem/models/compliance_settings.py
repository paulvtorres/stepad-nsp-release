from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class ComplianceSettings(Base):

    __tablename__ = "compliance_settings"


    id: Mapped[int] = mapped_column(
        primary_key=True
    )


    # How many days of DNS query logs are kept before pruning.
    log_retention_days: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=365
    )


    # Person responsible for reviewing logs, and how often (days).
    logs_reviewer_email: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    logs_review_frequency_days: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=7
    )

    last_logs_review: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
