from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class SyslogSettings(Base):

    __tablename__ = "syslog_settings"


    id: Mapped[int] = mapped_column(
        primary_key=True
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    server: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )


    port: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=514
    )


    # udp | tcp
    protocol: Mapped[str] = mapped_column(
        String(10),
        nullable=False,
        default="udp"
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
