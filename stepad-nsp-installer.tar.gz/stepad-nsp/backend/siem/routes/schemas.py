from pydantic import BaseModel


class SyslogSettingsRequest(BaseModel):

    enabled: bool | None = None

    server: str | None = None

    port: int | None = None

    protocol: str | None = None


class ComplianceSettingsRequest(BaseModel):

    log_retention_days: int | None = None


class LogsReviewRequest(BaseModel):

    reviewer_email: str | None = None

    frequency_days: int | None = None
