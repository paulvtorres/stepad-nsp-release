from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime
from backend.shared.datetime_utils import utcnow
from backend.core.database.base import Base


class ADGroupMapping(Base):

    __tablename__ = "ad_group_mappings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ad_group_dn: Mapped[str] = mapped_column(String(512), unique=True, nullable=False)
    ad_group_name: Mapped[str] = mapped_column(String(255), default="")
    nsp_group_id: Mapped[int] = mapped_column(
        ForeignKey("device_groups.id", ondelete="CASCADE"), nullable=False
    )
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )
