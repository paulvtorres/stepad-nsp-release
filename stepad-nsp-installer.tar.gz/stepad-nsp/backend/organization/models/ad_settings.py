from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime
from backend.shared.datetime_utils import utcnow
from backend.core.database.base import Base


class ADSettings(Base):

    __tablename__ = "ad_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    login_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    sync_interval_minutes: Mapped[int] = mapped_column(Integer, default=15)
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_sync_ok: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    last_sync_message: Mapped[str | None] = mapped_column(String(512), nullable=True)
    domain_name: Mapped[str] = mapped_column(String(255), default="")
    server: Mapped[str] = mapped_column(String(255), default="")
    port: Mapped[int] = mapped_column(Integer, default=636)
    use_ssl: Mapped[bool] = mapped_column(Boolean, default=True)
    verify_tls: Mapped[bool] = mapped_column(Boolean, default=True)
    base_dn: Mapped[str] = mapped_column(String(512), default="")
    bind_dn: Mapped[str] = mapped_column(String(512), default="")
    bind_password: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    user_filter: Mapped[str] = mapped_column(
        String(255), default="(sAMAccountName={username})"
    )
    group_filter: Mapped[str] = mapped_column(
        String(255), default="(member={user_dn})"
    )
    default_group_id: Mapped[int | None] = mapped_column(
        ForeignKey("device_groups.id", ondelete="SET NULL"), nullable=True
    )
    last_test_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_test_ok: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    last_test_message: Mapped[str | None] = mapped_column(String(512), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )
