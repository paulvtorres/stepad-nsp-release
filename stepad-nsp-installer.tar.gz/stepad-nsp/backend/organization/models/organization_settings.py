from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class OrganizationSettings(Base):

    __tablename__ = "organization_settings"


    id: Mapped[int] = mapped_column(
        primary_key=True
    )


    company_name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )


    ruc: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True
    )


    address: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    phone: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True
    )


    email: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    city: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )


    country: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
