import threading

from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.core.database.session import SessionLocal
from backend.organization.services.ad_directory_service import ad_directory_service
from backend.shared.logging.logger import logger


class ADDirectoryComponent(BaseComponent):

    name = "ad_directory"
    criticality = ComponentCriticality.OPTIONAL

    def __init__(self):
        self._thread = None
        self._stop = threading.Event()

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="ad-directory-sync"
        )
        self._thread.start()
        logger.info("ADDirectoryComponent started (sync task).")

    def _loop(self):
        while not self._stop.wait(60):
            db = SessionLocal()
            try:
                ad_directory_service.sync_if_due(db)
            except Exception as error:
                logger.warning("AD directory sync: %s", error)
            finally:
                db.close()

    def health_check(self):
        return bool(self._thread and self._thread.is_alive())

    def stop(self):
        self._stop.set()
        logger.info("ADDirectoryComponent stopped.")
