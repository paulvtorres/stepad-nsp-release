"""Authenticate an existing NSP user against AD read-only."""

from __future__ import annotations

from sqlalchemy.orm import Session

from backend.organization.models.ad_settings import ADSettings
from backend.shared.security.secret_box import decrypt


class ADAuthService:

    def authenticate(self, db: Session, username: str, password: str) -> dict:
        row = db.query(ADSettings).filter(ADSettings.id == 1).first()

        if (
            row is None
            or not row.enabled
            or not getattr(row, "login_enabled", False)
            or not row.server
            or not row.base_dn
            or not password
        ):
            return {"success": False, "message": "AD login no habilitado."}

        try:
            from ldap3 import Connection, Server, Tls
            from ldap3.core.exceptions import LDAPException
            from ldap3.utils.conv import escape_filter_chars
        except ImportError:
            return {"success": False, "message": "Falta el módulo ldap3."}

        user_filter = (row.user_filter or "(sAMAccountName={username})").format(
            username=escape_filter_chars(username)
        )

        try:
            server = Server(
                row.server,
                port=int(row.port or 636),
                use_ssl=bool(row.use_ssl),
                tls=Tls(validate=2 if row.verify_tls else 0),
                connect_timeout=6,
            )
            service_conn = Connection(
                server,
                user=row.bind_dn or None,
                password=decrypt(row.bind_password) if row.bind_password else None,
                auto_bind=True,
                receive_timeout=8,
            )
            service_conn.search(
                row.base_dn,
                user_filter,
                attributes=["distinguishedName", "sAMAccountName"],
                size_limit=2,
            )

            if not service_conn.entries:
                return {"success": False, "message": "Usuario no encontrado en AD."}

            user_dn = str(service_conn.entries[0].entry_dn)
            service_conn.unbind()

            user_conn = Connection(
                server,
                user=user_dn,
                password=password,
                auto_bind=True,
                receive_timeout=8,
            )
            ok = bool(user_conn.bound)
            user_conn.unbind()
            return {
                "success": ok,
                "message": "Autenticado por AD." if ok else "Credenciales AD inválidas.",
                "dn": user_dn,
            }
        except (LDAPException, OSError, ValueError) as error:
            return {"success": False, "message": str(error)[:300]}


ad_auth_service = ADAuthService()
