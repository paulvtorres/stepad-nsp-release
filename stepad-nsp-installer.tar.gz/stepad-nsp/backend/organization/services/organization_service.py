from sqlalchemy.orm import Session

from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository
)


class OrganizationService:

    def __init__(self):

        self.repository = OrganizationSettingsRepository()

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        return {
            "company_name": settings.company_name,
            "ruc": settings.ruc,
            "address": settings.address,
            "phone": settings.phone,
            "email": settings.email,
            "city": settings.city,
            "country": settings.country,
            "configured": bool(
                settings.company_name.strip()
            )
        }

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.repository.get(db)

        if data.company_name is not None:
            settings.company_name = data.company_name

        if data.ruc is not None:
            settings.ruc = data.ruc or None

        if data.address is not None:
            settings.address = data.address or None

        if data.phone is not None:
            settings.phone = data.phone or None

        if data.email is not None:
            settings.email = data.email or None

        if data.city is not None:
            settings.city = data.city or None

        if data.country is not None:
            settings.country = data.country or None

        self.repository.save(db, settings)

        return self.get_settings(db)
