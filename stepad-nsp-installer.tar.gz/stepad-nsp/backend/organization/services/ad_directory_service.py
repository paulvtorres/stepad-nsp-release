"""Read-only AD directory preview and explicit group mappings."""

from __future__ import annotations

import json
from datetime import timedelta

from sqlalchemy.orm import Session

from backend.groups.models.device_group import DeviceGroup
from backend.network.devices.models.network_device import NetworkDevice
from backend.organization.models.ad_group_mapping import ADGroupMapping
from backend.organization.models.ad_directory_snapshot import ADDirectorySnapshot
from backend.organization.models.ad_settings import ADSettings
from backend.shared.datetime_utils import utcnow
from backend.shared.security.secret_box import decrypt


class ADDirectoryService:

    def _settings(self, db: Session) -> ADSettings | None:
        return db.query(ADSettings).filter(ADSettings.id == 1).first()

    def _connect(self, db: Session):
        row = self._settings(db)

        if row is None or not row.server or not row.base_dn:
            return None, "Configura servidor y Base DN primero."

        try:
            from ldap3 import Connection, Server, Tls
            from ldap3.core.exceptions import LDAPException
        except ImportError:
            return None, "Falta el módulo ldap3."

        try:
            tls = Tls(validate=2 if row.verify_tls else 0)
            server = Server(
                row.server,
                port=int(row.port or 636),
                use_ssl=bool(row.use_ssl),
                tls=tls,
                connect_timeout=6,
            )
            connection = Connection(
                server,
                user=row.bind_dn or None,
                password=decrypt(row.bind_password) if row.bind_password else None,
                auto_bind=True,
                receive_timeout=8,
            )
            return connection, ""
        except Exception as error:
            return None, str(error)[:400]

    @staticmethod
    def _value(entry, name: str):
        value = entry.get(name)
        return value.value if value is not None else None

    def directory(self, db: Session) -> dict:
        connection, error = self._connect(db)

        if connection is None:
            return {"success": False, "message": error}

        row = self._settings(db)
        groups = []
        computers = []
        memberships: dict[str, list[str]] = {}

        try:
            connection.search(
                row.base_dn,
                "(objectClass=group)",
                attributes=["distinguishedName", "sAMAccountName", "name", "member"],
                size_limit=1000,
            )

            for entry in connection.entries:
                dn = str(entry.entry_dn)
                name = self._value(entry, "name") or self._value(entry, "sAMAccountName") or dn
                members = []
                member_attr = entry.get("member")
                if member_attr is not None:
                    members = [str(item) for item in (member_attr.values or [])]
                groups.append({"dn": dn, "name": str(name), "members": len(members)})
                for member in members:
                    memberships.setdefault(member, []).append(str(name))

            connection.search(
                row.base_dn,
                "(objectClass=computer)",
                attributes=["distinguishedName", "sAMAccountName", "name", "dNSHostName"],
                size_limit=1000,
            )

            device_rows = db.query(NetworkDevice).all()
            devices_by_name = {}

            for device in device_rows:
                for value in (device.hostname, device.display_name, device.mac_address):
                    if value:
                        devices_by_name[str(value).strip().lower()] = device

            for entry in connection.entries:
                dn = str(entry.entry_dn)
                hostname = (
                    self._value(entry, "dNSHostName")
                    or self._value(entry, "name")
                    or self._value(entry, "sAMAccountName")
                    or ""
                )
                short = str(hostname).split(".", 1)[0].strip().lower()
                device = devices_by_name.get(short)
                ad_groups = memberships.get(dn, [])
                computers.append({
                    "dn": dn,
                    "name": str(self._value(entry, "name") or ""),
                    "hostname": str(hostname),
                    "matched_device_id": device.id if device else None,
                    "matched_device": (
                        device.display_name or device.hostname or device.ip_address
                        if device else None
                    ),
                    "ad_groups": ad_groups,
                })

            return {
                "success": True,
                "domain": row.domain_name or "",
                "groups": groups,
                "computers": computers,
                "matched": sum(1 for item in computers if item["matched_device_id"]),
                "mappings": self.mappings(db),
            }
        except Exception as error:
            return {"success": False, "message": str(error)[:400]}
        finally:
            try:
                connection.unbind()
            except Exception:
                pass

    def sync(self, db: Session) -> dict:
        """Read AD now and persist the snapshot for later UI use."""

        result = self.directory(db)
        row = self._settings(db)

        if row is not None:
            row.last_sync_at = utcnow()
            row.last_sync_ok = bool(result.get("success"))
            row.last_sync_message = str(result.get("message") or "")[:512]
            db.add(ADDirectorySnapshot(
                success=bool(result.get("success")),
                message=str(result.get("message") or "")[:512],
                data=json.dumps(result, ensure_ascii=False, default=str),
            ))
            db.commit()

        result["synced_at"] = utcnow().isoformat()
        return result

    def latest(self, db: Session) -> dict:
        row = (
            db.query(ADDirectorySnapshot)
            .order_by(ADDirectorySnapshot.id.desc())
            .first()
        )

        if row is None:
            return {"success": False, "message": "Sin sincronización AD todavía."}

        try:
            result = json.loads(row.data)
        except ValueError:
            result = {"success": False, "message": "Snapshot AD inválido."}

        result["synced_at"] = row.created_at.isoformat() if row.created_at else None
        return result

    def sync_if_due(self, db: Session) -> dict:
        row = self._settings(db)

        if row is None or not row.enabled or not row.server or not row.base_dn:
            return {"success": False, "message": "AD no configurado o desactivado."}

        interval = max(1, min(1440, int(row.sync_interval_minutes or 15)))

        if row.last_sync_at and (
            utcnow() - row.last_sync_at
        ) < timedelta(minutes=interval):
            return {"success": True, "message": "Sin cambios; sincronización no vencida."}

        return self.sync(db)


    def mappings(self, db: Session) -> list[dict]:
        rows = db.query(ADGroupMapping).all()
        groups = {group.id: group for group in db.query(DeviceGroup).all()}

        return [
            {
                "id": row.id,
                "ad_group_dn": row.ad_group_dn,
                "ad_group_name": row.ad_group_name,
                "nsp_group_id": row.nsp_group_id,
                "nsp_group": groups.get(row.nsp_group_id).name if row.nsp_group_id in groups else "",
                "enabled": bool(row.enabled),
            }
            for row in rows
        ]

    def save_mapping(self, db: Session, payload: dict) -> dict:
        dn = str(payload.get("ad_group_dn") or "").strip()
        name = str(payload.get("ad_group_name") or "").strip()
        group_id = payload.get("nsp_group_id")

        if not dn or not group_id:
            raise ValueError("Grupo AD y grupo NSP son obligatorios.")

        group = db.query(DeviceGroup).filter(DeviceGroup.id == int(group_id)).first()

        if group is None:
            raise ValueError("Grupo NSP no encontrado.")

        row = db.query(ADGroupMapping).filter(ADGroupMapping.ad_group_dn == dn).first()

        if row is None:
            row = ADGroupMapping(ad_group_dn=dn)
            db.add(row)

        row.ad_group_name = name
        row.nsp_group_id = group.id
        row.enabled = bool(payload.get("enabled", True))
        db.commit()
        db.refresh(row)
        return {
            "id": row.id,
            "ad_group_dn": row.ad_group_dn,
            "ad_group_name": row.ad_group_name,
            "nsp_group_id": row.nsp_group_id,
            "nsp_group": group.name,
            "enabled": bool(row.enabled),
        }

    def delete_mapping(self, db: Session, mapping_id: int) -> bool:
        row = db.query(ADGroupMapping).filter(ADGroupMapping.id == mapping_id).first()
        if row is None:
            return False
        db.delete(row)
        db.commit()
        return True


ad_directory_service = ADDirectoryService()
