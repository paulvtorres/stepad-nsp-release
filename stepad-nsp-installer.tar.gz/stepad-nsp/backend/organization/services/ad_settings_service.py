"""AD/LDAP configuration only. Group/user sync is a later phase."""

from __future__ import annotations

from sqlalchemy.orm import Session

from backend.groups.models.device_group import DeviceGroup
from backend.organization.models.ad_settings import ADSettings
from backend.shared.datetime_utils import utcnow
from backend.shared.security.secret_box import decrypt, encrypt
from backend.shared.logging.logger import logger


class ADSettingsService:

    def _row(self, db: Session) -> ADSettings:
        row = db.query(ADSettings).filter(ADSettings.id == 1).first()
        if row is None:
            row = ADSettings(id=1)
            db.add(row)
            db.commit()
            db.refresh(row)
        return row

    def _dict(self, db: Session, row: ADSettings) -> dict:
        groups = [
            {"id": group.id, "name": group.name}
            for group in db.query(DeviceGroup).all()
        ]
        return {
            "configured": bool(row.server and row.base_dn),
            "enabled": bool(row.enabled),
            "login_enabled": bool(getattr(row, "login_enabled", False)),
            "sync_interval_minutes": int(getattr(row, "sync_interval_minutes", 15) or 15),
            "last_sync_at": row.last_sync_at.isoformat() if row.last_sync_at else None,
            "last_sync_ok": row.last_sync_ok,
            "last_sync_message": row.last_sync_message or "",
            "domain_name": row.domain_name or "",
            "server": row.server or "",
            "port": int(row.port or 636),
            "use_ssl": bool(row.use_ssl),
            "verify_tls": bool(row.verify_tls),
            "base_dn": row.base_dn or "",
            "bind_dn": row.bind_dn or "",
            "password_set": bool(row.bind_password),
            "user_filter": row.user_filter or "",
            "group_filter": row.group_filter or "",
            "default_group_id": row.default_group_id,
            "groups": groups,
            "last_test_at": row.last_test_at.isoformat() if row.last_test_at else None,
            "last_test_ok": row.last_test_ok,
            "last_test_message": row.last_test_message or "",
            "updated_at": row.updated_at.isoformat() if row.updated_at else None,
        }

    def get(self, db: Session) -> dict:
        return self._dict(db, self._row(db))

    def save(self, db: Session, payload: dict) -> dict:
        row = self._row(db)

        for field in (
            "enabled", "login_enabled", "sync_interval_minutes", "domain_name", "server", "base_dn", "bind_dn",
            "user_filter", "group_filter", "default_group_id",
            "use_ssl", "verify_tls",
        ):
            if field in payload:
                setattr(row, field, payload[field])

        if "port" in payload:
            port = int(payload["port"])
            if not 1 <= port <= 65535:
                raise ValueError("Puerto inválido.")
            row.port = port

        if "sync_interval_minutes" in payload:
            interval = int(payload["sync_interval_minutes"])
            if not 1 <= interval <= 1440:
                raise ValueError("Intervalo de sincronización inválido.")
            row.sync_interval_minutes = interval

        password = payload.get("bind_password")
        if password not in (None, "", "********"):
            row.bind_password = encrypt(password)

        if row.enabled and not (row.server and row.base_dn):
            raise ValueError(
                "Para activar AD, completa servidor y Base DN."
            )

        db.commit()
        db.refresh(row)
        return self._dict(db, row)

    def test(self, db: Session) -> dict:
        row = self._row(db)

        if not (row.server and row.base_dn):
            return {
                "success": False,
                "message": "Configura servidor y Base DN antes de probar.",
            }

        try:
            from ldap3 import Connection, Server, Tls
            from ldap3.core.exceptions import LDAPException
        except ImportError:
            return {
                "success": False,
                "message": "Falta el módulo ldap3. Instálalo antes de probar.",
            }

        try:
            tls = Tls(validate=2 if row.verify_tls else 0)
            server = Server(
                row.server,
                port=int(row.port or 636),
                use_ssl=bool(row.use_ssl),
                tls=tls,
                connect_timeout=6,
            )
            connection = Connection(
                server,
                user=row.bind_dn or None,
                password=decrypt(row.bind_password) if row.bind_password else None,
                auto_bind=True,
                receive_timeout=6,
            )
            connection.search(
                row.base_dn,
                "(objectClass=*)",
                attributes=["distinguishedName"],
                size_limit=1,
            )
            ok = bool(connection.bound)
            message = (
                f"Conexión correcta con {row.server}:{row.port}."
                if ok else "El servidor respondió, pero el bind no quedó activo."
            )
        except (LDAPException, OSError, ValueError) as error:
            ok = False
            message = str(error)[:400]

        row.last_test_at = utcnow()
        row.last_test_ok = ok
        row.last_test_message = message
        db.commit()
        return {"success": ok, "message": message}
