from sqlalchemy.orm import Session

from backend.organization.models.organization_settings import (
    OrganizationSettings
)


class OrganizationSettingsRepository:

    def get(
        self,
        db: Session
    ) -> OrganizationSettings:

        settings = db.get(OrganizationSettings, 1)

        if settings is None:

            settings = OrganizationSettings(id=1)

            db.add(settings)

            db.commit()

            db.refresh(settings)

        return settings

    def save(
        self,
        db: Session,
        settings: OrganizationSettings
    ):

        db.commit()

        db.refresh(settings)

        return settings
