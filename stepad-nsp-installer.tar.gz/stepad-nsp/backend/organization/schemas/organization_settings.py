from pydantic import BaseModel


class OrganizationSettingsRequest(BaseModel):

    company_name: str | None = None

    ruc: str | None = None

    address: str | None = None

    phone: str | None = None

    email: str | None = None

    city: str | None = None

    country: str | None = None
