from backend.core.bootstrap import Bootstrap
from backend.core.single_instance import single_instance_guard
from backend.shared.logging.logger import logger


def main():

    # This appliance should only ever run one STEPAD instance -- if
    # a previous one is still up (e.g. this is a manual run while
    # the systemd service is also active), stop it before we try to
    # bind the same ports/resources it's holding.
    single_instance_guard.ensure_single_instance()

    bootstrap = Bootstrap()

    try:

        # Blocks for the entire lifetime of the app: the last
        # component started, ApiComponent, calls uvicorn.run() which
        # doesn't return until uvicorn itself handles SIGINT/SIGTERM
        # and shuts its HTTP server down gracefully (that's uvicorn's
        # own built-in behavior, not something this code drives).
        #
        # So this call returning -- for ANY reason -- IS the signal
        # that it's time to shut the rest of STEPAD down. There's
        # deliberately no separate "wait for a signal" loop after
        # this: registering a handler down there would run too late
        # (uvicorn's own shutdown already happened by the time
        # control gets back here), which is exactly what caused a
        # second, uncaught SIGTERM to kill the process outright
        # before bootstrap.stop()/single_instance_guard.release()
        # ever ran.
        bootstrap.start()

        logger.info("API server stopped.")

    except KeyboardInterrupt:

        logger.info("")

        logger.info("Shutdown requested (SIGINT)...")

    finally:

        bootstrap.stop()

        single_instance_guard.release()

        logger.info("STEPAD NSP stopped cleanly.")


if __name__ == "__main__":

    main()
