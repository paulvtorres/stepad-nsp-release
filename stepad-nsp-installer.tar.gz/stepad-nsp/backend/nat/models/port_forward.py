from sqlalchemy import Boolean, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class PortForward(Base):

    __tablename__ = "port_forwards"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False
    )


    # tcp | udp | both
    protocol: Mapped[str] = mapped_column(
        String(5),
        nullable=False,
        default="tcp"
    )


    external_port: Mapped[int] = mapped_column(
        Integer,
        nullable=False
    )


    internal_ip: Mapped[str] = mapped_column(
        String(45),
        nullable=False
    )


    internal_port: Mapped[int] = mapped_column(
        Integer,
        nullable=False
    )


    # NULL = apply on every current WAN interface
    wan_interface: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
