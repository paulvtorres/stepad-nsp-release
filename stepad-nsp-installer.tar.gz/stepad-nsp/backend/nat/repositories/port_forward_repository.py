from sqlalchemy.orm import Session

from backend.nat.models.port_forward import PortForward


class PortForwardRepository:

    def find_all(
        self,
        db: Session
    ):

        return db.query(PortForward).all()

    def find_enabled(
        self,
        db: Session
    ):

        return (
            db.query(PortForward)
            .filter(PortForward.enabled.is_(True))
            .all()
        )

    def find_by_id(
        self,
        db: Session,
        forward_id: int
    ):

        return (
            db.query(PortForward)
            .filter(PortForward.id == forward_id)
            .first()
        )

    def save(
        self,
        db: Session,
        forward: PortForward
    ):

        db.add(forward)

        db.commit()

        db.refresh(forward)

        return forward

    def delete(
        self,
        db: Session,
        forward: PortForward
    ):

        db.delete(forward)

        db.commit()
