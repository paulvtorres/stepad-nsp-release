from fastapi import HTTPException

from sqlalchemy.orm import Session

from backend.nat.models.port_forward import PortForward
from backend.nat.repositories.port_forward_repository import (
    PortForwardRepository
)
from backend.nat.providers.linux_nat_provider import LinuxNatProvider

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)


class PortForwardService:

    def __init__(self):

        self.repository = PortForwardRepository()

        self.provider = LinuxNatProvider()

        self.interface_service = InterfaceService()

    def list_forwards(
        self,
        db: Session
    ):

        return self.repository.find_all(db)

    def _wan_names(
        self
    ) -> list[str]:

        wans = self.interface_service.get_wan_interfaces()

        return [wan.name for wan in wans]

    def sync(
        self,
        db: Session
    ):

        wan_names = self._wan_names()

        forwards = self.repository.find_enabled(db)

        return self.provider.sync_port_forwards(
            wan_names,
            forwards
        )

    def create(
        self,
        db: Session,
        data
    ):

        forward = PortForward(
            name=data.name,
            protocol=data.protocol,
            external_port=data.external_port,
            internal_ip=data.internal_ip,
            internal_port=data.internal_port,
            wan_interface=data.wan_interface or None,
            enabled=data.enabled
        )

        saved = self.repository.save(db, forward)

        self.sync(db)

        return saved

    def update(
        self,
        db: Session,
        forward_id: int,
        data
    ):

        forward = self.repository.find_by_id(db, forward_id)

        if forward is None:

            raise HTTPException(
                status_code=404,
                detail="Port forward not found"
            )

        if data.name is not None:
            forward.name = data.name

        if data.protocol is not None:
            forward.protocol = data.protocol

        if data.external_port is not None:
            forward.external_port = data.external_port

        if data.internal_ip is not None:
            forward.internal_ip = data.internal_ip

        if data.internal_port is not None:
            forward.internal_port = data.internal_port

        if data.wan_interface is not None:
            forward.wan_interface = data.wan_interface or None

        if data.enabled is not None:
            forward.enabled = data.enabled

        db.commit()

        db.refresh(forward)

        self.sync(db)

        return forward

    def delete(
        self,
        db: Session,
        forward_id: int
    ):

        forward = self.repository.find_by_id(db, forward_id)

        if forward is None:

            raise HTTPException(
                status_code=404,
                detail="Port forward not found"
            )

        self.repository.delete(db, forward)

        self.sync(db)

        return {"success": True}
