from backend.nat.providers.linux_nat_provider import LinuxNatProvider

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.shared.logging.logger import logger


class NatService:


    def __init__(self):

        self.provider = LinuxNatProvider()

        self.interface_service = InterfaceService()


    def enable_default_nat(self):

        wans = self.interface_service.get_wan_interfaces()

        if not wans:

            logger.error(
                "NAT: no WAN interface assigned yet -- masquerade not configured."
            )

            return {

                "forwarding": {"success": False, "error": "No WAN interface detected"},

                "nat": {"success": False, "error": "No WAN interface detected"}

            }

        wan_names = [wan.name for wan in wans]

        forwarding = (
            self.provider.enable_forwarding()
        )

        nat = (
            self.provider.sync_masquerade(wan_names)
        )

        logger.info(
            f"NAT configured for WAN(s): {wan_names}"
        )

        return {

            "forwarding": forwarding,

            "nat": nat

        }

    def get_status(self):

        return {

            "running": True

        }