from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.database.session import SessionLocal

from backend.nat.services.nat_service import NatService
from backend.nat.services.port_forward_service import PortForwardService

from backend.shared.logging.logger import logger



class NatComponent(BaseComponent):


    name = "nat"

    criticality = ComponentCriticality.IMPORTANT



    def __init__(self):

        self.service = NatService()

        self.port_forward_service = PortForwardService()



    def start(self):

        logger.info(
            "NatComponent started."
        )


        db = SessionLocal()

        try:

            result = (
                self.service.enable_default_nat()
            )

            logger.info(
                f"NAT configuration: {result}"
            )

            forwards = (
                self.port_forward_service.sync(db)
            )

            logger.info(
                f"Port-forward sync: {forwards}"
            )

        finally:

            db.close()



    def health_check(self) -> bool:
        try:
            from backend.network.interfaces.services.interface_service import (
                InterfaceService,
            )
            import subprocess

            if not InterfaceService().get_wan_interfaces():
                return True

            result = subprocess.run(
                ["sysctl", "-n", "net.ipv4.ip_forward"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            return result.stdout.strip() == "1"

        except Exception as error:
            logger.warning("NatComponent health_check: %s", error)
            return False

    def stop(self):

        logger.info(
            "NatComponent stopped."
        )
