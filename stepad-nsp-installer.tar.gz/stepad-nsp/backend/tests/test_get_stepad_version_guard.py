"""El instalador no debe degradar una instalación.

Si el CDN de GitHub sirve un VERSION atrasado, get-stepad.sh descargaba
un paquete más viejo que el instalado y, con los cambios de instalador,
abortaba la actualización a mitad de camino (pasó en producción). Ahora
el paquete viejo se rechaza y el bucle reintenta.
"""

import os
import subprocess

from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[2] / "get-stepad.sh"


def _compare(a, b):

    env = dict(os.environ)
    env["STEPAD_VC_A"] = a
    env["STEPAD_VC_B"] = b

    result = subprocess.run(
        ["bash", str(SCRIPT), "--compare-versions"],
        capture_output=True,
        text=True,
        env=env,
        timeout=30,
    )

    assert result.returncode == 0, result.stderr

    return result.stdout.strip()


def test_versiones_iguales():

    assert _compare("v2.5.361", "v2.5.361") == "ge"


def test_paquete_mas_nuevo_es_valido():

    assert _compare("v2.5.361", "v2.5.360") == "ge"


def test_paquete_mas_viejo_se_rechaza():

    assert _compare("v2.5.360", "v2.5.361") == "lt"


def test_compara_numericamente_no_alfabetico():

    # Alfabéticamente "v2.5.6" > "v2.5.10"; numéricamente es al revés.
    assert _compare("v2.5.6", "v2.5.10") == "lt"
    assert _compare("v2.5.10", "v2.5.6") == "ge"


def test_sin_version_instalada_no_bloquea():

    assert _compare("v2.5.1", "") == "ge"


def test_script_tiene_el_flag_de_autotest():

    text = SCRIPT.read_text(encoding="utf-8")

    assert "--compare-versions" in text
    assert "version_ge" in text
    assert "installed_version" in text
