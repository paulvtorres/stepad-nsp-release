from datetime import datetime, timedelta
from backend.shared.datetime_utils import utcnow

from backend.backups.services.restore_verification_service import (
    RestoreVerificationService,
)


def test_missing_state_should_run(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    assert service.should_run() is True

    assert service.status()["success"] is False


def test_recent_success_does_not_run(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    service._save({
        "success": True,
        "last_run_at": utcnow().isoformat(),
    })

    assert service.should_run() is False

    assert service.status()["success"] is True


def test_old_run_should_run_again(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    service._save({
        "success": True,
        "last_run_at": (utcnow() - timedelta(days=40)).isoformat(),
    })

    assert service.should_run() is True


def test_invalid_date_should_run(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    service._save({"success": True, "last_run_at": "no-es-fecha"})

    assert service.should_run() is True
