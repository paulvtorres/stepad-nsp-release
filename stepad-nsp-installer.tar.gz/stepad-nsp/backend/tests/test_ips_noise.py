from backend.ips.services.suricata_alert_ingest import SuricataAlertIngest


def test_stream_anomalies_are_noise():

    assert SuricataAlertIngest.is_noise_signature(
        "SURICATA STREAM Packet with invalid ack"
    ) is True


def test_et_info_is_noise():

    assert SuricataAlertIngest.is_noise_signature(
        "ET INFO Observed ZeroSSL SSL/TLS Certificate"
    ) is True


def test_real_attacks_are_not_noise():

    assert SuricataAlertIngest.is_noise_signature(
        "ET EXPLOIT Possible OpenSSL HeartBleed"
    ) is False

    assert SuricataAlertIngest.is_noise_signature(
        "ET HUNTING Real Malware Activity"
    ) is False


def test_dotted_quad_mz_is_noise():

    assert SuricataAlertIngest.is_noise_signature(
        "ET HUNTING SUSPICIOUS Dotted Quad Host MZ Response"
    ) is True
