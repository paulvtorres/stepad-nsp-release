"""Servicio de presencia con BD real (sqlite) y la red simulada."""

import os

os.environ.setdefault("STEPAD_ENV", "development")

from datetime import datetime, timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401 (registra modelos)
from backend.core.database.base import Base
from backend.network.devices.domain.presence import NeighEntry
from backend.network.devices.models.device_ip_history import DeviceIpHistory
from backend.network.devices.models.device_ip_observation import (
    DeviceIpObservation,
)
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.services.device_presence_service import (
    DevicePresenceService,
)

T0 = datetime(2026, 11, 13, 12, 0, 0)

A = "aa:00:00:00:00:01"
B = "aa:00:00:00:00:02"
C = "aa:00:00:00:00:03"


class World:
    """Estado de la red simulada + reloj."""

    def __init__(self):
        self.now = T0
        self.neigh: list[NeighEntry] = []
        self.leases: dict[str, str] = {}
        self.dns: dict[str, datetime] = {}
        self.probed: list[list[str]] = []
        self.after_probe: list[NeighEntry] | None = None


@pytest.fixture
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    yield session
    session.close()


@pytest.fixture
def world():
    return World()


@pytest.fixture
def alerts(monkeypatch):
    created = []
    import backend.alerts.services.alert_service as module

    monkeypatch.setattr(
        module.AlertService,
        "create",
        lambda self, db, **kw: created.append(kw),
    )
    return created


def make_service(world, probe=True):
    def prober(ips):
        world.probed.append(list(ips))
        if world.after_probe is not None:
            world.neigh = world.after_probe

    return DevicePresenceService(
        neigh_reader=lambda: list(world.neigh),
        lease_reader=lambda: dict(world.leases),
        dns_reader=lambda db, since: dict(world.dns),
        prober=prober,
        lan_ip=lambda ip: ip.startswith("192.168.1."),
        clock=lambda: world.now,
        active_probe=probe,
    )


def add(db, mac, ip, name, last_seen=None):
    device = NetworkDevice(
        mac_address=mac,
        ip_address=ip,
        hostname=name,
        status="OFFLINE",
        device_type="PC",
        last_seen=last_seen,
    )
    # `last_seen` es NOT NULL en la base; para los casos "sin evidencia"
    # usamos un valor viejo, no None.
    if device.last_seen is None:
        device.last_seen = T0 - timedelta(days=1)
    db.add(device)
    db.commit()
    return device


def reach(ip, mac):
    return NeighEntry(ip, mac, "enp3s0", "REACHABLE")


def stale(ip, mac):
    return NeighEntry(ip, mac, "enp3s0", "STALE")


def test_lease_vigente_de_un_equipo_ausente_no_es_presencia(db, world):
    """El bug que reproduje: lease de 24h => ONLINE aunque se fue."""
    laptop = add(db, A, "192.168.1.30", "laptop", last_seen=T0 - timedelta(hours=3))
    world.leases = {A: "192.168.1.30"}

    result = make_service(world).reconcile(db)

    db.refresh(laptop)
    assert laptop.presence_status == "OFFLINE"
    assert laptop.status == "OFFLINE"
    assert laptop.current_ip == ""
    assert laptop.assigned_ip == "192.168.1.30"  # la asignacion si se conserva
    assert result["online"] == 0


def test_dos_entradas_arp_ganan_la_alcanzable_no_la_ultima_linea(db, world):
    pc = add(db, C, "192.168.1.40", "pc")
    world.neigh = [reach("192.168.1.41", C), stale("192.168.1.40", C)]

    make_service(world).reconcile(db)

    db.refresh(pc)
    assert (pc.presence_status, pc.current_ip) == ("ONLINE", "192.168.1.41")
    assert pc.ip_address == "192.168.1.41"  # espejo legado
    # La IP anterior queda en el historial, no se pierde.
    assert db.query(DeviceIpHistory).filter_by(ip_address="192.168.1.40").count() == 1


def test_el_estado_envejece_por_la_hora_de_la_evidencia(db, world):
    pc = add(db, A, "192.168.1.30", "pc")
    service = make_service(world, probe=False)

    world.neigh = [reach("192.168.1.30", A)]
    service.reconcile(db)
    db.refresh(pc)
    assert pc.presence_status == "ONLINE"
    seen = pc.last_seen
    assert seen == T0

    # 10 min despues el kernel solo conserva la entrada como STALE.
    world.now = T0 + timedelta(minutes=10)
    world.neigh = [stale("192.168.1.30", A)]
    service.reconcile(db)
    db.refresh(pc)
    assert pc.presence_status == "PROBABLE"
    assert pc.presence_at == T0  # hora de la evidencia, no de la corrida
    assert pc.last_seen == seen  # una entrada STALE no mueve "ultimo visto"
    assert pc.status == "ONLINE"  # compat: PROBABLE no se da de baja aun

    # 31 min: sin evidencia fresca => OFFLINE, la ultima IP se conserva.
    world.now = T0 + timedelta(minutes=31)
    service.reconcile(db)
    db.refresh(pc)
    assert pc.presence_status == "OFFLINE"
    assert (pc.current_ip, pc.last_ip) == ("", "192.168.1.30")


def test_una_entrada_stale_eterna_no_mantiene_al_equipo_conectado(db, world):
    """El kernel no purga STALE con pocas entradas: no es una señal."""
    pc = add(db, A, "192.168.1.30", "pc", last_seen=T0 - timedelta(days=1))
    service = make_service(world, probe=False)
    world.neigh = [stale("192.168.1.30", A)]

    service.reconcile(db)
    db.refresh(pc)
    assert pc.presence_status == "PROBABLE"  # primera vez que se ve

    world.now = T0 + timedelta(minutes=35)
    service.reconcile(db)
    db.refresh(pc)
    assert pc.presence_status == "OFFLINE"


def test_la_verificacion_activa_confirma_a_un_equipo_silencioso(db, world):
    quiet = add(db, A, "192.168.1.30", "quiet", last_seen=T0 - timedelta(hours=1))
    busy = add(db, B, "192.168.1.31", "busy")
    world.neigh = [reach("192.168.1.31", B)]
    # Tras el ping, el equipo silencioso contesta ARP (aunque bloquee ICMP).
    world.after_probe = [reach("192.168.1.31", B), reach("192.168.1.30", A)]

    make_service(world).reconcile(db)

    db.refresh(quiet)
    db.refresh(busy)
    assert quiet.presence_status == "ONLINE"
    assert quiet.last_seen == T0
    # Solo se sondeo al que no tenia evidencia fresca.
    assert world.probed == [["192.168.1.30"]]


def test_si_no_contesta_la_verificacion_queda_offline(db, world):
    ghost = add(db, A, "192.168.1.30", "ghost", last_seen=T0 - timedelta(hours=2))
    world.after_probe = []

    make_service(world).reconcile(db)

    db.refresh(ghost)
    assert ghost.presence_status == "OFFLINE"


def test_conflicto_ip_asignada_a_uno_y_usada_por_otro(db, world, alerts):
    owner = add(db, A, "192.168.1.30", "dueño-del-lease")
    squatter = add(db, B, "192.168.1.99", "usurpador")
    world.leases = {A: "192.168.1.30"}
    world.neigh = [reach("192.168.1.30", B)]

    result = make_service(world, probe=False).reconcile(db)

    db.refresh(owner)
    db.refresh(squatter)
    assert result["conflicts"] == 1
    assert owner.ip_conflict and squatter.ip_conflict
    assert squatter.current_ip == "192.168.1.30"  # la realidad, sin ocultarla
    assert owner.assigned_ip == "192.168.1.30"  # y lo que DHCP asigno
    assert [a["alert_type"] for a in alerts] == ["DHCP_IP_DUPLICATE_ACTIVE"]
    assert alerts[0]["severity"] == "warning"


def test_una_entrada_stale_no_genera_conflicto_al_reutilizar_una_ip(db, world, alerts):
    """IP reutilizada: el equipo viejo deja un STALE, el nuevo tiene lease."""
    old = add(db, A, "192.168.1.30", "viejo")
    new = add(db, B, "192.168.1.30", "nuevo")
    world.leases = {B: "192.168.1.30"}
    world.neigh = [stale("192.168.1.30", A), reach("192.168.1.30", B)]

    result = make_service(world, probe=False).reconcile(db)

    assert result["conflicts"] == 0
    assert alerts == []


def test_dns_da_presencia_a_un_celular_que_no_responde_arp(db, world):
    phone = add(db, A, "192.168.1.50", "celular", last_seen=T0 - timedelta(hours=2))
    world.leases = {A: "192.168.1.50"}
    world.dns = {"192.168.1.50": T0 - timedelta(minutes=2)}
    world.after_probe = []

    make_service(world).reconcile(db)

    db.refresh(phone)
    assert (phone.presence_status, phone.presence_source) == ("ONLINE", "dns")


def test_dns_ambiguo_no_se_atribuye(db, world):
    """Dos equipos reclaman la IP: la consulta DNS no se le da a ninguno."""
    first = add(db, A, "192.168.1.50", "uno", last_seen=T0 - timedelta(hours=2))
    second = add(db, B, "192.168.1.99", "dos", last_seen=T0 - timedelta(hours=2))
    world.leases = {A: "192.168.1.50"}
    world.neigh = [stale("192.168.1.50", B)]
    world.dns = {"192.168.1.50": T0}
    world.after_probe = list(world.neigh)

    make_service(world).reconcile(db)

    db.refresh(first)
    assert first.presence_source != "dns"


def test_equipo_sin_evidencia_no_inventa_presencia(db, world):
    new = add(db, A, "192.168.1.30", "nuevo")
    world.after_probe = []

    make_service(world).reconcile(db)

    db.refresh(new)
    assert new.presence_status == "OFFLINE"
    assert new.current_ip == ""


def test_observaciones_viejas_se_purgan(db, world):
    add(db, A, "192.168.1.30", "pc")
    db.add(
        DeviceIpObservation(
            mac_address=A,
            ip_address="192.168.1.30",
            source="arp_reachable",
            observed_at=T0 - timedelta(days=9),
        )
    )
    db.commit()

    make_service(world, probe=False).reconcile(db)

    assert db.query(DeviceIpObservation).count() == 0


def test_la_reconciliacion_es_idempotente(db, world):
    pc = add(db, A, "192.168.1.30", "pc")
    world.neigh = [reach("192.168.1.30", A)]
    service = make_service(world, probe=False)

    service.reconcile(db)
    service.reconcile(db)

    assert db.query(DeviceIpObservation).count() == 1
    assert db.query(DeviceIpHistory).count() == 0
