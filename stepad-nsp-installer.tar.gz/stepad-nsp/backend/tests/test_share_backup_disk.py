from types import SimpleNamespace

from backend.shares.services import share_backup_disk as disk


def test_human_bytes():

    assert disk.human_bytes(0) == "0 B"

    assert disk.human_bytes(512) == "512 B"

    assert disk.human_bytes(1024) == "1.0 KiB"

    assert disk.human_bytes(1536) == "1.5 KiB"

    assert disk.human_bytes(1024**3) == "1.0 GiB"

    assert disk.human_bytes(None) == "0 B"

    assert disk.human_bytes("x") == "0 B"


def test_disk_info():

    usage = SimpleNamespace(total=1000, used=250, free=750)

    info = disk.disk_info("/mnt/x", usage)

    assert info["path"] == "/mnt/x"

    assert info["free_pct"] == 75.0

    assert info["used_human"] == "250 B"

    assert info["total_human"] == "1000 B"


def test_disk_info_zero_total():

    usage = SimpleNamespace(total=0, used=0, free=0)

    assert disk.disk_info("/mnt/x", usage)["free_pct"] == 100.0
