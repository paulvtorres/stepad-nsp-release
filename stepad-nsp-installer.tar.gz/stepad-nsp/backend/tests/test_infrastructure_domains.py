"""El feed no debe bloquear endpoints genéricos de infraestructura cloud."""

from backend.content.domain.infrastructure_domains import (
    is_infrastructure_domain,
)


def test_endpoints_genericos_de_aws_se_excluyen():

    for domain in (
        "s3.amazonaws.com",
        "s3.us-east-2.amazonaws.com",
        "s3.us-east-1.amazonaws.com",
        "s3-r-w.us-east-2.amazonaws.com",
        "s3-w.us-east-1.amazonaws.com",
        "cognito-idp.us-east-1.amazonaws.com",
        "execute-api.us-east-1.amazonaws.com",
        "checkip.amazonaws.com",
        "sts.amazonaws.com",
    ):

        assert is_infrastructure_domain(domain), domain


def test_buckets_y_recursos_concretos_se_siguen_bloqueando():

    for domain in (
        "hb-pricefloor.s3.us-east-2.amazonaws.com",
        "jsbin-user-assets.s3.amazonaws.com",
        "route66construction.s3.us-east-2.amazonaws.com",
        "o84pey3p61.execute-api.us-east-1.amazonaws.com",
        "public-ethos505-prod-va6-94e30a58c25add40.elb.us-east-1.amazonaws.com",
        "d30sec8k5ond2x.cloudfront.net",
        "placetopay-static-prod-bucket.s3.us-east-2.amazonaws.com",
    ):

        assert not is_infrastructure_domain(domain), domain


def test_otros_servicios_genericos():

    assert is_infrastructure_domain("blob.core.windows.net")
    assert is_infrastructure_domain("storage.googleapis.com")
    assert is_infrastructure_domain("cloudfront.net")


def test_dominios_normales_no_se_tocan():

    for domain in ("google.com", "web.whatsapp.com", "example.s3.evil.com", ""):

        assert not is_infrastructure_domain(domain), domain
