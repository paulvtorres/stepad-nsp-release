"""Resolución de la config en scripts/configure_suricata.py.

Este script calcula HOME_NET para Suricata leyendo la config del NSP.
Leía solo la copia del repo, que ya no existe (la config vive en
/etc/stepad/config.yaml): el instalador abortaba con FileNotFoundError.
"""

import importlib.util

from pathlib import Path


SCRIPT = (
    Path(__file__).resolve().parents[2]
    / "scripts"
    / "configure_suricata.py"
)

spec = importlib.util.spec_from_file_location("configure_suricata", SCRIPT)
module = importlib.util.module_from_spec(spec)

spec.loader.exec_module(module)


CONFIG = """dhcp:
  network: 10.5.0.0
  netmask: 255.255.255.0
"""


def test_usa_la_config_del_sistema(tmp_path, monkeypatch):

    system = tmp_path / "config.yaml"
    system.write_text(CONFIG, encoding="utf-8")

    monkeypatch.setattr(module, "SYSTEM_CONFIG", system)
    monkeypatch.setattr(module, "APP_CONFIG", tmp_path / "no-existe.yaml")

    assert module._lan_cidr() == "10.5.0.0/24"


def test_cae_a_la_config_del_repo(tmp_path, monkeypatch):

    legacy = tmp_path / "config.yaml"
    legacy.write_text(CONFIG, encoding="utf-8")

    monkeypatch.setattr(module, "SYSTEM_CONFIG", tmp_path / "no-existe.yaml")
    monkeypatch.setattr(module, "APP_CONFIG", legacy)

    assert module._lan_cidr() == "10.5.0.0/24"


def test_sin_config_no_aborta(tmp_path, monkeypatch):

    monkeypatch.setattr(module, "SYSTEM_CONFIG", tmp_path / "no-existe.yaml")
    monkeypatch.setattr(module, "APP_CONFIG", tmp_path / "tampoco.yaml")

    assert module._lan_cidr() == module.DEFAULT_LAN_CIDR
