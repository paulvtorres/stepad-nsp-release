from backend.shares.services.share_backup_service import ShareBackupService


def test_error_vault_aggregates_backup_issues():
    service = ShareBackupService()
    service._all_jobs = lambda: [
        {
            "id": 1,
            "name": "Produccion",
            "source_path": "/mnt/stepad-network/M/PRODUCCION_TQB",
            "last_attempt_at": "2026-11-11T10:00:00-05:00",
            "last_unreadable": {
                "count": 12,
                "samples": ["/mnt/a — permission denied"],
                "at": "2026-11-11T10:00:00-05:00",
            },
        },
        {
            "id": 2,
            "name": "Origen caido",
            "source_path": "/mnt/otro",
            "source_exists": False,
            "last_attempt_at": "2026-11-11T09:00:00-05:00",
        },
        {"id": 3, "name": "Sano", "source_path": "/mnt/sano"},
    ]

    data = service.error_vault()

    assert data["total"] == 3
    assert data["ok"] == 1
    assert data["warnings"] == 1
    assert data["errors"] == 1
    assert {item["type"] for item in data["issues"]} == {"unreadable", "source_missing"}
    unreadable = next(item for item in data["issues"] if item["type"] == "unreadable")
    assert unreadable["unreadable_count"] == 12
    assert "permission denied" in unreadable["unreadable_samples"][0]


def test_error_vault_removes_resolved_unreadable():
    service = ShareBackupService()
    job = {
        "id": 1,
        "name": "Produccion",
        "source_path": "/mnt/stepad-network/M/PRODUCCION_TQB",
        "last_attempt_at": "2026-11-11T10:00:00-05:00",
        "last_unreadable": {
            "count": 2,
            "samples": ["/mnt/a — permission denied"],
            "at": "2026-11-11T10:00:00-05:00",
        },
    }
    service._all_jobs = lambda: [job]
    assert service.error_vault()["warnings"] == 1

    job.pop("last_unreadable")
    clean = service.error_vault()
    assert clean["warnings"] == 0
    assert clean["ok"] == 1
    assert clean["issues"] == []
