import gzip
import io
import tarfile
from datetime import datetime, timedelta

from backend.backups.services import rollback_integrity_service as rb


def make_point(directory, name, valid=True):
    stem = directory / name
    tar_path = directory / f"{name}.app.tar.gz"
    with tarfile.open(tar_path, "w:gz") as archive:
        data = b"contenido"
        info = tarfile.TarInfo("manifest.json")
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
    (directory / f"{name}.version").write_text("v1.2.3\n")
    (directory / f"{name}.meta").write_text("meta\n")
    db = directory / f"{name}.db.sql.gz"
    if valid:
        with gzip.open(db, "wb") as handle:
            handle.write(b"-- dump\n")
    else:
        db.write_bytes(b"not gzip")
    return tar_path


def test_valid_point(tmp_path):
    path = make_point(tmp_path, "v1.2.3-20260101-000000")
    result = rb.check_point(path)

    assert result["ok"] is True
    assert result["version"] == "v1.2.3"
    assert result["db_size"] > 0


def test_corrupt_db(tmp_path):
    path = make_point(tmp_path, "v1.2.3-20260101-000000", valid=False)
    result = rb.check_point(path)

    assert result["ok"] is False
    assert "gzip" in result["error"]


def test_missing_db(tmp_path):
    path = make_point(tmp_path, "v1.2.3-20260101-000000")
    (tmp_path / "v1.2.3-20260101-000000.db.sql.gz").unlink()
    result = rb.check_point(path)

    assert result["ok"] is False
    assert "falta" in result["error"]


def test_service_state(tmp_path):
    make_point(tmp_path, "v1.2.3-20260101-000000")
    state = tmp_path / "state.json"
    service = rb.RollbackIntegrityService(str(state), tmp_path)

    result = service.run(alert=False)

    assert result["ok"] is True
    assert result["count"] == 1
    assert service.status()["count"] == 1
    assert service.should_run() is False

    service._save({"last_run_at": (datetime.utcnow() - timedelta(days=9)).isoformat()})
    assert service.should_run() is True
