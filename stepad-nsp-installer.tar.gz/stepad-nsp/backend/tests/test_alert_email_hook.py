from types import SimpleNamespace

import backend.alerts.services.alert_service as alert_module
from backend.alerts.services.alert_service import AlertService


class FakeRepo:

    def __init__(self):

        self.created = []

    def is_ignored(self, db, alert_type, title):

        return False

    def find_recent_unread(self, db, alert_type, title):

        return None

    def create(self, db, alert):

        alert.id = 1

        self.created.append(alert)

        return alert


class FakeEmail:

    sent = []

    def send(self, db, title, message):

        FakeEmail.sent.append((title, message))

        return True


def _service(monkeypatch):

    service = AlertService()

    service.repository = FakeRepo()

    monkeypatch.setattr(
        "backend.notifications.services.critical_alert_email_service.CriticalAlertEmailService",
        FakeEmail,
    )

    return service


def test_critical_alert_sends_email(monkeypatch):

    FakeEmail.sent = []

    service = _service(monkeypatch)

    service.create(None, "COMPONENT_DOWN", "critical", "NSP caido", "detalle")

    assert len(FakeEmail.sent) == 1


def test_warning_alert_does_not_send_email(monkeypatch):

    FakeEmail.sent = []

    service = _service(monkeypatch)

    service.create(None, "USER_LOGIN_FAILED", "warning", "Login", "detalle")

    assert FakeEmail.sent == []


def test_repeated_critical_is_throttled(monkeypatch):

    FakeEmail.sent = []

    service = _service(monkeypatch)

    service.create(None, "RESOURCE_CPU", "critical", "CPU al 95%", "x")

    service.create(None, "RESOURCE_CPU", "critical", "CPU al 95%", "x")

    assert len(FakeEmail.sent) == 1
