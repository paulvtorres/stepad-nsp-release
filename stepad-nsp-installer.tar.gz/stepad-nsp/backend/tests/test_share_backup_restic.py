from backend.shares.services import share_backup_restic as restic


def test_command_prioridad_idle():

    cmd = restic.command("/repo", ["snapshots", "--json"])

    assert cmd[:6] == ["nice", "-n", "19", "ionice", "-c", "3"]

    assert cmd[6:8] == ["restic", "-r"]

    assert cmd[-2:] == ["snapshots", "--json"]


def test_env_pone_password_y_locale():

    result = restic.env("secreta")

    assert result["RESTIC_PASSWORD"] == "secreta"

    assert result["LC_ALL"] == "C"


def test_progress_fraccion_a_porcentaje():

    data = restic.rich_progress({"percent_done": 0.5})

    assert data["percent"] == 50.0


def test_progress_porcentaje_se_acota():

    assert restic.rich_progress({"percent_done": 1.0})["percent"] == 100.0

    assert restic.rich_progress({"percent_done": 150})["percent"] == 100.0

    assert restic.rich_progress({"percent_done": -1})["percent"] == 0.0


def test_eta_solo_si_confiable():

    # 2%: no se publica ETA (poco progreso).
    small = restic.rich_progress({
        "percent_done": 0.02,
        "seconds_elapsed": 60,
    })

    assert "eta_seconds" not in small

    # 50% y >= 20 s: se publica.
    ok = restic.rich_progress({
        "percent_done": 0.5,
        "seconds_elapsed": 100,
    })

    assert ok["eta_seconds"] == 100


def test_progress_por_archivos_si_no_hay_percent():

    data = restic.rich_progress({
        "files_done": 25,
        "total_files_processed": 100,
    })

    assert data["percent"] == 25.0
