from starlette.requests import Request
from starlette.responses import Response

from backend.api.middleware.security_headers import (
    CSP,
    PERMISSIONS_POLICY,
    apply_security_headers,
)


def _request(scheme: str = "http") -> Request:
    return Request(
        {
            "type": "http",
            "method": "GET",
            "path": "/",
            "scheme": scheme,
            "headers": [],
            "query_string": b"",
            "server": ("testserver", 80),
            "client": ("testclient", 1),
            "root_path": "",
        }
    )


def test_security_headers_present():
    response = Response()
    apply_security_headers(_request(), response)

    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["x-frame-options"] == "DENY"
    assert response.headers["referrer-policy"] == "no-referrer"
    assert response.headers["permissions-policy"] == PERMISSIONS_POLICY
    assert response.headers["content-security-policy"] == CSP
    assert "frame-ancestors 'none'" in CSP
    assert "script-src 'self'" in CSP


def test_hsts_only_over_https():
    http = Response()
    https = Response()
    apply_security_headers(_request("http"), http)
    apply_security_headers(_request("https"), https)

    assert "strict-transport-security" not in http.headers
    assert (
        https.headers["strict-transport-security"]
        == "max-age=31536000"
    )


def test_headers_do_not_override_existing_values():
    response = Response(headers={"Referrer-Policy": "same-origin"})
    apply_security_headers(_request(), response)

    assert response.headers["referrer-policy"] == "same-origin"
