import os
import stat

from backend.shares.services import share_backup_mount as mount


def test_write_credentials_0600(tmp_path):

    path = mount.write_credentials("u", "p", directory=tmp_path / "cred")

    assert path is not None

    assert "username=u" in path.read_text("utf-8")

    assert "password=p" in path.read_text("utf-8")

    mode = stat.S_IMODE(os.stat(path).st_mode)

    assert mode == 0o600

    path.unlink()


def test_write_credentials_guest_none(tmp_path):

    assert mount.write_credentials("", "p", directory=tmp_path) is None


def test_options_use_credentials_file(tmp_path):

    path = mount.write_credentials("u", "p", directory=tmp_path)

    options = mount.cifs_options("u", "p", credentials=path)

    assert options.startswith(f"credentials={path},")

    assert "password=p" not in options
