from backend.shares.services import share_backup_mount as mount


def test_is_network_source():

    assert mount.is_network_source("//server/share") is True

    assert mount.is_network_source("\\\\server\\share") is True

    assert mount.is_network_source("/mnt/stepad-network/M/docs") is True

    assert mount.is_network_source("/mnt/stepad-share/sdb1") is False


def test_cifs_options_guest_and_user():

    assert mount.cifs_options("", "").startswith("guest,")

    options = mount.cifs_options("u", "p")

    assert options.startswith("username=u,password=p,")

    assert ",rw," not in options


def test_cifs_options_write():

    options = mount.cifs_options("u", "p", read_write=True)

    assert ",rw," in options
