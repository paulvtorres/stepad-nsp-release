from datetime import datetime, timedelta

from backend.backups.services import backup_health as health

NOW = datetime(2026, 11, 8, 20, 0)


def status(last, enabled=True, schedule=True):
    return {
        "enabled": enabled,
        "schedule_enabled": schedule,
        "last_backup": last.isoformat() if last else None,
    }


def test_disabled_has_no_issues():
    old = NOW - timedelta(days=10)
    assert health.evaluate(status(old, enabled=False), NOW) == []
    assert health.evaluate(status(old, schedule=False), NOW) == []


def test_recent_backup_is_ok():
    assert health.evaluate(status(NOW - timedelta(hours=5)), NOW) == []


def test_overdue_backup():
    issues = health.evaluate(status(NOW - timedelta(hours=72)), NOW)

    assert len(issues) == 1
    assert issues[0]["type"] == "SYSTEM_BACKUP_OVERDUE"
    assert "72 h" in issues[0]["message"]


def test_missing_backup():
    issues = health.evaluate(status(None), NOW)

    assert issues[0]["type"] == "SYSTEM_BACKUP_OVERDUE"


def test_low_disk():
    issues = health.evaluate(status(NOW - timedelta(hours=2)), NOW, free_pct=4.5)

    assert issues[0]["type"] == "SYSTEM_BACKUP_DISK_LOW"
    assert "4.5%" in issues[0]["message"]


def test_timezone_is_normalized():
    aware = (NOW - timedelta(hours=3)).replace(tzinfo=None).isoformat() + "+00:00"
    assert health.evaluate(
        {"enabled": True, "schedule_enabled": True, "last_backup": aware},
        NOW,
    ) == []
