"""Sincronización de IP del equipo y migración de lease infinito.

Dos problemas de produccion:
1. El reporte mostraba equipos sin IP: `sync_device_ips` borraba
   `ip_address` cuando el equipo estaba apagado y ademas dejaba que ARP
   pisara el lease.
2. `lease_time: infinite` impedia que un equipo soltara una IP ajena y
   que tomara su reserva.
"""

import sys

from backend.dhcp.services.dhcp_service import (
    DhcpService,
    next_device_ip,
)


module = sys.modules["backend.dhcp.services.dhcp_service"]


class FakeDevice:

    def __init__(self, ip_address="", permanent_ip=""):
        self.ip_address = ip_address
        self.permanent_ip = permanent_ip


class FakeConfigService:

    def __init__(self, lease_time):
        self.config = {"lease_time": lease_time, "network": "192.168.1.0"}
        self.updated = None

    def get_dhcp_config(self):
        return dict(self.config)

    def update_section(self, section, values):
        self.updated = (section, dict(values))


def test_el_lease_manda_sobre_arp():

    device = FakeDevice(ip_address="192.168.1.83")

    assert next_device_ip(device, "192.168.1.154") == "192.168.1.154"


def test_equipo_apagado_conserva_su_ultima_ip():

    device = FakeDevice(ip_address="192.168.1.50")

    assert next_device_ip(device, None) is None


def test_equipo_sin_ip_usa_su_reserva():

    device = FakeDevice(ip_address="", permanent_ip="192.168.1.26")

    assert next_device_ip(device, None) == "192.168.1.26"


def test_sin_ip_ni_reserva_no_cambia():

    assert next_device_ip(FakeDevice(), None) is None


def test_migra_lease_infinito_a_24h():

    service = DhcpService.__new__(DhcpService)
    service.config_service = FakeConfigService("infinite")

    service.migrate_infinite_lease()

    section, values = service.config_service.updated

    assert section == "dhcp"
    assert values["lease_time"] == "24h"
    assert values["network"] == "192.168.1.0"


def test_no_toca_un_lease_finito():

    service = DhcpService.__new__(DhcpService)
    service.config_service = FakeConfigService("12h")

    service.migrate_infinite_lease()

    assert service.config_service.updated is None
