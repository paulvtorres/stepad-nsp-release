"""Panel de uso de IPs: cuenta leases reales, no `ip_address` de la base.

Antes el "ocupadas" se calculaba sumando `ip_address` de los equipos
(que se conserva cuando se apagan) y el "libre" salía muy por debajo de
la realidad. Ahora el cálculo sale de la capa de dominio sobre los
leases de dnsmasq.
"""

import os

from types import SimpleNamespace

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from backend.dhcp.domain.leases import Lease

from backend.dhcp.services.dhcp_pool_stats_service import (
    DhcpPoolStatsService,
)


DHCP = {
    "gateway": "192.168.1.1",
    "pool_start": "192.168.1.20",
    "pool_end": "192.168.1.29",
    "group_ip_start": "192.168.1.10",
    "group_ip_end": "192.168.1.19",
    "lease_time": "24h",
    "excluded_ips": ["192.168.1.10-192.168.1.19"],
}

# (mac, permanent_ip)
DEVICE_ROWS = [
    ("aa:bb:cc:dd:ee:01", None),
    ("aa:bb:cc:dd:ee:02", "192.168.1.25"),
]

GROUP_ROWS = [("192.168.1.10",)]


class FakeQuery:

    def __init__(self, rows):
        self.rows = rows

    def filter(self, *args, **kwargs):
        return self

    def all(self):
        return self.rows


class FakeDb:

    def query(self, *models):
        if any("dns_alias_ip" in str(model) for model in models):
            return FakeQuery(GROUP_ROWS)
        return FakeQuery(DEVICE_ROWS)

    def close(self):
        return None


def _service(monkeypatch):

    service = DhcpPoolStatsService()
    service.config_service = SimpleNamespace(
        get_dhcp_config=lambda: DHCP
    )

    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_pool_stats_service.SessionLocal",
        lambda: FakeDb(),
    )
    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_pool_stats_service.read_leases",
        lambda path: [
            Lease(0, "aa:bb:cc:dd:ee:01", "192.168.1.21"),
            Lease(0, "aa:bb:cc:dd:ee:02", "192.168.1.25"),
        ],
    )
    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_pool_stats_service.arp_table_now",
        lambda: {"192.168.1.21": "aa:bb:cc:dd:ee:01"},
    )
    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_pool_stats_service.group_ip_capacity",
        lambda dhcp: 10,
    )
    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_pool_stats_service.free_group_ip_count",
        lambda used, dhcp: 9,
    )

    return service


def test_pool_stats_cuenta_leases_y_reservas(monkeypatch):

    stats = _service(monkeypatch).get_stats()

    devices = stats["devices"]

    assert devices["total"] == 10

    # 10 direcciones - 1 reservada = 9 dinamicas.
    assert devices["dynamic"] == 9

    assert devices["reserved"] == 1

    # .25 es una reserva (no consume pool dinamico): solo .21 cuenta.
    assert devices["leased"] == 1

    assert devices["reserved_in_use"] == 1

    assert devices["static"] == 0

    assert devices["online"] == 1

    # .25 tiene lease pero su equipo no esta en ARP (ocupa IP).
    assert devices["offline"] == 1

    # 9 dinamicas - 1 con lease dinamico (.21) = 8.
    assert devices["free"] == 8

    assert (
        devices["online"] + devices["offline"] + devices["free"]
        == devices["total"]
    )


def test_overall_suma_grupos(monkeypatch):

    stats = _service(monkeypatch).get_stats()

    assert stats["groups"] == {"total": 10, "used": 1, "free": 9}

    assert stats["overall"]["total"] == 20

    assert stats["overall"]["free"] == 17

    assert stats["dnsmasq_leases"] == 2


def test_presencia_real_en_la_red(monkeypatch):

    stats = _service(monkeypatch).get_stats()

    assert stats["network"]["present"] == 1

    assert stats["network"]["in_pool"] == 1

    assert stats["network"]["outside_pool"] == 0
