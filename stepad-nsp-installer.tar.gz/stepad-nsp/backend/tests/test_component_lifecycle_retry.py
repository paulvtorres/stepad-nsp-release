from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.core.lifecycle.component_lifecycle_manager import (
    ComponentLifecycleManager,
)


class FlakyComponent(BaseComponent):

    name = "flaky"
    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):
        self.calls = 0

    def start(self):
        self.calls += 1
        if self.calls < 2:
            raise RuntimeError("transitorio")


def test_componente_importante_reintenta_al_arrancar():
    manager = ComponentLifecycleManager()
    component = FlakyComponent()
    manager.register(component)

    manager.start_all()

    assert component.calls == 2
    assert manager._failures == []


class DownComponent(BaseComponent):

    name = "down"
    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):
        self.calls = 0

    def start(self):
        self.calls += 1

    def health_check(self):
        return False


def test_supervisor_reintenta_componente_caido():
    from backend.shared.runtime import runtime

    manager = ComponentLifecycleManager()
    component = DownComponent()
    manager.register(component)
    runtime.set(component.name, "running")

    manager._supervisor_cycle()

    assert component.calls == 1
