from backend.shares.services import share_backup_restic as restic


SAMPLE = (
    '{"message_type":"error","error":{"message":"failed to save '
    '/mnt/stepad-network/M/a.xlsx: read: connection reset"},"during":"archival",'
    '"item":"/mnt/stepad-network/M/a.xlsx"}'
)


def test_parses_json_error():
    count, samples = restic.parse_unreadable(SAMPLE)

    assert count == 1
    assert samples[0].startswith("/mnt/stepad-network/M/a.xlsx")


def test_parses_plain_error_and_dedupes():
    text = "\n".join(
        [
            "error: open /data/b.pdf: permission denied",
            "error: open /data/b.pdf: permission denied",
            "unrelated line",
        ]
    )

    count, samples = restic.parse_unreadable(text)

    assert count == 1
    assert "permission denied" in samples[0]


def test_counts_all_but_limits_samples():
    text = "\n".join(
        f'{{"message_type":"error","error":{{"message":"failed to save /f{i}"}},"item":"/f{i}"}}'
        for i in range(10)
    )

    count, samples = restic.parse_unreadable(text, limit=3)

    assert count == 10
    assert len(samples) == 3


def test_empty_and_detail():
    assert restic.parse_unreadable("") == (0, [])
    assert restic.unreadable_detail(0, []) == ""
    detail = restic.unreadable_detail(2, ["/a", "/b"])
    assert "2 archivo" in detail
    assert "/a" in detail
