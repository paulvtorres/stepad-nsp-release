import ipaddress

import pytest

from backend.assessment.services import findings, scope
from backend.shared.errors import ValidationError


def test_private_scope_and_host_cap():
    net = scope.validate_scope("192.168.1.0/24", True)

    assert net == ipaddress.ip_network("192.168.1.0/24")
    assert len(scope.hosts(net)) == 254
    assert scope.hosts(ipaddress.ip_network("192.168.1.5/32")) == ["192.168.1.5"]


def test_rejects_public_and_huge_and_unauthorized():
    with pytest.raises(ValidationError):
        scope.validate_scope("8.8.8.0/24", True)
    with pytest.raises(ValidationError):
        scope.validate_scope("192.168.0.0/8", True)
    with pytest.raises(ValidationError):
        scope.validate_scope("192.168.1.0/24", False)
    with pytest.raises(ValidationError):
        scope.validate_scope("nope", True)


def test_port_rules_and_score():
    telnet = findings.port_finding(23)
    http = findings.port_finding(80)

    assert telnet["severity"] == "critical"
    assert http["severity"] == "medium"
    assert findings.port_finding(22) is None
    assert findings.score([telnet, http]) == 68
    assert findings.worst([telnet, http]) == "critical"


def test_tls_findings():
    items = findings.tls_finding(expired=True, self_signed=True)

    assert {item["type"] for item in items} == {"TLS_EXPIRED", "TLS_SELF_SIGNED"}
    assert findings.tls_finding(False, False) == []


def test_system_backup_health_helper():
    from datetime import datetime, timedelta

    from backend.assessment.services.self_assessment_service import (
        system_backup_service_healthy,
    )

    now = datetime.utcnow()
    assert system_backup_service_healthy(
        {"last_backup": (now - timedelta(hours=3)).isoformat()}
    ) is True
    assert system_backup_service_healthy(
        {"last_backup": (now - timedelta(days=5)).isoformat()}
    ) is False
    assert system_backup_service_healthy({}) is False
