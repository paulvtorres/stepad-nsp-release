"""Aviso por correo del pool: destinatarios propios e independientes."""

import sys

from backend.dhcp.services.dhcp_pool_email_service import (
    DhcpPoolEmailService,
    parse_recipients,
)


module = sys.modules["backend.dhcp.services.dhcp_pool_email_service"]


class FakeConfig:
    def __init__(self, config):
        self._config = config

    def get_dhcp_config(self):
        return dict(self._config)


def test_parse_recipients_acepta_varios_formatos():

    assert parse_recipients("a@x.com, b@y.com") == ["a@x.com", "b@y.com"]

    assert parse_recipients("a@x.com;b@y.com c@z.com") == [
        "a@x.com",
        "b@y.com",
        "c@z.com",
    ]

    assert parse_recipients(["a@x.com", "a@x.com", "sin-arroba"]) == ["a@x.com"]

    assert parse_recipients("") == []


def test_sin_habilitar_no_hay_destinatarios():

    service = DhcpPoolEmailService(
        FakeConfig(
            {
                "pool_low_alert_enabled": False,
                "pool_low_alert_emails": "a@x.com",
            }
        )
    )

    assert service.recipients() == []


def test_destinatarios_independientes_de_alertas():

    service = DhcpPoolEmailService(
        FakeConfig(
            {
                "pool_low_alert_enabled": True,
                "pool_low_alert_emails": "sistemas@empresa.com",
            }
        )
    )

    assert service.recipients() == ["sistemas@empresa.com"]


def test_notify_sin_destinatarios_no_envia():

    sent = []

    service = DhcpPoolEmailService(
        FakeConfig({"pool_low_alert_enabled": True, "pool_low_alert_emails": ""})
    )

    service._send = lambda *args: sent.append(args)

    assert service.notify("low", 3, 5) is False

    assert sent == []


def test_notify_envia_a_los_configurados():

    sent = []

    service = DhcpPoolEmailService(
        FakeConfig(
            {
                "pool_low_alert_enabled": True,
                "pool_low_alert_emails": "sistemas@empresa.com, jefe@empresa.com",
            }
        )
    )

    service._send = lambda recipients, title, body: (
        sent.append((recipients, title, body)) or True
    )

    assert service.notify("low", 3, 5) is True

    recipients, title, body = sent[0]

    assert recipients == ["sistemas@empresa.com", "jefe@empresa.com"]

    assert "casi agotado" in title

    assert "3" in body and "5" in body


def test_notify_recuperado():

    sent = []

    service = DhcpPoolEmailService(
        FakeConfig(
            {"pool_low_alert_enabled": True, "pool_low_alert_emails": "a@x.com"}
        )
    )

    service._send = lambda recipients, title, body: (
        sent.append((recipients, title, body)) or True
    )

    assert service.notify("recovered", 40, 5) is True

    assert "nuevamente" in sent[0][1]
