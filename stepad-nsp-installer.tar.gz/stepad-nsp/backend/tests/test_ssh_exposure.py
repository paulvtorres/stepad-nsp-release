from backend.monitoring.components.monitoring_component import (
    MonitoringComponent,
)


def test_all_interfaces_is_exposed():

    assert MonitoringComponent.ssh_exposure(
        {"192.168.100.11"}, ["0.0.0.0", "192.168.1.1"]
    ) == ["0.0.0.0"]


def test_wan_address_is_exposed():

    assert MonitoringComponent.ssh_exposure(
        {"192.168.100.11"}, ["192.168.1.1", "192.168.100.11"]
    ) == ["192.168.100.11"]


def test_lan_and_tailscale_are_fine():

    assert MonitoringComponent.ssh_exposure(
        {"192.168.100.11"},
        ["192.168.1.1", "10.200.0.1", "100.97.46.90", "127.0.0.1"],
    ) == []


def test_ipv6_all_is_exposed():

    assert MonitoringComponent.ssh_exposure({}, ["::"]) == ["::"]
