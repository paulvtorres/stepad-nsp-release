from datetime import datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.network.devices.models.ip_assignment import IpAssignment
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.services.ipam_service import IpamService

T0 = datetime(2026, 11, 13, 12, 0, 0)
A = "aa:00:00:00:00:01"
B = "aa:00:00:00:00:02"


def db_session():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def add(db, mac, permanent_ip=None):
    device = NetworkDevice(
        mac_address=mac,
        ip_address="",
        permanent_ip=permanent_ip,
        status="OFFLINE",
        device_type="PC",
        last_seen=T0 - timedelta(days=1),
    )
    db.add(device)
    db.commit()
    return device


def service(monkeypatch, leases):
    svc = IpamService()
    monkeypatch.setattr(svc, "_leases", lambda: leases)
    monkeypatch.setattr(svc, "_alert_conflict", lambda *args: None)
    return svc


def test_reserva_crea_asignacion_activa(monkeypatch):
    db = db_session()
    add(db, A, "192.168.1.30")
    svc = service(monkeypatch, {})

    svc.reconcile(db)

    row = db.query(IpAssignment).one()
    assert (row.ip_address, row.mac_address, row.kind) == (
        "192.168.1.30", A, "reservation"
    )
    assert row.released_at is None


def test_lease_crea_asignacion_temporal(monkeypatch):
    db = db_session()
    add(db, A)
    svc = service(monkeypatch, {A: {"ip": "192.168.1.31", "expires_at": T0}})

    svc.reconcile(db)

    row = db.query(IpAssignment).one()
    assert (row.ip_address, row.kind, row.expires_at) == (
        "192.168.1.31", "lease", T0
    )


def test_lease_de_otra_mac_no_pisa_la_reserva(monkeypatch):
    db = db_session()
    add(db, A, "192.168.1.30")
    add(db, B)
    svc = service(monkeypatch, {B: {"ip": "192.168.1.30", "expires_at": T0}})

    result = svc.reconcile(db)

    active = db.query(IpAssignment).filter_by(released_at=None).one()
    assert (active.ip_address, active.mac_address, active.kind) == (
        "192.168.1.30", A, "reservation"
    )
    assert result["conflicts"] == 1


def test_lease_vencido_libera_la_asignacion(monkeypatch):
    db = db_session()
    add(db, A)
    svc = service(monkeypatch, {A: {"ip": "192.168.1.31", "expires_at": T0}})

    svc.reconcile(db)
    monkeypatch.setattr(svc, "_leases", lambda: {})

    svc.reconcile(db)

    row = db.query(IpAssignment).one()
    assert row.released_at is not None
    assert row.status == "released"
