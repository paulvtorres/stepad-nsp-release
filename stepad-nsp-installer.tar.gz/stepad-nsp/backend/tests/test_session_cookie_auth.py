"""Sesión por cookie HttpOnly (antes: JWT en localStorage).

El token ya no se expone a JavaScript: el login lo deja en una cookie
HttpOnly y la API lo acepta desde ahí. Se mantiene la cabecera
Authorization como compatibilidad.
"""

import pytest

from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials
from starlette.requests import Request
from starlette.responses import Response

from backend.auth.security import session_cookie
from backend.auth.security import jwt_auth


def make_request(
    method="GET",
    headers=None,
    scheme="https",
    path="/api/v1/auth/me"
):

    scope = {
        "type": "http",
        "method": method,
        "path": path,
        "scheme": scheme,
        "query_string": b"",
        "headers": [
            (key.lower().encode("latin-1"), value.encode("latin-1"))
            for key, value in (headers or {}).items()
        ],
    }

    return Request(scope)


def bearer(value="cabecera-token"):

    return HTTPAuthorizationCredentials(
        scheme="Bearer",
        credentials=value,
    )


def test_la_cookie_es_httponly_secure_y_acotada_a_la_api():

    response = Response()

    session_cookie.set_session_cookie(
        response,
        make_request(scheme="https"),
        "token-123",
        3600,
    )

    header = response.headers["set-cookie"]

    assert "stepad_session=token-123" in header
    assert "HttpOnly" in header
    assert "Path=/api" in header
    assert "SameSite=lax" in header
    assert "Secure" in header


def test_sin_https_la_cookie_no_lleva_secure():

    response = Response()

    session_cookie.set_session_cookie(
        response,
        make_request(scheme="http"),
        "token-123",
        3600,
    )

    assert "Secure" not in response.headers["set-cookie"]


def test_logout_borra_la_cookie():

    response = Response()

    session_cookie.clear_session_cookie(response)

    header = response.headers["set-cookie"]

    assert "stepad_session=" in header
    assert "Max-Age=0" in header
    assert "Path=/api" in header


def test_prefiere_la_cookie_sobre_la_cabecera():

    request = make_request(
        headers={"cookie": "stepad_session=desde-cookie"}
    )

    token, source = jwt_auth._session_token(request, bearer())

    assert token == "desde-cookie"
    assert source == "cookie"


def test_cae_a_la_cabecera_sin_cookie():

    token, source = jwt_auth._session_token(make_request(), bearer())

    assert token == "cabecera-token"
    assert source == "header"


def test_sin_cookie_ni_cabecera_no_hay_token():

    assert jwt_auth._session_token(make_request(), None) == (None, None)


def test_post_cross_site_con_cookie_se_rechaza():

    request = make_request(
        method="POST",
        headers={
            "origin": "https://malicioso.example",
            "host": "panel.local:8443",
        },
    )

    with pytest.raises(HTTPException) as error:

        jwt_auth._reject_cross_site(request)

    assert error.value.status_code == 403


def test_post_del_mismo_origen_se_permite():

    request = make_request(
        method="POST",
        headers={
            "origin": "https://panel.local:8443",
            "host": "panel.local:8443",
        },
    )

    assert jwt_auth._reject_cross_site(request) is None


def test_get_cross_site_no_se_bloquea():

    request = make_request(
        method="GET",
        headers={
            "origin": "https://otro.example",
            "host": "panel.local:8443",
        },
    )

    assert jwt_auth._reject_cross_site(request) is None


def test_sin_origin_no_se_bloquea_clientes_no_navegador():

    request = make_request(method="POST")

    assert jwt_auth._reject_cross_site(request) is None


def test_las_rutas_de_auth_tienen_logout_y_cookie():

    from backend.api.v1.routes import auth_router

    paths = {
        route.path
        for route in auth_router.router.routes
    }

    assert "/auth/logout" in paths
