"""Ruta de la configuración del NSP y migración a /etc/stepad.

La config (red/DHCP) es estado de cada máquina: vive en
/etc/stepad/config.yaml, fuera del repo. Estos tests cubren la
resolución de rutas y la migración de las instalaciones viejas (que la
tenían dentro del repo).
"""

import sys

from backend.shared.config.config_loader import ConfigLoader


# El paquete puede exponer una instancia con el mismo nombre que el
# submodulo: se toma del registro de modulos para poder monkeypatchear.
module = sys.modules["backend.shared.config.config_loader"]


def test_usa_la_config_del_sistema_si_existe(tmp_path, monkeypatch):

    system = tmp_path / "config.yaml"
    system.write_text("network:\n  wan_interface: eth0\n", encoding="utf-8")

    monkeypatch.setattr(module, "SYSTEM_CONFIG_PATH", system)

    legacy = tmp_path / "legacy.yaml"
    legacy.write_text("network:\n  wan_interface: eth1\n", encoding="utf-8")

    loader = ConfigLoader(legacy)

    assert loader.config_path == system


def test_cae_a_la_ruta_legacy_si_no_existe_la_del_sistema(
    tmp_path,
    monkeypatch
):

    monkeypatch.setattr(
        module,
        "SYSTEM_CONFIG_PATH",
        tmp_path / "no-existe.yaml",
    )

    legacy = tmp_path / "legacy.yaml"

    loader = ConfigLoader(legacy)

    assert loader.config_path == legacy


def test_la_variable_de_entorno_tiene_prioridad(tmp_path, monkeypatch):

    override = tmp_path / "otro.yaml"
    override.write_text("network: {}\n", encoding="utf-8")

    monkeypatch.setenv("STEPAD_CONFIG", str(override))
    monkeypatch.setattr(
        module,
        "SYSTEM_CONFIG_PATH",
        tmp_path / "no-existe.yaml",
    )

    loader = ConfigLoader(tmp_path / "legacy.yaml")

    assert loader.config_path == override


def test_save_escribe_en_la_ruta_del_sistema(tmp_path, monkeypatch):

    system = tmp_path / "config.yaml"
    system.write_text("network: {}\n", encoding="utf-8")

    monkeypatch.setattr(module, "SYSTEM_CONFIG_PATH", system)

    legacy = tmp_path / "legacy.yaml"
    legacy.write_text("network: {}\n", encoding="utf-8")

    loader = ConfigLoader(legacy)

    loader.update("network", {"wan_interface": "eth1"})

    assert "eth1" in system.read_text(encoding="utf-8")
    assert "eth1" not in legacy.read_text(encoding="utf-8")


def test_save_migra_la_config_legacy_al_sistema(tmp_path, monkeypatch):

    system = tmp_path / "config.yaml"

    monkeypatch.setattr(module, "SYSTEM_CONFIG_PATH", system)

    legacy = tmp_path / "legacy.yaml"
    legacy.write_text(
        "network:\n  wan_interface: eth0\n",
        encoding="utf-8",
    )

    loader = ConfigLoader(legacy)

    loader.update("network", {"wan_interface": "eth9"})

    assert system.exists()
    assert "eth9" in system.read_text(encoding="utf-8")
    assert loader.config_path == system


def test_lee_el_ejemplo_si_no_hay_config_ninguna(tmp_path, monkeypatch):

    monkeypatch.setattr(
        module,
        "SYSTEM_CONFIG_PATH",
        tmp_path / "no-existe.yaml",
    )

    # Ni la config del sistema ni la legacy existen: se lee el ejemplo.
    legacy = tmp_path / "config.yaml"

    example = tmp_path / "config.yaml.example"
    example.write_text("network:\n  wan_interface: null\n", encoding="utf-8")

    loader = ConfigLoader(legacy)

    assert loader._source_path() == example
