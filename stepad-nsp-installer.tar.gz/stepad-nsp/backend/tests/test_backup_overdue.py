from datetime import datetime

from backend.backups.services.backup_service import backup_overdue


def test_never_ran_before_schedule_is_not_overdue():

    now = datetime(2026, 10, 30, 2, 0)

    assert backup_overdue(None, now, 3, 30) is False


def test_never_ran_after_schedule_is_overdue():

    now = datetime(2026, 10, 30, 9, 0)

    assert backup_overdue(None, now, 3, 30) is True


def test_recent_run_is_fine():

    now = datetime(2026, 10, 30, 9, 0)

    last = datetime(2026, 10, 30, 3, 30)

    assert backup_overdue(last, now, 3, 30) is False


def test_run_more_than_a_day_ago_is_overdue():

    now = datetime(2026, 10, 30, 9, 0)

    last = datetime(2026, 10, 28, 3, 30)

    assert backup_overdue(last, now, 3, 30) is True


def test_grace_window_tolerates_restart():

    now = datetime(2026, 10, 30, 9, 0)

    last = datetime(2026, 10, 29, 3, 30)

    assert backup_overdue(last, now, 3, 30) is False
