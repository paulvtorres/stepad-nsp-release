from backend.api.middleware.error_handling import app_error_payload
from backend.backups.services.replacement_service import ReplacementService
from backend.shared.errors import (
    ConflictError,
    NotFoundError,
    PermissionDenied,
    ServiceUnavailable,
    ValidationError,
)


def test_error_status_and_codes():
    assert ValidationError("x").status_code == 400
    assert ValidationError("x").code == "validation_error"
    assert NotFoundError("x").status_code == 404
    assert ConflictError("x").status_code == 409
    assert PermissionDenied("x").status_code == 403
    assert ServiceUnavailable("x").status_code == 503


def test_payload_without_reference_for_client_errors():
    payload = app_error_payload(ValidationError("dato inválido"), "abc123")
    assert payload["status"] == 400
    assert payload["content"] == {
        "detail": "dato inválido",
        "code": "validation_error",
        "request_id": "abc123",
    }


def test_payload_adds_reference_for_server_errors():
    payload = app_error_payload(ServiceUnavailable("caído"), "abc123")
    assert payload["status"] == 503
    assert "(ref: abc123)" in payload["content"]["detail"]


def test_replacement_rejects_short_passphrase():
    try:
        ReplacementService().create_bundle("corta")
    except ValidationError as error:
        assert "12" in error.message
    else:
        raise AssertionError("esperaba ValidationError")
