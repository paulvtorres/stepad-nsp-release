from datetime import datetime
from types import SimpleNamespace

from backend.network.devices.services.device_service import DeviceService


def device(device_id, mac, status, last_seen, permanent_ip=None):
    return SimpleNamespace(
        id=device_id,
        mac_address=mac,
        status=status,
        last_seen=last_seen,
        permanent_ip=permanent_ip,
    )


def test_owner_actual_gana_a_registros_historicos():
    items = [
        device(247, "9e:38:25:28:55:5e", "OFFLINE", datetime(2026, 11, 11, 14, 58)),
        device(49, "4e:b5:a0:49:66:a0", "OFFLINE", datetime(2026, 11, 11, 14, 58)),
        device(115, "52:eb:e2:85:b3:2e", "ONLINE", datetime(2026, 11, 12, 16, 50)),
    ]

    owner = DeviceService._choose_ip_owner(
        items,
        "192.168.1.49",
        "52:eb:e2:85:b3:2e",
        "52:eb:e2:85:b3:2e",
    )

    assert owner.id == 115


def test_sin_arp_gana_el_mas_reciente():
    items = [
        device(1, "aa:00", "OFFLINE", datetime(2026, 11, 1)),
        device(2, "bb:00", "OFFLINE", datetime(2026, 11, 2)),
    ]

    owner = DeviceService._choose_ip_owner(items, "192.168.1.50", "", "")

    assert owner.id == 2


def test_reserva_gana_si_nadie_esta_en_arp():
    items = [
        device(1, "aa:00", "OFFLINE", datetime(2026, 11, 2)),
        device(2, "bb:00", "OFFLINE", datetime(2026, 11, 1), permanent_ip="192.168.1.51"),
    ]

    owner = DeviceService._choose_ip_owner(items, "192.168.1.51", "", "")

    assert owner.id == 2
