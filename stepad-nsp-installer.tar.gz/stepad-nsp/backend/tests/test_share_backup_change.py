from backend.shares.services import share_backup_change as change


def test_signature_stable_and_changes(tmp_path):

    (tmp_path / "a.txt").write_text("hola", encoding="utf-8")

    first = change.tree_signature(tmp_path)

    assert first == change.tree_signature(tmp_path)

    (tmp_path / "a.txt").write_text("hola mundo", encoding="utf-8")

    assert change.tree_signature(tmp_path) != first


def test_signature_ignores_empty_dirs(tmp_path):

    empty = tmp_path / "empty"

    empty.mkdir()

    with_dir = tmp_path / "with_dir"

    with_dir.mkdir()

    (with_dir / "sub").mkdir()

    assert change.tree_signature(empty) == change.tree_signature(with_dir)
