"""Capa de dominio del DHCP: exclusiones, rangos, leases y estadísticas.

Son funciones puras: si esto es correcto, el panel y los dhcp-range
escritos no pueden divergir (misma fuente de cálculo).
"""

import pytest

from backend.dhcp.domain.exclusions import (
    excluded_addresses,
    expand_token,
)
from backend.dhcp.domain.leases import (
    Lease,
    by_mac,
    dedupe_pairs,
    parse_leases,
)
from backend.dhcp.domain.pool import (
    build_pool_spec,
    build_ranges,
    pool_stats,
)


DHCP = {
    "pool_start": "192.168.1.20",
    "pool_end": "192.168.1.29",
    "netmask": "255.255.255.0",
    "lease_time": "24h",
    "group_ip_start": "192.168.1.10",
    "group_ip_end": "192.168.1.19",
    "excluded_ips": ["192.168.1.10-192.168.1.19"],
}


def test_expand_token_ip_y_rango():

    assert expand_token("192.168.1.50") == [int.from_bytes(bytes([192, 168, 1, 50]), "big")]

    assert len(expand_token("192.168.1.10-192.168.1.19")) == 10

    assert expand_token("") == []

    with pytest.raises(ValueError):

        expand_token("192.168.1.30-192.168.1.20")


def test_build_ranges_sin_excluidas():

    start = int.from_bytes(bytes([192, 168, 1, 20]), "big")

    end = start + 9  # .20 - .29

    excluded = {
        int.from_bytes(bytes([192, 168, 1, 25]), "big"),
    }

    ranges = build_ranges(start, end, excluded)

    assert [(a - start, b - start) for a, b in ranges] == [(0, 4), (6, 9)]


def test_pool_spec_excluye_reservas_del_pool_dinamico():

    spec = build_pool_spec(DHCP, reserved_ips=["192.168.1.25"])

    assert spec.total == 10

    assert spec.reserved == frozenset({spec.start + 5})

    # 10 direcciones - 1 reservada
    assert len(spec.dynamic) == 9

    assert all(spec.start + 5 not in segment for segment in [set(range(a, b + 1)) for a, b in spec.ranges])


def test_pool_stats_invariante():

    spec = build_pool_spec(DHCP, reserved_ips=["192.168.1.25"])

    def ip(value):

        return "192.168.1." + str(value)

    leases = [
        Lease(0, "aa:aa:aa:aa:aa:01", ip(21)),  # dinamica, ONLINE
        Lease(0, "aa:aa:aa:aa:aa:25", ip(25)),  # reservada, ONLINE
        Lease(0, "aa:aa:aa:aa:aa:26", ip(26)),  # dinamica, equipo apagado
    ]

    stats = pool_stats(
        spec,
        leases,
        online_macs={"aa:aa:aa:aa:aa:01", "aa:aa:aa:aa:aa:25"},
    )

    assert stats["online"] == 2

    assert stats["offline"] == 1  # .26: tiene lease pero el equipo no esta en ARP

    assert stats["reserved"] == 1

    assert stats["free"] == 7  # 9 dinamicas - 2 con lease

    assert stats["online"] + stats["offline"] + stats["free"] == stats["total"]


def test_pool_stats_reserva_ociosa_cuenta_como_ocupada():

    spec = build_pool_spec(DHCP, reserved_ips=["192.168.1.27"])

    stats = pool_stats(spec, [], online_macs=set())

    assert stats["offline"] == 1  # reserva que nadie usa ahora

    assert stats["free"] == 9

    assert stats["online"] + stats["offline"] + stats["free"] == stats["total"]


def test_parse_leases_infinito_y_sin_nombre():

    text = (
        "0 aa:bb:cc:dd:ee:01 192.168.1.30 * 01:aa\n"
        "1801055545 aa:bb:cc:dd:ee:02 192.168.1.31 PC-1 01:bb\n"
        "basura\n"
        "0 aa:bb:cc:dd:ee:01 192.168.1.30 NOMBRE 01:aa\n"
    )

    leases = dedupe_pairs(parse_leases(text))

    assert len(leases) == 2

    first = next(item for item in leases if item.mac.endswith(":01"))

    assert first.infinite is True
    assert first.hostname == "NOMBRE"  # el registro con nombre gana

    second = next(item for item in leases if item.mac.endswith(":02"))

    assert second.infinite is False
    assert by_mac(leases)[second.mac].ip == "192.168.1.31"


def test_ip_fija_dentro_del_pool_no_cuenta_como_libre():

    spec = build_pool_spec(DHCP, reserved_ips=["192.168.1.25"])

    def ip(value):

        return "192.168.1." + str(value)

    leases = [
        Lease(0, "aa:aa:aa:aa:aa:01", ip(21)),
    ]

    stats = pool_stats(
        spec,
        leases,
        online_macs={"aa:aa:aa:aa:aa:01"},
        static_ips=[ip(22), ip(23)],
    )

    # 9 dinamicas - 1 lease - 2 fijas = 6
    assert stats["free"] == 6

    assert stats["static"] == 2

    assert stats["online"] + stats["offline"] + stats["free"] == stats["total"]


def test_ip_fija_con_lease_no_se_descuenta_dos_veces():

    spec = build_pool_spec(DHCP, reserved_ips=[])

    def ip(value):

        return "192.168.1." + str(value)

    leases = [Lease(0, "aa:aa:aa:aa:aa:01", ip(21))]

    stats = pool_stats(
        spec,
        leases,
        online_macs={"aa:aa:aa:aa:aa:01"},
        static_ips=[ip(21)],
    )

    assert stats["static"] == 0

    assert stats["free"] == 9
