"""Tests del ancho de banda en vivo (WAN y por equipo).

Cubre el parseo de /proc/net/dev y /proc/net/nf_conntrack, el cálculo de
tasas y la acumulación de incrementos por flujo (que no debe caer
cuando el kernel expira una conexión).
"""

import sys
import time

from backend.bandwidth.services.live_traffic_service import (
    LiveTrafficService,
    is_internal_ip,
    parse_conntrack_line,
    parse_net_dev_counters,
    to_mbps,
)


module = sys.modules["backend.bandwidth.services.live_traffic_service"]


FLOW_1 = (
    "ipv4     2 tcp      6 431999 ESTABLISHED src=192.168.1.50 dst=1.1.1.1 "
    "sport=50000 dport=443 packets=10 bytes=1000 src=1.1.1.1 dst=192.168.1.50 "
    "sport=443 dport=50000 packets=20 bytes=5000 [ASSURED] mark=0 use=1\n"
)

FLOW_2 = (
    "ipv4     2 tcp      6 431999 ESTABLISHED src=192.168.1.50 dst=1.1.1.1 "
    "sport=50000 dport=443 packets=30 bytes=3000 src=1.1.1.1 dst=192.168.1.50 "
    "sport=443 dport=50000 packets=60 bytes=12000 [ASSURED] mark=0 use=1\n"
)

FLOW_SIN_CONTADORES = (
    "ipv4     2 tcp      6 431999 ESTABLISHED src=192.168.1.50 dst=1.1.1.1 "
    "sport=50000 dport=443 src=1.1.1.1 dst=192.168.1.50 sport=443 dport=50000 "
    "[ASSURED] mark=0 use=2\n"
)

FLOW_SALIENTE = (
    "ipv4     2 udp      17 29 src=8.8.4.4 dst=192.168.1.50 sport=53 dport=9999 "
    "packets=1 bytes=200 src=192.168.1.50 dst=8.8.4.4 sport=9999 dport=53 "
    "packets=1 bytes=300 mark=0 use=1\n"
)


def test_parse_net_dev_counters():

    line = (
        "enp2s0: 1234567 10 0 0 0 0 0 0 7654321 20 0 0 0 0 0 0\n"
    )

    assert parse_net_dev_counters(line, "enp2s0") == (1234567, 7654321)
    assert parse_net_dev_counters(line, "enp3s0") is None


def test_parse_conntrack_direcciones():

    parsed = parse_conntrack_line(FLOW_1)

    assert parsed is not None
    assert parsed["src"] == "192.168.1.50"
    # up = sentido original (equipo -> destino); down = respuesta.
    assert parsed["up"] == 1000
    assert parsed["down"] == 5000
    assert parsed["key"] == ("tcp", "192.168.1.50", "50000", "1.1.1.1", "443")


def test_parse_conntrack_sin_contabilidad_devuelve_none():

    assert parse_conntrack_line(FLOW_SIN_CONTADORES) is None


def test_to_mbps():

    # 1.000.000 bytes en 2 s = 4 Mbps.
    assert to_mbps(1_000_000, 2) == 4.0
    assert to_mbps(0, 2) == 0.0
    assert to_mbps(1000, 0) == 0.0


def test_is_internal_ip():

    assert is_internal_ip("192.168.1.20") is True
    assert is_internal_ip("127.0.0.1") is True
    assert is_internal_ip("8.8.8.8") is False
    assert is_internal_ip("no-es-ip") is False


def test_loopback_no_es_un_equipo(tmp_path, monkeypatch):

    conntrack = tmp_path / "nf_conntrack"
    conntrack.write_text(
        "ipv4 2 tcp 6 431999 ESTABLISHED src=127.0.0.1 dst=127.0.0.1 sport=1 dport=2 "
        "packets=1 bytes=100 src=127.0.0.1 dst=127.0.0.1 sport=2 dport=1 "
        "packets=1 bytes=200 mark=0 use=1\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(module, "CONNTRACK", conntrack)

    service = LiveTrafficService()

    assert service._collect_flow_deltas() == {}


def test_trafico_lan_a_lan_no_se_cuenta(tmp_path, monkeypatch):

    # Compartido SMB / DNS interno: no cruza la WAN.
    lan_flow = (
        "ipv4 2 tcp 6 431999 ESTABLISHED src=192.168.1.1 dst=192.168.1.50 "
        "sport=445 dport=50000 packets=10 bytes=999999 "
        "src=192.168.1.50 dst=192.168.1.1 sport=50000 dport=445 "
        "packets=10 bytes=999999 mark=0 use=1\n"
    )

    conntrack = tmp_path / "nf_conntrack"
    conntrack.write_text(lan_flow, encoding="utf-8")

    monkeypatch.setattr(module, "CONNTRACK", conntrack)

    service = LiveTrafficService()

    assert service._collect_flow_deltas() == {}


def test_deltas_por_flujo_no_caen_al_expirar(tmp_path, monkeypatch):

    conntrack = tmp_path / "nf_conntrack"
    conntrack.write_text(FLOW_1, encoding="utf-8")

    monkeypatch.setattr(module, "CONNTRACK", conntrack)

    service = LiveTrafficService()

    first = service._collect_flow_deltas()

    assert first == {"192.168.1.50": [1000, 5000]}

    conntrack.write_text(FLOW_2, encoding="utf-8")

    second = service._collect_flow_deltas()

    assert second == {"192.168.1.50": [2000, 7000]}

    # El flujo expira: desaparece de conntrack y no se vuelve a contar.
    conntrack.write_text("", encoding="utf-8")

    third = service._collect_flow_deltas()

    assert third == {}

    conntrack.write_text(FLOW_2, encoding="utf-8")

    fourth = service._collect_flow_deltas()

    # Flujo nuevo con contadores ya acumulados: se cuenta lo acumulado.
    assert fourth == {"192.168.1.50": [3000, 12000]}


def test_flujos_desde_internet_no_se_atribuyen(tmp_path, monkeypatch):

    conntrack = tmp_path / "nf_conntrack"
    conntrack.write_text(FLOW_SALIENTE, encoding="utf-8")

    monkeypatch.setattr(module, "CONNTRACK", conntrack)

    service = LiveTrafficService()

    assert service._collect_flow_deltas() == {}


def test_tasa_wan(monkeypatch):

    service = LiveTrafficService()

    service._wan_interfaces = ["enp2s0"]
    service._wan_ifaces_at = time.time()

    counters = iter([(0, 0), (1_000_000, 500_000)])

    monkeypatch.setattr(
        module,
        "read_net_dev_counters",
        lambda ifname: next(counters),
    )

    first = service._sample_wan(100.0)

    assert first["rx_mbps"] == 0.0
    assert first["interface"] == "enp2s0"

    second = service._sample_wan(102.0)

    assert second["rx_mbps"] == 4.0
    assert second["tx_mbps"] == 2.0
    assert second["rx_total_bytes"] == 1_000_000
