
from backend.shares.services import share_backup_store as store


def test_roundtrip_y_normalizacion(tmp_path):

    config = store.write_config(tmp_path / "v", {"jobs": [{"id": 4}]})

    assert config["schema"] == store.CONFIG_SCHEMA

    assert config["next_job_id"] == 5

    assert store.read_config(tmp_path / "v")["jobs"] == [{"id": 4}]

    mode = (tmp_path / "v" / store.CONFIG_FILENAME).stat().st_mode & 0o777

    assert mode == 0o600


def test_missing_o_invalido_devuelve_none(tmp_path):

    assert store.read_config(tmp_path / "nope") is None

    vault = tmp_path / "v"

    vault.mkdir()

    (vault / store.CONFIG_FILENAME).write_text("{}", encoding="utf-8")

    assert store.read_config(vault) is None

    (vault / store.CONFIG_FILENAME).write_text("no-json", encoding="utf-8")

    assert store.read_config(vault) is None


def test_empty_config_valido(tmp_path):

    vault = tmp_path / "v"

    store.write_config(vault, store.empty_config())

    assert store.read_config(vault)["jobs"] == []


def test_config_path(tmp_path):

    assert store.config_path(tmp_path) == tmp_path / ".respaldo.json"
