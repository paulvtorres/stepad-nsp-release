from backend.network.devices.utils.mac import (
    is_locally_administered,
    normalize_mac,
)


def test_normalize_mac():

    assert normalize_mac("AA-BB-CC-DD-EE-FF") == "aa:bb:cc:dd:ee:ff"

    assert normalize_mac(None) == ""


def test_randomized_macs_detected():

    for mac in ("1e:82:af:b5:24:8f", "ea:76:38:3c:3f:84", "3a:57:8f:09:70:a4"):

        assert is_locally_administered(mac) is True


def test_vendor_macs_not_flagged():

    for mac in ("40:8d:5c:0e:e6:08", "2c:fd:a1:bf:38:55", "00:26:73:1b:ef:32"):

        assert is_locally_administered(mac) is False


def test_invalid_mac_is_safe():

    assert is_locally_administered(None) is False

    assert is_locally_administered("") is False

    assert is_locally_administered("zz:zz") is False

    assert is_locally_administered("not-a-mac") is False
