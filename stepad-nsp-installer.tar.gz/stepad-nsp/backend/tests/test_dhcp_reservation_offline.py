"""La reserva DHCP debe existir aunque el equipo esté apagado.

`synchronize()` omitia los equipos con `ip_address` vacia (los apagados):
su IP quedaba fuera del pool sin un dhcp-host que la sirviera, asi que el
equipo al encender no podia tomar su IP reservada y terminaba usando la
de otro equipo (paso en produccion con COMERCIAL).
"""

import sys

from datetime import timedelta

from backend.shared.datetime_utils import utcnow


from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService,
)


module = sys.modules["backend.dhcp.services.dhcp_reservation_service"]


class FakeDevice:

    def __init__(
        self,
        mac,
        permanent_ip,
        ip_address="",
        device_id=1,
        last_seen=None,
        is_permanent=False,
        device_type="COMPUTER",
    ):
        self.id = device_id
        self.mac_address = mac
        self.permanent_ip = permanent_ip
        self.ip_address = ip_address
        self.zone_id = None
        self.blocked = False
        self.status = "OFFLINE"
        self.last_seen = last_seen
        self.is_permanent = is_permanent
        self.device_type = device_type


class FakeQuery:

    def __init__(self, devices):
        self._devices = devices

    def filter(self, *args, **kwargs):
        return self

    def all(self):
        return self._devices


class FakeDb:

    def __init__(self, devices):
        self._devices = devices

    def query(self, model):
        return FakeQuery(self._devices)

    def close(self):
        pass


class FakeProvider:

    def __init__(self):
        self.written = None

    def write_reservations(self, reservations):
        self.written = reservations
        return {"success": True, "total": len(reservations)}


class FakeZoneRepo:

    def find_all(self, db):
        return []


class FakeGroupRepo:

    def find_all(self, db):
        return []

    def device_ids(self, db, group_id):
        return []


class FakeConfigService:

    def get_dhcp_config(self):
        return {"gateway": "192.168.1.1"}


class FakePoolStats:

    def get_stats(self):
        return {"devices": {"free": 0, "dynamic": 100}}


class FakeDnsmasqManager:

    def restart(self):
        return {"success": True}


def _service(devices, monkeypatch):

    service = DhcpReservationService.__new__(DhcpReservationService)
    service.provider = FakeProvider()
    service.zone_repository = FakeZoneRepo()
    service.group_repository = FakeGroupRepo()

    monkeypatch.setattr(module, "SessionLocal", lambda: FakeDb(devices))

    from backend.shared.config import config_service as config_module
    monkeypatch.setattr(
        config_module, "ConfigService", FakeConfigService
    )

    from backend.core.dnsmasq import process_manager as pm_module
    monkeypatch.setattr(
        pm_module, "dnsmasq_process_manager", FakeDnsmasqManager()
    )

    return service


def test_reserva_se_genera_aunque_el_equipo_este_apagado(monkeypatch):

    devices = [FakeDevice("aa:bb:cc:dd:ee:ff", "192.168.1.26", ip_address="")]
    service = _service(devices, monkeypatch)

    # `collect()` es la entrada del reconciliador (no escribe archivos).
    reservations = service.collect()

    assert reservations == [
        {
            "mac": "aa:bb:cc:dd:ee:ff",
            "ip": "192.168.1.26",
            "hostname": "",
            "zone_tag": None,
            "group_tag": None,
        }
    ]


def test_sin_permanent_ip_no_se_reserva(monkeypatch):

    devices = [FakeDevice("aa:bb:cc:dd:ee:01", "", ip_address="192.168.1.40")]
    service = _service(devices, monkeypatch)

    assert service.collect() == []


def test_reserva_vieja_de_equipo_apagado_no_se_libera(monkeypatch):

    devices = [
        FakeDevice(
            "aa:bb:cc:dd:ee:02",
            "192.168.1.77",
            last_seen=utcnow() - timedelta(days=30),
        )
    ]
    service = _service(devices, monkeypatch)

    assert len(service.collect()) == 1


def test_reserva_permanente_no_se_libera(monkeypatch):

    devices = [
        FakeDevice(
            "aa:bb:cc:dd:ee:03",
            "192.168.1.78",
            last_seen=utcnow() - timedelta(days=30),
            is_permanent=True,
        )
    ]
    service = _service(devices, monkeypatch)

    assert len(service.collect()) == 1


def test_pool_agotado_no_libera_reservas(monkeypatch):

    devices = [
        FakeDevice(
            "aa:bb:cc:dd:ee:04",
            "192.168.1.79",
            last_seen=utcnow(),
        )
    ]
    service = _service(devices, monkeypatch)

    from backend.dhcp.services import dhcp_pool_stats_service as pool_module

    monkeypatch.setattr(
        pool_module, "DhcpPoolStatsService", FakePoolStats
    )

    assert len(service.collect()) == 1


def test_reserva_ocupada_por_otra_mac_sigue_publicada(monkeypatch):

    devices = [FakeDevice("aa:bb:cc:dd:ee:05", "192.168.1.80")]
    service = _service(devices, monkeypatch)

    monkeypatch.setattr(
        service,
        "_active_ip_owners",
        lambda: {"192.168.1.80": "bb:bb:bb:bb:bb:bb"},
    )

    reservations = service.collect()

    assert reservations[0]["ip"] == "192.168.1.80"
