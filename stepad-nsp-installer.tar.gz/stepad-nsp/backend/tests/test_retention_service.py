from datetime import datetime

import pytest

from backend.retention.services.retention_service import (
    BATCH_SIZE,
    KINDS,
    KINDS_BY_KEY,
    RETENTION_PRESETS,
    RetentionService,
    cutoff_for,
    validate_days,
)


def test_presets_cover_months_and_unlimited():

    # 1..6 meses, 9 y 12 meses, mas "ilimitado" (0).
    assert set(RETENTION_PRESETS) == {
        30, 60, 90, 120, 150, 180, 270, 365, 0
    }


def test_validate_days_rejects_values_outside_presets():

    assert validate_days(90) == 90

    assert validate_days("0") == 0

    with pytest.raises(ValueError):

        validate_days(45)


def test_cutoff_for_zero_or_negative_is_disabled():

    assert cutoff_for(0) is None

    assert cutoff_for(-10) is None


def test_cutoff_for_subtracts_days():

    now = datetime(2026, 10, 30, 12, 0, 0)

    assert cutoff_for(30, now) == datetime(2026, 9, 30, 12, 0, 0)


def test_kind_keys_are_unique_and_models_have_column():

    keys = [kind.key for kind in KINDS]

    assert len(keys) == len(set(keys))

    for kind in KINDS:

        assert hasattr(kind.model, kind.column)

        assert kind.model is not None


def test_batch_size_is_bounded():

    assert 1000 <= BATCH_SIZE <= 50000


class _FakeSetting:

    def __init__(self, days, enabled=True):

        self.retention_days = days

        self.enabled = enabled

        self.last_run_at = None

        self.last_deleted = 0


class _FakeService(RetentionService):

    def _ensure_setting(self, db, kind):

        return _FakeSetting(kind.default_days)

    def _stats(self, db, kind):

        return {"rows": 7, "oldest": datetime(2026, 1, 1)}


def test_list_settings_exposes_ui_contract():

    items = _FakeService().list_settings(None)

    assert len(items) == len(KINDS)

    item = next(i for i in items if i["key"] == "alerts")

    assert item["label"] == "Alertas"

    assert item["keep_unread"] is True

    assert item["options_days"] == list(RETENTION_PRESETS)

    assert item["rows"] == 7


def test_set_retention_validates_before_touching_db():

    service = RetentionService()

    with pytest.raises(ValueError):

        service.set_retention(None, "desconocido", 90)

    with pytest.raises(ValueError):

        service.set_retention(None, "dns_logs", 45)


def test_all_defaults_are_valid_presets():

    for kind in KINDS:

        assert kind.default_days in RETENTION_PRESETS
        assert KINDS_BY_KEY[kind.key] is kind

def test_inactive_devices_kind_is_guarded():

    kind = KINDS_BY_KEY["inactive_devices"]

    assert kind.guard == "device"

    assert kind.column == "last_seen"

    conditions = RetentionService().guard_conditions(kind)

    assert len(conditions) >= 4

    from sqlalchemy import select
    from sqlalchemy.dialects import postgresql

    from backend.network.devices.models.network_device import NetworkDevice

    sql = str(
        select(NetworkDevice.id)
        .where(*conditions)
        .compile(dialect=postgresql.dialect())
    )

    assert "is_company_asset" in sql

    assert "is_permanent" in sql

    assert "NOT (EXISTS" in sql

    assert "network_devices.status" in sql


def test_only_device_kind_has_guard():

    guarded = [kind.key for kind in KINDS if kind.guard]

    assert guarded == ["inactive_devices"]

