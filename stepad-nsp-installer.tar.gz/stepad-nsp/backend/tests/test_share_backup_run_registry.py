from backend.shares.services.share_backup_run_registry import BackupRunRegistry


def test_begin_finish_and_state():
    registry = BackupRunRegistry()

    assert registry.state(1) == "idle"
    assert registry.begin(1, "now") is True
    assert registry.begin(1, "later") is False
    assert registry.state(1) == "running"
    assert registry.running_since[1] == "now"
    assert registry.running_ids() == {1}

    registry.set_progress(1, {"files_done": 2})
    registry.finish(1)

    assert registry.state(1) == "idle"
    assert 1 not in registry.running_since
    assert registry.get_progress(1) == {}


def test_cancel_is_consumed_once():
    registry = BackupRunRegistry()

    registry.request_cancel(5)

    assert registry.consume_cancel(5) is True
    assert registry.consume_cancel(5) is False


def test_proc_and_restore_state():
    registry = BackupRunRegistry()
    proc = object()

    registry.set_proc(2, proc)
    assert registry.pop_proc(2) is proc
    assert registry.pop_proc(2) is None

    registry.set_restore(3, {"running": True})
    assert registry.get_restore(3)["running"] is True
    assert registry.restore_items() == [(3, {"running": True})]
