from unittest.mock import MagicMock, patch

from backend.monitoring.services import navigation_health_service
from backend.monitoring.services.navigation_health_service import (
    NavigationHealthService,
    probe_dns_a,
)


def test_probe_dns_a_invalid_resolver():

    assert probe_dns_a("127.0.0.1", "invalid..name") is False


def test_navigation_dhcp_stuck_marks_unhealthy():

    db = MagicMock()

    dhcp_snap = {
        "running": True,
        "stuck": True,
        "healthy": False,
        "recv_q": 99999,
    }

    with patch.object(
        NavigationHealthService,
        "__init__",
        lambda self: None,
    ), patch(
        "backend.monitoring.services.navigation_health_service."
        "DhcpHealthService"
    ) as dhcp_cls, patch(
        "backend.monitoring.services.navigation_health_service."
        "ConfigService"
    ) as cfg_cls, patch(
        "backend.monitoring.services.navigation_health_service."
        "probe_dns_a",
        return_value=True,
    ), patch(
        "backend.monitoring.services.navigation_health_service."
        "_pdns_active",
        return_value=True,
    ), patch(
        "backend.monitoring.services.navigation_health_service."
        "_listener_port_open",
        return_value=True,
    ), patch(
        "backend.monitoring.services.navigation_health_service."
        "dns_query_log_listener"
    ) as listener, patch(
        "backend.monitoring.services.navigation_health_service."
        "_recent_dns_log",
        return_value=10,
    ), patch(
        "backend.monitoring.services.navigation_health_service."
        "_ips_enabled",
        return_value=False,
    ), patch(
        "backend.monitoring.services.navigation_health_service."
        "_disk_free_mb",
        return_value=5000,
    ), patch(
        "backend.network.configuration.services.network_topology_check_service."
        "NetworkTopologyCheckService"
    ) as topo_cls, patch(
        "backend.network.zones.repositories.network_zone_repository."
        "NetworkZoneRepository"
    ) as zone_repo_cls:

        dhcp_cls.return_value.inspect.return_value = dhcp_snap

        cfg_cls.return_value.get_dhcp_config.return_value = {
            "dns_server": "192.168.1.1",
        }

        listener.is_started.return_value = True

        listener.last_message_at.return_value = None

        topo_cls.return_value.get_conflicts.return_value = {
            "ok": True,
            "detail": "ok",
        }

        zone_repo_cls.return_value.find_all.return_value = []

        service = NavigationHealthService.__new__(NavigationHealthService)

        service.dhcp_health = dhcp_cls.return_value

        report = service.inspect(db)

    assert report["checks"]["dhcp"]["ok"] is False
    assert "colgado" in report["checks"]["dhcp"]["detail"].lower()
    assert report["ok"] is False


def _fake_run(systemd_state, pgrep_rc=1, pgrep_out=""):

    def _run(cmd, *args, **kwargs):

        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""

        if cmd[:3] == ["systemctl", "is-active", "suricata"]:

            result.stdout = f"{systemd_state}\n"

        elif cmd[:2] == ["pgrep", "-f"]:

            result.returncode = pgrep_rc
            result.stdout = pgrep_out

        return result

    return _run


def test_suricata_active_accepts_transient_systemd_states():

    # Durante un reinicio en segundo plano systemd devuelve
    # "activating"/"reloading": NO debe generar alerta de IPS caído.
    for state in ("active", "activating", "reloading"):

        with patch.object(
            navigation_health_service.subprocess,
            "run",
            side_effect=_fake_run(state),
        ):

            assert navigation_health_service._suricata_active() is True


def test_suricata_active_falls_back_to_running_process():

    # systemd dice "inactive" pero el proceso existe (Suricata renombra
    # su proceso a "Suricata-Main"; hay que buscar con pgrep -f).
    with patch.object(
        navigation_health_service.subprocess,
        "run",
        side_effect=_fake_run("inactive", pgrep_rc=0, pgrep_out="3102633\n"),
    ):

        assert navigation_health_service._suricata_active() is True


def test_suricata_inactive_reports_not_running():

    with patch.object(
        navigation_health_service.subprocess,
        "run",
        side_effect=_fake_run("inactive"),
    ), patch.object(
        navigation_health_service,
        "SURICATA_PIDFILE",
        MagicMock(read_text=MagicMock(side_effect=FileNotFoundError())),
    ):

        assert navigation_health_service._suricata_active() is False
