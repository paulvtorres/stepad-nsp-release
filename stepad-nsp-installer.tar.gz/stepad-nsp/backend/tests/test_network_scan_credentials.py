from backend.api.v1.routes.network_scan import (
    ShareBrowseRequest,
    ShareListRequest,
    ShareTestRequest,
    router,
)


CREDENTIAL_PATHS = (
    "/shares/network/test",
    "/shares/network/list-shares",
    "/shares/network/browse",
)


def test_credential_routes_are_post_only():
    methods = {route.path: route.methods for route in router.routes}

    for path in CREDENTIAL_PATHS:
        assert methods[path] == {"POST"}, (
            f"{path} debe aceptar solo POST para no filtrar credenciales "
            "en la URL"
        )


def test_credentials_are_hidden_from_repr():
    assert "hunter2" not in repr(
        ShareTestRequest(host="h", share="s", password="hunter2")
    )
    assert "hunter2" not in repr(
        ShareListRequest(host="h", password="hunter2")
    )
    assert "hunter2" not in repr(
        ShareBrowseRequest(host="h", share="s", password="hunter2")
    )
