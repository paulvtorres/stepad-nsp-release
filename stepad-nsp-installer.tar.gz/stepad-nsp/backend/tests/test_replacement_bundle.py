from datetime import datetime

import pytest

from backend.backups.services import replacement_bundle as bundle


def test_manifest_roundtrip():
    now = datetime(2026, 11, 7, 18, 0)

    data = bundle.build_manifest(
        "v2.5.474", "host", "stepad_nsp", {"database.sql.gz": 10}, now=now
    )

    assert data["format"] == bundle.FORMAT
    assert data["created_at"] == "2026-11-07T18:00:00"
    assert bundle.validate_manifest(data) is data


def test_manifest_rejects_invalid():
    with pytest.raises(ValueError):
        bundle.validate_manifest({"format": "otro"})
    with pytest.raises(ValueError):
        bundle.validate_manifest({"format": bundle.FORMAT, "version": ""})
    with pytest.raises(ValueError):
        bundle.validate_manifest(
            {"format": bundle.FORMAT, "version": "v1", "files": []}
        )


def test_filename_is_safe():
    now = datetime(2026, 11, 7, 18, 5)

    name = bundle.bundle_filename("v2.5.474", now=now)

    assert name == "stepad-replacement-v2.5.474-20261107-1805.enc"
    assert "/" not in bundle.bundle_filename("a/b", now=now)
