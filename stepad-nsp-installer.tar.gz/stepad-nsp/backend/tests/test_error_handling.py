from backend.api.middleware.error_handling import is_explorer_path, map_exception


def test_explorer_permission_is_403():

    assert map_exception(
        PermissionError("x"), "/api/v1/shares/web/list"
    ) == (403, "Permiso denegado")

    assert map_exception(
        PermissionError("x"), "/api/v1/shares/network/browse"
    ) == (403, "Permiso denegado")


def test_explorer_missing_file_is_404():

    assert map_exception(
        FileNotFoundError("x"), "/api/v1/shares/web/info"
    ) == (404, "Recurso no encontrado")


def test_missing_binary_is_500_outside_explorer():

    assert map_exception(
        FileNotFoundError("parted"), "/api/v1/shares/volumes"
    ) == (500, "Error interno del servidor")

    assert map_exception(
        PermissionError("x"), "/api/v1/devices"
    ) == (500, "Error interno del servidor")


def test_timeout_is_504():

    assert map_exception(TimeoutError("x")) == (504, "Tiempo de espera agotado")


def test_unknown_error_is_500():

    assert map_exception(RuntimeError("x")) == (500, "Error interno del servidor")

    assert map_exception(ValueError("bug")) == (500, "Error interno del servidor")


def test_is_explorer_path():

    assert is_explorer_path("/api/v1/shares/web/list") is True

    assert is_explorer_path("/api/v1/shares/network/browse") is True

    assert is_explorer_path("/api/v1/shares/backups") is False

    assert is_explorer_path("") is False
