from backend.dhcp.domain.lease_events import (
    log_has_no_address,
    mac_from_log,
)


def test_no_address_en_ingles_y_espanol():
    assert log_has_no_address("DHCP no address available")
    assert log_has_no_address("DHCP ninguna dirección disponible")


def test_nak_no_es_no_address():
    assert not log_has_no_address("DHCPNAK 192.168.1.30 aa:bb:cc:dd:ee:ff")


def test_extrae_mac():
    assert mac_from_log(
        "no address available for aa:BB:CC:dd:EE:ff"
    ) == "aa:bb:cc:dd:ee:ff"
    assert mac_from_log("no address available") == ""
