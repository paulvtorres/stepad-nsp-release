from datetime import datetime, timedelta, timezone

from backend.api.v1.routes import observability as obs


def test_type_declared_once_per_metric():

    samples = {}


    samples.setdefault("stepad_service_up", ("gauge", []) )[1].extend(
        [
            ('{service="dnsmasq"}', "1"),
            ('{service="pdns"}', "1"),
            ('{service="suricata"}', "0"),
        ]
    )

    text = obs.render_metrics(samples)

    assert text.count("# TYPE stepad_service_up gauge") == 1

    assert text.count("stepad_service_up{") == 3


def test_naive_utc_normalizes():

    aware = datetime(2026, 1, 1, 12, 0, tzinfo=timezone.utc)

    assert obs.naive_utc(aware) == datetime(2026, 1, 1, 12, 0)

    shifted = datetime(
        2026, 1, 1, 7, 0, tzinfo=timezone(timedelta(hours=-5))
    )

    assert obs.naive_utc(shifted) == datetime(2026, 1, 1, 12, 0)

    assert obs.naive_utc("2026-01-01T12:00:00Z") == datetime(2026, 1, 1, 12, 0)

    assert obs.naive_utc(None) is None

    assert obs.naive_utc("nope") is None


def test_metrics_allowed_token_or_private():

    assert obs.metrics_allowed("", "", True) is True

    assert obs.metrics_allowed("", "", False) is False

    assert obs.metrics_allowed("s3cret", "s3cret", False) is True

    assert obs.metrics_allowed("bad", "s3cret", True) is False

    assert obs.metrics_allowed("", "s3cret", True) is False


def test_label_value_escapes():

    assert obs.label_value('a"b\\c') == 'a\\"b\\\\c'
