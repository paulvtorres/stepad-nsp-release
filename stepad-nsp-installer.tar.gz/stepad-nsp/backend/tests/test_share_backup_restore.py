from backend.shares.services import share_backup_restore as restore


def test_parse_restore_size_units():

    assert restore.parse_restore_size("Total Size: 1.5 GiB") == int(1.5 * 1024**3)

    assert restore.parse_restore_size("Total Size: 2 GB") == 2 * 10**9

    assert restore.parse_restore_size("Total Size: 512 MiB") == 512 * 1024**2

    assert restore.parse_restore_size("nada") is None

    assert restore.parse_restore_size("") is None


def test_find_restored_root_nested(tmp_path):

    target = tmp_path / "mnt" / "share" / "docs"

    target.mkdir(parents=True)

    (target / "a.txt").write_text("x", encoding="utf-8")

    assert (
        restore.find_restored_root(tmp_path, "/mnt/share/docs") == target
    )


def test_find_restored_root_single_inner(tmp_path):

    inner = tmp_path / "docs"

    inner.mkdir()

    (inner / "a.txt").write_text("x", encoding="utf-8")

    assert (
        restore.find_restored_root(tmp_path, "/no/match") == inner
    )


def test_find_restored_root_missing(tmp_path):

    assert restore.find_restored_root(tmp_path / "nope", "/x") is None

    empty = tmp_path / "empty"

    empty.mkdir()

    assert restore.find_restored_root(empty, "/x") is None
