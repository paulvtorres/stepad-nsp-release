from backend.core.health import ports_check as pc


def _fake(flag, tcp_any, udp_any):

    def _inner(flag_arg):

        if flag_arg == "-tln":

            return ({}, tcp_any)

        return ({}, udp_any)

    return _inner


def test_ssh_bound_to_specific_address_is_ok(monkeypatch):

    monkeypatch.setattr(
        pc,
        "_listening_ports",
        _fake("-tln", {8443: "0.0.0.0:8443", 22: "192.168.1.1:22"},
              {53: "127.0.0.1:53", 51820: "*:51820"}),
    )

    issues = pc.check_ports()

    assert not any("22" in issue["title"] for issue in issues)

    assert not any("8443" in issue["title"] for issue in issues)


def test_missing_ssh_is_reported(monkeypatch):

    monkeypatch.setattr(
        pc,
        "_listening_ports",
        _fake("-tln", {8443: "0.0.0.0:8443"},
              {53: "127.0.0.1:53", 51820: "*:51820"}),
    )

    issues = pc.check_ports()

    assert any("22" in issue["title"] for issue in issues)


def test_forbidden_only_on_wildcard(monkeypatch):

    def fake(flag):

        if flag == "-tln":

            return (
                {445: "0.0.0.0:445"},
                {
                    445: "0.0.0.0:445",
                    5432: "127.0.0.1:5432",
                    22: "192.168.1.1:22",
                    8443: "0.0.0.0:8443",
                },
            )

        return ({}, {53: "x", 51820: "x"})

    monkeypatch.setattr(pc, "_listening_ports", fake)

    titles = [issue["title"] for issue in pc.check_ports()]

    assert any("445" in title for title in titles)

    assert not any("5432" in title for title in titles)
