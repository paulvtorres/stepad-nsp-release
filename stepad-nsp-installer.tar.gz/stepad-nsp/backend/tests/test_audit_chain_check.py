import json
import os
import stat
from datetime import datetime, timedelta

from backend.audit.services import audit_chain_check_service as check


class FakeDB:
    def __init__(self):
        self.commits = 0

    def commit(self):
        self.commits += 1

    def close(self):
        pass


def test_should_run_based_on_state(tmp_path):
    service = check.AuditChainCheckService(str(tmp_path / "state.json"))

    assert service.should_run() is True

    service._save({"last_run_at": datetime.utcnow().isoformat()})
    assert service.should_run() is False

    service._save(
        {"last_run_at": (datetime.utcnow() - timedelta(hours=30)).isoformat()}
    )
    assert service.should_run() is True


def test_run_saves_state(tmp_path, monkeypatch):
    from backend.audit.services.audit_service import AuditService

    monkeypatch.setattr(
        AuditService,
        "verify_chain",
        lambda self, db: {"ok": True, "checked": 7, "legacy": 2},
    )

    service = check.AuditChainCheckService(str(tmp_path / "state.json"))
    db = FakeDB()

    result = service.run(db, alert=False)

    assert result["ok"] is True
    assert result["checked"] == 7
    assert result["message"] == "cadena íntegra"
    assert service.status()["ok"] is True


def test_run_reports_broken_state(tmp_path, monkeypatch):
    from backend.audit.services.audit_service import AuditService

    monkeypatch.setattr(
        AuditService,
        "verify_chain",
        lambda self, db: {"ok": False, "checked": 3, "broken_at": 42},
    )

    path = tmp_path / "state.json"
    service = check.AuditChainCheckService(str(path))

    result = service.run(FakeDB(), alert=False)

    assert result["ok"] is False
    assert "42" in result["message"]
    assert json.loads(path.read_text())["broken_at"] == 42
    assert stat.S_IMODE(os.stat(path).st_mode) == 0o600
