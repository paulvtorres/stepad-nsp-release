"""Un pico no alerta; la capacidad sostenida sí."""

from collections import deque

from backend.monitoring.components.monitoring_component import (
    MonitoringComponent,
)


class FakeMonitoring:

    def __init__(self, cpu):
        self.cpu = cpu

    def snapshot(self):
        return {
            "cpu_percent": self.cpu,
            "ram_percent": 20,
            "disk_percent": 30,
            "ram_available": 1000,
            "ram_total": 2000,
            "disk_used": 100,
            "disk_total": 1000,
            "cpu_cores": 4,
            "load_avg": [1.0, 1.0, 1.0],
        }

    def top_processes(self):
        return [{"name": "suricata", "cpu": 88.0}]


class FakeAlerts:

    def __init__(self):
        self.created = []
        self.resolved = []

    def create(self, db, alert_type, severity, title, message):
        self.created.append((alert_type, title, message))

    def resolve(self, db, alert_type, title=None):
        self.resolved.append((alert_type, title))


def component(cpu, samples):
    component = MonitoringComponent.__new__(MonitoringComponent)
    component.monitoring = FakeMonitoring(cpu)
    component.alert_service = FakeAlerts()
    component._cooldown = {}
    component._resource_samples = {
        "cpu": deque(samples, maxlen=20),
        "ram": deque([], maxlen=20),
        "disk": deque([], maxlen=20),
    }
    return component


def test_pico_aislado_no_alerta():
    # 19 muestras normales + un pico al final: el p95 sigue bajo.
    service = component(99.0, [10.0] * 19)

    service._check_resources(None)

    assert service.alert_service.created == []


def test_capacidad_sostenida_alerta():
    service = component(99.0, [95.0] * 19)

    service._check_resources(None)

    assert len(service.alert_service.created) == 1
    assert service.alert_service.created[0][0] == "RESOURCE_CPU"
    assert "sostenida" in service.alert_service.created[0][2].lower()
