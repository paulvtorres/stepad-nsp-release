from pathlib import Path
import pytest
from fastapi import HTTPException

from backend.shares.services.network_share_service import NetworkShareService
from backend.shares.services.partition_service import PartitionService


class FakeJob(dict):
    def __init__(self, data, vault=None):
        super().__init__(data)
        self.vault = vault


class FakeBackup:
    def __init__(self, jobs, running, restore_status=None):
        self._jobs = {int(j.get("id")): j for j in jobs}
        self._running_jobs = set(running)
        self._restore_status = restore_status or {}

    def _find_job(self, job_id):
        return self._jobs.get(int(job_id))


def make_service(backup=None):
    service = object.__new__(NetworkShareService)
    service.backup_service = backup or FakeBackup([], set())
    return service


MP = "/mnt/stepad-share/sdb1"


def test_in_use_by_running_source():

    job = FakeJob(
        {"id": 1, "name": "Docs", "source_path": MP + "/docs"},
        vault=Path("/mnt/other/Respaldo"),
    )
    service = make_service(FakeBackup([job], {1}))

    assert "Docs" in service._partition_in_use(MP)


def test_in_use_by_vault_attribute():

    job = FakeJob(
        {"id": 2, "name": "Copia", "source_path": "/tmp/out"},
        vault=Path(MP) / "Respaldo",
    )
    service = make_service(FakeBackup([job], {2}))

    assert "Copia" in service._partition_in_use(MP)


def test_in_use_by_plain_dict_destination():

    job = {
        "id": 3,
        "name": "Plano",
        "source_path": "/tmp/out",
        "destination_path": MP + "/Respaldo/job-3",
    }
    service = make_service(FakeBackup([job], {3}))

    assert "Plano" in service._partition_in_use(MP)


def test_not_in_use():

    job = FakeJob(
        {"id": 4, "name": "Otro", "source_path": "/srv/data"},
        vault=Path("/mnt/other/Respaldo"),
    )
    service = make_service(FakeBackup([job], {4}))

    assert service._partition_in_use(MP) is None


class FakeQuery:
    def filter(self, *args, **kwargs):
        return self

    def first(self):
        return None


class FakeDB:
    def query(self, *args, **kwargs):
        return FakeQuery()

    def rollback(self):
        pass


class FakeDiskMount:
    def __init__(self):
        self.deleted = []

    def delete_partition(self, device):
        self.deleted.append(device)
        return {"success": True, "message": "ok"}


def test_delete_partition_validates_before_unmount(monkeypatch):
    """If the partition is in use, nothing must be touched."""

    monkeypatch.setattr(
        "backend.shares.services.disk_guard.ensure_not_system_disk",
        lambda device, action: None,
    )

    service = make_service(FakeBackup([], set()))
    service._os_disk_names = lambda: set()
    service._parent_disk_name = lambda device: "sdb"
    service.list_units = lambda: [
        {
            "device": "/dev/sdb1",
            "whole_disk": False,
            "deletable": True,
            "mountpoint": MP,
        }
    ]
    service._partition_in_use = lambda mountpoint: "el respaldo «X»"
    service.partition_service = PartitionService(
        list_units=service.list_units,
        os_disk_names=service._os_disk_names,
        parent_disk_name=service._parent_disk_name,
        in_use=service._partition_in_use,
        ensure_safe=lambda device, action: None,
    )
    disk_mount = FakeDiskMount()
    service.disk_mount = disk_mount

    with pytest.raises(HTTPException) as error:
        service.delete_partition(FakeDB(), "/dev/sdb1", confirm="ELIMINAR")

    assert error.value.status_code == 400
    assert disk_mount.deleted == []

def test_delete_partition_never_touches_provider_for_system_disk():
    """Invariant: the OS disk is never touched, not even the provider."""

    def guard(device, action):
        raise HTTPException(400, "es el disco del sistema")

    service = make_service(FakeBackup([], set()))
    service._os_disk_names = lambda: set()
    service._parent_disk_name = lambda device: "sda"
    service.list_units = lambda: [
        {
            "device": "/dev/sda2",
            "whole_disk": False,
            "deletable": True,
            "mountpoint": "/",
        }
    ]
    service.partition_service = PartitionService(
        list_units=service.list_units,
        os_disk_names=service._os_disk_names,
        parent_disk_name=service._parent_disk_name,
        in_use=lambda mountpoint: None,
        ensure_safe=guard,
    )
    disk_mount = FakeDiskMount()
    service.disk_mount = disk_mount

    with pytest.raises(HTTPException) as error:
        service.delete_partition(FakeDB(), "/dev/sda2", confirm="ELIMINAR")

    assert error.value.status_code == 400
    assert disk_mount.deleted == []
