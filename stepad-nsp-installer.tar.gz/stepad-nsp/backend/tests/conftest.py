import os


# Debe ejecutarse al importar conftest (antes de que los módulos de test
# importen backend): Settings evalúa los secretos en tiempo de import y
# ahora falla cerrado salvo que STEPAD_ENV=development sea explícito.
os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")
