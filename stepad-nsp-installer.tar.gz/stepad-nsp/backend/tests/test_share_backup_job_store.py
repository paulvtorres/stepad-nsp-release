from pathlib import Path

from backend.shares.services.share_backup_job_store import BackupJobStore


class Job(dict):
    def __init__(self, data, vault=None):
        super().__init__(data)
        self.vault = vault


def build(configs, *, vaults=None, legacy=0, dir_live=None):
    data = {str(k): v for k, v in configs.items()}

    store = BackupJobStore(
        load_config=lambda vault: {
            "schema": 1,
            "next_job_id": len(data[str(vault)]) + 1,
            "jobs": data[str(vault)],
        },
        save_config=lambda vault, config: data.__setitem__(
            str(vault), config["jobs"]
        ),
        all_jobs=lambda: [
            Job(record, vault=Path(vault))
            for vault, records in data.items()
            for record in records
        ],
        vaults=lambda: vaults or [Path(v) for v in data],
        dir_live=dir_live or (lambda path: True),
        legacy_max_id=lambda: legacy,
        backup_subdir=".backups",
    )
    return store, data


def test_find_job_and_vault(tmp_path):
    vault_a = tmp_path / "a"
    vault_b = tmp_path / "b"
    store, _ = build(
        {
            vault_a: [{"id": 1, "name": "A"}],
            vault_b: [{"id": 2, "name": "B"}],
        }
    )

    assert store.find_job(1)["name"] == "A"
    assert store.find_job(3) is None
    assert store.find_job(1, vault=vault_b) is None
    assert store.find_job(2, vault=vault_b)["name"] == "B"


def test_global_max_includes_legacy_and_vaults(tmp_path):
    store, _ = build(
        {tmp_path: [{"id": 4}, {"id": 7}]},
        legacy=9,
    )
    assert store.global_max_job_id() == 9

    store, _ = build({tmp_path: [{"id": 4}, {"id": 7}]}, legacy=2)
    assert store.global_max_job_id() == 7


def test_save_job_replaces_record(tmp_path):
    vault = tmp_path / "a"
    store, data = build({vault: [{"id": 1, "name": "old"}]})

    store.save_job_locked(Job({"id": 1, "name": "new"}, vault=vault))

    assert data[str(vault)][0]["name"] == "new"


def test_unique_ids_renumber_and_rename_repo(tmp_path):
    vault_a = tmp_path / "a"
    vault_b = tmp_path / "b"
    (vault_b / ".backups" / "job-1").mkdir(parents=True)

    store, data = build(
        {
            vault_a: [{"id": 1, "name": "A"}],
            vault_b: [{"id": 1, "name": "B"}],
        }
    )

    store.ensure_unique_job_ids()

    assert data[str(vault_a)][0]["id"] == 1
    assert data[str(vault_b)][0]["id"] == 2
    assert not (vault_b / ".backups" / "job-1").exists()
    assert (vault_b / ".backups" / "job-2").exists()
