from backend.api.v1.routes.observability import is_private_client


def test_private_clients_allowed():

    for host in ("127.0.0.1", "192.168.1.10", "10.200.0.1", "100.97.46.90", "::1"):

        assert is_private_client(host) is True


def test_public_clients_rejected():

    for host in ("8.8.8.8", "203.0.113.10", "example.com", ""):

        assert is_private_client(host) is False
