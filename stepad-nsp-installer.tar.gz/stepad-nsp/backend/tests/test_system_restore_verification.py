import json
import os
import stat
from datetime import datetime, timedelta

from backend.backups.services import system_restore_verification_service as check
from backend.backups.services.system_backup_service import SystemBackupService


def test_should_run_uses_state(tmp_path):
    service = check.SystemRestoreVerificationService(str(tmp_path / "s.json"))

    assert service.should_run() is True

    service._save({"last_run_at": datetime.utcnow().isoformat()})
    assert service.should_run() is False

    service._save(
        {"last_run_at": (datetime.utcnow() - timedelta(days=40)).isoformat()}
    )
    assert service.should_run() is True


def test_run_skips_without_destination(tmp_path, monkeypatch):
    monkeypatch.setattr(SystemBackupService, "_get_repo_path", lambda self: None)

    path = tmp_path / "s.json"
    service = check.SystemRestoreVerificationService(str(path))

    result = service.run(alert=False)

    assert result["skipped"] is True
    assert result["success"] is False
    assert service.status()["skipped"] is True
    assert stat.S_IMODE(os.stat(path).st_mode) == 0o600
