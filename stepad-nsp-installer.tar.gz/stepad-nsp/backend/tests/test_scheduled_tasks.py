from datetime import datetime, timedelta

from backend.maintenance.services.scheduled_tasks_service import (
    next_daily,
    task_state,
)


def test_next_daily_today_or_tomorrow():

    now = datetime(2026, 10, 30, 9, 0)

    assert next_daily(now, 3, 30) == datetime(2026, 10, 31, 3, 30)

    assert next_daily(now, 18, 0) == datetime(2026, 10, 30, 18, 0)


def test_state_disabled_and_never():

    now = datetime(2026, 10, 30, 9, 0)

    assert task_state(False, datetime(2026, 10, 30, 3, 0), None, now) == "disabled"

    assert task_state(True, None, None, now) == "never"


def test_state_overdue_with_grace():

    now = datetime(2026, 10, 30, 9, 0)

    last = datetime(2026, 10, 30, 3, 0)

    assert task_state(True, last, now - timedelta(hours=1), now) == "ok"

    assert task_state(True, last, now - timedelta(hours=3), now) == "overdue"


def test_state_ok():

    now = datetime(2026, 10, 30, 9, 0)

    last = datetime(2026, 10, 30, 8, 0)

    assert task_state(True, last, now + timedelta(hours=1), now) == "ok"
