from datetime import datetime, timedelta

from backend.shares.services import share_absent_state as state


NOW = datetime(2026, 9, 16, 12, 0)


def test_volume_key_prefers_uuid():
    assert state.volume_key({"device_uuid": "U", "device_path": "/dev/sdb1"}) == "uuid:U"
    assert state.volume_key({"device_uuid": "", "device_path": "/dev/sdb1"}) == "dev:/dev/sdb1"


def test_new_orphan_is_stamped_not_expired():
    new, expired = state.update_state({}, {"uuid:A"}, {"uuid:A"}, NOW, 30)
    assert new["uuid:A"] == NOW.isoformat()
    assert expired == []


def test_absent_long_enough_expires():
    old = (NOW - timedelta(days=31)).isoformat()
    new, expired = state.update_state(
        {"uuid:A": old}, {"uuid:A"}, {"uuid:A"}, NOW, 30
    )
    assert expired == ["uuid:A"]
    assert new["uuid:A"] == old


def test_present_or_gone_resets_state():
    old = (NOW - timedelta(days=40)).isoformat()
    new, expired = state.update_state(
        {"uuid:A": old, "uuid:B": old},
        {"uuid:B"},
        {"uuid:A", "uuid:B"},
        NOW,
        30,
    )
    assert "uuid:A" not in new
    assert new["uuid:B"] == old
    assert expired == ["uuid:B"]

    new, expired = state.update_state(
        {"uuid:A": old}, {"uuid:A"}, set(), NOW, 30
    )
    assert new == {}
    assert expired == []


def test_grace_zero_disables_expiry():
    old = (NOW - timedelta(days=999)).isoformat()
    _, expired = state.update_state(
        {"uuid:A": old}, {"uuid:A"}, {"uuid:A"}, NOW, 0
    )
    assert expired == []
