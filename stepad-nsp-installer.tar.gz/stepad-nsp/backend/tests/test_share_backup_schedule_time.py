from datetime import datetime

from backend.shares.services import share_backup_schedule_time as st


def test_times_list_from_string():

    job = {"schedule_times": "03:00, 20:00", "schedule_hour": 1}

    assert st.times_list(job) == ["03:00", "20:00"]


def test_times_list_fallback_hour_minute():

    job = {"schedule_times": "", "schedule_hour": 3, "schedule_minute": 5}

    assert st.times_list(job) == ["03:05"]


def test_parse_job_time_accepts_z():

    parsed = st.parse_job_time("2026-01-01T10:00:00Z")

    assert parsed == datetime(2026, 1, 1, 10, 0, 0)


def test_parse_job_time_invalid():

    assert st.parse_job_time("nope") is None

    assert st.parse_job_time(None) is None


def test_backoff_minutes():

    table = [5, 15, 30, 60]

    assert st.backoff_minutes(0, table) == 0

    assert st.backoff_minutes(1, table) == 5

    assert st.backoff_minutes(3, table) == 30

    assert st.backoff_minutes(9, table) == 60


def test_backoff_elapsed():

    table = [5, 15, 30, 60]

    job = {"consecutive_failures": 1, "last_attempt_at": "2026-01-01T10:00:00"}

    assert st.backoff_elapsed(job, datetime(2026, 1, 1, 10, 4), table) is False

    assert st.backoff_elapsed(job, datetime(2026, 1, 1, 10, 5), table) is True


def test_daily_window():

    table = [5, 15, 30, 60]

    job = {
        "enabled": True,
        "schedule_mode": "daily",
        "schedule_times": "03:00",
        "last_backup_at": "2026-01-01T03:01:00",
    }

    assert st.is_due(job, datetime(2026, 1, 1, 3, 10), 30, table) is False

    assert st.is_due(job, datetime(2026, 1, 2, 3, 0), 30, table) is True


def test_interval_and_on_change():

    table = [5, 15, 30, 60]

    interval = {
        "enabled": True,
        "schedule_mode": "interval",
        "interval_minutes": 60,
        "last_backup_at": "2026-01-01T10:00:00",
    }

    assert st.is_due(interval, datetime(2026, 1, 1, 10, 59), 30, table) is False

    assert st.is_due(interval, datetime(2026, 1, 1, 11, 0), 30, table) is True

    assert st.is_due(
        {"enabled": True, "schedule_mode": "on_change"},
        datetime(2026, 1, 1, 11, 0),
        30,
        table,
    ) is False
