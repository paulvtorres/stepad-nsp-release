from backend.shares.services import share_backup_run_state as state


NOW = "2026-09-16T12:00:00"


def test_history_entry_and_limit():
    entry = state.history_entry(
        success=True,
        message="ok",
        now_iso=NOW,
        bytes_added=10,
        duration_seconds=1.234,
        trigger="manual",
        snapshot_id="a" * 80,
    )
    assert entry["duration_seconds"] == 1.2
    assert entry["trigger"] == "manual"
    assert len(entry["snapshot_id"]) == 64

    job = {"history": [{"at": str(i)} for i in range(30)]}
    state.append_history(job, entry, 30)
    assert len(job["history"]) == 30
    assert job["history"][-1]["message"] == "ok"


def test_success_resets_failures_and_reports_recovery():
    job = {
        "consecutive_failures": 4,
        "failure_alert_active": True,
        "overdue_alerted": True,
        "last_bytes": 1,
    }
    flags = state.apply_result(
        job,
        success=True,
        message="ok",
        now_iso=NOW,
        snapshot_id="snap1",
        bytes_added=99,
    )

    assert flags == {"recovered": True, "alert": False}
    assert job["consecutive_failures"] == 0
    assert job["failure_alert_active"] is False
    assert job["overdue_alerted"] is False
    assert job["last_bytes"] == 99
    assert job["last_backup_at"] == NOW
    assert job["last_snapshot_id"] == "snap1"


def test_failure_counts_and_alerts_once():
    job = {}
    for expected in (1, 2):
        flags = state.apply_result(
            job,
            success=False,
            message="boom",
            now_iso=NOW,
            failure_threshold=3,
        )
        assert flags["alert"] is False
        assert job["consecutive_failures"] == expected

    flags = state.apply_result(
        job,
        success=False,
        message="boom",
        now_iso=NOW,
        failure_threshold=3,
    )
    assert flags["alert"] is True
    assert job["failure_alert_active"] is True

    flags = state.apply_result(
        job,
        success=False,
        message="boom",
        now_iso=NOW,
        failure_threshold=3,
    )
    assert flags["alert"] is False


def test_failure_does_not_advance_backup_time_by_default():
    job = {"last_backup_at": "older"}
    state.apply_result(
        job,
        success=False,
        message="x",
        now_iso=NOW,
        update_backup_time=False,
    )
    assert job["last_backup_at"] == "older"
    assert job["last_attempt_at"] == NOW


def test_unreadable_is_stored_and_cleared():
    job = {}

    state.apply_result(
        job,
        success=True,
        message="ok",
        now_iso=NOW,
        unreadable_count=3,
        unreadable_samples=["/a", "/b"],
    )
    assert job["last_unreadable"]["count"] == 3
    assert job["last_unreadable"]["samples"] == ["/a", "/b"]

    state.apply_result(job, success=True, message="ok", now_iso=NOW)
    assert "last_unreadable" not in job
