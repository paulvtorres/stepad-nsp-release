from datetime import datetime

from backend.shares.services import share_backup_overdue as overdue


def parse(value):
    if not value:
        return None
    return datetime.fromisoformat(value)


def job(**extra):
    base = {
        "enabled": True,
        "schedule_mode": "daily",
        "schedule_times": "08:00",
        "last_backup_at": "2026-09-15T08:01:00",
        "interval_minutes": 60,
    }
    base.update(extra)
    return base


def times(value):
    return value["schedule_times"].split(",")


def never_due(value, now):
    return False


NOW = datetime(2026, 9, 16, 10, 0)


def is_overdue(value, due=never_due):
    return overdue.backup_is_overdue(
        value,
        NOW,
        times_list=times,
        parse_time=parse,
        grace_minutes=15,
        due=due,
    )


def test_daily_missed_yesterday():
    assert is_overdue(job(last_backup_at="2026-09-15T08:01:00")) is True


def test_daily_ran_today_after_slot():
    assert is_overdue(job(last_backup_at="2026-09-16T08:05:00")) is False


def test_daily_still_inside_window_is_not_overdue():
    def due(value, now):
        return True

    assert is_overdue(job(last_backup_at=None), due=due) is False


def test_daily_never_backed_up_after_grace():
    assert is_overdue(job(last_backup_at=None)) is True
    now = datetime(2026, 9, 16, 7, 0)
    value = job(last_backup_at=None)
    assert (
        overdue.backup_is_overdue(
            value,
            now,
            times_list=times,
            parse_time=parse,
            grace_minutes=15,
            due=never_due,
        )
        is False
    )


def test_interval_misses_two_periods():
    assert (
        is_overdue(
            job(
                schedule_mode="interval",
                interval_minutes=60,
                last_backup_at="2026-09-16T07:00:00",
            )
        )
        is True
    )
    assert (
        is_overdue(
            job(
                schedule_mode="interval",
                interval_minutes=120,
                last_backup_at="2026-09-16T08:00:00",
            )
        )
        is False
    )


def test_disabled_and_on_change_never_overdue():
    assert is_overdue(job(enabled=False)) is False
    assert is_overdue(job(schedule_mode="on_change")) is False


def test_maintenance_due():
    now = datetime(2026, 9, 16, 12, 0)

    assert overdue.maintenance_due({}, "check", now, parse) is False

    value = {
        "check_enabled": True,
        "check_interval_days": 7,
        "last_check_at": "2026-09-09T12:00:00",
        "last_snapshot_id": "abc",
    }
    assert overdue.maintenance_due(value, "check", now, parse) is True

    value["last_check_at"] = "2026-09-15T12:00:00"
    assert overdue.maintenance_due(value, "check", now, parse) is False

    value["last_check_at"] = None
    assert overdue.maintenance_due(value, "check", now, parse) is True

    value["last_snapshot_id"] = None
    assert overdue.maintenance_due(value, "check", now, parse) is False

    restore = {
        "test_restore_enabled": True,
        "test_restore_scratch": "",
        "test_restore_interval_days": 1,
    }
    assert overdue.maintenance_due(restore, "test_restore", now, parse) is False

    restore["test_restore_scratch"] = "/var/tmp/x"
    restore["last_test_restore_at"] = "2026-09-14T12:00:00"
    assert overdue.maintenance_due(restore, "test_restore", now, parse) is True
