from types import SimpleNamespace

from backend.shares.services.network_share_service import NetworkShareService


class FakeMount:
    def __init__(self):
        self.calls = []

    def is_mounted_at(self, mountpoint):
        return True

    def unmount_now(self, mountpoint):
        self.calls.append("unmount")
        return {"success": True}

    def mount_now(self, **kwargs):
        self.calls.append("mount")
        return {"success": True}

    def partition_info(self, device):
        return {
            "success": True,
            "size_bytes": 100 * 1024**3,
            "mounted": False,
            "fstype": "ext4",
        }

    def resize_partition(self, device, **kwargs):
        self.calls.append("resize")
        return {"success": True, "message": "ok", "new_size_gb": 200}


class FakeQuery:
    def __init__(self, volume):
        self.volume = volume

    def filter(self, *args, **kwargs):
        return self

    def first(self):
        return self.volume


class FakeDB:
    def __init__(self, volume):
        self.volume = volume
        self.commits = 0

    def query(self, *args, **kwargs):
        return FakeQuery(self.volume)

    def commit(self):
        self.commits += 1


VOLUME = SimpleNamespace(
    id=1,
    mountpoint="/mnt/stepad-share/sdb1",
    purpose="backup",
    sharing=False,
    device_uuid="UUID-1",
    device_path="/dev/sdb1",
    updated_at=None,
)


def test_resize_unmounts_resizes_and_remounts(monkeypatch):
    monkeypatch.setattr(
        "backend.shares.services.disk_guard.ensure_not_system_disk",
        lambda device, action: None,
    )
    service = object.__new__(NetworkShareService)
    mount = FakeMount()
    service.disk_mount = mount
    service._os_disk_names = lambda: set()
    service._parent_disk_name = lambda device: "sdb"
    service.get_status = lambda db: {}

    result = service.resize_partition(
        FakeDB(VOLUME), "sdb1", new_size_gb=None, confirm="ELIMINAR"
    )

    assert result["message"] == "ok"
    assert mount.calls == ["unmount", "resize", "mount"]


def test_resize_keeps_shared_mounted(monkeypatch):
    monkeypatch.setattr(
        "backend.shares.services.disk_guard.ensure_not_system_disk",
        lambda device, action: None,
    )
    shared = SimpleNamespace(**{**VOLUME.__dict__, "sharing": True, "purpose": "shared"})
    service = object.__new__(NetworkShareService)
    mount = FakeMount()
    service.disk_mount = mount
    service._os_disk_names = lambda: set()
    service._parent_disk_name = lambda device: "sdb"
    service.get_status = lambda db: {}

    service.resize_partition(
        FakeDB(shared), "sdb1", new_size_gb=None, confirm="ELIMINAR"
    )

    assert mount.calls == ["resize"]
