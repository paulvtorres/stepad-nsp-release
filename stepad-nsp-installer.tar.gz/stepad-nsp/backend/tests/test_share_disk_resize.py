import subprocess

from backend.shares.providers.share_disk_mount_provider import (
    ShareDiskMountProvider,
)

PARTED = """BYT;
/dev/sdb:1000204886016B:scsi:512:4096:msdos:ATA:;
1:1048576B:730145488895B:730144440320B:ext4::;
1:730145488896B:1000204886015B:270059397120B:free;
"""


def completed(cmd, code=0, out="", err=""):
    return subprocess.CompletedProcess(cmd, code, out, err)


def provider_with(run):
    service = object.__new__(ShareDiskMountProvider)
    service._run = run
    return service


def test_free_after_returns_absolute_end():
    service = provider_with(lambda cmd, **kw: completed(cmd, out=PARTED))

    end = service._latest_free_after("/dev/sdb", 730145488896)

    assert end == 1000204886015  # end, NOT the 270059397120 size


def test_free_after_ignores_non_contiguous():
    service = provider_with(
        lambda cmd, **kw: completed(cmd, out=PARTED)
    )

    assert service._latest_free_after("/dev/sdb", 1) is None


def test_grow_uses_free_end(monkeypatch):
    service = provider_with(lambda cmd, **kw: completed(cmd))
    service.partition_info = lambda device: {
        "success": True,
        "disk": "/dev/sdb",
        "part_num": 1,
        "start_bytes": 1048576,
        "size_bytes": 730144440320,
        "fstype": "ext4",
        "mounted": True,
        "mountpoint": "/mnt/stepad-share/sdb1",
    }
    service._latest_free_after = lambda disk, start: 1000204886015
    seen = []
    service._parted_resizepart = lambda disk, num, end: (
        seen.append(end) or {"success": True}
    )
    service._refresh_partitions = lambda disk: None

    monkeypatch.setattr(
        "backend.shares.services.disk_guard.ensure_not_system_disk",
        lambda device, action: None,
    )

    result = service.resize_partition("/dev/sdb1")

    assert result["success"] is True
    assert seen == [1000204886015]
    assert result["new_size_gb"] == round(
        (1000204886015 - 1048576 + 1) / 1024**3, 2
    )


def test_grow_is_noop_without_free_region(monkeypatch):
    service = provider_with(lambda cmd, **kw: completed(cmd))
    service.partition_info = lambda device: {
        "success": True,
        "disk": "/dev/sdb",
        "part_num": 1,
        "start_bytes": 1048576,
        "size_bytes": 730144440320,
        "fstype": "ext4",
        "mounted": True,
        "mountpoint": "/mnt/x",
    }
    service._latest_free_after = lambda disk, start: None

    monkeypatch.setattr(
        "backend.shares.services.disk_guard.ensure_not_system_disk",
        lambda device, action: None,
    )

    result = service.resize_partition("/dev/sdb1")

    assert result["success"] is True
    assert result["resized"] is False
