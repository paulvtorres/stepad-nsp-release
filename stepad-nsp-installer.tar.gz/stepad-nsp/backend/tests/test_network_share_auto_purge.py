import json

from backend.shares.services import network_share_service as mod
from backend.shares.services.network_share_service import NetworkShareService


def make_service(purge):
    service = object.__new__(NetworkShareService)
    service.purge_orphan_volume = purge
    return service


def orphan(volume_id=1, name="viejo", uuid="A"):
    return {
        "id": volume_id,
        "name": name,
        "device_uuid": uuid,
        "device_path": "/dev/sdb1",
    }


def test_fresh_orphan_is_not_purged(tmp_path, monkeypatch):
    path = tmp_path / "absent.json"
    monkeypatch.setattr(mod, "ABSENT_VOLUMES_PATH", path)
    monkeypatch.setenv("STEPAD_STALE_VOLUME_DAYS", "30")
    called = []
    service = make_service(lambda db, volume_id: called.append(volume_id))

    result = service._auto_purge_orphans(
        object(), [orphan()], [orphan()]
    )

    assert result == []
    assert called == []
    saved = json.loads(path.read_text())
    assert "uuid:A" in saved


def test_old_orphan_is_purged_and_state_cleared(tmp_path, monkeypatch):
    path = tmp_path / "absent.json"
    path.write_text(json.dumps({"uuid:A": "2026-01-01T00:00:00"}))
    monkeypatch.setattr(mod, "ABSENT_VOLUMES_PATH", path)
    monkeypatch.setenv("STEPAD_STALE_VOLUME_DAYS", "30")
    called = []
    service = make_service(lambda db, volume_id: called.append(volume_id))

    result = service._auto_purge_orphans(object(), [orphan()], [orphan()])

    assert called == [1]
    assert result == [{"id": 1, "name": "viejo"}]
    assert "uuid:A" not in json.loads(path.read_text())


def test_present_volume_resets_counter(tmp_path, monkeypatch):
    path = tmp_path / "absent.json"
    path.write_text(json.dumps({"uuid:A": "2026-01-01T00:00:00"}))
    monkeypatch.setattr(mod, "ABSENT_VOLUMES_PATH", path)
    monkeypatch.setenv("STEPAD_STALE_VOLUME_DAYS", "30")
    service = make_service(lambda db, volume_id: None)

    service._auto_purge_orphans(object(), [], [orphan()])

    assert "uuid:A" not in json.loads(path.read_text())


def test_purge_disabled_by_env(tmp_path, monkeypatch):
    path = tmp_path / "absent.json"
    monkeypatch.setattr(mod, "ABSENT_VOLUMES_PATH", path)
    monkeypatch.setenv("STEPAD_STALE_VOLUME_DAYS", "0")
    called = []
    service = make_service(lambda db, volume_id: called.append(volume_id))

    result = service._auto_purge_orphans(object(), [orphan()], [orphan()])

    assert result == []
    assert called == []
    assert not path.exists()
