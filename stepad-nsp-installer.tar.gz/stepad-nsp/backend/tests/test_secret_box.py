
from backend.shared.security import secret_box


def test_roundtrip_with_key(monkeypatch):

    monkeypatch.setenv("STEPAD_BACKUP_KEY", "clave-de-prueba")

    encrypted = secret_box.encrypt("mi-clave-smtp")

    assert encrypted.startswith("enc:v1:")

    assert secret_box.is_encrypted(encrypted)

    assert secret_box.decrypt(encrypted) == "mi-clave-smtp"


def test_encrypt_is_idempotent(monkeypatch):

    monkeypatch.setenv("STEPAD_BACKUP_KEY", "k")

    once = secret_box.encrypt("x")

    assert secret_box.encrypt(once) == once


def test_plaintext_passthrough(monkeypatch):

    monkeypatch.setenv("STEPAD_BACKUP_KEY", "k")

    assert secret_box.decrypt("texto-en-claro") == "texto-en-claro"

    assert secret_box.encrypt("") == ""


def test_no_key_keeps_plaintext(monkeypatch):

    monkeypatch.delenv("STEPAD_BACKUP_KEY", raising=False)

    monkeypatch.setattr(secret_box, "_key", lambda: "")

    assert secret_box.encrypt("x") == "x"
