"""Dominio de presencia: tabla de casos reales (sin BD ni red)."""

from datetime import datetime, timedelta

import pytest

from backend.network.devices.domain.presence import (
    ARP_REACHABLE,
    ARP_STALE,
    DNS,
    OFFLINE,
    ONLINE,
    PROBABLE,
    UNKNOWN,
    Evidence,
    derive_presence,
    find_ip_conflicts,
    parse_neigh,
)

NOW = datetime(2026, 11, 13, 12, 0, 0)


def ev(source, ip, minutes_ago):

    return Evidence(source, ip, NOW - timedelta(minutes=minutes_ago))


@pytest.mark.parametrize(
    "evidence, ever_seen, status, ip, source",
    [
        # Sin evidencia: un lease NO cuenta (ni siquiera se le pasa).
        ([], True, OFFLINE, "", None),
        ([], False, UNKNOWN, "", None),
        # ARP alcanzable reciente = ONLINE.
        ([ev(ARP_REACHABLE, "192.168.1.30", 0)], True, ONLINE, "192.168.1.30", ARP_REACHABLE),
        # Envejece solo: 10 min -> PROBABLE, 31 min -> OFFLINE.
        ([ev(ARP_REACHABLE, "192.168.1.30", 10)], True, PROBABLE, "192.168.1.30", ARP_REACHABLE),
        ([ev(ARP_REACHABLE, "192.168.1.30", 31)], True, OFFLINE, "", None),
        # ARP STALE nunca da ONLINE, aunque sea reciente.
        ([ev(ARP_STALE, "192.168.1.30", 1)], True, PROBABLE, "192.168.1.30", ARP_STALE),
        # ...y tampoco sostiene PROBABLE para siempre.
        ([ev(ARP_STALE, "192.168.1.30", 45)], True, OFFLINE, "", None),
        # DNS reciente = ONLINE (celular en ahorro de energia).
        ([ev(DNS, "192.168.1.31", 2)], True, ONLINE, "192.168.1.31", DNS),
        ([ev(DNS, "192.168.1.31", 12)], True, PROBABLE, "192.168.1.31", DNS),
        # IP vieja STALE + IP nueva REACHABLE: gana la nueva, no la ultima linea.
        (
            [ev(ARP_REACHABLE, "192.168.1.41", 0), ev(ARP_STALE, "192.168.1.40", 0)],
            True,
            ONLINE,
            "192.168.1.41",
            ARP_REACHABLE,
        ),
        # ARP (con MAC) pesa mas que DNS (solo IP) si ambos son frescos.
        (
            [ev(DNS, "192.168.1.50", 0), ev(ARP_REACHABLE, "192.168.1.51", 1)],
            True,
            ONLINE,
            "192.168.1.51",
            ARP_REACHABLE,
        ),
    ],
)
def test_derive_presence(evidence, ever_seen, status, ip, source):

    result = derive_presence(evidence, NOW, ever_seen=ever_seen)

    assert (result.status, result.current_ip, result.source) == (status, ip, source)


def test_evidencia_del_futuro_no_rompe_el_estado():

    future = Evidence(ARP_REACHABLE, "192.168.1.30", NOW + timedelta(hours=3))

    assert derive_presence([future], NOW).status == ONLINE


def test_evidence_at_es_la_hora_de_la_evidencia_no_la_de_la_corrida():

    result = derive_presence([ev(ARP_REACHABLE, "192.168.1.30", 12)], NOW)

    assert result.status == PROBABLE

    assert result.evidence_at == NOW - timedelta(minutes=12)


NEIGH = """\
192.168.1.31 dev enp3s0 lladdr aa:00:00:00:00:02 REACHABLE
192.168.1.40 dev enp3s0 lladdr AA:00:00:00:00:03 STALE
fe80::1234 dev enp3s0 lladdr aa:00:00:00:00:03 STALE
192.168.1.99 dev enp3s0  FAILED
192.168.1.98 dev enp3s0 lladdr aa:00:00:00:00:09 INCOMPLETE
192.168.1.1 dev wan0 lladdr aa:00:00:00:00:0a REACHABLE
"""


def test_parse_neigh_solo_ipv4_vivo_y_en_lan():

    entries = parse_neigh(NEIGH, accept_iface=lambda iface: iface != "wan0")

    assert [(e.ip, e.mac, e.state) for e in entries] == [
        ("192.168.1.31", "aa:00:00:00:00:02", "REACHABLE"),
        ("192.168.1.40", "aa:00:00:00:00:03", "STALE"),
    ]

    assert entries[0].reachable and not entries[1].reachable


def test_parse_neigh_sin_filtro_incluye_todas_las_interfaces_ipv4():

    assert len(parse_neigh(NEIGH)) == 3


def test_conflicto_solo_si_la_mac_observada_difiere_del_lease():

    assigned = {"192.168.1.30": "aa:01", "192.168.1.31": "aa:02"}

    observed = {"192.168.1.30": "bb:99", "192.168.1.31": "aa:02", "192.168.1.77": "cc:01"}

    assert find_ip_conflicts(assigned, observed) == {
        "192.168.1.30": ("bb:99", "aa:01")
    }
