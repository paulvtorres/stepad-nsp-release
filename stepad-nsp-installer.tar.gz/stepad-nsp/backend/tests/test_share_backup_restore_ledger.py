import os

from pathlib import Path

from backend.shares.services import share_backup_restore_ledger as ledger


def test_load_missing_devuelve_vacio(tmp_path):

    data = ledger.load(tmp_path / "nope.json")

    assert data == {"schema": 1, "restores": {}}


def test_upsert_crea_y_actualiza(tmp_path):

    path = tmp_path / "restore_state.json"

    ledger.upsert(path, 5, "2026-01-01T00:00:00", status="running")

    entry = ledger.load(path)["restores"]["5"]

    assert entry["status"] == "running"

    assert entry["job_id"] == 5

    ledger.upsert(path, 5, "2026-01-01T01:00:00", status="done")

    entry = ledger.load(path)["restores"]["5"]

    assert entry["status"] == "done"

    assert entry["updated_at"] == "2026-01-01T01:00:00"

    mode = path.stat().st_mode & 0o777

    assert mode == 0o600


def test_json_corrupto_no_rompe(tmp_path):

    path = tmp_path / "restore_state.json"

    path.write_text("no-json", encoding="utf-8")

    assert ledger.load(path)["restores"] == {}


def test_process_alive(tmp_path):

    assert ledger.process_alive(os.getpid()) is True

    assert ledger.process_alive(999999999) is False

    assert ledger.process_alive("basura") is False
