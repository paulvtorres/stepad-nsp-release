"""El sync de categorías no debe regenerar DNS una vez por dominio.

El feed de malware trae ~17.000 dominios: aplicar la regla una por una
(synchronize recarga la zona completa) es O(n^2) y dejaba el arranque
colgado durante horas, con la web sin responder.
"""

from backend.content.services.content_category_service import (
    ContentCategoryService,
)
from backend.content.models.content_category import ContentCategory
from backend.rules.models.device_access_rule import DeviceAccessRule


class _FakeQuery:

    def __init__(self, rows):
        self._rows = rows

    def all(self):
        return self._rows


class _FakeDb:

    def query(self, model):
        if model is ContentCategory:
            category = ContentCategory()
            category.key = "malware"
            category.enabled = True
            return _FakeQuery([category])
        raise AssertionError("query inesperada")


class _FakeRepository:

    def __init__(self):
        self.saved = []

    def find_global_domain(self, db, domain):
        return None

    def save(self, db, rule):
        self.saved.append(rule)
        return rule


class _FakeEngine:

    def __init__(self):
        self.applied = 0

    def apply(self, rule, db=None):
        self.applied += 1


def test_sync_inserta_todo_y_sincroniza_una_vez():

    service = ContentCategoryService.__new__(ContentCategoryService)

    service.repository = _FakeRepository()
    service.engine = _FakeEngine()

    domains = [f"dominio{i}.example" for i in range(50)]

    service._find_category_rules = lambda db, key: []
    service._domains = lambda db, category: domains

    sync_calls = []

    service._sync_domains = lambda db: sync_calls.append(1)

    result = service.sync(_FakeDb())

    assert result == {"success": True}
    assert len(service.repository.saved) == 50
    # Nada de engine.apply por dominio; una sola sincronización final.
    assert service.engine.applied == 0
    assert len(sync_calls) == 1

    rule = service.repository.saved[0]

    assert isinstance(rule, DeviceAccessRule)
    assert rule.source == "category"
    assert rule.source_ref == "malware"
    assert rule.scope == "GLOBAL"


def test_sync_sin_dominios_nuevos_no_sincroniza():

    service = ContentCategoryService.__new__(ContentCategoryService)

    service.repository = _FakeRepository()
    service.engine = _FakeEngine()

    service._find_category_rules = lambda db, key: []
    service._domains = lambda db, category: []

    sync_calls = []

    service._sync_domains = lambda db: sync_calls.append(1)

    service.sync(_FakeDb())

    assert service.repository.saved == []
    assert sync_calls == []
