from datetime import datetime

from backend.audit.services import audit_chain


def entry(prev, action, description="d", user_id=1):
    created = datetime(2026, 9, 16, 12, 0, 0, 123456)
    return {
        "id": 1,
        "user_id": user_id,
        "action": action,
        "resource": "r",
        "description": description,
        "created_at": created,
        "prev_hash": prev,
        "entry_hash": audit_chain.hash_entry(
            prev, user_id, action, "r", description, created
        ),
    }


def test_chain_verifies():
    first = entry("", "LOGIN")
    second = entry(first["entry_hash"], "LOGOUT")

    result = audit_chain.verify_rows([first, second])

    assert result["ok"] is True
    assert result["checked"] == 2
    assert result["last_hash"] == second["entry_hash"]


def test_tampering_breaks_at_that_row():
    first = entry("", "LOGIN")
    second = entry(first["entry_hash"], "LOGOUT")
    second["description"] = "alterado"

    result = audit_chain.verify_rows([first, second])

    assert result["ok"] is False
    assert result["checked"] == 1
    assert result["broken_at"] == second["id"]


def test_deleted_or_reordered_row_breaks_chain():
    first = entry("", "LOGIN")
    third = entry(first["entry_hash"], "EXPORT")

    result = audit_chain.verify_rows([first, third])

    # The third was hashed after `first`, so it still verifies; simulate a
    # gap by re-linking it to an unknown previous hash.
    third["prev_hash"] = "deadbeef"
    third["entry_hash"] = audit_chain.hash_entry(
        "deadbeef",
        third["user_id"],
        third["action"],
        third["resource"],
        third["description"],
        third["created_at"],
    )
    result = audit_chain.verify_rows([first, third])
    assert result["ok"] is False
