from backend.network.devices.services.device_discovery_service import (
    should_clear_hostname,
)


def test_name_confirmed_elsewhere_is_cleared():

    assert should_clear_hostname(
        "ONLINE", "", "", "PIZZERIA", False,
        confirmed_elsewhere=True,
    ) is True


def test_unique_stale_name_is_kept():

    # Sin lease ni resolucion, pero nadie mas confirma el nombre: se
    # conserva (no se pierde informacion unica).
    assert should_clear_hostname(
        "ONLINE", "", "", "Redmi-10C", False,
        confirmed_elsewhere=False,
    ) is False


def test_lease_confirms_own_name():

    assert should_clear_hostname(
        "ONLINE", "PIZZERIA", "", "PIZZERIA", False,
        confirmed_elsewhere=True,
    ) is False


def test_offline_keeps_history():

    assert should_clear_hostname(
        "OFFLINE", "", "", "PIZZERIA", False,
        confirmed_elsewhere=True,
    ) is False


def test_manual_name_and_infra_are_preserved():

    assert should_clear_hostname(
        "ONLINE", "", "Impresora RRHH", "viejo", False,
        confirmed_elsewhere=True,
    ) is False

    assert should_clear_hostname(
        "ONLINE", "", "", "viejo", True,
        confirmed_elsewhere=True,
    ) is False


def test_without_name_nothing_to_do():

    assert should_clear_hostname(
        "ONLINE", "", "", "", False,
        confirmed_elsewhere=True,
    ) is False
