"""Tests del auto-diagnostico de arranque y de puertos.

Cubre los falsos positivos que se reportaban en cada reinicio:
- version de schema fija (0032) desactualizada,
- comando de nft invalido ("list chains inet stepad"),
- proceso de Suricata renombrado a "Suricata-Main",
- DNS/WireGuard (UDP) detectados solo por TCP.
"""

import sys
from unittest.mock import MagicMock, patch

from backend.core.health.boot_health_check import BootHealthCheck
from backend.core.health import ports_check

# El paquete backend.core.health expone una INSTANCIA llamada
# "boot_health_check" que sombrea el submodulo: se toma del registro de
# modulos para poder monkeypatchearlo.
boot_health_check = sys.modules["backend.core.health.boot_health_check"]


def _run_result(stdout="", returncode=0):

    result = MagicMock()
    result.returncode = returncode
    result.stdout = stdout
    result.stderr = ""

    return result


def test_expected_alembic_version_matches_repo():

    expected = boot_health_check._expected_alembic_version()

    versions = boot_health_check.Path(
        boot_health_check.__file__
    ).resolve().parents[2] / "migrations" / "versions"

    revisions = [
        path.name.split("_", 1)[0]
        for path in versions.glob("*.py")
        if path.name.split("_", 1)[0].isdigit()
    ]

    assert revisions
    assert expected == max(revisions)
    assert expected != "0032" or max(revisions) == "0032"


def test_nftables_check_uses_valid_command_and_accepts_chains():

    ruleset = (
        "table inet stepad {\n"
        "\tchain harden-forward {\n"
        "\t}\n"
        "\tchain harden-input {\n"
        "\t}\n"
        "\tchain attack-block {\n"
        "\t}\n"
        "\tchain c2-block {\n"
        "\t}\n"
        "}\n"
    )

    seen = []

    def _run(cmd, *args, **kwargs):

        seen.append(cmd)

        return _run_result(ruleset)

    check = BootHealthCheck()

    with patch.object(boot_health_check.subprocess, "run", side_effect=_run):

        check._check_nftables()

    assert seen[0][:3] == ["/usr/sbin/nft", "list", "table"]
    assert check._issues == []


def test_nftables_check_reports_missing_chain():

    ruleset = "table inet stepad {\n\tchain harden-forward {\n\t}\n}\n"

    def _run(cmd, *args, **kwargs):

        return _run_result(ruleset)

    check = BootHealthCheck()

    with patch.object(boot_health_check.subprocess, "run", side_effect=_run):

        check._check_nftables()

    assert len(check._issues) == 1
    assert check._issues[0]["check"] == "nftables"
    assert "harden-input" in check._issues[0]["title"]


def test_suricata_process_detected_by_command_line():

    check = BootHealthCheck()

    assert check._process_command("suricata")[:2] == ["pgrep", "-f"]
    assert check._process_command("postgres") == ["pgrep", "-x", "postgres"]


def test_suricata_pid_alive_treats_permission_error_as_alive():

    check = BootHealthCheck()

    with patch.object(
        boot_health_check.Path,
        "read_text",
        MagicMock(return_value="1234"),
    ), patch.object(
        boot_health_check.os,
        "kill",
        MagicMock(side_effect=PermissionError()),
    ):

        assert check._suricata_pid_alive() is True


def test_ports_check_accepts_udp_services():

    tcp_output = (
        "State  Recv-Q Send-Q Local Address:Port Peer Address:Port\n"
        "LISTEN 0      128    0.0.0.0:22     0.0.0.0:*\n"
        "LISTEN 0      128    0.0.0.0:8443   0.0.0.0:*\n"
    )

    udp_output = (
        "State  Recv-Q Send-Q Local Address:Port Peer Address:Port\n"
        "UNCONN 0      0      192.168.1.10:53  0.0.0.0:*\n"
        "UNCONN 0      0      0.0.0.0:51820    0.0.0.0:*\n"
    )

    def _run(cmd, *args, **kwargs):

        if "-uln" in cmd:

            return _run_result(udp_output)

        return _run_result(tcp_output)

    with patch.object(
        ports_check.subprocess, "run", side_effect=_run,
    ):

        issues = ports_check.check_ports()

    assert issues == []


def test_ports_check_reports_missing_https_port():

    tcp_output = (
        "State  Recv-Q Send-Q Local Address:Port Peer Address:Port\n"
        "LISTEN 0      128    0.0.0.0:22     0.0.0.0:*\n"
    )

    udp_output = (
        "State  Recv-Q Send-Q Local Address:Port Peer Address:Port\n"
        "UNCONN 0      0      0.0.0.0:53     0.0.0.0:*\n"
        "UNCONN 0      0      0.0.0.0:51820  0.0.0.0:*\n"
    )

    def _run(cmd, *args, **kwargs):

        if "-uln" in cmd:

            return _run_result(udp_output)

        return _run_result(tcp_output)

    with patch.object(
        ports_check.subprocess, "run", side_effect=_run,
    ):

        issues = ports_check.check_ports()

    assert len(issues) == 1
    assert "8443" in issues[0]["title"]


def test_ports_check_flags_forbidden_wildcard_port():

    tcp_output = (
        "State  Recv-Q Send-Q Local Address:Port Peer Address:Port\n"
        "LISTEN 0      128    0.0.0.0:22     0.0.0.0:*\n"
        "LISTEN 0      128    0.0.0.0:8443   0.0.0.0:*\n"
        "LISTEN 0      128    0.0.0.0:3306   0.0.0.0:*\n"
    )

    udp_output = (
        "State  Recv-Q Send-Q Local Address:Port Peer Address:Port\n"
        "UNCONN 0      0      0.0.0.0:53     0.0.0.0:*\n"
        "UNCONN 0      0      0.0.0.0:51820  0.0.0.0:*\n"
    )

    def _run(cmd, *args, **kwargs):

        if "-uln" in cmd:

            return _run_result(udp_output)

        return _run_result(tcp_output)

    with patch.object(
        ports_check.subprocess, "run", side_effect=_run,
    ):

        issues = ports_check.check_ports()

    forbidden = [i for i in issues if "3306" in i["title"]]

    assert len(forbidden) == 1
    assert forbidden[0]["severity"] == "critical"
