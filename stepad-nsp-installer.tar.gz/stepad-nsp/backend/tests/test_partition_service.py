from fastapi import HTTPException

from backend.shares.services.partition_service import PartitionService


def build(units, system=(), in_use=None):
    return PartitionService(
        list_units=lambda: units,
        os_disk_names=lambda: set(system),
        parent_disk_name=lambda device: "sdb",
        in_use=in_use or (lambda mountpoint: None),
        ensure_safe=lambda device, action: None,
    )


UNIT = {
    "device": "/dev/sdb1",
    "whole_disk": False,
    "deletable": True,
    "mountpoint": "/mnt/x",
}


def test_normalize():
    assert PartitionService.normalize("sdb1") == "/dev/sdb1"
    assert PartitionService.normalize("/dev/sdb1") == "/dev/sdb1"
    assert PartitionService.normalize("") == ""


def test_accepts_valid_partition():
    service = build([UNIT])
    device, unit, mountpoint = service.inspect("sdb1")
    assert device == "/dev/sdb1"
    assert unit["device"] == "/dev/sdb1"
    assert mountpoint == "/mnt/x"
    assert service.can_delete(device, unit=unit) == (True, "")


def test_rejects_invalid_device():
    assert build([]).can_delete("")[0] is False


def test_rejects_missing_or_whole_disk():
    assert build([]).can_delete("/dev/sdb1")[0] is False
    whole = dict(UNIT, whole_disk=True)
    assert build([whole]).can_delete("/dev/sdb1")[0] is False
    not_deletable = dict(UNIT, deletable=False)
    assert build([not_deletable]).can_delete("/dev/sdb1")[0] is False


def test_rejects_system_disk():
    service = build([UNIT], system={"sdb"})
    assert service.can_delete("/dev/sdb1")[0] is False


def test_rejects_in_use():
    service = build([UNIT], in_use=lambda mountpoint: "una restauración")
    ok, reason = service.can_delete("/dev/sdb1")
    assert ok is False
    assert "restauración" in reason


def test_guard_rejection_is_returned_not_raised():
    def guard(device, action):
        raise HTTPException(400, "es el disco del sistema")

    service = PartitionService(
        list_units=lambda: [UNIT],
        os_disk_names=lambda: set(),
        parent_disk_name=lambda device: "sdb",
        in_use=lambda mountpoint: None,
        ensure_safe=guard,
    )
    ok, reason = service.can_delete("/dev/sdb1")
    assert ok is False
    assert "sistema" in reason
