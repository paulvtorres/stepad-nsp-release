import re
import socket
import struct
import subprocess


class HostnameResolver:

    def resolve(
        self,
        ip: str,
        timeout: float = 2.0
    ):

        name, _ = self.resolve_with_source(ip, timeout)

        return name

    def resolve_with_source(
        self,
        ip: str,
        timeout: float = 2.0
    ):

        name = self._resolve_netbios(ip, timeout)

        if name:
            return name, "netbios"

        name = self._dns_reverse_lookup(ip, 5353, timeout)

        if name:
            return name, "mdns"

        name = self._dns_reverse_lookup(ip, 5355, timeout)

        if name:
            return name, "llmnr"

        return None, None

    def _resolve_netbios(
        self,
        ip: str,
        timeout: float
    ):

        try:

            result = subprocess.run(
                ["nmblookup", "-A", ip],
                capture_output=True,
                text=True,
                timeout=timeout + 1
            )

        except (FileNotFoundError, subprocess.TimeoutExpired):

            return None

        server = None

        workstation = None

        for line in result.stdout.splitlines():

            line = line.strip()

            match = re.match(
                r"^(\S+)\s+<([0-9A-Fa-f]{2})>",
                line
            )

            if not match:
                continue

            name = match.group(1).strip()

            if not name:
                continue

            ntype = int(match.group(2), 16)

            if ntype == 0x20:

                server = name

            elif ntype == 0x00:

                workstation = name

        return server or workstation

    def _dns_reverse_lookup(
        self,
        ip: str,
        port: int,
        timeout: float
    ):

        sock = None

        try:

            octets = ip.split(".")

            if len(octets) != 4:

                return None

            reverse = ".".join(reversed(octets))

            name = f"{reverse}.in-addr.arpa"

            qname = b"".join(
                bytes([len(label)]) + label.encode()
                for label in name.split(".")
            ) + b"\x00"

            packet = (
                struct.pack(">HHHHHH", 0, 0, 1, 0, 0, 0)
                + qname
                + struct.pack(">HH", 12, 1)
            )

            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

            sock.settimeout(timeout)

            sock.sendto(packet, (ip, port))

            data, _ = sock.recvfrom(4096)

            return self._parse_ptr(data)

        except (socket.timeout, OSError):

            return None

        finally:

            if sock:

                try:
                    sock.close()
                except OSError:
                    pass

    def _parse_ptr(
        self,
        data: bytes
    ):

        if len(data) < 12:

            return None

        ancount = struct.unpack(">H", data[6:8])[0]

        offset = self._skip_name(data, 12)

        if offset is None:
            return None

        offset += 4

        for _ in range(ancount):

            offset = self._skip_name(data, offset)

            if offset is None:
                return None

            if offset + 10 > len(data):
                return None

            rtype, _, _, rdlen = struct.unpack(
                ">HHIH",
                data[offset:offset + 10]
            )

            offset += 10

            if rtype == 12:

                ptr = self._read_name(data, offset)

                if ptr:

                    ptr = ptr.strip()

                    if ptr.endswith(".local"):

                        ptr = ptr[: -len(".local")]

                    return ptr

            offset += rdlen

        return None

    def _skip_name(
        self,
        data: bytes,
        offset: int
    ):

        while offset < len(data):

            length = data[offset]

            if length == 0:
                return offset + 1

            if length & 0xC0 == 0xC0:
                return offset + 2

            offset += length + 1

        return None

    def _read_name(
        self,
        data: bytes,
        offset: int
    ):

        labels = []

        while offset < len(data):

            length = data[offset]

            if length == 0:

                return ".".join(labels)

            if length & 0xC0 == 0xC0:

                pointer = (
                    struct.unpack(">H", data[offset:offset + 2])[0]
                    & 0x3FFF
                )

                rest = self._read_name(data, pointer)

                labels.append(rest)

                return ".".join(labels)

            labels.append(
                data[offset + 1: offset + 1 + length].decode(
                    errors="replace"
                )
            )

            offset += length + 1

        return None
