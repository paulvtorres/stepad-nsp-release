import psutil
import socket
import subprocess

from backend.infrastructure.network.providers.interface_provider import InterfaceProvider
from backend.network.interfaces.models.network_interface_info import NetworkInterfaceInfo


class LinuxInterfaceProvider(InterfaceProvider):

    def get_default_interface(self):

        result = subprocess.run(
            ["ip", "route"],
            capture_output=True,
            text=True
        )

        for line in result.stdout.splitlines():

            if line.startswith("default"):

                parts = line.split()

                if "dev" in parts:

                    return parts[parts.index("dev") + 1]

        return None

    def should_ignore(self, interface_name: str) -> bool:

        ignored_prefixes = (

            "lo",

            "wl",
            "wlan",
            "wlp",

            "docker",

            "virbr",

            "br-",

            "veth",

            "tun",

            "tap",

            "tailscale",

            "zt"

        )

        return interface_name.startswith(ignored_prefixes)

    def _read_link_detected(self, interface_name: str, is_up: bool) -> bool:

        # "link detected" = hay cable/peer. El carrier solo se puede
        # leer con la interfaz arriba; si no se puede, se usa is_up.
        try:

            with open(
                f"/sys/class/net/{interface_name}/carrier"
            ) as f:

                value = f.read().strip()

            return value == "1"

        except Exception:

            return is_up


    def _ensure_physical_up(self, names) -> None:

        # Levantar las NIC físicas detectadas (sin IP es inofensivo)
        # para poder leer su carrier y mostrar cuál tiene cable.
        changed = False

        for name in names:

            try:

                result = subprocess.run(
                    ["ip", "link", "set", name, "up"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )

                if result.returncode == 0:

                    changed = True

            except Exception:

                pass

        if changed:

            # Esperar a que el enlace se negocie para leer el carrier.
            import time

            time.sleep(2)


    def _read_sys_mac(self, interface_name: str) -> str:

        try:

            with open(
                f"/sys/class/net/{interface_name}/address"
            ) as f:

                value = f.read().strip()

            if value and value != "00:00:00:00:00:00":

                return value

        except Exception:

            pass

        return ""


    def list_interfaces(self, deep: bool = True):

        interfaces = []

        addresses = psutil.net_if_addrs()

        stats = psutil.net_if_stats()

        index = 1

        # deep=True: levanta las NIC fisicas y espera a leer el carrier
        # (lento, ~2s). deep=False: solo lee el estado actual (rapido),
        # para la carga normal de la web; el rescan explicito usa deep.
        if deep:

            self._ensure_physical_up(set(addresses) | set(stats))

            stats = psutil.net_if_stats()

        for interface_name in (set(addresses) | set(stats)):

            if self.should_ignore(interface_name):

                continue

            address_list = addresses.get(interface_name, [])

            mac = ""

            ip = ""
            subnet_mask = ""

            first_inet = True

            for address in address_list:

                if address.family == socket.AF_INET:

                    if first_inet:

                        ip = address.address
                        subnet_mask = address.netmask
                        first_inet = False

                elif address.family == psutil.AF_LINK:

                    mac = address.address

                elif hasattr(socket, "AF_PACKET") and address.family == socket.AF_PACKET:

                    mac = address.address

            if not mac:

                mac = self._read_sys_mac(interface_name)

            stat = stats.get(interface_name)

            is_up = stat.isup if stat is not None else False

            has_ip = ip != ""

            connection_state = self.resolve_connection_state(
                is_up,
                has_ip
            )

            interfaces.append(
                NetworkInterfaceInfo(
                    id=index,

                    name=interface_name,

                    display_name=interface_name,

                    ipv4_address=ip,

                    mac_address=mac,

                    ipv6_address=None,

                    subnet_mask=subnet_mask,

                    gateway=None,

                    mtu=(stat.mtu if stat is not None else 0),

                    speed=(stat.speed if stat is not None else None),

                    status="UP" if is_up else "DOWN",

                    interface_type="ETHERNET",

                    is_default_gateway=(

                        interface_name == self.get_default_interface()

                    ),

                    link_detected=self._read_link_detected(
                        interface_name, is_up
                    ),
                    connection_state=connection_state
                )
            )
        
            index += 1

        return interfaces

    def resolve_connection_state(

        self,

        is_up: bool,

        has_ip: bool

    ):

        if not is_up:

            return "NO_LINK"

        if is_up and not has_ip:

            return "CONNECTED_NO_IP"

        return "ACTIVE"