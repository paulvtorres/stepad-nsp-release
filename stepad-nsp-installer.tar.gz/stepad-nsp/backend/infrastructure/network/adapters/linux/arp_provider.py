import subprocess

from backend.network.devices.models.network_device_info import (
    NetworkDeviceInfo
)


class ARPProvider:


    def list_devices(
        self,
        interface: str
    ):

        result = subprocess.run(
            [
                "ip",
                "neigh",
                "show",
                "dev",
                interface
            ],
            capture_output=True,
            text=True
        )


        devices = []


        for line in result.stdout.splitlines():


            parts = line.split()


            if len(parts) < 3:
                continue



            ip = parts[0]



            # Ignore IPv6 link-local

            if ip.startswith("fe80"):
                continue



            # Ignore APIPA

            if ip.startswith("169.254"):
                continue



            mac = "-"



            if "lladdr" in parts:


                index = parts.index(
                    "lladdr"
                )


                if index + 1 < len(parts):

                    mac = parts[index + 1]



            # Ignore entries without MAC

            if mac == "-":
                continue



            status = parts[-1].upper()



            devices.append(

                NetworkDeviceInfo(

                    id=len(devices) + 1,

                    ip_address=ip,

                    mac_address=mac,

                    interface=interface,

                    status=status,

                    device_type="host"

                )

            )



        return devices