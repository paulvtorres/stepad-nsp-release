from abc import ABC, abstractmethod
from typing import List

from backend.network.interfaces.models.network_interface import NetworkInterface


class InterfaceProvider(ABC):

    @abstractmethod
    def list_interfaces(self) -> List[NetworkInterface]:
        pass
