from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import (
    ComponentCriticality
)

from backend.bandwidth.services.bandwidth_service import (
    BandwidthService
)

from backend.shared.logging.logger import logger


class BandwidthComponent(BaseComponent):


    name = "bandwidth"

    criticality = ComponentCriticality.OPTIONAL


    def __init__(self):

        self.service = BandwidthService()


    def start(self):

        try:

            result = self.service.apply()

            logger.info(
                "BandwidthComponent aplicado: %s",
                result
            )

        except Exception as error:

            logger.error(
                "BandwidthComponent fallo: %s",
                error
            )


    def stop(self):

        logger.info(
            "BandwidthComponent detenido."
        )
