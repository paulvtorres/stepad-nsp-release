from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import (
    ComponentCriticality
)

from backend.bandwidth.services.bandwidth_service import (
    BandwidthService
)

from backend.bandwidth.services.live_traffic_service import (
    live_traffic_service
)

from backend.shared.logging.logger import logger


class BandwidthComponent(BaseComponent):


    name = "bandwidth"

    criticality = ComponentCriticality.OPTIONAL


    def __init__(self):

        self.service = BandwidthService()


    def start(self):

        try:

            result = self.service.apply()

            logger.info(
                "BandwidthComponent aplicado: %s",
                result
            )

        except Exception as error:

            logger.error(
                "BandwidthComponent fallo: %s",
                error
            )

        # Muestreo del ancho de banda en vivo (WAN y por equipo) para el
        # panel de Ancho de banda. Es solo lectura de /proc: si falla,
        # el resto del componente sigue igual.
        try:

            live_traffic_service.start()

        except Exception as error:

            logger.error(
                "BandwidthComponent: no pude iniciar el muestreo en vivo: %s",
                error
            )


    def stop(self):

        live_traffic_service.stop()

        logger.info(
            "BandwidthComponent detenido."
        )
