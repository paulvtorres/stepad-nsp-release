"""Ancho de banda en vivo: tasa actual de la WAN y por equipo.

Fuentes de datos:
  * WAN total: contadores acumulados de /proc/net/dev (exacto, barato).
  * Por equipo: contabilidad de bytes de conntrack
    (/proc/net/nf_conntrack). Se guarda el acumulado de cada flujo y se
    suman los INCREMENTOS entre muestras: así la cifra no cae cuando el
    kernel expira un flujo. Requiere nf_conntrack_acct=1, que se activa
    al arrancar y se persiste desde install.sh.

Todo vive en memoria: el histórico del gráfico es un anillo de los
últimos 60 minutos a 2 s. No se escribe nada en la base de datos (el
volumen histórico por hora sigue en egress_flow_stats).
"""

import ipaddress
import subprocess
import threading
import time

from collections import deque

from datetime import datetime
from backend.shared.datetime_utils import utcnow
from pathlib import Path

from backend.core.database.session import SessionLocal

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.network.interfaces.registry.models.managed_interface import (
    ManagedInterface
)

from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


NET_DEV = Path("/proc/net/dev")
CONNTRACK = Path("/proc/net/nf_conntrack")
CONNTRACK_ACCT = Path("/proc/sys/net/netfilter/nf_conntrack_acct")

SAMPLE_SECONDS = 2

# Ventana para la tasa "actual": 5 muestras de 2 s = 10 s.
RATE_WINDOW_SAMPLES = 5

# 60 minutos de histórico a 2 s.
HISTORY_SAMPLES = 1800

WAN_REFRESH_SECONDS = 60

NAME_CACHE_TTL = 300

MAX_DEVICES = 30

# Por debajo de esto (5 kbps) se considera ruido de fondo.
MIN_DEVICE_MBPS = 0.005


def parse_net_dev_counters(line: str, ifname: str):

    """Devuelve (bytes_recibidos, bytes_enviados) de una línea de /proc/net/dev."""

    head, _, rest = line.partition(":")

    if head.strip() != ifname:

        return None

    fields = rest.split()

    if len(fields) < 9:

        return None

    try:

        return int(fields[0]), int(fields[8])

    except (TypeError, ValueError):

        return None


def read_net_dev_counters(ifname: str):

    try:

        with open(NET_DEV, "r", encoding="utf-8") as file:

            for line in file:

                counters = parse_net_dev_counters(line, ifname)

                if counters:

                    return counters

    except OSError:

        return None

    return None


def _fields(tokens) -> dict:

    values = {}

    for token in tokens:

        name, sep, value = token.partition("=")

        if sep:

            values[name] = value

    return values


def parse_conntrack_line(line: str):

    """Extrae el flujo y sus bytes de una línea de /proc/net/nf_conntrack.

    El formato es: `ipv4 2 tcp 6 431999 ESTABLISHED <tuple1> <tuple2> ...`
    donde cada tuple trae sus propios `packets=` y `bytes=`. Los bytes de
    la primera tuple son del sentido ORIGINAL (equipo -> destino) y los
    de la segunda, del sentido de respuesta (destino -> equipo).

    Devuelve None si la línea no tiene contadores (nf_conntrack_acct
    desactivado) o no es un flujo IP.
    """

    tokens = line.split()

    starts = [
        index for index, token in enumerate(tokens)
        if token.startswith("src=")
    ]

    if not starts:

        return None

    first = _fields(tokens[starts[0]: starts[1] if len(starts) > 1 else len(tokens)])

    second = _fields(tokens[starts[1]:]) if len(starts) > 1 else {}

    src = first.get("src")
    dst = first.get("dst")

    if not src or not dst:

        return None

    try:

        up = int(first.get("bytes", 0) or 0)
        down = int(second.get("bytes", 0) or 0)

    except (TypeError, ValueError):

        return None

    if up <= 0 and down <= 0:

        return None

    proto = tokens[2] if len(tokens) > 2 else ""

    key = (proto, src, first.get("sport", ""), dst, first.get("dport", ""))

    return {
        "key": key,
        "src": src,
        "dst": dst,
        "up": up,
        "down": down,
    }


def is_internal_ip(value: str) -> bool:

    try:

        address = ipaddress.ip_address(value)

    except ValueError:

        return False

    return address.is_private or address.is_loopback


def is_lan_ip(value: str) -> bool:

    """IP de un equipo de la LAN (privada, pero no loopback).

    El loopback (127.0.0.1) no es un equipo: se excluye para no ensuciar
    la tabla con el tráfico interno del propio NSP.
    """

    try:

        address = ipaddress.ip_address(value)

    except ValueError:

        return False

    return address.is_private and not address.is_loopback


def to_mbps(byte_count: int, seconds: float) -> float:

    if seconds <= 0:

        return 0.0

    return round((byte_count * 8) / seconds / 1_000_000, 3)


class LiveTrafficService:


    def __init__(self):

        self._lock = threading.Lock()

        self._thread: threading.Thread | None = None

        self._stop = threading.Event()

        self._wan_interfaces: list[str] = []
        self._local_ips: set[str] = set()
        self._wan_ifaces_at = 0.0

        # Ventana de la WAN: misma duración que la de equipos (10 s) para
        # que "bajada/subida ahora" y la tabla sean comparables.
        self._wan_window: deque = deque(maxlen=RATE_WINDOW_SAMPLES)

        self._flows: dict[tuple, tuple[int, int]] = {}

        self._window: deque = deque(maxlen=RATE_WINDOW_SAMPLES)

        self._history: deque = deque(maxlen=HISTORY_SAMPLES)

        self._wan = {
            "interface": "",
            "rx_mbps": 0.0,
            "tx_mbps": 0.0,
            "rx_total_bytes": 0,
            "tx_total_bytes": 0,
        }

        self._devices: list[dict] = []

        self._names: dict[str, tuple[str, float]] = {}

        self._acct_enabled = False

        self._updated_at = None


    # ------------------------------------------------------------------
    # Ciclo de vida
    # ------------------------------------------------------------------

    def start(self):

        if self._thread and self._thread.is_alive():

            return

        self._stop.clear()

        self._enable_acct()

        self._thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name="live-traffic-sampler"
        )

        self._thread.start()

        logger.info("LiveTrafficService iniciado (muestreo cada %ss)", SAMPLE_SECONDS)


    def stop(self):

        self._stop.set()


    def _loop(self):

        self._refresh_wan_interfaces()

        while not self._stop.is_set():

            try:

                self._sample()

            except Exception as error:

                logger.warning("LiveTrafficService: fallo al muestrear: %s", error)

            self._stop.wait(SAMPLE_SECONDS)


    def _enable_acct(self):

        """Activa la contabilidad de bytes de conntrack (idempotente)."""

        try:

            if CONNTRACK_ACCT.exists() and CONNTRACK_ACCT.read_text().strip() != "1":

                CONNTRACK_ACCT.write_text("1\n")

                logger.info("conntrack accounting activado (nf_conntrack_acct=1)")

        except OSError as error:

            logger.warning("No se pudo activar nf_conntrack_acct: %s", error)

        try:

            self._acct_enabled = CONNTRACK_ACCT.read_text().strip() == "1"

        except OSError:

            self._acct_enabled = False


    # ------------------------------------------------------------------
    # WAN
    # ------------------------------------------------------------------

    def _refresh_wan_interfaces(self):

        try:

            with SessionLocal() as db:

                rows = (
                    db.query(ManagedInterface)
                    .filter(ManagedInterface.role.ilike("wan"))
                    .all()
                )

                names = [
                    (row.last_seen_name or "").strip()
                    for row in rows
                ]

            self._wan_interfaces = [name for name in names if name]

            self._local_ips = self._read_local_ips()

            self._wan_ifaces_at = time.time()

        except Exception as error:

            logger.warning("LiveTrafficService: no pude leer interfaces WAN: %s", error)


    def _read_local_ips(self) -> set:

        """IPs propias del NSP (todas las interfaces) para etiquetarlo.

        Se incluye la LAN: el trafico del propio NSP hacia Internet sale
        con su IP de LAN (192.168.1.1) y antes aparecia como un equipo
        sin nombre.
        """

        addresses = set()

        try:

            result = subprocess.run(
                ["ip", "-4", "-o", "addr", "show"],
                capture_output=True,
                text=True,
                timeout=3,
            )

            for line in result.stdout.splitlines():

                for token in line.split():

                    if "/" in token and token[0].isdigit():

                        addresses.add(token.split("/")[0])

        except Exception as error:
            logger.debug("live_traffic_service._read_local_ips: %s", error)
        return addresses


    def _sample_wan(self, now: float):

        if not self._wan_interfaces or (now - self._wan_ifaces_at) > WAN_REFRESH_SECONDS:

            self._refresh_wan_interfaces()

        rx_total = 0
        tx_total = 0

        for ifname in self._wan_interfaces:

            counters = read_net_dev_counters(ifname)

            if not counters:

                continue

            rx, tx = counters

            rx_total += rx
            tx_total += tx

        rx_mbps = 0.0
        tx_mbps = 0.0

        self._wan_window.append((now, rx_total, tx_total))

        if len(self._wan_window) >= 2:

            first_ts, first_rx, first_tx = self._wan_window[0]

            elapsed = max(now - first_ts, 1.0)

            delta_rx = rx_total - first_rx
            delta_tx = tx_total - first_tx

            if delta_rx < 0 or delta_tx < 0:

                # Contador reiniciado (interfaz caída o wrap): re-basear.
                self._wan_window.clear()

                self._wan_window.append((now, rx_total, tx_total))

            else:

                rx_mbps = to_mbps(delta_rx, elapsed)
                tx_mbps = to_mbps(delta_tx, elapsed)

        return {
            "interface": ", ".join(self._wan_interfaces),
            "rx_mbps": round(rx_mbps, 3),
            "tx_mbps": round(tx_mbps, 3),
            "rx_total_bytes": rx_total,
            "tx_total_bytes": tx_total,
        }


    # ------------------------------------------------------------------
    # Por equipo (conntrack)
    # ------------------------------------------------------------------

    def _collect_flow_deltas(self) -> dict:

        """Incrementos de bytes por IP interna desde la muestra anterior."""

        try:

            with open(CONNTRACK, "r", encoding="utf-8") as file:

                lines = file.readlines()

        except OSError:

            self._acct_enabled = False

            return {}

        current = {}
        deltas: dict[str, list[int]] = {}

        for line in lines:

            parsed = parse_conntrack_line(line)

            if not parsed:

                continue

            current[parsed["key"]] = (parsed["up"], parsed["down"])

            src = parsed["src"]

            if not is_lan_ip(src):

                continue

            # El panel mide el consumo del ENLACE A INTERNET. El trafico
            # LAN<->LAN (compartidos SMB, DNS interno, NSP como gateway)
            # no cruza la WAN y hacia que un equipo mostrara cientos de
            # Mbps y porcentajes >100% sobre la tasa real de la WAN.
            if is_lan_ip(parsed["dst"]):

                continue

            previous = self._flows.get(parsed["key"])

            if previous:

                up_delta = max(0, parsed["up"] - previous[0])
                down_delta = max(0, parsed["down"] - previous[1])

            else:

                # Flujo nuevo: lo ya acumulado ocurrió en esta ventana.
                up_delta = parsed["up"]
                down_delta = parsed["down"]

            if up_delta or down_delta:

                bucket = deltas.setdefault(src, [0, 0])

                bucket[0] += up_delta
                bucket[1] += down_delta

        # Los flujos que expiraron desaparecen: sus bytes ya se contaron.
        self._flows = current

        if current:

            self._acct_enabled = True

        return deltas


    def _device_names(self, ips, now: float) -> dict:

        pending = [
            ip for ip in ips
            if ip not in self._names or (now - self._names[ip][1]) > NAME_CACHE_TTL
        ]

        if pending:

            try:

                with SessionLocal() as db:

                    rows = (
                        db.query(
                            NetworkDevice.ip_address,
                            NetworkDevice.display_name,
                            NetworkDevice.hostname,
                        )
                        .filter(NetworkDevice.ip_address.in_(pending))
                        .all()
                    )

                    found = {}

                    for ip, display_name, hostname in rows:

                        found[ip] = (display_name or hostname or "").strip()

                    for ip in pending:

                        self._names[ip] = (found.get(ip, ""), now)

            except Exception as error:

                logger.warning("LiveTrafficService: no pude leer nombres: %s", error)

        return {ip: self._names.get(ip, ("", now))[0] for ip in ips}


    def _sample_devices(self, now: float):

        deltas = self._collect_flow_deltas()

        self._window.append((now, deltas))

        if len(self._window) < 2:

            return []

        first_ts = self._window[0][0]

        elapsed = max(now - first_ts, SAMPLE_SECONDS)

        totals: dict[str, list[int]] = {}

        for _, bucket in self._window:

            for ip, (up, down) in bucket.items():

                entry = totals.setdefault(ip, [0, 0])

                entry[0] += up
                entry[1] += down

        names = self._device_names(list(totals.keys()), now)

        devices = []

        for ip, (up, down) in totals.items():

            rx_mbps = to_mbps(down, elapsed)
            tx_mbps = to_mbps(up, elapsed)

            if (rx_mbps + tx_mbps) < MIN_DEVICE_MBPS:

                continue

            name = names.get(ip, "")

            if not name and ip in self._local_ips:

                name = "Este equipo (NSP)"

            devices.append({
                "ip": ip,
                "name": name,
                "rx_mbps": rx_mbps,
                "tx_mbps": tx_mbps,
            })

        devices.sort(key=lambda item: item["rx_mbps"] + item["tx_mbps"], reverse=True)

        return devices[:MAX_DEVICES]


    # ------------------------------------------------------------------
    # Muestreo
    # ------------------------------------------------------------------

    def _sample(self):

        now = time.time()

        wan = self._sample_wan(now)

        devices = self._sample_devices(now)

        with self._lock:

            self._wan = wan

            self._devices = devices

            self._updated_at = utcnow()

            self._history.append((now, wan["rx_mbps"], wan["tx_mbps"]))


    def snapshot(self, include_history: bool = False) -> dict:

        with self._lock:

            wan = dict(self._wan)

            devices = [dict(item) for item in self._devices]

            history = list(self._history)

            updated_at = self._updated_at

            acct_enabled = self._acct_enabled

        if not wan["interface"] and not self._thread:

            self.start()

        peak_rx = max((item[1] for item in history), default=0.0)
        peak_tx = max((item[2] for item in history), default=0.0)

        total_rx = round(sum(item["rx_mbps"] for item in devices), 3)
        total_tx = round(sum(item["tx_mbps"] for item in devices), 3)

        payload = {
            "timestamp": to_iso_utc(updated_at),
            "epoch": round(history[-1][0], 3) if history else None,
            "sample_seconds": SAMPLE_SECONDS,
            "window_seconds": SAMPLE_SECONDS * RATE_WINDOW_SAMPLES,
            "wan": {
                **wan,
                "peak_rx_mbps": round(peak_rx, 3),
                "peak_tx_mbps": round(peak_tx, 3),
            },
            "devices": devices,
            "devices_total_rx_mbps": total_rx,
            "devices_total_tx_mbps": total_tx,
            "acct_enabled": acct_enabled,
        }

        if include_history:

            payload["history"] = [
                {"t": round(ts, 3), "rx": rx, "tx": tx}
                for ts, rx, tx in history
            ]

        return payload


live_traffic_service = LiveTrafficService()