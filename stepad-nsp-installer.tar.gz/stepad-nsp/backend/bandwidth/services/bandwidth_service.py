import ipaddress

from sqlalchemy.orm import Session

from backend.core.database.session import SessionLocal

from backend.network.configuration.services.network_configuration_service import (
    NetworkConfigurationService
)

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.groups.models.device_group import (
    DeviceGroup,
    GroupDevice
)

from backend.bandwidth.providers.linux.tc_provider import (
    TcProvider
)

from backend.shared.logging.logger import logger


DEFAULT_TOTAL_KBIT = 1_000_000


class BandwidthService:


    def __init__(self):

        self.provider = TcProvider()

        self.network_configuration = NetworkConfigurationService()


    def effective_limits(
        self,
        db: Session
    ):

        network = self.network_configuration.get_lan_configuration()

        if not network:

            return None, []

        interface = network["interface"]

        lan_network = ipaddress.ip_network(
            network["network"]
        )

        devices = (
            db.query(NetworkDevice)
            .filter(
                NetworkDevice.ip_address.isnot(None)
            )
            .all()
        )

        groups = {
            group.id: group
            for group in db.query(DeviceGroup).all()
        }

        group_by_device = {}

        for member in db.query(GroupDevice).all():

            group_by_device[member.device_id] = member.group_id

        limits = []

        for device in devices:

            try:

                device_ip = ipaddress.ip_address(
                    device.ip_address
                )

            except ValueError:

                continue

            if device_ip not in lan_network:

                continue

            group_limit = None

            group_id = group_by_device.get(device.id)

            if group_id and groups.get(group_id):

                group_limit = groups[group_id].bandwidth_limit_kbps

            limit = device.bandwidth_limit_kbps

            if limit is None:

                limit = group_limit

            if limit is not None and limit > 0:

                limits.append(
                    (device.ip_address, int(limit))
                )

        return interface, limits


    def apply(self):

        db = SessionLocal()

        try:

            network = self.network_configuration.get_lan_configuration()

            if not network:

                return {
                    "success": False,
                    "message": "No hay interfaz LAN configurada"
                }

            interface, limits = self.effective_limits(db)

            if not limits:

                self.provider.clear(interface)

                logger.info(
                    "Bandwidth: sin límites, tc limpiado en %s",
                    interface
                )

                return {
                    "success": True,
                    "interface": interface,
                    "applied": []
                }

            result = self.provider.apply_download_shaping(
                interface,
                DEFAULT_TOTAL_KBIT,
                limits
            )

            logger.info(
                "Bandwidth: %d reglas aplicadas en %s (%s)",
                len(limits),
                interface,
                result
            )

            return {
                "success": result.get("success", False),
                "interface": interface,
                "applied": [
                    {"ip": ip, "kbps": kbit}
                    for ip, kbit in limits
                ]
            }

        finally:

            db.close()
