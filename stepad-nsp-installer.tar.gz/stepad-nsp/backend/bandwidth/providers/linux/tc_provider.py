import subprocess

from backend.shared.logging.logger import logger


class TcProvider:


    TC_BIN = "/usr/sbin/tc"


    def apply_download_shaping(
        self,
        interface: str,
        total_kbit: int,
        limits: list
    ):

        commands = []

        commands.append(
            ["qdisc", "del", "dev", interface, "root"]
        )

        commands.append(
            ["qdisc", "add", "dev", interface, "root",
             "handle", "1:", "htb", "default", "9999"]
        )

        commands.append(
            ["class", "add", "dev", interface, "parent", "1:",
             "classid", "1:9999", "htb",
             "rate", f"{total_kbit}kbit", "ceil", f"{total_kbit}kbit"]
        )

        for minor, (ip, kbit) in enumerate(limits, start=100):

            classid = f"1:{minor}"

            commands.append(
                ["class", "add", "dev", interface, "parent", "1:",
                 "classid", classid, "htb",
                 "rate", f"{kbit}kbit", "ceil", f"{kbit}kbit"]
            )

            commands.append(
                ["filter", "add", "dev", interface, "parent", "1:",
                 "protocol", "ip", "prio", "10", "u32",
                 "match", "ip", "dst", f"{ip}/32",
                 "flowid", classid]
            )

        return self._run(commands)


    def clear(
        self,
        interface: str
    ):

        return self._run(
            [["qdisc", "del", "dev", interface, "root"]]
        )


    def _run(self, commands):

        for args in commands:

            cmd = [self.TC_BIN] + args

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:

                # Removing a root qdisc that doesn't exist is a
                # normal no-op (nothing configured yet) -- ignore it.
                if args[:2] == ["qdisc", "del"]:

                    continue

                logger.warning(
                    "tc %s -> %s",
                    " ".join(args),
                    result.stderr.strip()
                )

                return {
                    "success": False,
                    "error": result.stderr.strip()
                }

        return {
            "success": True
        }
