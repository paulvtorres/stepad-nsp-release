"""Gestion de discos conectados al NSP y explorador de su contenido.

El explorador (listar, crear, renombrar, mover, copiar, borrar, subir,
descargar, propiedades y búsqueda) solo puede operar dentro de las unidades
montadas de datos: nunca sobre el disco del sistema. Cada ruta que llega desde
la API se resuelve (siguiendo enlaces simbólicos) y debe quedar dentro de una
raíz permitida; ver ``_allowed_roots``.
"""

import errno
import json
import os
import re
import shutil
import stat as stat_mod
import subprocess
import time

from pathlib import Path

from fastapi import HTTPException, UploadFile

from backend.core.config.paths import SHARE_DISK_MOUNT, SHARE_VOLUMES_ROOT
from backend.shared.logging.logger import logger
from backend.storage.services import fs_ops


MOUNT_BASE = "/mnt/stepad-disk"

_UPLOAD_CHUNK = 1024 * 1024
_SAFE_SEGMENT = re.compile(r"^[^/\x00]+$")

# Un disco que tenga montado alguno de estos se considera «del sistema».
_SYSTEM_DISK_MARKERS = {"/", "/boot", "/boot/efi"}

# Puntos de montaje del sistema operativo: nunca se exploran.
_SYSTEM_MOUNTS = {
    "/", "/boot", "/boot/efi", "/home", "/var", "/usr", "/etc", "/opt",
    "/srv", "/tmp", "/root", "/bin", "/sbin", "/lib", "/dev", "/proc", "/sys",
    "/run", "[SWAP]",
}


def _unescape_mount_field(value: str) -> str:
    """/proc/mounts escapa espacios y tabuladores como \\040 y \\011."""
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), value)


class DiskService:

    _ROOTS_TTL_S = 3.0

    def __init__(self):
        Path(MOUNT_BASE).mkdir(parents=True, exist_ok=True)
        self._roots_cache = None  # (timestamp, [Path, ...])

    # ------------------------------------------------------------------ #
    # Discos y montaje
    # ------------------------------------------------------------------ #

    def _lsblk(self) -> list:
        try:
            result = subprocess.run(
                ["lsblk", "-J", "-o", "NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,MODEL"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return json.loads(result.stdout).get("blockdevices", [])
        except Exception as exc:
            logger.error("DiskService: %s", exc)
        return []

    @staticmethod
    def _walk_tree(device: dict):
        yield device
        for child in device.get("children") or []:
            yield from DiskService._walk_tree(child)

    def _system_device_names(self) -> set:
        """Nombres (sda, sda1, ...) de los discos que alojan el sistema."""
        return self._system_names_from(self._lsblk())

    def _system_names_from(self, blockdevices: list) -> set:
        names: set = set()
        for disk in blockdevices:
            nodes = list(self._walk_tree(disk))
            if any(
                (node.get("mountpoint") or "") in _SYSTEM_DISK_MARKERS
                for node in nodes
            ):
                names.update(node.get("name") for node in nodes if node.get("name"))
        return names

    def list_disks(self) -> list:
        disks = []
        for device in self._lsblk():
            if device.get("type") != "disk":
                continue
            disk = {
                "name": device["name"],
                "device": device["name"],
                "model": (device.get("model") or "").strip() or "Desconocido",
                "size": device.get("size", ""),
                "partitions": [],
            }
            for part in device.get("children", []):
                if part.get("type") != "part":
                    continue
                disk["partitions"].append({
                    "name": part["name"],
                    "device": part["name"],
                    "size": part.get("size", ""),
                    "fstype": part.get("fstype") or "desconocido",
                    "mountpoint": part.get("mountpoint") or "",
                    "mounted": bool(part.get("mountpoint")),
                })
            disks.append(disk)
        return disks

    @staticmethod
    def _read_mounts() -> list:
        """Lista de montajes: dict(source, mountpoint, fstype, options)."""
        mounts = []
        try:
            with open("/proc/mounts", encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    parts = line.split()
                    if len(parts) < 4:
                        continue
                    mounts.append({
                        "source": _unescape_mount_field(parts[0]),
                        "mountpoint": _unescape_mount_field(parts[1]),
                        "fstype": parts[2],
                        "options": set(parts[3].split(",")),
                    })
        except OSError:
            pass
        return mounts

    def _find_mount_of_device(self, dev_path: str):
        """Punto de montaje del dispositivo (comparación exacta, no subcadena)."""
        target = os.path.realpath(dev_path)
        for mount in self._read_mounts():
            if not mount["source"].startswith("/dev/"):
                continue
            if os.path.realpath(mount["source"]) == target:
                return mount
        return None

    def _mount_covering(self, path: Path):
        """Montaje más específico que contiene ``path`` (para saber si es ro)."""
        best = None
        best_len = -1
        text = str(path)
        for mount in self._read_mounts():
            mp = mount["mountpoint"].rstrip("/") or "/"
            if text == mp or text.startswith(mp.rstrip("/") + "/"):
                if len(mp) > best_len:
                    best, best_len = mount, len(mp)
        return best

    def mount(self, device: str, fstype: str = None) -> dict:
        try:
            dev_path = device if device.startswith("/dev/") else f"/dev/{device}"
            real = os.path.realpath(dev_path)
            if not real.startswith("/dev/") or not os.path.exists(real):
                return {"success": False, "error": f"No existe {dev_path}"}
            try:
                if not stat_mod.S_ISBLK(os.stat(real).st_mode):
                    return {"success": False, "error": f"{dev_path} no es un dispositivo de bloques"}
            except OSError as exc:
                return {"success": False, "error": str(exc)}

            dev_name = os.path.basename(real)
            if dev_name in self._system_device_names():
                return {
                    "success": False,
                    "error": "No se puede explorar un disco del sistema.",
                }

            existing = self._find_mount_of_device(real)
            if existing:
                self._roots_cache = None
                return {
                    "success": True,
                    "mountpoint": existing["mountpoint"],
                    "readonly": "ro" in existing["options"],
                }

            mount_point = f"{MOUNT_BASE}/{dev_name}"
            Path(mount_point).mkdir(parents=True, exist_ok=True)
            fs = fstype or self._detect_fs(real)
            if fs == "ntfs":
                cmd = ["ntfs-3g", real, mount_point]
            else:
                cmd = ["mount", real, mount_point]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            self._roots_cache = None
            if result.returncode != 0:
                cmd_ro = (
                    ["ntfs-3g", real, mount_point, "-o", "ro"]
                    if fs == "ntfs"
                    else ["mount", "-o", "ro", real, mount_point]
                )
                result = subprocess.run(cmd_ro, capture_output=True, text=True, timeout=30)
                self._roots_cache = None
                if result.returncode != 0:
                    return {"success": False, "error": result.stderr}
                return {"success": True, "mountpoint": mount_point, "readonly": True}
            return {"success": True, "mountpoint": mount_point, "readonly": False}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def unmount(self, device: str) -> dict:
        try:
            dev_path = device if device.startswith("/dev/") else f"/dev/{device}"
            real = os.path.realpath(dev_path)
            existing = self._find_mount_of_device(real)
            if not existing:
                return {"success": True, "error": ""}
            mount_point = existing["mountpoint"]
            # Solo se desmonta lo que montó este explorador; los montajes
            # gestionados por «Unidades compartidas» se desactivan desde ahí.
            if not (mount_point == MOUNT_BASE or mount_point.startswith(MOUNT_BASE + "/")):
                return {
                    "success": False,
                    "error": f"Está montado en {mount_point}, gestionado por otra función.",
                }
            result = subprocess.run(
                ["umount", mount_point], capture_output=True, text=True, timeout=10
            )
            self._roots_cache = None
            if result.returncode != 0:
                return {"success": False, "error": result.stderr.strip() or "No se pudo desmontar (¿en uso?)."}
            return {"success": True, "error": ""}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def _detect_fs(self, device: str) -> str:
        try:
            result = subprocess.run(
                ["blkid", "-s", "TYPE", "-o", "value", device],
                capture_output=True, text=True, timeout=5,
            )
            return result.stdout.strip().lower()
        except Exception:
            return ""

    # ------------------------------------------------------------------ #
    # Confinamiento de rutas
    # ------------------------------------------------------------------ #

    def _allowed_roots(self) -> list:
        """Raíces exploradas: unidades de datos montadas, nunca el sistema.

        Se cachea unos segundos porque cada operación valida varias rutas y
        ejecutar ``lsblk`` en cada una sería innecesariamente lento.
        """
        cached = self._roots_cache
        if cached and time.monotonic() - cached[0] < self._ROOTS_TTL_S:
            return cached[1]
        roots = self._compute_allowed_roots()
        self._roots_cache = (time.monotonic(), roots)
        return roots

    def _compute_allowed_roots(self) -> list:
        roots: dict = {}

        def add(path) -> None:
            try:
                p = Path(path)
                if p.is_dir():
                    real = p.resolve()
                    if str(real) not in _SYSTEM_MOUNTS:
                        roots[str(real)] = real
            except OSError:
                pass

        # Rutas fijas conocidas
        add(SHARE_VOLUMES_ROOT)
        add(SHARE_DISK_MOUNT)

        # Agregar TODOS los mount points no-SO del sistema
        for mount in self._read_mounts():
            mp = mount["mountpoint"]
            if mp not in _SYSTEM_MOUNTS and not mp.startswith("/boot"):
                add(mp)

        # Agregar subdirectorios de MOUNT_BASE (discos montados por NSP)
        base = MOUNT_BASE.rstrip("/")
        for mount in self._read_mounts():
            mp = mount["mountpoint"]
            if mp.startswith(base + "/"):
                add(mp)

        # Agregar mount points de discos no-SO detectados por lsblk
        blockdevices = self._lsblk()
        system = self._system_names_from(blockdevices)
        for disk in blockdevices:
            if disk.get("name") in system:
                continue
            for node in self._walk_tree(disk):
                mp = node.get("mountpoint") or ""
                if mp and mp not in _SYSTEM_MOUNTS and not mp.startswith("/boot"):
                    add(mp)

        return list(roots.values())

    @staticmethod
    def _inside(path: Path, root: Path) -> bool:
        return path == root or root in path.parents

    def _root_of(self, path: Path, roots: list = None):
        roots = roots if roots is not None else self._allowed_roots()
        best = None
        for root in roots:
            if self._inside(path, root) and (best is None or len(str(root)) > len(str(best))):
                best = root
        return best

    def _safe_dir(self, path: str) -> tuple:
        """Carpeta existente dentro de una raíz permitida -> (ruta, raíz)."""
        if not path or "\x00" in path or not os.path.isabs(path):
            raise HTTPException(400, "Ruta no válida.")
        try:
            resolved = Path(path).resolve()
        except OSError as exc:
            raise HTTPException(400, "Ruta no válida.") from exc
        root = self._root_of(resolved)
        if root is None:
            raise HTTPException(403, "Ruta fuera de las unidades permitidas.")
        if not resolved.exists():
            raise HTTPException(404, "No existe.")
        if not resolved.is_dir():
            raise HTTPException(400, "No es una carpeta.")
        return resolved, root

    def _safe_entry(self, path: str, must_exist: bool = True) -> tuple:
        """Elemento (sin seguir su propio enlace simbólico) -> (ruta, raíz).

        Se resuelve solo la carpeta contenedora: así, borrar o renombrar un
        enlace simbólico actúa sobre el enlace y no sobre su destino.
        """
        if not path or "\x00" in path or not os.path.isabs(path):
            raise HTTPException(400, "Ruta no válida.")
        raw = Path(path)
        if raw.name in ("", ".", ".."):
            raise HTTPException(400, "Ruta no válida.")
        try:
            parent = raw.parent.resolve()
        except OSError as exc:
            raise HTTPException(400, "Ruta no válida.") from exc
        root = self._root_of(parent)
        if root is None:
            raise HTTPException(403, "Ruta fuera de las unidades permitidas.")
        entry = parent / raw.name
        if must_exist and not os.path.lexists(entry):
            raise HTTPException(404, "No existe.")
        return entry, root

    def _guard_not_root(self, entry: Path, roots: list = None) -> None:
        roots = roots if roots is not None else self._allowed_roots()
        try:
            resolved = entry.resolve()
        except OSError:
            resolved = entry
        if resolved in roots or os.path.ismount(entry):
            raise HTTPException(400, "No se puede modificar la raíz de una unidad.")

    # ------------------------------------------------------------------ #
    # Explorador
    # ------------------------------------------------------------------ #

    def explore(self, path: str) -> dict:
        target, root = self._safe_dir(path)
        listing = fs_ops.list_entries(target, dir_type_name="directory")

        mount = self._mount_covering(target)
        mount_root = None
        if mount:
            mp = Path(mount["mountpoint"])
            try:
                mp_real = mp.resolve()
            except OSError:
                mp_real = mp
            if self._inside(mp_real, root):
                mount_root = mp_real
        base = mount_root or root

        parent = None if target == base else str(target.parent)
        return {
            **listing,
            "path": str(target),
            "root": str(base),
            "parent": parent,
            "usage": fs_ops.disk_usage(target),
            "mount": (
                {
                    "device": mount["source"],
                    "mountpoint": mount["mountpoint"],
                    "fstype": mount["fstype"],
                    "readonly": "ro" in mount["options"],
                }
                if (mount and mount_root is not None) else None
            ),
        }

    def list_directory(self, path: str) -> list:
        """Compatibilidad: solo la lista de elementos."""
        try:
            return self.explore(path)["items"]
        except HTTPException:
            return []

    def info(self, path: str) -> dict:
        entry, _root = self._safe_entry(path)
        return fs_ops.entry_properties(entry)

    def search(self, path: str, query: str) -> dict:
        target, _root = self._safe_dir(path)
        return fs_ops.search_tree(target, query)

    def create_folder(self, path: str, name: str) -> dict:
        name = fs_ops.validate_name(name)
        parent, _root = self._safe_dir(path)
        folder = parent / name
        if os.path.lexists(folder):
            raise HTTPException(409, "Ya existe un elemento con ese nombre.")
        try:
            folder.mkdir()
        except OSError as exc:
            fs_ops.raise_os_error(exc, "crear la carpeta")
        return {"success": True, "path": str(folder)}

    def rename(self, path: str, new_name: str) -> dict:
        new_name = fs_ops.validate_name(new_name)
        entry, _root = self._safe_entry(path)
        self._guard_not_root(entry)
        final = entry.parent / new_name
        if final == entry:
            return {"success": True, "path": str(entry)}
        if os.path.lexists(final):
            raise HTTPException(409, f"Ya existe «{new_name}» en esta carpeta.")
        try:
            os.rename(entry, final)
        except OSError as exc:
            fs_ops.raise_os_error(exc, "renombrar")
        return {"success": True, "path": str(final)}

    def move(self, source: str, dest_dir: str) -> dict:
        entry, _root = self._safe_entry(source)
        self._guard_not_root(entry)
        dest, _dest_root = self._safe_dir(dest_dir)

        if entry.is_dir() and not entry.is_symlink():
            entry_real = entry.resolve()
            if dest == entry_real or entry_real in dest.parents:
                raise HTTPException(400, "No se puede mover una carpeta dentro de sí misma.")
        final = dest / entry.name
        if final == entry:
            raise HTTPException(400, "El elemento ya está en esa carpeta.")
        if os.path.lexists(final):
            raise HTTPException(409, f"Ya existe «{entry.name}» en el destino.")
        fs_ops.move_item(entry, final)
        return {"success": True, "path": str(final)}

    def copy(self, source: str, dest_dir: str) -> dict:
        entry, _root = self._safe_entry(source)
        dest, _dest_root = self._safe_dir(dest_dir)
        final = fs_ops.copy_item(entry, dest)
        return {"success": True, "path": str(final), "name": final.name}

    def delete_item(self, path: str, recursive: bool = False) -> dict:
        entry, _root = self._safe_entry(path)
        self._guard_not_root(entry)
        try:
            if entry.is_symlink() or not entry.is_dir():
                entry.unlink()
            elif recursive:
                shutil.rmtree(entry)
            else:
                try:
                    entry.rmdir()
                except OSError as exc:
                    if exc.errno == errno.ENOTEMPTY:
                        raise HTTPException(
                            409, "La carpeta no está vacía."
                        ) from exc
                    raise
        except HTTPException:
            raise
        except OSError as exc:
            fs_ops.raise_os_error(exc, "eliminar")
        return {"success": True}

    def download_path(self, path: str) -> Path:
        entry, _root = self._safe_entry(path)
        try:
            resolved = entry.resolve()
        except OSError as exc:
            raise HTTPException(400, "Ruta no válida.") from exc
        if self._root_of(resolved) is None:
            raise HTTPException(403, "Ruta fuera de las unidades permitidas.")
        if not resolved.is_file():
            raise HTTPException(400, "Solo se pueden descargar archivos individuales.")
        return resolved

    @staticmethod
    def _rel_parts(rel: str) -> list:
        rel = (rel or "").strip("/")
        if not rel:
            return []
        parts = rel.split("/")
        for part in parts:
            if part in ("", ".", "..") or not _SAFE_SEGMENT.match(part):
                raise HTTPException(400, "Ruta no permitida.")
        return parts

    async def upload(self, path: str, files: list) -> dict:
        target, _root = self._safe_dir(path)
        if not files:
            raise HTTPException(400, "No se recibieron archivos.")

        created: list = []
        skipped: list = []
        failed: list = []

        for upload in files:
            raw_name = upload.filename or ""
            try:
                parts = self._rel_parts(raw_name)
            except HTTPException as exc:
                await upload.close()
                failed.append({"name": raw_name or "(sin nombre)", "error": exc.detail})
                continue
            if not parts:
                await upload.close()
                failed.append({"name": raw_name or "(sin nombre)", "error": "Nombre inválido"})
                continue

            parents, name = parts[:-1], parts[-1]
            dest = target
            try:
                for part in parents:
                    dest = dest / part
                    dest.mkdir(exist_ok=True)
                final = dest / name
            except OSError as exc:
                await upload.close()
                failed.append({"name": raw_name, "error": f"No se pudo crear la carpeta: {exc.strerror or exc}"})
                continue

            if os.path.lexists(final):
                await upload.close()
                skipped.append(raw_name if parents else name)
                continue

            try:
                with final.open("wb") as out:
                    while True:
                        chunk = await upload.read(_UPLOAD_CHUNK)
                        if not chunk:
                            break
                        out.write(chunk)
            except OSError as exc:
                await upload.close()
                try:
                    final.unlink()
                except OSError:
                    pass
                failed.append({"name": raw_name, "error": f"No se pudo guardar: {exc.strerror or exc}"})
                continue
            await upload.close()
            info = fs_ops.describe_entry(final) or {}
            created.append({
                "name": raw_name if parents else name,
                "size": info.get("size"),
                "modified": info.get("modified"),
            })

        if not created:
            if skipped:
                return {
                    "created": [], "skipped": skipped, "failed": failed,
                    "message": "Archivos ya existentes; nada nuevo para subir.",
                }
            detail = failed[0]["error"] if failed else "Ningún archivo válido para subir."
            raise HTTPException(400, detail)

        return {
            "created": created,
            "skipped": skipped,
            "failed": failed,
            "message": f"{len(created)} archivo(s) subido(s)"
            + (f", {len(skipped)} ya existían" if skipped else ""),
        }


disk_service = DiskService()
