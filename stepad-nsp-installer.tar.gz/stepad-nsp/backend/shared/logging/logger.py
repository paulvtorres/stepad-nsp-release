from backend.shared.logging.logger_factory import create_logger

logger = create_logger()