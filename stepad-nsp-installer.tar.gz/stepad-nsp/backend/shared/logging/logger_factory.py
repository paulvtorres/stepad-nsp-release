import logging
from pathlib import Path
from backend.shared.config.config_loader import config

def create_logger():
    """
    Factory responsible for building the STEPAD NSP logger.
    """

    logger = logging.getLogger(f"{config['app']['name']}")

    # Evitar duplicar handlers si ya fue creado
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)

    # Crear carpeta de logs si no existe
    log_path = Path(config["log"]["directory"])
    log_path.mkdir(exist_ok=True)

    file_path = log_path / config["log"]["file"]

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(message)s"
    )

    # Console Handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    # File Handler
    file_handler = logging.FileHandler(file_path)
    file_handler.setFormatter(formatter)

    # Attach handlers
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger