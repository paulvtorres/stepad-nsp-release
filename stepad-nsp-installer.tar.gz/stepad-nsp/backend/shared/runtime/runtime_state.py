from datetime import datetime, timezone


class RuntimeState:

    def __init__(self):
        self._state = {}

    def set(
        self,
        key: str,
        status: str,
        error: str | None = None
    ):

        entry = {
            "status": status,
            "error": error,
            "updated_at": datetime.now(timezone.utc).isoformat(
                timespec="seconds"
            )
        }

        self._state[key] = entry

    def get(self, key: str):
        return self._state.get(key)

    def is_running(self, key: str):
        entry = self._state.get(key)

        return entry is not None and entry.get("status") == "running"

    def all(self):
        return self._state


runtime = RuntimeState()
