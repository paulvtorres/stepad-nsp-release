"""Encryption of secrets at rest (AES-256 with STEPAD_BACKUP_KEY)."""

import os
import subprocess

from pathlib import Path


PREFIX = "enc:v1:"
ENV_FILE = Path("/etc/stepad/stepad.env")


def _key() -> str:

    key = os.environ.get("STEPAD_BACKUP_KEY", "")

    if key:

        return key

    try:

        if ENV_FILE.exists():

            for line in ENV_FILE.read_text(encoding="utf-8").splitlines():

                if line.startswith("STEPAD_BACKUP_KEY="):

                    return line.split("=", 1)[1].strip().strip('"')

    except Exception:

        pass

    return ""


def is_encrypted(value: str | None) -> bool:

    return bool(value) and str(value).startswith(PREFIX)


def encrypt(value: str | None) -> str:

    """Encrypt text; unchanged when already encrypted or no key is available."""

    text = value or ""

    if not text or is_encrypted(text):

        return text

    key = _key()

    if not key:

        return text

    result = subprocess.run(
        [
            "openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-A", "-base64",
            "-pass", f"pass:{key}",
        ],
        input=text.encode(),
        capture_output=True,
    )

    if result.returncode != 0:

        return text

    return PREFIX + result.stdout.decode().strip()


def decrypt(value: str | None) -> str:

    """Decrypt; legacy plaintext values are returned as-is."""

    text = value or ""

    if not text or not is_encrypted(text):

        return text

    key = _key()

    if not key:

        return ""

    result = subprocess.run(
        [
            "openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2", "-A", "-base64",
            "-pass", f"pass:{key}",
        ],
        input=text[len(PREFIX):].encode(),
        capture_output=True,
    )

    if result.returncode != 0:

        return ""

    return result.stdout.decode()
