import yaml

from pathlib import Path


class ConfigLoader:


    def __init__(
        self,
        config_path: str | Path
    ):

        self.config_path = Path(config_path)

        self._config = None


    def load(self):

        with open(
            self.config_path,
            "r",
            encoding="utf-8"
        ) as file:

            self._config = yaml.safe_load(file)

        return self._config


    def get(self):

        if self._config is None:

            self.load()

        return self._config


    def save(self):

        with open(
            self.config_path,
            "w",
            encoding="utf-8"
        ) as file:

            yaml.safe_dump(
                self._config,
                file,
                sort_keys=False,
                allow_unicode=True
            )


    def reload(self):

        self._config = None

        return self.load()


    def update(
        self,
        section: str,
        values: dict
    ):

        config = self.get()

        if section not in config:

            config[section] = {}

        config[section].update(values)

        self.save()


config_loader = ConfigLoader(
    config_path=Path(__file__).parent / "config.yaml"
)

config = config_loader.get()