import os
import shutil
import yaml

from pathlib import Path


# Config canónica del NSP: vive FUERA del repo, junto al resto del
# estado runtime (stepad.env, network_units.json, claves WireGuard...).
# Así el repositorio no arrastra el estado de cada máquina y un update
# nunca puede pisar la config (el paquete trae una genérica).
SYSTEM_CONFIG_PATH = Path("/etc/stepad/config.yaml")


class ConfigLoader:


    def __init__(
        self,
        config_path: str | Path = None
    ):

        self.legacy_config_path = Path(
            config_path
            if config_path
            else Path(__file__).parent / "config.yaml"
        )

        self._config = None


    @property
    def config_path(self) -> Path:

        """Ruta activa de la configuración.

        Orden de resolución:
          1. STEPAD_CONFIG (override explícito).
          2. /etc/stepad/config.yaml (ubicación canónica en producción).
          3. La ruta legacy dentro del repo (entorno de desarrollo).
        """

        override = os.environ.get("STEPAD_CONFIG")

        if override:

            path = Path(override)

            if path.exists():

                return path

        if SYSTEM_CONFIG_PATH.exists():

            return SYSTEM_CONFIG_PATH

        return self.legacy_config_path


    def _source_path(self) -> Path:
        """
        Ruta desde la que se lee la configuración.

        `config.yaml` es estado propio de cada máquina (interfaces, DHCP)
        y no se versiona. En un clon o instalación nueva todavía no existe:
        se lee el `config.yaml.example` versionado como valores iniciales
        hasta que la aplicación guarde su propia copia. `save()` siempre
        escribe en la ruta activa.
        """

        if self.config_path.exists():

            return self.config_path

        example = self.legacy_config_path.with_name(
            f"{self.legacy_config_path.name}.example"
        )

        if example.exists():

            return example

        return self.config_path


    def load(self):

        with open(
            self._source_path(),
            "r",
            encoding="utf-8"
        ) as file:

            self._config = yaml.safe_load(file)

        return self._config


    def get(self):

        if self._config is None:

            self.load()

        return self._config


    def save(self):

        target = self.config_path

        if target == self.legacy_config_path:

            # Maquina nueva: la config debe vivir en /etc/stepad. Si se
            # puede migrar, se escribe ahi y la copia del repo queda
            # solo como respaldo (no se borra: permite revertir).
            if self._migrate_to_system():

                target = SYSTEM_CONFIG_PATH

        with open(
            target,
            "w",
            encoding="utf-8"
        ) as file:

            yaml.safe_dump(
                self._config,
                file,
                sort_keys=False,
                allow_unicode=True
            )


    def _migrate_to_system(self) -> bool:

        """Copia la config legacy a /etc/stepad/config.yaml.

        Devuelve True si la copia existe ya en la ubicacion canonica.
        """

        if SYSTEM_CONFIG_PATH.exists():

            return True

        if not self.legacy_config_path.exists():

            return False

        try:

            SYSTEM_CONFIG_PATH.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            shutil.copy2(
                self.legacy_config_path,
                SYSTEM_CONFIG_PATH,
            )

            os.chmod(SYSTEM_CONFIG_PATH, 0o640)

            return True

        except OSError:

            # Sin permisos (por ejemplo, un entorno de desarrollo donde
            # /etc no es escribible): se sigue con la ruta legacy.
            return False


    def reload(self):

        self._config = None

        return self.load()


    def update(
        self,
        section: str,
        values: dict
    ):

        config = self.get()

        if section not in config:

            config[section] = {}

        config[section].update(values)

        self.save()


config_loader = ConfigLoader(
    config_path=Path(__file__).parent / "config.yaml"
)

config = config_loader.get()
