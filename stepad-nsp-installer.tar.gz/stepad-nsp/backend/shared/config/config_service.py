import yaml

from backend.shared.config.config_loader import (
    config_loader
)


class ConfigService:


    def get(self):

        return config_loader.get()



    def reload(self):

        return config_loader.load()



    def save(
        self,
        configuration: dict
    ):

        with open(
            config_loader.config_path,
            "w"
        ) as file:

            yaml.safe_dump(

                configuration,

                file,

                sort_keys=False,

                default_flow_style=False

            )


        config_loader.load()



    def update_section(

        self,

        section: str,

        values: dict

    ):

        configuration = self.get()

        configuration[section] = values

        self.save(configuration)

    def get_dhcp_config(self):

        return self.get().get(
            "dhcp",
            {}
        )