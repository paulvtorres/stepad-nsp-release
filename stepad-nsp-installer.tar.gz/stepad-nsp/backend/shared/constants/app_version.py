import subprocess

from pathlib import Path


APP_VERSION = "1.0.0"

REPO_DIR = Path("/home/paulan/stepad-nsp")


def git_commit() -> str:

    try:

        result = subprocess.run(
            [
                "git", "-C", str(REPO_DIR),
                "-c", f"safe.directory={REPO_DIR}",
                "rev-parse", "--short", "HEAD"
            ],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0 and result.stdout.strip():

            return result.stdout.strip()

    except Exception:

        pass

    return "-"

def installed_version() -> str:

    try:

        marker = Path("/etc/stepad/version")

        if marker.exists():

            value = marker.read_text().strip()

            if value:

                return value

    except Exception:

        pass

    return APP_VERSION

