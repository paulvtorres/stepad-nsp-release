import subprocess

from pathlib import Path

from backend.shared.logging.logger import logger


APP_VERSION = "1.0.0"

REPO_DIR = Path(__file__).resolve().parents[3]


def git_commit() -> str:

    try:

        result = subprocess.run(
            [
                "git", "-C", str(REPO_DIR),
                "-c", f"safe.directory={REPO_DIR}",
                "rev-parse", "--short", "HEAD"
            ],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0 and result.stdout.strip():

            return result.stdout.strip()

    except Exception as error:
        logger.debug("app_version.git_commit: %s", error)
    return "-"

def installed_version() -> str:

    try:

        marker = Path("/etc/stepad/version")

        if marker.exists():

            value = marker.read_text().strip()

            if value:

                return value

    except Exception as error:
        logger.debug("app_version.installed_version: %s", error)
    return APP_VERSION