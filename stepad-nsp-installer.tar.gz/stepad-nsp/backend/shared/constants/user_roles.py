class UserRoles:

    ADMIN = "ADMIN"

    OPERATOR = "OPERATOR"