from enum import Enum


class RuleType(str, Enum):
    DOMAIN = "DOMAIN"
    IP = "IP"
    MAC = "MAC"
    URL = "URL"
    PORT = "PORT"