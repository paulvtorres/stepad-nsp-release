from enum import Enum


class RuleAction(str, Enum):
    BLOCK = "BLOCK"
    ALLOW = "ALLOW"