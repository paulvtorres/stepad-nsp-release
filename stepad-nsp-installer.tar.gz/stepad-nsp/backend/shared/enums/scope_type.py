from enum import Enum

class ScopeType(str, Enum):

    GLOBAL = "GLOBAL"

    ZONE = "ZONE"

    DEVICE = "DEVICE"