"""Typed application errors.

Domain code can raise these instead of importing FastAPI's HTTPException;
the global handler turns them into a consistent JSON body with a code and
a support reference.
"""


class AppError(Exception):
    status_code = 500
    code = "internal_error"

    def __init__(self, message: str | None = None, *, status_code=None, code=None):
        self.message = message or "Error interno del servidor"
        if status_code is not None:
            self.status_code = status_code
        if code is not None:
            self.code = code
        super().__init__(self.message)


class ValidationError(AppError):
    status_code = 400
    code = "validation_error"


class NotFoundError(AppError):
    status_code = 404
    code = "not_found"


class ConflictError(AppError):
    status_code = 409
    code = "conflict"


class PermissionDenied(AppError):
    status_code = 403
    code = "forbidden"


class ServiceUnavailable(AppError):
    status_code = 503
    code = "unavailable"
