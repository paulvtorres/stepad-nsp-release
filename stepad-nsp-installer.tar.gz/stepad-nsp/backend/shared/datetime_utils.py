"""Time helpers.

`utcnow()` returns a naive UTC datetime, matching what `datetime.utcnow()`
used to return (and what the database stores), but without the deprecated
call. For comparisons, normalize tz-aware values with
`backend.api.v1.routes.observability.naive_utc` (or `astimezone`).
"""

from datetime import datetime, timezone


def utcnow() -> datetime:

    return datetime.now(timezone.utc).replace(tzinfo=None)
