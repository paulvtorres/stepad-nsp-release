from datetime import datetime
from backend.shared.datetime_utils import utcnow

from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class RetentionSetting(Base):

    __tablename__ = "data_retention_settings"

    id: Mapped[int] = mapped_column(primary_key=True)

    data_type: Mapped[str] = mapped_column(
        String(64),
        unique=True,
        nullable=False,
        index=True
    )

    retention_days: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=90
    )

    enabled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True
    )

    last_run_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )

    last_deleted: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utcnow,
        onupdate=utcnow
    )
