import threading

from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.retention.services.retention_service import RetentionService
from backend.shared.logging.logger import logger


class RetentionComponent(BaseComponent):

    name = "retention"

    criticality = ComponentCriticality.OPTIONAL

    CHECK_INTERVAL_SECONDS = 3600

    def start(self):

        self._stop = threading.Event()

        # One pass at startup: applies a reduced retention right away and
        # seeds the table with the current values.
        RetentionService().run_all_safe()

        self._thread = threading.Thread(
            target=self._loop,
            name="retention-cleanup",
            daemon=True,
        )

        self._thread.start()

        logger.info(
            "RetentionComponent started (every %s s).",
            self.CHECK_INTERVAL_SECONDS,
        )

    def _loop(self):

        while not self._stop.wait(self.CHECK_INTERVAL_SECONDS):

            RetentionService().run_all_safe()

    def stop(self):

        self._stop.set()
