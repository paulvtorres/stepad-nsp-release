import ipaddress
import subprocess
import time

from datetime import datetime
from pathlib import Path

from sqlalchemy.orm import Session

from backend.core.config.paths import DNS_DIR
from backend.core.dnsmasq.process_manager import dnsmasq_process_manager

from backend.groups.repositories.device_group_repository import (
    DeviceGroupRepository
)
from backend.groups.models.device_group import DeviceGroup

from backend.content.models.content_category import (
    ContentCategory,
    CategoryDomain,
    GroupCategory,
)

from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository
)
from backend.shared.enums import RuleAction

from backend.network.devices.models.network_device import NetworkDevice

from backend.shared.logging.logger import logger


GROUPS_DNS_CONFIG = DNS_DIR / "groups_dns.conf"

GROUP_DIR = DNS_DIR / "group-dns"

PDNS_RECURSOR_BIN = "/usr/sbin/pdns_recursor"

REC_CONTROL_BIN = "/usr/bin/rec_control"

RPZ_TTL_SECONDS = 300

# Alias IPs on the LAN for each group's DNS server. The base is the
# LAN gateway; each group gets gateway + 10 + index (assumes the DHCP
# pool starts above that).
ALIAS_BASE_OFFSET = 10


class GroupDnsService:

    def __init__(self):

        self.repository = DeviceGroupRepository()

        self.rule_repository = DeviceAccessRuleRepository()

    # ------------------------------------------------------------------
    # Blocklist computation
    # ------------------------------------------------------------------

    def group_blocklist(
        self,
        db: Session,
        group: DeviceGroup
    ) -> list[str]:
        """
        Effective blocklist for a group:
          (global default blocks - group ALLOWs) | group BLOCKs | permanent blocks
        """

        now = datetime.utcnow()

        all_global = self.rule_repository.find_global_domains(db)

        permanent = {
            rule.value.strip().lower()
            for rule in all_global
            if rule.is_permanent
        }

        default = {
            rule.value.strip().lower()
            for rule in all_global
            if not rule.is_permanent
        }

        group_rules = (
            db.query(DeviceAccessRule)
            .filter(DeviceAccessRule.group_id == group.id)
            .all()
        )

        allows = {
            rule.value.strip().lower()
            for rule in group_rules
            if rule.action == RuleAction.ALLOW
        }

        blocks = {
            rule.value.strip().lower()
            for rule in group_rules
            if rule.action == RuleAction.BLOCK
        }

        # Categorias de contenido seleccionadas para este grupo
        # (perfil de navegacion por area). Sus dominios se suman al
        # blocklist del grupo.
        group_category_ids = {
            row.category_id
            for row in db.query(GroupCategory)
            .filter(GroupCategory.group_id == group.id)
            .all()
        }

        if group_category_ids:

            category_domains = (
                db.query(CategoryDomain)
                .filter(CategoryDomain.category_id.in_(group_category_ids))
                .all()
            )

            blocks |= {
                row.domain.strip().lower()
                for row in category_domains
            }

        effective = (default - allows) | blocks | permanent

        return sorted(effective)

    # ------------------------------------------------------------------
    # Alias IP allocation
    # ------------------------------------------------------------------

    def group_alias_ip(
        self,
        db: Session,
        group: DeviceGroup
    ) -> str | None:
        """
        Returns the LAN alias IP where this group's DNS will listen.
        Derived from the LAN gateway + ALIAS_BASE_OFFSET + index.
        """

        try:

            from backend.network.interfaces.services.interface_service import (
                InterfaceService
            )

            lan = InterfaceService().get_primary_lan()

            if lan is None:

                return None

            from backend.shared.config.config_service import ConfigService

            network = ConfigService().get_dhcp_config().get("network")

            if not network:

                return None

            net = ipaddress.ip_network(network, strict=False)

            hosts = list(net.hosts())

            if not hosts:

                return None

            return str(hosts[0] + ALIAS_BASE_OFFSET + (group.id - 1))

        except Exception as error:

            logger.warning(
                f"Could not allocate group DNS alias: {error}"
            )

            return None

    # ------------------------------------------------------------------
    # Per-group recursor
    # ------------------------------------------------------------------

    def _ensure_recursor(
        self,
        group: DeviceGroup,
        alias_ip: str,
        blocklist: list[str]
    ):

        group_dir = GROUP_DIR / str(group.id)

        group_dir.mkdir(parents=True, exist_ok=True)

        rpz_file = group_dir / "blocked_domains.rpz"

        lua_file = group_dir / "rpz.lua"

        pid_file = group_dir / "pdns.pid"

        # Put the alias IP on the LAN interface (idempotent).
        try:

            from backend.network.interfaces.services.interface_service import (
                InterfaceService
            )

            lan = InterfaceService().get_primary_lan()

            if lan:

                subprocess.run(
                    ["ip", "addr", "add", f"{alias_ip}/24", "dev", lan.name],
                    capture_output=True,
                    timeout=10
                )

        except Exception:

            pass

        # RPZ zone file.
        lines = ["$TTL 300\n@ IN SOA localhost. root.localhost. ( 1 300 300 300 300 )\n@ IN NS localhost.\n"]

        for domain in blocklist:

            lines.append(f"{domain} IN CNAME .\n")

        rpz_file.write_text("".join(lines))

        lua_file.write_text(
            f'rpzFile("{rpz_file}", '
            f'{{defpol=Policy.NXDOMAIN, policyName="stepad-group-{group.id}"}})\n'
        )

        recursor_yml = group_dir / "recursor.yml"

        # Formato YAML de PowerDNS 5.2 (incoming/recursor). El recursor
        # de grupo recusa de forma independiente: necesita hint_file.
        recursor_yml.write_text(
            "incoming:\n"
            "  listen:\n"
            f"  - {alias_ip}\n"
            "  allow_from:\n"
            "  - 0.0.0.0/0\n"
            "recursor:\n"
            f"  lua_config_file: {lua_file}\n"
            # Socket de control PROPIO del grupo: sin esto pdns usa el
            # socket por defecto y choca con el recursor principal -> el
            # reload del RPZ iba al recursor equivocado y el bloqueo era
            # intermitente (a veces resolvia lo bloqueado).
            f"  socket_dir: {group_dir}\n"
            "  hint_file: /usr/share/dns/root.hints\n"
            "  security_poll_suffix: \"\"\n"
            "dnssec:\n"
            "  validation: \"off\"\n"
        )


        # Detectar recursor ya corriendo para este grupo (por config-dir;
        # el pid_file no se escribe porque la config no define pid-file).
        pids = subprocess.run(
            ["pgrep", "-f", f"config-dir={group_dir}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        running = any(p.strip() for p in pids.stdout.split())

        socket_path = str(group_dir / "pdns_recursor.controlsocket")

        if running:

            # Ya corre: SOLO se recarga el RPZ (sin reiniciar, sin ventana
            # de no-bloqueo) y se vacia la cache de los dominios
            # bloqueados (pdns sirve respuestas positivas cacheadas de
            # antes del bloqueo hasta que expiren).
            subprocess.run(
                [REC_CONTROL_BIN, "-s", socket_path, "reload-lua-config"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            try:
                subprocess.run(
                    [REC_CONTROL_BIN, "-s", socket_path, "wipe-cache"]
                    + blocklist,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            except Exception:
                pass
            return alias_ip

        subprocess.run(
            [PDNS_RECURSOR_BIN, "--daemon=yes", "--config-dir=" + str(group_dir)],
            capture_output=True,
            timeout=10
        )

        return alias_ip

    def _write_dhcp_conf(
        self,
        db: Session,
        groups: list[tuple[DeviceGroup, str, list[str]]]
    ):
        """
        Writes groups_dns.conf for dnsmasq: tags each device to its
        group and hands the group's DNS alias to tagged clients. Only
        restarts dnsmasq if the file actually changed.
        """

        lines = ["# Auto-generated group DNS assignment -- do not edit by hand.\n"]

        # Un dispositivo pertenece a UN SOLO grupo DNS. Si esta en
        # varios, el grupo especifico (no por defecto) gana; el grupo
        # por defecto solo aplica si el dispositivo no esta en otro.
        mac_to_group = {}

        for group, alias_ip, blocklist in groups:

            is_default = bool(getattr(group, "is_default", False))

            device_ids = self.repository.device_ids(db, group.id)

            for device_id in device_ids:

                device = db.get(NetworkDevice, device_id)

                if not device or not device.mac_address:

                    continue

                mac = device.mac_address

                current = mac_to_group.get(mac)

                if current is None or (current["default"] and not is_default):

                    mac_to_group[mac] = {
                        "group_id": group.id,
                        "default": is_default,
                    }

        for mac, info in mac_to_group.items():

            lines.append(f"dhcp-host={mac},set:grp{info['group_id']}\n")

        for group, alias_ip, blocklist in groups:

            if any(
                info["group_id"] == group.id
                for info in mac_to_group.values()
            ):

                lines.append(f"dhcp-option=tag:grp{group.id},6,{alias_ip}\n")

        content = "".join(lines)

        GROUPS_DNS_CONFIG.parent.mkdir(parents=True, exist_ok=True)

        previous = (
            GROUPS_DNS_CONFIG.read_text(encoding="utf-8")
            if GROUPS_DNS_CONFIG.exists()
            else ""
        )

        if content != previous:

            GROUPS_DNS_CONFIG.write_text(content)

            dnsmasq_process_manager.restart()

        return True

    # ------------------------------------------------------------------
    # Public sync entry points
    # ------------------------------------------------------------------

    def sync_group(
        self,
        db: Session,
        group_id: int
    ):

        try:

            group = self.repository.find_by_id(db, group_id)

            if group is None:

                return

            self._sync_all(db)

        except Exception as error:

            logger.exception(f"Group DNS sync failed: {error}")

    def sync_device(
        self,
        db: Session,
        device_id: int
    ):

        try:

            self._sync_all(db)

        except Exception as error:

            logger.exception(f"Device DNS sync failed: {error}")

    def sync_all(
        self,
        db: Session
    ):

        try:

            self._sync_all(db)

        except Exception as error:

            logger.exception(f"Group DNS sync_all failed: {error}")

    def _sync_all(
        self,
        db: Session
    ):

        groups = self.repository.find_all(db)

        entries = []

        for group in groups:

            device_ids = self.repository.device_ids(db, group.id)

            if not device_ids:

                continue

            alias_ip = self.group_alias_ip(db, group)

            if alias_ip is None:

                continue

            blocklist = self.group_blocklist(db, group)

            self._ensure_recursor(group, alias_ip, blocklist)

            entries.append((group, alias_ip, blocklist))

        self._write_dhcp_conf(db, entries)

        logger.info(
            f"Group DNS synced ({len(entries)} active groups)."
        )


group_dns_service = GroupDnsService()
