import os
import subprocess
import threading

from sqlalchemy.orm import Session

from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.logging.logger import logger

RULES_FILE = "/var/lib/suricata/rules/stepad-sni.rules"
SURICATA_YAML = "/etc/suricata/suricata.yaml"
SNI_YAML_ENTRY = "- /var/lib/suricata/rules/stepad-sni.rules"
RULES_HEADER = ""

NFT = "/usr/sbin/nft"
IP_COMMENT_PREFIX = "stepad-ipblock"

REFRESH_INTERVAL_SECONDS = 6 * 3600
FIRST_REFRESH_SECONDS = 120
SNI_BASE_SID = 900000
LEASES_FILE = "/var/lib/misc/dnsmasq.leases"
MAX_IPS_PER_GROUP = 500

# Infraestructura compartida de Google que NUNCA debe bloquearse por
# SNI (Gmail, Drive, Search, Fonts, reCAPTCHA, Analytics...). Solo se
# bloquean los dominios especificos de YouTube/lo que el grupo marque.
NEVER_BLOCK_SUFFIXES = (
    "google.com",
    "googleapis.com",
    "gstatic.com",
    "googleusercontent.com",
)

# IPs de la cache de Google del ISP (Google Global Cache / GGC) que
# sirven el video y audio de YouTube. Son por ISP: ajustar en cada
# despliegue si el video sale por la cache local del proveedor.
EXTRA_BLOCKED_IPS = [
    "45.162.73.216",
    "45.162.73.217",
    "45.162.73.236",
    "45.162.73.237",
]


class SniBlockService:
    """
    Bloqueo por SNI (Suricata) por equipo.

    El bloqueo por IP de Google rompe Gmail/Drive porque YouTube comparte
    la infraestructura de Google. Aqui se bloquea SOLO por nombre de host:
    Suricata (IPS) mira el SNI del saludo TLS de cada conexion y la corta
    si el host pertenece a un dominio bloqueado por el grupo del equipo.

    Se genera UNA regla por (equipo, dominio bloqueado):
      drop tls <ip> any -> any any (tls.sni; pcre:"/patron/i"; ...)
    Nota: en el archivo de reglas el patron usa `\.` (literal).
    """

    def __init__(self):
        self._thread = None
        self._stop = threading.Event()

    # ------------------------------------------------------------------
    # Data helpers
    # ------------------------------------------------------------------

    def _group(self, db: Session, group_id: int):
        from backend.groups.models.device_group import DeviceGroup
        return (
            db.query(DeviceGroup)
            .filter(DeviceGroup.id == group_id)
            .first()
        )

    def _group_device_macs(self, db: Session, group_id: int) -> list[str]:
        from backend.groups.repositories.device_group_repository import (
            DeviceGroupRepository
        )
        device_ids = DeviceGroupRepository().device_ids(db, group_id)
        if not device_ids:
            return []
        rows = (
            db.query(NetworkDevice.mac_address)
            .filter(NetworkDevice.id.in_(device_ids))
            .all()
        )
        macs = []
        for (mac,) in rows:
            mac = mac.strip().lower()
            if mac:
                macs.append(mac)
        return macs

    def _group_blocklist(self, db: Session, group) -> list[str]:
        from backend.groups.services.group_dns_service import (
            group_dns_service
        )
        try:
            return group_dns_service.group_blocklist(db, group) or []
        except Exception as error:
            logger.exception(f"group_blocklist failed: {error}")
            return []

    def _lease_ips(self) -> dict[str, str]:
        result: dict[str, str] = {}
        try:
            with open(LEASES_FILE) as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 3:
                        result[parts[1].strip().lower()] = parts[2].strip()
        except Exception:
            pass
        return result

    def _device_ips(self, db: Session, macs: list[str]) -> list[str]:
        leases = self._lease_ips()
        ips = []
        for mac in macs:
            ip = leases.get(mac)
            if not ip:
                row = (
                    db.query(NetworkDevice.ip_address)
                    .filter(NetworkDevice.mac_address == mac)
                    .first()
                )
                ip = row[0] if row else None
            if ip:
                ips.append(ip)
        return ips

    def _is_allowed(self, domain: str) -> bool:
        d = domain.strip().lower()
        return not any(
            d == s or d.endswith("." + s)
            for s in NEVER_BLOCK_SUFFIXES
        )

    def _parents(self, domains: list[str]) -> list[str]:
        """Deja solo los dominios que no son subdominios de otro de la
        lista (youtube.com cubre www.youtube.com -> se elimina el hijo)."""
        unique = sorted(set(domains))
        result = []
        for d in unique:
            if any(
                d.endswith("." + other)
                for other in unique
                if other != d
            ):
                continue
            result.append(d)
        return result

    def _escape(self, domain: str) -> str:
        return domain.replace(".", "\\.")

    # ------------------------------------------------------------------
    # Rule generation
    # ------------------------------------------------------------------

    def _build_rules(self, entries: list[tuple[str, str]]) -> list[str]:
        lines = []
        seen = set()
        sid = SNI_BASE_SID
        for ip, domain in entries:
            key = (ip, domain)
            if key in seen:
                continue
            seen.add(key)
            escaped = self._escape(domain)
            # TLS (TCP) y QUIC (UDP/HTTP3): el video/audio de YouTube va
            # por QUIC; ambas reglas se generan para cubrir ambos.
            lines.append(
                f'drop tls {ip} any -> any any '
                f'(tls.sni; pcre:"/(^|\\.){escaped}$/i"; '
                f'sid:{sid}; rev:1;)'
            )
            sid += 1
            lines.append(
                f'drop quic {ip} any -> any any '
                f'(quic.sni; pcre:"/(^|\\.){escaped}$/i"; '
                f'sid:{sid}; rev:1;)'
            )
            sid += 1
        return lines

    def _write_file(self, lines: list[str]):
        content = "\n".join(lines)
        if lines:
            content += "\n"
        tmp = RULES_FILE + ".tmp"
        try:
            os.makedirs(os.path.dirname(RULES_FILE), exist_ok=True)
            with open(tmp, "w") as f:
                f.write(content)
            os.replace(tmp, RULES_FILE)
        except Exception as error:
            logger.error(f"SNI rules write fallo: {error}")

    def _ensure_yaml(self):
        try:
            with open(SURICATA_YAML) as f:
                content = f.read()
            if not content.startswith("%YAML 1.1"):
                content = "%YAML 1.1\n---\n" + content
            if SNI_YAML_ENTRY not in content:
                content = content.replace(
                    "- suricata.rules",
                    "- suricata.rules\n" + SNI_YAML_ENTRY,
                    1,
                )
            with open(SURICATA_YAML, "w") as f:
                f.write(content)
        except Exception as error:
            logger.error(f"Suricata yaml update fallo: {error}")

    def _reload(self):
        # Si suricata no esta corriendo no hay nada que recargar (el
        # bloqueo DNS+IP sigue activo) y no se pierde tiempo aqui.
        try:
            status = subprocess.run(
                ["systemctl", "is-active", "suricata"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if status.stdout.strip() != "active":
                return
        except Exception:
            return

        # Reload rapido de reglas (suricatasc, sin reiniciar el proceso).
        # El restart de systemd tarda ~10s y bloquea las respuestas de la
        # API (reglas/equipos que parecen "no hacer nada"). Si el socket
        # no esta disponible, se cae al restart.
        try:
            result = subprocess.run(
                ["suricatasc", "-c", "reload-rules"],
                capture_output=True,
                text=True,
                timeout=8,
            )
            if result.returncode == 0:
                return
        except Exception:
            pass
        try:
            subprocess.run(
                ["systemctl", "restart", "suricata"],
                capture_output=True,
                text=True,
                timeout=30,
            )
        except Exception as error:
            logger.error(f"Suricata reload fallo: {error}")

    # ------------------------------------------------------------------
    # Sync
    # ------------------------------------------------------------------

    def _compute(self, db: Session) -> list[tuple[str, str]]:
        from backend.groups.repositories.device_group_repository import (
            DeviceGroupRepository
        )
        entries: list[tuple[str, str]] = []
        for group in DeviceGroupRepository().find_all(db):
            blocklist = self._group_blocklist(db, group)
            if not blocklist:
                continue
            macs = self._group_device_macs(db, group.id)
            if not macs:
                continue
            ips = self._device_ips(db, macs)
            if not ips:
                continue
            domains = self._parents(
                [d for d in blocklist if self._is_allowed(d)]
            )
            if not domains:
                continue
            for ip in ips:
                for d in domains:
                    entries.append((ip, d))
        return entries

    # ------------------------------------------------------------------
    # IP block (specific resolved IPs, per device)
    # ------------------------------------------------------------------

    def _ip_set_name(self, gid: int) -> str:
        return f"stepad_grp_ips_v4_{gid}"

    def _lan_interface(self) -> str | None:
        try:
            from backend.network.interfaces.services.interface_service import (
                InterfaceService
            )
            lan = InterfaceService().get_primary_lan()
            return lan.name if lan else None
        except Exception:
            return None

    def _run(self, cmd):
        try:
            return subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
        except Exception:
            return None

    def _blocked_ips(self, domains: list[str]) -> list[str]:
        import ipaddress
        ips: set[str] = set(EXTRA_BLOCKED_IPS)
        for domain in domains:
            if len(ips) >= MAX_IPS_PER_GROUP:
                break
            result = self._run(
                ["dig", "+short", "+timeout=3", "+tries=1",
                 "A", domain, "@8.8.8.8"]
            )
            if result is None or result.returncode != 0:
                continue
            for line in result.stdout.splitlines():
                line = line.strip()
                try:
                    ips.add(str(ipaddress.IPv4Address(line)))
                except ValueError:
                    continue
        return list(ips)[:MAX_IPS_PER_GROUP]

    def _ip_rule_exists(self, comment: str) -> bool:
        result = self._run([NFT, "list", "chain", "inet", "stepad", "forward"])
        return bool(result and result.returncode == 0 and comment in result.stdout)

    def _delete_ip_rule(self, comment: str):
        result = self._run([NFT, "-a", "list", "chain", "inet", "stepad", "forward"])
        if result is None or result.returncode != 0:
            return
        for line in result.stdout.splitlines():
            if comment in line and "handle" in line:
                handle = line.split("handle")[1].strip().split()[0]
                self._run(
                    [NFT, "delete", "rule", "inet", "stepad", "forward", "handle", handle]
                )
                return

    def _ensure_ip_set(self, name: str):
        self._run(
            [NFT, "add", "set", "inet", "stepad", name,
             "{", "type", "ipv4_addr", ";", "}"]
        )

    def _flush_ip_set(self, name: str):
        self._run([NFT, "flush", "set", "inet", "stepad", name])

    def _add_ip_elements(self, name: str, elements: list[str]):
        for i in range(0, len(elements), 64):
            chunk = elements[i:i + 64]
            args = [NFT, "add", "element", "inet", "stepad", name, "{"]
            for j, el in enumerate(chunk):
                args.append(el + ("," if j < len(chunk) - 1 else ""))
            args.append("}")
            result = self._run(args)
            if result is None or result.returncode != 0:
                logger.error(
                    f"nft add element {name} fallo: "
                    f"{result.stderr.strip() if result else 'run failed'}"
                )

    def _apply_group_ip_block(
        self,
        db: Session,
        group,
        lan: str | None,
    ):
        macs = self._group_device_macs(db, group.id)
        blocklist = self._group_blocklist(db, group)
        if not macs or not blocklist:
            self._remove_group_ip_block(group.id)
            return

        domains = self._parents(
            [d for d in blocklist if self._is_allowed(d)]
        )
        ips = self._blocked_ips(domains)
        if not ips:
            self._remove_group_ip_block(group.id)
            return

        set_name = self._ip_set_name(group.id)
        self._ensure_ip_set(set_name)
        self._flush_ip_set(set_name)
        self._add_ip_elements(set_name, ips)

        for mac in macs:
            comment = f"{IP_COMMENT_PREFIX}-{group.id}-{mac}"
            if self._ip_rule_exists(comment):
                continue
            args = [NFT, "insert", "rule", "inet", "stepad", "forward"]
            if lan:
                args += ["iifname", lan]
            args += [
                "ether", "saddr", mac,
                "ip", "daddr", f"@{set_name}",
                "counter", "drop",
                "comment", f'"{comment}"',
            ]
            self._run(args)

        logger.info(
            f"Group {group.id} IP block: {len(macs)} equipos, "
            f"{len(ips)} IPs especificas."
        )

    def _remove_group_ip_block(self, gid: int):
        result = self._run([NFT, "-a", "list", "chain", "inet", "stepad", "forward"])
        comments = []
        if result and result.returncode == 0:
            for line in result.stdout.splitlines():
                if IP_COMMENT_PREFIX not in line:
                    continue
                marker = f"{IP_COMMENT_PREFIX}-{gid}-"
                if marker in line and "handle" in line:
                    handle = line.split("handle")[1].strip().split()[0]
                    self._run(
                        [NFT, "delete", "rule", "inet", "stepad", "forward", "handle", handle]
                    )
        self._run([NFT, "delete", "set", "inet", "stepad", self._ip_set_name(gid)])

    def _sync_ip_block(self, db: Session):
        from backend.groups.repositories.device_group_repository import (
            DeviceGroupRepository
        )
        lan = self._lan_interface()
        groups = DeviceGroupRepository().find_all(db)
        active_markers = []
        for group in groups:
            self._apply_group_ip_block(db, group, lan)
            active_markers.append(f"{IP_COMMENT_PREFIX}-{group.id}-")
        result = self._run([NFT, "-a", "list", "chain", "inet", "stepad", "forward"])
        if result and result.returncode == 0:
            for line in result.stdout.splitlines():
                if IP_COMMENT_PREFIX not in line or "handle" not in line:
                    continue
                if not any(m in line for m in active_markers):
                    handle = line.split("handle")[1].strip().split()[0]
                    self._run(
                        [NFT, "delete", "rule", "inet", "stepad", "forward", "handle", handle]
                    )

    def sync_all(self, db: Session):
        try:
            entries = self._compute(db)
            rules = self._build_rules(entries)
            self._write_file(rules)
            self._ensure_yaml()
            self._reload()
            self._sync_ip_block(db)
            logger.info(
                f"SNI block aplicado: {len(entries)} reglas "
                f"({len(rules)} unicas)."
            )
        except Exception as error:
            logger.exception(f"SNI block sync_all failed: {error}")

    def sync_group(self, db: Session, group_id: int):
        self.sync_all(db)

    # ------------------------------------------------------------------
    # Periodic re-resolution
    # ------------------------------------------------------------------

    def start_refresh_timer(self):
        if self._thread and self._thread.is_alive():
            return

        self._stop.clear()

        def _refresh():
            try:
                from backend.core.database.session import SessionLocal
                db = SessionLocal()
                try:
                    self.sync_all(db)
                finally:
                    db.close()
            except Exception as error:
                logger.exception(f"SNI block refresh failed: {error}")

        def loop():
            if not self._stop.wait(FIRST_REFRESH_SECONDS):
                _refresh()
            while not self._stop.is_set():
                if self._stop.wait(REFRESH_INTERVAL_SECONDS):
                    break
                _refresh()

        self._thread = threading.Thread(
            target=loop,
            daemon=True,
            name="group-sni-block-refresh",
        )
        self._thread.start()
        logger.info("SNI block refresh timer iniciado.")

    def stop_refresh_timer(self):
        self._stop.set()


sni_block_service = SniBlockService()
