from sqlalchemy.orm import Session

from backend.groups.models.device_group import DeviceGroup, GroupDevice


class DeviceGroupRepository:

    def find_all(
        self,
        db: Session
    ):

        return db.query(DeviceGroup).order_by(DeviceGroup.id).all()

    def find_by_id(
        self,
        db: Session,
        group_id: int
    ):

        return db.get(DeviceGroup, group_id)

    def find_default(
        self,
        db: Session
    ):

        return (
            db.query(DeviceGroup)
            .filter(DeviceGroup.is_default.is_(True))
            .first()
        )

    def device_ids(
        self,
        db: Session,
        group_id: int
    ):

        rows = (
            db.query(GroupDevice.device_id)
            .filter(GroupDevice.group_id == group_id)
            .all()
        )

        return [row[0] for row in rows]

    def group_ids_for_device(
        self,
        db: Session,
        device_id: int
    ):

        rows = (
            db.query(GroupDevice.group_id)
            .filter(GroupDevice.device_id == device_id)
            .all()
        )

        return [row[0] for row in rows]

    def add_device(
        self,
        db: Session,
        group_id: int,
        device_id: int
    ):

        exists = (
            db.query(GroupDevice)
            .filter(
                GroupDevice.group_id == group_id,
                GroupDevice.device_id == device_id
            )
            .first()
        )

        if exists:

            return False

        db.add(GroupDevice(group_id=group_id, device_id=device_id))

        db.commit()

        return True

    def remove_device(
        self,
        db: Session,
        group_id: int,
        device_id: int
    ):

        db.query(GroupDevice).filter(
            GroupDevice.group_id == group_id,
            GroupDevice.device_id == device_id
        ).delete(synchronize_session=False)

        db.commit()

    def save(
        self,
        db: Session,
        group: DeviceGroup
    ):

        db.add(group)

        db.commit()

        db.refresh(group)

        return group

    def delete(
        self,
        db: Session,
        group: DeviceGroup
    ):

        db.query(GroupDevice).filter(
            GroupDevice.group_id == group.id
        ).delete(synchronize_session=False)

        db.delete(group)

        db.commit()
