from sqlalchemy import Boolean, DateTime, Integer, String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class VpnPeer(Base):

    __tablename__ = "vpn_peers"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False
    )


    public_key: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        unique=True
    )


    # Client address inside the VPN (e.g. 10.200.0.2/32)
    allowed_ip: Mapped[str] = mapped_column(
        String(18),
        nullable=False,
        unique=True
    )


    # Justification/documentation for the authorization (Requerimiento 3).
    client_note: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # NULL = permanent; set = temporary access revoked automatically.
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    created_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id"),
        nullable=True
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
