import os
import subprocess

from pathlib import Path

from backend.shared.logging.logger import logger


def ensure_self_signed_cert(
    cert_path: str,
    key_path: str
) -> bool:
    """
    Generates a self-signed certificate for the web UI on first run
    (10 years). The operator trusts it once in the browser; the
    alternative is a real CA cert via STEPAD_TLS_CERT/STEPAD_TLS_KEY.
    """

    cert = Path(cert_path)

    key = Path(key_path)

    if cert.exists() and key.exists():

        return True

    cert.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    result = subprocess.run(
        [
            "openssl", "req",
            "-x509", "-newkey", "rsa:2048", "-nodes",
            "-days", "3650",
            "-keyout", str(key),
            "-out", str(cert),
            "-subj", "/CN=stepad-nsp",
            "-addext", "subjectAltName=DNS:stepad-nsp,IP:0.0.0.0"
        ],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:

        logger.error(
            f"Failed to generate TLS certificate: {result.stderr.strip()}"
        )

        return False

    os.chmod(key, 0o600)

    logger.info(
        f"Self-signed TLS certificate generated: {cert}"
    )

    return True
