from datetime import datetime, timedelta

from fastapi import HTTPException

from sqlalchemy.orm import Session

from backend.vpn.models.vpn_peer import VpnPeer
from backend.vpn.repositories.vpn_peer_repository import VpnPeerRepository
from backend.vpn.services.wireguard_provider import WireGuardProvider

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.audit.services.audit_service import AuditService

from backend.core.config.settings import Settings

from backend.shared.logging.logger import logger


class VpnService:

    def __init__(self):

        self.repository = VpnPeerRepository()

        self.provider = WireGuardProvider()

        self.interface_service = InterfaceService()

        self.audit_service = AuditService()

    def _wan_names(
        self
    ) -> list[str]:

        wans = self.interface_service.get_wan_interfaces()

        return [wan.name for wan in wans]

    def get_status(
        self,
        db: Session
    ):

        peers = self.repository.find_all(db)

        sessions = self.provider.sessions()

        return {
            "interface": self.provider.INTERFACE,
            "address": self.provider.ADDRESS,
            "listen_port": self.provider.LISTEN_PORT,
            "public_key": self.provider.server_public_key(),
            "peers": len(peers),
            "active_sessions": sum(
                1 for s in sessions if s.get("active")
            )
        }

    def list_peers(
        self,
        db: Session
    ):

        # Revoke any expired temporary peer now (not only at boot) --
        # the UI polls this endpoint, so an expiry is enforced within
        # seconds of its deadline.
        self.sweep_expired(db)

        live = {
            s["public_key"]: s
            for s in self.provider.sessions()
        }

        peers = self.repository.find_all(db)

        result = []

        for peer in peers:

            item = {
                "id": peer.id,
                "name": peer.name,
                "public_key": peer.public_key,
                "allowed_ip": peer.allowed_ip,
                "client_note": peer.client_note,
                "expires_at": (
                    peer.expires_at.isoformat()
                    if peer.expires_at else None
                ),
                "enabled": peer.enabled,
                "created_at": peer.created_at.isoformat(),
            }

            session = live.get(peer.public_key)

            if session:

                item["active"] = session.get("active", False)

                item["endpoint"] = session.get("endpoint")

                item["last_handshake_seconds_ago"] = (
                    session.get("active_seconds_ago")
                )

            else:

                item["active"] = False

                item["endpoint"] = None

                item["last_handshake_seconds_ago"] = None

            result.append(item)

        return result

    def create_peer(
        self,
        db: Session,
        request,
        created_by: int
    ):

        allowed_ip = self.repository.next_allowed_ip(db)

        if not allowed_ip:

            raise HTTPException(
                status_code=400,
                detail="VPN address pool exhausted"
            )

        keys = self.provider.run_command(
            ["bash", "-c",
             'P=$(/usr/bin/wg genkey); echo "$P"; echo "$P" | /usr/bin/wg pubkey']
        )

        lines = keys["output"].strip().splitlines()

        private_key = lines[0].strip() if lines else ""

        public_key = lines[1].strip() if len(lines) > 1 else ""

        if not private_key or not public_key:

            raise HTTPException(
                status_code=500,
                detail="Failed to generate WireGuard keys"
            )

        expires_at = None

        if request.expires_at:

            try:

                expires_at = datetime.fromisoformat(
                    str(request.expires_at)
                )

            except ValueError:

                raise HTTPException(
                    status_code=400,
                    detail="Invalid expires_at (use ISO datetime)"
                )

        peer = VpnPeer(
            name=request.name,
            public_key=public_key,
            allowed_ip=allowed_ip,
            client_note=request.client_note or None,
            expires_at=expires_at,
            created_by=created_by,
            enabled=True
        )

        saved = self.repository.save(db, peer)

        self.provider.apply_peer(saved)

        self.audit_service.create_log(
            db=db,
            user_id=created_by,
            action="VPN_PEER_CREATED",
            resource="VPN",
            description=(
                f"Created VPN peer {saved.name} "
                f"({saved.allowed_ip})"
            )
        )

        return {
            "peer": next(
                (p for p in self.list_peers(db) if p["id"] == saved.id),
                None
            ),
            "private_key": private_key,
            "config": self._client_config(saved, private_key)
        }

    def _client_config(
        self,
        peer,
        private_key: str
    ) -> str:

        return (
            "[Interface]\n"
            f"PrivateKey = {private_key}\n"
            f"Address = {peer.allowed_ip}\n\n"
            "[Peer]\n"
            f"PublicKey = {self.provider.server_public_key()}\n"
            f"Endpoint = <IP_DEL_NSP>:{self.provider.LISTEN_PORT}\n"
            "AllowedIPs = 10.200.0.0/24\n"
            "PersistentKeepalive = 25\n"
        )

    def update_peer(
        self,
        db: Session,
        peer_id: int,
        request,
        changed_by: int
    ):

        peer = self.repository.find_by_id(db, peer_id)

        if peer is None:

            raise HTTPException(
                status_code=404,
                detail="VPN peer not found"
            )

        if request.name is not None:
            peer.name = request.name

        if request.client_note is not None:
            peer.client_note = request.client_note or None

        if request.enabled is not None:
            peer.enabled = request.enabled

        if request.expires_at is not None:
            try:
                peer.expires_at = datetime.fromisoformat(
                    str(request.expires_at)
                ) if request.expires_at else None
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail="Invalid expires_at (use ISO datetime)"
                )

        db.commit()

        db.refresh(peer)

        self.provider.apply_peer(peer)

        self.audit_service.create_log(
            db=db,
            user_id=changed_by,
            action="VPN_PEER_UPDATED",
            resource="VPN",
            description=f"Updated VPN peer {peer.name}"
        )

        return peer

    def delete_peer(
        self,
        db: Session,
        peer_id: int,
        changed_by: int
    ):

        peer = self.repository.find_by_id(db, peer_id)

        if peer is None:

            raise HTTPException(
                status_code=404,
                detail="VPN peer not found"
            )

        self.provider.remove_peer(peer)

        self.repository.delete(db, peer)

        self.audit_service.create_log(
            db=db,
            user_id=changed_by,
            action="VPN_PEER_DELETED",
            resource="VPN",
            description=f"Removed VPN peer {peer.name}"
        )

        return {"success": True}

    def sweep_expired(
        self,
        db: Session
    ):

        expired = self.repository.find_expired(db, datetime.utcnow())

        removed = 0

        for peer in expired:

            self.provider.remove_peer(peer)

            self.repository.delete(db, peer)

            self.audit_service.create_log(
                db=db,
                user_id=None,
                action="VPN_PEER_EXPIRED",
                resource="VPN",
                description=(
                    f"Temporary VPN peer {peer.name} "
                    f"({peer.allowed_ip}) expired and was revoked"
                )
            )

            removed += 1

        if removed:

            logger.info(f"VPN: revoked {removed} expired peer(s).")

        return {"removed": removed}

    def sync(
        self,
        db: Session
    ):

        peers = self.repository.find_all(db)

        for peer in peers:

            self.provider.apply_peer(peer)

        # Remote-admin enforcement is opt-in (STEPAD_VPN_REQUIRE_REMOTE_ADMIN,
        # default OFF): never apply it automatically -- it can cut the
        # operator's own management path (see incident on 2026-08-06).
        if Settings.VPN_REQUIRE_REMOTE_ADMIN:

            self.provider.restrict_admin_input(self._wan_names())

        return {"success": True, "peers": len(peers)}
