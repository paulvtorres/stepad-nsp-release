import subprocess

from pathlib import Path

from backend.core.config.settings import Settings

from backend.shared.logging.logger import logger


class WireGuardProvider:

    CONFIG_DIR = Path("/etc/stepad/wireguard")

    SERVER_PRIVATE_KEY = CONFIG_DIR / "server_private.key"

    SERVER_PUBLIC_KEY = CONFIG_DIR / "server_public.key"

    INTERFACE = "wg0"

    ADDRESS = "10.200.0.1/24"

    LISTEN_PORT = "51820"


    def run_command(
        self,
        command: list[str]
    ):

        result = subprocess.run(
            command,
            capture_output=True,
            text=True
        )

        return {
            "success": result.returncode == 0,
            "output": result.stdout.strip(),
            "error": result.stderr.strip()
        }

    def _wg(
        self,
        *args: str
    ):

        return self.run_command(["/usr/bin/wg", *args])

    def ensure_server_keys(
        self
    ):

        self.CONFIG_DIR.mkdir(
            parents=True,
            exist_ok=True
        )

        if not self.SERVER_PRIVATE_KEY.exists():

            key = self.run_command(["/usr/bin/wg", "genkey"])

            if not key["success"]:

                return key

            self.SERVER_PRIVATE_KEY.write_text(
                key["output"] + "\n"
            )

            self.SERVER_PRIVATE_KEY.chmod(0o600)

        if not self.SERVER_PUBLIC_KEY.exists():

            pub = self.run_command(
                ["bash", "-c",
                 f"/usr/bin/wg pubkey < {self.SERVER_PRIVATE_KEY}"]
            )

            if not pub["success"]:

                return pub

            self.SERVER_PUBLIC_KEY.write_text(
                pub["output"] + "\n"
            )

        return {"success": True}

    def ensure_interface(
        self
    ):

        # Idempotent setup of wg0.
        add = self.run_command([
            "ip", "link", "add", self.INTERFACE,
            "type", "wireguard"
        ])

        self.run_command([
            "ip", "addr", "add", self.ADDRESS,
            "dev", self.INTERFACE
        ])

        self.run_command([
            "ip", "link", "set", self.INTERFACE, "up"
        ])

        key = self.SERVER_PRIVATE_KEY.read_text().strip()

        self._wg("set", self.INTERFACE,
                 "listen-port", self.LISTEN_PORT,
                 "private-key", self.SERVER_PRIVATE_KEY)

        logger.info(f"WireGuard interface {self.INTERFACE} ready.")

        return {
            "success": True,
            "interface": self.INTERFACE,
            "address": self.ADDRESS,
            "listen_port": self.LISTEN_PORT,
            "public_key": self.server_public_key()
        }

    def server_public_key(
        self
    ) -> str:

        if not self.SERVER_PUBLIC_KEY.exists():

            return ""

        return self.SERVER_PUBLIC_KEY.read_text().strip()

    def apply_peer(
        self,
        peer
    ):

        if not peer.enabled:

            return self.remove_peer(peer)

        return self._wg(
            "set", self.INTERFACE,
            "peer", peer.public_key,
            "allowed-ips", peer.allowed_ip,
            "persistent-keepalive", "25"
        )

    def remove_peer(
        self,
        peer
    ):

        return self._wg(
            "set", self.INTERFACE,
            "peer", peer.public_key,
            "remove"
        )

    def sessions(
        self
    ) -> list[dict]:
        """
        Parses `wg show wg0 dump` into per-peer state: the latest
        handshake and transfer counters. A peer with a recent
        handshake (last few minutes) is an active session.
        """

        import time

        result = self.run_command([
            "/usr/bin/wg", "show", self.INTERFACE, "dump"
        ])

        sessions = []

        lines = result["output"].splitlines()

        if not lines:

            return sessions

        header = lines[0].split("\t")

        for line in lines[1:]:

            parts = line.split("\t")

            if len(parts) < 6:

                continue

            peer = {
                "public_key": parts[0],
                "allowed_ips": parts[3],
                "endpoint": parts[4] or None,
                "latest_handshake": int(parts[5] or 0),
                "rx_bytes": int(parts[6] or 0),
                "tx_bytes": int(parts[7] or 0),
            }

            if peer["latest_handshake"]:

                age = time.time() - peer["latest_handshake"]

                peer["active"] = age < 180

                peer["active_seconds_ago"] = int(age)

            else:

                peer["active"] = False

                peer["active_seconds_ago"] = None

            sessions.append(peer)

        return sessions

    def restrict_admin_input(
        self,
        wan_interfaces: list[str]
    ):
        """
        Default "remote admin over VPN/LAN only" policy. Drops the
        HTTPS web administration port (WEB_TLS_PORT) arriving on any
        WAN interface, so the admin UI is reachable only from the LAN
        or through the VPN. SSH (22) is deliberately NOT touched --
        it stays as the documented out-of-band recovery channel and
        must never be cut automatically (see incident 2026-08-06).
        Everything else stays default-accept (DHCP/DNS/VPN listen port).
        """

        web_port = str(Settings.WEB_TLS_PORT)

        self.run_command(["nft", "add", "table", "inet", "stepad"])

        self.run_command([
            "nft", "add", "chain", "inet", "stepad", "input", "{",
            "type", "filter", "hook", "input", "priority", "0", ";",
            "policy", "accept", ";",
            "}"
        ])

        existing = self.run_command([
            "nft", "list", "chain", "inet", "stepad", "input"
        ])

        for wan in wan_interfaces:

            marker = f"ADMIN_VPN_ONLY_{wan}"

            if marker in existing["output"]:

                continue

            self.run_command([
                "nft", "add", "rule", "inet", "stepad", "input",
                "iifname", wan,
                "tcp", "dport", web_port,
                "drop",
                "comment", marker
            ])

        return {"success": True, "wan_interfaces": wan_interfaces}
