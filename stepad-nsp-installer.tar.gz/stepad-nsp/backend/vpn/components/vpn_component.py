from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.database.session import SessionLocal

from backend.vpn.services.wireguard_provider import WireGuardProvider
from backend.vpn.services.vpn_service import VpnService

from backend.shared.logging.logger import logger


class VpnComponent(BaseComponent):

    name = "vpn"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.provider = WireGuardProvider()

        self.service = VpnService()

    def start(self):

        logger.info("VpnComponent started.")

        keys = self.provider.ensure_server_keys()

        if not keys.get("success"):

            logger.error(f"VPN server keys failed: {keys}")

            return

        interface = self.provider.ensure_interface()

        logger.info(f"VPN interface: {interface}")

        db = SessionLocal()

        try:

            sync = self.service.sync(db)

            expired = self.service.sweep_expired(db)

            logger.info(
                f"VPN synced ({sync.get('peers')} peer(s), "
                f"{expired.get('removed')} expired removed)."
            )

        finally:

            db.close()

    def stop(self):

        logger.info("VpnComponent stopped.")
