from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.database.session import SessionLocal

from backend.vpn.services.wireguard_provider import WireGuardProvider
from backend.vpn.services.vpn_service import VpnService

from backend.shared.logging.logger import logger


class VpnComponent(BaseComponent):

    name = "vpn"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.provider = WireGuardProvider()

        self.service = VpnService()

    def health_check(self) -> bool:
        try:
            import subprocess

            interface = getattr(self.provider, "INTERFACE", None)

            if not interface:
                return True

            result = subprocess.run(
                ["ip", "link", "show", interface],
                capture_output=True,
                text=True,
                timeout=5,
            )

            return result.returncode == 0

        except Exception as error:
            logger.warning("VpnComponent health_check: %s", error)
            return False

    def start(self):

        logger.info("VpnComponent started.")

        keys = self.provider.ensure_server_keys()

        if not keys.get("success"):

            logger.error(f"VPN server keys failed: {keys}")

            return

        interface = self.provider.ensure_interface()

        logger.info(f"VPN interface: {interface}")

        db = SessionLocal()

        try:

            sync = self.service.sync(db)

            expired = self.service.sweep_expired(db)

            logger.info(
                f"VPN synced ({sync.get('peers')} peer(s), "
                f"{expired.get('removed')} expired removed)."
            )

        finally:

            db.close()

    def stop(self):

        logger.info("VpnComponent stopped.")
