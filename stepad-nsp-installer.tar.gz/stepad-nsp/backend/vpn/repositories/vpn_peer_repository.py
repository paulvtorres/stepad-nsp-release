from sqlalchemy.orm import Session

from backend.vpn.models.vpn_peer import VpnPeer


class VpnPeerRepository:

    def find_all(
        self,
        db: Session
    ):

        return db.query(VpnPeer).all()

    def find_enabled(
        self,
        db: Session
    ):

        return (
            db.query(VpnPeer)
            .filter(VpnPeer.enabled.is_(True))
            .all()
        )

    def find_by_id(
        self,
        db: Session,
        peer_id: int
    ):

        return (
            db.query(VpnPeer)
            .filter(VpnPeer.id == peer_id)
            .first()
        )

    def find_expired(
        self,
        db: Session,
        now
    ):

        return (
            db.query(VpnPeer)
            .filter(
                VpnPeer.enabled.is_(True),
                VpnPeer.expires_at.isnot(None),
                VpnPeer.expires_at < now
            )
            .all()
        )

    def next_allowed_ip(
        self,
        db: Session
    ) -> str:

        used = set()

        for peer in self.find_all(db):

            used.add(peer.allowed_ip.split("/")[0])

        for index in range(2, 255):

            candidate = f"10.200.0.{index}"

            if candidate not in used:

                return f"{candidate}/32"

        return None

    def save(
        self,
        db: Session,
        peer: VpnPeer
    ):

        db.add(peer)

        db.commit()

        db.refresh(peer)

        return peer

    def delete(
        self,
        db: Session,
        peer: VpnPeer
    ):

        db.delete(peer)

        db.commit()
