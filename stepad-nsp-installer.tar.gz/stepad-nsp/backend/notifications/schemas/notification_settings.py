from pydantic import BaseModel


class NotificationSettingsRequest(BaseModel):

    enabled: bool | None = None

    smtp_host: str | None = None

    smtp_port: int | None = None

    smtp_user: str | None = None

    smtp_password: str | None = None

    from_email: str | None = None

    to_emails: str | None = None

    frequency: str | None = None

    send_hour: int | None = None

    send_minute: int | None = None
