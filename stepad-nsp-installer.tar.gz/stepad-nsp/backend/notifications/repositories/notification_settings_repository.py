from sqlalchemy.orm import Session

from backend.notifications.models.notification_settings import (
    NotificationSettings
)


class NotificationSettingsRepository:

    def get(
        self,
        db: Session
    ) -> NotificationSettings:

        settings = db.get(NotificationSettings, 1)

        if settings is None:

            settings = NotificationSettings(id=1)

            db.add(settings)

            db.commit()

            db.refresh(settings)

        return settings

    def save(
        self,
        db: Session,
        settings: NotificationSettings
    ):

        db.commit()

        db.refresh(settings)

        return settings
