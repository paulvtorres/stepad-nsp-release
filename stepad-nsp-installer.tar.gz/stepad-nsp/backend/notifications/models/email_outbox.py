from sqlalchemy import DateTime, Integer, String, Text, Index
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


class EmailOutbox(Base):

    __tablename__ = "email_outbox"
    __table_args__ = (
        Index("ix_email_outbox_dedupe", "dedupe_key"),
        Index("ix_email_outbox_status", "status", "next_attempt_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    channel: Mapped[str] = mapped_column(String(40), nullable=False, default="general")

    to_emails: Mapped[str] = mapped_column(Text, nullable=False, default="")

    cc_emails: Mapped[str] = mapped_column(Text, nullable=False, default="")

    bcc_emails: Mapped[str] = mapped_column(Text, nullable=False, default="")

    subject: Mapped[str] = mapped_column(String(255), nullable=False, default="")

    html_body: Mapped[str] = mapped_column(Text, nullable=False, default="")

    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")

    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    dedupe_key: Mapped[str | None] = mapped_column(String(64), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    sent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
