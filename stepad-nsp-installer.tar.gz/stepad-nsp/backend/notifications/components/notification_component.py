from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.notifications.services.notification_service import (
    NotificationService
)

from backend.shared.logging.logger import logger


class NotificationComponent(BaseComponent):

    name = "notifications"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.service = NotificationService()

    def health_check(self) -> bool:
        try:
            thread = getattr(self.service, "_scheduler_thread", None)
            return bool(thread and thread.is_alive())
        except Exception as error:
            logger.warning("NotificationComponent health_check: %s", error)
            return False

    def start(self):

        logger.info("NotificationComponent started.")

        self.service.start_scheduler()

    def stop(self):

        logger.info("NotificationComponent stopped.")
