import io
import socket
import html as html_lib

from datetime import datetime

from openpyxl import Workbook

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository
)


def _format_duration(minutes: int) -> str:

    minutes = minutes or 0

    if minutes <= 0:

        return "—"

    hours = minutes // 60

    remainder = minutes % 60

    if hours:

        return f"{hours} h {remainder} min"

    return f"{remainder} min"


def _escape(value) -> str:

    return html_lib.escape(str(value or ""))


class ReportService:

    def __init__(self):

        self.query_repo = DnsQueryLogRepository()

        self.org_repo = OrganizationSettingsRepository()

    def _organization(
        self,
        db
    ) -> dict:

        settings = self.org_repo.get(db)

        return {
            "company_name": settings.company_name,
            "ruc": settings.ruc,
            "address": settings.address,
            "phone": settings.phone,
            "email": settings.email,
        }

    @staticmethod
    def _hostname() -> str:

        try:

            return socket.gethostname()

        except Exception:

            return "stepad-nsp"

    def summary_rows(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ):

        return self.query_repo.find_summary(
            db,
            start=start,
            end=end,
            device_id=device_id,
            domain_contains=domain
        )

    def blocked_recent(
        self,
        db,
        start
    ):

        return self.query_repo.find_blocked_recent(
            db,
            start=start
        )

    def _per_device(
        self,
        rows
    ):

        devices = {}

        for row in rows:

            entry = devices.setdefault(row.device_id, {
                "device_name": row.device_hostname or row.hostname or row.ip_address or "Desconocido",
                "device_ip": row.ip_address,
                "visits": 0,
                "active_minutes": 0,
                "blocked": 0,
                "domains": {},
            })

            entry["visits"] += row.visit_count or 0

            entry["active_minutes"] += row.active_minutes or 0

            entry["blocked"] += row.blocked_count or 0

            entry["domains"][row.domain] = (
                entry["domains"].get(row.domain, 0)
                + (row.active_minutes or 0)
            )

        return sorted(
            devices.values(),
            key=lambda d: d["active_minutes"],
            reverse=True
        )

    def build_html_report(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ) -> str:

        rows = self.summary_rows(db, start, end, device_id, domain)

        devices = self._per_device(rows)

        blocked = self.blocked_recent(db, start)

        period = (
            f"{start.strftime('%d/%m/%Y %H:%M')} a "
            f"{end.strftime('%d/%m/%Y %H:%M')}"
        )

        org = self._organization(db)

        company = org["company_name"] or "STEPAD NSP"

        parts = []

        parts.append(
            f"<h2>{_escape(company)} — Resumen de navegación</h2>"
            f"<p>Período: <b>{_escape(period)}</b></p>"
        )

        parts.append("<h3>Resumen por equipo</h3>")
        parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
        parts.append("<tr style='background:#f3f4f6'><th>Equipo</th><th>IP</th><th>Consultas</th><th>Tiempo activo</th></tr>")

        for device in devices:

            parts.append(
                "<tr>"
                f"<td>{_escape(device['device_name'])}</td>"
                f"<td>{_escape(device['device_ip'])}</td>"
                f"<td>{device['visits']}</td>"
                f"<td>{_format_duration(device['active_minutes'])}</td>"
                "</tr>"
            )

        parts.append("</table>")

        parts.append("<h3>Páginas navegadas</h3>")
        parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
        parts.append("<tr style='background:#f3f4f6'><th>Equipo</th><th>Página</th><th>Frecuencia</th><th>Desde</th><th>Hasta</th><th>Horas</th></tr>")

        for row in rows:

            parts.append(
                "<tr>"
                f"<td>{_escape(row.device_hostname or row.hostname or row.ip_address or 'Desconocido')}</td>"
                f"<td>{_escape(row.domain)}</td>"
                f"<td>{row.visit_count}</td>"
                f"<td>{row.first_seen.strftime('%d/%m/%Y %H:%M') if row.first_seen else '—'}</td>"
                f"<td>{row.last_seen.strftime('%d/%m/%Y %H:%M') if row.last_seen else '—'}</td>"
                f"<td>{_format_duration(row.active_minutes)}</td>"
                "</tr>"
            )

        parts.append("</table>")

        total_blocked = sum((b.get("blocked_count") or 0) for b in blocked)

        parts.append("<h3>Notificaciones importantes</h3>")
        parts.append(f"<p>Consultas bloqueadas en el período: <b>{total_blocked}</b></p>")

        if blocked:

            parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
            parts.append("<tr style='background:#fef2f2'><th>Equipo</th><th>Dominio</th><th>Fecha</th></tr>")

            for item in blocked:

                parts.append(
                    "<tr>"
                    f"<td>{_escape(item['device_name'])}</td>"
                    f"<td>{_escape(item['domain'])}</td>"
                    f"<td>{item['queried_at'].strftime('%d/%m/%Y %H:%M')}</td>"
                    "</tr>"
                )

            parts.append("</table>")

        parts.append(
            "<p style='color:#6b7280;font-size:12px'>"
            "Tiempo activo estimado a partir de la actividad DNS "
            "(minutos con consultas). Reporte generado por STEPAD NSP.</p>"
        )

        return "".join(parts)

    def build_excel(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ) -> io.BytesIO:

        rows = self.summary_rows(db, start, end, device_id, domain)

        devices = self._per_device(rows)

        from openpyxl.styles import (
            Alignment,
            Border,
            Font,
            PatternFill,
            Side,
        )
        from openpyxl.utils import get_column_letter

        workbook = Workbook()

        sheet = workbook.active

        sheet.title = "Reporte de navegación"

        header_font = Font(bold=True, color="FFFFFF", size=11)

        header_fill = PatternFill("solid", fgColor="2563EB")

        title_font = Font(bold=True, size=16, color="1F2937")

        meta_font = Font(size=10, color="4B5563")

        band_fill = PatternFill("solid", fgColor="F3F4F6")

        thin = Side(style="thin", color="D1D5DB")

        border = Border(
            left=thin, right=thin, top=thin, bottom=thin
        )

        center = Alignment(
            horizontal="center", vertical="center"
        )

        left_align = Alignment(
            horizontal="left", vertical="center"
        )

        org = self._organization(db)

        company = org["company_name"] or "—"

        period_start = start.strftime("%d/%m/%Y %H:%M") if start else "—"

        period_end = end.strftime("%d/%m/%Y %H:%M") if end else "—"

        # Título (empresa) fusionado a lo ancho.
        sheet.merge_cells("A1:G1")

        sheet["A1"] = company

        sheet["A1"].font = title_font

        sheet["A1"].alignment = left_align

        # Metadatos: RUC, período y fecha de generación (sin "EQUIPO").
        meta_lines = []

        if org.get("ruc"):

            meta_lines.append(f"RUC: {org['ruc']}")

        meta_lines.append(
            f"Período: {period_start}  →  {period_end}"
        )

        meta_lines.append(
            "Generado: "
            + datetime.now().strftime("%d/%m/%Y %H:%M")
        )

        row_idx = 2

        for line in meta_lines:

            sheet.merge_cells(
                start_row=row_idx,
                start_column=1,
                end_row=row_idx,
                end_column=7
            )

            cell = sheet.cell(row=row_idx, column=1, value=line)

            cell.font = meta_font

            cell.alignment = left_align

            row_idx += 1

        # Fila en blanco y encabezado de la tabla.
        header_row = row_idx + 1

        headers = [
            "Equipo",
            "IP",
            "Página (dominio)",
            "Visitas",
            "Desde",
            "Hasta",
            "Horas aprox.",
        ]

        for col, heading in enumerate(headers, start=1):

            cell = sheet.cell(row=header_row, column=col, value=heading)

            cell.font = header_font

            cell.fill = header_fill

            cell.alignment = center

            cell.border = border

        sorted_rows = sorted(
            rows,
            key=lambda row: row.visit_count or 0,
            reverse=True
        )

        data_row = header_row + 1

        for index, row in enumerate(sorted_rows):

            values = [
                (
                    row.device_hostname
                    or row.hostname
                    or row.ip_address
                    or "Desconocido"
                ),
                row.ip_address or "—",
                row.domain,
                row.visit_count,
                row.first_seen,
                row.last_seen,
                round((row.active_minutes or 0) / 60, 1),
            ]

            banded = index % 2 == 1

            for col, value in enumerate(values, start=1):

                cell = sheet.cell(
                    row=data_row,
                    column=col,
                    value=value
                )

                cell.border = border

                if col in (1, 2, 3):

                    cell.alignment = left_align

                elif col in (5, 6):

                    cell.alignment = center

                    cell.number_format = "DD/MM/YYYY HH:MM"

                else:

                    cell.alignment = center

                    if col == 4:

                        cell.number_format = "#,##0"

                if banded:

                    cell.fill = band_fill

            data_row += 1

        sheet.auto_filter.ref = (
            f"A{header_row}:G{data_row - 1}"
        )

        sheet.freeze_panes = f"A{header_row + 1}"

        for index, width in enumerate(
            [24, 16, 40, 14, 20, 20, 12],
            start=1
        ):

            sheet.column_dimensions[
                get_column_letter(index)
            ].width = width

        sheet.sheet_view.showGridLines = False

        buffer = io.BytesIO()

        workbook.save(buffer)

        buffer.seek(0)

        return buffer
