import io
import socket
import html as html_lib

from datetime import datetime

from openpyxl import Workbook

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository
)


def _format_duration(minutes: int) -> str:

    minutes = minutes or 0

    if minutes <= 0:

        return "—"

    hours = minutes // 60

    remainder = minutes % 60

    if hours:

        return f"{hours} h {remainder} min"

    return f"{remainder} min"


def _escape(value) -> str:

    return html_lib.escape(str(value or ""))


class ReportService:

    def __init__(self):

        self.query_repo = DnsQueryLogRepository()

        self.org_repo = OrganizationSettingsRepository()

    def _organization(
        self,
        db
    ) -> dict:

        settings = self.org_repo.get(db)

        return {
            "company_name": settings.company_name,
            "ruc": settings.ruc,
            "address": settings.address,
            "phone": settings.phone,
            "email": settings.email,
        }

    @staticmethod
    def _hostname() -> str:

        try:

            return socket.gethostname()

        except Exception:

            return "stepad-nsp"

    def summary_rows(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ):

        return self.query_repo.find_summary(
            db,
            start=start,
            end=end,
            device_id=device_id,
            domain_contains=domain
        )

    def blocked_recent(
        self,
        db,
        start
    ):

        return self.query_repo.find_blocked_recent(
            db,
            start=start
        )

    def _per_device(
        self,
        rows
    ):

        devices = {}

        for row in rows:

            entry = devices.setdefault(row.device_id, {
                "device_name": row.device_hostname or row.hostname or row.ip_address or "Desconocido",
                "device_ip": row.ip_address,
                "visits": 0,
                "active_minutes": 0,
                "blocked": 0,
                "domains": {},
            })

            entry["visits"] += row.visit_count or 0

            entry["active_minutes"] += row.active_minutes or 0

            entry["blocked"] += row.blocked_count or 0

            entry["domains"][row.domain] = (
                entry["domains"].get(row.domain, 0)
                + (row.active_minutes or 0)
            )

        return sorted(
            devices.values(),
            key=lambda d: d["active_minutes"],
            reverse=True
        )

    def build_html_report(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ) -> str:

        rows = self.summary_rows(db, start, end, device_id, domain)

        devices = self._per_device(rows)

        blocked = self.blocked_recent(db, start)

        period = (
            f"{start.strftime('%d/%m/%Y %H:%M')} a "
            f"{end.strftime('%d/%m/%Y %H:%M')}"
        )

        org = self._organization(db)

        company = org["company_name"] or "STEPAD NSP"

        parts = []

        parts.append(
            f"<h2>{_escape(company)} — Resumen de navegación</h2>"
            f"<p>Período: <b>{_escape(period)}</b></p>"
            f"<p>Equipo: <b>{_escape(self._hostname())}</b></p>"
        )

        parts.append("<h3>Resumen por equipo</h3>")
        parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
        parts.append("<tr style='background:#f3f4f6'><th>Equipo</th><th>IP</th><th>Consultas</th><th>Tiempo activo</th></tr>")

        for device in devices:

            parts.append(
                "<tr>"
                f"<td>{_escape(device['device_name'])}</td>"
                f"<td>{_escape(device['device_ip'])}</td>"
                f"<td>{device['visits']}</td>"
                f"<td>{_format_duration(device['active_minutes'])}</td>"
                "</tr>"
            )

        parts.append("</table>")

        parts.append("<h3>Páginas navegadas</h3>")
        parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
        parts.append("<tr style='background:#f3f4f6'><th>Equipo</th><th>Página</th><th>Frecuencia</th><th>Desde</th><th>Hasta</th><th>Horas</th></tr>")

        for row in rows:

            parts.append(
                "<tr>"
                f"<td>{_escape(row.device_hostname or row.hostname or row.ip_address or 'Desconocido')}</td>"
                f"<td>{_escape(row.domain)}</td>"
                f"<td>{row.visit_count}</td>"
                f"<td>{row.first_seen.strftime('%d/%m/%Y %H:%M') if row.first_seen else '—'}</td>"
                f"<td>{row.last_seen.strftime('%d/%m/%Y %H:%M') if row.last_seen else '—'}</td>"
                f"<td>{_format_duration(row.active_minutes)}</td>"
                "</tr>"
            )

        parts.append("</table>")

        total_blocked = sum((b.get("blocked_count") or 0) for b in blocked)

        parts.append("<h3>Notificaciones importantes</h3>")
        parts.append(f"<p>Consultas bloqueadas en el período: <b>{total_blocked}</b></p>")

        if blocked:

            parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
            parts.append("<tr style='background:#fef2f2'><th>Equipo</th><th>Dominio</th><th>Fecha</th></tr>")

            for item in blocked:

                parts.append(
                    "<tr>"
                    f"<td>{_escape(item['device_name'])}</td>"
                    f"<td>{_escape(item['domain'])}</td>"
                    f"<td>{item['queried_at'].strftime('%d/%m/%Y %H:%M')}</td>"
                    "</tr>"
                )

            parts.append("</table>")

        parts.append(
            "<p style='color:#6b7280;font-size:12px'>"
            "Tiempo activo estimado a partir de la actividad DNS "
            "(minutos con consultas). Reporte generado por STEPAD NSP.</p>"
        )

        return "".join(parts)

    def build_excel(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ) -> io.BytesIO:

        rows = self.summary_rows(db, start, end, device_id, domain)

        devices = self._per_device(rows)

        workbook = Workbook()

        from openpyxl.styles import Font, PatternFill
        from openpyxl.utils import get_column_letter

        header_font = Font(bold=True, color="FFFFFF")

        header_fill = PatternFill("solid", fgColor="2563EB")

        title_font = Font(bold=True, size=14)

        label_font = Font(bold=True)


        org = self._organization(db)

        company = org["company_name"] or "—"

        period_start = start.strftime("%d/%m/%Y %H:%M") if start else "—"

        period_end = end.strftime("%d/%m/%Y %H:%M") if end else "—"

        sheet = workbook.active

        sheet.title = "Páginas navegadas"

        sheet.append([f"EMPRESA: {company}"])

        sheet["A1"].font = title_font

        if org.get("ruc"):

            sheet.append([f"RUC: {org['ruc']}"])

            sheet["A2"].font = label_font

        sheet.append([f"EQUIPO: {self._hostname()}"])

        sheet[f"A{sheet.max_row}"].font = label_font

        sheet.append([f"PERÍODO: {period_start}  →  {period_end}"])

        sheet[f"A{sheet.max_row}"].font = label_font

        sheet.append(
            [f"GENERADO: {datetime.now().strftime('%d/%m/%Y %H:%M')}"]
        )

        sheet[f"A{sheet.max_row}"].font = label_font

        sheet.append([])

        data_header_row = sheet.max_row + 1

        sheet.append(
            ["Equipo", "Página (dominio)", "Frecuencia (visitas)",
             "Desde", "Hasta", "Horas aprox"]
        )

        sorted_rows = sorted(
            rows,
            key=lambda row: row.visit_count or 0,
            reverse=True
        )

        for row in sorted_rows:

            sheet.append([
                row.device_hostname or row.hostname or row.ip_address or "Desconocido",
                row.domain,
                row.visit_count,
                row.first_seen,
                row.last_seen,
                round((row.active_minutes or 0) / 60, 1)
            ])

        for cell in sheet[data_header_row]:

            cell.font = header_font

            cell.fill = header_fill

        sheet.auto_filter.ref = (
            f"A{data_header_row}:F{sheet.max_row}"
        )

        sheet.freeze_panes = f"A{data_header_row + 1}"

        for index, width in enumerate(
            [24, 40, 18, 20, 20, 12],
            start=1
        ):

            sheet.column_dimensions[
                get_column_letter(index)
            ].width = width

        buffer = io.BytesIO()

        workbook.save(buffer)

        buffer.seek(0)

        return buffer
