import threading
import time

from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.notifications.models.notification_settings import (
    NotificationSettings
)
from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.report_service import ReportService

from backend.core.database.session import SessionLocal

from backend.shared.logging.logger import logger


class NotificationService:

    def __init__(self):

        self.repository = NotificationSettingsRepository()

        self.email_service = EmailService()

        self.report_service = ReportService()

        self._scheduler_thread = None

        self._stop = False

    def _period(
        self,
        frequency: str
    ) -> tuple[datetime, datetime]:

        end = datetime.utcnow()

        days = {
            "daily": 1,
            "weekly": 7,
            "monthly": 30,
        }.get(frequency, 1)

        start = end - timedelta(days=days)

        return start, end

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        return {
            "id": settings.id,
            "enabled": settings.enabled,
            "smtp_host": settings.smtp_host,
            "smtp_port": settings.smtp_port,
            "smtp_user": settings.smtp_user,
            "has_smtp_password": bool(settings.smtp_password),
            "from_email": settings.from_email,
            "to_emails": settings.to_emails,
            "frequency": settings.frequency,
            "send_hour": settings.send_hour,
            "send_minute": settings.send_minute,
            "last_sent_at": (
                settings.last_sent_at.isoformat()
                if settings.last_sent_at else None
            )
        }

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.repository.get(db)

        if data.enabled is not None:
            settings.enabled = data.enabled

        if data.smtp_host is not None:
            settings.smtp_host = data.smtp_host

        if data.smtp_port is not None:
            settings.smtp_port = data.smtp_port

        if data.smtp_user is not None:
            settings.smtp_user = data.smtp_user

        # Only overwrite the password when a new one is provided.
        if data.smtp_password:
            settings.smtp_password = data.smtp_password

        if data.from_email is not None:
            settings.from_email = data.from_email

        if data.to_emails is not None:
            settings.to_emails = data.to_emails

        if data.frequency is not None:
            settings.frequency = data.frequency

        if data.send_hour is not None:
            settings.send_hour = data.send_hour

        if data.send_minute is not None:
            settings.send_minute = data.send_minute

        self.repository.save(db, settings)

        return self.get_settings(db)

    def send_report(
        self,
        db: Session,
        settings: NotificationSettings = None
    ) -> dict:

        settings = settings or self.repository.get(db)

        start, end = self._period(settings.frequency)

        html_body = self.report_service.build_html_report(
            db,
            start,
            end
        )

        subject = (
            f"Resumen de navegación "
            f"({start.strftime('%d/%m/%Y')} - {end.strftime('%d/%m/%Y')})"
        )

        result = self.email_service.send_html(
            settings,
            subject,
            html_body
        )

        if result["success"]:

            settings.last_sent_at = datetime.utcnow()

            self.repository.save(db, settings)

        return result

    def send_test(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        html_body = (
            "<h2>Prueba de notificación</h2>"
            "<p>Este es un correo de prueba de STEPAD NSP. "
            "Si lo estás viendo, la configuración de correo es correcta.</p>"
        )

        return self.email_service.send_html(
            settings,
            "STEPAD NSP - Prueba de notificación",
            html_body
        )

    def is_due(
        self,
        settings: NotificationSettings,
        now: datetime
    ) -> bool:

        if not settings.enabled:

            return False

        if (
            now.hour < settings.send_hour
            or (
                now.hour == settings.send_hour
                and now.minute < settings.send_minute
            )
        ):

            return False

        last = settings.last_sent_at

        if last is None:

            return True

        if settings.frequency == "daily":

            return last.date() < now.date()

        if settings.frequency == "weekly":

            return (now.date() - last.date()).days >= 7

        if settings.frequency == "monthly":

            return (
                last.year != now.year
                or last.month != now.month
            )

        return False

    def _scheduler_loop(
        self
    ):

        logger.info("Notification scheduler started.")

        while not self._stop:

            try:

                db = SessionLocal()

                try:

                    settings = self.repository.get(db)

                    if self.is_due(settings, datetime.utcnow()):

                        result = self.send_report(db, settings)

                        logger.info(
                            f"Notification report: {result}"
                        )

                    try:

                        from backend.siem.services.compliance_service import (
                            ComplianceService
                        )

                        ComplianceService().check_logs_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Logs review check failed: {error}"
                        )

                    try:

                        from backend.firewall.services.firewall_hardening_service import (
                            FirewallHardeningService
                        )

                        FirewallHardeningService().check_access_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Access review check failed: {error}"
                        )

                finally:

                    db.close()

            except Exception as error:

                logger.exception(
                    f"Notification scheduler error: {error}"
                )

            time.sleep(30)

    def start_scheduler(
        self
    ):

        if self._scheduler_thread is not None:

            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="notification-scheduler"
        )

        self._scheduler_thread.start()
