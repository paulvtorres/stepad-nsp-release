"""Tamper-evident audit chain.

Each entry stores the previous entry hash and its own hash over the
immutable fields. Editing or deleting a row breaks the chain from that
point on, which `verify_rows` reports with the first broken id.
"""

import hashlib


def _canonical(
    prev_hash: str,
    user_id,
    action: str,
    resource: str,
    description: str,
    created_at,
) -> str:
    stamp = (
        created_at.isoformat(timespec="microseconds")
        if created_at is not None
        else ""
    )
    return "\x1f".join(
        [
            prev_hash or "",
            "" if user_id is None else str(user_id),
            action or "",
            resource or "",
            description or "",
            stamp,
        ]
    )


def hash_entry(
    prev_hash: str,
    user_id,
    action: str,
    resource: str,
    description: str,
    created_at,
) -> str:
    payload = _canonical(
        prev_hash, user_id, action, resource, description, created_at
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def verify_rows(rows: list) -> dict:
    """rows: dicts with id, user_id, action, resource, description,
    created_at, prev_hash, entry_hash. Returns ok/checked/broken_at."""
    previous = ""
    checked = 0
    for row in rows:
        expected = hash_entry(
            previous,
            row.get("user_id"),
            row.get("action"),
            row.get("resource"),
            row.get("description"),
            row.get("created_at"),
        )
        if (row.get("prev_hash") or "") != previous or row.get(
            "entry_hash"
        ) != expected:
            return {
                "ok": False,
                "checked": checked,
                "broken_at": row.get("id"),
            }
        previous = row.get("entry_hash")
        checked += 1
    return {"ok": True, "checked": checked, "last_hash": previous or None}
