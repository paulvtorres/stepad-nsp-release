import threading

from sqlalchemy import func
from sqlalchemy.orm import Session

from backend.audit.models.audit_log import AuditLog
from backend.audit.repositories.audit_repository import AuditRepository

from backend.alerts.services.alert_service import AlertService

from backend.siem.services.syslog_service import SyslogService
from backend.audit.services import audit_chain
from backend.shared.datetime_utils import utcnow


class AuditService:

    _chain_lock = threading.Lock()


    def __init__(self):

        self.repository = AuditRepository()

        self.alert_service = AlertService()

        self.syslog_service = SyslogService()


    def create_log(
        self,
        db: Session,
        user_id: int | None,
        action: str,
        resource: str,
        description: str
    ):

        with self._chain_lock:
            previous = (
                db.query(AuditLog.entry_hash)
                .filter(AuditLog.entry_hash.isnot(None))
                .order_by(AuditLog.id.desc())
                .limit(1)
                .scalar()
            ) or ""
            now = utcnow()
            audit = AuditLog(
                user_id=user_id,
                action=action,
                resource=resource,
                description=description,
                created_at=now,
                prev_hash=previous,
                entry_hash=audit_chain.hash_entry(
                    previous,
                    user_id,
                    action,
                    resource,
                    description,
                    now,
                ),
            )
            saved = self.repository.save(db, audit)

        # Promote security-relevant actions to the alert feed.
        severity = AlertService.SEVERITY.get(action)

        if severity:

            self.alert_service.create(
                db,
                action,
                severity,
                description,
                f"{resource}: {description}"
            )

        # Forward to the SIEM (syslog) when configured.
        self.syslog_service.forward(
            db,
            action=action,
            resource=resource,
            user_id=user_id,
            description=description
        )

        return saved


    def verify_chain(self, db: Session) -> dict:
        """Recompute the chain; report the first broken entry, if any."""
        rows = (
            db.query(AuditLog)
            .filter(AuditLog.entry_hash.isnot(None))
            .order_by(AuditLog.id.asc())
            .all()
        )
        legacy = (
            db.query(func.count(AuditLog.id))
            .filter(AuditLog.entry_hash.is_(None))
            .scalar()
            or 0
        )
        result = audit_chain.verify_rows(
            [
                {
                    "id": row.id,
                    "user_id": row.user_id,
                    "action": row.action,
                    "resource": row.resource,
                    "description": row.description,
                    "created_at": row.created_at,
                    "prev_hash": row.prev_hash,
                    "entry_hash": row.entry_hash,
                }
                for row in rows
            ]
        )
        result["legacy"] = int(legacy)
        return result
