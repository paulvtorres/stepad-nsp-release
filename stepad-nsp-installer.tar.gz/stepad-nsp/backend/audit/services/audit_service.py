from sqlalchemy.orm import Session

from backend.audit.models.audit_log import AuditLog
from backend.audit.repositories.audit_repository import AuditRepository

from backend.alerts.services.alert_service import AlertService

from backend.siem.services.syslog_service import SyslogService


class AuditService:


    def __init__(self):

        self.repository = AuditRepository()

        self.alert_service = AlertService()

        self.syslog_service = SyslogService()


    def create_log(
        self,
        db: Session,
        user_id: int | None,
        action: str,
        resource: str,
        description: str
    ):

        audit = AuditLog(

            user_id=user_id,

            action=action,

            resource=resource,

            description=description

        )


        saved = self.repository.save(
            db,
            audit
        )

        # Promote security-relevant actions to the alert feed.
        severity = AlertService.SEVERITY.get(action)

        if severity:

            self.alert_service.create(
                db,
                action,
                severity,
                description,
                f"{resource}: {description}"
            )

        # Forward to the SIEM (syslog) when configured.
        self.syslog_service.forward(
            db,
            action=action,
            resource=resource,
            user_id=user_id,
            description=description
        )

        return saved
