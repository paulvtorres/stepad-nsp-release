"""Periodic verification of the tamper-evident audit chain.

Runs at most once a day (and on demand from the Audit page), stores the
result in a 0600 JSON state file, exposes it to metrics/scheduled tasks,
and raises a critical alert when the chain becomes broken.
"""

import json
import os
import threading

from datetime import datetime, timedelta

from sqlalchemy.exc import SQLAlchemyError

from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger

STATE_PATH = os.environ.get(
    "STEPAD_AUDIT_CHAIN_STATE",
    "/etc/stepad/audit_chain_check.json",
)

CHECK_HOURS = 20


class AuditChainCheckService:

    def __init__(self, state_path: str | None = None):

        self.state_path = state_path or STATE_PATH

        self._lock = threading.Lock()

    def status(self) -> dict:

        try:

            with open(self.state_path, encoding="utf-8") as handle:

                data = json.load(handle)

            if isinstance(data, dict):

                return data

        except (OSError, ValueError) as error:

            logger.debug("audit_chain_check.status: %s", error)

        return {}

    def should_run(self) -> bool:

        last_raw = self.status().get("last_run_at")

        if not last_raw:

            return True

        try:

            last = datetime.fromisoformat(last_raw)

        except ValueError:

            return True

        return utcnow() - last > timedelta(hours=CHECK_HOURS)

    def _save(self, data: dict) -> None:

        try:

            tmp = f"{self.state_path}.tmp"

            with open(tmp, "w", encoding="utf-8") as handle:

                json.dump(data, handle, ensure_ascii=False, indent=2)

            os.replace(tmp, self.state_path)

            try:

                os.chmod(self.state_path, 0o600)

            except OSError:

                pass

        except OSError as error:

            logger.warning("No pude guardar el estado de auditoría: %s", error)

    def run(self, db=None, alert: bool = True) -> dict:

        if not self._lock.acquire(blocking=False):

            return {"ok": False, "message": "verificación en curso"}

        try:

            return self._run_locked(db, alert)

        finally:

            self._lock.release()

    def _run_locked(self, db, alert: bool) -> dict:

        from backend.audit.services.audit_service import AuditService
        from backend.core.database.session import SessionLocal

        own = db is None

        session = db or SessionLocal()

        try:

            result = AuditService().verify_chain(session)

            previous = self.status()

            result["last_run_at"] = utcnow().isoformat()
            result["message"] = (
                "cadena íntegra"
                if result.get("ok")
                else f"cadena rota en el registro {result.get('broken_at')}"
            )

            self._save(result)

            if alert and not result.get("ok"):

                broken = result.get("broken_at")

                already = (
                    previous.get("ok") is False
                    and previous.get("broken_at") == broken
                )

                if not already:

                    try:

                        from backend.alerts.services.alert_service import (
                            AlertService,
                        )

                        AlertService().create(
                            session,
                            alert_type="AUDIT_CHAIN_BROKEN",
                            severity="critical",
                            title="Auditoría: cadena de hashes alterada",
                            message=(
                                "La verificación de la auditoría falló en el "
                                f"registro {broken} ({result.get('checked')} "
                                "verificados). Revisa la base de datos y el "
                                "acceso al equipo."
                            ),
                        )
                        session.commit()

                    except (
                        ImportError, SQLAlchemyError, OSError, ValueError,
                        KeyError, TypeError,
                    ) as error:

                        logger.error(
                            "No pude crear la alerta de auditoría: %s", error
                        )

            return result

        finally:

            if own:

                session.close()
