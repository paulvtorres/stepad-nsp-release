from datetime import datetime

from sqlalchemy.orm import Session

from backend.audit.models.audit_log import AuditLog


class AuditRepository:


    def save(
        self,
        db: Session,
        audit_log: AuditLog
    ):

        db.add(audit_log)

        db.commit()

        db.refresh(audit_log)

        return audit_log


    def find_filtered(
        self,
        db: Session,
        action: str | None = None,
        resource: str | None = None,
        start: datetime | None = None,
        end: datetime | None = None,
        limit: int = 200
    ):

        query = db.query(AuditLog)

        if action:

            query = query.filter(AuditLog.action == action)

        if resource:

            query = query.filter(AuditLog.resource == resource)

        if start:

            query = query.filter(AuditLog.created_at >= start)

        if end:

            query = query.filter(AuditLog.created_at <= end)

        return (
            query
            .order_by(AuditLog.id.desc())
            .limit(limit)
            .all()
        )
