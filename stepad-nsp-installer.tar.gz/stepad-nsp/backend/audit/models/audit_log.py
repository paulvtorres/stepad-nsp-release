from sqlalchemy import String, DateTime, Integer
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column

from datetime import datetime

from backend.core.database.base import Base


class AuditLog(Base):

    __tablename__ = "audit_logs"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    user_id: Mapped[int | None] = mapped_column(
        nullable=True
    )


    action: Mapped[str] = mapped_column(
        String(50),
        nullable=False
    )


    resource: Mapped[str] = mapped_column(
        String(50),
        nullable=False
    )


    description: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )