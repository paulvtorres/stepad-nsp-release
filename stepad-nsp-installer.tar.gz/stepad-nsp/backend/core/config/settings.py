import os

from pathlib import Path

from backend.shared.enums import (
    EnvironmentType
)

_PRODUCTION_ENV_FILE = Path("/etc/stepad/stepad.env")


def _resolve_environment():

    env_value = os.getenv("STEPAD_ENV")

    if env_value:

        return EnvironmentType(env_value)

    # Defensive: an installed box whose /etc/stepad/stepad.env lost
    # the STEPAD_ENV key must keep running against /etc/stepad
    # instead of silently falling back to dev (~/.stepad), which
    # would desync the app from the dnsmasq/firewall it manages.
    if _PRODUCTION_ENV_FILE.exists():

        return EnvironmentType.PRODUCTION

    return EnvironmentType.DEVELOPMENT


_IS_PRODUCTION = (
    _resolve_environment() == EnvironmentType.PRODUCTION
)


def _secret(
    name: str,
    dev_default: str
):

    value = os.getenv(name)

    if _IS_PRODUCTION and not value:

        raise RuntimeError(
            f"Missing required environment variable '{name}'. "
            "STEPAD NSP will not start in production with insecure "
            "default secrets. install.py writes these into "
            "/etc/stepad/stepad.env (loaded via systemd "
            "EnvironmentFile)."
        )

    return value if value else dev_default


class Settings:


    APP_NAME = os.getenv(
        "APP_NAME",
        "STEPAD NSP"
    )


    ENVIRONMENT = _resolve_environment()


    IS_PRODUCTION = _IS_PRODUCTION


    if IS_PRODUCTION:

        STEPAD_DIR = Path("/etc/stepad")

    else:

        STEPAD_DIR = Path.cwd() / ".stepad"


    DB_HOST = os.getenv(
        "DB_HOST",
        "localhost"
    )


    DB_PORT = int(
        os.getenv(
            "DB_PORT",
            5432
        )
    )


    DB_NAME = os.getenv(
        "DB_NAME",
        "stepad_nsp"
    )


    DB_USER = os.getenv(
        "DB_USER",
        "stepad_app"
    )


    DB_PASSWORD = _secret(
        "DB_PASSWORD",
        "paulan2000"
    )


    JWT_SECRET = _secret(
        "STEPAD_JWT_SECRET",
        "change_this_secret"
    )


    JWT_ALGORITHM = os.getenv(
        "JWT_ALGORITHM",
        "HS256"
    )


    DNS_ENGINE = os.getenv(
        "STEPAD_DNS_ENGINE",
        "dnsmasq"
    )


    API_PORT = int(
        os.getenv(
            "STEPAD_API_PORT",
            8000
        )
    )


    JWT_EXPIRE_MINUTES = int(

        os.getenv(

            "JWT_EXPIRE_MINUTES",

            60

        )

    )


    PASSWORD_MAX_AGE_DAYS = int(

        os.getenv(

            "STEPAD_PASSWORD_MAX_AGE_DAYS",

            90

        )

    )


    INACTIVITY_TIMEOUT_MINUTES = int(

        os.getenv(

            "STEPAD_INACTIVITY_TIMEOUT_MINUTES",

            15

        )

    )


    MFA_REQUIRED_FOR_ADMINS = (

        os.getenv(

            "STEPAD_MFA_REQUIRED_FOR_ADMINS",

            "false"

        ).lower() in ("1", "true", "yes")

    )


    VPN_REQUIRE_REMOTE_ADMIN = (

        os.getenv(

            "STEPAD_VPN_REQUIRE_REMOTE_ADMIN",

            "true"

        ).lower() in ("1", "true", "yes")

    )


    WEB_TLS_PORT = int(

        os.getenv(

            "STEPAD_WEB_TLS_PORT",

            8443

        )

    )


    WEB_TLS_CERT = os.getenv(

        "STEPAD_TLS_CERT",

        "/etc/stepad/ssl/server.crt"

    )


    WEB_TLS_KEY = os.getenv(

        "STEPAD_TLS_KEY",

        "/etc/stepad/ssl/server.key"

    )


    FRONTEND_DIST = os.getenv(

        "STEPAD_FRONTEND_DIST",

        "/home/paulan/stepad-nsp/frontend/dist"

    )


    CORS_ORIGINS = [

        origin.strip()

        for origin in os.getenv(
            "STEPAD_CORS_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173"
        ).split(",")

        if origin.strip()

    ]
