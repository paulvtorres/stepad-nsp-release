"""Open-port verification for the NSP.

Compares listening ports against the allow/deny lists and reports
unexpected ones.

Note: local DNS (pdns) and WireGuard listen on UDP and/or a specific IP
(not 0.0.0.0). Expected TCP services may also bind specific addresses
(for example SSH restricted to LAN/Tailscale), so expected ports accept
any local address while forbidden ports are only flagged on wildcard.
"""

import subprocess

from backend.shared.logging.logger import logger


# TCP ports the NSP MUST have listening on any local address
EXPECTED_TCP = {
    22: "SSH (admin)",
    8443: "HTTPS (panel web)",
}

# Ports the NSP MUST have listening (UDP or TCP, on any IP)
EXPECTED_ANY = {
    53: "DNS (local)",
    51820: "WireGuard VPN",
}

# TCP ports that must NEVER be open on 0.0.0.0
FORBIDDEN_TCP = {
    80: "HTTP (debe usar HTTPS 8443)",
    3306: "MySQL (base de datos no expuesta)",
    5432: "PostgreSQL (debe ser solo localhost)",
    445: "Samba/SMB (no exponer)",
    139: "NetBIOS (no exponer)",
    3389: "RDP (no exponer)",
    11211: "Memcached (no exponer)",
    6379: "Redis (no exponer)",
    27017: "MongoDB (no exponer)",
}


def _listening_ports(flag):
    """Return (wildcard ports, ports on any local address).

    `flag` is the socket family: "-tln" (TCP) or "-uln" (UDP).
    """

    try:

        result = subprocess.run(
            ["ss", flag],
            capture_output=True, text=True, timeout=5,
        )

    except Exception as exc:

        logger.warning("ports_check: no pude ejecutar ss %s: %s", flag, exc)

        return {}, {}

    if result.returncode != 0:

        logger.warning(
            "ports_check: ss %s devolvio %s", flag, result.returncode,
        )

        return {}, {}

    wildcard = {}
    anywhere = {}

    for line in result.stdout.splitlines()[1:]:

        parts = line.split()

        if len(parts) < 4:

            continue

        local = parts[3]

        if ":" not in local:

            continue

        try:

            port = int(local.rsplit(":", 1)[-1])

        except ValueError:

            continue

        anywhere.setdefault(port, line.strip())

        if local.startswith("0.0.0.0:") or local.startswith("[::]:"):

            wildcard[port] = line.strip()

    return wildcard, anywhere


def check_ports():
    """Check open ports and return the issues found."""

    issues = []

    tcp_wildcard, tcp_any = _listening_ports("-tln")
    udp_wildcard, udp_any = _listening_ports("-uln")

    for port, desc in FORBIDDEN_TCP.items():
        if port in tcp_wildcard:
            issues.append({
                "check": "ports",
                "severity": "critical",
                "title": "Puerto prohibido abierto: %d (%s)" % (port, desc),
                "message": (
                    "El puerto %d (%s) esta escuchando en todas las "
                    "interfaces. Esto es un riesgo de seguridad."
                    "\n\nLinea: %s"
                    % (port, desc, tcp_wildcard.get(port, ""))
                ),
                "repair": (
                    "1) Identifique que servicio lo abre: "
                    "ss -tlnp | grep ':%d'\n"
                    "2) Detenga ese servicio: "
                    "sudo systemctl stop <servicio>\n"
                    "3) Si es intencional, restrinja a localhost: "
                    "bind 127.0.0.1 en su config" % port
                ),
            })

    for port, desc in EXPECTED_TCP.items():
        if port not in tcp_any:
            issues.append({
                "check": "ports",
                "severity": "warning",
                "title": "Puerto esperado no escucha: %d (%s)" % (port, desc),
                "message": (
                    "El puerto %d (%s) no esta escuchando. "
                    "Esto puede indicar un servicio caido." % (port, desc)
                ),
                "repair": (
                    "Verifique el servicio asociado y reinicie si es necesario."
                ),
            })

    listening_any = set(tcp_any) | set(udp_any)

    for port, desc in EXPECTED_ANY.items():
        if port not in listening_any:
            issues.append({
                "check": "ports",
                "severity": "warning",
                "title": "Puerto esperado no escucha: %d (%s)" % (port, desc),
                "message": (
                    "El puerto %d (%s) no esta escuchando. "
                    "Esto puede indicar un servicio caido." % (port, desc)
                ),
                "repair": (
                    "Verifique el servicio asociado y reinicie si es necesario."
                ),
            })

    return issues
