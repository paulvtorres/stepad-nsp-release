from enum import Enum


class ComponentState(Enum):

    STOPPED = "stopped"
    RUNNING = "running"
    FAILED = "failed"
