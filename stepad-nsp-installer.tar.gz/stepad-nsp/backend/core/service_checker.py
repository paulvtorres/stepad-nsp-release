import subprocess


class ServiceChecker:


    def is_active(self, service_name: str) -> bool:

        result = subprocess.run(
            [
                "systemctl",
                "is-active",
                service_name
            ],
            capture_output=True,
            text=True
        )

        return result.stdout.strip() == "active"