from abc import ABC, abstractmethod

from backend.core.lifecycle.component_criticality import ComponentCriticality


class BaseComponent(ABC):

    name = "component"
    criticality = ComponentCriticality.OPTIONAL

    @abstractmethod
    def start(self):
        pass

    def stop(self):
        pass