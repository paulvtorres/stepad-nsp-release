from abc import ABC, abstractmethod

from backend.core.lifecycle.component_criticality import ComponentCriticality


class BaseComponent(ABC):

    name = "component"
    criticality = ComponentCriticality.OPTIONAL

    @abstractmethod
    def start(self):
        pass

    def stop(self):
        pass

    def health_check(self) -> bool:
        """True si el componente sigue operativo.

        Por defecto se confía en el estado de arranque. Los componentes
        con un servicio propio (como DHCP) deben sobrescribirlo.
        """

        return True
