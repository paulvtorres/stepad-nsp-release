from backend.shared.logging.logger import logger

from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality


class CoreComponent(BaseComponent):
    name = "core"
    criticality = ComponentCriticality.CRITICAL

    def start(self):
        logger.info("CoreComponent started.")
        self._run_schema_migrations()

    def stop(self):
        logger.info("CoreComponent stopped.")

    def _run_schema_migrations(self):
        """
        Alembic es la fuente única de verdad del esquema. Reemplaza a
        create_tables.py y a las migraciones sueltas que antes vivían
        aquí: aplica en orden las migraciones pendientes y no repite
        ninguna (el registro vive en alembic_version). Si la base de
        datos es de una instalación anterior a Alembic, se marca la
        baseline y `upgrade head` aplica solo lo pendiente.
        """

        from backend.core.database.schema_migrations import run_migrations

        run_migrations()
