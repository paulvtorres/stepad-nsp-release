from sqlalchemy import text

from backend.core.database.session import SessionLocal

from backend.shared.logging.logger import logger

from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality


class CoreComponent(BaseComponent):
    name = "core"
    criticality = ComponentCriticality.CRITICAL

    def start(self):
        logger.info("CoreComponent started.")
        self._run_schema_migrations()

    def stop(self):
        logger.info("CoreComponent stopped.")

    def _run_schema_migrations(self):
        """
        STEPAD has no Alembic/migration framework -- tables are
        created once via create_tables.py and never altered after.
        For small, additive, backwards-compatible column additions,
        running a guarded "ADD COLUMN IF NOT EXISTS" here on every
        boot is enough: it's a no-op once the column exists, and
        existing installs pick up the change automatically on their
        next restart instead of needing a manual ALTER TABLE.
        """

        statements = [

            (
                "users.failed_attempts",
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS failed_attempts "
                "INTEGER NOT NULL DEFAULT 0"
            ),

            (
                "users.locked_until",
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS locked_until TIMESTAMP"
            ),

            (
                "users.password_changed_at",
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS password_changed_at TIMESTAMP"
            ),

            (
                "users.last_login_at",
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP"
            ),

            (
                "users.totp_secret",
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS totp_secret VARCHAR(64)"
            ),

            (
                "users.mfa_enabled",
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS mfa_enabled BOOLEAN "
                "NOT NULL DEFAULT false"
            ),

            (
                "network_zones.interface_mac",
                "ALTER TABLE network_zones "
                "ADD COLUMN IF NOT EXISTS interface_mac VARCHAR(17)"
            ),

            (
                "port_forwards (table)",
                "CREATE TABLE IF NOT EXISTS port_forwards ("
                "id SERIAL PRIMARY KEY, "
                "name VARCHAR(100) NOT NULL, "
                "protocol VARCHAR(5) NOT NULL DEFAULT 'tcp', "
                "external_port INTEGER NOT NULL, "
                "internal_ip VARCHAR(45) NOT NULL, "
                "internal_port INTEGER NOT NULL, "
                "wan_interface VARCHAR(50), "
                "enabled BOOLEAN NOT NULL DEFAULT true, "
                "created_at TIMESTAMP NOT NULL DEFAULT now(), "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "vpn_peers (table)",
                "CREATE TABLE IF NOT EXISTS vpn_peers ("
                "id SERIAL PRIMARY KEY, "
                "name VARCHAR(100) NOT NULL, "
                "public_key VARCHAR(64) NOT NULL UNIQUE, "
                "allowed_ip VARCHAR(18) NOT NULL UNIQUE, "
                "client_note VARCHAR(255), "
                "expires_at TIMESTAMP, "
                "created_by INTEGER REFERENCES users(id), "
                "enabled BOOLEAN NOT NULL DEFAULT true, "
                "created_at TIMESTAMP NOT NULL DEFAULT now(), "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "notification_settings (table)",
                "CREATE TABLE IF NOT EXISTS notification_settings ("
                "id INTEGER PRIMARY KEY, "
                "enabled BOOLEAN NOT NULL DEFAULT false, "
                "smtp_host VARCHAR(255) NOT NULL DEFAULT '', "
                "smtp_port INTEGER NOT NULL DEFAULT 587, "
                "smtp_user VARCHAR(255), "
                "smtp_password VARCHAR(255), "
                "from_email VARCHAR(255) NOT NULL DEFAULT '', "
                "to_emails VARCHAR(1000) NOT NULL DEFAULT '', "
                "frequency VARCHAR(20) NOT NULL DEFAULT 'daily', "
                "send_hour INTEGER NOT NULL DEFAULT 8, "
                "send_minute INTEGER NOT NULL DEFAULT 0, "
                "last_sent_at TIMESTAMP, "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "backup_settings (table)",
                "CREATE TABLE IF NOT EXISTS backup_settings ("
                "id INTEGER PRIMARY KEY, "
                "enabled BOOLEAN NOT NULL DEFAULT false, "
                "send_hour INTEGER NOT NULL DEFAULT 3, "
                "send_minute INTEGER NOT NULL DEFAULT 0, "
                "retention_count INTEGER NOT NULL DEFAULT 7, "
                "last_backup_at TIMESTAMP, "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "organization_settings (table)",
                "CREATE TABLE IF NOT EXISTS organization_settings ("
                "id INTEGER PRIMARY KEY, "
                "company_name VARCHAR(255) NOT NULL DEFAULT '', "
                "ruc VARCHAR(50), "
                "address VARCHAR(255), "
                "phone VARCHAR(50), "
                "email VARCHAR(255), "
                "city VARCHAR(100), "
                "country VARCHAR(100), "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "alerts (table)",
                "CREATE TABLE IF NOT EXISTS alerts ("
                "id SERIAL PRIMARY KEY, "
                "alert_type VARCHAR(50) NOT NULL, "
                "severity VARCHAR(10) NOT NULL DEFAULT 'info', "
                "title VARCHAR(255) NOT NULL, "
                "message VARCHAR(500) NOT NULL, "
                "read BOOLEAN NOT NULL DEFAULT false, "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "syslog_settings (table)",
                "CREATE TABLE IF NOT EXISTS syslog_settings ("
                "id INTEGER PRIMARY KEY, "
                "enabled BOOLEAN NOT NULL DEFAULT false, "
                "server VARCHAR(255) NOT NULL DEFAULT '', "
                "port INTEGER NOT NULL DEFAULT 514, "
                "protocol VARCHAR(10) NOT NULL DEFAULT 'udp', "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "compliance_settings (table)",
                "CREATE TABLE IF NOT EXISTS compliance_settings ("
                "id INTEGER PRIMARY KEY, "
                "log_retention_days INTEGER NOT NULL DEFAULT 365, "
                "logs_reviewer_email VARCHAR(255), "
                "logs_review_frequency_days INTEGER NOT NULL DEFAULT 7, "
                "last_logs_review TIMESTAMP, "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "backup_settings.email_backup",
                "ALTER TABLE backup_settings "
                "ADD COLUMN IF NOT EXISTS email_backup "
                "BOOLEAN NOT NULL DEFAULT FALSE"
            ),

            (
                "compliance_settings.logs_reviewer_email",
                "ALTER TABLE compliance_settings "
                "ADD COLUMN IF NOT EXISTS logs_reviewer_email VARCHAR(255)"
            ),

            (
                "compliance_settings.logs_review_frequency_days",
                "ALTER TABLE compliance_settings "
                "ADD COLUMN IF NOT EXISTS logs_review_frequency_days "
                "INTEGER NOT NULL DEFAULT 7"
            ),

            (
                "compliance_settings.last_logs_review",
                "ALTER TABLE compliance_settings "
                "ADD COLUMN IF NOT EXISTS last_logs_review TIMESTAMP"
            ),

            (
                "content_categories (table + seed)",
                "CREATE TABLE IF NOT EXISTS content_categories ("
                "id SERIAL PRIMARY KEY, "
                "key VARCHAR(50) NOT NULL UNIQUE, "
                "name VARCHAR(100) NOT NULL, "
                "description VARCHAR(255), "
                "enabled BOOLEAN NOT NULL DEFAULT false, "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                "); "
                "CREATE TABLE IF NOT EXISTS category_domains ("
                "id SERIAL PRIMARY KEY, "
                "category_id INTEGER NOT NULL "
                "REFERENCES content_categories(id), "
                "domain VARCHAR(255) NOT NULL UNIQUE, "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                ")",
            ),

            (
                "device_access_rules.source",
                "ALTER TABLE device_access_rules "
                "ADD COLUMN IF NOT EXISTS source "
                "VARCHAR(20) NOT NULL DEFAULT 'manual'"
            ),

            (
                "device_access_rules.source_ref",
                "ALTER TABLE device_access_rules "
                "ADD COLUMN IF NOT EXISTS source_ref VARCHAR(50)"
            ),

            (
                "device_groups (table)",
                "CREATE TABLE IF NOT EXISTS device_groups ("
                "id SERIAL PRIMARY KEY, "
                "name VARCHAR(100) NOT NULL UNIQUE, "
                "description VARCHAR(255), "
                "is_default BOOLEAN NOT NULL DEFAULT false, "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "group_devices (table)",
                "CREATE TABLE IF NOT EXISTS group_devices ("
                "id SERIAL PRIMARY KEY, "
                "group_id INTEGER NOT NULL "
                "REFERENCES device_groups(id) ON DELETE CASCADE, "
                "device_id INTEGER NOT NULL "
                "REFERENCES network_devices(id) ON DELETE CASCADE, "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "device_access_rules.group_id",
                "ALTER TABLE device_access_rules "
                "ADD COLUMN IF NOT EXISTS group_id INTEGER "
                "REFERENCES device_groups(id)"
            ),

            (
                "group_categories (table)",
                "CREATE TABLE IF NOT EXISTS group_categories ("
                "id SERIAL PRIMARY KEY, "
                "group_id INTEGER NOT NULL "
                "REFERENCES device_groups(id) ON DELETE CASCADE, "
                "category_id INTEGER NOT NULL "
                "REFERENCES content_categories(id) ON DELETE CASCADE, "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "firewall_settings (table)",
                "CREATE TABLE IF NOT EXISTS firewall_settings ("
                "id INTEGER PRIMARY KEY, "
                "hardening_enabled BOOLEAN NOT NULL DEFAULT FALSE, "
                "last_review TIMESTAMP, "
                "last_access_review TIMESTAMP, "
                "admin_access_start_hour INTEGER, "
                "admin_access_end_hour INTEGER"
                ")"
            ),

            (
                "module_settings (table)",
                "CREATE TABLE IF NOT EXISTS module_settings ("
                "id SERIAL PRIMARY KEY, "
                "module_key VARCHAR(50) NOT NULL UNIQUE, "
                "enabled BOOLEAN NOT NULL DEFAULT TRUE, "
                "updated_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "firewall_settings.last_access_review",
                "ALTER TABLE firewall_settings "
                "ADD COLUMN IF NOT EXISTS last_access_review TIMESTAMP"
            ),

            (
                "firewall_settings.admin_access_start_hour",
                "ALTER TABLE firewall_settings "
                "ADD COLUMN IF NOT EXISTS admin_access_start_hour INTEGER"
            ),

            (
                "firewall_settings.admin_access_end_hour",
                "ALTER TABLE firewall_settings "
                "ADD COLUMN IF NOT EXISTS admin_access_end_hour INTEGER"
            ),

            (
                "config_revisions (table)",
                "CREATE TABLE IF NOT EXISTS config_revisions ("
                "id SERIAL PRIMARY KEY, "
                "label VARCHAR(255) NOT NULL DEFAULT '', "
                "data TEXT NOT NULL, "
                "created_by INTEGER REFERENCES users(id), "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

            (
                "network_devices.display_name",
                "ALTER TABLE network_devices "
                "ADD COLUMN IF NOT EXISTS display_name VARCHAR(255)"
            ),

            (
                "network_devices.bandwidth_limit_kbps",
                "ALTER TABLE network_devices "
                "ADD COLUMN IF NOT EXISTS bandwidth_limit_kbps INTEGER"
            ),

            (
                "device_groups.bandwidth_limit_kbps",
                "ALTER TABLE device_groups "
                "ADD COLUMN IF NOT EXISTS bandwidth_limit_kbps INTEGER"
            ),

            (
                "network_devices.linked_to_id",
                "ALTER TABLE network_devices "
                "ADD COLUMN IF NOT EXISTS linked_to_id INTEGER "
                "REFERENCES network_devices(id)"
            ),

            (
                "managed_interfaces (table)",
                "CREATE TABLE IF NOT EXISTS managed_interfaces ("
                "id SERIAL PRIMARY KEY, "
                "mac_address VARCHAR(17) NOT NULL UNIQUE, "
                "display_name VARCHAR(100), "
                "role VARCHAR(10), "
                "priority INTEGER NOT NULL DEFAULT 100, "
                "status VARCHAR(20) NOT NULL DEFAULT 'pending_assignment', "
                "last_seen_name VARCHAR(50), "
                "last_seen_at TIMESTAMP, "
                "created_at TIMESTAMP NOT NULL DEFAULT now()"
                ")"
            ),

        ]

        db = SessionLocal()

        try:

            for label, statement in statements:

                try:

                    db.execute(text(statement))

                    db.commit()

                except Exception as error:

                    db.rollback()

                    logger.error(
                        f"Schema migration failed for {label}: {error}"
                    )

        finally:

            db.close()