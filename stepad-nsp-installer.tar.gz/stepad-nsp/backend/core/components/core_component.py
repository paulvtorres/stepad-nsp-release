from backend.shared.logging.logger import logger

from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.shared.datetime_utils import utcnow


class CoreComponent(BaseComponent):
    name = "core"
    criticality = ComponentCriticality.CRITICAL

    def start(self):
        logger.info("CoreComponent started.")
        try:
            self._run_schema_migrations()
        except Exception as exc:
            logger.critical(
                "CoreComponent: FALLO CRITICO en migraciones de esquema: %s. "
                "La base de datos podria estar en estado inconsistente. "
                "Revise los logs y la tabla de alertas.",
                exc,
            )
            self._emit_critical_alert(
                "Migraciones de esquema fallaron: %s" % exc,
            )
            raise

        # Secretos: garantiza que la clave restic exista y que haya una
        # copia reciente en env-backups en cada arranque (no solo cada
        # update). Si la clave llegó a faltar, la restaura desde los
        # backups; nunca rota sola.
        try:
            from backend.core.config.secret_manager import ensure_env_backup
            backup = ensure_env_backup()
            logger.info(
                "Secretos verificados %s",
                f"(backup: {backup.name})" if backup else "(sin backup)",
            )
        except Exception as exc:
            logger.error(
                "No se pudo verificar secretos al arrancar: %s", exc,
            )

    def stop(self):
        logger.info("CoreComponent stopped.")

    def _run_schema_migrations(self):
        from backend.core.database.schema_migrations import run_migrations
        run_migrations()

    def _emit_critical_alert(self, message):
        """Alerta crítica; AlertService envía correo inmediato."""

        try:
            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()
            try:
                AlertService().create(
                    db,
                    alert_type="STARTUP_CRITICAL",
                    severity="critical",
                    title="NSP: error critico en arranque",
                    message=message[:500],
                )
                db.commit()
            finally:
                db.close()
        except Exception as alert_exc:
            logger.error(
                "No pude crear alerta critica en DB: %s", alert_exc,
            )
