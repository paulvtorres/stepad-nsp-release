from abc import ABC, abstractmethod
from backend.core.component_state import ComponentState


class Component(ABC):

    def __init__(self):

        self.state = ComponentState.STOPPED

    @abstractmethod
    def name(self):
        pass

    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def stop(self):
        pass
