from enum import Enum


class Lifecycle(Enum):

    STOPPED = "Stopped"

    STARTING = "Starting"

    RUNNING = "Running"

    STOPPING = "Stopping"

    ERROR = "Error"
