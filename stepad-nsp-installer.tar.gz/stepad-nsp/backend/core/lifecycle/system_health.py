from dataclasses import dataclass

from backend.core.lifecycle.component_health import ComponentHealth


@dataclass
class SystemHealth:

    status: str

    components: list[ComponentHealth]