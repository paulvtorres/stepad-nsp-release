from dataclasses import dataclass, field

from backend.core.lifecycle.component_status import (
    ComponentStatus
)


@dataclass
class ComponentHealth:

    name: str

    status: ComponentStatus

    message: str

    details: list = field(default_factory=list)
    