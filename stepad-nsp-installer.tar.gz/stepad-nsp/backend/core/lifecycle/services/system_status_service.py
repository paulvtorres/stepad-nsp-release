from backend.shared.runtime import runtime


class SystemStatusService:

    def get_status(self):

        states = dict(runtime.all())

        # El estado del componente se registra al arrancar, pero dnsmasq
        # puede caerse después. El panel debe reflejar el proceso real,
        # no el estado congelado del arranque.
        try:

            from backend.dhcp.services.dhcp_health_service import (
                DhcpHealthService,
            )

            snap = DhcpHealthService().inspect()

            current = dict(states.get("dhcp") or {})

            current.update(
                {
                    "status": "running" if snap.get("healthy") else "failed",
                    "pid": snap.get("pid"),
                    "running": bool(snap.get("running")),
                    "stuck": bool(snap.get("stuck")),
                    "recv_q": snap.get("recv_q"),
                    "error": (
                        None
                        if snap.get("healthy")
                        else "DHCP no operativo"
                    ),
                }
            )

            states["dhcp"] = current

        except Exception:

            # Si no se puede consultar, no declarar DHCP sano.
            current = dict(states.get("dhcp") or {})
            current.update(
                {
                    "status": "failed",
                    "error": "No se pudo verificar DHCP",
                }
            )
            states["dhcp"] = current

        healthy = all(
            state.get("status") == "running"
            for state in states.values()
        )

        return {
            "status": "healthy" if healthy else "degraded",
            "components": states,
        }
