from backend.shared.runtime import runtime


class SystemStatusService:

    def get_status(self, db=None):

        states = dict(runtime.all())

        # El estado del componente se registra al arrancar, pero dnsmasq
        # puede caerse después. El panel debe reflejar el proceso real,
        # no el estado congelado del arranque.
        try:

            from backend.dhcp.services.dhcp_health_service import (
                DhcpHealthService,
            )

            snap = DhcpHealthService().inspect()

            current = dict(states.get("dhcp") or {})

            current.update(
                {
                    "status": "running" if snap.get("healthy") else "failed",
                    "pid": snap.get("pid"),
                    "running": bool(snap.get("running")),
                    "stuck": bool(snap.get("stuck")),
                    "recv_q": snap.get("recv_q"),
                    "error": (
                        None
                        if snap.get("healthy")
                        else "DHCP no operativo"
                    ),
                }
            )

            states["dhcp"] = current

        except Exception:

            # Si no se puede consultar, no declarar DHCP sano.
            current = dict(states.get("dhcp") or {})
            current.update(
                {
                    "status": "failed",
                    "error": "No se pudo verificar DHCP",
                }
            )
            states["dhcp"] = current

        # DNS, IPS, NAT, listener, disco y zonas también forman parte del
        # estado operativo. Antes el panel podía decir "healthy" con el
        # DNS o Suricata caídos.
        if db is not None:

            try:

                from backend.monitoring.services.navigation_health_service import (
                    NavigationHealthService,
                )

                report = NavigationHealthService().inspect(db)

                for key, check in (report.get("checks") or {}).items():

                    current = dict(states.get(key) or {})

                    current.update(
                        {
                            "status": "running" if check.get("ok") else "failed",
                            "detail": check.get("detail"),
                            "error": None if check.get("ok") else check.get("detail"),
                        }
                    )

                    states[key] = current

            except Exception as error:

                states["navigation_health"] = {
                    "status": "failed",
                    "error": f"No se pudo verificar: {type(error).__name__}",
                }

        healthy = all(
            state.get("status") == "running"
            for state in states.values()
        )

        return {
            "status": "healthy" if healthy else "degraded",
            "components": states,
        }
