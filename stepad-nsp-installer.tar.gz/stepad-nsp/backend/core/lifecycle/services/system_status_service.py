from backend.shared.runtime import runtime

class SystemStatusService:

    def get_status(self):

        states = runtime.all()

        healthy = all(
            state.get("status") == "running"
            for state in states.values()
        )

        return {

            "status": "healthy" if healthy else "degraded",

            "components": states

        }
