import threading
import time

from backend.shared.logging.logger import logger
from backend.shared.runtime import runtime

from backend.core.lifecycle.component_status import ComponentStatus
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.shared.datetime_utils import utcnow


class ComponentLifecycleManager:
    """
    Controls lifecycle of all NSP components.
    """

    def __init__(self):
        self.components = []
        self._failures = []
        self._supervisor_stop = threading.Event()
        self._supervisor_thread = None
        self._last_recovery_attempt: dict[str, float] = {}

    def register(self, component):
        self.components.append(component)

        runtime.set(
            component.name,
            ComponentStatus.PENDING.value
        )

        logger.info(f"Registered component: {component.name}")

    def start_all(self):
        logger.info("Starting component lifecycle...")

        self._start_supervisor()

        for component in self.components:

            # Los componentes críticos (core/API) no se reintentan aquí:
            # si fallan, el proceso debe terminar para que systemd lo
            # reinicie. Los servicios importantes sí toleran fallos
            # transitorios de arranque.
            attempts = (
                1
                if component.criticality == ComponentCriticality.CRITICAL
                else 3
            )

            last_error = None

            for attempt in range(1, attempts + 1):

                try:
                    logger.info(
                        "Starting %s (intento %s/%s)",
                        component.name,
                        attempt,
                        attempts,
                    )

                    runtime.set(
                        component.name,
                        ComponentStatus.STARTING.value
                    )

                    component.start()

                    runtime.set(
                        component.name,
                        ComponentStatus.RUNNING.value
                    )

                    logger.info(f"{component.name} is RUNNING")

                    last_error = None

                    break

                except Exception as e:

                    last_error = e

                    logger.exception(
                        "%s fallo al iniciar (intento %s/%s): %s",
                        component.name,
                        attempt,
                        attempts,
                        e,
                    )

                    if attempt < attempts:

                        delay = min(10, attempt * 2)

                        time.sleep(delay)

            if last_error is None:

                continue

            e = last_error

            runtime.set(
                component.name,
                ComponentStatus.FAILED.value,
                error=f"{type(e).__name__}: {e}"
            )

            self._failures.append({
                "component": component.name,
                "error": f"{type(e).__name__}: {e}",
            })

            logger.critical(
                "Componente %s fallo al iniciar definitivamente: %s.",
                component.name, e,
            )

            self._emit_failure_alert(component.name, e)

            if component.criticality == ComponentCriticality.CRITICAL:

                raise RuntimeError(
                    f"Componente crítico {component.name} no pudo iniciar: {e}"
                )

        if self._failures:
            failed_names = [f["component"] for f in self._failures]
            logger.critical(
                "Arranque incompleto: %d componente(s) fallaron: %s. "
                "Revise la tabla de alertas para detalles.",
                len(self._failures),
                ", ".join(failed_names),
            )

    def _start_supervisor(self):
        if self._supervisor_thread and self._supervisor_thread.is_alive():
            return

        self._supervisor_stop.clear()
        self._supervisor_thread = threading.Thread(
            target=self._supervisor_loop,
            daemon=True,
            name="component-supervisor",
        )
        self._supervisor_thread.start()

    def _supervisor_loop(self):
        # Da tiempo al arranque inicial y a sus reintentos.
        if self._supervisor_stop.wait(30):
            return
        while not self._supervisor_stop.is_set():
            try:
                self._supervisor_cycle()
            except Exception as error:
                logger.warning("Component supervisor: %s", error)
            if self._supervisor_stop.wait(30):
                return

    def _supervisor_cycle(self):
        now = time.monotonic()
        for component in self.components:
            if component.criticality == ComponentCriticality.CRITICAL:
                continue
            state = runtime.get(component.name) or {}
            status = state.get("status")
            try:
                healthy = bool(component.health_check())
            except Exception:
                healthy = False
            failed = status == ComponentStatus.FAILED.value or not healthy
            if not failed:
                continue
            last = self._last_recovery_attempt.get(component.name, 0.0)
            if now - last < 120:
                continue
            self._last_recovery_attempt[component.name] = now
            logger.warning(
                "Componente %s caído; intentando recuperación automática.",
                component.name,
            )
            try:
                component.start()
                runtime.set(component.name, ComponentStatus.RUNNING.value)
                self._emit_recovery_alert(component.name)
                logger.info("Componente %s recuperado automáticamente.", component.name)
            except Exception as error:
                runtime.set(
                    component.name,
                    ComponentStatus.FAILED.value,
                    error=f"{type(error).__name__}: {error}",
                )
                logger.warning(
                    "Componente %s no pudo recuperarse: %s",
                    component.name,
                    error,
                )

    def _emit_recovery_alert(self, component_name):
        try:
            from backend.core.database.connection import engine
            from sqlalchemy import text

            with engine.connect() as conn:
                conn.execute(
                    text(
                        "INSERT INTO alerts (alert_type, severity, title, "
                        "message, read, created_at) VALUES "
                        "(:at, :sev, :title, :msg, false, :ts)"
                    ),
                    {
                        "at": "COMPONENT_RECOVERED",
                        "sev": "info",
                        "title": f"Componente {component_name} recuperado",
                        "msg": "El componente se recuperó automáticamente.",
                        "ts": utcnow(),
                    },
                )
                conn.commit()
        except Exception as alert_exc:
            logger.error("No pude crear alerta de recuperación: %s", alert_exc)

    def stop_all(self):
        logger.info("Stopping all components...")

        self._supervisor_stop.set()
        supervisor = self._supervisor_thread
        if supervisor and supervisor.is_alive():
            supervisor.join(timeout=3)
        self._supervisor_thread = None

        for component in reversed(self.components):
            try:

                component.stop()

                runtime.set(
                    component.name,
                    ComponentStatus.STOPPED.value
                )

                logger.info(f"{component.name} stopped")

            except Exception as e:

                runtime.set(
                    component.name,
                    ComponentStatus.FAILED.value,
                    error=f"{type(e).__name__}: {e}"
                )

                logger.exception(
                    f"{component.name} stop failed: {e}"
                )

    def _emit_failure_alert(self, component_name, error):
        """Crea una alerta CRITICA en la DB cuando un componente falla."""
        try:
            from datetime import datetime
            from backend.core.database.connection import engine
            from sqlalchemy import text

            with engine.connect() as conn:
                conn.execute(
                    text(
                        "INSERT INTO alerts (alert_type, severity, title, "
                        "message, read, created_at) VALUES "
                        "(:at, :sev, :title, :msg, false, :ts)"
                    ),
                    {
                        "at": "COMPONENT_FAILURE",
                        "sev": "critical",
                        "title": f"Componente {component_name} fallo",
                        "msg": f"{type(error).__name__}: {error}"[:500],
                        "ts": utcnow(),
                    },
                )
                conn.commit()
        except Exception as alert_exc:
            logger.error(
                "No pude crear alerta de fallo de componente: %s",
                alert_exc,
            )
