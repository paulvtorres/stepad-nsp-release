from backend.shared.logging.logger import logger
from backend.shared.runtime import runtime

from backend.core.lifecycle.component_status import ComponentStatus


class ComponentLifecycleManager:
    """
    Controls lifecycle of all NSP components.
    """

    def __init__(self):
        self.components = []

    def register(self, component):
        self.components.append(component)

        runtime.set(
            component.name,
            ComponentStatus.PENDING.value
        )

        logger.info(f"Registered component: {component.name}")

    def start_all(self):
        logger.info("Starting component lifecycle...")

        for component in self.components:
            try:
                logger.info(f"Starting {component.name}")

                runtime.set(
                    component.name,
                    ComponentStatus.STARTING.value
                )

                component.start()
                if component.name == "api":

                    runtime.set(
                        component.name,
                        ComponentStatus.RUNNING.value
                    )

                    continue

                runtime.set(
                    component.name,
                    ComponentStatus.RUNNING.value
                )

                logger.info(f"{component.name} is RUNNING")

            except Exception as e:

                runtime.set(
                    component.name,
                    ComponentStatus.FAILED.value,
                    error=f"{type(e).__name__}: {e}"
                )

                logger.exception(
                    f"{component.name} failed: {e}"
                )

    def stop_all(self):
        logger.info("Stopping all components...")

        for component in reversed(self.components):
            try:

                component.stop()

                runtime.set(
                    component.name,
                    ComponentStatus.STOPPED.value
                )

                logger.info(f"{component.name} stopped")

            except Exception as e:

                runtime.set(
                    component.name,
                    ComponentStatus.FAILED.value,
                    error=f"{type(e).__name__}: {e}"
                )

                logger.exception(
                    f"{component.name} stop failed: {e}"
                )