import os

import time

from pathlib import Path

import psutil

from backend.core.config.paths import STEPAD_PID_FILE

from backend.shared.logging.logger import logger


# Checked as a distinct argv element (not a substring of the joined
# command line) -- see _looks_like_stepad()'s docstring for why that
# distinction matters.
MODULE_ARG = "backend.main"

TERMINATE_WAIT_SECONDS = 5


class SingleInstanceGuard:
    """
    STEPAD is meant to be the only thing running on the appliance it
    ships on -- so if startup finds a previous STEPAD process still
    alive (holding port 8000, port 4242, nftables rules, the DHCP/DNS
    daemons, etc.), the right behavior for an appliance is to stop it
    automatically and take over, not fail with "address already in
    use" and wait for someone to SSH in and kill it by hand. That's
    fine for a developer's laptop; it's not acceptable for a device
    an end customer just powers on.

    Tracks the running instance via a PID file (STEPAD_PID_FILE).
    """

    def ensure_single_instance(self):

        self._own_ancestor_pids = self._get_own_ancestor_pids()

        self._stop_stale_instance()

        self._stop_other_matching_processes()

        self._write_pid_file()


    def _get_own_ancestor_pids(self) -> set:
        """
        Never a candidate for stopping, no matter what its cmdline
        looks like -- e.g. when launched via `sudo python3 -m
        backend.main`, the sudo session's own monitor process is our
        parent, and (on Debian's default `use_pty` sudo config) its
        cmdline is literally the full "sudo ... python3 -m
        backend.main" invocation, which would otherwise satisfy the
        cmdline check below. Killing an ancestor of our own process
        takes us down with it -- this was found the hard way (a
        `sudo`-launched run killed itself via this exact path).
        """

        ancestors = set()

        try:

            process = psutil.Process(os.getpid())

            while True:

                parent = process.parent()

                if parent is None:

                    break

                ancestors.add(parent.pid)

                process = parent

        except psutil.NoSuchProcess:

            pass

        return ancestors


    def _looks_like_stepad(
        self,
        process: psutil.Process
    ) -> bool:
        """
        A PID file surviving a crash/reboot can end up pointing at a
        PID that the OS has since handed to a COMPLETELY unrelated
        process (PIDs get reused). Killing that blindly because a
        stale file said so would be a real hazard on a general-
        purpose Debian box, and even on a dedicated appliance it is
        needless risk when a one-line check avoids it entirely: only
        ever terminate a process whose own command line shows it's
        actually STEPAD.

        Matching is deliberately strict, on TWO conditions together:
          1. argv[0] (the executable) is a python interpreter --
             rules out `sudo`, `su`, `pkexec`, a shell, etc. even
             though their OWN argv often contains the full command
             they're about to run as a substring.
          2. "backend.main" appears as its OWN argv element (i.e.
             the actual `-m backend.main` invocation), not merely
             somewhere in the joined command-line string.

        A plain substring check on the joined cmdline (the previous
        version of this code) matches both a real STEPAD process AND
        a `sudo` wrapper whose argv happens to quote that same
        command -- which is exactly the bug this version fixes.
        """

        try:

            cmdline = process.cmdline()

        except (psutil.NoSuchProcess, psutil.AccessDenied):

            return False

        if not cmdline:

            return False

        executable_name = Path(cmdline[0]).name

        if not executable_name.startswith("python"):

            return False

        return MODULE_ARG in cmdline


    def _stop_process(
        self,
        process: psutil.Process
    ):

        process.terminate()

        try:

            process.wait(timeout=TERMINATE_WAIT_SECONDS)

        except psutil.TimeoutExpired:

            logger.warning(
                f"PID {process.pid} didn't stop within "
                f"{TERMINATE_WAIT_SECONDS}s -- forcing it."
            )

            process.kill()

            process.wait(timeout=TERMINATE_WAIT_SECONDS)

        logger.info(f"Previous instance (PID {process.pid}) stopped.")


    def _stop_other_matching_processes(self):
        """
        The PID-file check above only catches a previous instance
        that THIS mechanism itself started and tracked. It can't see
        one that predates it -- e.g. the very first boot after
        upgrading to this code, where stepad-nsp.service was already
        running from before this file existed. Belt-and-suspenders:
        scan every running process for our own cmdline signature and
        stop any match that isn't us (or one of our own ancestors --
        see _get_own_ancestor_pids), regardless of what the PID file
        says or whether it exists at all.
        """

        our_pid = os.getpid()

        for process in psutil.process_iter(["pid"]):

            if process.pid == our_pid:

                continue

            if process.pid in self._own_ancestor_pids:

                continue

            if not self._looks_like_stepad(process):

                continue

            logger.warning(
                f"Found another STEPAD instance running (PID "
                f"{process.pid}) that wasn't tracked by stepad.pid "
                f"(likely started before this check existed, e.g. "
                f"by systemd) -- stopping it."
            )

            try:

                self._stop_process(process)

            except (psutil.NoSuchProcess, psutil.AccessDenied) as error:

                logger.error(
                    f"Could not stop PID {process.pid}: {error}"
                )

        # Give the kernel a moment to release any sockets freed above
        # before we try to bind them ourselves.
        time.sleep(1)


    def _stop_stale_instance(self):

        if not STEPAD_PID_FILE.exists():

            return

        try:

            old_pid = int(STEPAD_PID_FILE.read_text().strip())

        except (ValueError, OSError):

            return

        if old_pid == os.getpid() or old_pid in self._own_ancestor_pids:

            return

        try:

            process = psutil.Process(old_pid)

        except psutil.NoSuchProcess:

            # Already dead (clean shutdown that didn't clean up the
            # file, or a crash) -- nothing to do.
            return

        if not self._looks_like_stepad(process):

            logger.warning(
                f"stepad.pid pointed at PID {old_pid}, but that "
                f"process isn't STEPAD (PID likely reused by "
                f"something else since STEPAD last ran) -- leaving "
                f"it alone."
            )

            return

        logger.warning(
            f"A previous STEPAD instance is still running (PID "
            f"{old_pid}). Only one instance should run on this "
            f"appliance -- stopping it before continuing."
        )

        self._stop_process(process)

        # Give the kernel a moment to actually release the sockets
        # (port 8000, 4242) before we try to bind them ourselves.
        time.sleep(1)


    def _write_pid_file(self):

        STEPAD_PID_FILE.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        STEPAD_PID_FILE.write_text(
            str(os.getpid())
        )


    def release(self):

        try:

            if (
                STEPAD_PID_FILE.exists()
                and STEPAD_PID_FILE.read_text().strip() == str(os.getpid())
            ):

                STEPAD_PID_FILE.unlink()

        except OSError:

            pass


single_instance_guard = SingleInstanceGuard()
