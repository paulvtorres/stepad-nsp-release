from backend.core.lifecycle import Lifecycle
from backend.shared.logging.logger import logger

class NSPService:

    def __init__(self):

        self.state = Lifecycle.STOPPED

    def start(self):

        self.state = Lifecycle.STARTING

        logger.info("Core service starting...")

        self.state = Lifecycle.RUNNING

        logger.info("Core service running.")

    def get_state(self):

        return self.state
