"""
Registro de TODOS los modelos de STEPAD NSP.

Importar este modulo registra todas las tablas en `Base.metadata`,
de modo que `Base.metadata.create_all(engine)` crea el esquema completo
(antes create_tables.py solo importaba 3 modelos y core_component
cubria 17 con SQL hardcodeado -> 9 tablas quedaban sin crear en una
instalacion nueva).
"""

# Al importar cada modulo, su clase hereda de Base y queda registrada.
from backend.alerts.models import alert  # noqa: F401
from backend.audit.models import audit_log  # noqa: F401
from backend.backups.models import backup_settings  # noqa: F401
from backend.backups.models import cloud_storage_settings  # noqa: F401
from backend.config_revisions.models import config_revision  # noqa: F401
from backend.content.models import content_category  # noqa: F401
from backend.content.models import domain_group  # noqa: F401
from backend.dns.logging.models import dns_query_log  # noqa: F401
from backend.dns.logging.models import sni_log  # noqa: F401
from backend.firewall.models import firewall_interface  # noqa: F401
from backend.firewall.models import firewall_settings  # noqa: F401
from backend.groups.models import device_group  # noqa: F401
from backend.ips.models import threat_response_setting  # noqa: F401
from backend.ips.models import malware_event  # noqa: F401
from backend.ips.models import egress_flow_stat  # noqa: F401
from backend.monitoring.models import wan_monitor  # noqa: F401
from backend.nat.models import port_forward  # noqa: F401
from backend.network.devices.models import network_device  # noqa: F401
from backend.network.devices.models import device_ip_history  # noqa: F401
from backend.network.interfaces.registry.models import managed_interface  # noqa: F401
from backend.network.zones.models import network_zone  # noqa: F401
from backend.network.zones.models import schedule  # noqa: F401
from backend.notifications.models import notification_settings  # noqa: F401
from backend.notifications.models import email_settings  # noqa: F401
from backend.organization.models import organization_settings  # noqa: F401
from backend.retention.models import retention_setting  # noqa: F401
from backend.rules.models import device_access_rule  # noqa: F401
from backend.siem.models import compliance_settings  # noqa: F401
from backend.siem.models import syslog_settings  # noqa: F401
from backend.system.models import module_settings  # noqa: F401
from backend.users.models import user  # noqa: F401
from backend.vpn.models import vpn_peer  # noqa: F401
from backend.rustdesk.models import rustdesk_settings  # noqa: F401
from backend.shares.models import network_share_settings  # noqa: F401
from backend.shares.models import network_share_folder  # noqa: F401
from backend.shares.models import network_share_volume  # noqa: F401
from backend.shares.models import network_share_backup_job  # noqa: F401
