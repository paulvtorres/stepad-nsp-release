from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


# Importar modelos para registrar metadata
from backend.core.database import models