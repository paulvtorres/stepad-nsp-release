from sqlalchemy import create_engine

from backend.core.config.settings import Settings


def _database_url() -> str:

    host = Settings.DB_HOST

    # Si DB_HOST es una ruta (ej. /var/run/postgresql) se usa el
    # socket Unix de Postgres, que es más fiable que TCP (evita
    # timeouts en equipos con la pila IPv4/IPv6 degradada).
    if host.startswith("/"):

        return (
            f"postgresql+psycopg2://"
            f"{Settings.DB_USER}:{Settings.DB_PASSWORD}@"
            f"/{Settings.DB_NAME}?host={host}&port={Settings.DB_PORT}"
        )

    return (
        f"postgresql+psycopg2://"
        f"{Settings.DB_USER}:{Settings.DB_PASSWORD}@"
        f"{host}:{Settings.DB_PORT}/"
        f"{Settings.DB_NAME}"
    )


DATABASE_URL = _database_url()


engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=10,
)