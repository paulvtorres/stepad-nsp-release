import os

from pathlib import Path

from alembic import command
from alembic.config import Config

from sqlalchemy import inspect

from backend.shared.logging.logger import logger


# backend/core/database/schema_migrations.py -> parents[3] = raiz del repo
REPO_ROOT = Path(__file__).resolve().parents[3]


def _load_env_file():

    env_file = Path("/etc/stepad/stepad.env")

    if "DB_PASSWORD" in os.environ or not env_file.exists():

        return

    try:

        for line in env_file.read_text().splitlines():

            line = line.strip()

            if line and not line.startswith("#") and "=" in line:

                key, _, value = line.partition("=")

                os.environ.setdefault(key, value)

    except Exception:

        pass


def _config():

    cfg = Config(str(REPO_ROOT / "alembic.ini"))

    cfg.set_main_option(
        "prepend_sys_path",
        str(REPO_ROOT)
    )

    cfg.set_main_option(
        "script_location",
        str(REPO_ROOT / "backend" / "migrations")
    )

    return cfg


def _table_exists(engine, table: str) -> bool:

    return table in inspect(engine).get_table_names()


def run_migrations():

    """Aplica las migraciones pendientes con Alembic.

    Fuente unica de verdad del esquema: reemplaza a create_tables.py y
    a las migraciones sueltas que vivian en core_component.py. Si la
    base de datos es de una instalacion anterior a Alembic (existen
    tablas de la app pero no existe alembic_version), se marca la
    baseline (stamp 0001) para que `upgrade head` aplique SOLO lo
    pendiente y nunca intente re-crear tablas ya existentes.
    """

    _load_env_file()

    from backend.core.database.connection import engine

    cfg = _config()

    if not _table_exists(engine, "alembic_version"):

        if _table_exists(engine, "users"):

            logger.info(
                "Base de datos existente sin historial Alembic: "
                "marcando baseline (stamp 0001)."
            )

            command.stamp(cfg, "0001")

        else:

            logger.info(
                "Base de datos nueva: se aplicara el esquema completo "
                "desde la baseline."
            )

    command.upgrade(cfg, "head")

    logger.info(
        "Esquema sincronizado por Alembic (upgrade head)."
    )


if __name__ == "__main__":

    run_migrations()
