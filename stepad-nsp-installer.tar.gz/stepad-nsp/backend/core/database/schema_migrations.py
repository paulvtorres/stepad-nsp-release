import os

from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory

from sqlalchemy import inspect

from backend.shared.logging.logger import logger


# backend/core/database/schema_migrations.py -> parents[3] = raiz del repo
REPO_ROOT = Path(__file__).resolve().parents[3]


def _load_env_file():

    env_file = Path("/etc/stepad/stepad.env")

    if "DB_PASSWORD" in os.environ or not env_file.exists():

        return

    try:

        for line in env_file.read_text().splitlines():

            line = line.strip()

            if line and not line.startswith("#") and "=" in line:

                key, _, value = line.partition("=")

                os.environ.setdefault(key, value)

    except Exception:

        pass


def _config():

    cfg = Config(str(REPO_ROOT / "alembic.ini"))

    cfg.set_main_option(
        "prepend_sys_path",
        str(REPO_ROOT)
    )

    cfg.set_main_option(
        "script_location",
        str(REPO_ROOT / "backend" / "migrations")
    )

    return cfg


def _table_exists(engine, table: str) -> bool:

    return table in inspect(engine).get_table_names()


def _head_revision(cfg) -> str:

    script = ScriptDirectory.from_config(cfg)

    heads = script.get_heads()

    return heads[0] if heads else None


def run_migrations():

    """Aplica las migraciones pendientes con Alembic.

    Fuente unica de verdad del esquema: reemplaza a create_all y a las
    migraciones sueltas que vivian en core_component.py. El sello se
    decide segun el estado real de la base:

    - sin alembic_version y sin tablas de la app  -> BD nueva:
      `upgrade head` aplica el esquema completo.
    - sin alembic_version y sin tablas nuevas      -> instalacion
      anterior a Alembic: se marca la baseline y `upgrade head`
      aplica SOLO lo pendiente (nunca re-crea lo existente).
    - sin alembic_version pero con el esquema
      completo (install.py legacy con create_all)  -> se marca head
      para no volver a crear tablas ya existentes.
    - con alembic_version                          -> `upgrade head`
      (no-op si ya esta en head).
    """

    _load_env_file()

    from backend.core.database.connection import engine

    cfg = _config()

    if not _table_exists(engine, "alembic_version"):

        if _table_exists(engine, "users"):

            if (
                _table_exists(engine, "malware_events")
                and _table_exists(engine, "threat_response_settings")
            ):

                head = _head_revision(cfg)

                logger.info(
                    "Esquema completo presente sin historial Alembic: "
                    "marcando head (%s).",
                    head
                )

                command.stamp(cfg, head)

            else:

                logger.info(
                    "Base de datos existente sin historial Alembic: "
                    "marcando baseline (0001) y aplicando pendientes."
                )

                command.stamp(cfg, "0001")

        else:

            logger.info(
                "Base de datos nueva: se aplicara el esquema completo "
                "desde la baseline."
            )

    command.upgrade(cfg, "head")

    logger.info(
        "Esquema sincronizado por Alembic (upgrade head)."
    )


if __name__ == "__main__":

    run_migrations()
