import threading
from backend.shared.logging.logger import logger

class ComponentManager:

    def __init__(self):

        self.components = []
        self.threads = []

    def register(self, component):

        self.components.append(component)

    def start(self):

        logger.info("Starting components in runtime mode...")

        for component in self.components:

            thread = threading.Thread(
                target=self._run_component,
                args=(component,),
                daemon=True
            )

            self.threads.append(thread)
            thread.start()

        logger.info("All components running.")

    def _run_component(self, component):

        try:

            logger.info(f"Starting {component.name()}")

            component.state = "RUNNING"

            component.start()

        except Exception as e:

            component.state = "FAILED"

            logger.error(f"[ERROR] {component.name()} failed: {e}")

    def stop_all(self):

        logger.info("Stopping all components...")

        for component in self.components:

            try:

                component.stop()
                component.state = "STOPPED"

                logger.info(f"{component.name()} stopped")

            except Exception as e:

                logger.error(f"[ERROR] stopping {component.name()}: {e}")
