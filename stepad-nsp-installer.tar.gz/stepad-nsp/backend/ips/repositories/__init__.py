from backend.ips.repositories.malware_event_repository import MalwareEventRepository  # noqa: F401
