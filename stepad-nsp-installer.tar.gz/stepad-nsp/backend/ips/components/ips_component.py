import threading

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import (
    ComponentCriticality
)

from backend.ips.services.suricata_alert_ingest import (
    SuricataAlertIngest
)

from backend.shared.logging.logger import logger


class IpsComponent(BaseComponent):


    name = "ips"

    criticality = ComponentCriticality.OPTIONAL


    def __init__(self):

        self.ingest = SuricataAlertIngest()


    def start(self):

        self._thread = threading.Thread(
            target=self.ingest.run_forever,
            daemon=True,
            name="suricata-alert-ingest"
        )

        self._thread.start()

        logger.info(
            "IpsComponent iniciado (ingesta de alertas Suricata)."
        )


    def stop(self):

        logger.info(
            "IpsComponent detenido."
        )
