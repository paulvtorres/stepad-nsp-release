import threading

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import (
    ComponentCriticality
)

from backend.ips.services.suricata_alert_ingest import (
    SuricataAlertIngest
)

from backend.dns.logging.services.sni_log_ingest import (
    sni_log_ingest
)

from backend.ips.services.threat_response_service import (
    threat_response_service
)

from backend.shared.logging.logger import logger


class IpsComponent(BaseComponent):


    name = "ips"

    criticality = ComponentCriticality.OPTIONAL


    def __init__(self):

        self.ingest = SuricataAlertIngest()


    def start(self):

        self._thread = threading.Thread(
            target=self.ingest.run_forever,
            daemon=True,
            name="suricata-alert-ingest"
        )

        self._thread.start()

        # Registro de conexiones HTTPS por dominio (SNI): cada handshake
        # TLS de un equipo deja el dominio exacto al que se conecta.
        self._sni_thread = threading.Thread(
            target=sni_log_ingest.run_forever,
            daemon=True,
            name="suricata-sni-ingest"
        )

        self._sni_thread.start()

        try:

            threat_response_service.sync_c2_rules()

        except Exception as error:

            logger.exception(
                "Fallo la sincronizacion de bloqueos C2 al arrancar: %s",
                error
            )

        logger.info(
            "IpsComponent iniciado (alertas Suricata + SNI)."
        )


    def stop(self):

        logger.info(
            "IpsComponent detenido."
        )
