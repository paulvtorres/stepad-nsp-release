"""Clasificación de detecciones IPS por TIPO.

Fuente única para etiquetar (y decidir si genera alerta/notificación) una
detección de Suricata: evita confundir ataques reales con política/hunting.

Devuelve (kind, label, severity):
  kind: malware | exploit | dos | recon | suspicious | policy | other
"""
from __future__ import annotations

# Tipos que ameritan ALERTA/notificación (amenaza real o sospechosa).
NOTIFY_KINDS = {"malware", "exploit", "dos", "recon", "suspicious"}

# Tipos que NO se auditan como "ataque externo" (ruido de política).
NOISE_KINDS = {"policy"}

_LABELS = {
    "malware": "Malware",
    "exploit": "Explotación",
    "dos": "DoS",
    "recon": "Escaneo",
    "suspicious": "Sospechoso",
    "policy": "Política",
    "other": "Otro",
}

_SEVERITY = {
    "malware": "critical",
    "exploit": "critical",
    "dos": "critical",
    "recon": "warning",
    "suspicious": "warning",
    "policy": "info",
    "other": "info",
}


def classify(signature, category):
    text = ((signature or "") + " " + (category or "")).upper()

    if any(k in text for k in (
        "MALWARE", "TROJAN", "BOTNET", "CNC", "C2", "SPYWARE", "RANSOM",
        "BACKDOOR", "COINMINER", "STEALER", "CREDENTIAL", "DROPPER",
        "KEYLOGGER", "MINER",
    )):
        kind = "malware"
    elif any(k in text for k in (
        "EXPLOIT", "SHELLCODE", "ATTACK_RESPONSE", "ATTEMPTED-ADMIN",
    )):
        kind = "exploit"
    elif any(k in text for k in ("DDOS", "DOS ")):
        kind = "dos"
    elif any(k in text for k in ("HUNTING", "DOTTED QUAD", "SUSPICIOUS")):
        kind = "suspicious"
    elif any(k in text for k in ("SCAN", "PROBE")):
        kind = "recon"
    elif any(k in text for k in (
        "POLICY", "P2P", "BITTORRENT", "TORRENT",
    )):
        kind = "policy"
    else:
        kind = "other"

    return kind, _LABELS[kind], _SEVERITY[kind]
