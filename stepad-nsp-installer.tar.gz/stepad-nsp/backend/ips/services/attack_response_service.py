"""
Respuesta ante ataques externos (IPS entrante) y bloqueo de atacantes.

El administrador decide con auto_block_inbound si el bloqueo de IPs
atacantes detectadas por Suricata es automatico o solo se registra:

  - auto_block_inbound = True  -> la IP origen se bloquea sola.
  - auto_block_inbound = False -> solo queda registrada en el log.

Los bloqueos MANUALES desde la seccion "Ataques externos" se aplican
siempre (independentemente del toggle). Persisten en la tabla
attack_blocked_ips y se re-aplican al arrancar.
"""

import ipaddress
import subprocess
from pathlib import Path

from backend.core.database.session import SessionLocal

from backend.alerts.services.alert_service import AlertService

from backend.audit.services.audit_service import AuditService

from backend.ips.models.attack_blocked_ip import AttackBlockedIp

from backend.ips.models.threat_response_setting import ThreatResponseSetting

from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


NFT = "/usr/sbin/nft"

ATTACK_SET = "auto_attack_v4"
ATTACK_SET_V6 = "auto_attack_v6"

ATTACK_CHAIN = "attack-block"

# Guardarraíles del bloqueo AUTOMÁTICO (para no crecer sin límite ni
# bloquear algo legítimo ante un escaneo/spoof masivo):
#   - TTL: un auto-bloqueo expira solo pasado este tiempo (se re-evalúa).
#   - TOPE: máximo de IPs auto-bloqueadas simultáneas.
import os as _os
AUTO_BLOCK_TTL_SECONDS = int(_os.environ.get("STEPAD_AUTO_BLOCK_TTL", str(6 * 3600)))
AUTO_BLOCK_MAX = int(_os.environ.get("STEPAD_AUTO_BLOCK_MAX", "5000"))


class AttackResponseService:

    def __init__(self):

        self.alert_service = AlertService()

        self.audit_service = AuditService()

    def _nft_lock(self):

        from backend.shared.runtime.resource_locks import resource_locks

        return resource_locks.nft

    def _run(self, args):

        result = subprocess.run(
            [NFT, *args],
            capture_output=True,
            text=True,
        )

        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }

    # ------------------------------------------------------------------
    # Ajustes
    # ------------------------------------------------------------------

    def get_auto_block(self, db) -> bool:

        row = db.query(ThreatResponseSetting).first()

        if row is None:

            return False

        return bool(getattr(row, "auto_block_inbound", False))

    def set_auto_block(self, db, enabled: bool) -> dict:

        row = db.query(ThreatResponseSetting).first()

        if row is None:

            row = ThreatResponseSetting()

            db.add(row)

        row.auto_block_inbound = bool(enabled)

        db.commit()

        self.sync(db)

        return {"auto_block_inbound": bool(enabled)}

    # ------------------------------------------------------------------
    # Bloqueo P2P/BitTorrent (preferencia en archivo; DEFAULT: bloqueado)
    # ------------------------------------------------------------------
    P2P_STATE_FILE = Path("/etc/stepad/ips/p2p_block")

    def get_block_p2p(self) -> bool:
        try:
            return self.P2P_STATE_FILE.read_text().strip() != "0"
        except Exception as error:
            logger.debug("attack_response_service.get_block_p2p: %s", error)
            return True

    def set_block_p2p(self, enabled: bool) -> dict:
        try:
            self.P2P_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
            self.P2P_STATE_FILE.write_text("1" if enabled else "0")
        except Exception as error:
            logger.warning("No pude guardar block_p2p: %s", error)
        return {"block_p2p": bool(enabled)}

    # ------------------------------------------------------------------
    # nftables: set auto_attack_v4 + cadena attack-block
    # ------------------------------------------------------------------

    def _ensure_rules(self):

        with self._nft_lock():

            self._run(["add", "table", "inet", "stepad"])

            self._run([
                "add", "chain", "inet", "stepad", "forward",
                "{", "type", "filter", "hook", "forward", "priority", "0", ";",
                "policy", "accept", ";", "}",
            ])

            self._run([
                "add", "chain", "inet", "stepad", "input",
                "{", "type", "filter", "hook", "input", "priority", "-10", ";",
                "policy", "accept", ";", "}",
            ])

            self._run([
                "add", "set", "inet", "stepad", ATTACK_SET,
                "{", "type", "ipv4_addr", ";", "}",
            ])

            self._run([
                "add", "set", "inet", "stepad", ATTACK_SET_V6,
                "{", "type", "ipv6_addr", ";", "}",
            ])

            self._run([
                "add", "chain", "inet", "stepad", ATTACK_CHAIN,
            ])

            chain = self._run([
                "list", "chain", "inet", "stepad", ATTACK_CHAIN,
            ])

            if f"saddr @{ATTACK_SET} drop" not in chain["stdout"]:

                self._run([
                    "add", "rule", "inet", "stepad", ATTACK_CHAIN,
                    "ip", "saddr", f"@{ATTACK_SET}", "drop",
                ])

            if f"daddr @{ATTACK_SET} drop" not in chain["stdout"]:

                self._run([
                    "add", "rule", "inet", "stepad", ATTACK_CHAIN,
                    "ip", "daddr", f"@{ATTACK_SET}", "drop",
                ])

            if f"saddr @{ATTACK_SET_V6} drop" not in chain["stdout"]:

                self._run([
                    "add", "rule", "inet", "stepad", ATTACK_CHAIN,
                    "ip6", "saddr", f"@{ATTACK_SET_V6}", "drop",
                ])

            if f"daddr @{ATTACK_SET_V6} drop" not in chain["stdout"]:

                self._run([
                    "add", "rule", "inet", "stepad", ATTACK_CHAIN,
                    "ip6", "daddr", f"@{ATTACK_SET_V6}", "drop",
                ])

            for chain_name in ("forward", "input"):

                listing = self._run([
                    "list", "chain", "inet", "stepad", chain_name,
                ])

                if f"jump {ATTACK_CHAIN}" not in listing["stdout"]:

                    self._run([
                        "add", "rule", "inet", "stepad", chain_name,
                        "jump", ATTACK_CHAIN,
                    ])

    def _flush_set(self):

        with self._nft_lock():

            self._run([
                "flush", "set", "inet", "stepad", ATTACK_SET,
            ])

            self._run([
                "flush", "set", "inet", "stepad", ATTACK_SET_V6,
            ])

    @staticmethod
    def _set_for_ip(ip: str) -> str:
        try:
            if ipaddress.ip_address(ip).version == 6:
                return ATTACK_SET_V6
        except ValueError:
            pass
        return ATTACK_SET

    def _add_element(self, ip: str):

        with self._nft_lock():

            return self._run([
                "add", "element", "inet", "stepad", self._set_for_ip(ip),
                "{", ip, "}",
            ])

    def _delete_element(self, ip: str):

        with self._nft_lock():

            return self._run([
                "delete", "element", "inet", "stepad", self._set_for_ip(ip),
                "{", ip, "}",
            ])

    # ------------------------------------------------------------------
    # Aplicar / consultar
    # ------------------------------------------------------------------

    @staticmethod
    def _never_block(ip: str) -> bool:
        """Nunca bloquear direcciones privadas/loopback/reservadas (allowlist
        base) ni IPs inválidas."""
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return True
        return (
            addr.is_private or addr.is_loopback or addr.is_link_local
            or addr.is_multicast or addr.is_reserved or addr.is_unspecified
        )

    def expire_auto(self, db, ttl_seconds: int | None = None) -> int:
        """Elimina AUTO-bloqueos vencidos (TTL). Los manuales NO expiran.
        Devuelve cuántos expiró."""
        from datetime import datetime, timedelta

        ttl = AUTO_BLOCK_TTL_SECONDS if ttl_seconds is None else int(ttl_seconds)
        cutoff = datetime.utcnow() - timedelta(seconds=ttl)
        rows = (
            db.query(AttackBlockedIp)
            .filter(AttackBlockedIp.rule_source.in_(("auto", "p2p")))
            .filter(AttackBlockedIp.created_at < cutoff)
            .all()
        )
        for row in rows:
            try:
                self._delete_element(row.ip)
            except Exception as error:
                logger.debug("attack_response_service.expire_auto: %s", error)
            db.delete(row)
        if rows:
            db.commit()
            logger.info("Auto-bloqueos expirados (TTL %ss): %d", ttl, len(rows))
        return len(rows)

    def sync(self, db=None):

        own_db = db is None

        if own_db:

            db = SessionLocal()

        try:

            self._ensure_rules()

            # Purgar auto-bloqueos vencidos (TTL) antes de re-aplicar.
            try:
                self.expire_auto(db)
            except Exception as error:
                logger.warning("No pude expirar auto-bloqueos: %s", error)

            auto = self.get_auto_block(db)

            self._flush_set()

            rows = db.query(AttackBlockedIp).all()

            applied = []

            for row in rows:

                if row.rule_source == "auto" and not auto:

                    continue

                if row.rule_source == "p2p" and not self.get_block_p2p():

                    continue

                element = self._add_element(row.ip)

                if element["success"]:

                    applied.append(row.ip)

            return {
                "synced": len(applied),
                "auto_block_inbound": auto,
                "blocked_ips": applied,
            }

        finally:

            if own_db:

                db.close()

    def is_blocked(self, db, ip: str) -> AttackBlockedIp | None:

        return db.get(AttackBlockedIp, ip)

    def list_blocked(self, db) -> dict:

        rows = (
            db.query(AttackBlockedIp)
            .order_by(AttackBlockedIp.created_at.desc())
            .all()
        )

        auto = self.get_auto_block(db)

        return {
            "auto_block_inbound": auto,
            "count": len(rows),
            "ips": [
                {
                    "ip": row.ip,
                    "rule_source": row.rule_source,
                    "reason": row.reason,
                    "created_by": row.created_by,
                    "created_at": to_iso_utc(row.created_at),
                    "active": row.rule_source == "manual" or auto,
                }
                for row in rows
            ],
        }

    # ------------------------------------------------------------------
    # Bloquear / desbloquear
    # ------------------------------------------------------------------

    def block(
        self,
        db,
        ip: str,
        source: str = "manual",
        reason: str = "",
        actor: str | None = None,
    ) -> dict:

        try:

            address = ipaddress.ip_address(ip)

        except ValueError:

            return {"success": False, "message": "IP invalida"}

        existing = self.is_blocked(db, ip)

        fresh = existing is None

        if fresh and source in ("auto", "p2p"):

            if self._never_block(ip):

                logger.info(
                    "Auto-bloqueo omitido (allowlist/base reservada): %s", ip
                )

                return {
                    "success": False,
                    "ip": ip,
                    "blocked": False,
                    "message": "IP reservada; no se bloquea",
                }

            auto_count = (
                db.query(AttackBlockedIp)
                .filter(AttackBlockedIp.rule_source == "auto")
                .count()
            )

            if auto_count >= AUTO_BLOCK_MAX:

                logger.warning(
                    "Tope de auto-bloqueos (%d) alcanzado: no se bloquea %s",
                    AUTO_BLOCK_MAX,
                    ip,
                )

                return {
                    "success": False,
                    "ip": ip,
                    "blocked": False,
                    "message": "tope de auto-bloqueos alcanzado",
                }

        if fresh:

            db.add(AttackBlockedIp(
                ip=ip,
                rule_source=source,
                reason=(reason or "")[:255] or None,
                created_by=actor,
            ))

            db.commit()

        self._ensure_rules()

        result = self._add_element(ip)

        if not result["success"] and fresh:

            logger.warning(
                "No agregue %s al set de atacantes: %s",
                ip,
                result["stderr"],
            )

        if fresh:

            title = f"BLOQUEO ATACANTE: {ip}"

            kind = "automatico" if source == "auto" else "manual"

            message = (
                f"IP {ip} bloqueada ({kind}). "
                + (f"Motivo: {reason}. " if reason else "")
                + "La IP no podra alcanzar la red ni este equipo."
                + (f" Accion de {actor}." if actor else "")
            )

            self.alert_service.create(
                db,
                alert_type="attack_block",
                severity="warning",
                title=title,
                message=message,
            )

            try:

                self.audit_service.create_log(
                    db,
                    None,
                    "ATTACK_BLOCK",
                    "network",
                    message,
                )

            except Exception as error:

                logger.warning(
                    "Auditoria de bloqueo de atacante fallo: %s",
                    error,
                )

        return {
            "success": True,
            "ip": ip,
            "blocked": True,
            "rule_source": existing.rule_source if existing else source,
            "actor": actor,
        }

    def unblock(self, db, ip: str, actor: str | None = None) -> dict:

        row = self.is_blocked(db, ip)

        if row is not None:

            db.delete(row)

            db.commit()

        self._delete_element(ip)

        message = f"IP atacante {ip} desbloqueada."

        if actor:

            message += f" Accion de {actor}."

        self.alert_service.create(
            db,
            alert_type="attack_unblock",
            severity="info",
            title=f"Desbloqueado: {ip}",
            message=message,
        )

        try:

            self.audit_service.create_log(
                db,
                None,
                "ATTACK_UNBLOCK",
                "network",
                message,
            )

        except Exception as error:

            logger.warning(
                "Auditoria de desbloqueo fallo: %s",
                error,
            )

        return {"success": True, "ip": ip, "blocked": False, "actor": actor}


attack_response_service = AttackResponseService()