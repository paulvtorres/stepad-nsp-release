"""Egreso / Exfiltración: agrega los FLUJOS salientes de eve.json.

Lee los eventos `flow` de Suricata (que traen bytes_toserver/toclient) y
acumula, por equipo interno -> destino de Internet, el volumen saliente,
entrante y la cantidad de conexiones. Alimenta el panel de Egreso.
"""

import ipaddress
import json
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy import delete as sa_delete
from sqlalchemy.dialects.postgresql import insert as pg_insert

from backend.core.database.session import SessionLocal
from backend.ips.models.egress_flow_stat import EgressFlowStat
from backend.ips.services.geoip_service import geoip_service
from backend.network.devices.repositories.device_repository import (
    DeviceRepository,
)
from backend.shared.logging.logger import logger


EVE_LOG = Path("/var/log/suricata/eve.json")

STATE_FILE = Path("/etc/stepad/ips/egress_offset")

POLL_INTERVAL = 10

FLUSH_INTERVAL_SECONDS = 20

MAX_PENDING = 4000

DEFAULT_RETENTION_DAYS = 60

NAME_CACHE_TTL = 300


def _is_global(ip: str) -> bool:
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False


class EgressFlowIngest:
    def __init__(self):
        self.device_repo = DeviceRepository()
        self._offset = 0
        self._pending: dict = {}
        self._names: dict = {}
        self._last_flush = time.time()
        self._load_offset()

    def _load_offset(self):
        try:
            self._offset = int(STATE_FILE.read_text().strip())
        except Exception:
            try:
                if EVE_LOG.exists():
                    self._offset = EVE_LOG.stat().st_size
            except Exception:
                self._offset = 0

    def _save_offset(self):
        try:
            STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
            STATE_FILE.write_text(str(self._offset))
        except Exception as error:
            logger.warning(
                "No pude guardar el offset de eve.json (egress): %s",
                error,
            )

    def _name_for(self, db, src_ip: str):
        now = time.time()
        cached = self._names.get(src_ip)
        if cached and now - cached[0] < NAME_CACHE_TTL:
            return cached[1], cached[2]
        try:
            device = self.device_repo.find_by_ip(db, src_ip)
        except Exception:
            device = None
        if device is not None:
            name = device.display_name or device.hostname or None
            dev_id = device.id
            if name:
                self._names[src_ip] = (now, name, dev_id)
        else:
            name, dev_id = None, None
        return name, dev_id

    def _process_event(self, event):
        if event.get("event_type") != "flow":
            return

        src_ip = event.get("src_ip", "")
        dest_ip = event.get("dest_ip", "")

        if not src_ip or not dest_ip:
            return

        if _is_global(src_ip) or not _is_global(dest_ip):
            return

        flow = event.get("flow") or {}

        bytes_out = int(flow.get("bytes_toserver") or 0)
        bytes_in = int(flow.get("bytes_toclient") or 0)

        if bytes_out + bytes_in <= 0:
            return

        dest_port = event.get("dest_port")
        app_proto = (event.get("app_proto") or "").strip()[:32] or None

        now = datetime.utcnow()
        bucket = now.replace(minute=0, second=0, microsecond=0)

        key = (bucket, src_ip, dest_ip, dest_port, app_proto)

        agg = self._pending.get(key)

        if agg is None:
            self._pending[key] = [bytes_out, bytes_in, 1, now, now]
        else:
            agg[0] += bytes_out
            agg[1] += bytes_in
            agg[2] += 1
            agg[4] = now

    def poll_once(self):
        try:
            if not EVE_LOG.exists():
                return

            size = EVE_LOG.stat().st_size

            if size < self._offset:
                logger.warning(
                    "eve.json (egress) rotado o truncado "
                    f"(size={size}, offset={self._offset}); "
                    "se reinicia el offset al final del fichero."
                )
                self._offset = size
                self._save_offset()

            if size > self._offset:
                with open(EVE_LOG, "r") as handle:
                    handle.seek(self._offset)
                    for line in handle:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            event = json.loads(line)
                        except ValueError:
                            continue
                        self._process_event(event)
                    self._offset = handle.tell()
                self._save_offset()

            if self._pending and (
                time.time() - self._last_flush >= FLUSH_INTERVAL_SECONDS
                or len(self._pending) >= MAX_PENDING
            ):
                self._flush()

        except Exception as error:
            logger.error("Error al leer eve.json (egress): %s", error)

    def _flush(self):
        if not self._pending:
            return

        pending = self._pending
        self._pending = {}
        self._last_flush = time.time()

        db = SessionLocal()

        try:
            for key, agg in pending.items():
                bucket, src_ip, dest_ip, dest_port, app_proto = key

                bytes_out, bytes_in, connections, first_seen, last_seen = agg

                geo = geoip_service.enrich(dest_ip)

                device_name, device_id = self._name_for(db, src_ip)

                statement = pg_insert(EgressFlowStat).values(
                    bucket_hour=bucket,
                    src_ip=src_ip,
                    device_id=device_id,
                    device_name=device_name,
                    dest_ip=dest_ip,
                    dest_port=dest_port,
                    app_proto=app_proto,
                    country=geo.get("country"),
                    asn=geo.get("asn"),
                    as_org=geo.get("as_org"),
                    bytes_out=bytes_out,
                    bytes_in=bytes_in,
                    connections=connections,
                    first_seen=first_seen,
                    last_seen=last_seen,
                )

                statement = statement.on_conflict_do_update(
                    constraint="uq_egress_flow_stat",
                    set_={
                        "bytes_out": EgressFlowStat.bytes_out + bytes_out,
                        "bytes_in": EgressFlowStat.bytes_in + bytes_in,
                        "connections": EgressFlowStat.connections + connections,
                        "last_seen": last_seen,
                        "device_name": device_name,
                        "device_id": device_id,
                    },
                )

                db.execute(statement)

            db.commit()

        except Exception as error:
            logger.error("Error al guardar egreso: %s", error)
            db.rollback()
        finally:
            db.close()

    def _retention_loop(self, retention_days: int):
        while True:
            time.sleep(3600)
            db = SessionLocal()
            try:
                cutoff = datetime.utcnow() - timedelta(days=retention_days)
                deleted = db.execute(
                    sa_delete(EgressFlowStat).where(
                        EgressFlowStat.last_seen < cutoff
                    )
                ).rowcount
                db.commit()
                if deleted:
                    logger.info(
                        "Egreso: podados %s registro(s) con antiguedad > %s dias",
                        deleted,
                        retention_days,
                    )
            except Exception as error:
                logger.error("Egreso: fallo la poda: %s", error)
            finally:
                db.close()

    def run_forever(self):
        retention_days = DEFAULT_RETENTION_DAYS

        try:
            db = SessionLocal()
            try:
                from backend.siem.services.compliance_service import (
                    ComplianceService,
                )

                retention_days = ComplianceService().retention_days(db)
            finally:
                db.close()
        except Exception as error:
            logger.debug("egress_flow_ingest.run_forever: %s", error)
        threading.Thread(
            target=self._retention_loop,
            args=(retention_days,),
            daemon=True,
            name="egress-retention",
        ).start()

        logger.info(
            "Ingesta de Egreso iniciada (eve.json flows, retencion %s dias).",
            retention_days,
        )

        while True:
            try:
                self.poll_once()
            except Exception as error:
                logger.exception("Error en el bucle de Egreso: %s", error)
            time.sleep(POLL_INTERVAL)


egress_flow_ingest = EgressFlowIngest()