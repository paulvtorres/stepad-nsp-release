"""Avisos de seguridad (postura) del NSP.

Revisa proactivamente la configuración/exposición y devuelve una lista de
avisos con severidad, detalle y recomendación — para que el administrador
vea de entrada lo que debe atender.
"""
from __future__ import annotations

import ipaddress
import json
import subprocess
import time
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

from backend.shared.logging.logger import logger


_AUTH_INBOUND_FILE = Path("/etc/stepad/ips/authorized_inbound.json")


_SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}

# Puertos con nombre legible (para el aviso de exposición en la WAN).
_SENSITIVE_PORTS = {
    "22": "SSH",
    "8443": "Panel/API del NSP",
    "21115": "RustDesk hbbs",
    "21116": "RustDesk hbbs",
    "21117": "RustDesk hbbr",
    "21118": "RustDesk hbbs",
    "21119": "RustDesk hbbr",
}

# Puertos de servicios del NSP (para inferir alcanzabilidad desde Internet).
_SERVICE_PORTS = {"22", "8443", "21115", "21116", "21117", "21118", "21119"}


class SecurityPostureService:

    _public_cache = {"ts": 0.0, "ip": None}

    # ------------------------------------------------------------------
    def _run(self, args):
        try:
            return subprocess.run(
                args, capture_output=True, text=True, timeout=6
            ).stdout or ""
        except Exception as error:
            logger.debug("security_posture_service._run: %s", error)
            return ""

    def _listening(self):
        """[(addr, port)] de puertos TCP en LISTEN."""
        out = self._run(["ss", "-H", "-lnt"])
        items = []
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 4:
                local = parts[3]
                addr, _, port = local.rpartition(":")
                items.append((addr, port))
        return items

    def _default_wan(self):
        """(interfaz, IP) de la ruta por defecto (WAN)."""
        out = self._run(["ip", "-j", "route", "show", "default"])
        try:
            data = json.loads(out or "[]")
        except Exception as error:
            logger.debug("security_posture_service._default_wan: %s", error)
            data = []
        if data:
            return data[0].get("dev"), data[0].get("prefsrc")
        return None, None

    def _public_ip(self):
        cache = self._public_cache
        now = time.time()
        if cache.get("ip") and now - cache.get("ts", 0) < 300:
            return cache["ip"]
        try:
            with urllib.request.urlopen(
                "https://api.ipify.org", timeout=6
            ) as response:
                ip = (response.read() or b"").decode().strip()
            if ip:
                self._public_cache = {"ts": now, "ip": ip}
                return ip
        except Exception as error:
            logger.debug("security_posture_service._public_ip: %s", error)
        return cache.get("ip")

    @staticmethod
    def _is_private(ip):
        try:
            return ipaddress.ip_address(ip).is_private
        except Exception as error:
            logger.debug("security_posture_service._is_private: %s", error)
            return False

    # ------------------------------------------------------------------
    # Puertos de ingreso AUTORIZADOS (el NSP debe autorizar el forward)
    # ------------------------------------------------------------------
    def get_authorized_inbound(self):
        try:
            data = json.loads(_AUTH_INBOUND_FILE.read_text())
            ports = data.get("ports") if isinstance(data, dict) else data
            return [str(p) for p in (ports or [])]
        except Exception as error:
            logger.debug("security_posture_service.get_authorized_inbound: %s", error)
            return []

    def set_authorized_inbound(self, ports):
        clean = []
        for p in (ports or []):
            p = str(p).strip()
            if p.isdigit() and p not in clean:
                clean.append(p)
        try:
            _AUTH_INBOUND_FILE.parent.mkdir(parents=True, exist_ok=True)
            _AUTH_INBOUND_FILE.write_text(
                json.dumps({"ports": clean}, ensure_ascii=False, indent=2)
            )
        except Exception as error:
            logger.warning("No pude guardar puertos autorizados: %s", error)
        return clean

    # ------------------------------------------------------------------
    def _established_inbound(self):
        """Puertos de servicio con conexiones ENTRANTES activas de IPs
        públicas (evidencia de forward/DMZ en el router de arriba)."""
        out = self._run(["ss", "-Hn", "state", "established"])
        ports = set()
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 5:
                local = parts[3]
                peer = parts[4]
                _, _, lport = local.rpartition(":")
                paddr, _, _ = peer.rpartition(":")
                if lport in _SERVICE_PORTS and paddr and not self._is_private(paddr):
                    ports.add(lport)
        return sorted(ports, key=lambda x: int(x))

    def _recent_public_inbound(self, db, days=7):
        """¿Se registró tráfico entrante de IPs públicas en los últimos días?"""
        if db is None:
            return []
        try:
            from datetime import datetime, timedelta
            from backend.ips.models.inbound_attack_event import InboundAttackEvent
            since = datetime.utcnow() - timedelta(days=days)
            rows = (
                db.query(InboundAttackEvent.src_ip)
                .filter(InboundAttackEvent.last_seen >= since)
                .distinct()
                .all()
            )
            return [r[0] for r in rows if r[0] and not self._is_private(r[0])]
        except Exception as error:
            logger.debug("security_posture_service._recent_public_inbound: %s", error)
            return []

    def get_posture(self, db=None) -> dict:
        advisories = []

        def add(sev, title, detail, rec, ports=None, action=None):
            item = {
                "severity": sev,
                "title": title,
                "detail": detail,
                "recommendation": rec,
            }
            if ports:
                item["ports"] = ports
            if action:
                item["action"] = action
            advisories.append(item)

        # 1) Servicios sensibles escuchando en TODAS las interfaces (WAN).
        try:
            lis = self._listening()
            any_iface = ("0.0.0.0", "*", "::", "[::]", "")
            exposed_crit = sorted({
                p for (a, p) in lis
                if a in any_iface and p in ("22", "8443")
            }, key=lambda x: int(x))
            if exposed_crit:
                names = ", ".join(
                    f"{_SENSITIVE_PORTS.get(p, p)} ({p})" for p in exposed_crit
                )
                add(
                    "high",
                    "Servicios sensibles escuchando en la WAN",
                    f"Estos servicios escuchan en TODAS las interfaces: {names}. "
                    "Si el router de arriba publica esos puertos, quedan "
                    "expuestos a Internet.",
                    "Restringí SSH y el Panel/API a la LAN/Tailscale (no a la WAN).",
                )
            rustdesk = sorted({
                p for (a, p) in lis
                if a in any_iface and p in ("21115", "21116", "21117", "21118", "21119")
            })
            if rustdesk:
                add(
                    "info",
                    "RustDesk publicado en la WAN",
                    "Puertos 21115-21119 escuchan para acceso remoto (por diseño).",
                    "Si no usás RustDesk remoto, desactivalo o restringilo a la VPN.",
                )
        except Exception as error:
            logger.warning("posture: exposición: %s", error)

        # 2) NSP detrás de NAT (no está en el borde).
        try:
            wan_dev, wan_ip = self._default_wan()
            public_ip = self._public_ip()
            if (
                wan_ip
                and self._is_private(wan_ip)
                and public_ip
                and not self._is_private(public_ip)
            ):
                add(
                    "medium",
                    "El NSP está detrás de otro router (doble NAT)",
                    f"IP WAN del NSP: {wan_ip} (privada) · IP pública de salida: "
                    f"{public_ip}. El NSP NO está en el borde: no verá ni "
                    "bloqueará intentos de ingreso externos reales.",
                    "Para proteger el borde, poné el router de arriba en "
                    "bridge o hacé DMZ hacia el NSP. Si no, el NSP solo ve "
                    "tráfico de la LAN.",
                )
        except Exception as error:
            logger.warning("posture: nat: %s", error)

        # 3) Protecciones apagadas.
        try:
            off = []
            from backend.ips.services.threat_response_service import (
                threat_response_service,
            )
            from backend.ips.services.attack_response_service import (
                attack_response_service,
            )
            if db is not None:
                s = threat_response_service.get_settings(db)
                if not s.get("ips_fail_closed"):
                    off.append("Modo fail-closed (NFQUEUE) OFF")
                if not s.get("auto_block_inbound"):
                    off.append("Bloqueo automático del atacante OFF")
                if not s.get("quarantine_enabled"):
                    off.append("Cuarentena automática OFF")
            if not attack_response_service.get_block_p2p():
                off.append("Bloqueo de P2P/BitTorrent OFF")
            try:
                from backend.firewall.services.firewall_hardening_service import (
                    FirewallHardeningService,
                )
                h = FirewallHardeningService().get_settings()
                if not h.get("hardening_enabled"):
                    off.append("Hardening del firewall (deny-all) OFF")
            except Exception as error:
                logger.debug("security_posture_service.add: %s", error)
            if off:
                add(
                    "medium",
                    "Protecciones recomendadas desactivadas",
                    "Desactivadas: " + "; ".join(off) + ".",
                    "Activá las que apliquen para una postura más estricta.",
                )
        except Exception as error:
            logger.warning("posture: protecciones: %s", error)

        # 4) Feeds de inteligencia desactualizados / sin datos.
        try:
            from backend.ips.services.geoip_service import geoip_service
            meta = getattr(geoip_service, "meta", {}) or {}
            rows = meta.get("rows") or meta.get("count") or 0
            if not rows:
                add(
                    "low",
                    "GeoIP sin datos",
                    "No hay base GeoIP cargada (no se enriquecen país/ASN/org).",
                    "Actualizá las listas/feeds de inteligencia.",
                )
        except Exception as error:
            logger.warning("posture: geoip: %s", error)

        # 5) Alcanzabilidad / ingreso entrante (infiere forward/DMZ del router).
        #    El ingreso NO autorizado es CRÍTICO (el NSP debe autorizarlo).
        try:
            authorized = self.get_authorized_inbound()
            reach = self._established_inbound()
            pub_in = self._recent_public_inbound(db, 7)
            unauthorized = [p for p in reach if p not in authorized]
            if unauthorized:
                names = ", ".join(
                    f"{_SENSITIVE_PORTS.get(p, 'puerto ' + p)} ({p})"
                    for p in unauthorized
                )
                add(
                    "critical",
                    "Ingreso entrante NO AUTORIZADO",
                    f"Hay ingreso desde Internet hacia: {names} y el NSP NO lo "
                    "autorizó (posible forward/DMZ en el router hecho sin permiso).",
                    "Cerrá ese forward en el router o autorizá el puerto en el "
                    "NSP si es intencional.",
                    ports=unauthorized,
                    action="authorize_inbound",
                )
            elif reach:
                names = ", ".join(
                    f"{_SENSITIVE_PORTS.get(p, 'puerto ' + p)} ({p})" for p in reach
                )
                add(
                    "info",
                    "Ingreso entrante autorizado",
                    f"Ingreso desde Internet hacia: {names} (autorizado).",
                    "Mantené solo lo necesario y protegido.",
                    ports=reach,
                )
            elif pub_in:
                sample = ", ".join(pub_in[:5])
                add(
                    "info",
                    "Se observó tráfico entrante de IPs públicas",
                    f"IPs públicas observadas (7 días): {sample}"
                    + (" …" if len(pub_in) > 5 else "") + ".",
                    "Hay algún camino entrante; revisá la exposición de servicios.",
                )
            else:
                add(
                    "info",
                    "Sin ingreso entrante (7 días)",
                    "No se registró tráfico entrante de Internet; consistente con "
                    "el NSP detrás de NAT (sin forward/DMZ en el router de arriba).",
                    "Si esperás proteger ataques externos, publicá el NSP en el "
                    "borde (DMZ/bridge) y revisá los avisos de exposición.",
                )
        except Exception as error:
            logger.warning("posture: inbound: %s", error)

        advisories.sort(key=lambda a: _SEV_ORDER.get(a["severity"], 9))

        counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for a in advisories:
            counts[a["severity"]] = counts.get(a["severity"], 0) + 1

        return {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "worst": (advisories[0]["severity"] if advisories else "ok"),
            "counts": counts,
            "authorized_inbound": self.get_authorized_inbound(),
            "advisories": advisories,
        }


security_posture_service = SecurityPostureService()