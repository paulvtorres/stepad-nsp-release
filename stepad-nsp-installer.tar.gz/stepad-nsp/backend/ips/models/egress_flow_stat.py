from datetime import datetime

from sqlalchemy import (
    BigInteger,
    DateTime,
    Index,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class EgressFlowStat(Base):
    """Agregado de tráfico SALIENTE (egress) por equipo y destino.

    Cada fila acumula el volumen y las conexiones de un equipo interno
    hacia un destino de Internet, en una ventana horaria. Sirve para el
    panel de Egreso / Exfiltración (qué sale, hacia dónde y cuánto).
    """

    __tablename__ = "egress_flow_stats"

    __table_args__ = (
        UniqueConstraint(
            "bucket_hour",
            "src_ip",
            "dest_ip",
            "dest_port",
            "app_proto",
            name="uq_egress_flow_stat",
        ),
        Index("ix_egress_flow_stats_hour", "bucket_hour"),
        Index("ix_egress_flow_stats_dest", "dest_ip"),
        Index("ix_egress_flow_stats_src", "src_ip"),
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    bucket_hour: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
    )

    src_ip: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
    )

    device_id: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    device_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    dest_ip: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
    )

    dest_port: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    app_proto: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    country: Mapped[str | None] = mapped_column(
        String(8),
        nullable=True,
    )

    asn: Mapped[str | None] = mapped_column(
        String(16),
        nullable=True,
    )

    as_org: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    bytes_out: Mapped[int] = mapped_column(
        BigInteger,
        default=0,
        nullable=False,
    )

    bytes_in: Mapped[int] = mapped_column(
        BigInteger,
        default=0,
        nullable=False,
    )

    connections: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    first_seen: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
    )

    last_seen: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
    )
