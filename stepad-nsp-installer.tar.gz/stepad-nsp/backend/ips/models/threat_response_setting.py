from sqlalchemy import Boolean, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class ThreatResponseSetting(Base):

    __tablename__ = "threat_response_settings"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # Aisla (bloquea la MAC) el dispositivo que genera una deteccion
    # de malware/C2 en el IPS.
    quarantine_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )

    # Agrega la IP destino (C2) a la lista de bloqueo del cortafuegos.
    c2_block_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
