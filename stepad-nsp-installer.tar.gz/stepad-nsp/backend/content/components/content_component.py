import threading

from sqlalchemy.orm import Session

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.core.database.session import SessionLocal

from backend.content.models.content_category import (
    ContentCategory,
    CategoryDomain,
    SEED_CATEGORIES,
)
from backend.content.services.content_category_service import (
    ContentCategoryService
)

from backend.shared.logging.logger import logger


class ContentComponent(BaseComponent):

    name = "content"

    criticality = ComponentCriticality.IMPORTANT

    def start(self):

        logger.info("ContentComponent started.")

        db = SessionLocal()

        try:

            self._seed(db)

            from backend.groups.services.group_service import GroupService

            GroupService().ensure_default_group(db)

            # Todo equipo queda en el grupo por defecto si no tiene uno.
            GroupService().reconcile_unassigned_devices(db)

            from backend.content.services.domain_group_service import (
                DomainGroupService
            )

            DomainGroupService().seed(db)

            from backend.groups.services.group_dns_service import (
                group_dns_service
            )

            group_dns_service.sync_all(db)

            from backend.groups.services.sni_block_service import (
                sni_block_service
            )

            def _load_sni_block():

                try:

                    from backend.core.database.session import SessionLocal

                    db2 = SessionLocal()

                    try:

                        sni_block_service.sync_all(db2)

                    finally:

                        db2.close()

                except Exception as error:

                    logger.exception(f"Group SNI block inicial fallo: {error}")

            # En segundo plano: no debe retrasar la web. El refresco
            # programado re-arma las reglas cada 6 h.
            threading.Thread(
                target=_load_sni_block,
                daemon=True,
                name="group-sni-block-initial"
            ).start()

            sni_block_service.start_refresh_timer()

            ContentCategoryService().sync(db)

            self._ensure_malware_feed(db)

        finally:

            db.close()

    def _ensure_malware_feed(
        self,
        db: Session
    ):

        category = (
            db.query(ContentCategory)
            .filter(ContentCategory.key == "malware")
            .first()
        )

        if category is None:

            return

        has_domains = (
            db.query(CategoryDomain)
            .filter(CategoryDomain.category_id == category.id)
            .count()
        ) > 0

        if has_domains:

            return

        def _load_feed():

            try:

                from backend.content.services.malware_feed_service import (
                    MalwareFeedService
                )

                result = MalwareFeedService().refresh()

                logger.info(
                    "Feed malware inicial: %s",
                    result
                )

            except Exception as error:

                logger.error(
                    "No se pudo cargar el feed de malware: %s",
                    error
                )

        # Carga en segundo plano: en una instalación nueva la red WAN
        # aún no está configurada y la descarga podría tardar o fallar;
        # la web debe arrancar al instante igualmente.
        threading.Thread(
            target=_load_feed,
            daemon=True,
            name="malware-feed-initial"
        ).start()

    def _seed(
        self,
        db: Session
    ):

        for seed in SEED_CATEGORIES:

            existing = (
                db.query(ContentCategory)
                .filter(ContentCategory.key == seed["key"])
                .first()
            )

            if existing:

                continue

            # Non-work content is blocked by default on a fresh install:
            # adult, gambling, gaming and malware come enabled; the
            # rest are company policy choices left for the admin.
            default_enabled = seed["key"] in (
                "adult", "gambling", "gaming", "malware"
            )

            category = ContentCategory(
                key=seed["key"],
                name=seed["name"],
                description=seed["description"],
                enabled=default_enabled
            )

            db.add(category)

            db.flush()

            for domain in seed["domains"]:

                db.add(CategoryDomain(
                    category_id=category.id,
                    domain=domain
                ))

        db.commit()

        logger.info(
            "Content categories reconciled."
        )

    def stop(self):

        logger.info("ContentComponent stopped.")
