from sqlalchemy.orm import Session

from backend.content.models.domain_group import (
    DomainGroup,
    DomainGroupMember,
)

# Grupos de dominios (padre -> hijos). Al bloquear un dominio que
# pertenece a uno de estos grupos, se agregan automaticamente todos
# los dominios del grupo al bloqueo. Se puede extender esta lista.
SEED_DOMAIN_GROUPS = {
    "YouTube": {
        "description": "Dominios que usa YouTube (video, miniaturas, CDN)",
        "domains": [
            "youtube.com",
            "www.youtube.com",
            "m.youtube.com",
            "youtu.be",
            "googlevideo.com",
            "ytimg.com",
            "i.ytimg.com",
            "s.ytimg.com",
            "youtube-nocookie.com",
            "ggpht.com",
            "yt3.ggpht.com",
        ],
    },
    "Facebook": {
        "description": "Dominios de Facebook",
        "domains": [
            "facebook.com",
            "www.facebook.com",
            "m.facebook.com",
            "fb.com",
            "fbcdn.net",
            "scontent-*.cdninstagram.com",
            "fbsbx.com",
        ],
    },
    "Instagram": {
        "description": "Dominios de Instagram",
        "domains": [
            "instagram.com",
            "www.instagram.com",
            "cdninstagram.com",
            "scontent-*.cdninstagram.com",
            "instagr.am",
        ],
    },
    "TikTok": {
        "description": "Dominios de TikTok",
        "domains": [
            "tiktok.com",
            "www.tiktok.com",
            "tiktokcdn.com",
            "tiktokv.com",
            "musical.ly",
            "ibytedtos.com",
        ],
    },
    "X/Twitter": {
        "description": "Dominios de X (Twitter)",
        "domains": [
            "twitter.com",
            "x.com",
            "twimg.com",
            "t.co",
            "twttr.com",
        ],
    },
    "Netflix": {
        "description": "Dominios de Netflix",
        "domains": [
            "netflix.com",
            "www.netflix.com",
            "nflxvideo.net",
            "nflxext.com",
            "nflximg.net",
            "nflxso.net",
        ],
    },
    "WhatsApp": {
        "description": "Dominios de WhatsApp",
        "domains": [
            "whatsapp.com",
            "whatsapp.net",
            "wa.me",
            "whtsapp.net",
        ],
    },
    "LinkedIn": {
        "description": "Dominios de LinkedIn",
        "domains": [
            "linkedin.com",
            "www.linkedin.com",
            "licdn.com",
            "lnkd.in",
        ],
    },
    "Pinterest": {
        "description": "Dominios de Pinterest",
        "domains": [
            "pinterest.com",
            "www.pinterest.com",
            "pinimg.com",
            "pin.it",
        ],
    },
    "Snapchat": {
        "description": "Dominios de Snapchat",
        "domains": [
            "snapchat.com",
            "www.snapchat.com",
            "sc-cdn.net",
            "snap.com",
        ],
    },
    "Reddit": {
        "description": "Dominios de Reddit",
        "domains": [
            "reddit.com",
            "www.reddit.com",
            "redd.it",
            "redditmedia.com",
            "reddcdn.com",
        ],
    },
    "Discord": {
        "description": "Dominios de Discord",
        "domains": [
            "discord.com",
            "discord.gg",
            "discordapp.com",
            "discordapp.net",
        ],
    },
    "Twitch": {
        "description": "Dominios de Twitch",
        "domains": [
            "twitch.tv",
            "www.twitch.tv",
            "ttvnw.net",
            "twitchcdn.net",
        ],
    },
    "Spotify": {
        "description": "Dominios de Spotify",
        "domains": [
            "spotify.com",
            "www.spotify.com",
            "scdn.co",
            "spotifycdn.com",
        ],
    },
    "Telegram": {
        "description": "Dominios de Telegram",
        "domains": [
            "telegram.org",
            "t.me",
            "telegram.me",
        ],
    },
    "Roblox": {
        "description": "Dominios de Roblox",
        "domains": [
            "roblox.com",
            "www.roblox.com",
            "rbxcdn.com",
        ],
    },
    "Steam": {
        "description": "Dominios de Steam",
        "domains": [
            "steampowered.com",
            "steamstatic.com",
            "steamcommunity.com",
        ],
    },
}


class DomainGroupService:

    def seed(self, db: Session):

        for name, data in SEED_DOMAIN_GROUPS.items():

            group = (
                db.query(DomainGroup)
                .filter(DomainGroup.name == name)
                .first()
            )

            if group is None:

                group = DomainGroup(
                    name=name,
                    description=data["description"],
                )

                db.add(group)

                db.flush()

            # Agregar los dominios nuevos que no esten ya (upsert):
            # asi una actualizacion del seed con mas dominios llega a
            # los equipos ya instalados.
            existing_domains = {
                member.domain
                for member in db.query(DomainGroupMember)
                .filter(DomainGroupMember.domain_group_id == group.id)
                .all()
            }

            for domain in data["domains"]:

                if domain not in existing_domains:

                    db.add(DomainGroupMember(
                        domain_group_id=group.id,
                        domain=domain,
                    ))

        db.commit()


    def expand_domains(
        self,
        db: Session,
        domain: str
    ) -> list[str]:

        """Dado un dominio a bloquear, devuelve el dominio mas todos los
        'hijos' del grupo padre al que pertenezca (ej. youtube.com ->
        googlevideo.com, ytimg.com...). Si no pertenece a ningun grupo,
        devuelve solo el dominio."""

        domain = (domain or "").strip().lower()

        if not domain:

            return []

        # buscar grupos que contengan este dominio (o el dominio
        # coincida con un patron del grupo).
        rows = (
            db.query(DomainGroupMember)
            .filter(DomainGroupMember.domain == domain)
            .all()
        )

        result = {domain}

        for member in rows:

            siblings = (
                db.query(DomainGroupMember)
                .filter(
                    DomainGroupMember.domain_group_id == member.domain_group_id
                )
                .all()
            )

            for sibling in siblings:

                result.add(sibling.domain)

        return sorted(result)

    # ------------------------------------------------------------------
    # Administración (para editar los grupos desde la web)
    # ------------------------------------------------------------------

    def list_groups(self, db: Session) -> list[dict]:

        groups = db.query(DomainGroup).order_by(DomainGroup.name).all()

        result = []

        for group in groups:

            members = (
                db.query(DomainGroupMember)
                .filter(DomainGroupMember.domain_group_id == group.id)
                .order_by(DomainGroupMember.domain)
                .all()
            )

            result.append({
                "id": group.id,
                "name": group.name,
                "description": group.description or "",
                "domains": [m.domain for m in members],
            })

        return result


    def create_group(
        self,
        db: Session,
        name: str,
        description: str | None = None
    ) -> dict:

        existing = (
            db.query(DomainGroup)
            .filter(DomainGroup.name == name)
            .first()
        )

        if existing:

            return {"success": False, "message": "El grupo ya existe"}

        group = DomainGroup(name=name, description=description)

        db.add(group)
        db.commit()
        db.refresh(group)

        return {"success": True, "id": group.id}


    def delete_group(self, db: Session, group_id: int) -> dict:

        group = db.get(DomainGroup, group_id)

        if group is None:

            return {"success": False, "message": "Grupo no encontrado"}

        db.query(DomainGroupMember).filter(
            DomainGroupMember.domain_group_id == group_id
        ).delete()

        db.delete(group)
        db.commit()

        return {"success": True}


    def add_domain(
        self,
        db: Session,
        group_id: int,
        domain: str
    ) -> dict:

        group = db.get(DomainGroup, group_id)

        if group is None:

            return {"success": False, "message": "Grupo no encontrado"}

        domain = (domain or "").strip().lower()

        if not domain:

            return {"success": False, "message": "Dominio vacío"}

        existing = (
            db.query(DomainGroupMember)
            .filter(
                DomainGroupMember.domain_group_id == group_id,
                DomainGroupMember.domain == domain,
            )
            .first()
        )

        if existing:

            return {"success": True, "message": "Ya existía"}

        db.add(DomainGroupMember(
            domain_group_id=group_id,
            domain=domain,
        ))
        db.commit()

        return {"success": True}


    def remove_domain(
        self,
        db: Session,
        group_id: int,
        domain: str
    ) -> dict:

        db.query(DomainGroupMember).filter(
            DomainGroupMember.domain_group_id == group_id,
            DomainGroupMember.domain == domain.strip().lower(),
        ).delete()
        db.commit()

        return {"success": True}
