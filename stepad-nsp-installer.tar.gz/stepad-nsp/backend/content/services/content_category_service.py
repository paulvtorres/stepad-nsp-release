from sqlalchemy.orm import Session

from fastapi import HTTPException

from backend.content.models.content_category import (
    ContentCategory,
    CategoryDomain,
)
from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository
)
from backend.rules.engine.rule_engine import RuleEngine
from backend.audit.services.audit_service import AuditService

from backend.shared.logging.logger import logger


# Categorias que la politica de red mantiene bloqueadas globalmente
# (reglas permanentes en DNS/RPZ). No dependen del grupo del equipo.
ROOT_CATEGORY_KEYS = ("adult", "gambling", "gaming")


class ContentCategoryService:

    def __init__(self):

        self.repository = DeviceAccessRuleRepository()

        self.engine = RuleEngine()

        self.audit_service = AuditService()

    def _category(
        self,
        db: Session,
        key: str
    ) -> ContentCategory:

        category = (
            db.query(ContentCategory)
            .filter(ContentCategory.key == key)
            .first()
        )

        if category is None:

            raise HTTPException(
                status_code=404,
                detail="Category not found"
            )

        return category

    def _domains(
        self,
        db: Session,
        category: ContentCategory
    ) -> list[str]:

        rows = (
            db.query(CategoryDomain)
            .filter(CategoryDomain.category_id == category.id)
            .all()
        )

        return [row.domain for row in rows]

    def _find_category_rules(
        self,
        db: Session,
        key: str
    ):

        return (
            db.query(DeviceAccessRule)
            .filter(
                DeviceAccessRule.source == "category",
                DeviceAccessRule.source_ref == key
            )
            .all()
        )

    def _apply_rule(
        self,
        db: Session,
        category_key: str,
        domain: str,
        user_id: int | None,
        apply_engine: bool = True
    ):

        existing = self.repository.find_global_domain(db, domain)

        if existing:

            return None

        rule = DeviceAccessRule(
            device_id=None,
            action="BLOCK",
            rule_type="DOMAIN",
            value=domain,
            scope="GLOBAL",
            enabled=True,
            is_permanent=True,
            source="category",
            source_ref=category_key,
            created_by=user_id
        )

        saved = self.repository.save(db, rule)

        # OJO: aplicar la regla aquí regenera TODAS las reglas de dominio
        # (synchronize recarga la zona completa). Hacerlo por cada dominio
        # de una categoría grande (malware trae ~17.000) es O(n^2) y deja
        # el arranque colgado horas. El sync masivo desactiva esto y hace
        # una sola sincronización al final.
        if apply_engine:

            self.engine.apply(saved, db)

        return saved

    def _remove_rule(
        self,
        db: Session,
        rule: DeviceAccessRule
    ):

        self.repository.delete(db, rule)

    def _sync_domains(
        self,
        db: Session
    ):

        self.engine.domain_service.synchronize(db)

        self.engine.domain_service.synchronize_all_zones(db)

    def list(
        self,
        db: Session
    ):

        categories = db.query(ContentCategory).all()

        result = []

        for category in categories:

            result.append({
                "key": category.key,
                "name": category.name,
                "description": category.description,
                "enabled": category.enabled,
                "is_root": category.key in ROOT_CATEGORY_KEYS,
                "domains": len(self._domains(db, category))
            })

        return result

    def detail(
        self,
        db: Session,
        key: str
    ):

        category = self._category(db, key)

        return {
            "key": category.key,
            "name": category.name,
            "description": category.description,
            "enabled": category.enabled,
            "is_root": category.key in ROOT_CATEGORY_KEYS,
            "domains": self._domains(db, category)
        }

    def set_enabled(
        self,
        db: Session,
        key: str,
        enabled: bool,
        user_id: int | None
    ):

        category = self._category(db, key)

        if not enabled and key in ROOT_CATEGORY_KEYS:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Esta categoría es un bloqueo de raiz "
                    "(porno, apuestas o juegos) y no puede desactivarse."
                ),
            )

        if category.enabled == enabled:

            return self.detail(db, key)

        category.enabled = enabled

        db.commit()

        if enabled:

            for domain in self._domains(db, category):

                self._apply_rule(db, key, domain, user_id)

        else:

            rules = self._find_category_rules(db, key)

            for rule in rules:

                self._remove_rule(db, rule)

            if rules:

                self._sync_domains(db)

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="CATEGORY_ENABLED" if enabled else "CATEGORY_DISABLED",
            resource="CONTENT",
            description=(
                f"Category '{category.name}' "
                f"{'enabled' if enabled else 'disabled'}"
            )
        )

        return self.detail(db, key)

    def add_domain(
        self,
        db: Session,
        key: str,
        domain: str,
        user_id: int | None
    ):

        category = self._category(db, key)

        domain = domain.strip().lower()

        existing = (
            db.query(CategoryDomain)
            .filter(CategoryDomain.domain == domain)
            .first()
        )

        if existing is None:

            db.add(CategoryDomain(
                category_id=category.id,
                domain=domain
            ))

            db.commit()

        if category.enabled:

            self._apply_rule(db, key, domain, user_id)

        return self.detail(db, key)

    def remove_domain(
        self,
        db: Session,
        key: str,
        domain: str,
        user_id: int | None
    ):

        category = self._category(db, key)

        domain = domain.strip().lower()

        row = (
            db.query(CategoryDomain)
            .filter(
                CategoryDomain.category_id == category.id,
                CategoryDomain.domain == domain
            )
            .first()
        )

        if row:

            db.delete(row)

            db.commit()

        if category.enabled:

            rules = (
                db.query(DeviceAccessRule)
                .filter(
                    DeviceAccessRule.source == "category",
                    DeviceAccessRule.source_ref == key,
                    DeviceAccessRule.value == domain
                )
                .all()
            )

            for rule in rules:

                self._remove_rule(db, rule)

            if rules:

                self._sync_domains(db)

        return self.detail(db, key)

    def sync(
        self,
        db: Session
    ):
        """
        Reconciliation on boot: enabled categories keep their rules,
        disabled categories have none.
        """

        categories = db.query(ContentCategory).all()

        inserted = False

        for category in categories:

            existing = self._find_category_rules(db, category.key)

            existing_values = {rule.value for rule in existing}

            if category.enabled:

                for domain in self._domains(db, category):

                    if domain in existing_values:

                        continue

                    saved = self._apply_rule(
                        db,
                        category.key,
                        domain,
                        None,
                        apply_engine=False
                    )

                    if saved is not None:

                        inserted = True

                        existing_values.add(domain)

            else:

                for rule in existing:

                    self._remove_rule(db, rule)

                if existing:

                    self._sync_domains(db)

        # Una sola regeneración de la zona DNS para todo lo insertado
        # (antes: una por dominio).
        if inserted:

            self._sync_domains(db)

        logger.info("Content categories synced.")

        return {"success": True}

    def ensure_root_blocks(
        self,
        db: Session
    ):
        """
        Garantiza que porno, apuestas y juegos sigan activos a nivel
        global (bloqueo de raiz para toda la red).
        """

        changed = False

        for key in ROOT_CATEGORY_KEYS:

            category = (
                db.query(ContentCategory)
                .filter(ContentCategory.key == key)
                .first()
            )

            if category is None:

                continue

            if not category.enabled:

                category.enabled = True

                changed = True

                logger.info(
                    "Bloqueo de raiz reactivado: %s",
                    category.name,
                )

        if changed:

            db.commit()

        return {"success": True}
