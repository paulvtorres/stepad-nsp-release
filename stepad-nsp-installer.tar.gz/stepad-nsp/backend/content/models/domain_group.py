from sqlalchemy import String, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class DomainGroup(Base):

    __tablename__ = "domain_groups"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        unique=True
    )


    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


class DomainGroupMember(Base):

    __tablename__ = "domain_group_members"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    domain_group_id: Mapped[int] = mapped_column(
        ForeignKey("domain_groups.id", ondelete="CASCADE"),
        nullable=False
    )


    domain: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )
