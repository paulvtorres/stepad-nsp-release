from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base

class ContentCategory(Base):

    __tablename__ = "content_categories"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    key: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        unique=True
    )


    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False
    )


    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )


class CategoryDomain(Base):

    __tablename__ = "category_domains"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    category_id: Mapped[int] = mapped_column(
        ForeignKey("content_categories.id"),
        nullable=False
    )


    domain: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        unique=True
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )


class GroupCategory(Base):

    __tablename__ = "group_categories"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    group_id: Mapped[int] = mapped_column(
        ForeignKey("device_groups.id", ondelete="CASCADE"),
        nullable=False
    )


    category_id: Mapped[int] = mapped_column(
        ForeignKey("content_categories.id", ondelete="CASCADE"),
        nullable=False
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )


# Curated seed of the most common sites per category. The operator
# can extend or trim these from the UI.
SEED_CATEGORIES = [
    {
        "key": "social",
        "name": "Redes sociales",
        "description": "Facebook, Instagram, TikTok, X, Snapchat y similares",
        "domains": [
            "facebook.com", "instagram.com", "tiktok.com", "snapchat.com",
            "x.com", "twitter.com", "threads.net", "pinterest.com",
            "reddit.com", "whatsapp.com", "t.me",
        ],
    },
    {
        "key": "gaming",
        "name": "Juegos",
        "description": "Roblox, Steam, Epic Games, consolas y similares",
        "domains": [
            "roblox.com", "steampowered.com", "steamgames.com",
            "epicgames.com", "fortnite.com", "minecraft.net",
            "playstation.com", "xbox.com", "nintendo.com", "ea.com",
            "discord.gg",
        ],
    },
    {
        "key": "gambling",
        "name": "Apuestas",
        "description": "Casinos y casas de apuestas online",
        "domains": [
            "bet365.com", "betano.com", "1xbet.com", "betsson.com",
            "codere.com", "betway.com", "bwin.com", "pokerstars.com",
            "marathonbet.com", "winamax.com",
        ],
    },
    {
        "key": "streaming",
        "name": "Streaming",
        "description": "Netflix, Disney+, Max, Spotify y plataformas de video/música",
        "domains": [
            "netflix.com", "disneyplus.com", "max.com", "hbomax.com",
            "hulu.com", "primevideo.com", "paramountplus.com",
            "crunchyroll.com", "spotify.com",
        ],
    },
    {
        "key": "shopping",
        "name": "Compras",
        "description": "Amazon, Mercado Libre, eBay, Shein y marketplaces",
        "domains": [
            "amazon.com", "mercadolibre.com", "ebay.com", "aliexpress.com",
            "shein.com", "temu.com", "wish.com", "liverpool.com.mx",
            "falabella.com", "ripley.com.pe",
        ],
    },
    {
        "key": "adult",
        "name": "Contenido para adultos",
        "description": "Sitios de contenido explícito",
        "domains": [
            "pornhub.com", "xvideos.com", "xhamster.com", "onlyfans.com",
            "redtube.com", "youporn.com", "porndude.com",
            "xnxx.com", "xvedios.com", "xvideo.com", "xvideos3.com",
            "porn.com", "pornhd.com", "porntrex.com", "pornohub.com",
            "spankbang.com", "tube8.com", "youjizz.com", "tube9.com",
            "beeg.com", "brazzers.com", "bangbros.com", "mofos.com",
            "naughtyamerica.com", "realitykings.com", "digitalplayground.com",
            "vixen.com", "blacked.com", "kink.com", "adulttime.com",
            "fapdungeon.com", "hqporner.com", "tnaflix.com", "keezmovies.com",
            "motherless.com", "pornhub.net", "xvideos.red",
            "cam4.com", "chaturbate.com", "livejasmin.com", "stripchat.com",
            "bongacams.com", "camster.com", "myfreecams.com",
            "onlyfans.xxx", "pornmd.com", "pornhubpremium.com",
            "eporner.com", "porndig.com", "sextube.com", "sxyprn.com",
        ],
    },
    {
        "key": "malware",
        "name": "Malware / Phishing",
        "description": "Dominios maliciosos y de phishing (feed automático URLhaus + OpenPhish)",
        "domains": [],
    },
]
