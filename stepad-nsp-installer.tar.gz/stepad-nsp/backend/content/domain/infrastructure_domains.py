"""Cloud infrastructure endpoints that must NEVER be blocked.

Malware feeds sometimes list the generic service endpoint (for example
`s3.us-east-2.amazonaws.com`) instead of the specific malicious bucket.
Blocking the generic endpoint cuts EVERY legitimate app that uses the
service and raises false "malware or phishing" alerts (this happened
with the CONTABILIDAD machine).

Only endpoints WITHOUT their own bucket/subdomain are excluded: a
specific bucket (`my-bucket.s3.amazonaws.com`) or a specific distribution
(`d30sec8k5ond2x.cloudfront.net`) are still blocked.

Pure functions: no IO and no database access.
"""

from __future__ import annotations

import re


# Generic AWS service endpoint: <service>[.region...].amazonaws.com
AWS_ENDPOINT_RE = re.compile(
    r"^(?:"
    r"s3[-a-z0-9]*|execute-api|appsync-api|appsync|cognito-idp|cognito-identity|"
    r"firehose|kinesis|sns|sqs|sts|elb|nlb|checkip|cloudfront|dynamodb|lambda-url"
    r")"
    r"(?:\.[a-z0-9-]+)*"
    r"\.amazonaws\.com(?:\.cn)?$"
)


# Other storage/infra services queried by their generic name
# (not by a specific resource).
OTHER_INFRASTRUCTURE_HOSTS = {
    "blob.core.windows.net",
    "storage.googleapis.com",
    "cloudfront.net",
    "azureedge.net",
}


def is_infrastructure_domain(domain: str) -> bool:

    value = (domain or "").strip().lower().rstrip(".")

    if not value:

        return False

    if value in OTHER_INFRASTRUCTURE_HOSTS:

        return True

    return bool(AWS_ENDPOINT_RE.match(value))
