"""Endpoints de infraestructura cloud que NUNCA deben bloquearse.

Los feeds de malware listan a veces el endpoint genérico del servicio
(por ejemplo `s3.us-east-2.amazonaws.com`) en lugar del bucket concreto
malicioso. Bloquear el endpoint genérico corta TODAS las aplicaciones
legítimas que usan ese servicio y genera alertas de "malware o phishing"
falsas (pasó con la máquina de CONTABILIDAD).

Solo se excluyen los endpoints SIN bucket/subdominio propio: un bucket
concreto (`mi-bucket.s3.amazonaws.com`) o una distribución concreta
(`d30sec8k5ond2x.cloudfront.net`) sí se siguen bloqueando.

Funciones puras: sin IO ni base de datos.
"""

from __future__ import annotations

import re


# Endpoint genérico de un servicio AWS: <servicio>[.region...].amazonaws.com
AWS_ENDPOINT_RE = re.compile(
    r"^(?:"
    r"s3[-a-z0-9]*|execute-api|appsync-api|appsync|cognito-idp|cognito-identity|"
    r"firehose|kinesis|sns|sqs|sts|elb|nlb|checkip|cloudfront|dynamodb|lambda-url"
    r")"
    r"(?:\.[a-z0-9-]+)*"
    r"\.amazonaws\.com(?:\.cn)?$"
)


# Otros servicios de almacenamiento/infra que se consultan por su nombre
# genérico (no por un recurso concreto).
OTHER_INFRASTRUCTURE_HOSTS = {
    "blob.core.windows.net",
    "storage.googleapis.com",
    "cloudfront.net",
    "azureedge.net",
}


def is_infrastructure_domain(domain: str) -> bool:

    value = (domain or "").strip().lower().rstrip(".")

    if not value:

        return False

    if value in OTHER_INFRASTRUCTURE_HOSTS:

        return True

    return bool(AWS_ENDPOINT_RE.match(value))
