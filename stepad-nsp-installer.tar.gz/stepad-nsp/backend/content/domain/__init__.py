"""Capa de dominio del contenido: clasificación pura de dominios."""
