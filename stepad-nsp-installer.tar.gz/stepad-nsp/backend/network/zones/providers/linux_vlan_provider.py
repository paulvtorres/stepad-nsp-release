import subprocess

from backend.network.zones.models.network_zone import NetworkZone

from backend.network.zones.services.zone_interface_resolver import (
    ZoneInterfaceResolver
)


class LinuxVlanProvider:
    """
    Two modes, same resulting shape (an interface name + a gateway
    IP the rest of the system can bind DHCP/DNS to):

    - vlan_id set: creates a real tagged 802.1Q sub-interface
      (e.g. enx00e04c554a88.60). Requires the upstream switch port
      to be configured as a trunk carrying that VLAN tag -- that
      one-time physical/switch-side step is NOT something this
      software can do without a supported managed switch (see the
      SNMP/vendor-API discussion for that separate, optional piece).

    - vlan_id is None: adds the zone's gateway IP as a secondary
      address on the physical interface directly (IP aliasing).
      Works on any hardware, no VLAN-capable switch required, at
      the cost of no layer-2 traffic isolation between zones.
    """

    def __init__(self):

        self.resolver = ZoneInterfaceResolver()

    def _interface_parts(
        self,
        zone: NetworkZone
    ) -> tuple[str, str]:
        """
        Returns (parent_interface, interface_name). The parent is
        resolved through ZoneInterfaceResolver so a zone keeps
        working if its NIC is swapped or re-plugged. With a vlan_id
        the name is the tagged 802.1Q sub-interface; otherwise both
        are the physical interface.
        """

        base = self.resolver.resolve(zone)

        if zone.vlan_id:

            return base, f"{base}.{zone.vlan_id}"

        return base, base


    def _run(
        self,
        command: list[str]
    ):

        result = subprocess.run(
            command,
            capture_output=True,
            text=True
        )

        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip()
        }


    def ensure_zone_interface(
        self,
        zone: NetworkZone
    ):

        base_interface, interface_name = self._interface_parts(zone)

        prefix_length = zone.network_cidr.split("/")[-1]

        if zone.vlan_id:

            # Idempotent: "ip link add" on an existing link errors
            # harmlessly (RTNETLINK answers: File exists), same
            # tolerance pattern as the nftables chain/set creation
            # elsewhere in this codebase.
            self._run([
                "ip", "link", "add",
                "link", base_interface,
                "name", interface_name,
                "type", "vlan",
                "id", str(zone.vlan_id)
            ])

            self._run(["ip", "link", "set", interface_name, "up"])

        result = self._run([
            "ip", "addr", "add",
            f"{zone.gateway_ip}/{prefix_length}",
            "dev", interface_name
        ])

        if not result["success"] and "File exists" not in result["stderr"]:

            return result

        return {
            "success": True,
            "interface": interface_name,
            "message": f"Zone interface ready: {interface_name} ({zone.gateway_ip})"
        }


    def remove_zone_interface(
        self,
        zone: NetworkZone
    ):

        base_interface, interface_name = self._interface_parts(zone)

        prefix_length = zone.network_cidr.split("/")[-1]

        if zone.vlan_id:

            # Deleting the VLAN sub-interface takes its addresses
            # with it -- no need to remove the IP separately.
            return self._run(["ip", "link", "delete", interface_name])

        return self._run([
            "ip", "addr", "del",
            f"{zone.gateway_ip}/{prefix_length}",
            "dev", interface_name
        ])
