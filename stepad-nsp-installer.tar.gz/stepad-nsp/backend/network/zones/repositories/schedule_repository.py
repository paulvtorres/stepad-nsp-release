from sqlalchemy.orm import Session

from backend.network.zones.models.schedule import Schedule


class ScheduleRepository:

    def find_all(
        self,
        db: Session
    ):

        return db.query(Schedule).all()


    def find_by_id(
        self,
        db: Session,
        schedule_id: int
    ):

        return (
            db.query(Schedule)
            .filter(Schedule.id == schedule_id)
            .first()
        )


    def save(
        self,
        db: Session,
        schedule: Schedule
    ):

        db.add(schedule)
        db.commit()
        db.refresh(schedule)

        return schedule


    def delete(
        self,
        db: Session,
        schedule: Schedule
    ):

        db.delete(schedule)
        db.commit()
