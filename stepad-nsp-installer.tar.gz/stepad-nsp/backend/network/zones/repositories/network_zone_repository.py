from sqlalchemy.orm import Session

from backend.network.zones.models.network_zone import NetworkZone


class NetworkZoneRepository:

    def find_all(
        self,
        db: Session
    ):

        return db.query(NetworkZone).all()


    def find_by_id(
        self,
        db: Session,
        zone_id: int
    ):

        return (
            db.query(NetworkZone)
            .filter(NetworkZone.id == zone_id)
            .first()
        )


    def find_default(
        self,
        db: Session
    ):

        return (
            db.query(NetworkZone)
            .filter(NetworkZone.is_default.is_(True))
            .first()
        )


    def save(
        self,
        db: Session,
        zone: NetworkZone
    ):

        db.add(zone)
        db.commit()
        db.refresh(zone)

        return zone


    def update(
        self,
        db: Session,
        zone: NetworkZone
    ):

        db.commit()
        db.refresh(zone)

        return zone


    def delete(
        self,
        db: Session,
        zone: NetworkZone
    ):

        db.delete(zone)
        db.commit()
