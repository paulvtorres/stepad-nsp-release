from backend.infrastructure.network.adapters.linux.linux_interface_provider import (
    LinuxInterfaceProvider
)


class ZoneInterfaceResolver:

    def __init__(self):

        self.provider = LinuxInterfaceProvider()

    def resolve(
        self,
        zone
    ) -> str:
        """
        Returns the current Linux interface name a zone should bind
        to. If the zone carries an interface_mac, the card is looked
        up by MAC (so swapping/re-plugging the NIC keeps the zone
        working without manual edits); otherwise the zone's
        physical_interface is used as-is.
        """

        mac = getattr(
            zone,
            "interface_mac",
            None
        )

        if mac:

            mac = mac.strip().lower()

            if mac:

                for interface in self.provider.list_interfaces():

                    if getattr(
                        interface,
                        "mac_address",
                        ""
                    ).lower() == mac:

                        return interface.name

        return zone.physical_interface
