from datetime import date, time

from pydantic import BaseModel


class CreateScheduleRequest(BaseModel):

    name: str | None = None

    days_of_week: str | None = None

    start_time: time | None = None

    end_time: time | None = None

    start_date: date | None = None

    end_date: date | None = None
