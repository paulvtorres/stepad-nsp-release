from pydantic import BaseModel


class CreateZoneRequest(BaseModel):

    name: str

    description: str | None = None

    vlan_id: int | None = None

    physical_interface: str

    interface_mac: str | None = None

    network_cidr: str

    gateway_ip: str

    dhcp_pool_start: str

    dhcp_pool_end: str

    is_default: bool = False

    enforce_time_cutoff: bool = False

    time_cutoff_schedule_id: int | None = None
