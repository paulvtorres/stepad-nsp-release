from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import (
    ComponentCriticality
)

from backend.core.database.session import SessionLocal

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)
from backend.network.zones.providers.linux_vlan_provider import (
    LinuxVlanProvider
)

from backend.dns.providers.zone_pdns_provider import ZonePdnsProvider
from backend.dns.services.domain_service import DomainService
from backend.dns.factory import get_dns_provider

from backend.firewall.services.time_policy_service import TimePolicyService

from backend.firewall.services.zone_isolation_service import (
    ZoneIsolationService
)

from backend.shared.logging.logger import logger


class ZoneComponent(BaseComponent):

    name = "zones"

    criticality = ComponentCriticality.IMPORTANT


    def __init__(self):

        self.repository = NetworkZoneRepository()

        self.vlan_provider = LinuxVlanProvider()

        self.domain_service = DomainService(get_dns_provider())

        self.time_policy_service = TimePolicyService()

        self.isolation_service = ZoneIsolationService()


    def start(self):

        db = SessionLocal()

        try:

            zones = self.repository.find_all(db)

            if not zones:

                logger.info(
                    "ZoneComponent started (no zones configured yet -- "
                    "domain blocking runs through the GLOBAL/no-zone "
                    "path until at least one zone exists)."
                )

                return

            for zone in zones:

                interface_result = self.vlan_provider.ensure_zone_interface(zone)

                if not interface_result.get("success"):

                    logger.error(
                        f"Zone {zone.id} ({zone.name}): interface setup "
                        f"failed: {interface_result}"
                    )

                    continue

                pdns = ZonePdnsProvider(zone)

                pdns.bootstrap()

                pdns.start()

                self.domain_service.synchronize_zone(db, zone.id)

                self.time_policy_service.sync_zone(db, zone)

                logger.info(
                    f"Zone {zone.id} ({zone.name}) ready: "
                    f"{interface_result.get('interface')} / {zone.gateway_ip}"
                )

            logger.info(
                f"ZoneComponent started ({len(zones)} zone(s))."
            )

            self.isolation_service.sync(db)

            logger.info("Zone isolation policies synced.")

        finally:

            db.close()


    def stop(self):

        db = SessionLocal()

        try:

            for zone in self.repository.find_all(db):

                ZonePdnsProvider(zone).stop()

        finally:

            db.close()

        logger.info("ZoneComponent stopped.")
