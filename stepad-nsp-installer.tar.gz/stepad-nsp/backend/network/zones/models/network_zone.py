from sqlalchemy import Boolean, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NetworkZone(Base):

    __tablename__ = "network_zones"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        unique=True
    )


    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # NULL = no managed switch yet -- this zone is implemented as an
    # IP alias on the shared physical LAN interface. A real VLAN ID
    # (1-4094) means LinuxVlanProvider creates a tagged 802.1Q
    # sub-interface instead. Same model either way -- only
    # LinuxVlanProvider's behavior changes.
    vlan_id: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )


    physical_interface: Mapped[str] = mapped_column(
        String(50),
        nullable=False
    )


    # Optional MAC of the NIC this zone lives on. When set, the
    # zone's interface is resolved at apply time by MAC (the card
    # can be swapped or re-plugged and the zone follows it
    # automatically); falls back to physical_interface if the card
    # is not currently detected.
    interface_mac: Mapped[str | None] = mapped_column(
        String(17),
        nullable=True
    )


    network_cidr: Mapped[str] = mapped_column(
        String(18),
        nullable=False
    )


    gateway_ip: Mapped[str] = mapped_column(
        String(45),
        nullable=False
    )


    dhcp_pool_start: Mapped[str] = mapped_column(
        String(45),
        nullable=False
    )


    dhcp_pool_end: Mapped[str] = mapped_column(
        String(45),
        nullable=False
    )


    # Where new/unrecognized devices land automatically (see
    # DeviceDiscoveryService) -- including phones connecting for the
    # first time. Exactly one zone should have this set; enforced in
    # NetworkZoneService, not at the DB level.
    is_default: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    # Whole-zone internet cutoff outside working hours applies to
    # every device in the zone UNLESS this is False for a given
    # device (see NetworkDevice.is_company_asset) -- e.g. an
    # employee's personal phone sharing the "default" zone shouldn't
    # necessarily lose internet at 6pm just because it's on the
    # office Wi-Fi.
    enforce_time_cutoff: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    # Defines WHEN internet is allowed for this zone's company-asset
    # devices when enforce_time_cutoff is True -- reuses Schedule
    # rather than duplicating days/hours fields here. NULL while
    # enforce_time_cutoff is True means "misconfigured"; TimePolicyService
    # treats that as "no cutoff applied" and logs a warning rather than
    # guessing a default window.
    time_cutoff_schedule_id: Mapped[int | None] = mapped_column(
        ForeignKey("schedules.id"),
        nullable=True
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
