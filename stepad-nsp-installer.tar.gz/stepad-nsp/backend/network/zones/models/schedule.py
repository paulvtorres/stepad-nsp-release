from sqlalchemy import String, Date, Time
from sqlalchemy.orm import Mapped, mapped_column

from datetime import date, time, datetime

from backend.core.database.base import Base


class Schedule(Base):

    __tablename__ = "schedules"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    name: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )


    # Comma-separated day names ("Monday,Tuesday,Wednesday"). NULL
    # means every day. Stored as a simple string rather than a
    # separate table -- schedules are read far more often than
    # written, and this keeps the merge logic in one query.
    days_of_week: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )


    start_time: Mapped[time | None] = mapped_column(
        Time,
        nullable=True
    )


    end_time: Mapped[time | None] = mapped_column(
        Time,
        nullable=True
    )


    # For one-off windows ("the week of July 20-22"). NULL on both =
    # recurring indefinitely, gated only by days_of_week/start_time/
    # end_time.
    start_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True
    )

    end_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True
    )


    def is_active_now(
        self,
        now: datetime
    ) -> bool:

        if self.start_date and now.date() < self.start_date:

            return False

        if self.end_date and now.date() > self.end_date:

            return False

        if self.days_of_week:

            allowed_days = {
                day.strip()
                for day in self.days_of_week.split(",")
                if day.strip()
            }

            if now.strftime("%A") not in allowed_days:

                return False

        if self.start_time and now.time() < self.start_time:

            return False

        if self.end_time and now.time() > self.end_time:

            return False

        return True
