import re
import subprocess

from backend.network.configuration.models.interface_address import InterfaceAddress


class LinuxInterfaceConfigProvider:


    def interface_exists(
        self,
        interface: str
    ):

        result = subprocess.run(
            [
                "ip",
                "link",
                "show",
                interface
            ],
            capture_output=True,
            text=True
        )

        return result.returncode == 0



    def bring_up(
        self,
        interface: str
    ):

        result = subprocess.run(
            [
                "ip",
                "link",
                "set",
                interface,
                "up"
            ],
            capture_output=True,
            text=True
        )

        return result.returncode == 0



    def has_address(
        self,
        address: InterfaceAddress
    ):

        result = subprocess.run(
            [
                "ip",
                "addr",
                "show",
                address.interface
            ],
            capture_output=True,
            text=True
        )


        expected = (
            f"{address.ip}/{address.prefix}"
        )


        return expected in result.stdout



    def list_ipv4_addresses(
        self,
        interface: str
    ):
        """
        Returns every "ip/prefix" string currently bound to `interface`
        (e.g. ["192.168.50.1/24", "192.168.100.174/24"]) -- used to
        detect and clean up a gateway IP that ended up stuck on the
        wrong interface (see configure_lan's self-healing step).
        """

        result = subprocess.run(
            [
                "ip",
                "-4",
                "-o",
                "addr",
                "show",
                "dev",
                interface
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:

            return []

        return re.findall(
            r"inet\s+(\S+)",
            result.stdout
        )



    def remove_address(
        self,
        interface: str,
        ip: str,
        prefix: int
    ):

        result = subprocess.run(
            [
                "ip",
                "addr",
                "del",
                f"{ip}/{prefix}",
                "dev",
                interface
            ],
            capture_output=True,
            text=True
        )

        return {

            "success": result.returncode == 0,

            "stderr": result.stderr.strip()

        }



    def add_address(
        self,
        address: InterfaceAddress
    ):

        result = subprocess.run(
            [
                "ip",
                "addr",
                "add",
                f"{address.ip}/{address.prefix}",
                "dev",
                address.interface
            ],
            capture_output=True,
            text=True
        )

        return result


 
    def configure_address(
        self,
        address: InterfaceAddress
    ):


        if not self.interface_exists(
            address.interface
        ):

            return {

                "success": False,

                "message": (
                    f"Interface {address.interface} "
                    "does not exist"
                )

            }



        self.bring_up(
            address.interface
        )



        if self.has_address(address):

            return {

                "success": True,

                "message": "Address already configured",

                "interface": address.interface,

                "address": (
                    f"{address.ip}/{address.prefix}"
                )

            }



        result = self.replace_address(
            address
        )


        if result.returncode != 0:

            return {

                "success": False,

                "message": result.stderr

            }



        return {

            "success": True,

            "message": "Address configured",

            "interface": address.interface,

            "address": (
                f"{address.ip}/{address.prefix}"
            )

        }

    def replace_address(
        self,
        address: InterfaceAddress
    ):

        result = subprocess.run(
            [
                "ip",
                "addr",
                "replace",
                f"{address.ip}/{address.prefix}",
                "dev",
                address.interface
            ],
            capture_output=True,
            text=True
        )

        return result