from backend.network.interfaces.models.network_interface import NetworkInterface


class InterfaceConfigurationValidator:


    def validate_lan(
        self,
        interface: NetworkInterface
    ):


        errors = []


        if interface.role != "LAN":

            errors.append(
                "Interface is not configured as LAN"
            )


        if interface.status == "UNKNOWN":

            errors.append(
                "Interface status unknown"
            )


        return {

            "valid": len(errors) == 0,

            "errors": errors

        }