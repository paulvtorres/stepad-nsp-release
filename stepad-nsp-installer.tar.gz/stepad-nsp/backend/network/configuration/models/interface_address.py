from dataclasses import dataclass


@dataclass
class InterfaceAddress:

    interface: str

    ip: str

    prefix: int