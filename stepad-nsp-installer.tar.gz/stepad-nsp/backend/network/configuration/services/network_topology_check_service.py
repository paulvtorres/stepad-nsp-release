import ipaddress
import random
import socket
import struct
import subprocess
import time

from backend.network.configuration.services.network_configuration_service import (
    NetworkConfigurationService
)
from backend.shared.logging.logger import logger


class NetworkTopologyCheckService:

    def check(self):

        nc = NetworkConfigurationService()

        lan = nc.get_lan_configuration()

        wan = nc.get_wan_configuration()

        return {
            "lan": lan,
            "wan": wan,
            "segment_conflict": self._segment_conflict(lan, wan),
            "rogue_dhcp_on_lan": self._rogue_dhcp_on_lan(lan),
            "lan_gateway_conflict": self._lan_gateway_conflict(lan),
            "wan_online": self._wan_online(),
        }


    def get_conflicts(self):
        """
        Chequeo RAPIDO de conflictos de red para el indicador del Panel
        (sin el DHCP-discover que tarda ~4s). Solo segmentos solapados
        y gateway duplicado.
        """

        nc = NetworkConfigurationService()

        lan = nc.get_lan_configuration()

        wan = nc.get_wan_configuration()

        checks = [
            self._segment_conflict(lan, wan),
            self._lan_gateway_conflict(lan),
        ]

        for result in checks:

            if result.get("status") == "error":

                return {
                    "ok": False,
                    "detail": result.get(
                        "message",
                        "Conflicto de red detectado"
                    ),
                }

        return {
            "ok": True,
            "detail": "Sin conflictos de red",
        }

    def _segment_conflict(self, lan, wan):

        if not lan or not wan or not lan.get("network") or not wan.get("network"):

            return {
                "status": "unknown",
                "message": "Faltan datos de LAN/WAN",
            }

        try:

            lan_net = ipaddress.ip_network(lan["network"], strict=False)

            wan_net = ipaddress.ip_network(wan["network"], strict=False)

            if lan_net.overlaps(wan_net):

                return {
                    "status": "error",
                    "message": (
                        f"El segmento LAN {lan_net} CHOCA con la red "
                        f"WAN {wan_net}. Debes cambiar el segmento LAN "
                        f"(la WAN prevalece)."
                    ),
                }

            return {
                "status": "ok",
                "message": f"LAN {lan_net} y WAN {wan_net} no se superponen.",
            }

        except Exception as error:

            return {"status": "unknown", "message": str(error)}

    def _rogue_dhcp_on_lan(self, lan):

        if not lan:

            return {"status": "unknown", "message": "Sin LAN configurada"}

        interface = lan["interface"]

        gateway = lan["ip"]

        mac = lan.get("mac", "")

        offer_ip = self._dhcp_discover(interface, mac)

        if offer_ip is None:

            return {
                "status": "ok",
                "message": "No se detectó otro servidor DHCP en la red interna.",
            }

        if offer_ip == gateway:

            return {
                "status": "ok",
                "message": "Solo responde el DHCP propio del gateway.",
            }

        return {
            "status": "error",
            "message": (
                f"¡Otro servidor DHCP respondió desde {offer_ip}! "
                f"Parece que hay un cable de Internet/u otro router "
                f"conectado a la red interna (LAN)."
            ),
        }

    def _dhcp_discover(self, interface, mac, timeout=4):

        try:

            mac_bytes = bytes.fromhex(mac.replace(":", "").replace("-", ""))

        except Exception:

            mac_bytes = b"\x00" * 6

        xid = random.randint(0, 0xFFFFFFFF)

        header = struct.pack(
            "!BBBBIHHIIII",
            1, 1, 6, 0,
            xid,
            0,
            0x8000,
            0, 0, 0, 0
        )

        packet = (
            header
            + mac_bytes + b"\x00" * 10
            + b"\x00" * 64
            + b"\x00" * 128
            + b"\x63\x82\x53\x63"
            + bytes([53, 1, 1])
            + bytes([255])
        )

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        sock.bind(("0.0.0.0", 68))

        sock.settimeout(timeout)

        try:

            sock.sendto(packet, ("255.255.255.255", 67))

            end = time.time() + timeout

            while time.time() < end:

                try:

                    data, addr = sock.recvfrom(2048)

                except socket.timeout:

                    break

                if len(data) < 240 or data[0] != 2:

                    continue

                if b"\x35\x01\x02" in data[240:]:

                    return addr[0]

        finally:

            sock.close()

        return None

    def _lan_gateway_conflict(self, lan):

        if not lan:

            return {"status": "unknown", "message": "Sin LAN configurada"}

        interface = lan["interface"]

        gateway = lan["ip"]

        lan_mac = (lan.get("mac") or "").lower()

        try:

            result = subprocess.run(
                ["ip", "neigh", "show", "dev", interface],
                capture_output=True,
                text=True,
                timeout=5
            )

        except Exception:

            return {"status": "unknown", "message": "No se pudo leer ARP"}

        for line in result.stdout.splitlines():

            parts = line.split()

            if len(parts) < 2 or parts[0] != gateway:

                continue

            if "lladdr" in parts:

                index = parts.index("lladdr")

                arp_mac = parts[index + 1].lower() if index + 1 < len(parts) else ""

                if lan_mac and arp_mac and arp_mac != lan_mac:

                    return {
                        "status": "error",
                        "message": (
                            f"La IP del gateway LAN {gateway} está en uso "
                            f"por otra MAC ({arp_mac}). Posible cable "
                            f"conectado a la red equivocada."
                        ),
                    }

        return {
            "status": "ok",
            "message": "IP del gateway LAN sin conflicto.",
        }

    def _wan_online(self):

        try:

            result = subprocess.run(
                ["ip", "route", "show", "default"],
                capture_output=True,
                text=True,
                timeout=5
            )

        except Exception:

            return {"status": "unknown", "message": "No se pudo ver la ruta"}

        if "default" in result.stdout:

            return {
                "status": "ok",
                "message": "WAN con ruta por defecto (Internet conectado).",
            }

        return {
            "status": "error",
            "message": (
                "WAN sin ruta por defecto: el cable de Internet no parece "
                "conectado a la interfaz WAN."
            ),
        }

    def set_lan_segment(
        self,
        network_cidr: str,
        pool_start: str | None = None,
        pool_end: str | None = None,
        excluded_ips: list[str] | None = None
    ):

        try:

            new_net = ipaddress.ip_network(
                network_cidr,
                strict=False
            )

        except Exception as error:

            return {
                "success": False,
                "message": f"Segmento inválido: {error}",
            }

        if new_net.num_addresses < 4:

            return {
                "success": False,
                "message": "El segmento es demasiado pequeño (mín. /30).",
            }

        # El NSP siempre es el primer host (.1) del segmento.
        gateway = str(new_net.network_address + 1)

        network_address = str(new_net.network_address)

        netmask = str(new_net.netmask)

        # Pool DHCP por defecto: .100 hasta min(.200, último útil).
        first_usable = int(new_net.network_address) + 2

        last_usable = int(new_net.broadcast_address) - 1

        default_start = min(
            int(new_net.network_address) + 100,
            last_usable - 1
        )

        default_end = min(
            int(new_net.network_address) + 200,
            last_usable
        )

        pool_start = pool_start or str(
            ipaddress.ip_address(default_start)
        )

        pool_end = pool_end or str(
            ipaddress.ip_address(default_end)
        )

        try:

            start_int = int(ipaddress.ip_address(pool_start))

            end_int = int(ipaddress.ip_address(pool_end))

        except ValueError as error:

            return {
                "success": False,
                "message": f"Pool inválido: {error}",
            }

        if (
            start_int < first_usable
            or end_int > last_usable
            or start_int > end_int
        ):

            return {
                "success": False,
                "message": (
                    f"El pool {pool_start}-{pool_end} no cabe dentro de "
                    f"{new_net} (usables {ipaddress.ip_address(first_usable)}"
                    f"-{ipaddress.ip_address(last_usable)})."
                ),
            }

        if start_int == int(new_net.network_address) + 1:

            return {
                "success": False,
                "message": "El pool no puede incluir el gateway (.1) del NSP.",
            }

        try:

            exclusions = self._validate_exclusions(
                excluded_ips or [],
                new_net,
                gateway
            )

        except ValueError as error:

            return {
                "success": False,
                "message": str(error),
            }

        nc = NetworkConfigurationService()

        wan = nc.get_wan_configuration()

        if wan and wan.get("network"):

            try:

                wan_net = ipaddress.ip_network(
                    wan["network"],
                    strict=False
                )

                if new_net.overlaps(wan_net):

                    return {
                        "success": False,
                        "message": (
                            f"El segmento LAN {new_net} CHOCA con la WAN "
                            f"{wan_net}. La WAN prevalece: elige otro "
                            f"segmento para la red interna."
                        ),
                    }

            except Exception:

                pass

        from backend.shared.config.config_loader import config_loader

        current = config_loader.get().get("dhcp", {})

        config_loader.update(
            "dhcp",
            {
                "network": network_address,
                "netmask": netmask,
                "gateway": gateway,
                "dns_server": gateway,
                "pool_start": str(ipaddress.ip_address(start_int)),
                "pool_end": str(ipaddress.ip_address(end_int)),
                "lease_time": current.get("lease_time", "10m"),
                "excluded_ips": exclusions,
            }
        )

        from backend.network.configuration.services.interface_configuration_service import (
            InterfaceConfigurationService
        )

        result = InterfaceConfigurationService().configure_lan()

        if not result.get("success", False):

            return {
                "success": False,
                "message": f"Falló al aplicar IP en LAN: {result.get('message')}",
            }

        from backend.dhcp.services.dhcp_service import DhcpService

        dhcp_result = DhcpService().apply_config()

        self._refresh_suricata_home_net()

        logger.info(
            "Segmento LAN cambiado a %s: %s (DHCP %s)",
            new_net,
            result,
            dhcp_result
        )

        return {
            "success": dhcp_result.get("success", False),
            "message": (
                f"Segmento LAN cambiado a {new_net} (gateway {gateway})."
                if dhcp_result.get("success", False)
                else "Config guardada, pero dnsmasq no se reaplicó."
            ),
            "segment": str(new_net),
            "gateway": gateway,
            "pool": f"{pool_start}-{pool_end}",
            "excluded_ips": exclusions,
            "dhcp": dhcp_result,
        }

    def _validate_exclusions(
        self,
        ips: list[str],
        network: ipaddress.IPv4Network,
        gateway: str
    ):
        from backend.dhcp.services.dhcp_exclusion_utils import (
            normalize_exclusions
        )

        return normalize_exclusions(
            ips,
            str(network.network_address),
            str(network.netmask),
            gateway
        )

    def _refresh_suricata_home_net(self):
        """Regenera HOME_NET de Suricata desde config.yaml (best-effort)."""
        from pathlib import Path
        import sys

        try:

            script = Path(__file__).resolve().parents[3] / (
                "scripts" / "configure_suricata.py"
            )

            if not script.exists():

                return

            subprocess.run(
                [sys.executable, str(script)],
                capture_output=True,
                text=True,
                timeout=60
            )

            subprocess.run(
                ["systemctl", "restart", "suricata"],
                capture_output=True,
                text=True,
                timeout=60
            )

        except Exception as error:

            logger.warning(
                "No se pudo refrescar HOME_NET de Suricata: %s",
                error
            )
