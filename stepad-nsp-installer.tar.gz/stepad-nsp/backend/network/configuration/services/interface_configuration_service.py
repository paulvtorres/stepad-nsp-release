from ipaddress import ip_interface

from backend.shared.config.config_loader import config_loader

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.network.configuration.models.interface_address import (
    InterfaceAddress
)

from backend.network.configuration.providers.linux_interface_config_provider import (
    LinuxInterfaceConfigProvider
)


class InterfaceConfigurationService:


    def __init__(self):

        self.provider = LinuxInterfaceConfigProvider()

        self.interface_service = InterfaceService()


    def configure_lan(self):

        config = config_loader.reload()

        interfaces = self.interface_service.list_interfaces()

        lan = self.interface_service.get_primary_lan()

        if lan is None:

            return {
                "success": False,
                "message": "LAN interface not detected"
            }

        gateway = config["dhcp"]["gateway"]

        netmask = config["dhcp"]["netmask"]

        prefix = ip_interface(
            f"{gateway}/{netmask}"
        ).network.prefixlen

        cleanup_messages = self._remove_stray_gateway_addresses(
            interfaces=interfaces,
            lan_interface_name=lan.name,
            gateway=gateway,
            prefix=prefix
        )

        address = InterfaceAddress(
            interface=lan.name,
            ip=gateway,
            prefix=prefix
        )

        result = self.provider.configure_address(
            address
        )

        return {

            "success": result["success"],

            "interface": lan.name,

            "address": f"{gateway}/{prefix}",

            "provider_result": result,

            "cleanup": cleanup_messages

        }


    def _remove_stray_gateway_addresses(
        self,
        interfaces,
        lan_interface_name: str,
        gateway: str,
        prefix: int
    ):
        """
        Self-healing repair for the exact failure this module used to
        cause: on a boot where role resolution briefly misidentified
        the WAN nic as LAN (see InterfaceService.resolve_role), the
        gateway IP got applied there and, since nothing ever removed
        it afterwards, stayed stuck permanently -- two interfaces
        answering ARP for the same LAN gateway IP, breaking LAN
        clients' internet access.

        Runs on every configure_lan() call (i.e. every boot): if the
        gateway/prefix is found on any interface OTHER than the
        correct LAN interface, it's removed from there. Only ever
        touches this exact ip/prefix -- never anything else the
        interface may be carrying (e.g. a legitimate WAN DHCP lease).
        """

        expected = f"{gateway}/{prefix}"

        messages = []

        for interface in interfaces:

            if interface.name == lan_interface_name:

                continue

            current_addresses = self.provider.list_ipv4_addresses(
                interface.name
            )

            if expected not in current_addresses:

                continue

            removal = self.provider.remove_address(
                interface.name,
                gateway,
                prefix
            )

            messages.append(
                f"Removed stray LAN gateway {expected} found on "
                f"{interface.name}: success={removal['success']}"
            )

        return messages


    def remove_address_if_present(
        self,
        interface_name: str,
        ip: str,
        prefix: int
    ):
        """
        Used when the LAN network segment itself is being changed:
        the OLD gateway/prefix has to be explicitly removed from the
        LAN interface before the new one is applied, or the
        interface ends up carrying both the old and new subnet's
        addresses at once.
        """

        current = self.provider.list_ipv4_addresses(interface_name)

        expected = f"{ip}/{prefix}"

        if expected not in current:

            return {"success": True, "message": "Address not present"}

        return self.provider.remove_address(interface_name, ip, prefix)


    def configure_lan_default(self):

        return self.configure_lan()