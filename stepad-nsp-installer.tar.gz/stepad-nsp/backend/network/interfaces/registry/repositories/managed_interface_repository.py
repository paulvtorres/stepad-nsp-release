from sqlalchemy.orm import Session

from backend.network.interfaces.registry.models.managed_interface import (
    ManagedInterface
)


class ManagedInterfaceRepository:


    def find_all(
        self,
        db: Session
    ):

        return db.query(ManagedInterface).all()


    def find_by_mac(
        self,
        db: Session,
        mac_address: str
    ):

        return (

            db.query(ManagedInterface)

            .filter(ManagedInterface.mac_address == mac_address)

            .first()

        )


    def find_by_id(
        self,
        db: Session,
        interface_id: int
    ):

        return (

            db.query(ManagedInterface)

            .filter(ManagedInterface.id == interface_id)

            .first()

        )


    def find_active_by_role(
        self,
        db: Session,
        role: str
    ):
        """
        All assigned+live candidates for a role, cheapest priority
        first. With a single WAN/LAN this returns at most one
        useful entry; this is the hook multi-WAN/LAN failover will
        read from later.
        """

        return (

            db.query(ManagedInterface)

            .filter(
                ManagedInterface.role == role,
                ManagedInterface.status == "assigned"
            )

            .order_by(ManagedInterface.priority)

            .all()

        )


    def save(
        self,
        db: Session,
        entity: ManagedInterface
    ):

        db.add(entity)

        db.commit()

        db.refresh(entity)

        return entity


    def update(
        self,
        db: Session,
        entity: ManagedInterface
    ):

        db.commit()

        db.refresh(entity)

        return entity


    def delete(
        self,
        db: Session,
        entity: ManagedInterface
    ):

        db.delete(entity)

        db.commit()
