from datetime import datetime

from sqlalchemy import String, Integer, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class ManagedInterface(Base):
    """
    A physical NIC, identified by its MAC address -- NOT by the
    kernel-assigned name (enp0s25, enx00e04c554a88, ...), which can
    change for reasons that have nothing to do with the admin's
    intent: a hardware swap (moving STEPAD to a different machine,
    replacing a failed card), a kernel update that renames things,
    or simply a different boot-time enumeration order for two USB
    NICs. The MAC is the one thing about a card that doesn't change
    just because the box it's plugged into did.

    config.yaml's network.wan_interface / network.lan_interface
    remain in place as a CACHE, kept in sync by
    InterfaceRegistryService whenever the resolved WAN/LAN interface
    changes -- every other part of the codebase that already reads
    those two keys (NAT, DoT/DoH blocking, LAN address configuration)
    keeps working unmodified. This table is the actual source of
    truth; config.yaml is just where the answer gets cached for
    everything downstream.
    """

    __tablename__ = "managed_interfaces"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    mac_address: Mapped[str] = mapped_column(
        String(17),
        unique=True,
        nullable=False
    )


    # Admin-editable label shown in the UI, e.g. "Fibra Claro" or
    # "Switch de oficina" -- purely cosmetic, never used for logic.
    display_name: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )


    # "WAN" | "LAN" | None (detected, not yet assigned by the admin)
    role: Mapped[str | None] = mapped_column(
        String(10),
        nullable=True
    )


    # Lower = preferred. Only meaningful once more than one
    # interface shares a role (multi-WAN failover, multi-LAN) --
    # unused by any selection logic today beyond "pick the lowest
    # among assigned+live candidates", which is a no-op with a
    # single WAN/LAN. The field exists now so failover can be built
    # later without another schema change.
    priority: Mapped[int] = mapped_column(
        Integer,
        default=100
    )


    # "pending_assignment" -- detected, admin hasn't assigned a role
    # "assigned"           -- has a role, currently detected/live
    # "missing"            -- had a role, not detected in the last
    #                          reconciliation pass (unplugged,
    #                          failed, or hardware was swapped out)
    status: Mapped[str] = mapped_column(
        String(20),
        default="pending_assignment"
    )


    # Last kernel interface name this MAC was seen under -- display/
    # debugging only, and what gets written into config.yaml's
    # cache. Never used as identity.
    last_seen_name: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True
    )


    last_seen_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
