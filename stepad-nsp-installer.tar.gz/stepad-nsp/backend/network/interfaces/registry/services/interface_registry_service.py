from datetime import datetime

from backend.network.interfaces.registry.repositories.managed_interface_repository import (
    ManagedInterfaceRepository
)

from backend.network.interfaces.registry.models.managed_interface import (
    ManagedInterface
)

from backend.infrastructure.network.adapters.linux.linux_interface_provider import (
    LinuxInterfaceProvider
)

from backend.core.database.session import SessionLocal

from backend.shared.config.config_loader import config, config_loader

from backend.shared.logging.logger import logger


class InterfaceRegistryService:
    """
    Keeps ManagedInterface (identity by MAC) in sync with whatever
    NICs are physically present, and keeps config.yaml's
    network.wan_interface / network.lan_interface -- which
    everything else in the codebase already reads (NAT, DoT/DoH
    blocking, LAN address configuration) -- pointing at whatever
    interface the registry currently resolves for that role. That
    second part is what makes a hardware swap or a failed card just
    work once the admin re-assigns roles from the web UI, without
    editing config.yaml by hand or touching any other module.

    Runs on a timer (see InterfaceRegistryComponent) AND once at
    boot before NetworkComponent tries to configure the LAN address
    -- the very first pass is also when a fresh config.yaml (no
    registry entries yet) gets migrated into the registry.
    """

    def __init__(self):

        self.repository = ManagedInterfaceRepository()

        self.provider = LinuxInterfaceProvider()


    def get_role_for_mac(
        self,
        mac_address: str
    ) -> str | None:
        """
        Used by InterfaceService.resolve_role() -- the registry is
        now the primary source of truth for "what role is this NIC",
        ahead of both the old is_default_gateway heuristic and a
        direct config.yaml name comparison (both of which break the
        moment the physical card changes).
        """

        if not mac_address:

            return None

        db = SessionLocal()

        try:

            entry = self.repository.find_by_mac(db, mac_address.lower())

            if entry and entry.role and entry.status != "missing":

                return entry.role

            return None

        finally:

            db.close()


    def get_priority_for_mac(
        self,
        mac_address: str
    ) -> int | None:
        """
        Used by InterfaceService.resolve_priority(). Returns the
        registry-assigned priority (lower = preferred) for an
        interface that currently holds a role, None otherwise -- so
        multi-WAN/multi-LAN ordering always follows the same
        registry that owns the role assignment.
        """

        if not mac_address:

            return None

        db = SessionLocal()

        try:

            entry = self.repository.find_by_mac(db, mac_address.lower())

            if entry and entry.role and entry.status != "missing":

                return entry.priority

            return None

        finally:

            db.close()


    def reconcile(self):

        db = SessionLocal()

        try:

            live_interfaces = self.provider.list_interfaces()

            live_by_mac = {
                interface.mac_address.lower(): interface
                for interface in live_interfaces
                if interface.mac_address
            }

            self._migrate_from_config_if_needed(db, live_by_mac)

            seen_macs = set()

            for mac_address, live in live_by_mac.items():

                seen_macs.add(mac_address)

                entry = self.repository.find_by_mac(db, mac_address)

                if entry is None:

                    entry = ManagedInterface(
                        mac_address=mac_address,
                        role=None,
                        status="pending_assignment",
                        last_seen_name=live.name,
                        last_seen_at=datetime.utcnow()
                    )

                    self.repository.save(db, entry)

                    logger.warning(
                        f"New network interface detected: {live.name} "
                        f"({mac_address}) -- awaiting role assignment "
                        f"from the web UI."
                    )

                    continue

                entry.last_seen_name = live.name

                entry.last_seen_at = datetime.utcnow()

                if entry.role and entry.status == "missing":

                    logger.info(
                        f"Previously missing interface reappeared: "
                        f"{live.name} ({mac_address})."
                    )

                if entry.role:

                    entry.status = "assigned"

                self.repository.update(db, entry)

            for entry in self.repository.find_all(db):

                if entry.mac_address in seen_macs:

                    continue

                if entry.role and entry.status != "missing":

                    entry.status = "missing"

                    self.repository.update(db, entry)

                    logger.warning(
                        f"Interface with role {entry.role} "
                        f"(last seen as {entry.last_seen_name}, "
                        f"{entry.mac_address}) is no longer detected "
                        f"-- check the cable/card, or reassign its "
                        f"role from the web UI."
                    )

            self._sync_config_cache(db)

        finally:

            db.close()


    def _migrate_from_config_if_needed(
        self,
        db,
        live_by_mac: dict
    ):

        if self.repository.find_all(db):

            return

        network_config = config.get("network", {})

        if not network_config.get("initialized"):

            return

        wan_name = network_config.get("wan_interface")

        lan_name = network_config.get("lan_interface")

        for mac_address, live in live_by_mac.items():

            role = None

            if live.name == wan_name:

                role = "WAN"

            elif live.name == lan_name:

                role = "LAN"

            if not role:

                continue

            entry = ManagedInterface(
                mac_address=mac_address,
                role=role,
                status="assigned",
                last_seen_name=live.name,
                last_seen_at=datetime.utcnow(),
                display_name=f"{role} (migrated from config.yaml)"
            )

            self.repository.save(db, entry)

            logger.info(
                f"Migrated existing config.yaml assignment: "
                f"{role} = {live.name} ({mac_address})"
            )


    def _get_active(
        self,
        db,
        role: str
    ) -> ManagedInterface | None:
        """
        The PRIMARY interface for a role: the lowest-priority
        assigned+live entry. config.yaml's cache only ever holds the
        primary per role -- the name everything downstream that
        still reads config.yaml (resolve_role's fallback, DHCP's
        segment) should resolve to.
        """

        candidates = self.repository.find_active_by_role(db, role)

        return candidates[0] if candidates else None


    def _get_active_all(
        self,
        db,
        role: str
    ) -> list:
        """
        Every assigned+live interface for a role, cheapest priority
        first. This is what multi-WAN/multi-LAN features consume
        (NAT per WAN, recursor/DHCP per LAN) -- the registry is the
        one and only place "which cards carry this role" is decided.
        """

        return self.repository.find_active_by_role(db, role)


    def _sync_config_cache(
        self,
        db
    ):

        network_config = config.get("network", {})

        updates = {}

        wan = self._get_active(db, "WAN")

        current_wan_name = wan.last_seen_name if wan else None

        if current_wan_name != network_config.get("wan_interface"):

            # Covers BOTH directions: a new WAN assigned (write its
            # name) AND the previous WAN unassigned with nothing
            # replacing it (write None, clearing the stale name).
            # Only ever writing forward and never clearing is
            # exactly what let resolve_role()'s config.yaml fallback
            # keep reporting a role for an interface the admin had
            # just unassigned -- the registry (priority 0) correctly
            # said "unassigned", but config.yaml (priority 1) still
            # held the old name, so it won that fallback anyway.
            updates["wan_interface"] = current_wan_name

        lan = self._get_active(db, "LAN")

        current_lan_name = lan.last_seen_name if lan else None

        lan_changed = current_lan_name != network_config.get("lan_interface")

        if lan_changed:

            updates["lan_interface"] = current_lan_name

        if not updates:

            return

        updates["initialized"] = True

        config_loader.update("network", updates)

        logger.warning(
            f"Interface role assignment changed -- config.yaml "
            f"updated: {updates}"
        )

        if lan_changed and current_lan_name:

            # Local imports: avoid a circular import at module load
            # time (all three pull in InterfaceService, which is
            # what calls INTO this service for resolve_role()).
            from backend.network.configuration.services.interface_configuration_service import (
                InterfaceConfigurationService
            )

            from backend.dhcp.services.dhcp_service import DhcpService

            from backend.dns.factory import get_dns_provider

            InterfaceConfigurationService().configure_lan()

            dhcp_result = DhcpService().apply_config()

            logger.info(
                f"DHCP applied live after LAN assignment: {dhcp_result}"
            )

            dns_provider = get_dns_provider()

            if hasattr(dns_provider, "ensure_listen_address"):

                recursor_result = dns_provider.ensure_listen_address()

                logger.info(
                    f"PowerDNS Recursor listen address synced live "
                    f"after LAN assignment: {recursor_result}"
                )
