import threading

from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.network.interfaces.registry.services.interface_registry_service import (
    InterfaceRegistryService
)

from backend.shared.logging.logger import logger


RECONCILE_INTERVAL_SECONDS = 15


class InterfaceRegistryComponent(BaseComponent):
    """
    Runs InterfaceRegistryService.reconcile() once immediately at
    startup (BEFORE NetworkComponent configures the LAN address --
    see registration order in bootstrap.py, this is what lets a
    hardware swap resolve correctly on the very first boot with the
    new card, not just from the second reconcile pass onward), then
    every RECONCILE_INTERVAL_SECONDS afterwards on a daemon thread --
    same pattern as ScheduleEnforcementService.
    """

    name = "interface_registry"

    criticality = ComponentCriticality.IMPORTANT


    def __init__(self):

        self.service = InterfaceRegistryService()

        self._stop_event = threading.Event()

        self._thread = None


    def start(self):

        self.service.reconcile()

        self._stop_event.clear()

        self._thread = threading.Thread(
            target=self._run,
            daemon=True
        )

        self._thread.start()

        logger.info(
            "InterfaceRegistryComponent started "
            f"(re-checking hardware every {RECONCILE_INTERVAL_SECONDS}s)."
        )


    def _run(self):

        while not self._stop_event.wait(RECONCILE_INTERVAL_SECONDS):

            try:

                self.service.reconcile()

            except Exception as error:

                logger.error(
                    f"Interface registry reconciliation failed: {error}"
                )


    def stop(self):

        self._stop_event.set()

        if self._thread:

            self._thread.join(timeout=5)

        logger.info("InterfaceRegistryComponent stopped.")
