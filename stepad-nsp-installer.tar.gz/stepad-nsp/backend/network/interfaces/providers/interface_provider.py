from abc import ABC
from abc import abstractmethod

from backend.network.interfaces.models import NetworkInterfaceInfo


class InterfaceProvider(ABC):

    @abstractmethod
    def list_interfaces(self) -> list[NetworkInterfaceInfo]:
        pass