from dataclasses import dataclass


@dataclass
class NetworkInterfaceInfo:

    id: int

    name: str

    display_name: str

    mac_address: str | None

    ipv4_address: str | None

    ipv6_address: str | None

    subnet_mask: str | None

    gateway: str | None

    mtu: int | None

    speed: int | None

    status: str

    interface_type: str

    is_default_gateway: bool

    link_detected: bool

    connection_state: str