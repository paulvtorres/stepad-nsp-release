from dataclasses import dataclass


@dataclass
class NetworkInterface:

    id: int

    name: str

    display_name: str

    ip: str | None

    subnet_mask: str | None

    mac: str | None

    status: str

    role: str | None = None

    # Lower = preferred. Orders multiple interfaces sharing a role
    # (multi-WAN failover, multi-LAN): get_wan_interfaces() /
    # get_lan_interfaces() return role members sorted by this, and
    # get_primary_*() is the lowest value. Mirrors ManagedInterface.
    priority: int = 100

    interface_type: str | None = None

    is_wan_candidate: bool = False

    is_lan_candidate: bool = False

    link_detected: bool = False

    connection_state: str | None = None