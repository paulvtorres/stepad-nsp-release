from dataclasses import dataclass


@dataclass
class InterfaceDiagnosis:

    total_interfaces: int

    ethernet_interfaces: int

    wan_detected: bool

    lan_detected: bool

    ready: bool

    messages: list[str]