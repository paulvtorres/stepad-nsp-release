from backend.network.interfaces.services.interface_service import InterfaceService
from backend.network.interfaces.models.interface_diagnosis import InterfaceDiagnosis


class InterfaceDiagnosisService:


    def __init__(self):

        self.interface_service = InterfaceService()



    def diagnose(self):

        interfaces = self.interface_service.list_interfaces()


        ethernet_interfaces = [

            interface

            for interface in interfaces

            if interface.interface_type == "ETHERNET"

        ]


        wan_detected = any(

            interface.role == "WAN"

            for interface in interfaces

        )


        lan_detected = any(

            interface.role == "LAN"

            for interface in interfaces

        )


        messages = []


        if not wan_detected:

            messages.append(
                "No se detectó una interfaz WAN"
            )


        if not lan_detected:

            messages.append(
                "No se detectó una interfaz LAN"
            )


        if len(ethernet_interfaces) < 2:

            messages.append(
                "Se requieren al menos dos interfaces Ethernet para modo gateway"
            )


        ready = (

            wan_detected

            and lan_detected

            and len(ethernet_interfaces) >= 2

        )


        return InterfaceDiagnosis(

            total_interfaces=len(interfaces),

            ethernet_interfaces=len(ethernet_interfaces),

            wan_detected=wan_detected,

            lan_detected=lan_detected,

            ready=ready,

            messages=messages

        )