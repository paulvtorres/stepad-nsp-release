from backend.network.interfaces.models import (
    InterfaceDiagnosis,
    NetworkInterface,
)


class InterfaceAnalyzer:

    def analyze(
        self,
        interfaces: list[NetworkInterface]
    ) -> InterfaceDiagnosis:

        ethernet_count = 0

        connected_count = 0

        wan_candidates = 0

        lan_candidates = 0

        warnings = []

        recommendations = []

        for interface in interfaces:

            ethernet_count += 1

            if interface.status == "UP":

                connected_count += 1

            if interface.role == "WAN":

                wan_candidates += 1

            elif interface.role == "LAN":

                lan_candidates += 1

        if ethernet_count == 0:

            status = "ERROR"

            warnings.append(
                "No se detectaron interfaces Ethernet."
            )

        elif ethernet_count == 1:

            status = "WARNING"

            warnings.append(
                "Solo existe una interfaz Ethernet."
            )

            recommendations.append(
                "Conecte un adaptador Ethernet adicional para utilizar STEPAD NSP como firewall."
            )

        else:

            status = "READY"

        if connected_count < ethernet_count:

            warnings.append(
                "Existen interfaces Ethernet sin conexión."
            )

        return InterfaceDiagnosis(

            status=status,

            ethernet_interfaces=ethernet_count,

            connected_interfaces=connected_count,

            wan_candidates=wan_candidates,

            lan_candidates=lan_candidates,

            warnings=warnings,

            recommendations=recommendations

        )