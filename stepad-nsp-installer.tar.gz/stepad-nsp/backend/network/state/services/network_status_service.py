from backend.dhcp.services.dhcp_service import DhcpService
from backend.dns.services.domain_service import DomainService
from backend.firewall.services.firewall_service import FirewallService
from backend.nat.services.nat_service import NatService
from backend.network.interfaces.services.interface_service import (
    InterfaceService
)


class NetworkStatusService:

    def __init__(self):

        self.dhcp = DhcpService()

        self.dns = DomainService()

        self.firewall = FirewallService()

        self.nat = NatService()

        self.interfaces = InterfaceService()

    def get_status(self):

        return {

            "services": {

                "dhcp": self.dhcp.get_status(),

                "dns": self.dns.get_status(),

                "firewall": self.firewall.get_status(),

                "nat": self.nat.get_status()

            },

            "interfaces": len(
                self.interfaces.list_interfaces()
            )

        }