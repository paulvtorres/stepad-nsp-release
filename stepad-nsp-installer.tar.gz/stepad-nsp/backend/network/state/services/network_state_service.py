from backend.network.interfaces.services.interface_service import InterfaceService

from backend.network.state.models.network_state import NetworkState

from ipaddress import ip_interface


class NetworkStateService:


    def __init__(self):

        self.interface_service = InterfaceService()



    def get_state(self):

        wan = self.interface_service.get_primary_wan()

        lan = self.interface_service.get_primary_lan()

        lan_network = None

        if lan and lan.ip and lan.subnet_mask:

            lan_network = str(
                ip_interface(
                    f"{lan.ip}/{lan.subnet_mask}"
                ).network
            )

        return NetworkState(

            wan_interface=(
                wan.name
                if wan
                else None
            ),


            lan_interface=(
                lan.name
                if lan
                else None
            ),


            wan_ip=(
                wan.ip
                if wan
                else None
            ),


            lan_ip=(
                lan.ip
                if lan
                else None
            ),


            ready=(
                wan is not None
                and lan is not None
            ),

            lan_network=lan_network

        )