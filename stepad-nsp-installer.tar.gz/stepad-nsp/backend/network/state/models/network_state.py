from dataclasses import dataclass


@dataclass
class NetworkState:

    wan_interface: str | None

    lan_interface: str | None

    wan_ip: str | None

    lan_ip: str | None

    lan_network: str | None

    ready: bool