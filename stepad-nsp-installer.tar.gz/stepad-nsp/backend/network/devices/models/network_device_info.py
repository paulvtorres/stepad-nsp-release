from dataclasses import dataclass


@dataclass
class NetworkDeviceInfo:

    id: int

    ip_address: str

    mac_address: str

    interface: str

    status: str

    hostname: str | None = None

    vendor: str | None = None

    device_type: str | None = None