from sqlalchemy import String, Boolean, DateTime, ForeignKey, Integer
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column

from datetime import datetime
from backend.shared.datetime_utils import utcnow

from backend.core.database.base import Base


class NetworkDevice(Base):

    __tablename__ = "network_devices"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    # The zone this device belongs to (its View). A device can only
    # ever be in ONE zone -- with a single NIC it can only be on one
    # L3 network at a time, this is a hardware constraint, not a
    # design choice. NULL only transiently, before the discovery
    # service assigns it to the default zone on first sighting.
    zone_id: Mapped[int | None] = mapped_column(
        ForeignKey("network_zones.id"),
        nullable=True
    )


    # A physical machine with more than one NIC (e.g. a laptop with
    # Wi-Fi + Ethernet) shows up as one NetworkDevice row per MAC --
    # that's still correct for enforcement, since blocking the
    # machine actually means blocking each of its MACs individually.
    # This column is purely a DISPLAY grouping: when set, this row
    # is a secondary NIC of the device pointed to by linked_to_id,
    # and the API folds it under that primary device's
    # `linked_devices` instead of listing it as its own top-level
    # entry. NULL means "not linked" (either a single-NIC device, or
    # the primary/canonical row of a linked group).
    linked_to_id: Mapped[int | None] = mapped_column(
        ForeignKey("network_devices.id"),
        nullable=True
    )


    # False for personal devices (e.g. an employee's own phone on
    # the office Wi-Fi) that happen to share a zone with company
    # equipment. A zone's enforce_time_cutoff policy skips devices
    # where this is False -- see ScheduleEnforcementService /
    # TimePolicyService.
    is_company_asset: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    # Última IP conocida (histórica). NO es la IP actual observada.
    ip_address: Mapped[str] = mapped_column(
        String(45),
        nullable=False
    )

    # IP actual derivada de observaciones (ARP/lease/DNS/ping).
    current_ip: Mapped[str] = mapped_column(
        String(45),
        nullable=False,
        default="",
        server_default="",
    )

    presence_status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="UNKNOWN",
        server_default="UNKNOWN",
    )

    presence_source: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
    )

    presence_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    ip_conflict: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
    )


    mac_address: Mapped[str] = mapped_column(
        String(17),
        nullable=False,
        unique=True
    )


    hostname: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # Admin-set display name (overrides the auto-detected hostname in
    # the UI). The auto hostname keeps updating from DHCP; the
    # display_name is what the operator wants to see.
    display_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # Download bandwidth cap in kbps for THIS device (overrides the
    # group's cap). NULL = follow the group / unlimited.
    bandwidth_limit_kbps: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )


    vendor: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )


    interface: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True
    )


    status: Mapped[str] = mapped_column(
        String(20),
        default="UNKNOWN"
    )


    device_type: Mapped[str] = mapped_column(
        String(50),
        default="UNKNOWN"
    )


    is_permanent: Mapped[bool] = mapped_column(Boolean, default=False)

    # Reserved IP: what the device should get after restart (DHCP reservation)
    permanent_ip: Mapped[str | None] = mapped_column(String(45), nullable=True)

    blocked: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    first_seen: Mapped[datetime] = mapped_column(

        DateTime,

        default=utcnow

    )

    last_seen: Mapped[datetime] = mapped_column(

        DateTime,

        default=utcnow

    )