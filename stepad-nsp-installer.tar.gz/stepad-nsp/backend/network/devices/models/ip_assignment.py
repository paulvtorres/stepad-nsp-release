from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


class IpAssignment(Base):

    __tablename__ = "ip_assignments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    ip_address: Mapped[str] = mapped_column(
        String(45), nullable=False, index=True
    )

    mac_address: Mapped[str] = mapped_column(
        String(17), nullable=False, index=True
    )

    device_id: Mapped[int | None] = mapped_column(
        ForeignKey("network_devices.id", ondelete="SET NULL"),
        nullable=True,
    )

    kind: Mapped[str] = mapped_column(
        String(20), nullable=False, default="lease"
    )

    source: Mapped[str] = mapped_column(
        String(20), nullable=False, default="dhcp"
    )

    assigned_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, nullable=False
    )

    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )

    released_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )

    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="active"
    )
