from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


class DeviceIpHistory(Base):

    __tablename__ = "device_ip_history"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )

    device_id: Mapped[int | None] = mapped_column(
        ForeignKey("network_devices.id", ondelete="SET NULL"),
        nullable=True,
    )

    mac_address: Mapped[str | None] = mapped_column(
        String(17),
        nullable=True,
    )

    ip_address: Mapped[str] = mapped_column(
        String(45),
        nullable=False,
    )

    source: Mapped[str] = mapped_column(
        String(30),
        default="reconcile",
    )

    started_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utcnow,
    )

    ended_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
        default=utcnow,
    )
