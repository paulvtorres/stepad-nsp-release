from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


class DeviceIpObservation(Base):

    __tablename__ = "device_ip_observations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    mac_address: Mapped[str] = mapped_column(
        String(17), nullable=False, index=True
    )

    ip_address: Mapped[str] = mapped_column(
        String(45), nullable=False, index=True
    )

    source: Mapped[str] = mapped_column(
        String(20), nullable=False, index=True
    )

    observed_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, nullable=False, index=True
    )

    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )
