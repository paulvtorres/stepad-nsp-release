from sqlalchemy.orm import Session

from backend.network.devices.models.network_device import (
    NetworkDevice
)


class DeviceRepository:


    def find_all(
        self,
        db: Session
    ):

        return (

            db.query(NetworkDevice)

            .order_by(
                NetworkDevice.hostname
            )

            .all()

        )


    def find_top_level(
        self,
        db: Session
    ):
        """
        Devices NOT folded under another device -- either a
        single-NIC device, or the primary/canonical row of a linked
        group. This is what the devices list UI iterates over.
        """

        return (

            db.query(NetworkDevice)

            .filter(
                NetworkDevice.linked_to_id.is_(None)
            )

            .order_by(
                NetworkDevice.hostname
            )

            .all()

        )


    def find_linked_to(
        self,
        db: Session,
        primary_device_id: int
    ):

        return (

            db.query(NetworkDevice)

            .filter(
                NetworkDevice.linked_to_id == primary_device_id
            )

            .all()

        )


    def find_all_by_interface(
        self,
        db: Session,
        interface: str
    ):

        return (

            db.query(NetworkDevice)

            .filter(
                NetworkDevice.interface == interface
            )

            .all()

        )


    def find_by_mac(
        self,
        db: Session,
        mac: str
    ):

        return (

            db.query(NetworkDevice)

            .filter(
                NetworkDevice.mac_address == mac
            )

            .first()

        )


    def find_by_ip(
        self,
        db: Session,
        ip: str
    ):

        return (

            db.query(NetworkDevice)

            .filter(
                NetworkDevice.ip_address == ip
            )

            .first()

        )


    def count_new_since(
        self,
        db: Session,
        since
    ):

        return (

            db.query(NetworkDevice)

            .filter(
                NetworkDevice.first_seen >= since
            )

            .count()

        )


    def find_by_id(
        self,
        db: Session,
        device_id: int
    ):

        return (

            db.query(NetworkDevice)

            .filter(
                NetworkDevice.id == device_id
            )

            .first()

        )


    def save(
        self,
        db: Session,
        device: NetworkDevice
    ):

        db.add(device)

        db.commit()

        db.refresh(device)

        return device


    def update(
        self,
        db: Session,
        device: NetworkDevice
    ):

        db.commit()

        db.refresh(device)

        return device


    def delete(
        self,
        db: Session,
        device: NetworkDevice
    ):

        db.delete(device)

        db.commit()