"""Dominio puro de dispositivos (sin BD ni red)."""
