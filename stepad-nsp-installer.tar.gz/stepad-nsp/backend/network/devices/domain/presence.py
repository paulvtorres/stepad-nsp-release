"""Presencia de dispositivos: dominio PURO (sin BD, sin red, sin reloj).

Reglas, en una sola pagina:

* Un lease DHCP es una ASIGNACION, no una prueba de que el equipo este
  conectado. Nunca decide la presencia.
* La presencia sale de EVIDENCIAS con hora: ARP alcanzable (el kernel
  confirmo al vecino), consultas DNS desde esa IP y entradas ARP viejas.
* ONLINE   = evidencia fuerte reciente (<= online_ttl).
  PROBABLE = evidencia, pero vieja (<= probable_ttl) o solo ARP STALE.
  OFFLINE  = sin evidencia dentro de la ventana (UNKNOWN si nunca se vio).
* El estado envejece solo: ONLINE -> PROBABLE -> OFFLINE segun la hora de
  la ULTIMA evidencia, no segun la hora en que corre el reconciliador.
* Un conflicto de IP es "la IP esta en uso por una MAC distinta de la que
  tiene el lease". Nunca se oculta ni se resuelve quitandole la IP a nadie.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Iterable, Mapping

ONLINE = "ONLINE"
PROBABLE = "PROBABLE"
OFFLINE = "OFFLINE"
UNKNOWN = "UNKNOWN"

ARP_REACHABLE = "arp_reachable"
ARP_STALE = "arp_stale"
DNS = "dns"

# Fuentes que pueden dar ONLINE si la evidencia es reciente.
STRONG_SOURCES = frozenset({ARP_REACHABLE, DNS})

# Estados del kernel (`ip neigh`).
REACHABLE_STATES = frozenset({"REACHABLE", "DELAY", "PROBE", "PERMANENT"})
DEAD_STATES = frozenset({"FAILED", "INCOMPLETE"})

# Desempate al elegir la IP actual: ARP (con MAC) pesa mas que DNS (solo IP).
_RANK = {ARP_REACHABLE: 3, DNS: 2, ARP_STALE: 1}


@dataclass(frozen=True)
class PresencePolicy:

    online_ttl: timedelta = timedelta(minutes=5)

    probable_ttl: timedelta = timedelta(minutes=30)


@dataclass(frozen=True)
class NeighEntry:

    ip: str
    mac: str
    iface: str
    state: str

    @property
    def reachable(self) -> bool:

        return self.state in REACHABLE_STATES


@dataclass(frozen=True)
class Evidence:

    source: str
    ip: str
    seen_at: datetime


@dataclass(frozen=True)
class Presence:

    status: str
    current_ip: str
    source: str | None
    evidence_at: datetime | None


def parse_neigh(text: str, accept_iface=None) -> list[NeighEntry]:
    """Parsea `ip neigh show` (puro).

    Solo IPv4 (una entrada IPv6 de la misma MAC no debe pisar la IPv4) y
    solo vecinos con MAC resuelta y no muertos. `accept_iface` filtra por
    interfaz (p. ej. descartar la WAN).
    """

    entries: list[NeighEntry] = []

    for line in (text or "").splitlines():

        parts = line.split()

        if len(parts) < 4 or "lladdr" not in parts:

            continue

        ip = parts[0]

        try:

            if ipaddress.ip_address(ip).version != 4:

                continue

        except ValueError:

            continue

        try:

            mac = parts[parts.index("lladdr") + 1].lower()

        except IndexError:

            continue

        iface = parts[parts.index("dev") + 1] if "dev" in parts[:-1] else ""

        state = parts[-1].upper()

        if state in DEAD_STATES:

            continue

        if accept_iface is not None and not accept_iface(iface):

            continue

        entries.append(NeighEntry(ip, mac, iface, state))

    return entries


def _age(now: datetime, seen_at: datetime) -> timedelta:

    # Un reloj adelantado nunca debe dar evidencia "del futuro".
    return max(timedelta(0), now - seen_at)


def derive_presence(
    evidence: Iterable[Evidence],
    now: datetime,
    policy: PresencePolicy | None = None,
    ever_seen: bool = False,
) -> Presence:
    """Deriva la presencia de UN equipo a partir de sus evidencias."""

    policy = policy or PresencePolicy()

    items = [item for item in evidence if item.ip]

    strong = [
        item
        for item in items
        if item.source in STRONG_SOURCES
        and _age(now, item.seen_at) <= policy.online_ttl
    ]

    if strong:

        best = max(
            strong,
            key=lambda item: (_RANK.get(item.source, 0), item.seen_at),
        )

        return Presence(ONLINE, best.ip, best.source, best.seen_at)

    recent = [
        item
        for item in items
        if _age(now, item.seen_at) <= policy.probable_ttl
    ]

    if recent:

        best = max(
            recent,
            key=lambda item: (item.seen_at, _RANK.get(item.source, 0)),
        )

        return Presence(PROBABLE, best.ip, best.source, best.seen_at)

    latest = max((item.seen_at for item in items), default=None)

    return Presence(
        OFFLINE if (ever_seen or items) else UNKNOWN,
        "",
        None,
        latest,
    )


def find_ip_conflicts(
    assigned: Mapping[str, str],
    observed: Mapping[str, str],
) -> dict[str, tuple[str, str]]:
    """IPs usadas por una MAC distinta de la que tiene el lease.

    `assigned`: ip -> mac con lease vigente.
    `observed`: ip -> mac vista ALCANZABLE en la red ahora.
    Devuelve ip -> (mac_observada, mac_con_lease).
    """

    conflicts: dict[str, tuple[str, str]] = {}

    for ip, observed_mac in observed.items():

        owner = assigned.get(ip)

        if owner and owner != observed_mac:

            conflicts[ip] = (observed_mac, owner)

    return conflicts
