"""Utilidades de direcciones MAC."""


def normalize_mac(value: str | None) -> str:

    return (value or "").strip().lower().replace("-", ":")


def is_locally_administered(value: str | None) -> bool:

    """True si el MAC es de administracion local (aleatorio/privacidad).

    El segundo bit menos significativo del primer octeto distingue una MAC
    asignada por el fabricante de una generada por el sistema operativo
    para no ser rastreado. Esos MAC cambian con frecuencia, asi que no
    identifican de forma estable a un equipo.
    """

    mac = normalize_mac(value)

    if not mac:

        return False

    first = mac.split(":", 1)[0]

    if len(first) != 2:

        return False

    try:

        octet = int(first, 16)

    except ValueError:

        return False

    return bool(octet & 0x02)
