from sqlalchemy.orm import Session

from datetime import datetime

from backend.network.devices.models.network_device import NetworkDevice

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.rules.models.device_access_rule import DeviceAccessRule

from backend.groups.models.device_group import DeviceGroup, GroupDevice

from backend.network.devices.services.device_discovery_service import (
    DeviceDiscoveryService
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.firewall.services.time_policy_service import TimePolicyService

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)

from backend.bandwidth.services.bandwidth_service import (
    BandwidthService
)

from backend.shared.logging.logger import logger


# Hostnames too generic to safely suggest a match on -- several
# unrelated devices commonly share these (a phone's factory default,
# a router's own advertised name, a device that never customized
# it). Suggesting a link on these would produce mostly noise and,
# worse, could be trivially spoofed by an unrelated device that
# wants to look like it "belongs" with an already-trusted one.
GENERIC_HOSTNAMES = {
    "android",
    "android-phone",
    "iphone",
    "ipad",
    "localhost",
    "esp32",
    "esp8266",
    "unknown",
    "device",
}


class DeviceService:


    def __init__(self):

        self.repository = DeviceRepository()

        self.discovery_service = DeviceDiscoveryService()

        self.zone_repository = NetworkZoneRepository()

        self.time_policy_service = TimePolicyService()

        self.reservation_service = DhcpReservationService()

        self.bandwidth_service = BandwidthService()



    def get_all_devices(
        self,
        db: Session,
        scan: bool = False,
        include_infra: bool = False
    ):


        # El escaneo de red (netbios/mdns/llmnr) es lento y SOLO se
        # ejecuta cuando se pide explicitamente (scan=True, boton
        # "Escanear red"). La carga normal lee la base (rapida).

        if scan:

            self.discovery_service.synchronize(
                db
            )


        # Retornar dispositivos de nivel superior (sin agrupar bajo
        # otro), cada uno con sus NICs vinculadas embebidas para que
        # una misma máquina con Wi-Fi + cable aparezca como un solo
        # equipo en el listado.

        primaries = self.repository.find_top_level(
            db
        )

        # Los dispositivos de infraestructura (impresoras, teléfonos
        # IP, routers) se detectan y registran, pero quedan ocultos de
        # la lista por defecto (include_infra=False). Se filtran aqui
        # para que tampoco cuenten en contadores del listado.
        if not include_infra:

            from backend.network.devices.services.device_classifier import (
                DeviceClassifier
            )

            primaries = [
                device
                for device in primaries
                if not DeviceClassifier.is_infrastructure(
                    device.device_type
                )
            ]

        from backend.groups.repositories.device_group_repository import (
            DeviceGroupRepository
        )

        group_repo = DeviceGroupRepository()

        for device in primaries:

            # Grupo al que pertenece el equipo (un equipo = un solo
            # grupo). Se expone para que la UI pueda filtrar equipos
            # ya asignados.
            gids = group_repo.group_ids_for_device(db, device.id)
            device.groups = []
            if gids:
                for g in db.query(DeviceGroup).filter(
                    DeviceGroup.id.in_(gids)
                ).all():
                    device.groups.append({
                        "id": g.id,
                        "name": g.name,
                    })

            linked = self.repository.find_linked_to(
                db,
                device.id
            )

            device.linked_devices = [
                {
                    "id": nic.id,
                    "mac_address": nic.mac_address,
                    "ip_address": nic.ip_address,
                    "hostname": nic.hostname,
                    "interface": nic.interface,
                    "vendor": nic.vendor,
                    "status": nic.status,
                    "device_type": nic.device_type,
                }
                for nic in linked
            ]

        self._attach_suggested_matches(primaries)

        return primaries



    def _attach_suggested_matches(
        self,
        primaries
    ):
        """
        Flags likely-same-machine candidates for the admin to review
        and confirm with one click -- NEVER auto-linked. Two
        still-unlinked top-level devices are suggested to each other
        when they report the exact same DHCP hostname (case
        insensitive) and that hostname isn't one of the generic
        defaults several unrelated devices tend to share.

        Deliberately conservative: hostname is the only signal we
        have that's actually set by the device's OS rather than
        guessed from network behavior, but it CAN be spoofed by a
        hostile device wanting to inherit a trusted device's
        permissions -- which is exactly why this only ever produces
        a suggestion, never an automatic merge.
        """

        by_hostname = {}

        for device in primaries:

            hostname = (device.hostname or "").strip().lower()

            if not hostname or hostname in GENERIC_HOSTNAMES:

                continue

            by_hostname.setdefault(hostname, []).append(device)

        for device in primaries:

            device.suggested_matches = []

        for hostname, group in by_hostname.items():

            if len(group) < 2:

                continue

            for device in group:

                device.suggested_matches = [
                    {
                        "id": other.id,
                        "mac_address": other.mac_address,
                        "interface": other.interface,
                        "hostname": other.hostname,
                    }
                    for other in group
                    if other.id != device.id
                ]



    def get_device(
        self,
        device_id: int,
        db: Session
    ):


        return self.repository.find_by_id(
            db,
            device_id
        )



    def link_devices(
        self,
        device_id: int,
        primary_device_id: int,
        db: Session
    ):
        """
        Marks `device_id` as a secondary NIC of `primary_device_id`
        -- for grouping two MAC addresses belonging to the same
        physical machine (e.g. its Wi-Fi and Ethernet adapters) into
        one entry in the devices list. Both rows keep existing
        independently for enforcement purposes (blocking, schedules,
        DHCP reservations still act per-MAC, since that's what
        actually cuts a NIC off) -- this only affects how they're
        displayed.
        """

        device = self.repository.find_by_id(db, device_id)

        primary = self.repository.find_by_id(db, primary_device_id)

        if not device or not primary:

            return {
                "success": False,
                "message": "Device not found"
            }

        if device.id == primary.id:

            return {
                "success": False,
                "message": "A device cannot be linked to itself"
            }

        if primary.linked_to_id is not None:

            return {
                "success": False,
                "message": (
                    "The target device is itself linked to another "
                    "one -- link to its primary device instead"
                )
            }

        # Flatten: if `device` already has other NICs grouped under
        # it, move them to the new primary too rather than leaving
        # them orphaned under a row that's about to stop being a
        # primary itself.
        for nic in self.repository.find_linked_to(db, device.id):

            nic.linked_to_id = primary.id

            self.repository.update(db, nic)

        device.linked_to_id = primary.id

        self.repository.update(db, device)

        return {
            "success": True,
            "message": f"Linked device {device.id} under {primary.id}"
        }



    def unlink_device(
        self,
        device_id: int,
        db: Session
    ):

        device = self.repository.find_by_id(db, device_id)

        if not device:

            return {
                "success": False,
                "message": "Device not found"
            }

        device.linked_to_id = None

        self.repository.update(db, device)

        return {
            "success": True,
            "message": f"Unlinked device {device.id}"
        }



    def refresh_device(
        self,
        device_id: int,
        db: Session
    ):

        device = self.repository.find_by_id(db, device_id)

        if not device:

            return None

        discovery = self.discovery_service

        changes = []

        lease = next(
            (
                lease
                for lease in discovery.lease_service.list_leases()
                if lease.mac.lower() == device.mac_address.lower()
            ),
            None
        )

        if lease:

            if lease.hostname:

                if (
                    device.display_name
                    and device.display_name != lease.hostname
                ):

                    # El nombre visible era un nombre fijado que ya no
                    # coincide con el que reporta el equipo: Actualizar
                    # trae el nombre real del dispositivo.
                    device.display_name = None

                    changes.append("nombre")

                if lease.hostname != device.hostname:

                    device.hostname = lease.hostname

                    device.device_type = discovery.classifier.classify(
                        lease.hostname
                    )

                    changes.append("nombre")

            if lease.ip and lease.ip != device.ip_address:

                device.ip_address = lease.ip

                changes.append("IP")

        online = False

        network = discovery.network_configuration.get_lan_configuration()

        if network is not None:

            for info in discovery.provider.list_devices(
                network["interface"]
            ):

                if (
                    info.mac_address.lower()
                    == device.mac_address.lower()
                ):

                    online = True

                    break

        if online:

            device.last_seen = datetime.utcnow()

        if online:

            # Preguntar el nombre actual al propio equipo (NetBIOS,
            # mDNS o LLMNR) aunque el lease de DHCP esté vencido/obsoleto.
            live_name, live_source = (
                discovery.hostname_resolver.resolve_with_source(
                    device.ip_address
                )
            )

            logger.info(
                "[Actualizar] mac=%s ip=%s lease_hostname=%s "
                "live_name=%s (fuente=%s) hostname_actual=%s",
                device.mac_address,
                device.ip_address,
                lease.hostname if lease else None,
                live_name,
                live_source or "no responde netbios/mdns/llmnr",
                device.hostname,
            )

            if live_name:

                current = device.display_name or device.hostname

                if (
                    not current
                    or live_name.lower() != current.lower()
                ):

                    device.hostname = live_name

                    device.display_name = None

                    device.device_type = discovery.classifier.classify(
                        live_name
                    )

                    changes.append("nombre")

        new_status = "ONLINE" if online else "OFFLINE"

        if new_status != device.status:

            device.status = new_status

            changes.append("estado")

        payload = {
            "id": device.id,
            "hostname": device.hostname,
            "display_name": device.display_name,
            "mac_address": device.mac_address,
            "ip_address": device.ip_address,
            "device_type": device.device_type,
            "status": device.status,
            "online": device.status == "ONLINE",
            "bandwidth_limit_kbps": device.bandwidth_limit_kbps,
            "last_seen": device.last_seen.isoformat() if device.last_seen else None,
        }

        if not changes:

            return {
                "success": True,
                "changed": False,
                "message": "No hay nada que actualizar",
                "device": payload,
            }

        self.repository.update(db, device)

        return {
            "success": True,
            "changed": True,
            "message": "Dispositivo actualizado: " + ", ".join(changes),
            "device": payload,
        }

    def update_device(
        self,
        device_id: int,
        request,
        db: Session
    ):

        device = self.repository.find_by_id(db, device_id)

        if not device:

            return None

        previous_zone_id = device.zone_id

        if request.zone_id is not None:

            device.zone_id = request.zone_id

        if request.is_company_asset is not None:

            device.is_company_asset = request.is_company_asset

        if request.display_name is not None:

            device.display_name = (
                request.display_name.strip() or None
            )

        if "bandwidth_limit_kbps" in request.model_fields_set:

            device.bandwidth_limit_kbps = (
                request.bandwidth_limit_kbps
            )

        updated = self.repository.update(db, device)

        if request.zone_id is not None:

            self.reservation_service.synchronize()

        if "bandwidth_limit_kbps" in request.model_fields_set:

            try:

                self.bandwidth_service.apply()

            except Exception as error:

                logger.error(
                    "Fallo al aplicar ancho de banda: %s",
                    error
                )

        # Re-sync the time-cutoff nftables set for every zone whose
        # company-asset IP membership could have just changed --
        # both where the device came FROM and where it went TO.
        affected_zone_ids = {
            zone_id
            for zone_id in (previous_zone_id, updated.zone_id)
            if zone_id is not None
        }

        for zone_id in affected_zone_ids:

            zone = self.zone_repository.find_by_id(db, zone_id)

            if zone:

                self.time_policy_service.sync_zone(db, zone)

        return updated


    def delete_device(
        self,
        device_id: int,
        db: Session,
        user_id: int | None = None,
        reason: str = ""
    ) -> dict:

        device = self.repository.find_by_id(db, device_id)

        if not device:

            return {"deleted": False, "reason": "not_found"}

        # Unlink any device that pointed to this one as its primary.
        db.query(NetworkDevice).filter(
            NetworkDevice.linked_to_id == device.id
        ).update(
            {"linked_to_id": None},
            synchronize_session=False
        )

        # Access rules reference the device and have no ON DELETE
        # CASCADE, so remove them explicitly.
        db.query(DeviceAccessRule).filter(
            DeviceAccessRule.device_id == device.id
        ).delete(synchronize_session=False)

        # Los logs de navegacion NO se borran: se conservan con el
        # nombre de la maquina (device_hostname) que se guardo al
        # escribirlos. Solo se desvincula device_id (FK) para poder
        # eliminar la fila del dispositivo sin violar la referencia.
        from backend.dns.logging.models.dns_query_log import DnsQueryLog

        db.query(DnsQueryLog).filter(
            DnsQueryLog.device_id == device.id
        ).update(
            {"device_id": None},
            synchronize_session=False
        )

        # Group membership rows (DB also cascades them; removed
        # explicitly for determinism).
        db.query(GroupDevice).filter(
            GroupDevice.device_id == device.id
        ).delete(synchronize_session=False)

        self.repository.delete(db, device)

        # Registrar el motivo de eliminacion en el log de auditoria.
        try:

            from backend.audit.services.audit_service import AuditService

            AuditService().create_log(
                db,
                user_id=user_id,
                action="device_delete",
                resource=f"Device {device_id}",
                description=(
                    f"Dispositivo eliminado: {device.hostname or ''} "
                    f"({device.mac_address}). "
                    f"Motivo: {reason or 'sin especificar'}."
                )
            )

        except Exception as error:

            from backend.shared.logging.logger import logger

            logger.warning(
                f"No se pudo registrar la auditoria del borrado: {error}"
            )

        return {"deleted": True}
