"""Reconciliador de presencia: el UNICO escritor de IP y estado.

Flujo (una pasada):

1. Leer la realidad: vecinos ARP (`ip neigh`, solo IPv4 y fuera de la
   WAN), leases vigentes y la ultima consulta DNS por IP.
2. Guardar OBSERVACIONES con su hora (tabla `device_ip_observations`).
   Una entrada ARP STALE solo se registra la primera vez: que el kernel la
   conserve no es una señal nueva del equipo.
3. Derivar la presencia con `derive_presence` (dominio puro) leyendo esas
   mismas observaciones, asi el estado envejece por la hora de la ultima
   evidencia y no por la hora en que corre el reconciliador.
4. Los equipos sin evidencia fresca se VERIFICAN activamente (ping en
   paralelo: obliga al kernel a resolver ARP, y un equipo que bloquea ICMP
   igual contesta ARP) y se vuelve a derivar.
5. Escribir: `current_ip`, `assigned_ip`, `last_ip`, `presence_*`,
   `ip_conflict` y, por compatibilidad, `status`, `last_seen` e
   `ip_address` (espejo de la ultima IP). Nadie mas debe escribirlos.

El lease solo alimenta `assigned_ip` y los conflictos: nunca la presencia.
"""

from __future__ import annotations

import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from pathlib import Path

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.session import SessionLocal
from backend.dhcp.domain.leases import read_leases
from backend.dhcp.domain.neighbors import arp_mac_by_ip
from backend.network.devices.domain.presence import (
    ARP_REACHABLE,
    ARP_STALE,
    DNS,
    OFFLINE,
    ONLINE,
    PROBABLE,
    STRONG_SOURCES,
    UNKNOWN,
    Evidence,
    NeighEntry,
    PresencePolicy,
    derive_presence,
    find_ip_conflicts,
    parse_neigh,
)
from backend.network.devices.models.device_ip_observation import (
    DeviceIpObservation,
)
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.services.ip_history_service import (
    IpHistoryService,
)
from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger

OBSERVATION_RETENTION = timedelta(days=7)

MAX_PROBES = 128


class DevicePresenceService:

    def __init__(
        self,
        policy: PresencePolicy | None = None,
        *,
        neigh_reader=None,
        lease_reader=None,
        dns_reader=None,
        prober=None,
        lan_ip=None,
        accept_iface=None,
        clock=utcnow,
        active_probe: bool = True,
    ):

        self.policy = policy or PresencePolicy()

        self._neigh_reader = neigh_reader or self._read_neigh

        self._lease_reader = lease_reader or self._read_leases

        self._dns_reader = dns_reader or self._read_dns

        self._prober = prober or self._probe

        self._lan_ip = lan_ip

        self._accept_iface = accept_iface

        self._clock = clock

        self._active_probe = active_probe

    # ------------------------------------------------------------------
    # Lecturas de la realidad (todas reemplazables en tests)
    # ------------------------------------------------------------------

    def _lan_scope(self):

        try:

            from backend.network.services.lan_scope_service import (
                LanScopeService,
            )

            return LanScopeService()

        except Exception as error:  # pragma: no cover - entorno sin red

            logger.debug("presence: sin LanScopeService: %s", error)

            return None

    def _iface_filter(self):

        if self._accept_iface is not None:

            return self._accept_iface

        scope = self._lan_scope()

        if scope is None:

            return None

        # Solo se descarta la WAN: las interfaces de zonas/VLAN cuentan.
        return lambda iface: not scope.is_wan_interface(iface)

    def _is_lan_ip(self, ip: str) -> bool:

        if self._lan_ip is not None:

            return bool(self._lan_ip(ip))

        scope = self._lan_scope()

        return bool(scope.is_lan_ip(ip)) if scope else True

    def _read_neigh(self) -> list[NeighEntry]:

        accept = self._iface_filter()

        try:

            proc = subprocess.run(
                ["ip", "neigh", "show"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            entries = parse_neigh(proc.stdout, accept)

            if entries or proc.stdout.strip():

                return entries

        except (OSError, subprocess.SubprocessError):

            pass

        # Respaldo sin `ip neigh`: /proc/net/arp no trae estado, asi que
        # todo cuenta como STALE (evidencia debil), nunca como alcanzable.
        try:

            text = Path("/proc/net/arp").read_text(encoding="utf-8")

            return [
                NeighEntry(ip, (mac or "").lower(), "", "STALE")
                for ip, mac in arp_mac_by_ip(text).items()
            ]

        except OSError:

            return []

    def _read_leases(self) -> dict[str, str]:
        """mac -> ip de los leases VIGENTES."""

        now = int(time.time())

        result: dict[str, str] = {}

        try:

            for lease in read_leases(DNSMASQ_LEASES_FILE):

                if lease.infinite or lease.expires_at > now:

                    result[(lease.mac or "").lower()] = lease.ip

        except Exception as error:

            logger.debug("presence: no se leyeron leases: %s", error)

        return result

    def _read_dns(self, db, since: datetime) -> dict[str, datetime]:

        try:

            from backend.dns.logging.repositories.dns_query_log_repository import (
                DnsQueryLogRepository,
            )

            return DnsQueryLogRepository().last_query_by_ip(db, since)

        except Exception as error:

            logger.debug("presence: sin señal DNS: %s", error)

            return {}

    @staticmethod
    def _probe(ips: list[str]) -> None:
        """Ping en paralelo: fuerza la resolucion ARP de cada IP."""

        def ping(ip: str) -> None:

            try:

                subprocess.run(
                    ["ping", "-c", "1", "-W", "1", "-q", ip],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=2,
                )

            except Exception as error:

                logger.debug("presence: ping %s: %s", ip, error)

        if not ips:

            return

        with ThreadPoolExecutor(max_workers=min(32, len(ips))) as pool:

            list(pool.map(ping, ips))

    # ------------------------------------------------------------------
    # Observaciones
    # ------------------------------------------------------------------

    @staticmethod
    def _load_rows(db) -> dict[tuple, DeviceIpObservation]:

        rows = {}

        for row in db.query(DeviceIpObservation).all():

            rows.setdefault(
                (row.mac_address, row.ip_address, row.source), row
            )

        return rows

    @staticmethod
    def _upsert(
        db,
        rows: dict,
        mac: str,
        ip: str,
        source: str,
        seen_at: datetime,
        refresh: bool = True,
    ) -> None:

        key = (mac, ip, source)

        row = rows.get(key)

        if row is None:

            row = DeviceIpObservation(
                mac_address=mac,
                ip_address=ip,
                source=source,
                observed_at=seen_at,
            )

            db.add(row)

            rows[key] = row

        elif refresh and seen_at > row.observed_at:

            row.observed_at = seen_at

    def _record(
        self,
        db,
        rows: dict,
        known: set[str],
        entries: list[NeighEntry],
        leases: dict[str, str],
        dns_last: dict[str, datetime],
        now: datetime,
    ) -> None:

        claims: dict[str, set[str]] = {}

        for entry in entries:

            claims.setdefault(entry.ip, set()).add(entry.mac)

            if entry.mac not in known:

                continue

            if entry.reachable:

                self._upsert(db, rows, entry.mac, entry.ip, ARP_REACHABLE, now)

            elif not any(
                key[0] == entry.mac and key[1] == entry.ip for key in rows
            ):

                # STALE: el kernel solo recuerda al vecino; no es una señal
                # nueva. Se registra UNA vez y solo si de esa (mac, ip) no
                # hay nada mas: si ya hubo evidencia real, el STALE no la
                # extiende ni la reemplaza.
                self._upsert(
                    db, rows, entry.mac, entry.ip, ARP_STALE, now, refresh=False
                )

        for mac, ip in leases.items():

            claims.setdefault(ip, set()).add(mac)

        # DNS solo se atribuye cuando la IP tiene UN solo reclamante: si
        # dos equipos la reclaman, la consulta es ambigua y se descarta.
        for ip, seen_at in dns_last.items():

            owners = claims.get(ip) or set()

            if len(owners) == 1:

                mac = next(iter(owners))

                if mac in known:

                    self._upsert(db, rows, mac, ip, DNS, seen_at)

    def _evidence(self, rows: dict, now: datetime) -> dict[str, list[Evidence]]:

        horizon = now - self.policy.probable_ttl

        result: dict[str, list[Evidence]] = {}

        for (mac, ip, source), row in rows.items():

            if row.observed_at >= horizon:

                result.setdefault(mac, []).append(
                    Evidence(source, ip, row.observed_at)
                )

        return result

    # ------------------------------------------------------------------
    # Reconciliacion
    # ------------------------------------------------------------------

    def reconcile(self, db=None) -> dict:

        own = db is None

        if own:

            db = SessionLocal()

        try:

            return self._reconcile(db)

        except Exception:

            db.rollback()

            raise

        finally:

            if own:

                db.close()

    def _derive_all(self, devices, evidence, now):

        return {
            (device.mac_address or "").lower(): derive_presence(
                evidence.get((device.mac_address or "").lower(), []),
                now,
                self.policy,
                ever_seen=bool(device.last_seen or device.presence_at),
            )
            for device in devices
        }

    def _reconcile(self, db) -> dict:

        now = self._clock()

        devices = db.query(NetworkDevice).all()

        by_mac = {(d.mac_address or "").lower(): d for d in devices}

        known = set(by_mac)

        leases = self._lease_reader()

        dns_last = self._dns_reader(db, now - self.policy.probable_ttl)

        rows = self._load_rows(db)

        entries = self._neigh_reader()

        self._record(db, rows, known, entries, leases, dns_last, now)

        evidence = self._evidence(rows, now)

        results = self._derive_all(devices, evidence, now)

        # Verificacion activa: solo a quien no tiene evidencia fresca.
        if self._active_probe:

            targets = []

            for mac, result in results.items():

                if result.status == ONLINE:

                    continue

                device = by_mac[mac]

                ip = (
                    device.current_ip
                    or device.last_ip
                    or device.ip_address
                    or leases.get(mac)
                    or ""
                )

                if ip and self._is_lan_ip(ip):

                    targets.append(ip)

            targets = list(dict.fromkeys(targets))[:MAX_PROBES]

            if targets:

                self._prober(targets)

                entries = self._neigh_reader()

                self._record(db, rows, known, entries, leases, {}, now)

                evidence = self._evidence(rows, now)

                results = self._derive_all(devices, evidence, now)

        observed = {}

        for entry in entries:

            if entry.reachable:

                observed.setdefault(entry.ip, entry.mac)

        assigned = {ip: mac for mac, ip in leases.items()}

        conflicts = find_ip_conflicts(assigned, observed)

        conflicted = {mac for pair in conflicts.values() for mac in pair}

        history = IpHistoryService()

        for mac, device in by_mac.items():

            result = results[mac]

            assigned_ip = leases.get(mac, "")

            device.assigned_ip = assigned_ip

            device.current_ip = result.current_ip

            if result.current_ip:

                previous_ip = device.last_ip or device.ip_address

                if previous_ip and previous_ip != result.current_ip:

                    history.record_closed(db, device, previous_ip, "presence")

                device.last_ip = result.current_ip

                # Espejo legado: el resto del sistema sigue leyendo
                # `ip_address` como "ultima IP conocida".
                device.ip_address = result.current_ip

            elif not device.last_ip and assigned_ip:

                device.last_ip = assigned_ip

            device.presence_status = result.status

            device.presence_source = result.source

            if result.evidence_at is not None:

                device.presence_at = result.evidence_at

            device.ip_conflict = mac in conflicted

            # Compatibilidad: `status` ya no lo escribe nadie mas.
            device.status = (
                "ONLINE" if result.status in (ONLINE, PROBABLE) else "OFFLINE"
            )

            # Solo una evidencia FUERTE mueve "ultimo visto" (el reclamo
            # de leases del DHCP y la limpieza dependen de ese dato).
            if (
                result.source in STRONG_SOURCES
                and result.evidence_at is not None
                and (not device.last_seen or result.evidence_at > device.last_seen)
            ):

                device.last_seen = result.evidence_at

            db.add(device)

        self._alert_conflicts(db, conflicts, by_mac)

        db.query(DeviceIpObservation).filter(
            DeviceIpObservation.observed_at < now - OBSERVATION_RETENTION
        ).delete(synchronize_session=False)

        db.commit()

        counts = {ONLINE: 0, PROBABLE: 0, OFFLINE: 0, UNKNOWN: 0}

        for result in results.values():

            counts[result.status] = counts.get(result.status, 0) + 1

        return {
            "success": True,
            "devices": len(devices),
            "online": counts[ONLINE],
            "probable": counts[PROBABLE],
            "offline": counts[OFFLINE],
            "unknown": counts[UNKNOWN],
            "conflicts": len(conflicts),
        }

    def mark_all_offline(self, db) -> int:
        """Sin red LAN configurada nadie puede estar conectado."""

        count = 0

        for device in db.query(NetworkDevice).all():

            if device.presence_status != OFFLINE or device.current_ip:

                device.presence_status = OFFLINE

                device.presence_source = None

                device.current_ip = ""

                device.ip_conflict = False

                device.status = "OFFLINE"

                db.add(device)

                count += 1

        db.commit()

        return count

    @staticmethod
    def _alert_conflicts(db, conflicts: dict, by_mac: dict) -> None:

        if not conflicts:

            return

        def label(mac):

            device = by_mac.get(mac)

            name = (device.display_name or device.hostname) if device else None

            return f"{name} ({mac})" if name else mac

        try:

            from backend.alerts.services.alert_service import AlertService

            for ip, (observed_mac, owner_mac) in conflicts.items():

                AlertService().create(
                    db,
                    alert_type="DHCP_IP_DUPLICATE_ACTIVE",
                    severity="warning",
                    title=f"IP en uso por otro equipo: {ip}",
                    message=(
                        f"{ip} está asignada por DHCP a {label(owner_mac)} "
                        f"pero la está usando {label(observed_mac)}. La "
                        "lista muestra ambos equipos con el conflicto "
                        "marcado; no se le quita la IP a ninguno."
                    ),
                )

        except Exception as error:

            logger.debug("device_presence_service alert: %s", error)
