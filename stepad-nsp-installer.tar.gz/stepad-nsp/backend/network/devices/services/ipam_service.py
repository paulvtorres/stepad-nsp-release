"""IPAM formal: reservas y leases como asignaciones, no observaciones."""

from __future__ import annotations

import time
from datetime import datetime, timezone

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.session import SessionLocal
from backend.dhcp.domain.leases import read_leases
from backend.network.devices.models.ip_assignment import IpAssignment
from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger


def _naive_utc(timestamp):
    return datetime.fromtimestamp(timestamp, timezone.utc).replace(tzinfo=None)


class IpamService:

    def _leases(self) -> dict[str, dict]:
        now = int(time.time())
        result = {}

        try:
            for lease in read_leases(DNSMASQ_LEASES_FILE):
                if lease.infinite or lease.expires_at > now:
                    result[(lease.mac or "").lower()] = {
                        "ip": lease.ip,
                        "expires_at": (
                            None
                            if lease.infinite
                            else _naive_utc(lease.expires_at)
                        ),
                    }
        except Exception as error:
            logger.debug("ipam: no se leyeron leases: %s", error)

        return result

    def _alert_conflict(self, db, ip, lease_mac, reserved_mac):
        try:
            from backend.alerts.services.alert_service import AlertService

            AlertService().create(
                db,
                alert_type="IPAM_CONFLICT",
                severity="warning",
                title=f"Conflicto de asignación: {ip}",
                message=(
                    f"La IP {ip} está reservada a {reserved_mac}, pero el "
                    f"lease vigente pertenece a {lease_mac}. La reserva se "
                    "mantiene; revisar el equipo con el lease."
                ),
            )
        except Exception as error:
            logger.debug("ipam alert: %s", error)

    def reconcile(self, db=None) -> dict:
        own = db is None
        if own:
            db = SessionLocal()

        try:
            now = utcnow()
            leases = self._leases()
            devices = db.query(NetworkDevice).all()
            by_mac = {
                (device.mac_address or "").lower(): device
                for device in devices
            }

            desired = {}
            conflicts = []

            # Las reservas son la autoridad máxima.
            for device in devices:
                ip = (device.permanent_ip or "").strip()
                mac = (device.mac_address or "").lower()
                if not ip or not mac:
                    continue
                if ip in desired and desired[ip]["mac"] != mac:
                    conflicts.append((ip, mac, desired[ip]["mac"]))
                    continue
                desired[ip] = {
                    "mac": mac,
                    "device_id": device.id,
                    "kind": "reservation",
                    "source": "reservation",
                    "expires_at": None,
                }

            # Los leases no pueden pisar una reserva de otra MAC.
            for mac, info in leases.items():
                ip = info["ip"]
                if ip in desired:
                    if desired[ip]["mac"] != mac:
                        self._alert_conflict(
                            db, ip, mac, desired[ip]["mac"]
                        )
                        conflicts.append((ip, mac, desired[ip]["mac"]))
                    # Misma MAC: la reserva manda y no duplica asignación.
                    continue
                desired[ip] = {
                    "mac": mac,
                    "device_id": getattr(by_mac.get(mac), "id", None),
                    "kind": "lease",
                    "source": "dhcp",
                    "expires_at": info["expires_at"],
                }

            active = (
                db.query(IpAssignment)
                .filter(IpAssignment.released_at.is_(None))
                .all()
            )
            active_by_ip = {row.ip_address: row for row in active}

            for ip, item in desired.items():
                current = active_by_ip.get(ip)
                if (
                    current
                    and current.mac_address == item["mac"]
                    and current.kind == item["kind"]
                ):
                    current.expires_at = item["expires_at"]
                    current.device_id = item["device_id"]
                    current.source = item["source"]
                    db.add(current)
                    continue

                if current:
                    current.released_at = now
                    current.status = "released"
                    db.add(current)
                    db.flush()

                db.add(
                    IpAssignment(
                        ip_address=ip,
                        mac_address=item["mac"],
                        device_id=item["device_id"],
                        kind=item["kind"],
                        source=item["source"],
                        assigned_at=now,
                        expires_at=item["expires_at"],
                        status="active",
                    )
                )

            for ip, current in active_by_ip.items():
                if ip not in desired:
                    current.released_at = now
                    current.status = "released"
                    db.add(current)

            db.commit()

            return {
                "success": True,
                "assignments": len(desired),
                "conflicts": len(conflicts),
            }

        except Exception:
            db.rollback()
            raise
        finally:
            if own:
                db.close()

    def active_by_mac(self, db) -> dict[str, dict]:
        rows = (
            db.query(IpAssignment)
            .filter(IpAssignment.released_at.is_(None))
            .all()
        )
        return {
            row.mac_address: {
                "ip": row.ip_address,
                "kind": row.kind,
                "expires_at": row.expires_at,
            }
            for row in rows
        }
