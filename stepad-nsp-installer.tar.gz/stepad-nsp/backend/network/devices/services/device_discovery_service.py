import ipaddress

from datetime import datetime

from sqlalchemy.orm import Session

from backend.infrastructure.network.adapters.linux.arp_provider import (
    ARPProvider
)

from backend.infrastructure.network.services.hostname_resolver import (
    HostnameResolver
)

from backend.dhcp.services.dhcp_lease_service import (
    DhcpLeaseService
)

from backend.network.configuration.services.network_configuration_service import (
    NetworkConfigurationService
)

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.network.devices.services.device_classifier import (
    DeviceClassifier
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.groups.services.group_service import (
    GroupService
)

from backend.shared.logging.logger import logger


class DeviceDiscoveryService:


    def __init__(self):

        self.provider = ARPProvider()

        self.lease_service = DhcpLeaseService()

        self.hostname_resolver = HostnameResolver()

        self.network_configuration = NetworkConfigurationService()

        self.repository = DeviceRepository()

        self.classifier = DeviceClassifier()

        self.zone_repository = NetworkZoneRepository()

    def synchronize(
        self,
        db: Session
    ):


        network = self.network_configuration.get_lan_configuration()


        if network is None:

            # No LAN interface exists right now (e.g. mid-setup on
            # new hardware, nothing assigned yet) -- by definition
            # nothing can actually be online. Without this, the
            # function used to just `return []` here, which skipped
            # the "mark missing devices offline" pass below entirely
            # -- any device previously seen stayed stuck at
            # status=ONLINE forever, even with no LAN at all to have
            # seen it on.
            self._mark_all_devices_offline(db)

            return []



        interface = network["interface"]



        devices = self.provider.list_devices(
            interface
        )



        # Only neighbors actually inside one of the configured LAN
        # networks are part of the protected network. ARP on a LAN
        # interface normally can't return anything else, but an
        # interface that was (mis)assigned LAN before the admin
        # sorted out the interface registry leaves stale neighbors
        # in the table -- exactly how foreign hosts (e.g.
        # 192.168.100.x from the WAN card) once got persisted as
        # "devices". Filtering here is what stops that from ever
        # happening again.
        lan_networks = [
            ipaddress.ip_network(net["network"])
            for net in self.network_configuration.get_lan_configurations()
            if net.get("network")
        ]

        if lan_networks:

            devices = [
                device
                for device in devices
                if any(
                    ipaddress.ip_address(device.ip_address) in lan_network
                    for lan_network in lan_networks
                )
            ]



        found_macs = {

            device.mac_address.lower()

            for device in devices

        }



        leases = self.lease_service.list_leases()



        leases_by_mac = {

            lease.mac.lower(): lease

            for lease in leases

            if lease.mac

        }



        saved_devices = []

        default_zone = self.zone_repository.find_default(db)

        for device in devices:


            lease = leases_by_mac.get(
                device.mac_address.lower()
            )


            if lease:

                device.hostname = lease.hostname

                device.device_type = self.classifier.classify(

                device.hostname

)


            # Si el equipo no tiene lease ni nombre (IP estatica), se
            # intenta resolver el nombre por NetBIOS/mDNS/LLMNR, como
            # hace "Actualizar informacion". Solo para equipos que NO
            # son infraestructura (telefonos/impresoras/routers) y sin
            # nombre, para no ralentizar el escaneo.
            if not device.hostname and not DeviceClassifier.is_infrastructure(
                device.device_type
            ):

                try:

                    resolved, _ = self.hostname_resolver.resolve_with_source(
                        device.ip_address,
                        timeout=1.5,
                    )

                    if resolved:

                        device.hostname = resolved

                        device.device_type = self.classifier.classify(
                            resolved
                        )

                except Exception:

                    pass


            # Fallback por MAC (OUI del fabricante): muchos telefonos IP,
            # impresoras y routers no declaran hostname ni responden a
            # netbios/mDNS/LLMNR. Si la clasificacion por nombre no los
            # marco como infraestructura, se intenta por fabricante.
            # Solo se aplica si el OUI da un resultado util (nunca
            # "UNKNOWN", para no pisar el tipo derivado del nombre).
            if not DeviceClassifier.is_infrastructure(
                device.device_type
            ):

                mac_type = DeviceClassifier.classify_by_mac(
                    device.mac_address
                )

                if mac_type != "UNKNOWN":

                    device.device_type = mac_type

            existing = self.repository.find_by_mac(
                db,
                device.mac_address
            )



            if existing:


                existing.ip_address = device.ip_address

                # NO pisar el nombre guardado (p. ej. fijado con
                # "Actualizar información") si el equipo no reporta uno
                # nuevo (lease o resolucion). Si device.hostname es None,
                # se conserva el nombre existente.
                if device.hostname:

                    existing.hostname = device.hostname

                existing.vendor = device.vendor

                existing.interface = device.interface

                existing.status = "ONLINE"

                existing.device_type = device.device_type

                existing.last_seen = datetime.utcnow()



                self.repository.update(
                    db,
                    existing
                )


                saved_devices.append(existing)



            else:


                model = NetworkDevice(

                    ip_address=device.ip_address,

                    mac_address=device.mac_address,

                    hostname=device.hostname,

                    vendor=device.vendor,

                    interface=device.interface,

                    status="ONLINE",

                    device_type=device.device_type,

                    zone_id=default_zone.id if default_zone else None,

                    first_seen=datetime.utcnow(),

                    last_seen=datetime.utcnow()

                )



                saved = self.repository.save(
                    db,
                    model
                )

                # New/unrecognized device lands in the default group
                # (Invitados) automatically; the admin moves it to its
                # department later. Los dispositivos de infraestructura
                # (impresoras, teléfonos IP, routers) NO pueden
                # pertenecer a grupos, así que no se asignan.
                if not DeviceClassifier.is_infrastructure(
                    model.device_type
                ):
                    try:

                        group_service = GroupService()

                        default_group = group_service.ensure_default_group(db)

                        group_service.repository.add_device(
                            db,
                            default_group.id,
                            saved.id
                        )

                    except Exception as error:

                        logger.warning(
                            f"Auto-assign to default group failed: {error}"
                        )

                saved_devices.append(saved)



        #
        # Marcar dispositivos desaparecidos como OFFLINE
        #

        existing_devices = self.repository.find_all_by_interface(
            db,
            interface
        )



        for existing in existing_devices:


            if existing.mac_address.lower() not in found_macs:


                existing.status = "OFFLINE"



                self.repository.update(
                    db,
                    existing
                )



        #
        # NO se purgan dispositivos por IP fuera de la red LAN actual:
        # al cambiar el segmento, los equipos conservan su registro (por
        # MAC), grupo y zona; su IP se actualiza cuando reconectan. El
        # borrado es SOLO manual (caso extremo) y preserva los logs.
        #


        #
        # Refrescar nombres desde los leases DHCP (el nombre
        # autoritativo). Esto cubre equipos que renovaron su lease
        # (con un hostname nuevo) pero que en este momento no figuran
        # en el ARP -- así "Escanear Red" sí actualiza el nombre.
        #

        for lease in leases:

            if not lease.hostname:

                continue

            leased_device = self.repository.find_by_mac(
                db,
                lease.mac
            )

            if leased_device is None:

                continue

            if leased_device.hostname != lease.hostname:

                leased_device.hostname = lease.hostname

                leased_device.device_type = self.classifier.classify(
                    lease.hostname
                )

                self.repository.update(db, leased_device)


        return saved_devices


    def _mark_all_devices_offline(
        self,
        db: Session
    ):

        for device in self.repository.find_all(db):

            if device.status == "ONLINE":

                device.status = "OFFLINE"

                self.repository.update(db, device)