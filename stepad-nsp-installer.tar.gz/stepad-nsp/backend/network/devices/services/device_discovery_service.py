import ipaddress

from datetime import datetime

from sqlalchemy.orm import Session

from backend.dns.logging.models.dns_query_log import (
    DnsQueryLog
)

from backend.infrastructure.network.adapters.linux.arp_provider import (
    ARPProvider
)

from backend.infrastructure.network.services.hostname_resolver import (
    HostnameResolver
)

from backend.dhcp.services.dhcp_lease_service import (
    DhcpLeaseService
)

from backend.network.configuration.services.network_configuration_service import (
    NetworkConfigurationService
)

from backend.network.devices.models.network_device import (
    NetworkDevice
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.network.devices.services.device_classifier import (
    DeviceClassifier
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.groups.services.group_service import (
    GroupService
)

from backend.shared.logging.logger import logger


class DeviceDiscoveryService:


    def __init__(self):

        self.provider = ARPProvider()

        self.lease_service = DhcpLeaseService()

        self.hostname_resolver = HostnameResolver()

        self.network_configuration = NetworkConfigurationService()

        self.repository = DeviceRepository()

        self.classifier = DeviceClassifier()

        self.zone_repository = NetworkZoneRepository()

    def synchronize(
        self,
        db: Session
    ):


        network = self.network_configuration.get_lan_configuration()


        if network is None:

            # No LAN interface exists right now (e.g. mid-setup on
            # new hardware, nothing assigned yet) -- by definition
            # nothing can actually be online. Without this, the
            # function used to just `return []` here, which skipped
            # the "mark missing devices offline" pass below entirely
            # -- any device previously seen stayed stuck at
            # status=ONLINE forever, even with no LAN at all to have
            # seen it on.
            self._mark_all_devices_offline(db)

            return []



        interface = network["interface"]



        devices = self.provider.list_devices(
            interface
        )



        # Only neighbors actually inside one of the configured LAN
        # networks are part of the protected network. ARP on a LAN
        # interface normally can't return anything else, but an
        # interface that was (mis)assigned LAN before the admin
        # sorted out the interface registry leaves stale neighbors
        # in the table -- exactly how foreign hosts (e.g.
        # 192.168.100.x from the WAN card) once got persisted as
        # "devices". Filtering here is what stops that from ever
        # happening again.
        lan_networks = [
            ipaddress.ip_network(net["network"])
            for net in self.network_configuration.get_lan_configurations()
            if net.get("network")
        ]

        if lan_networks:

            devices = [
                device
                for device in devices
                if any(
                    ipaddress.ip_address(device.ip_address) in lan_network
                    for lan_network in lan_networks
                )
            ]



        found_macs = {

            device.mac_address.lower()

            for device in devices

        }



        leases = self.lease_service.list_leases()



        leases_by_mac = {

            lease.mac.lower(): lease

            for lease in leases

            if lease.mac

        }



        saved_devices = []

        default_zone = self.zone_repository.find_default(db)

        for device in devices:


            lease = leases_by_mac.get(
                device.mac_address.lower()
            )


            if lease:

                device.hostname = lease.hostname

                device.device_type = self.classifier.classify(

                device.hostname

)

            existing = self.repository.find_by_mac(
                db,
                device.mac_address
            )



            if existing:


                existing.ip_address = device.ip_address

                existing.hostname = device.hostname

                existing.vendor = device.vendor

                existing.interface = device.interface

                existing.status = "ONLINE"

                existing.device_type = device.device_type

                existing.last_seen = datetime.utcnow()



                self.repository.update(
                    db,
                    existing
                )


                saved_devices.append(existing)



            else:


                model = NetworkDevice(

                    ip_address=device.ip_address,

                    mac_address=device.mac_address,

                    hostname=device.hostname,

                    vendor=device.vendor,

                    interface=device.interface,

                    status="ONLINE",

                    device_type=device.device_type,

                    zone_id=default_zone.id if default_zone else None,

                    first_seen=datetime.utcnow(),

                    last_seen=datetime.utcnow()

                )



                saved = self.repository.save(
                    db,
                    model
                )

                # New/unrecognized device lands in the default group
                # (Invitados) automatically; the admin moves it to its
                # department later.
                try:

                    group_service = GroupService()

                    default_group = group_service.ensure_default_group(db)

                    group_service.repository.add_device(
                        db,
                        default_group.id,
                        saved.id
                    )

                except Exception as error:

                    logger.warning(
                        f"Auto-assign to default group failed: {error}"
                    )

                saved_devices.append(saved)



        #
        # Marcar dispositivos desaparecidos como OFFLINE
        #

        existing_devices = self.repository.find_all_by_interface(
            db,
            interface
        )



        for existing in existing_devices:


            if existing.mac_address.lower() not in found_macs:


                existing.status = "OFFLINE"



                self.repository.update(
                    db,
                    existing
                )



        #
        # Purgar dispositivos fuera de las redes LAN
        #

        self._purge_external_devices(
            db,
            lan_networks
        )


        #
        # Refrescar nombres desde los leases DHCP (el nombre
        # autoritativo). Esto cubre equipos que renovaron su lease
        # (con un hostname nuevo) pero que en este momento no figuran
        # en el ARP -- así "Escanear Red" sí actualiza el nombre.
        #

        for lease in leases:

            if not lease.hostname:

                continue

            leased_device = self.repository.find_by_mac(
                db,
                lease.mac
            )

            if leased_device is None:

                continue

            if leased_device.hostname != lease.hostname:

                leased_device.hostname = lease.hostname

                leased_device.device_type = self.classifier.classify(
                    lease.hostname
                )

                self.repository.update(db, leased_device)


        return saved_devices


    def _purge_external_devices(
        self,
        db: Session,
        lan_networks
    ):
        """
        Deletes devices that ended up recorded with an IP outside every
        configured LAN network -- hosts discovered through a card that
        has since been reassigned WAN. They are not part of the
        protected network and must never appear in the device list.
        References in dns_query_logs are cleared first (the FK has no
        ON DELETE rule).
        """

        if not lan_networks:

            return

        for device in self.repository.find_all(db):

            if not device.ip_address:

                continue

            if any(
                ipaddress.ip_address(device.ip_address) in lan_network
                for lan_network in lan_networks
            ):

                continue

            db.query(DnsQueryLog).filter(
                DnsQueryLog.device_id == device.id
            ).update(
                {"device_id": None}
            )

            self.repository.delete(db, device)


    def _mark_all_devices_offline(
        self,
        db: Session
    ):

        for device in self.repository.find_all(db):

            if device.status == "ONLINE":

                device.status = "OFFLINE"

                self.repository.update(db, device)