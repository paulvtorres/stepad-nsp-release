from backend.network.devices.services.ip_history_service import (
    IpHistoryService,
)


class IpOwnershipService:
    """Registra la IP de un equipo SIN decidir quien tiene la razon.

    Antes quitaba la IP al dueño anterior y lo marcaba OFFLINE: con dos
    equipos reales en la misma IP el ultimo escritor ganaba y el listado
    ocultaba justo el conflicto. Ahora solo se guarda la IP (y su historial
    si cambia). Quien esta realmente conectado y si hay conflicto lo decide
    `DevicePresenceService`, el unico dueño de `current_ip`, `status` e
    `ip_conflict`.
    """

    def set_ip(self, db, device, ip, source="sync"):

        ip = (ip or "").strip()

        if not ip:

            # "Sin IP" no existe como dato de entrada: la ultima IP conocida
            # se conserva y la presencia dice si esta o no conectado.
            return device

        if getattr(device, "id", None) is None:

            db.add(device)

            db.flush()

        previous = getattr(device, "ip_address", "") or ""

        if previous and previous != ip:

            IpHistoryService().record_closed(db, device, previous, source)

        device.ip_address = ip

        device.last_ip = ip

        db.add(device)

        db.flush()

        return device
