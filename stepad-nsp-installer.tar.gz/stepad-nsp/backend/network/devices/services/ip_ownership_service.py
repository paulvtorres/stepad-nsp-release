from backend.network.devices.services.ip_history_service import (
    IpHistoryService,
)
from backend.network.devices.models.network_device import NetworkDevice


class IpOwnershipService:
    """Mantiene una sola IP activa por dirección.

    Limpia primero al dueño anterior y recién después asigna la IP nueva,
    para que el índice único parcial nunca vea dos dueños a la vez.
    """

    def set_ip(self, db, device, ip, source="sync"):

        ip = (ip or "").strip()

        history = IpHistoryService()

        if not ip:

            if getattr(device, "ip_address", ""):

                history.record_closed(
                    db,
                    device,
                    device.ip_address,
                    source,
                )

                device.ip_address = ""

                db.add(device)

            return device

        if getattr(device, "id", None) is None:

            db.add(device)

            db.flush()

        others = (
            db.query(NetworkDevice)
            .filter(
                NetworkDevice.ip_address == ip,
                NetworkDevice.id != device.id,
            )
            .all()
        )

        for other in others:

            history.record_closed(db, other, ip, source)

            other.ip_address = ""

            if other.status == "ONLINE":

                other.status = "OFFLINE"

            db.add(other)

        if others:

            db.flush()

        if device.ip_address != ip:

            if getattr(device, "ip_address", ""):

                history.record_closed(
                    db,
                    device,
                    device.ip_address,
                    source,
                )

            device.ip_address = ip

            db.add(device)

        db.flush()

        return device
