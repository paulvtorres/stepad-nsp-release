class DeviceClassifier:


    # Tipos que NO son equipos de usuario: no pueden pertenecer a
    # grupos y quedan ocultos de la lista por defecto.
    INFRASTRUCTURE_TYPES = frozenset(
        {"PRINTER", "ROUTER", "IP_PHONE"}
    )


    @staticmethod
    def is_infrastructure(
        device_type: str | None
    ) -> bool:

        return (
            device_type
            in DeviceClassifier.INFRASTRUCTURE_TYPES
        )


    def classify(
        self,
        hostname: str | None
    ) -> str:


        if not hostname:
            return "UNKNOWN"


        name = hostname.lower()


        mobile_keywords = [

            "iphone",
            "ipad",
            "android",
            "realme",
            "xiaomi",
            "redmi",
            "samsung",
            "galaxy",
            "motorola",
            "moto",
            "oppo",
            "vivo"

        ]


        computer_keywords = [

            "pc",
            "desktop",
            "laptop",
            "macbook",
            "imac",
            "ubuntu",
            "windows"

        ]


        printer_keywords = [

            "printer",
            "epson",
            "hp",
            "canon",
            "brother",
            "scanner",
            "mfp",
            "laserjet",
            "deskjet"

        ]


        phone_keywords = [

            "yealink",
            "polycom",
            "grandstream",
            "gxp",
            "fanvil",
            "gigaset",
            "snom",
            "avaya",
            "panasonic",
            "obihai",
            "cisco-spa",
            "cisco-cp",
            "sep",
            "sip",
            "voip",
            "ip-phone",
            "ipphone"

        ]


        router_keywords = [

            "router",
            "mikrotik",
            "tplink",
            "tp-link",
            "ubiquiti",
            "cisco",
            "openwrt",
            "access-point",
            "ap"

        ]



        for keyword in mobile_keywords:

            if keyword in name:
                return "MOBILE"



        for keyword in computer_keywords:

            if keyword in name:
                return "COMPUTER"



        for keyword in printer_keywords:

            if keyword in name:
                return "PRINTER"



        for keyword in phone_keywords:

            if keyword in name:
                return "IP_PHONE"



        for keyword in router_keywords:

            if keyword in name:
                return "ROUTER"



        return "UNKNOWN"