class DeviceClassifier:


    # Tipos que NO son equipos de usuario: no pueden pertenecer a
    # grupos y quedan ocultos de la lista por defecto.
    INFRASTRUCTURE_TYPES = frozenset(
        {"PRINTER", "ROUTER", "IP_PHONE"}
    )

    # Prefijos OUI (primeros 3 octetos en minusculas) de fabricantes de
    # telefonia IP, para clasificar por MAC cuando el equipo no declara
    # nombre (muchos telefonos no responden a netbios/mDNS/LLMNR).
    PHONE_OUI = frozenset({
        # Grandstream
        "00:0b:82", "00:0d:0b", "00:1d:0d",
        # Yealink
        "00:15:65", "3c:64:d9", "1c:b7:2c", "74:64:a6", "f8:a7:63",
        # Cisco / Linksys (SPA, CP, PAP2)
        "00:0e:08", "00:1b:0c", "64:16:66", "9c:34:26", "00:0f:66",
        # Polycom
        "00:04:f2", "00:e0:db", "24:c9:a1", "00:0f:20",
        # Snom
        "00:04:13",
        # Avaya
        "00:04:0d", "00:1b:9f",
        # Fanvil
        "28:f9:da",
        # Obihai
        "9c:93:4e", "d0:9c:6b",
        # Gigaset
        "00:25:ca", "00:24:2c",
        # Panasonic
        "00:80:f0", "00:07:05",
        # Audiocodes
        "00:0e:5f",
    })

    # Prefijos OUI de impresoras comunes (por si el nombre no se resuelve).
    PRINTER_OUI = frozenset({
        "00:1f:45",  # HP (algunos)
        "00:23:7d",  # Ricoh
        "00:21:b7",  # Brother
        "00:00:48",  # Xerox
    })

    # Prefijos OUI de routers/AP/mesh (TP-Link, Ubiquiti, Mikrotik...).
    ROUTER_OUI = frozenset({
        "50:c7:bf",  # TP-Link
        "f4:f2:6d",  # TP-Link
        "6c:9c:ed",  # TP-Link
        "98:da:c4",  # TP-Link
        "04:d9:f5",  # Ubiquiti
        "24:a4:3c",  # Ubiquiti
        "dc:9f:db",  # Mikrotik
        "48:8f:5a",  # Mikrotik
        "10:27:f5",  # Mikrotik
    })

    # Prefijos OUI de fabricantes de PC/computadores (fallback por MAC
    # cuando no se resuelve el nombre).
    COMPUTER_OUI = frozenset({
        "3c:d9:2b",  # HP
        "b4:2e:99",  # HP
        "9c:b6:54",  # HP
        "d8:cb:8a",  # HP
        "f8:75:a4",  # Dell
        "00:14:22",  # Dell
        "18:66:da",  # Dell
        "b8:ae:ed",  # Dell
        "34:17:eb",  # Lenovo
        "54:ee:75",  # Lenovo
        "3c:a6:f6",  # Lenovo
        "20:cf:30",  # Acer
        "54:04:a6",  # Acer
        "00:1b:fc",  # ASUSTek
        "bc:ae:c5",  # ASUSTek
        "4c:cc:6a",  # ASUSTek
        "00:1e:8f",  # ASUSTek
        "f0:18:98",  # ASUSTek
        "5c:f9:38",  # Toshiba
        "04:92:26",  # Toshiba
    })

    # Prefijos OUI de camaras IP (Hikvision, Dahua, Axis, Uniview...).
    CAMERA_OUI = frozenset({
        "7c:8b:ca",  # Hikvision
        "28:57:be",  # Hikvision
        "c4:2f:90",  # Hikvision
        "3c:ef:8c",  # Dahua
        "e0:50:8b",  # Dahua
        "9c:8e:cd",  # Dahua
        "00:40:8c",  # Axis
        "ac:cc:8e",  # Axis
        "84:2e:14",  # Uniview
    })


    @staticmethod
    def is_infrastructure(
        device_type: str | None
    ) -> bool:

        return (
            device_type
            in DeviceClassifier.INFRASTRUCTURE_TYPES
        )


    @staticmethod
    def classify_by_mac(
        mac: str | None
    ) -> str:
        """
        Clasifica por fabricante (primeros 3 octetos de la MAC) cuando
        el equipo no declara hostname. Muchos telefonos IP, impresoras
        y routers no responden a netbios/mDNS/LLMNR, asi que el nombre
        nunca llega a resolverlos.
        """

        if not mac:

            return "UNKNOWN"

        oui = mac.strip().lower()[:8]

        if oui in DeviceClassifier.PHONE_OUI:

            return "IP_PHONE"

        if oui in DeviceClassifier.PRINTER_OUI:

            return "PRINTER"

        if oui in DeviceClassifier.ROUTER_OUI:

            return "ROUTER"

        if oui in DeviceClassifier.COMPUTER_OUI:

            return "COMPUTER"

        if oui in DeviceClassifier.CAMERA_OUI:

            return "CAMERA"

        return "UNKNOWN"


    def classify(
        self,
        hostname: str | None
    ) -> str:


        if not hostname:
            return "UNKNOWN"


        name = hostname.lower()


        mobile_keywords = [

            "iphone",
            "ipad",
            "android",
            "realme",
            "xiaomi",
            "redmi",
            "samsung",
            "galaxy",
            "motorola",
            "moto",
            "oppo",
            "vivo",
            "tecno",
            "spark",
            "infinix",
            "itel",
            "honor",
            "huawei",
            "oneplus",
            "nokia",
            "zte",
            "lg",

        ]


        computer_keywords = [

            "pc",
            "desktop",
            "laptop",
            "macbook",
            "imac",
            "ubuntu",
            "windows",
            "server",
            # Nombres de equipos por departamento/negocio (muy comunes
            # en oficinas: el hostname no es "DESKTOP-*").
            "gerencia",
            "comercial",
            "contabilidad",
            "rrhh",
            "rh-",
            "recepcion",
            "ventas",
            "sistemas",
            "pizzeria",
            "administracion",
            "bodega",
            "tienda",
            "caja",
            "oficina",
            "secretaria",
            "gerente",
            "auditoria",
            "logistica",
            "pagos",
            "cobros",
            "tesoreria",
            "financiero",
            "coys",

        ]


        printer_keywords = [

            "printer",
            "epson",
            "hp",
            "canon",
            "brother",
            "scanner",
            "mfp",
            "laserjet",
            "deskjet"

        ]


        phone_keywords = [

            "yealink",
            "polycom",
            "grandstream",
            "gxp",
            "gxv",
            "grp",
            "ht8",
            "fanvil",
            "gigaset",
            "snom",
            "avaya",
            "panasonic",
            "obihai",
            "cisco-spa",
            "cisco-cp",
            "sep",
            "sip",
            "voip",
            "ip-phone",
            "ipphone",
            "audiocodes",
            "alcatel"

        ]


        router_keywords = [

            "router",
            "mikrotik",
            "tplink",
            "tp-link",
            "ubiquiti",
            "cisco",
            "openwrt",
            "access-point",
            "deco"

        ]


        camera_keywords = [

            "camera",
            "ipcam",
            "hikvision",
            "dahua",
            "axis",
            "dvr",
            "nvr",
            "cam",

        ]



        for keyword in mobile_keywords:

            if keyword in name:
                return "MOBILE"



        for keyword in camera_keywords:

            if keyword in name:
                return "CAMERA"



        for keyword in computer_keywords:

            if keyword in name:
                return "COMPUTER"



        for keyword in printer_keywords:

            if keyword in name:
                return "PRINTER"



        for keyword in phone_keywords:

            if keyword in name:
                return "IP_PHONE"



        for keyword in router_keywords:

            if keyword in name:
                return "ROUTER"



        return "OTRO"