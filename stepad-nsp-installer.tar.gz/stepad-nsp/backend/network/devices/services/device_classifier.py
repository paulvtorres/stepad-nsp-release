class DeviceClassifier:


    def classify(
        self,
        hostname: str | None
    ) -> str:


        if not hostname:
            return "UNKNOWN"


        name = hostname.lower()


        mobile_keywords = [

            "iphone",
            "ipad",
            "android",
            "realme",
            "xiaomi",
            "redmi",
            "samsung",
            "galaxy",
            "motorola",
            "moto",
            "oppo",
            "vivo"

        ]


        computer_keywords = [

            "pc",
            "desktop",
            "laptop",
            "macbook",
            "imac",
            "ubuntu",
            "windows"

        ]


        printer_keywords = [

            "printer",
            "epson",
            "hp",
            "canon",
            "brother"

        ]



        router_keywords = [

            "router",
            "mikrotik",
            "tplink",
            "tp-link",
            "ubiquiti",
            "cisco"

        ]



        for keyword in mobile_keywords:

            if keyword in name:
                return "MOBILE"



        for keyword in computer_keywords:

            if keyword in name:
                return "COMPUTER"



        for keyword in printer_keywords:

            if keyword in name:
                return "PRINTER"



        for keyword in router_keywords:

            if keyword in name:
                return "ROUTER"



        return "UNKNOWN"