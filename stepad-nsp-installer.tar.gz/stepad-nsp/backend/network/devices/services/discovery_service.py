import psutil

class DiscoveryService:

    def get_devices(self):
        interfaces = psutil.net_if_addrs()
        return [
            {
                "id": i,
                "hostname": name,
                "ip": "system",
                "vendor": "local",
                "status": "online",
            }
            for i, name in enumerate(interfaces.keys(), 1)
        ]