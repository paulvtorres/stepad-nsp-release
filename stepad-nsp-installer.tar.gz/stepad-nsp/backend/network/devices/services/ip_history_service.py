from backend.network.devices.models.device_ip_history import (
    DeviceIpHistory,
)
from backend.shared.datetime_utils import utcnow


class IpHistoryService:

    def record_closed(self, db, device, ip, source="reconcile"):
        """Guarda una IP que dejó de pertenecer a un equipo."""

        ip = (ip or "").strip()

        if not ip:
            return None

        row = DeviceIpHistory(
            device_id=device.id,
            mac_address=(device.mac_address or "").lower() or None,
            ip_address=ip,
            source=source,
            started_at=device.last_seen or utcnow(),
            ended_at=utcnow(),
        )

        db.add(row)

        return row
