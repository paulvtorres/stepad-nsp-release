from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.network.interfaces.services.interface_service import InterfaceService
from backend.network.configuration.services.interface_configuration_service import (
    InterfaceConfigurationService,
)

from backend.shared.logging.logger import logger


class NetworkComponent(BaseComponent):

    name = "network"
    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.interface_service = InterfaceService()
        self.configuration_service = InterfaceConfigurationService()


    def start(self):

        logger.info("NetworkComponent started.")
        logger.info("")

        self._configure_interfaces()

        #
        # Próximos servicios de red
        #
        # self._start_dhcp()
        # self._start_dns()
        # self._enable_ip_forwarding()
        # self._configure_nat()
        # self._start_firewall()

        logger.info("")
        logger.info("Detected Interfaces")
        logger.info("------------------------------")

        self._log_interfaces()


    def stop(self):

        logger.info("NetworkComponent stopped.")


    def _configure_interfaces(self):

        result = self.configuration_service.configure_lan_default()

        if result["success"]:

            logger.info("LAN configured")

            logger.info(
                f"Interface : {result['interface']}"
            )

            logger.info(
                f"Address   : {result['address']}"
            )

            provider = result.get(
                "provider_result",
                {}
            )

            message = provider.get("message")

            if message:

                logger.info(
                    f"Result    : {message}"
                )

        else:

            logger.error(
                result["message"]
            )


    def _log_interfaces(self):

        interfaces = self.interface_service.list_interfaces()

        for interface in interfaces:

            logger.info(
                f"Name   : {interface.name}"
            )

            logger.info(
                f"Role   : {interface.role}"
            )

            logger.info(
                f"Status : {interface.status}"
            )

            logger.info(
                f"MAC    : {interface.mac}"
            )

            logger.info("")