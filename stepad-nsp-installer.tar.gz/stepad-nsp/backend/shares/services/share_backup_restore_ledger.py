"""Bitacora persistente de restauraciones (restore_state.json).

Solo E/S y utilidades puras: lectura tolerante, escritura atomica 0600,
upsert por job y chequeo de proceso vivo. La reconciliacion con el
estado en memoria vive en el servicio. Extraido sin cambiar conducta.
"""

import json
import os

from pathlib import Path

from backend.shared.logging.logger import logger


def empty() -> dict:

    return {"schema": 1, "restores": {}}


def load(path: Path) -> dict:

    try:

        if not path.is_file():

            return empty()

        data = json.loads(path.read_text("utf-8"))

    except Exception as error:

        logger.debug("share_backup_restore_ledger.load: %s", error)

        return empty()

    if not isinstance(data, dict):

        return empty()

    data.setdefault("schema", 1)

    data.setdefault("restores", {})

    return data


def save(path: Path, ledger: dict) -> None:

    try:

        path.parent.mkdir(parents=True, exist_ok=True)

        tmp = path.with_suffix(".tmp")

        tmp.write_text(
            json.dumps(ledger, ensure_ascii=False, indent=2),
            "utf-8",
        )

        os.replace(tmp, path)

        try:

            os.chmod(path, 0o600)

        except OSError:

            pass

    except Exception as error:

        logger.warning(
            "No se pudo escribir la bitácora de restauración: %s", error
        )


def upsert(path: Path, job_id: int, updated_at: str, **fields) -> dict:

    ledger = load(path)

    entry = ledger["restores"].get(str(job_id)) or {"job_id": int(job_id)}

    entry.update(fields)

    entry["updated_at"] = updated_at

    ledger["restores"][str(job_id)] = entry

    save(path, ledger)

    return ledger


def process_alive(pid) -> bool:

    try:

        os.kill(int(pid), 0)

        return True

    except (OSError, ValueError, TypeError):

        return False
