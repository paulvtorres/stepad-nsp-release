"""Restore helpers for share backups.

Extracted from `share_backup_service` (monolith): restic restore-size
parsing and locating the restored root inside the staging directory.
"""

import re

from pathlib import Path

from backend.shared.logging.logger import logger

_SIZE_MULTIPLIERS = {
    "TIB": 1024**4, "TI": 1024**4, "TB": 10**12,
    "GIB": 1024**3, "GI": 1024**3, "GB": 10**9,
    "MIB": 1024**2, "MI": 1024**2, "MB": 10**6,
    "KIB": 1024, "KI": 1024, "KB": 10**3,
    "B": 1,
}


def parse_restore_size(text: str) -> int | None:

    """Bytes from `restic stats --mode restore-size` output."""

    match = re.search(
        r"Total Size:\s*([\d.]+)\s*([TGMK]?i?B)", text or ""
    )

    if not match:

        return None

    value = float(match.group(1))

    unit = match.group(2).upper()

    return int(value * _SIZE_MULTIPLIERS.get(unit, 1024**3))


def find_restored_root(staging: Path, source: str) -> Path | None:

    """Real content root inside `staging` (restic keeps absolute paths).

    Looks for the folder matching the original `source`; otherwise returns
    the only inner directory that actually contains files."""

    if not staging.exists():

        return None

    try:

        wanted = str(Path(source)).rstrip("/").lstrip("/")

        parts = [part for part in wanted.split("/") if part]

    except (OSError, ValueError, TypeError) as error:

        logger.debug("share_backup_restore.find_restored_root: %s", error)

        parts = []

    current = staging

    for part in parts:

        candidate = current / part

        if not candidate.exists():

            break

        current = candidate

    if current != staging and current.exists():

        return current

    try:

        inner = [child for child in staging.iterdir() if child.is_dir()]

        if len(inner) == 1:

            single = inner[0]

            if any(item.is_file() for item in single.iterdir()):

                return single

    except (OSError, ValueError, TypeError) as error:

        logger.debug("share_backup_restore.find_restored_root: %s", error)

    return None
