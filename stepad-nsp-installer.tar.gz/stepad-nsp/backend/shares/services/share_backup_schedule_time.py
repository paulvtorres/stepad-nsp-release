"""Pure scheduling logic for share backups.

Extracted from `share_backup_service` (monolith) without behavior changes.
All functions take the job mapping (dict-like), the current time and the
tuning constants, so they are easy to test.
"""

from datetime import datetime

from backend.shared.logging.logger import logger


def times_list(job) -> list:

    """HH:MM times of a job (schedule_times or the classic hour:minute)."""

    times = []

    for part in (job.get("schedule_times") or "").split(","):

        part = part.strip()

        if part:

            times.append(part)

    if not times:

        times = [
            f"{int(job.get('schedule_hour') or 0):02d}:"
            f"{int(job.get('schedule_minute') or 0):02d}"
        ]

    return times


def parse_job_time(value) -> datetime | None:

    if not value:

        return None

    try:

        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))

        if parsed.tzinfo is not None:

            parsed = parsed.replace(tzinfo=None)

        return parsed

    except Exception as error:

        logger.debug("share_backup_schedule_time.parse_job_time: %s", error)

        return None


def backoff_minutes(consecutive_failures: int, table: list) -> int:

    if consecutive_failures <= 0:

        return 0

    index = min(consecutive_failures - 1, len(table) - 1)

    return table[index]


def backoff_elapsed(job, now: datetime, table: list) -> bool:

    """True when enough time passed since the last failed attempt."""

    failures = int(job.get("consecutive_failures") or 0)

    if failures <= 0:

        return True

    last_attempt = parse_job_time(job.get("last_attempt_at"))

    if last_attempt is None:

        return True

    cooldown_minutes = backoff_minutes(failures, table)

    return (now - last_attempt).total_seconds() >= cooldown_minutes * 60


def is_due(
    job,
    now: datetime,
    tolerance_minutes: int,
    backoff_table: list,
) -> bool:

    if not job.get("enabled"):

        return False

    skip_until = job.get("skip_until")

    if skip_until:

        try:

            if now < datetime.fromisoformat(skip_until):

                return False

        except (TypeError, ValueError):

            pass

    if not backoff_elapsed(job, now, backoff_table):

        return False

    if job.get("schedule_mode") == "interval":

        last = parse_job_time(job.get("last_backup_at"))

        if last is None:

            return True

        interval = max(1, int(job.get("interval_minutes") or 60))

        elapsed = (now - last).total_seconds()

        return elapsed >= interval * 60

    if job.get("schedule_mode") == "on_change":

        return False

    times = times_list(job)

    minute_of_day = now.hour * 60 + now.minute

    last = parse_job_time(job.get("last_backup_at"))

    reached = None

    for raw in times:

        try:

            hh, mm = (int(x) for x in raw.split(":"))

        except Exception as error:

            logger.debug("share_backup_schedule_time.is_due: %s", error)

            continue

        slot = hh * 60 + mm

        if slot <= minute_of_day:

            reached = slot if reached is None else max(reached, slot)

    if reached is None:

        return False

    if last is None:

        for raw in times:

            try:

                hh, mm = (int(x) for x in raw.split(":"))

            except Exception as error:

                logger.debug("share_backup_schedule_time.is_due: %s", error)

                continue

            if hh * 60 + mm == minute_of_day:

                return True

        return False

    if minute_of_day - reached > tolerance_minutes:

        return False

    if last.date() == now.date():

        last_min = last.hour * 60 + last.minute

        if last_min >= reached:

            return False

    return True
