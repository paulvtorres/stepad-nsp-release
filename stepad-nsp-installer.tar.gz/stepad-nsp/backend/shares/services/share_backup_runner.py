"""Backup execution: launching, running and finishing a backup job.

Extracted from `share_backup_service` as a mixin (the methods use the
service state and helpers via `self`). No behavior changes.
"""

from __future__ import annotations

import json
import subprocess
import threading
import time

from pathlib import Path
from typing import TYPE_CHECKING

from fastapi import HTTPException

from backend.core.database.session import SessionLocal
from backend.shares.models.network_share_volume import NetworkShareVolume

from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import now_ecuador
from backend.shares.services import share_backup_restic as restic_runner
from backend.shares.services import share_backup_run_state as run_state
from backend.shares.services import net_rate_shaper
from backend.shares.services.share_backup_disk import human_bytes as _human_bytes

if TYPE_CHECKING:
    from backend.shares.services.share_backup_service import Job

BACKUP_STALL_SECONDS = 1800


class BackupRunnerMixin:

    def run_backup_job(self, job: Job, *, trigger: str = "manual") -> dict:
        """Igual que run_backup pero sobre un job YA resuelto (con su bóveda).

        El scheduler la usa para ejecutar EXACTAMENTE el job cuyo is_due()
        evaluó: re-resolver por id con _find_job() podría devolver un job
        distinto con el mismo id en otra bóveda (ids por-bóveda)."""
        started_at = time.monotonic()

        # Retomar tras un corte: restic es tolerante a interrupciones — si la
        # corrida anterior se cortó (corte de red, reinicio del servicio,
        # timeout), los datos ya subidos quedan en el repo y restic continúa
        # desde donde quedó (no vuelve a subir lo subido). Aquí se detecta e
        # informa, y si el repo queda sospechoso se hace `restic check`
        # (sin bloquear la corrida) para detectar daño.
        prev_ok = job.get("last_result") or ""
        prev_failed = not (
            prev_ok.startswith("Sin cambios") or prev_ok.startswith("Respaldo ejecutado") or prev_ok.startswith("Éxito")
            or prev_ok.startswith("OK") or ("restaurado" in prev_ok) or (prev_ok == "")
        )
        if prev_failed:
            logger.info(
                "Respaldo '%s' (%s): la corrida anterior quedó interrumpida "
                "(%s). restic retomará desde donde quedó (no re-subirá lo ya "
                "subido).",
                job.get("name"), trigger, prev_ok[:80] or "sin registro",
            )

        # Omitir si nada cambió desde el último respaldo real: así un horario o
        # un «Ejecutar ahora» sin modificaciones no crea versiones vacías.
        source = Path(job.get("source_path") or "")
        baseline = job.get("tree_hash")
        # OJO (v2.5.283): para orígenes de red YA NO se omite comparando el
        # ID del último snapshot del repo contra el baseline "snap:<id>".
        # Ese approach era INCORRECTO: detectó que "el último snapshot NO ha
        # cambiado" (siempre es el mismo dd46de72) y por eso ignoraba cambios
        # FUTUROS en M (el respaldo decía "sin cambios" aunque hubieras
        # modificado archivos). Ahora el respaldo de red SIEMPRE corre
        # `restic backup --json`: restic escanea el árbol por stat (rápido en
        # red, sin leer contenido) y emite summary con bytes_added. Si dio
        # +0 bytes, el bloque posterior (bytes_added == 0) marca el nuevo
        # baseline snap:<id>; si hubo cambios, crea la versión y actualiza.
        # Así se versionan SÍ los cambios, sin crear versiones vacías por
        # cada horario.
        if self._dir_live(source) and baseline:
            current = self._tree_signature(source)
            if current and current == baseline:
                detail = "Sin cambios desde el último respaldo. No se creó versión."
                dur = time.monotonic() - started_at
                logger.info(
                    "Respaldo '%s' (%s): no se hizo nada por no haber cambios; "
                    "demoró %.1f s. No se creó versión.",
                    job.get("name"),
                    trigger,
                    dur,
                )
                self._finish_run(
                    job,
                    success=True,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                )
                return {
                    "success": True,
                    "skipped": True,
                    "message": detail,
                    "bytes_added": 0,
                    "bytes_added_human": "0 B",
                }

        return self._launch_run_thread(
            job,
            started_at=started_at,
            trigger=trigger,
        )

    def _launch_run_thread(
        self,
        job: Job,
        *,
        started_at: float,
        trigger: str,
    ) -> dict:
        """Lanza el respaldo en segundo plano y vuelve al toque.

        El respaldo puede tardar mucho (especialmente desde un share de red):
        bloqueando la petición el usuario ve «Ejecutando respaldo…» para
        siempre. En su lugar se devuelve enseguida y el progreso/estado se
        consulta por el endpoint de progress y el listado de jobs."""
        worker = threading.Thread(
            target=self._run_backup_in_thread,
            args=(job,),
            kwargs={"started_at": started_at, "trigger": trigger},
            name=f"share-backup-{job.get('id')}",
            daemon=True,
        )
        worker.start()
        return {
            "success": True,
            "running": True,
            "message": "Respaldo en curso…",
            "job_id": job.get("id"),
        }

    def _backup_volume_for_path(
        self,
        vault: Path | str | None,
    ):
        """
        Si la bóveda de destino vive dentro de una partición registrada
        con rol "backup", devuelve el NetworkShareVolume. Los roles
        "shared" / "private" no aplican aquí (los primeros quedan
        siempre montados; las privadas las gestiona la web).
        """
        if not vault:
            return None
        try:
            vault_str = str(vault).strip()
            db = SessionLocal()
            try:
                for volume in db.query(NetworkShareVolume).all():
                    purpose = getattr(volume, "purpose", "shared") or "shared"
                    if purpose != "backup":
                        continue
                    mp = str(volume.mountpoint or "").rstrip("/")
                    if mp and vault_str.startswith(mp + "/"):
                        return volume
                return None
            finally:
                db.close()
        except Exception as error:
            logger.warning("_backup_volume_for_path: %s", error)
            return None

    def _mount_backup_dest(self, job: Job) -> dict | None:
        """
        Monta por demanda la partición "backup" que contiene la bóveda
        destino de este job. Devuelve {"volume": name, "mounted_now": bool}
        o None si no aplica (no es backup).
        """
        vault = job.vault or self._dest_folder(job.get("source_path") or "")
        volume = self._backup_volume_for_path(vault)
        if volume is None:
            return None
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        provider = ShareDiskMountProvider()
        if not provider.is_mounted_at(volume.mountpoint):
            result = provider.mount_now(
                uuid=volume.device_uuid,
                mountpoint=volume.mountpoint,
            )
            if not result.get("success"):
                raise HTTPException(
                    status_code=500,
                    detail=(
                        f"No se pudo montar la partición de respaldo "
                        f"«{volume.name}»: {result.get('message', '')}"
                    ),
                )
            return {
                "volume": volume.name,
                "mounted_now": True,
                "mountpoint": volume.mountpoint,
            }
        return {
            "volume": volume.name,
            "mounted_now": False,
            "mountpoint": volume.mountpoint,
        }

    def _unmount_backup_dest(self, job: Job) -> None:
        """Desmonta la partición "backup" destino tras el respaldo."""
        vault = job.vault or self._dest_folder(job.get("source_path") or "")
        volume = self._backup_volume_for_path(vault)
        if volume is None:
            return
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        provider = ShareDiskMountProvider()
        if provider.is_mounted_at(volume.mountpoint):
            provider.unmount_now(volume.mountpoint)

    def _run_backup_in_thread(
        self,
        job: Job,
        *,
        started_at: float,
        trigger: str,
    ) -> None:
        with self._lock:
            if not self.run_registry.begin(
                job.get("id"), now_ecuador().isoformat()
            ):
                return

        protected = job.get("schedule_mode") != "on_change"
        if protected:
            self._begin_protected_backup()

        # Cola anti-solapamiento: si otro respaldo programado/manual está
        # corriendo, éste ESPERA su turno (se encola) en vez de correr en
        # paralelo y competir por disco/red. Se libera solo.
        if protected:
            waited = 0
            while True:
                with self._lock:
                    other_running = any(
                        other != job.get("id")
                        for other in self._running_jobs
                    )
                    self_job_running = job.get("id") in self._running_jobs
                if not self_job_running:
                    # El job fue cancelado/eliminado mientras esperaba.
                    return
                if not other_running:
                    break
                if waited >= 60 * 60:
                    logger.warning(
                        "Respaldo %s esperó 60 min por otro respaldo; "
                        "arranca de todos modos.",
                        job.get("name"),
                    )
                    break
                time.sleep(5)
                waited += 5

        shaper = None
        # Limitar el ancho de banda del respaldo de red (QoS): restic lee el
        # origen a plena velocidad y satura el enlace. Best-effort: si no se
        # puede, el respaldo corre sin límite (nunca se rompe).
        if self._is_network_source(str(job.get("source_path") or "")):
            try:
                ip = self._network_source_ip(job)
                if ip:
                    iface = net_rate_shaper.interface_for(ip)
                    link = net_rate_shaper.link_speed_mbps(iface) if iface else 0
                    mbps = net_rate_shaper.effective_limit_mbps(
                        job.get("rate_limit_mbps"), link,
                    )
                    if mbps and iface:
                        shaper = net_rate_shaper.apply(iface, ip, mbps, link)
            except Exception as error:
                logger.warning("No se pudo aplicar límite de red del respaldo: %s", error)

        mounted_dest = None
        try:
            mounted_dest = self._mount_backup_dest(job)
            try:
                self._run_backup_locked(
                    job,
                    started_at=started_at,
                    trigger=trigger,
                )
            except HTTPException as error:
                self._finish_run(
                    job,
                    success=False,
                    message=error.detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
            except Exception as error:
                logger.exception(
                    "Respaldo %s falló inesperadamente: %s",
                    job.get("name"), error,
                )
                self._finish_run(
                    job,
                    success=False,
                    message=f"Error inesperado: {error}",
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
        finally:
            # La partición "backup" solo está montada durante la corrida:
            # se desmonta al terminar (éxito o fallo) para que quede
            # inaccesible al resto del tiempo (anti-ransomware).
            if mounted_dest:
                try:
                    self._unmount_backup_dest(job)
                except Exception as error:
                    logger.warning(
                        "No se pudo desmontar partición de respaldo: %s",
                        error,
                    )
            with self._lock:
                self.run_registry.finish(job.get("id"))
            if protected:
                self._end_protected_backup()
            # Quitar el límite de ancho de banda aplicado a este respaldo
            # (si se llegó a aplicar), para volver a plena velocidad.
            if shaper:
                try:
                    net_rate_shaper.remove(shaper.get("iface"), shaper.get("ip"))
                except Exception as error:
                    logger.warning("No se pudo quitar límite de red del respaldo: %s", error)

    def _run_backup_locked(self, job: Job, *, started_at: float, trigger: str) -> dict:
        if not self.installed():
            raise HTTPException(
                status_code=400,
                detail="restic no está instalado. Instala el paquete: apt-get install -y restic",
            )
        source = Path(job.get("source_path") or "")
        mounted = None

        # Mount network share if needed (only for SMB paths, not local mounts)
        if self._is_network_source(str(source)) and not str(source).startswith("/mnt/"):
            mounted = self._mount_share(job, str(source))
            if not mounted:
                detail = "No se pudo montar el share de red. Verifique credenciales y conectividad."
                self._finish_run(
                    job,
                    success=False,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
                return {"success": False, "message": detail}
            source = Path(mounted)
        elif "/stepad-network/" in str(source):
            # Unidad de red registrada (p. ej. /mnt/stepad-network/M). Se
            # ASEGURA el montaje siempre: un share puede quedar "fantasma"
            # (dir vacío sin acceso real) y restic correría contra una
            # carpeta vacía sin terminar bien el respaldo programado.
            needs_mount = not self._dir_live(source)
            if not needs_mount:
                try:
                    has_children = any(Path(source).iterdir())
                except OSError:
                    has_children = False
                if not has_children:
                    # Dir vacío: o el share no está montado de verdad o el
                    # equipo origen no lo expone. Forzamos (re)montaje.
                    needs_mount = True
            if needs_mount:
                if not self._ensure_network_unit_mounted(str(source)):
                    detail = (
                        f"La unidad de red del origen no está disponible "
                        f"({source}). Verifique que el equipo origen esté "
                        "encendido y conectado, y vuelva a intentar."
                    )
                    self._finish_run(
                        job,
                        success=False,
                        message=detail,
                        started_at=started_at,
                        trigger=trigger,
                        update_backup_time=False,
                    )
                    return {"success": False, "message": detail}
                source = Path(job.get("source_path") or "")

            # Tras montar, el origen DEBE traer datos: si sigue vacío, el
            # share no responde y un respaldo programado quedaría colgado.
            try:
                origin_empty = not any(Path(source).iterdir())
            except OSError:
                origin_empty = True
            if origin_empty:
                detail = (
                    f"El origen {source} está vacío o sin acceso al share "
                    "de red. Verifique que el equipo origen esté encendido "
                    "y vuelva a intentar."
                )
                self._finish_run(
                    job,
                    success=False,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
                return {"success": False, "message": detail}

        if not self._dir_live(source):
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        # Crear directorio del repo antes de verificar
        try:
            self._ensure_repo(job)
        except HTTPException:
            if mounted:
                self._unmount_share(job)
            raise

        # Verificar que el destino esté disponible
        repo = self._repo_path(job)
        dest_parent = repo.parent
        if not dest_parent.exists():
            detail = f"El destino del respaldo no está disponible ({dest_parent}). Verifique que el disco/USB esté conectado."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        # Verificar que se pueda escribir en el destino
        try:
            test_file = dest_parent / ".stepad_write_test"
            test_file.write_text("test")
            test_file.unlink()
        except (OSError, PermissionError) as e:
            detail = f"No se puede escribir en el destino ({dest_parent}): {e}. Verifique permisos y que el disco no esté en solo lectura."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}
        except HTTPException:
            if mounted:
                self._unmount_share(job)
            raise

        # Skip system/temp files that cause "device or resource busy"
        # on SMB mounts (hidden files, windows system files, etc.)
        args = [
            "backup",
            str(source),
            "--host", "stepad",
            "--tag", f"job:{job.get('id')}",
            "--exclude-caches",
            "--exclude", "desktop.ini",
            "--exclude", "Thumbs.db",
            "--exclude", ".DS_Store",
            "--exclude", "System Volume Information",
            "--exclude", "$RECYCLE.BIN",
            "--exclude", ".*",
            "--json",
        ]
        try:
            # 48 h de tope: un respaldo inicial grande (cientos de GB desde
            # una unidad de red lenta, decenas de miles de archivos) no debe
            # cortarse por el reloj. El respaldo corre en segundo plano y el
            # usuario puede cancelarlo con «Parar» cuando quiera.
            result = self._restic(job, args, timeout=172800, track=True, stall_timeout=BACKUP_STALL_SECONDS)
        except subprocess.TimeoutExpired:
            detail = "El respaldo tardó demasiado y se canceló."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}
        except Exception as error:
            logger.debug("share_backup_service._run_backup_locked: %s", error)
            detail = f"Error ejecutando restic: {error}"
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        if mounted:
            self._unmount_share(job)

        if job.get("id") in self._cancel_requested:
            self._cancel_requested.discard(job.get("id"))
            # La ejecución se detuvo por desactivar/pausar la programación.
            # No es una cancelación "del usuario" (nadie la cancela): es una
            # detención controlada. Lo ya respaldado se conserva y, al
            # reactivar, restic retoma sin resubir.
            detail = "Pausado (se desactivó o pausó la programación)."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            return {"success": False, "paused": True, "message": detail}

        if result.returncode not in (0, 3):
            if result.returncode == -15:
                detail = (
                    "Interrumpido: el origen no respondió (posible caída de red). "
                    "Se retomará en el próximo horario."
                )
            else:
                detail = f"restic falló: {result.stderr.strip()[:400]}"
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            return {"success": False, "message": detail}

        snapshot_id = None
        bytes_processed = 0
        bytes_added = 0
        files_new = 0
        files_changed = 0
        for line in (result.stdout or "").splitlines():
            try:
                payload = json.loads(line)
            except Exception as error:
                logger.debug("share_backup_service._run_backup_locked: %s", error)
                continue
            if payload.get("message_type") == "summary":
                snapshot_id = payload.get("snapshot_id")
                bytes_processed = int(payload.get("total_bytes_processed") or 0)
                # Mismo criterio que la lista de VERSIONES (list_snapshots):
                # 'data_added' = datos nuevos (dedup). Así el HISTORIAL y las
                # VERSIONES muestran el MISMO tamaño (antes el historial leía
                # "packed" y por eso salía 0 mientras la versión mostraba X).
                bytes_added = int(
                    payload.get("data_added")
                    or payload.get("total_bytes_added_packed")
                    or payload.get("total_bytes_added")
                    or 0
                )
                files_new = int(payload.get("files_new") or 0)
                files_changed = int(payload.get("files_changed") or 0)
            elif payload.get("message_type") == "snapshot":
                snapshot_id = payload.get("snapshot_id") or payload.get("id") or snapshot_id

        unreadable_count, unreadable_samples = restic_runner.parse_unreadable(
            result.stderr or ""
        )
        warning_text = restic_runner.unreadable_detail(
            unreadable_count, unreadable_samples
        )

        if result.returncode == 3 and not snapshot_id:
            detail = (
                "restic no pudo completar el respaldo"
                + (f": {warning_text}" if warning_text else ".")
            )
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
                unreadable_count=unreadable_count,
                unreadable_samples=unreadable_samples,
            )
            return {
                "success": False,
                "message": detail,
                "unreadable_count": unreadable_count,
            }

        fresh_hash = None
        if not self._is_network_source(str(source)):
            try:
                fresh_hash = self._tree_signature(source)
            except Exception as error:
                logger.debug("share_backup_service._run_backup_locked: %s", error)
                fresh_hash = None
        if fresh_hash is not None:
            job["tree_hash"] = fresh_hash
        elif "tree_hash" in job:
            # Keep previous baseline if any, so the early "sin cambios"
            # skip still works without rescanning.
            job.setdefault("tree_hash", job.get("tree_hash"))

        # Para orígenes de red no se puede escanear el árbol barato; se usa
        # el snapshot id como baseline. Si restic reporta +0 bytes nuevos,
        # NO hubo cambios reales: se descarta la copia vacía recién creada
        # (ver bloque siguiente) para NO generar versiones sin cambios.
        # Solo se descarta el snapshot si el árbol es IDÉNTICO al anterior
        # (sin bytes nuevos Y sin archivos nuevos ni cambiados). Si hubiera
        # archivos nuevos/cambiados, es una versión REAL aunque restic reporte
        # +0 B (los datos pudieron subirse antes / deduplicarse): en ese caso
        # se CONSERVA la versión.
        if (
            bytes_added == 0
            and files_new == 0
            and files_changed == 0
            and snapshot_id
            and self._is_network_source(str(source))
        ):
            # Los orígenes de red no se pueden omitir escaneando el árbol
            # (restic backup --json corre siempre). Pero un snapshot "+0 B"
            # significa que el árbol NO cambió: restic creó un snapshot
            # redundante. Si ya existía una copia previa, se descarta esa
            # copia vacía y NO se crea versión (solo queda el registro en la
            # bitácora). Si es la primera copia del repo se conserva.
            prev_baseline = job.get("tree_hash") or ""
            if prev_baseline.startswith("snap:"):
                prev_id = prev_baseline.split(":", 1)[1]
                dropped = False
                try:
                    drop = self._restic(job, ["forget", snapshot_id], timeout=300)
                    dropped = drop.returncode == 0
                except Exception as error:
                    logger.warning(
                        "No se pudo descartar snapshot vacío %s: %s",
                        snapshot_id, error,
                    )
                if dropped:
                    job["tree_hash"] = f"snap:{prev_id}"
                    detail = "Respaldo ejecutado correctamente: sin cambios desde el último respaldo. No se creó versión."
                    if warning_text:
                        detail += f" Aviso: {warning_text}."
                    self._finish_run(
                        job,
                        success=True,
                        message=detail,
                        started_at=started_at,
                        trigger=trigger,
                        snapshot_id=prev_id,
                        bytes_added=0,
                        unreadable_count=unreadable_count,
                        unreadable_samples=unreadable_samples,
                    )
                    self._enforce_retention_count(job)
                    return {
                        "success": True,
                        "skipped": True,
                        "message": detail,
                        "snapshot_id": prev_id,
                        "snapshot_short": prev_id[:12],
                        "bytes_processed": bytes_processed,
                        "bytes_human": _human_bytes(bytes_processed),
                        "bytes_added": 0,
                        "bytes_added_human": "0 B",
                        "pruned": False,
                        "unreadable_count": unreadable_count,
                        "unreadable_samples": unreadable_samples,
                    }
            else:
                job["tree_hash"] = f"snap:{snapshot_id}"
        elif snapshot_id and self._is_network_source(str(source)):
            # Versión real conservada (hubo archivos nuevos/cambiados aunque
            # restic reporte +0 B por deduplicación): fijar el baseline de red
            # al snapshot nuevo.
            job["tree_hash"] = f"snap:{snapshot_id}"

        job["source_missing_alerted"] = False

        detail = (
            f"OK  snapshot {snapshot_id[:12] if snapshot_id else 'n/a'} "
            f"+{_human_bytes(bytes_added)} nuevos · "
            f"{files_new} nuevos, {files_changed} modificados · "
            f"{_human_bytes(bytes_processed)} escaneados"
        )
        if warning_text:
            detail += f" · aviso: {warning_text}"
        self._finish_run(
            job,
            success=True,
            message=detail,
            started_at=started_at,
            trigger=trigger,
            snapshot_id=snapshot_id,
            bytes_added=bytes_added,
            unreadable_count=unreadable_count,
            unreadable_samples=unreadable_samples,
        )

        self._enforce_retention_count(job)
        pruned = self._maybe_prune(job)

        return {
            "success": True,
            "snapshot_id": snapshot_id,
            "snapshot_short": snapshot_id[:12] if snapshot_id else None,
            "bytes_processed": bytes_processed,
            "bytes_human": _human_bytes(bytes_processed),
            "bytes_added": bytes_added,
            "bytes_added_human": _human_bytes(bytes_added),
            "pruned": pruned,
            "unreadable_count": unreadable_count,
            "unreadable_samples": unreadable_samples,
        }

