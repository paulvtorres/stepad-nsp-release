"""Job state for share backups: lookup, persistence and global IDs.

Extracted from `share_backup_service` (monolith). It owns the job records
only; vault discovery and the on-disk config IO stay in the service and
are injected as callables. This module never touches disks or partitions.

The duplicate-id renumbering (v2.5.301 bug) lives here now: IDs are
global, and a colliding job is renumbered together with its repo folder.
"""

import os

from pathlib import Path

from backend.shared.logging.logger import logger


class BackupJobStore:

    def __init__(
        self,
        *,
        load_config,
        save_config,
        all_jobs,
        vaults,
        dir_live,
        legacy_max_id,
        backup_subdir: str,
    ):
        self._load_config = load_config
        self._save_config = save_config
        self._all_jobs = all_jobs
        self._vaults = vaults
        self._dir_live = dir_live
        self._legacy_max_id = legacy_max_id
        self._backup_subdir = backup_subdir

    def find_job(self, job_id: int, *, vault: Path | None = None):
        for job in self._all_jobs():
            if int(job.get("id")) != int(job_id):
                continue
            if vault is not None:
                job_vault = getattr(job, "vault", None)
                if job_vault is None:
                    continue
                try:
                    if Path(str(job_vault)).resolve() != Path(str(vault)).resolve():
                        continue
                except OSError:
                    continue
            return job
        return None

    def global_max_job_id(self) -> int:
        max_id = 0
        try:
            max_id = max(max_id, int(self._legacy_max_id() or 0))
        except (TypeError, ValueError) as error:
            logger.debug("share_backup_job_store.global_max_job_id: %s", error)
        for vault in self._vaults():
            try:
                config = self._load_config(vault)
            except (OSError, ValueError, TypeError, KeyError) as error:
                logger.debug("share_backup_job_store.global_max_job_id: %s", error)
                continue
            for record in config.get("jobs", []):
                try:
                    max_id = max(max_id, int(record.get("id") or 0))
                except (TypeError, ValueError):
                    pass
        return max_id

    def save_job_locked(self, job) -> None:
        config = self._load_config(job.vault)
        for index, record in enumerate(config.get("jobs", [])):
            if int(record.get("id") or 0) == int(job.get("id")):
                config["jobs"][index] = dict(job)
                break
        self._save_config(job.vault, config)

    def ensure_unique_job_ids(self) -> None:
        """Renumber jobs that share an id across vaults (one-shot).

        Only LOCAL mounted vaults are touched; the repo folder is renamed
        (<backup_subdir>/job-<old> -> job-<new>) without copying data.
        """
        seen: dict[int, str] = {}
        max_id = self.global_max_job_id()
        for vault in self._vaults():
            if "/mnt/stepad-network/" in str(vault):
                continue
            if not self._dir_live(vault):
                continue
            config = self._load_config(vault)
            changed = False
            for record in config.get("jobs", []):
                try:
                    job_id = int(record.get("id") or 0)
                except (TypeError, ValueError):
                    continue
                if not job_id:
                    continue
                if job_id in seen:
                    old_repo = (
                        Path(vault) / self._backup_subdir / f"job-{job_id}"
                    )
                    max_id += 1
                    new_id = max_id
                    new_repo = (
                        Path(vault) / self._backup_subdir / f"job-{new_id}"
                    )
                    try:
                        if old_repo.exists() and not new_repo.exists():
                            os.rename(str(old_repo), str(new_repo))
                        record["id"] = new_id
                        changed = True
                        logger.info(
                            "Job duplicado %s en %s -> renumerado a %s "
                            "(id global único); repo renombrado.",
                            job_id,
                            vault,
                            new_id,
                        )
                    except OSError as error:
                        logger.warning(
                            "No se pudo renumerar job %s de %s (duplicado): %s",
                            job_id,
                            vault,
                            error,
                        )
                else:
                    seen[job_id] = str(vault)
            if changed:
                config["next_job_id"] = max(
                    int(config.get("next_job_id") or 1),
                    max(
                        (
                            int(r.get("id") or 0)
                            for r in config.get("jobs", [])
                        ),
                        default=0,
                    )
                    + 1,
                )
                self._save_config(vault, config)
