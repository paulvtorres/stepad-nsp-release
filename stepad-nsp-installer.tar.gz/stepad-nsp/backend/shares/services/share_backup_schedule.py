"""Mirror cache of backup schedules (per vault).

Read when the backup partition is unmounted so schedules are not lost.
Format v2: {"version": 2, "by_vault": {path: [jobs]}}; the legacy v1
single-vault format is also accepted.

Extracted from `share_backup_service` (monolith) without behavior changes.
"""

import json
import os

from pathlib import Path

from backend.shared.logging.logger import logger


def entry_for(jobs: list) -> list:

    """Jobs for the mirror, without SMB credentials."""

    return [
        {
            key: value
            for key, value in dict(job).items()
            if key not in ("smb_user", "smb_password")
        }
        for job in jobs
    ]


def read_cache_map(path: Path) -> dict:

    try:

        if path.is_file():

            current = json.loads(path.read_text("utf-8"))

            if isinstance(current, dict):

                if current.get("version") == 2:

                    return dict(current.get("by_vault") or {})

                if current.get("vault"):

                    return {
                        str(current["vault"]).rstrip("/"):
                            current.get("jobs") or []
                    }

    except Exception as error:

        logger.warning("Unreadable backup schedule cache: %s", error)

    return {}


def write_cache_map(path: Path, by_vault: dict) -> None:

    try:

        path.parent.mkdir(parents=True, exist_ok=True)

        tmp = path.with_suffix(".tmp")

        tmp.write_text(
            json.dumps(
                {"version": 2, "by_vault": by_vault},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        os.replace(tmp, path)

        try:

            os.chmod(path, 0o600)

        except Exception as error:

            logger.debug("share_backup_schedule.write_cache_map: %s", error)

    except Exception as error:

        logger.warning(
            "Could not update backup schedule cache: %s", error
        )


def jobs_for(path: Path, vault: Path) -> list | None:

    return read_cache_map(path).get(str(vault).rstrip("/"))


def mirror(path: Path, vault: Path, jobs: list) -> None:

    by_vault = read_cache_map(path)

    by_vault[str(vault).rstrip("/")] = entry_for(jobs)

    write_cache_map(path, by_vault)


def remove_entry(path: Path, vault: Path) -> None:

    try:

        by_vault = read_cache_map(path)

        if by_vault.pop(str(vault).rstrip("/"), None) is not None:

            write_cache_map(path, by_vault)

    except Exception as error:

        logger.warning("Could not clear schedule cache for %s: %s", vault, error)


def ensure_mirror(path: Path, vault: Path, jobs: list) -> None:

    key = str(vault).rstrip("/")

    entry = entry_for(jobs)

    by_vault = read_cache_map(path)

    if by_vault.get(key) != entry:

        by_vault[key] = entry

        write_cache_map(path, by_vault)
