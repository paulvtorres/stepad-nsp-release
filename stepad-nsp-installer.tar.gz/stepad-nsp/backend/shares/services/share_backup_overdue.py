"""Overdue watchdog and per-job maintenance windows.

Pure logic extracted from `share_backup_service`. The caller supplies the
time parsing, schedule list, `is_due` check and the grace constant.
"""

from backend.shared.logging.logger import logger


def maintenance_due(job, kind: str, now, parse_time) -> bool:
    """Whether `kind` ("check" or "test_restore") is due for this job.

    Each job owns its interval and last run. The first run waits until the
    job already has a snapshot (never check an empty repo).
    """
    if kind == "test_restore" and not (job.get("test_restore_scratch") or "").strip():
        return False
    if not job.get(f"{kind}_enabled"):
        return False
    at_key = "last_check_at" if kind == "check" else "last_test_restore_at"
    interval_days = max(
        1,
        int(
            job.get(f"{kind}_interval_days")
            or (7 if kind == "check" else 30)
        ),
    )
    last = parse_time(job.get(at_key))
    if last is not None:
        return (now - last).total_seconds() >= interval_days * 86400
    return bool(job.get("last_snapshot_id"))


def backup_is_overdue(
    job,
    now,
    *,
    times_list,
    parse_time,
    grace_minutes: int,
    due,
) -> bool:
    """A scheduled backup missed its window (and should alert once)."""
    if not job.get("enabled"):
        return False
    mode = job.get("schedule_mode")
    if mode == "on_change":
        return False

    # A job still inside its execution window is not "lost": the scheduler
    # will run it in this same tick.
    if mode == "daily":
        try:
            if due(job, now):
                return False
        except Exception as error:
            logger.debug("share_backup_overdue.backup_is_overdue: %s", error)

    last = parse_time(job.get("last_backup_at"))

    if mode == "daily":
        slots = []
        for raw in times_list(job):
            try:
                hours, minutes = (int(part) for part in raw.split(":"))
                slots.append(hours * 60 + minutes)
            except Exception as error:
                logger.debug("share_backup_overdue.backup_is_overdue: %s", error)
                continue
        minute_of_day = now.hour * 60 + now.minute
        passed = [slot for slot in slots if slot <= minute_of_day - grace_minutes]
        if passed and last is None:
            return True
        if passed:
            latest = max(passed)
            if last.date() < now.date():
                return True
            if (
                last.date() == now.date()
                and last.hour * 60 + last.minute < latest
            ):
                return True
        return False

    if mode == "interval":
        interval = max(1, int(job.get("interval_minutes") or 60))
        return (
            last is not None
            and (now - last).total_seconds() > 2 * interval * 60
        )

    return False
