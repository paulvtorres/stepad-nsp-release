"""Run outcome bookkeeping for share backups.

Pure mutations of a job record: last result, failure counters, recovery
flags and the run history. Extracted from `share_backup_service`.
"""


def history_entry(
    *,
    success: bool,
    message: str,
    now_iso: str,
    bytes_added: int = 0,
    duration_seconds: float | None = None,
    trigger: str = "scheduled",
    snapshot_id: str | None = None,
) -> dict:
    entry = {
        "at": now_iso,
        "success": bool(success),
        "message": (message or "")[:500],
        "bytes_added": int(bytes_added or 0),
        "duration_seconds": (
            round(duration_seconds, 1)
            if duration_seconds is not None
            else None
        ),
        "trigger": trigger,
    }
    if snapshot_id:
        entry["snapshot_id"] = (snapshot_id or "")[:64]
    return entry


def append_history(job, entry: dict, limit: int) -> list:
    history = list(job.get("history") or [])
    history.append(entry)
    job["history"] = history[-limit:]
    return job["history"]


def apply_result(
    job,
    *,
    success: bool,
    message: str,
    now_iso: str,
    snapshot_id: str | None = None,
    bytes_added: int = 0,
    update_backup_time: bool = True,
    failure_threshold: int = 3,
) -> dict:
    """Update the job in place; return {"recovered", "alert"} flags."""
    job["last_result"] = (message or "")[:500]
    job["last_attempt_at"] = now_iso
    if update_backup_time:
        job["last_backup_at"] = now_iso
    if snapshot_id is not None:
        job["last_snapshot_id"] = (snapshot_id or "")[:64]

    recovered = False
    alert = False
    if success:
        job["last_bytes"] = bytes_added
        job["consecutive_failures"] = 0
        job["overdue_alerted"] = False
        if job.get("failure_alert_active"):
            job["failure_alert_active"] = False
            recovered = True
    else:
        job["consecutive_failures"] = int(
            job.get("consecutive_failures") or 0
        ) + 1
        if (
            job["consecutive_failures"] >= failure_threshold
            and not job.get("failure_alert_active")
        ):
            job["failure_alert_active"] = True
            alert = True
    return {"recovered": recovered, "alert": alert}
