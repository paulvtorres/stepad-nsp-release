"""Change detection for on-change share backups.

Extracted from `share_backup_service` (monolith) without behavior changes.
"""

import hashlib

from pathlib import Path


def tree_signature(root: Path) -> str | None:

    """Snapshot of (path, mtime, size) so on-change backups detect edits.

    Returns None on I/O errors (the caller skips the check)."""

    try:

        entries = []

        for path in sorted(root.rglob("*")):

            if path.is_dir():

                continue

            stat = path.stat()

            rel = path.relative_to(root).as_posix()

            entries.append(f"{rel}:{stat.st_mtime_ns}:{stat.st_size}")

        return hashlib.sha256(
            "\n".join(entries).encode("utf-8", "replace")
        ).hexdigest()

    except OSError:

        return None
