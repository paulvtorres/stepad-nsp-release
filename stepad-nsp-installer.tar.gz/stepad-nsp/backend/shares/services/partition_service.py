"""Partition validation, extracted from NetworkShareService.

Single source of truth for "can this partition be deleted?". The
network-share service delegates here instead of repeating the OS-disk,
existence and in-use checks.
"""

from pathlib import Path

from fastapi import HTTPException

from backend.shared.logging.logger import logger


class PartitionService:

    def __init__(
        self,
        *,
        list_units,
        os_disk_names,
        parent_disk_name,
        in_use,
        ensure_safe=None,
    ):
        self._list_units = list_units
        self._os_disk_names = os_disk_names
        self._parent_disk_name = parent_disk_name
        self._in_use = in_use
        if ensure_safe is None:
            from backend.shares.services.disk_guard import ensure_not_system_disk

            ensure_safe = ensure_not_system_disk
        self._ensure_safe = ensure_safe

    @staticmethod
    def normalize(device: str) -> str:
        value = (device or "").strip()
        if value and not value.startswith("/dev/"):
            value = f"/dev/{value}"
        return value

    def inspect(self, device: str) -> tuple[str, dict | None, str | None]:
        """Return (normalized device, unit, mountpoint)."""
        device = self.normalize(device)
        if not device.startswith("/dev/"):
            return device, None, None
        units = {
            unit.get("device"): unit
            for unit in self._list_units()
        }
        unit = units.get(device)
        mountpoint = (unit or {}).get("mountpoint") or None
        return device, unit, mountpoint

    def can_delete(
        self,
        device: str,
        *,
        unit: dict | None = None,
        mountpoint: str | None = None,
    ) -> tuple[bool, str]:
        """(ok, reason). Never raises for expected rejections."""

        device = self.normalize(device)

        if not device.startswith("/dev/"):
            return False, "Indica una partición /dev/..."

        try:
            self._ensure_safe(device, "eliminar la partición")
        except HTTPException as error:
            return False, str(error.detail)
        except Exception as error:
            logger.warning("partition_service.can_delete: %s", error)
            return False, "No se pudo verificar el disco del sistema."

        os_disks = self._os_disk_names()
        parent = self._parent_disk_name(device)
        if os_disks and (
            parent in os_disks or Path(device).name in os_disks
        ):
            return False, "No se puede eliminar una partición del disco del sistema."

        if unit is None:
            _, unit, detected = self.inspect(device)
            mountpoint = mountpoint or detected

        if not unit or unit.get("whole_disk") or not unit.get("deletable"):
            return False, "Esa partición no se puede eliminar (¿es del SO?)."

        mountpoint = mountpoint or unit.get("mountpoint")

        if mountpoint:
            in_use = self._in_use(mountpoint)
            if in_use:
                return False, (
                    f"No se puede eliminar la partición {device}: está en uso "
                    f"por {in_use}. Espera a que termine el proceso o "
                    "detenelo antes de eliminar."
                )

        return True, ""
