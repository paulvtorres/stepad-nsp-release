"""Explicit, thread-safe state of backup/restore runs.

One owner for the in-memory run state (running jobs, start time, cancel
requests, progress, restic processes and restore statuses). The service
keeps its historical attributes as views over this registry.
"""

import threading


class BackupRunRegistry:

    def __init__(self):
        self._lock = threading.RLock()
        self.running: set = set()
        self.running_since: dict = {}
        self.cancel_requested: set = set()
        self.progress: dict = {}
        self.restore_status: dict = {}
        self.procs: dict = {}

    def begin(self, job_id, since_iso: str) -> bool:
        with self._lock:
            if job_id in self.running:
                return False
            self.running.add(job_id)
            self.running_since[job_id] = since_iso
            return True

    def finish(self, job_id) -> None:
        with self._lock:
            self.running.discard(job_id)
            self.running_since.pop(job_id, None)
            self.progress.pop(job_id, None)

    def is_running(self, job_id) -> bool:
        return job_id in self.running

    def running_ids(self) -> set:
        return set(self.running)

    def state(self, job_id) -> str:
        return "running" if job_id in self.running else "idle"

    def request_cancel(self, job_id) -> None:
        with self._lock:
            self.cancel_requested.add(job_id)

    def consume_cancel(self, job_id) -> bool:
        with self._lock:
            if job_id in self.cancel_requested:
                self.cancel_requested.discard(job_id)
                return True
            return False

    def set_progress(self, job_id, data: dict) -> None:
        self.progress[job_id] = data

    def get_progress(self, job_id) -> dict:
        return self.progress.get(job_id) or {}

    def set_proc(self, job_id, proc) -> None:
        self.procs[job_id] = proc

    def pop_proc(self, job_id):
        return self.procs.pop(job_id, None)

    def set_restore(self, job_id, data: dict) -> None:
        self.restore_status[job_id] = data

    def get_restore(self, job_id) -> dict:
        return self.restore_status.get(job_id) or {}

    def restore_items(self) -> list:
        return list(self.restore_status.items())
