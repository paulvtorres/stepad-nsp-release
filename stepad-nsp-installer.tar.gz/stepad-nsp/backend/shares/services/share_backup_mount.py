"""CIFS option/command helpers for share backups.

Extracted from `share_backup_service` (monolith). Pure option builders
plus a small helper that writes 0600 credentials files.
"""

import os
import tempfile

from pathlib import Path

from backend.shared.logging.logger import logger

NETWORK_BASE = "uid=0,gid=0,iocharset=utf8,vers=3.0,nobrl,soft"

# Read-only mount used to inspect a source.
READ_OPTIONS = f"{NETWORK_BASE},echo_interval=15,actimeo=20,cache=strict"

# Read-write mount used by backups (timeouts tuned for slow CIFS links).
WRITE_OPTIONS = (
    f"{NETWORK_BASE},rw,timeo=50,retrans=1,echo_interval=5,"
    "actimeo=20,cache=strict"
)


def is_network_source(source: str) -> bool:

    """True for SMB shares and mounted network units."""

    value = source or ""

    return (
        value.startswith("//")
        or value.startswith("\\\\")
        or "/stepad-network/" in value
    )


CREDENTIALS_DIR = Path("/run/stepad")


def write_credentials(
    user: str,
    password: str,
    *,
    directory: Path = CREDENTIALS_DIR,
) -> Path | None:

    """Write a 0600 credentials file so the password stays out of `ps`.

    Returns None for guest mounts or when the directory is not writable
    (the caller then falls back to inline options)."""

    if not user:

        return None

    try:

        directory.mkdir(mode=0o700, parents=True, exist_ok=True)

        handle = tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=directory,
            prefix="cifs-",
            suffix=".cred",
            delete=False,
        )

        try:

            os.fchmod(handle.fileno(), 0o600)

            handle.write(f"username={user}\npassword={password}\n")

        finally:

            handle.close()

        return Path(handle.name)

    except OSError as error:

        logger.warning("No pude crear credenciales CIFS temporales: %s", error)

        return None


def cifs_options(
    user: str,
    password: str,
    *,
    read_write: bool = False,
    credentials: Path | None = None,
) -> str:

    options = WRITE_OPTIONS if read_write else READ_OPTIONS

    if credentials is not None:

        return f"credentials={credentials},{options}"

    if user:

        return f"username={user},password={password},{options}"

    return f"guest,{options}"
