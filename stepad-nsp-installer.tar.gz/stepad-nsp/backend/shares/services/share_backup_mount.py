"""CIFS option/command helpers for share backups.

Extracted from `share_backup_service` (monolith) without behavior changes.
Only pure functions: source detection and mount options.
"""

NETWORK_BASE = "uid=0,gid=0,iocharset=utf8,vers=3.0,nobrl,soft"

# Read-only mount used to inspect a source.
READ_OPTIONS = f"{NETWORK_BASE},echo_interval=15,actimeo=20,cache=strict"

# Read-write mount used by backups (timeouts tuned for slow CIFS links).
WRITE_OPTIONS = (
    f"{NETWORK_BASE},rw,timeo=50,retrans=1,echo_interval=5,"
    "actimeo=20,cache=strict"
)


def is_network_source(source: str) -> bool:

    """True for SMB shares and mounted network units."""

    value = source or ""

    return (
        value.startswith("//")
        or value.startswith("\\\\")
        or "/stepad-network/" in value
    )


def cifs_options(user: str, password: str, *, read_write: bool = False) -> str:

    options = WRITE_OPTIONS if read_write else READ_OPTIONS

    if user:

        return f"username={user},password={password},{options}"

    return f"guest,{options}"
