"""Disk size helpers for share backups.

Extracted from `share_backup_service` (monolith) without behavior changes.
"""


def human_bytes(value) -> str:

    try:

        value = int(value or 0)

    except (TypeError, ValueError):

        value = 0

    size = float(value)

    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):

        if size < 1024 or unit == "TiB":

            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"

        size /= 1024

    return f"{int(value)} B"


def disk_info(path: str, disk) -> dict:

    """Shape a statvfs-like result for the API/UI."""

    return {
        "path": str(path),
        "total_bytes": disk.total,
        "used_bytes": disk.used,
        "free_bytes": disk.free,
        "free_pct": (
            round(100 * disk.free / disk.total, 1) if disk.total else 100.0
        ),
        "used_human": human_bytes(disk.used),
        "total_human": human_bytes(disk.total),
    }
