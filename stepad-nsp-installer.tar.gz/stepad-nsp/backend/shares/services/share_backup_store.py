"""Backup configuration store per vault (`.respaldo.json`).

File IO only: normalizes the schema and writes atomically with 0600
permissions. Cache/mirror and scheduler logic stay in the service.
Extracted from the monolith without behavior changes.
"""

import json
import os

from pathlib import Path

from backend.shared.logging.logger import logger


CONFIG_FILENAME = ".respaldo.json"

CONFIG_SCHEMA = 1


def config_path(vault: Path) -> Path:

    return vault / CONFIG_FILENAME


def empty_config() -> dict:

    return {"schema": CONFIG_SCHEMA, "next_job_id": 1, "jobs": []}


def read_config(vault: Path) -> dict | None:

    """Real vault config, or None when missing/invalid."""

    try:

        payload = json.loads(config_path(vault).read_text("utf-8"))

    except FileNotFoundError:

        return None

    except Exception as error:

        logger.warning("Unreadable backup config in %s: %s", vault, error)

        return None

    if isinstance(payload, dict) and isinstance(payload.get("jobs"), list):

        return payload

    return None


def write_config(vault: Path, config: dict) -> dict:

    vault.mkdir(parents=True, exist_ok=True)

    config.setdefault("schema", CONFIG_SCHEMA)

    config.setdefault("jobs", [])

    config.setdefault(
        "next_job_id",
        max(
            (int(job.get("id") or 0) for job in config.get("jobs", [])),
            default=0,
        ) + 1,
    )

    path = config_path(vault)

    temp = path.with_suffix(".tmp")

    temp.write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    os.replace(temp, path)

    try:

        os.chmod(path, 0o600)

    except Exception as error:

        logger.debug("share_backup_store.write_config: %s", error)

    return config
