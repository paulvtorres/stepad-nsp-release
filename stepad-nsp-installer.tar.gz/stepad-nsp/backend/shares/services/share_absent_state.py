"""Grace-period tracking for volumes whose device is absent.

Used by the periodic reconciliation to purge truly stale rows WITHOUT
deleting a volume that was merely unplugged for a while. State lives in a
0600 JSON sidecar (key -> first time seen absent).
"""

import json
import os

from datetime import datetime


def volume_key(volume) -> str:
    """Stable identity: UUID when known, otherwise device path."""
    uuid = None
    path = None
    if isinstance(volume, dict):
        uuid = volume.get("device_uuid")
        path = volume.get("device_path")
    else:
        uuid = getattr(volume, "device_uuid", None)
        path = getattr(volume, "device_path", None)
    return f"uuid:{uuid}" if uuid else f"dev:{path or ''}"


def read_state(path) -> dict:
    try:
        payload = json.loads(path.read_text("utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return {
        str(key): str(value)
        for key, value in payload.items()
        if isinstance(key, str) and isinstance(value, str)
    }


def write_state(path, state: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temp, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    except OSError:
        pass


def update_state(
    state: dict,
    orphan_keys: set,
    all_keys: set,
    now: datetime,
    grace_days: int,
) -> tuple[dict, list[str]]:
    """Return (new_state, expired_keys).

    - Keys no longer present are dropped.
    - Present volumes reset their counter.
    - New orphans are stamped with `now`.
    - A key expires once absent >= grace_days.
    Expired keys stay in the state until the caller purges them (retry).
    """
    new_state: dict = {}
    expired: list[str] = []

    for key in sorted(all_keys):
        if key not in orphan_keys:
            continue
        stamp = state.get(key)
        if stamp is None:
            stamp = now.isoformat()
        try:
            since = datetime.fromisoformat(stamp)
        except ValueError:
            since = now
            stamp = now.isoformat()
        new_state[key] = stamp
        if grace_days > 0 and (now - since).total_seconds() >= grace_days * 86400:
            expired.append(key)

    return new_state, expired
