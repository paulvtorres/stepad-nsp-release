"""Rangos DHCP de las zonas, leídos de la base (compartido por el
reconciliador y el panel)."""

from __future__ import annotations

import ipaddress

from backend.shared.logging.logger import logger


def load_zone_ranges(db=None) -> list[dict]:
    """[{id, name, start, end, netmask}] de cada zona con su pool DHCP.

    Si no se pasa `db` abre y cierra su propia sesión.
    """

    from backend.network.zones.models.network_zone import NetworkZone

    own = db is None

    if own:

        from backend.core.database.session import SessionLocal

        db = SessionLocal()

    try:

        result = []

        for zone in db.query(NetworkZone).all():

            try:

                netmask = str(
                    ipaddress.ip_network(zone.network_cidr, strict=False).netmask
                )

            except ValueError as error:

                logger.debug("zona %s con CIDR inválido: %s", zone.name, error)

                continue

            result.append(
                {
                    "id": zone.id,
                    "name": zone.name,
                    "start": zone.dhcp_pool_start,
                    "end": zone.dhcp_pool_end,
                    "netmask": netmask,
                }
            )

        return result

    finally:

        if own:

            db.close()
