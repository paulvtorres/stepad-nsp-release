"""
Versioned backups of shared volumes using restic (anti-ransomware).

Each job snapshots one directory (a shared volume mountpoint or folder)
into a dedicated, encrypted and deduplicated restic repository stored in
each unit's private vault folder:  {unit}/Respaldo/.backups/job-{id}.

The vault (the private "Respaldo" folder of every unit) is never exposed
through Samba -- shares.conf only references shared folder mountpoints under
/mnt/stepad-share -- so an SMB client (or ransomware moving through SMB)
cannot reach, list or delete the repositories.

Job definitions (characteristics) live in a hidden file inside each vault:
    {unit}/Respaldo/.respaldo.json

That file is the single source of truth for the backups: it assigns each new
job its sequential id and stores the schedule, retention, runtime state and
the flag that suppresses repeated "source missing" alerts. No database sync
is required, which avoids inconsistencies between the database and the disk.

A scheduler runs the enabled jobs on their schedule; when a job's source
directory disappears, an alert (SHARE_BACKUP_SOURCE_MISSING) is raised in
the alerts panel.

Retention keeps the newest N snapshots; when free space on the disk hosting
the repository drops below a threshold, `forget --keep-last N --prune`
trims old versions while preserving recent ones.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time
from datetime import datetime, timedelta
from backend.shared.utils.datetimes import now_ecuador
from pathlib import Path
from typing import Any

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc
from backend.shares.models.network_share_folder import NetworkShareFolder
from backend.shares.models.network_share_volume import NetworkShareVolume

SHARE_ROOT = Path("/mnt/stepad-share")
VOLUME_RESERVED_NAME = "Respaldo"
BACKUP_SUBDIR = ".backups"
CONFIG_FILENAME = ".respaldo.json"
CONFIG_SCHEMA = 1

_MOUNT_INFO_CACHE: dict[str, tuple[float, set[str]]] = {}


def is_mountpoint_in_mountinfo(path: str) -> bool:
    """True si `path` figura como punto de montaje en /proc/mounts.

    Lectura instantánea (nunca toca el filesystem), segura con shares de red
    caídos. Un "mount fantasma" del namespace del servicio aparece aquí sin
    que el contenido real sea accesible."""
    try:
        with open("/proc/mounts", encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                parts = raw.split()
                if len(parts) >= 2 and parts[1].rstrip("/") == path.rstrip("/"):
                    return True
    except OSError:
        pass
    return False


def mount_point_name(path: Path) -> str | None:
    """Nombre del mount más cercano (ancestro o igual) sin tocar el FS.

    Lee ``/proc/mounts`` (instantáneo, no se cuelga) y devuelve el mountpoint
    más específico que contiene a ``path``, o None si no hay ninguno. Nunca
    ejecuta syscalls sobre el filesystem, así que es seguro con shares de red
    caídos."""
    text = str(path)
    cache = _MOUNT_INFO_CACHE.get(text)
    now = time.monotonic()
    if cache and now - cache[0] < 2.0:
        mounts = cache[1]
    else:
        mounts: set[str] = set()
        try:
            with open("/proc/mounts", encoding="utf-8", errors="replace") as fh:
                for raw in fh:
                    parts = raw.split()
                    if len(parts) >= 2:
                        mounts.add(parts[1])
        except OSError:
            return None
        _MOUNT_INFO_CACHE[text] = (now, mounts)
    best = None
    for mp in mounts:
        if text == mp or text.startswith(mp.rstrip("/") + "/"):
            if best is None or len(mp) > len(best):
                best = mp
    return best

POLL_SECONDS = 60

RECONCILE_SECONDS = 300

# Raíces del sistema operativo: nunca se tratan como unidades de datos.
_SYSTEM_MOUNTS = {
    "/", "/boot", "/boot/efi", "/home", "/var", "/usr", "/etc", "/opt",
    "/srv", "/tmp", "/root", "/bin", "/sbin", "/lib", "/dev", "/proc",
    "/sys", "/run", "[SWAP]", "/snap",
}

SOURCE_MISSING_ALERT = "SHARE_BACKUP_SOURCE_MISSING"

# Alerta cuando un job lleva varios intentos fallidos seguidos (ver
# _finish_run). Antes solo existía alerta para "la carpeta desapareció";
# cualquier otro fallo (credenciales, restic roto, disco lleno, timeout)
# no generaba ninguna señal visible para el usuario -- solo una línea
# en logger.warning() que nadie revisa.
BACKUP_FAILING_ALERT = "SHARE_BACKUP_FAILING"

# A partir de cuántos fallos consecutivos se levanta esa alerta. Menos
# que esto se asume que puede ser un problema transitorio (ej. un
# reinicio de red de un minuto) y no vale la pena alarmar todavía.
FAILURE_ALERT_THRESHOLD = 3

# Backoff entre reintentos tras un fallo, en minutos, según cuántos
# fallos consecutivos lleva el job (índice 0 = tras el 1er fallo, etc.;
# el último valor se repite para cualquier cantidad mayor de fallos).
# Sin esto, un job roto (ej. contraseña SMB incorrecta) se reintentaba
# cada POLL_SECONDS (60s) sin límite -- lo suficiente para bloquear una
# cuenta de Active Directory por política de intentos fallidos en
# cuestión de minutos.
FAILURE_BACKOFF_MINUTES = [5, 15, 30, 60]

# Cuántas corridas (éxito o fallo) se guardan por job en su bitácora.
HISTORY_LIMIT = 30


def _human_bytes(value: int | None) -> str:
    try:
        value = int(value or 0)
    except (TypeError, ValueError):
        value = 0
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024 or unit == "TiB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{int(value)} B"


def _empty_config() -> dict:
    return {"schema": CONFIG_SCHEMA, "next_job_id": 1, "jobs": []}


def _default_job() -> dict:
    return {
        "id": 0,
        "name": "",
        "source_path": "",
        "smb_user": "",
        "smb_password": "",
        "enabled": True,
        "schedule_mode": "daily",
        "schedule_hour": 2,
        "schedule_minute": 0,
        "schedule_times": None,
        "interval_minutes": None,
        "retention_count": 7,
        "prune_free_pct": 15,
        "folder_id": None,
        "change_hash": None,
        "tree_hash": None,
        "last_backup_at": None,
        "last_result": None,
        "last_snapshot_id": None,
        "last_bytes": 0,
        "source_missing_alerted": False,
        # Seguimiento de fallos consecutivos, para el backoff de is_due()
        # y la alerta de BACKUP_FAILING_ALERT (ver _finish_run).
        "consecutive_failures": 0,
        "last_attempt_at": None,
        "failure_alert_active": False,
        # Pausa manual (botón «saltar»): el job no corre hasta este instante.
        "skip_until": None,
        # Bitácora de corridas (más reciente al final); ver HISTORY_LIMIT.
        "history": [],
    }


class Job(dict):
    """Job record augmented with its vault folder (never persisted)."""

    def __init__(self, *args, vault: Path | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.vault = vault


# Module-level singleton so the scheduler is shared across callers
# (monitoring component starts it; must not spawn duplicates).
_shared_instance = None


def get_share_backup_service():
    global _shared_instance
    if _shared_instance is None:
        _shared_instance = ShareBackupService()
    return _shared_instance


class ShareBackupService:

    def __init__(self):
        self._stop = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._running_jobs: set[int] = set()
        # Timestamp (ISO) de inicio de cada job en ejecución, para mostrar
        # "respaldo en curso desde hace N min" en la UI.
        self._running_since: dict[int, str] = {}
        # Contador de respaldos "por horario" (daily/interval) en curso.
        # Mientras sea > 0, el watch antiransomware (share_integrity_watch_
        # service) se salta su escaneo -- ver has_active_protected_backup().
        # on_change queda deliberadamente FUERA de esta protección.
        self._active_protected_backups = 0
        self._last_reconcile = 0.0
        # Procesos restic en curso por job (para poder "Parar").
        self._procs: dict[int, "subprocess.Popen"] = {}
        # Jobs cuyo respaldo en curso fue cancelado por el usuario.
        self._cancel_requested: set[int] = set()
        # Caché de tamaños de carpetas (path -> (monotonic, bytes)).
        self._size_cache: dict[str, tuple[float, int]] = {}
        # Progreso de respaldos en curso: job_id -> {files_done, files_total, bytes_done, bytes_total, current_file}
        self._progress: dict[int, dict] = {}
        # Última razón por la que no se pudo medir el origen (para la UI).
        self._last_size_error: str | None = None

    # ------------------------------------------------------------------
    # vault / config file storage (single source of truth)
    # ------------------------------------------------------------------

    @staticmethod
    def _inode(path):
        try:
            return os.stat(path).st_ino
        except (OSError, ValueError):
            return None

    def _vaults(self, db: Session | None = None) -> list[Path]:
        """Todas las bóvedas de respaldo (destinos posibles).

        Incluye:
          - la carpeta privada «Respaldo» de cada unidad local (convención);
          - cualquier subcarpeta de una unidad local que ya actúe como bóveda
            (tiene config `.respaldo.json` o repos `.backups`), detectada por
            archivos para que un repo real nunca se pierda sin la BD;
          - las unidades de red montadas (se listan, pero no valen como
            destino de respaldo);
          - si se pasa `db`, además TODAS las carpetas privadas de unidades
            locales (aunque aún no tengan respaldos).
        Si dos rutas apuntan al mismo directorio (hardlinks), solo devuelve
        una de ellas (el camino más corto)."""
        def as_vault(leaf: Path) -> Path | None:
            if not self._dir_live(leaf or Path()):
                return None
            try:
                inode = os.stat(leaf).st_ino
            except OSError:
                return None
            if inode in seen_inodes:
                return None
            seen_inodes.add(inode)
            return leaf

        seen_inodes: set[int] = set()
        vaults: list[Path] = []
        # SHARE_ROOT: unidades locales (unidad1/Respaldo, etc.)
        if SHARE_ROOT.is_dir():
            for volume in sorted(SHARE_ROOT.iterdir(), key=lambda c: len(str(c))):
                if not volume.is_dir():
                    continue
                vault = as_vault(volume / VOLUME_RESERVED_NAME)
                if vault is not None:
                    vaults.append(vault)
                # Subcarpetas de la unidad que ya son bóveda (config/repo).
                try:
                    children = list(volume.iterdir())
                except OSError:
                    children = []
                for child in children:
                    if not child.is_dir() or child.name == VOLUME_RESERVED_NAME:
                        continue
                    if child.name.startswith("."):
                        continue
                    if (child / CONFIG_FILENAME).is_file() or (child / BACKUP_SUBDIR).is_dir():
                        extra = as_vault(child)
                        if extra is not None:
                            vaults.append(extra)
        # Unidades de red: /mnt/stepad-network/{letter}/Respaldo
        network_base = Path("/mnt/stepad-network")
        if network_base.is_dir():
            try:
                network_entries = list(network_base.iterdir())
            except OSError:
                network_entries = []
            for mount_point in network_entries:
                # No listar rutas de una unidad de red desconectada: su
                # contenido no es legible y solo genera avisos falsos de
                # "repo huérfano" o destinos fantasma.
                if not self._dir_live(mount_point):
                    continue
                vault = as_vault(mount_point / VOLUME_RESERVED_NAME)
                if vault is not None:
                    vaults.append(vault)
        # Discos/externos/USB: cualquier montaje de datos detectado
        # dinámicamente en /proc/mounts (NSP es dinámico: se puede quitar un
        # disco y poner otro sin tocar config; no hay rutas fijas).
        self._add_data_mount_vaults(vaults_list=vaults, seen_inodes=seen_inodes, as_vault=as_vault)
        # Con BD: todas las carpetas privadas de unidades locales cuentan
        # como destino aunque todavía no tengan ningún respaldo.
        if db is not None:
            try:
                volumes = {
                    v.id: v
                    for v in db.query(NetworkShareVolume).all()
                    if v.mountpoint and "/mnt/stepad-network/" not in (v.mountpoint or "")
                }
                folders = db.query(NetworkShareFolder).filter(
                    NetworkShareFolder.shared.is_(False)
                ).all()
                for folder in folders:
                    volume = volumes.get(folder.volume_id)
                    root = Path(volume.mountpoint) if volume else None
                    if root is None or not folder.folder_name:
                        continue
                    extra = as_vault(root / folder.folder_name)
                    if extra is not None:
                        vaults.append(extra)
            except Exception as error:
                logger.warning("_vaults: no se pudieron cargar carpetas privadas: %s", error)
        return vaults

    def _add_data_mount_vaults(
        self,
        *,
        vaults_list: list,
        seen_inodes: set,
        as_vault,
    ) -> None:
        """Agrega bóvedas «Respaldo» desde cualquier montaje de datos activo.

        Lee /proc/mounts (nunca se cuelga) y considera los puntos de montaje
        con filesystems de datos (ext4, ntfs, exfat, vfat, cifs, xfs, btrfs…)
        que NO son el sistema. Para cada uno busca la carpeta «Respaldo» y
        subcarpetas con config/repo de respaldo. Así el NSP es dinámico: se
        puede quitar una unidad y poner otra y la bóveda se detecta sola."""
        if not hasattr(self, "_data_fstypes"):
            self._data_fstypes = {
                "ext2", "ext3", "ext4", "xfs", "btrfs", "ntfs", "ntfs3",
                "exfat", "vfat", "msdos", "fuseblk", "cifs", "smb3",
                "iso9660", "udf",
            }
        data_roots: set[str] = set()
        try:
            with open("/proc/mounts", encoding="utf-8", errors="replace") as fh:
                for raw in fh:
                    parts = raw.split()
                    if len(parts) < 2:
                        continue
                    fstype = parts[2]
                    mountpoint = parts[1]
                    if fstype not in self._data_fstypes:
                        continue
                    if mountpoint in _SYSTEM_MOUNTS:
                        continue
                    if mountpoint.startswith("/boot"):
                        continue
                    data_roots.add(mountpoint)
        except OSError:
            return

        for root_str in sorted(data_roots, key=len):
            root = Path(root_str)
            # El mount raíz puede estar caído (red): no tocar ni colgarse.
            if not self._dir_live(root):
                continue
            # «Respaldo» en la raíz de la unidad.
            vault = as_vault(root / VOLUME_RESERVED_NAME)
            if vault is not None:
                vaults_list.append(vault)
            # Subcarpetas de la unidad que ya son bóveda (config/repo).
            try:
                children = list(root.iterdir())
            except OSError:
                continue
            for child in children:
                if not self._dir_live(child):
                    continue
                if not child.is_dir() or child.name == VOLUME_RESERVED_NAME:
                    continue
                if child.name.startswith("."):
                    continue
                if (child / CONFIG_FILENAME).is_file() or (child / BACKUP_SUBDIR).is_dir():
                    extra = as_vault(child)
                    if extra is not None:
                        vaults_list.append(extra)

    def _vault_for_source(self, source: str) -> Path | None:
        """Bóveda (carpeta Respaldo) de la unidad que contiene el origen."""
        if not source:
            return None
        # Network source: use LOCAL vault, not the network vault
        if "/stepad-network/" in source or source.startswith("//") or source.startswith("\\\\"):
            local_vaults = [v for v in self._vaults() if "/stepad-network/" not in str(v)]
            return local_vaults[0] if local_vaults else (self._vaults()[0] if self._vaults() else None)
        if not SHARE_ROOT.is_dir():
            return None
        path = Path(source)
        candidates = [c for c in SHARE_ROOT.iterdir() if c.is_dir()]
        # Prefer the shortest path when multiple volumes resolve to the
        # same directory (hardlinks / bind-mounts).
        candidates.sort(key=lambda c: len(str(c)))
        for volume in candidates:
            vault = volume / VOLUME_RESERVED_NAME
            if vault.is_dir() and (
                path == volume or str(path).startswith(str(volume) + "/")
            ):
                return vault
        return None

    def _dest_folder(self, source: str) -> Path:
        vault = self._vault_for_source(source)
        return vault if vault is not None else Path("")

    def _vault_from_destination_path(self, destination: str, db: Session | None = None) -> Path | None:
        """Resuelve el destino elegido por el usuario a una bóveda local.

        Vale cualquier carpeta privada de una unidad local (incluida la
        convención «Respaldo»). Las de unidades de red montadas en
        stepad-network no. Devuelve None si no coincide con ninguna.
        """
        if not destination:
            return None
        target = Path(destination).resolve()
        for vault in self._vaults(db):
            if "/stepad-network/" in str(vault):
                continue
            if Path(str(vault)).resolve() == target:
                return vault
        return None

    def _mount_destination_if_backup(
        self,
        db: Session | None,
        vault,
    ) -> bool:
        """
        Antes de VALIDAR/guardar un job, si el destino vive en una
        partición de finalidad "backup" que está desmontada (montaje por
        demanda), la monta y crea la carpeta «Respaldo». Devuelve True si
        el destino quedó disponible.
        """
        if vault is None:
            return True
        try:
            vault_str = str(vault).strip().rstrip("/")
            from backend.shares.models.network_share_volume import NetworkShareVolume
            session = db or SessionLocal()
            own = session is db
            try:
                for volume in session.query(NetworkShareVolume).all():
                    purpose = getattr(volume, "purpose", "shared") or "shared"
                    if purpose != "backup":
                        continue
                    mp = str(volume.mountpoint or "").rstrip("/")
                    if not mp:
                        continue
                    if vault_str == mp or vault_str.startswith(mp + "/"):
                        from backend.shares.providers.share_disk_mount_provider import (
                            ShareDiskMountProvider,
                        )
                        provider = ShareDiskMountProvider()
                        if not provider.is_mounted_at(mp):
                            result = provider.mount_now(
                                uuid=volume.device_uuid,
                                mountpoint=mp,
                            )
                            if not result.get("success"):
                                logger.warning(
                                    "No se pudo montar partición Respaldo %s "
                                    "para guardar el job: %s",
                                    volume.name,
                                    result.get("message"),
                                )
                                return False
                        Path(mp).mkdir(parents=True, exist_ok=True)
                        (Path(mp) / "Respaldo").mkdir(
                            parents=True, exist_ok=True
                        )
                        return True
                return True
            finally:
                if not own:
                    session.close()
        except Exception as error:
            logger.warning("_mount_destination_if_backup: %s", error)
            return True

    def _assert_destination_is_backup(
        self,
        db: Session | None,
        vault,
    ) -> None:
        """
        El destino de un respaldo DEBE vivir dentro de una partición con
        finalidad "backup". Nunca se respalda sobre una unidad compartida
        ni privada (serían blanco de la red o de la web).
        """
        if vault is None:
            return
        try:
            vault_str = str(vault).strip().rstrip("/")
            if not vault_str:
                return
            from backend.shares.models.network_share_volume import NetworkShareVolume
            session = db or SessionLocal()
            own = session is db
            try:
                for volume in session.query(NetworkShareVolume).all():
                    purpose = getattr(volume, "purpose", "shared") or "shared"
                    mp = str(volume.mountpoint or "").rstrip("/")
                    if not mp:
                        continue
                    if vault_str == mp or vault_str.startswith(mp + "/"):
                        if purpose != "backup":
                            raise HTTPException(
                                status_code=400,
                                detail=(
                                    f"El destino «{vault_str}» está en una "
                                    f"partición «{volume.name}» de finalidad "
                                    f"«{purpose}». El destino de un respaldo "
                                    "debe ser una partición de tipo "
                                    "«Respaldo»."
                                ),
                            )
                        return
            finally:
                if not own:
                    session.close()
        except HTTPException:
            raise
        except Exception as error:
            logger.warning("_assert_destination_is_backup: %s", error)

    def _create_vault_for_source(self, source: str) -> "Path | None":
        """Crea la carpeta privada «Respaldo» de la unidad local que contiene
        el origen (primer uso). Devuelve la bóveda creada o None si el origen
        no vive en una unidad local."""
        if not source or "/stepad-network/" in source or source.startswith("//") or source.startswith("\\"):
            return None
        if not SHARE_ROOT.is_dir():
            return None
        path = Path(source)
        candidates = sorted(
            (c for c in SHARE_ROOT.iterdir() if c.is_dir()),
            key=lambda c: len(str(c)),
        )
        for volume in candidates:
            if path != volume and not str(path).startswith(str(volume) + "/"):
                continue
            vault = volume / VOLUME_RESERVED_NAME
            try:
                vault.mkdir(parents=True, exist_ok=True)
                return vault
            except OSError as error:
                logger.warning("No se pudo crear la carpeta «Respaldo» %s: %s", vault, error)
                return None
        return None

    def _create_vault_from_destination(self, destination: str) -> "Path | None":
        """Crea la carpeta privada «Respaldo» elegida como destino cuando aún
        no existe, solo si pertenece a una unidad LOCAL (carpeta raíz de
        SHARE_ROOT). Devuelve la bóveda o None si no califica."""
        if not destination or "/stepad-network/" in destination or not SHARE_ROOT.is_dir():
            return None
        target = Path(destination)
        if target.name != VOLUME_RESERVED_NAME:
            return None
        volume = target.parent
        if volume == SHARE_ROOT or volume.parent != SHARE_ROOT or not volume.is_dir():
            return None
        try:
            target.mkdir(parents=True, exist_ok=True)
            return target
        except OSError as error:
            logger.warning("No se pudo crear la carpeta «Respaldo» %s: %s", target, error)
            return None

    def _config_path(self, vault: Path) -> Path:
        return vault / CONFIG_FILENAME

    def _load_config(self, vault: Path) -> dict:
        try:
            payload = json.loads(self._config_path(vault).read_text("utf-8"))
            if isinstance(payload, dict) and isinstance(payload.get("jobs"), list):
                return payload
        except FileNotFoundError:
            pass
        except Exception as error:
            logger.warning("Config de respaldos ilegible en %s: %s", vault, error)
        return _empty_config()

    def _save_config(self, vault: Path, config: dict) -> None:
        vault.mkdir(parents=True, exist_ok=True)
        config.setdefault("schema", CONFIG_SCHEMA)
        config.setdefault("next_job_id", max((int(j.get("id") or 0) for j in config.get("jobs", [])), default=0) + 1)
        config.setdefault("jobs", [])
        path = self._config_path(vault)
        temp = path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temp, path)
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass

    def _all_jobs(self) -> list[Job]:
        jobs: list[Job] = []
        for vault in self._vaults():
            config = self._load_config(vault)
            for record in config.get("jobs", []):
                record = dict(_default_job(), **{k: v for k, v in record.items() if k in _default_job()})
                record["id"] = int(record.get("id") or 0)
                jobs.append(Job(record, vault=vault))
        jobs.sort(key=lambda j: j["id"])
        return jobs

    def _find_job(self, job_id: int) -> Job | None:
        for job in self._all_jobs():
            if int(job.get("id")) == int(job_id):
                return job
        return None

    def _save_job(self, job: Job) -> None:
        with self._lock:
            self._save_job_locked(job)

    def _save_job_locked(self, job: Job) -> None:
        config = self._load_config(job.vault)
        for index, record in enumerate(config.get("jobs", [])):
            if int(record.get("id") or 0) == int(job.get("id")):
                config["jobs"][index] = dict(job)
                break
        self._save_config(job.vault, config)

    def _repo_path(self, job: Job) -> Path:
        return job.vault / BACKUP_SUBDIR / f"job-{job.get('id')}"

    # ------------------------------------------------------------------
    # network share mounting
    # ------------------------------------------------------------------

    def _is_network_source(self, source: str) -> bool:
        """Detecta si la fuente es un share SMB de red o unidad de red montada."""
        return source.startswith("//") or source.startswith("\\\\") or "/stepad-network/" in source

    def _parse_network_source(self, source: str) -> dict | None:
        """Parsea un path SMB: //host/share/subfolder → {host, share, subfolder}."""
        clean = source.replace("\\", "/")
        if not clean.startswith("//"):
            return None
        parts = clean[2:].split("/")
        if len(parts) < 2:
            return None
        return {
            "host": parts[0],
            "share": parts[1],
            "subfolder": "/".join(parts[2:]) if len(parts) > 2 else "",
        }

    def _mount_point(self, job_id: int) -> Path:
        return Path(f"/mnt/stepad-backup-{job_id}")

    def _mount_share(self, job: Job, source: str) -> str | None:
        """Monta un share SMB como carpeta local. Retorna el punto de montaje o None si falla."""
        parsed = self._parse_network_source(source)
        if not parsed:
            return None
        mount_point = self._mount_point(job.get("id"))
        mount_point.mkdir(parents=True, exist_ok=True)
        user = job.get("smb_user", "")
        password = job.get("smb_password", "")
        # Auto-fetch credentials from network unit if empty
        if not user and "/stepad-network/" in source:
            try:
                from backend.shares.services.network_unit_service import NetworkUnitService
                nu_svc = NetworkUnitService()
                letter = source.split("/stepad-network/")[-1].strip("/").split("/")[0]
                for u in nu_svc._load().get("units", []):
                    if u.get("letter") == letter:
                        user = u.get("user", "")
                        password = u.get("password", "")
                        break
            except Exception:
                pass
        opts = f"uid=0,gid=0,iocharset=utf8,vers=3.0,nobrl,soft,rw,timeo=50,retrans=1,echo_interval=5"
        if user:
            opts = f"username={user},password={password},{opts}"
        else:
            opts = f"guest,{opts}"
        cmd = ["mount", "-t", "cifs", f"//{parsed['host']}/{parsed['share']}", str(mount_point), "-o", opts]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            if parsed["subfolder"]:
                return str(mount_point / parsed["subfolder"])
            return str(mount_point)
        else:
            logger.error("Failed to mount //%s/%s: %s", parsed["host"], parsed["share"], result.stderr)
            return None

    def _unmount_share(self, job: Job) -> None:
        """Desmonta un share SMB."""
        mount_point = self._mount_point(job.get("id"))
        if mount_point.exists():
            subprocess.run(["umount", str(mount_point)], capture_output=True, timeout=10)
            try:
                mount_point.rmdir()
            except Exception:
                pass

    def _ensure_network_unit_mounted(self, source: str) -> bool:
        """Monta la unidad de red registrada que da origen a `source`.

        Acepta rutas como ``/mnt/stepad-network/M/subcarpeta`` y usa la
        configuración de ``network_units.json`` (credenciales incluidas).
        evitar ``NetworkUnitService.list_units()``: ahí se marca
        "montada" con ``is_mount()``, una syscall que cuelga en D-state si el
        share está caído. Devuelve True si el origen quedó montado y legible.
        """
        base = "/mnt/stepad-network/"
        if "/stepad-network/" not in source:
            return False
        try:
            raw = source.split("/stepad-network/", 1)[1]
            letter = raw.split("/", 1)[0].strip().upper()
        except Exception:
            return False
        if not letter:
            return False
        try:
            config = json.loads(
                Path("/etc/stepad/network_units.json").read_text(encoding="utf-8")
            )
        except Exception:
            return False
        unit = None
        for candidate in config.get("units", []):
            if (candidate.get("letter") or "").upper() == letter:
                unit = candidate
                break
        if not unit:
            return False
        mount_point = Path(base + letter)
        mount_point.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(mount_point, 0o755)
        except Exception:
            pass
        user = unit.get("user", "")
        password = unit.get("password", "")
        opts = f"uid=0,gid=0,iocharset=utf8,vers=3.0,nobrl,soft,rw,timeo=50,retrans=1,echo_interval=5"
        if user:
            opts = f"username={user},password={password},{opts}"
        else:
            opts = f"guest,{opts}"
        try:
            host = unit.get("host", "")
            share = unit.get("share", "")
            cmd = ["mount", "-t", "cifs", f"//{host}/{share}", str(mount_point), "-o", opts]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
            ok = result.returncode == 0
        except (subprocess.TimeoutExpired, OSError):
            ok = False
        return ok and self._dir_live(Path(base + letter))

    def _repositories(self) -> list[Path]:
        """Todos los repositorios reales en las bóvedas privadas."""
        repos: list[Path] = []
        for vault in self._vaults():
            store = vault / BACKUP_SUBDIR
            if not store.is_dir():
                continue
            # No tocar bóvedas que viven sobre un sistema de archivos no
            # montado (unidades de red desconectadas): recorrerlas o borrar
            # nada ahí solo produce errores de I/O y avisos falsos.
            if not self._dir_live(store):
                continue
            for child in store.iterdir():
                if child.is_dir() and child.name.startswith("job-"):
                    repos.append(child)
        return repos

    def _dir_live(self, path: Path) -> bool:
        """True si el directorio es legible (evita cifs desconectados que
        cuelgan en D-state al hacer stat/readdir).

        Hacer ``os.stat``/``os.path.ismount``/``iterdir`` sobre un share CIFS
        cuyo servidor se cayó puede bloquear el hilo en kernel (D-state) sin
        que ningún timeout de Python ayude. La prueba corre en un thread
        aparte y se abandona a los 2s: si cuelga, el resto del servicio
        sigue operando (solo ese thread queda varado hasta que el kernel
        aborte por timeo)."""
        path = Path(path)

        # Confirmar que el directorio (o un ancestro) figura como mount real:
        # leer /proc/mounts es instantáneo y NUNCA se cuelga, a diferencia de
        # os.path.ismount() que hace una syscall al filesystem sujeto a fallo.
        if "/stepad-network/" in str(path):
            probe_path = path
            while True:
                if mount_point_name(probe_path):
                    break
                parent = probe_path.parent
                if parent == probe_path:
                    return False
                probe_path = parent

        outcome: list[bool] = []

        def _probe():
            try:
                for _ in Path(path).iterdir():
                    break
                outcome.append(True)
            except OSError:
                outcome.append(False)

        probe_thread = threading.Thread(target=_probe, daemon=True)
        probe_thread.start()
        probe_thread.join(timeout=2.0)
        if probe_thread.is_alive():
            # Cifs sin respuesta: considerar no disponible y seguir.
            return False
        return bool(outcome and outcome[0])

    def _used_bytes(self) -> int:
        total = 0
        for repo in self._repositories():
            if self._is_network_source(str(repo)):
                continue
            try:
                result = subprocess.run(
                    ["du", "-sb", str(repo)],
                    capture_output=True, text=True, timeout=5,
                )
                if result.returncode == 0:
                    total += int(result.stdout.split()[0])
            except Exception:
                pass
        return total

    def _vault_disk(self, vault: Path) -> dict | None:
        try:
            disk = self._disk_usage_with_timeout(vault, timeout=5)
            return {
                "path": str(vault),
                "total_bytes": disk.total,
                "used_bytes": disk.used,
                "free_bytes": disk.free,
                "free_pct": round(100 * disk.free / disk.total, 1) if disk.total else 100.0,
                "used_human": _human_bytes(disk.used),
                "total_human": _human_bytes(disk.total),
            }
        except Exception:
            return None

    def _disk_usage_with_timeout(self, path: Path, timeout: float = 5) -> "os.statvfs_result | None":
        result: list = []

        def _probe():
            try:
                result.append(shutil.disk_usage(path))
            except Exception:
                result.append(None)

        thread = threading.Thread(target=_probe, daemon=True)
        thread.start()
        thread.join(timeout=timeout)
        if thread.is_alive() or not result:
            return None
        return result[0]

    # ------------------------------------------------------------------
    # restic commands
    # ------------------------------------------------------------------

    def _password(self) -> str:
        # Fuente única y centralizada: si la clave falta en el env, se
        # restaura desde los backups del actualizador; solo se genera
        # nueva si no existe NINGUNA copia, y entonces se persiste en
        # todos los sitios a la vez. Evita que un update o reinicio
        # vuelva a huérfanar los repositorios.
        from backend.core.config.secret_manager import get_restic_password
        return get_restic_password()

    def _env(self) -> dict:
        return {
            **os.environ,
            "RESTIC_PASSWORD": self._password(),
            "LC_ALL": "C",
            "LANG": "C",
        }

    def _restic(self, job: Job, args: list[str], *, timeout: int = 3600) -> subprocess.CompletedProcess:
        command = ["restic", "-r", str(self._repo_path(job)), *args]
        job_id = int(job.get("id") or 0)
        proc = subprocess.Popen(
            command,
            env=self._env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        self._procs[job_id] = proc
        deadline = time.monotonic() + timeout
        stdout_lines = []
        try:
            while True:
                code = proc.poll()
                if code is not None:
                    remaining = proc.stdout.read()
                    if remaining:
                        stdout_lines.append(remaining)
                    stdout = "".join(stdout_lines)
                    stderr = proc.stderr.read() if proc.stderr else ""
                    return subprocess.CompletedProcess(command, code, stdout, stderr)
                # Read available stdout for progress
                import select
                if select.select([proc.stdout], [], [], 0.1)[0]:
                    line = proc.stdout.readline()
                    if line:
                        stdout_lines.append(line)
                        # Parse progress from restic JSON output
                        try:
                            import json
                            data = json.loads(line)
                            if not isinstance(data, dict):
                                # restic imprime listas (p. ej. `snapshots
                                # --json`); no son progreso, se ignoran.
                                continue
                            if data.get("message_type") == "status":
                                self._progress[job_id] = self._rich_progress(
                                    data,
                                )
                            elif data.get("message_type") == "progress":
                                self._progress[job_id] = self._rich_progress(
                                    data,
                                )
                        except (json.JSONDecodeError, KeyError):
                            pass
                if job_id in self._cancel_requested:
                    self._terminate_proc(proc)
                    try:
                        stdout, stderr = proc.communicate(timeout=30)
                    except subprocess.TimeoutExpired:
                        stdout, stderr = "", ""
                    return subprocess.CompletedProcess(command, -9, stdout, stderr)
                if time.monotonic() >= deadline:
                    self._terminate_proc(proc)
                    raise subprocess.TimeoutExpired(command, timeout)
                time.sleep(0.5)
        finally:
            self._procs.pop(job_id, None)
            self._progress.pop(job_id, None)

    def _terminate_proc(self, proc: "subprocess.Popen") -> None:
        try:
            proc.terminate()
        except OSError:
            pass
        try:
            proc.kill()
        except OSError:
            pass

    def get_progress(self, job_id: int) -> dict:
        """Devuelve el progreso actual de un respaldo en curso."""
        progress = self._progress.get(job_id, {})
        running = job_id in self._procs
        return {
            "running": running,
            "files_done": progress.get("files_done", 0),
            "files_total": progress.get("files_total", 0),
            "bytes_done": progress.get("bytes_done", 0),
            "bytes_total": progress.get("bytes_total", 0),
            "current_file": progress.get("current_file", ""),
            "percent": progress.get("percent"),
            "elapsed_seconds": progress.get("elapsed_seconds"),
            "eta_seconds": progress.get("eta_seconds"),
        }

    @staticmethod
    def _rich_progress(data: dict) -> dict:
        """Progreso enriquecido con porcentaje y tiempo restante estimado.

        restic ``--json`` informa (campo a campo) ``percent_done``,
        ``bytes_done``/``total_bytes_processed`` y ``seconds_elapsed``;
        cuando no trae el total se estima con la velocidad media de bytes."""
        base = {
            "files_done": data.get("files_done", 0),
            "files_total": data.get("files_total", 0),
            "bytes_done": data.get("bytes_done", 0),
            "bytes_total": data.get("bytes_total", 0),
            "current_file": (
                data.get("current_files", [""])[0]
                if data.get("current_files")
                else ""
            ),
        }

        percent = data.get("percent_done")
        # restic informa percent_done como fracción (0.0-1.0); normalizamos.
        if percent is not None:
            try:
                percent = float(percent)
            except (TypeError, ValueError):
                percent = None
            else:
                if percent <= 1.0:
                    percent = percent * 100.0
                percent = round(min(100.0, max(0.0, percent)), 1)
        if percent is None and data.get("total_files_processed"):
            done = int(data.get("files_done") or 0)
            total = int(data.get("total_files_processed") or 0)
            percent = round(100.0 * done / total, 1) if total else None

        base["percent"] = percent
        elapsed = data.get("seconds_elapsed")
        if elapsed is not None:
            base["elapsed_seconds"] = int(elapsed)

        eta = data.get("seconds_remaining")
        if eta is None and percent is not None:
            if percent > 0 and elapsed is not None:
                eta = int(round((elapsed / (percent / 100.0)) * (1 - percent / 100.0)))
            else:
                total_b = data.get("total_bytes_processed")
                if total_b and percent:
                    bytes_done = float(data.get("bytes_done") or 0)
                    elapsed_f = float(elapsed or 0)
                    if bytes_done > 0 and elapsed_f > 0 and percent < 100:
                        eta = int(round((total_b - bytes_done) * elapsed_f / bytes_done))
        if eta is not None:
            base["eta_seconds"] = max(0, int(eta))
        return base

    def _terminate_proc(self, proc: "subprocess.Popen") -> None:
        try:
            proc.terminate()
        except OSError:
            pass
        try:
            proc.kill()
        except OSError:
            pass

    def _ensure_repo(self, job: Job) -> None:
        repo = self._repo_path(job)
        repo.parent.mkdir(parents=True, exist_ok=True)
        if not repo.exists():
            repo.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(repo, 0o700)
            except Exception:
                pass
        # A fresh restic repo is initialized lazily on first successful run.
        probe = self._restic(job, ["snapshots", "--json"], timeout=60)
        if probe.returncode != 0:
            if "already locked" in (probe.stderr or ""):
                # Lock restante de un proceso anterior (cayó/colgado): se
                # libera para que el respaldo no quede esperando para siempre.
                self._restic(job, ["unlock"], timeout=60)
                probe = self._restic(job, ["snapshots", "--json"], timeout=60)
            if probe.returncode != 0:
                # Solo inicializar si el error es "no es un repositorio":
                # si y solo si restic no encuentra config. Si el repo ya
                # existe inicializado (aunque el probe falle por otra
                # razón: password distinta, daño, lock), NO se re-inicializa
                # — `restic init` en un repo existente falla con "config
                # file already exists" y rompe el respaldo innecesariamente.
                stderr = (probe.stderr or "").lower()
                looks_empty = (
                    "is there a repository" in stderr
                    or "does not look like a repository" in stderr
                    or (
                        "no repository" in stderr
                        and "password" not in stderr
                    )
                )
                if looks_empty:
                    init = self._restic(job, ["init"], timeout=120)
                    if init.returncode != 0:
                        init_err = (init.stderr or "").lower()
                        if "config file already exists" in init_err:
                            # Raza: otra corrida acabó de inicializar.
                            return
                        raise HTTPException(
                            status_code=500,
                            detail=f"No se pudo inicializar el repositorio restic: {init.stderr.strip()[:300]}",
                        )
                elif "wrong password" in stderr or "no key found" in stderr:
                    # La password guardada no abre este repo (rotó o se
                    # regeneró en algún reinicio). El respaldo no puede
                    # avanzar con un repo inaccesible: se descarta el
                    # repo huérfano (conservando los datos como
                    # .discarded-*) y se inicializa uno nuevo con la
                    # password actual, de modo que "Ejecutar ahora"
                    # siempre funcione.
                    try:
                        discard = repo.with_name(repo.name + ".discarded")
                        discard.parent.mkdir(parents=True, exist_ok=True)
                        if discard.exists():
                            import shutil
                            shutil.rmtree(discard)
                        os.replace(repo, discard)
                        logger.warning(
                            f"Repo inaccesible (password no coincide); "
                            f"movido a {discard} y se re-inicializa."
                        )
                    except Exception as error:
                        raise HTTPException(
                            status_code=500,
                            detail=(
                                "No se pudo re-crear el repositorio restic "
                                f"(password desincronizada): {error}"
                            ),
                        )
                    repo.mkdir(parents=True, exist_ok=True)
                    try:
                        os.chmod(repo, 0o700)
                    except Exception:
                        pass
                    init = self._restic(job, ["init"], timeout=120)
                    if init.returncode != 0:
                        raise HTTPException(
                            status_code=500,
                            detail=f"No se pudo inicializar el repositorio restic: {init.stderr.strip()[:300]}",
                        )

    def installed(self) -> bool:
        return bool(shutil.which("restic"))

    # ------------------------------------------------------------------
    # job CRUD + status
    # ------------------------------------------------------------------

    def list_jobs(self, db: Session = None) -> dict:
        jobs = self._all_jobs()

        vaults = self._vaults(db)
        repo_bytes = self._used_bytes()

        vaults_info = []
        total_free = 0
        total_size = 0
        for vault in vaults:
            info = self._vault_disk(vault)
            if info:
                vaults_info.append(info)
                total_free += info["free_bytes"]
                total_size += info["total_bytes"]

        free_pct = round(100 * total_free / total_size, 1) if total_size else 100.0

        return {
            "installed": self.installed(),
            "store_root": "Carpeta privada «Respaldo» de cada unidad",
            "store_used_bytes": repo_bytes,
            "store_used_human": _human_bytes(repo_bytes),
            "store_free_bytes": total_free,
            "store_free_pct": free_pct,
            "vaults": vaults_info,
            "jobs": [self._serialize(job) for job in jobs],
        }

    def _serialize(self, job: Job) -> dict:
        return {
            "id": job.get("id"),
            "name": job.get("name"),
            "source_exists": bool(
                (job.get("source_path") or "")
                and self._dir_live(Path(job.get("source_path") or ""))
            ),
            "destination_exists": bool(
                Path(str(job.vault or self._dest_folder(job.get("source_path") or ""))).parent.exists()
            ),
            "source_path": job.get("source_path"),
            "destination_path": str(job.vault or self._dest_folder(job.get("source_path") or "")),
            "repository_path": str(self._repo_path(job)),
            "enabled": bool(job.get("enabled")),
            "schedule_mode": job.get("schedule_mode"),
            "folder_id": job.get("folder_id"),
            "schedule_hour": job.get("schedule_hour"),
            "schedule_minute": job.get("schedule_minute"),
            "schedule_times": self._times_list(job),
            "interval_minutes": job.get("interval_minutes"),
            "retention_count": job.get("retention_count"),
            "prune_free_pct": job.get("prune_free_pct"),
            "last_backup_at": job.get("last_backup_at"),
            "running": job.get("id") in self._running_jobs,
            "running_since": self._running_since.get(job.get("id")),
            "last_result": job.get("last_result"),
            "skip_until": job.get("skip_until"),
            "last_snapshot_id": job.get("last_snapshot_id"),
            "last_bytes": job.get("last_bytes"),
            "consecutive_failures": int(job.get("consecutive_failures") or 0),
            "failing": bool(job.get("failure_alert_active")),
            "next_run": self._next_run(job),
        }

    def _next_run(self, job: Job) -> str | None:
        if not job.get("enabled"):
            return None
        if job.get("schedule_mode") == "interval":
            minutes = max(1, int(job.get("interval_minutes") or 60))
            return f"cada {minutes} min"
        if job.get("schedule_mode") == "on_change":
            return "al modificar archivos"
        times = self._times_list(job)
        if times:
            return ", ".join(times)
        return f"{int(job.get('schedule_hour') or 0):02d}:{int(job.get('schedule_minute') or 0):02d}"

    def _folder_size(self, path_str: str) -> int | None:
        """Tamaño aparente (bytes) de la carpeta origen, con timeout y caché
        corta. Devuelve None si no se pudo medir (red lenta, permisos)."""
        path = str(path_str)
        cache_key = "size:" + path
        cached = self._size_cache.get(cache_key)
        if cached and time.monotonic() - cached[0] < 300:
            return cached[1]

        is_network = "/stepad-network/" in path

        # Una unidad de red registrada pero desconectada aparece como carpeta
        # vacía: du la mediría como 0 bytes (engañoso) o fallaría. Mejor
        # reportar "no se pudo medir" y dejar claro que falta el mount.
        if not self._dir_live(Path(path)):
            self._last_size_error = (
                "unidad de red no montada"
                if is_network
                else "directorio no disponible"
            )
            self._size_cache[cache_key] = (time.monotonic(), None)
            return None

        result_box: list[int] = []

        def _run_du():
            try:
                r = subprocess.run(
                    ["du", "-sb", "--apparent-size", path],
                    capture_output=True,
                    text=True,
                    timeout=25,
                )
                if r.returncode == 0 and r.stdout:
                    first = r.stdout.splitlines()[0]
                    result_box.append(int(first.split()[0]))
            except (subprocess.TimeoutExpired, OSError, ValueError, IndexError):
                pass

        # En red el `du` puede quedarse en stat (cifs colgado); se ejecuta en
        # un hilo y se abandona si no respondió en unos segundos, para que el
        # guardado del respaldo nunca se congele por medir el origen.
        probe = threading.Thread(target=_run_du, daemon=True)
        probe.start()
        probe.join(timeout=(4.0 if is_network else 40.0))
        if probe.is_alive() or not result_box:
            self._last_size_error = (
                "unidad de red lenta o sin permisos"
                if is_network
                else "sin permisos"
            )
            self._size_cache[cache_key] = (time.monotonic(), None)
            return None

        size = result_box[0]
        self._size_cache[cache_key] = (time.monotonic(), size)
        return size

    def _vault_free_bytes(self, vault: Path) -> int | None:
        try:
            disk = self._disk_usage_with_timeout(vault, timeout=5)
            return disk.free if disk is not None else None
        except Exception:
            return None

    def space_check(self, source: str = "", destination: str = "") -> dict:
        """Compara el tamaño del origen con el espacio libre del destino."""
        src = (source or "").strip()
        dst = (destination or "").strip()
        free_bytes = None
        free_human = ""
        if dst:
            free_bytes = self._vault_free_bytes(Path(dst))
            if free_bytes is not None:
                free_human = _human_bytes(free_bytes)
        if not src or not self._dir_live(Path(src)):
            if src and "/stepad-network/" in src:
                note = (
                    "El origen es una unidad de red que no está disponible "
                    "(no montada o sin respuesta). Conectá la unidad (o "
                    "verificá que el equipo origen esté encendido) antes de "
                    "guardar el respaldo."
                )
            else:
                note = "No se pudo medir el origen (red lenta o sin permisos)."
            return {
                "source_size": None,
                "source_size_human": "",
                "free_bytes": free_bytes,
                "free_human": free_human,
                "sufficient": None,
                "missing_bytes": 0,
                "missing_pct": None,
                "note": note,
            }
        size = self._folder_size(src)
        if size is None:
            reason = getattr(self, "_last_size_error", None)
            if reason == "unidad de red no montada":
                note = (
                    "El origen es una unidad de red que no está montada. "
                    "Conectá la unidad (o verificá que el equipo origen esté "
                    "encendido) antes de guardar el respaldo."
                )
            elif reason == "unidad de red lenta o sin permisos":
                note = (
                    "El origen es una unidad de red y no se pudo medir su "
                    "contenido (lenta o sin permisos). Podés guardar igual: "
                    "el respaldo se validará al ejecutarse."
                )
            else:
                note = "No se pudo medir el origen (red lenta o sin permisos)."
            return {
                "source_size": None,
                "source_size_human": "",
                "free_bytes": free_bytes,
                "free_human": free_human,
                "sufficient": None,
                "missing_bytes": 0,
                "missing_pct": None,
                "note": note,
            }
        missing = max(0, size - (free_bytes or 0)) if free_bytes is not None else 0
        pct = round(100 * missing / size) if size else 0
        sufficient = (free_bytes is not None) and (free_bytes >= size)
        return {
            "source_size": size,
            "source_size_human": _human_bytes(size),
            "free_bytes": free_bytes,
            "free_human": free_human,
            "sufficient": sufficient,
            "missing_bytes": missing if not sufficient else 0,
            "missing_pct": pct if not sufficient else 0,
        }

    def _validate_create_space(self, source: str, vault: Path) -> None:
        """Bloquea crear el respaldo si el primer respaldo completo no entra."""
        size = self._folder_size(source)
        if size is None:
            return
        free = self._vault_free_bytes(vault)
        if free is None or free >= size:
            return
        missing = size - free
        pct = round(100 * missing / size) if size else 0
        raise HTTPException(
            status_code=400,
            detail=(
                "Falta espacio en el destino: el respaldo completo del origen "
                f"necesita {_human_bytes(size)} y solo hay {_human_bytes(free)} "
                f"libres (falta {_human_bytes(missing)}, ~{pct}%). "
                "Liberá espacio o elegí otro destino."
            ),
        )

    def _next_slot_at(self, job: Job, now: datetime) -> datetime:
        if job.get("schedule_mode") == "interval":
            minutes = max(1, int(job.get("interval_minutes") or 60))
            return now + timedelta(minutes=minutes)
        if job.get("schedule_mode") == "on_change":
            return now + timedelta(minutes=60)
        times = self._times_list(job)
        slots = []
        for raw in times:
            try:
                hh, mm = (int(x) for x in raw.split(":"))
            except Exception:
                continue
            slots.append(hh * 60 + mm)
        if not slots:
            slots = [
                int(job.get("schedule_hour") or 0) * 60
                + int(job.get("schedule_minute") or 0),
            ]
        minute_of_day = now.hour * 60 + now.minute
        future = [t for t in slots if t > minute_of_day]
        if future:
            t = min(future)
            return now.replace(hour=t // 60, minute=t % 60, second=0, microsecond=0)
        t = min(slots)
        day = now.date() + timedelta(days=1)
        return datetime(day.year, day.month, day.day, t // 60, t % 60)

    def _cancel_running_backup(self, job_id: int) -> bool:
        """Cancela un respaldo en curso de `job_id` (no pierde lo ya
        respaldado: restic retoma sin resubir). True si había uno corrido."""
        job_id = int(job_id or 0)
        if job_id not in self._running_jobs:
            return False
        self._cancel_requested.add(job_id)
        proc = self._procs.get(job_id)
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass
        return True

    def skip_to_next_slot(self, job_id: int) -> dict:
        """Pausa el job: cancela un respaldo en curso (si lo hay) y no
        vuelve a correr hasta la próxima hora programada.

        Es la acción «parar y retomar en el siguiente horario»: útil cuando
        se necesita detener el respaldo (ej. porque la gente vuelve a
        trabajar) sin perder lo ya respaldado — restic retoma luego sin
        resubir lo subido."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")

        cancelled = self._cancel_running_backup(job.get("id"))

        nxt = self._next_slot_at(job, now_ecuador())
        job["skip_until"] = nxt.isoformat()
        self._save_job(job)
        return {
            "cancelled": cancelled,
            "next_at": nxt.isoformat(),
            "next_label": nxt.strftime("%d/%m %H:%M"),
        }

    def stop_backup(self, job_id: int) -> dict:
        """Cancela el respaldo en curso: no avanza last_backup_at y el
        próximo corre en el siguiente horario programado."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        job_id = int(job.get("id") or 0)
        if job_id not in self._running_jobs:
            return {"running": False, "message": "No hay ningún respaldo en ejecución."}
        self._cancel_requested.add(job_id)
        proc = self._procs.get(job_id)
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass
        return {
            "running": True,
            "message": "Respaldo cancelado. El próximo correrá en su horario.",
        }

        """Devuelve el inodo de una ruta (para comparar hardlinks)."""
        try:
            return os.stat(path).st_ino
        except OSError:
            return None

    def _find_conflict(self, config: dict, source: str, exclude_id: int | None = None) -> tuple[dict | None, str]:
        """Busca un job cuya ruta se superponga con la fuente dada:
        coincidencia exacta → ('exact', record), subcarpeta/padre → ('parent_child', record),
        nada → (None, '')."""
        source_inode = self._inode(source)
        source_path = Path(source)
        for record in config.get("jobs", []):
            if exclude_id is not None and int(record.get("id") or 0) == int(exclude_id):
                continue
            existing = record.get("source_path") or ""
            if not existing:
                continue
            existing_inode = self._inode(existing)
            # Same inode → exact match (hardlink / same dir)
            if source_inode and existing_inode and source_inode == existing_inode:
                return record, "exact"
            existing_path = Path(existing)
            # Exact string match
            if source_path == existing_path:
                return record, "exact"
            # One is a parent of the other → conflict
            try:
                source_path.relative_to(existing_path)
                return record, "parent_child"
            except ValueError:
                pass
            try:
                existing_path.relative_to(source_path)
                return record, "parent_child"
            except ValueError:
                pass
        return None, ""

    def create_job(self, data, db: Session = None) -> dict:
        source = (getattr(data, "source_path", None) or "").strip()
        logger.info("create_job called: source=%s name=%s times=%s mode=%s",
                     source, getattr(data, "name", None),
                     getattr(data, "schedule_times", None),
                     getattr(data, "schedule_mode", None))

        # Validar fuente (local o red)
        is_network = self._is_network_source(source)
        # Auto-fill SMB credentials from network unit if not provided
        if is_network and "/stepad-network/" in source:
            try:
                from backend.shares.services.network_unit_service import NetworkUnitService
                nu_svc = NetworkUnitService()
                letter = source.split("/stepad-network/")[-1].strip("/")
                nu_data = nu_svc._load()
                for u in nu_data.get("units", []):
                    if u.get("letter") == letter:
                        if not getattr(data, "smb_user", None):
                            data.smb_user = u.get("user", "")
                        if not getattr(data, "smb_password", None):
                            data.smb_password = u.get("password", "")
                        break
            except Exception:
                pass
        if not is_network and (not source or not Path(source).is_dir()):
            logger.warning("create_job: source invalid: %s", source)
            raise HTTPException(
                status_code=400,
                detail="La ruta de origen no existe o no es un directorio.",
            )

        # Destino explícito elegido por el usuario (carpeta privada
        # «Respaldo» de la unidad destino). Si viene, tiene prioridad sobre
        # el destino automático (la bóveda de la unidad del origen).
        destination = (getattr(data, "destination_path", None) or "").strip()
        if destination:
            # El destino suele vivir en una partición "backup" que está
            # DESMONTADA (montaje por demanda). Se monta primero, no sea
            # que la validación de "existe la carpeta" falle por eso.
            self._mount_destination_if_backup(db, Path(destination))
            dest_path = Path(destination)
            if not dest_path.is_dir():
                logger.warning("create_job: invalid destination: %s", destination)
                raise HTTPException(
                    status_code=400,
                    detail="El destino no existe o no es un directorio.",
                )
            vault = dest_path
        elif is_network:
            local_vaults = [v for v in self._vaults() if "/stepad-network/" not in str(v)]
            vault = local_vaults[0] if local_vaults else (self._vaults()[0] if self._vaults() else None)
            if vault is None:
                raise HTTPException(status_code=400, detail="No hay unidades locales disponibles para respaldos.")
        else:
            vault = self._vault_for_source(source)
            if vault is None or not vault.is_dir():
                vault = self._create_vault_for_source(source)
            if vault is None or not vault.is_dir():
                logger.warning("create_job: no vault for source: %s (vault=%s)", source, vault)
                raise HTTPException(
                    status_code=400,
                    detail="La unidad del origen no tiene carpeta privada «Respaldo».",
                )
        # El destino DEBE estar en una partición de finalidad "backup"
        # (nunca se respalda sobre una compartida/privada).
        self._assert_destination_is_backup(db, vault)
        # Si el destino es una partición "backup" desmontada (montaje por
        # demanda), la monta y asegura la carpeta «Respaldo» antes de
        # validar espacio y guardar.
        if not self._mount_destination_if_backup(db, vault):
            raise HTTPException(
                status_code=400,
                detail=(
                    "No se pudo montar la partición de respaldo del "
                    "destino. Verificá que el disco esté conectado."
                ),
            )
        # Validar espacio: el respaldo inicial completo debe caber en el destino.
        self._validate_create_space(source, vault)

        with self._lock:
            config = self._load_config(vault)

            # Una sola programación por fuente: si la ruta ya tiene un job
            # (o un job padre/hijo) se edita ese en lugar de crear un duplicado.
            conflict, kind = self._find_conflict(config, source)
            # Si el user todavía no configuró ningún origen, la bóveda tiene
            # solo el job placeholder creado junto con la partición (source_path
            # vacío). En ese caso NO se crea un segundo job: se convierte el
            # placeholder en el respaldo real (se le asigna este origen), para
            # que nunca quede un job vacío mostrando "Origen no disponible".
            if conflict is None:
                for placeholder in config.get("jobs", []):
                    if not (placeholder.get("source_path") or "").strip():
                        conflict = placeholder
                        kind = "placeholder"
                        break
            if conflict is not None and kind == "parent_child":
                raise HTTPException(
                    status_code=400,
                    detail="Ya existe un respaldo para la ruta %s (o una carpeta padre/hijo). Solo se permite uno por carpeta." % (conflict.get("source_path") or ""),
                )
            if conflict is not None:
                job = Job(conflict, vault=vault)
                if kind == "placeholder":
                    job["source_path"] = source
            else:
                record = dict(_default_job())
                record.update({
                    "id": int(config.get("next_job_id") or 1),
                    "name": (getattr(data, "name", None) or "").strip() or Path(source).name,
                    "source_path": source,
                    "enabled": True if getattr(data, "enabled", None) is None else bool(data.enabled),
                    "smb_user": getattr(data, "smb_user", None) or "",
                    "smb_password": getattr(data, "smb_password", None) or "",
                })
                record["schedule_mode"] = (
                    data.schedule_mode
                    if getattr(data, "schedule_mode", None) == "interval"
                    else "daily"
                )
                name_exists = any(
                    r.get("name") == record["name"] and r.get("source_path") != source
                    for r in config.get("jobs", [])
                )
                if name_exists:
                    raise HTTPException(status_code=400, detail="Ya existe un respaldo con ese nombre.")
                config["next_job_id"] = int(record["id"]) + 1
                config.setdefault("jobs", []).append(record)
                job = Job(record, vault=vault)

            self._apply_job_data(job, data)
            config["jobs"] = [
                dict(r) for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id"))
            ]
            config["jobs"].append(dict(job))
            self._save_config(vault, config)

        self._dedupe_by_source(vault, source, job)
        self._sync_folder_policy(db, job)
        return self._serialize(job)

    def _apply_job_data(self, job: Job, data) -> None:
        if getattr(data, "name", None) is not None:
            job["name"] = (data.name or "").strip() or job.get("name") or ""
        if getattr(data, "smb_user", None) is not None:
            job["smb_user"] = (data.smb_user or "").strip()
        if getattr(data, "smb_password", None) is not None:
            job["smb_password"] = data.smb_password or ""
        if getattr(data, "enabled", None) is not None:
            job["enabled"] = bool(data.enabled)
        if getattr(data, "schedule_mode", None) is not None:
            if data.schedule_mode == "on_change":
                # Riesgo de ransomware: respaldar "al cambiar archivos"
                # podría guardar versiones modificadas por el virus. Solo
                # se respalda por horario.
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "El modo «al cambiar archivos» no está disponible: "
                        "por seguridad solo se respalda por horario."
                    ),
                )
            if data.schedule_mode not in ("daily", "interval"):
                raise HTTPException(status_code=400, detail="schedule_mode inválido.")
            job["schedule_mode"] = data.schedule_mode
        if getattr(data, "schedule_hour", None) is not None:
            job["schedule_hour"] = int(data.schedule_hour)
        if getattr(data, "schedule_minute", None) is not None:
            job["schedule_minute"] = int(data.schedule_minute)
        if getattr(data, "schedule_times", None) is not None:
            normalized = self._normalize_times(data.schedule_times)
            if normalized:
                job["schedule_times"] = normalized
                job["schedule_mode"] = "daily"
            elif job.get("schedule_mode") == "daily":
                job["schedule_times"] = None
        if getattr(data, "interval_minutes", None) is not None:
            job["interval_minutes"] = max(15, int(data.interval_minutes))
        if getattr(data, "retention_count", None) is not None:
            job["retention_count"] = max(1, int(data.retention_count))
        if getattr(data, "prune_free_pct", None) is not None:
            job["prune_free_pct"] = max(5, min(80, int(data.prune_free_pct)))

    def _dedupe_by_source(self, vault: Path, source: str, keep: Job) -> None:
        """Una sola programación por fuente: elimina duplicados y subcarpetas
        que queden cubiertas por el job mantenido."""
        source_inode = self._inode(source)
        source_path = Path(source)
        with self._lock:
            config = self._load_config(vault)
            kept: list[dict] = []
            for record in config.get("jobs", []):
                if int(record.get("id") or 0) == int(keep.get("id") or 0):
                    kept.append(record)
                    continue
                existing_source = record.get("source_path") or ""
                if not existing_source:
                    kept.append(record)
                    continue
                existing_inode = self._inode(existing_source)
                # Same inode → duplicate (hardlink)
                if source_inode and existing_inode and source_inode == existing_inode:
                    dup = Job(record, vault=vault)
                    self._remove_repo(dup)
                    continue
                existing_path = Path(existing_source)
                # Keep if not related (no parent/child)
                is_related = False
                try:
                    source_path.relative_to(existing_path)
                    is_related = True
                except ValueError:
                    pass
                try:
                    existing_path.relative_to(source_path)
                    is_related = True
                except ValueError:
                    pass
                if is_related:
                    dup = Job(record, vault=vault)
                    self._remove_repo(dup)
                    continue
                kept.append(record)
            config["jobs"] = kept
            self._save_config(vault, config)

    def update_job(self, job_id: int, data, db: Session = None) -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        # Rechazar cambio de destino: el repo de restic ya vive en la
        # carpeta Respaldo del job.
        requested_dest = getattr(data, "destination_path", None)
        if requested_dest:
            dest = (requested_dest or "").strip()
            if dest:
                resolved = self._vault_from_destination_path(dest, db)
                if (
                    resolved is None
                    or Path(str(job.vault)).resolve() != Path(str(resolved)).resolve()
                ):
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            "El destino de un respaldo ya creado no se puede "
                            "cambiar; creá uno nuevo respaldando otra vez."
                        ),
                    )
        new_source = getattr(data, "source_path", None)
        if new_source is not None:
            source = (new_source or "").strip()
            if not source:
                # Origen en blanco: solo se permite conservar el actual.
                # El origen se elige UNA vez; los cambios de horario no
                # deben exigirlo de nuevo.
                has_existing = bool((job.get("source_path") or "").strip())
                if not has_existing:
                    raise HTTPException(
                        status_code=400,
                        detail="Elegí el origen a respaldar (la primera vez que configurás este respaldo).",
                    )
                source = job["source_path"]
            if not Path(source).is_dir():
                raise HTTPException(status_code=400, detail="La ruta de origen no es válida.")
            vault = self._vault_for_source(source)
            if vault is None or not vault.is_dir():
                raise HTTPException(status_code=400, detail="La unidad no tiene carpeta Respaldo.")
            config = self._load_config(vault)
            conflict, kind = self._find_conflict(config, source, exclude_id=job_id)
            if conflict is not None and kind == "parent_child":
                raise HTTPException(
                    status_code=400,
                    detail=f"Ya existe un respaldo para la ruta {conflict.get('source_path')} (o una carpeta padre/hijo).",
                )
            job["source_path"] = source
            job.vault = vault
        with self._lock:
            self._apply_job_data(job, data)
            self._save_job_locked(job)
        # «Desactivar» también detiene un respaldo en curso: lo ya
        # respaldado se conserva y, al reactivar, restic retoma sin resubir.
        enabled_req = getattr(data, "enabled", None)
        if enabled_req is False:
            cancelled = self._cancel_running_backup(job.get("id"))
            if cancelled:
                logger.info(
                    "Respaldo %s desactivado; se canceló la ejecución en curso.",
                    job.get("name"),
                )
        if new_source is not None:
            self._dedupe_by_source(job.vault, job["source_path"], job)
        self._sync_folder_policy(db, job)
        return self._serialize(job)

    def delete_job(self, job_id: int) -> None:
        """Elimina SOLO la programación (no toca los datos del respaldo).

        La partición de respaldo es la entidad que conserva el repo: quitar
        una programación nunca borra el histórico. Para borrar también los
        datos se usa `delete_job_and_repo` con confirmación explícita.
        """
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        with self._lock:
            config = self._load_config(job.vault)
            config["jobs"] = [
                r for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            self._save_config(job.vault, config)
        # NO se llama a _remove_repo: los datos pertenecen a la partición.

    def delete_job_and_repo(self, job_id: int, *, confirm: str) -> dict:
        """Borra la programación Y el repositorio restic de ese respaldo.

        Es la única vía de perder el histórico; exige confirmación explícita
        (confirm == "ELIMINAR") y avisa que incluye perder el acceso a la
        información respaldada.
        """
        if (confirm or "").strip().upper() != "ELIMINAR":
            raise HTTPException(
                status_code=400,
                detail=("Para borrar el respaldo y sus datos escribe ELIMINAR."),
            )
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        # No borrar un repo que está en ejecución.
        if job.get("id") in self._running_jobs:
            raise HTTPException(
                status_code=400,
                detail="El respaldo está en ejecución; desactívalo/espéralo antes de borrar sus datos.",
            )
        with self._lock:
            config = self._load_config(job.vault)
            config["jobs"] = [
                r for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            self._save_config(job.vault, config)
        repo = self._repo_path(job)
        removed = repo.exists() and repo.is_dir()
        if removed:
            try:
                shutil.rmtree(repo)
            except Exception as error:
                logger.warning("No se pudo borrar repo %s: %s", repo, error)
                raise HTTPException(
                    status_code=500,
                    detail=f"No se pudo borrar el repositorio: {error}",
                )
        return {
            "success": True,
            "programming_removed": True,
            "data_removed": removed,
            "message": (
                "Programación eliminada"
                + (" y datos del respaldo borrados." if removed else ".")
            ),
        }

    def delete_jobs_for_folder(self, folder_id: int) -> None:
        """Elimina la programación de los jobs de una carpeta (sin tocar
        los repos; los datos quedan en la partición de respaldo)."""
        for vault in self._vaults():
            config = self._load_config(vault)
            victims = [
                r for r in config.get("jobs", []) if int(r.get("folder_id") or 0) == int(folder_id or 0)
            ]
            if not victims:
                continue
            alive = [
                r for r in config.get("jobs", []) if int(r.get("folder_id") or 0) != int(folder_id or 0)
            ]
            with self._lock:
                config["jobs"] = alive
                self._save_config(vault, config)

    def delete_jobs_for_source(self, source_path: str) -> None:
        """Elimina la programación de los jobs apuntando a ese origen (no
        toca los repos; los datos quedan en la partición de respaldo)."""
        if not source_path:
            return
        for vault in self._vaults():
            config = self._load_config(vault)
            victims = [
                r for r in config.get("jobs", []) if r.get("source_path") == source_path
            ]
            if not victims:
                continue
            alive = [
                r for r in config.get("jobs", []) if r.get("source_path") != source_path
            ]
            with self._lock:
                config["jobs"] = alive
                self._save_config(vault, config)

    def _remove_repo(self, job: Job) -> None:
        repo = self._repo_path(job)
        if repo.exists():
            try:
                shutil.rmtree(repo)
            except Exception as error:
                logger.warning("Could not remove repo %s: %s", repo, error)

    # ------------------------------------------------------------------
    # folder policy bridge (the config file is the source of truth; the
    # folder fields in the DB are only a read-only reflection)
    # ------------------------------------------------------------------

    def _find_folder_for_source(self, db: Session, source: str) -> NetworkShareFolder | None:
        if db is None or not source:
            return None
        from backend.shares.services.network_share_service import NetworkShareService

        svc = NetworkShareService()
        for folder in db.query(NetworkShareFolder).all():
            try:
                if svc._folder_path(db, folder) == source:
                    return folder
            except Exception:
                continue
        return None

    def _sync_folder_policy(self, db: Session, job: Job) -> None:
        """Refleja la programación del job (fuente de verdad) en la carpeta
        de la base de datos únicamente como caché de la interfaz."""
        folder = self._find_folder_for_source(db, job.get("source_path") or "")
        if folder is None:
            return
        folder.backup_mode = "on_change" if job.get("schedule_mode") == "on_change" else "times"
        folder.backup_retention = max(1, int(job.get("retention_count") or 7))
        if job.get("schedule_mode") == "daily":
            times = self._times_list(job)
            if times:
                folder.backup_times_per_day = max(1, min(24, len(times)))
        else:
            folder.backup_times_per_day = max(
                1, min(24, int(folder.backup_times_per_day or 1))
            )
        db.commit()

    def ensure_folder_job(self, db: Session, folder, source: str) -> None:
        """Convierte la política de respaldo de una carpeta en un job del
        archivo de configuración (bóveda). «off» elimina el job."""
        source = (source or "").strip()
        vault = self._vault_for_source(source) if source else None
        if folder is not None and getattr(folder, "backup_mode", None) == "off":
            if vault is not None and vault.is_dir():
                with self._lock:
                    config = self._load_config(vault)
                    victims = [
                        r for r in config.get("jobs", []) if r.get("source_path") == source
                    ]
                    if victims:
                        for record in victims:
                            self._remove_repo(Job(record, vault=vault))
                        config["jobs"] = [
                            r for r in config.get("jobs", []) if r.get("source_path") != source
                        ]
                        self._save_config(vault, config)
            return
        if vault is None or not vault.is_dir() or not source:
            return

        with self._lock:
            config = self._load_config(vault)
            existing = next(
                (r for r in config.get("jobs", []) if r.get("source_path") == source),
                None,
            )
            if existing is not None:
                job = Job(existing, vault=vault)
                job["enabled"] = True
                job["retention_count"] = max(
                    1, int(getattr(folder, "backup_retention", None) or job.get("retention_count") or 7)
                )
                job["folder_id"] = getattr(folder, "id", None)
            else:
                record = dict(_default_job())
                record.update({
                    "id": int(config.get("next_job_id") or 1),
                    "name": f"folder-{getattr(folder, 'id', '')}-{getattr(folder, 'name', '')}",
                    "source_path": source,
                    "enabled": True,
                    "folder_id": getattr(folder, "id", None),
                    "retention_count": max(1, int(getattr(folder, "backup_retention", None) or 7)),
                })
                if getattr(folder, "backup_mode", None) == "on_change":
                    record["schedule_mode"] = "on_change"
                    record["interval_minutes"] = None
                else:
                    record["schedule_mode"] = "interval"
                    times = max(1, min(24, int(getattr(folder, "backup_times_per_day", None) or 1)))
                    record["interval_minutes"] = max(15, 1440 // times)
                config["next_job_id"] = int(record["id"]) + 1
                config.setdefault("jobs", []).append(record)
                job = Job(record, vault=vault)

            config["jobs"] = [
                dict(r) for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            config["jobs"].append(dict(job))
            self._save_config(vault, config)

        self._dedupe_by_source(vault, source, job)
        self._sync_folder_policy(db, job)

    # ------------------------------------------------------------------
    # protección antiransomware durante respaldos "por horario"
    # ------------------------------------------------------------------

    def has_active_protected_backup(self) -> bool:
        """
        True mientras haya al menos un respaldo "por horario" (daily o
        interval) en ejecución. `share_integrity_watch_service` consulta
        esto para saltarse su escaneo mientras dure -- así el propio
        respaldo (lectura masiva del árbol de origen) nunca puede disparar
        el bloqueo antiransomware por error, y la ventana sin vigilancia
        dura exactamente lo que dura el respaldo, ni un segundo más.

        Deliberadamente NO cubre "on_change": ese modo queda pendiente de
        revisión por su propio riesgo de evasión y no debe ganar además
        una ventana de protección.
        """
        with self._lock:
            return self._active_protected_backups > 0

    def _begin_protected_backup(self) -> None:
        with self._lock:
            self._active_protected_backups += 1

    def _end_protected_backup(self) -> None:
        with self._lock:
            self._active_protected_backups = max(
                0, self._active_protected_backups - 1
            )

    # ------------------------------------------------------------------
    # bitácora de corridas (éxito/fallo, con logging del sistema)
    # ------------------------------------------------------------------

    def _append_history(
        self,
        job: Job,
        *,
        success: bool,
        message: str,
        bytes_added: int = 0,
        duration_seconds: float | None = None,
        trigger: str = "scheduled",
    ) -> None:
        entry = {
            "at": now_ecuador().isoformat(),
            "success": bool(success),
            "message": (message or "")[:500],
            "bytes_added": int(bytes_added or 0),
            "duration_seconds": (
                round(duration_seconds, 1)
                if duration_seconds is not None
                else None
            ),
            # "scheduled" (horario) | "manual" (botón Ejecutar ahora) |
            # "on_change" (pendiente/desactivado hoy).
            "trigger": trigger,
        }
        history = list(job.get("history") or [])
        history.append(entry)
        job["history"] = history[-HISTORY_LIMIT:]

        log_line = "Respaldo '%s' (job %s, %s): %s"
        if success:
            logger.info(log_line, job.get("name"), job.get("id"), trigger, entry["message"])
        else:
            logger.warning(log_line, job.get("name"), job.get("id"), trigger, entry["message"])

    def _finish_run(
        self,
        job: Job,
        *,
        success: bool,
        message: str,
        started_at: float,
        trigger: str,
        snapshot_id: str | None = None,
        bytes_added: int = 0,
        update_backup_time: bool = True,
    ) -> None:
        """Registra el resultado de una corrida (bitácora + log + guardado).

        `update_backup_time` preserva el comportamiento previo: un timeout,
        un error de restic o un fallo de montaje NO adelantan
        `last_backup_at`, así el job sigue "vencido" y se reintenta -- pero
        ahora con backoff (ver is_due/_backoff_elapsed) en vez de cada
        POLL_SECONDS sin límite.
        """
        duration = time.monotonic() - started_at
        job["last_result"] = (message or "")[:500]
        job["last_attempt_at"] = now_ecuador().isoformat()
        if update_backup_time:
            job["last_backup_at"] = now_ecuador().isoformat()
        if snapshot_id is not None:
            job["last_snapshot_id"] = (snapshot_id or "")[:64]
        if success:
            job["last_bytes"] = bytes_added
            job["consecutive_failures"] = 0
            if job.get("failure_alert_active"):
                job["failure_alert_active"] = False
                logger.info(
                    "Respaldo '%s' se recuperó tras fallos consecutivos.",
                    job.get("name"),
                )
        else:
            job["consecutive_failures"] = int(job.get("consecutive_failures") or 0) + 1
            if (
                job["consecutive_failures"] >= FAILURE_ALERT_THRESHOLD
                and not job.get("failure_alert_active")
            ):
                job["failure_alert_active"] = True
                self._raise_failure_alert(job, message)
        self._append_history(
            job,
            success=success,
            message=message,
            bytes_added=bytes_added,
            duration_seconds=duration,
            trigger=trigger,
        )
        self._save_job(job)

    def _raise_failure_alert(self, job: Job, message: str) -> None:
        """Alerta cuando un job acumula FAILURE_ALERT_THRESHOLD fallos
        consecutivos. Antes de esto, un respaldo roto por cualquier motivo
        que no fuera "la carpeta desapareció" fallaba en silencio -- nadie
        se enteraba a menos que abriera manualmente el historial de ESE
        job en particular.
        """
        try:
            db = SessionLocal()
            try:
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type=BACKUP_FAILING_ALERT,
                    severity="warning",
                    title=f"Respaldo fallando: {job.get('name')}",
                    message=(
                        f"El respaldo «{job.get('name')}» lleva "
                        f"{job.get('consecutive_failures')} intentos "
                        f"fallidos consecutivos. Último error: {message}"
                    )[:500],
                )
                db.commit()
                logger.warning(
                    "Alerta: respaldo '%s' fallando repetidamente (%s intentos).",
                    job.get("name"), job.get("consecutive_failures"),
                )
            finally:
                db.close()
        except Exception as error:
            logger.warning("No se pudo crear alerta de respaldo fallido: %s", error)

    def job_history(self, job_id: int) -> list[dict]:
        """Bitácora del job, más reciente primero."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        return list(reversed(job.get("history") or []))

    # ------------------------------------------------------------------
    # run / snapshots / files / download
    # ------------------------------------------------------------------

    def run_backup(self, job_id: int, *, trigger: str = "manual") -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")

        started_at = time.monotonic()

        # Omitir si nada cambió desde el último respaldo real: así un horario o
        # un «Ejecutar ahora» sin modificaciones no crea versiones vacías.
        source = Path(job.get("source_path") or "")
        baseline = job.get("tree_hash")
        if self._dir_live(source) and baseline:
            current = self._tree_signature(source)
            if current and current == baseline:
                detail = "Sin cambios desde el último respaldo. No se creó versión."
                self._finish_run(
                    job,
                    success=True,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                )
                return {
                    "success": True,
                    "skipped": True,
                    "message": detail,
                    "bytes_added": 0,
                    "bytes_added_human": "0 B",
                }

        return self._launch_run_thread(
            job,
            started_at=started_at,
            trigger=trigger,
        )

    def _launch_run_thread(
        self,
        job: Job,
        *,
        started_at: float,
        trigger: str,
    ) -> dict:
        """Lanza el respaldo en segundo plano y vuelve al toque.

        El respaldo puede tardar mucho (especialmente desde un share de red):
        bloqueando la petición el usuario ve «Ejecutando respaldo…» para
        siempre. En su lugar se devuelve enseguida y el progreso/estado se
        consulta por el endpoint de progress y el listado de jobs."""
        worker = threading.Thread(
            target=self._run_backup_in_thread,
            args=(job,),
            kwargs={"started_at": started_at, "trigger": trigger},
            name=f"share-backup-{job.get('id')}",
            daemon=True,
        )
        worker.start()
        return {
            "success": True,
            "running": True,
            "message": "Respaldo en curso…",
            "job_id": job.get("id"),
        }

    def _backup_volume_for_path(
        self,
        vault: Path | str | None,
    ):
        """
        Si la bóveda de destino vive dentro de una partición registrada
        con rol "backup", devuelve el NetworkShareVolume. Los roles
        "shared" / "private" no aplican aquí (los primeros quedan
        siempre montados; las privadas las gestiona la web).
        """
        if not vault:
            return None
        try:
            vault_str = str(vault).strip()
            db = SessionLocal()
            try:
                for volume in db.query(NetworkShareVolume).all():
                    purpose = getattr(volume, "purpose", "shared") or "shared"
                    if purpose != "backup":
                        continue
                    mp = str(volume.mountpoint or "").rstrip("/")
                    if mp and vault_str.startswith(mp + "/"):
                        return volume
                return None
            finally:
                db.close()
        except Exception as error:
            logger.warning("_backup_volume_for_path: %s", error)
            return None

    def _mount_backup_dest(self, job: Job) -> dict | None:
        """
        Monta por demanda la partición "backup" que contiene la bóveda
        destino de este job. Devuelve {"volume": name, "mounted_now": bool}
        o None si no aplica (no es backup).
        """
        vault = job.vault or self._dest_folder(job.get("source_path") or "")
        volume = self._backup_volume_for_path(vault)
        if volume is None:
            return None
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        provider = ShareDiskMountProvider()
        if not provider.is_mounted_at(volume.mountpoint):
            result = provider.mount_now(
                uuid=volume.device_uuid,
                mountpoint=volume.mountpoint,
            )
            if not result.get("success"):
                raise HTTPException(
                    status_code=500,
                    detail=(
                        f"No se pudo montar la partición de respaldo "
                        f"«{volume.name}»: {result.get('message', '')}"
                    ),
                )
            return {
                "volume": volume.name,
                "mounted_now": True,
                "mountpoint": volume.mountpoint,
            }
        return {
            "volume": volume.name,
            "mounted_now": False,
            "mountpoint": volume.mountpoint,
        }

    def _unmount_backup_dest(self, job: Job) -> None:
        """Desmonta la partición "backup" destino tras el respaldo."""
        vault = job.vault or self._dest_folder(job.get("source_path") or "")
        volume = self._backup_volume_for_path(vault)
        if volume is None:
            return
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        provider = ShareDiskMountProvider()
        if provider.is_mounted_at(volume.mountpoint):
            provider.unmount_now(volume.mountpoint)

    def _run_backup_in_thread(
        self,
        job: Job,
        *,
        started_at: float,
        trigger: str,
    ) -> None:
        with self._lock:
            if job.get("id") in self._running_jobs:
                return
            self._running_jobs.add(job.get("id"))
            self._running_since[job.get("id")] = now_ecuador().isoformat()

        protected = job.get("schedule_mode") != "on_change"
        if protected:
            self._begin_protected_backup()

        # Cola anti-solapamiento: si otro respaldo programado/manual está
        # corriendo, éste ESPERA su turno (se encola) en vez de correr en
        # paralelo y competir por disco/red. Se libera solo.
        if protected:
            waited = 0
            while True:
                with self._lock:
                    other_running = any(
                        other != job.get("id")
                        for other in self._running_jobs
                    )
                    self_job_running = job.get("id") in self._running_jobs
                if not self_job_running:
                    # El job fue cancelado/eliminado mientras esperaba.
                    return
                if not other_running:
                    break
                if waited >= 60 * 60:
                    logger.warning(
                        "Respaldo %s esperó 60 min por otro respaldo; "
                        "arranca de todos modos.",
                        job.get("name"),
                    )
                    break
                time.sleep(5)
                waited += 5

        mounted_dest = None
        try:
            mounted_dest = self._mount_backup_dest(job)
            try:
                self._run_backup_locked(
                    job,
                    started_at=started_at,
                    trigger=trigger,
                )
            except HTTPException as error:
                self._finish_run(
                    job,
                    success=False,
                    message=error.detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
            except Exception as error:
                logger.exception(
                    "Respaldo %s falló inesperadamente: %s",
                    job.get("name"), error,
                )
                self._finish_run(
                    job,
                    success=False,
                    message=f"Error inesperado: {error}",
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
        finally:
            # La partición "backup" solo está montada durante la corrida:
            # se desmonta al terminar (éxito o fallo) para que quede
            # inaccesible al resto del tiempo (anti-ransomware).
            if mounted_dest:
                try:
                    self._unmount_backup_dest(job)
                except Exception as error:
                    logger.warning(
                        "No se pudo desmontar partición de respaldo: %s",
                        error,
                    )
            with self._lock:
                self._running_jobs.discard(job.get("id"))
                self._running_since.pop(job.get("id"), None)
            if protected:
                self._end_protected_backup()

    def _run_backup_locked(self, job: Job, *, started_at: float, trigger: str) -> dict:
        if not self.installed():
            raise HTTPException(
                status_code=400,
                detail="restic no está instalado. Instala el paquete: apt-get install -y restic",
            )
        source = Path(job.get("source_path") or "")
        mounted = None

        # Mount network share if needed (only for SMB paths, not local mounts)
        if self._is_network_source(str(source)) and not str(source).startswith("/mnt/"):
            mounted = self._mount_share(job, str(source))
            if not mounted:
                detail = "No se pudo montar el share de red. Verifique credenciales y conectividad."
                self._finish_run(
                    job,
                    success=False,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
                return {"success": False, "message": detail}
            source = Path(mounted)
        elif "/stepad-network/" in str(source):
            # Unidad de red registrada (p. ej. /mnt/stepad-network/M). Se
            # ASEGURA el montaje siempre: un share puede quedar "fantasma"
            # (dir vacío sin acceso real) y restic correría contra una
            # carpeta vacía sin terminar bien el respaldo programado.
            needs_mount = not self._dir_live(source)
            if not needs_mount:
                try:
                    has_children = any(Path(source).iterdir())
                except OSError:
                    has_children = False
                if not has_children:
                    # Dir vacío: o el share no está montado de verdad o el
                    # equipo origen no lo expone. Forzamos (re)montaje.
                    needs_mount = True
            if needs_mount:
                if not self._ensure_network_unit_mounted(str(source)):
                    detail = (
                        f"La unidad de red del origen no está disponible "
                        f"({source}). Verifique que el equipo origen esté "
                        "encendido y conectado, y vuelva a intentar."
                    )
                    self._finish_run(
                        job,
                        success=False,
                        message=detail,
                        started_at=started_at,
                        trigger=trigger,
                        update_backup_time=False,
                    )
                    return {"success": False, "message": detail}
                source = Path(job.get("source_path") or "")

            # Tras montar, el origen DEBE traer datos: si sigue vacío, el
            # share no responde y un respaldo programado quedaría colgado.
            try:
                origin_empty = not any(Path(source).iterdir())
            except OSError:
                origin_empty = True
            if origin_empty:
                detail = (
                    f"El origen {source} está vacío o sin acceso al share "
                    "de red. Verifique que el equipo origen esté encendido "
                    "y vuelva a intentar."
                )
                self._finish_run(
                    job,
                    success=False,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
                return {"success": False, "message": detail}

        if not self._dir_live(source):
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        # Crear directorio del repo antes de verificar
        try:
            self._ensure_repo(job)
        except HTTPException:
            if mounted:
                self._unmount_share(job)
            raise

        # Verificar que el destino esté disponible
        repo = self._repo_path(job)
        dest_parent = repo.parent
        if not dest_parent.exists():
            detail = f"El destino del respaldo no está disponible ({dest_parent}). Verifique que el disco/USB esté conectado."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        # Verificar que se pueda escribir en el destino
        try:
            test_file = dest_parent / ".stepad_write_test"
            test_file.write_text("test")
            test_file.unlink()
        except (OSError, PermissionError) as e:
            detail = f"No se puede escribir en el destino ({dest_parent}): {e}. Verifique permisos y que el disco no esté en solo lectura."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}
        except HTTPException:
            if mounted:
                self._unmount_share(job)
            raise

        # Skip system/temp files that cause "device or resource busy"
        # on SMB mounts (hidden files, windows system files, etc.)
        args = [
            "backup",
            str(source),
            "--host", "stepad",
            "--tag", f"job:{job.get('id')}",
            "--exclude-caches",
            "--exclude", "desktop.ini",
            "--exclude", "Thumbs.db",
            "--exclude", ".DS_Store",
            "--exclude", "System Volume Information",
            "--exclude", "$RECYCLE.BIN",
            "--exclude", ".*",
            "--json",
        ]
        try:
            # 24 h de tope: un respaldo inicial grande (cientos de GB desde
            # una unidad de red lenta) no debe cortarse por el reloj. El
            # respaldo corre en segundo plano y el usuario puede cancelarlo
            # con «Parar» cuando quiera.
            result = self._restic(job, args, timeout=86400)
        except subprocess.TimeoutExpired:
            detail = "El respaldo tardó demasiado y se canceló."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}
        except Exception as error:
            detail = f"Error ejecutando restic: {error}"
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        if mounted:
            self._unmount_share(job)

        if job.get("id") in self._cancel_requested:
            self._cancel_requested.discard(job.get("id"))
            detail = "Respaldo cancelado por el usuario."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            return {"success": False, "cancelled": True, "message": detail}

        if result.returncode != 0:
            detail = f"restic falló: {result.stderr.strip()[:400]}"
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            return {"success": False, "message": detail}

        snapshot_id = None
        bytes_processed = 0
        bytes_added = 0
        for line in (result.stdout or "").splitlines():
            try:
                payload = json.loads(line)
            except Exception:
                continue
            if payload.get("message_type") == "summary":
                snapshot_id = payload.get("snapshot_id")
                bytes_processed = int(payload.get("total_bytes_processed") or 0)
                bytes_added = int(
                    payload.get("total_bytes_added_packed")
                    or payload.get("total_bytes_added")
                    or 0
                )
            elif payload.get("message_type") == "snapshot":
                snapshot_id = payload.get("snapshot_id") or payload.get("id") or snapshot_id

        fresh_hash = None
        if not self._is_network_source(str(source)):
            try:
                fresh_hash = self._tree_signature(source)
            except Exception:
                fresh_hash = None
        if fresh_hash is not None:
            job["tree_hash"] = fresh_hash
        elif "tree_hash" in job:
            # For network sources keep previous baseline if any, so the
            # early "sin cambios" skip still works without rescanning.
            job.setdefault("tree_hash", job.get("tree_hash"))
        job["source_missing_alerted"] = False

        detail = (
            f"OK  snapshot {snapshot_id[:12] if snapshot_id else 'n/a'} "
            f"+{_human_bytes(bytes_added)} nuevos · {_human_bytes(bytes_processed)} escaneados"
        )
        self._finish_run(
            job,
            success=True,
            message=detail,
            started_at=started_at,
            trigger=trigger,
            snapshot_id=snapshot_id,
            bytes_added=bytes_added,
        )

        self._enforce_retention_count(job)
        pruned = self._maybe_prune(job)

        return {
            "success": True,
            "snapshot_id": snapshot_id,
            "snapshot_short": snapshot_id[:12] if snapshot_id else None,
            "bytes_processed": bytes_processed,
            "bytes_human": _human_bytes(bytes_processed),
            "bytes_added": bytes_added,
            "bytes_added_human": _human_bytes(bytes_added),
            "pruned": pruned,
        }

    def list_snapshots(self, job_id: int) -> list[dict]:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            return []
        try:
            self._ensure_repo(job)
        except HTTPException:
            return []
        result = self._restic(job, ["snapshots", "--json"], timeout=120)
        if result.returncode != 0:
            return []
        try:
            rows = json.loads(result.stdout or "[]")
        except Exception:
            rows = []
        snapshots = []
        for row in rows:
            summary = row.get("summary") or {}
            data_added = summary.get("data_added") or summary.get("total_bytes_added_packed") or 0
            snapshots.append({
                "id": row.get("id", ""),
                "short_id": row.get("short_id", ""),
                "time_iso": to_iso_utc(self._parse_restic_time(row.get("time"))),
                "time": (row.get("time") or "")[:19].replace("T", " "),
                "hostname": row.get("hostname"),
                "tags": row.get("tags") or [],
                "paths": row.get("paths") or [],
                "files_new": summary.get("files_new"),
                "files_changed": summary.get("files_changed"),
                "files_unmodified": summary.get("files_unmodified"),
                "data_added": data_added,
                "data_added_human": _human_bytes(data_added),
                "total_bytes_processed": summary.get("total_bytes_processed"),
                "total_bytes_human": _human_bytes(summary.get("total_bytes_processed")),
            })
        snapshots.sort(key=lambda s: s.get("time") or "", reverse=True)
        return snapshots

    def _parse_restic_time(self, value) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except Exception:
            try:
                return datetime.fromtimestamp(value)
            except Exception:
                return None

    def _normalize_times(self, value) -> str | None:
        """Acepta list[str] ['HH:MM','HH:MM'] o str 'HH:MM,HH:MM'.
        Normaliza y valida horas 00-23 y minutos 00-59. Devuelve
        None si no hay horas validas."""
        if value is None:
            return None
        if isinstance(value, str):
            raw = [t.strip() for t in (value or "").split(",")]
        else:
            raw = [str(t).strip() for t in value]
        hours = []
        for part in raw:
            if not part:
                continue
            try:
                hh, mm = part.split(":")
                hh = int(hh)
                mm = int(mm)
            except Exception:
                continue
            if 0 <= hh <= 23 and 0 <= mm <= 59:
                hours.append(f"{hh:02d}:{mm:02d}")
        hours = sorted(set(hours))
        return ",".join(hours) if hours else None

    def _times_list(self, job: Job) -> list:
        """Devuelve la lista de horas HH:MM del job (schedule_times o el
        schedule_hour:minute clásico)."""
        times = []
        for part in (job.get("schedule_times") or "").split(","):
            part = part.strip()
            if part:
                times.append(part)
        if not times:
            times = [f"{int(job.get('schedule_hour') or 0):02d}:{int(job.get('schedule_minute') or 0):02d}"]
        return times

    def _parse_job_time(self, value) -> datetime | None:
        if not value:
            return None
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if parsed.tzinfo is not None:
                parsed = parsed.replace(tzinfo=None)
            return parsed
        except Exception:
            return None

    def _backoff_minutes(self, consecutive_failures: int) -> int:
        if consecutive_failures <= 0:
            return 0
        index = min(consecutive_failures - 1, len(FAILURE_BACKOFF_MINUTES) - 1)
        return FAILURE_BACKOFF_MINUTES[index]

    def _backoff_elapsed(self, job: Job, now: datetime) -> bool:
        """True si ya pasó suficiente tiempo desde el último intento
        fallido como para reintentar (ver FAILURE_BACKOFF_MINUTES)."""
        failures = int(job.get("consecutive_failures") or 0)
        if failures <= 0:
            return True
        last_attempt = self._parse_job_time(job.get("last_attempt_at"))
        if last_attempt is None:
            return True
        cooldown_minutes = self._backoff_minutes(failures)
        return (now - last_attempt).total_seconds() >= cooldown_minutes * 60

    def is_due(self, job: Job, now: datetime) -> bool:
        if not job.get("enabled"):
            return False
        skip_until = job.get("skip_until")
        if skip_until:
            try:
                if now < datetime.fromisoformat(skip_until):
                    return False
            except (TypeError, ValueError):
                pass
        if not self._backoff_elapsed(job, now):
            return False
        if job.get("schedule_mode") == "interval":
            # N backups a day -> run every 24h/N (interval_minutes).
            last = self._parse_job_time(job.get("last_backup_at"))
            if last is None:
                return True
            interval = max(1, int(job.get("interval_minutes") or 60))
            elapsed = (now - last).total_seconds()
            return elapsed >= interval * 60
        if job.get("schedule_mode") == "on_change":
            # Handled by the change watcher, never by the clock.
            return False
        # daily: run at each configured time, once per time per day.
        times = self._times_list(job)
        minute_of_day = now.hour * 60 + now.minute
        last = self._parse_job_time(job.get("last_backup_at"))
        # Elige la hora más reciente que ya pasó hoy (>= now).
        reached = None
        for raw in times:
            try:
                hh, mm = (int(x) for x in raw.split(":"))
            except Exception:
                continue
            t = hh * 60 + mm
            if t <= minute_of_day:
                reached = t if reached is None else max(reached, t)
        if reached is None:
            return False
        if last is None:
            # Nunca respaldado: solo corre exactamente en una hora programada
            # (la próxima). No corre por horas que YA pasaron hoy y no se
            # dispara en reintentos fuera de horario: hay que esperar al
            # siguiente horario programado.
            for raw in times:
                try:
                    hh, mm = (int(x) for x in raw.split(":"))
                except Exception:
                    continue
                if hh * 60 + mm == minute_of_day:
                    return True
            return False
        # Si ya se respaldó hoy a esa hora (o después), no repetir.
        if last.date() == now.date():
            last_min = last.hour * 60 + last.minute
            if last_min >= reached:
                return False
        return True

    def _tree_signature(self, root: Path) -> str | None:
        """Snapshot of (path, mtime, size) so on-change backups can detect edits.

        For network mounts (slow SMB/CIFS) this would rglob the whole tree
        and hang on D-state, so it returns None instead."""
        if self._is_network_source(str(root)):
            return None
        try:
            entries = []
            for path in sorted(root.rglob("*")):
                if path.is_dir():
                    continue
                stat = path.stat()
                rel = path.relative_to(root).as_posix()
                entries.append(f"{rel}:{stat.st_mtime_ns}:{stat.st_size}")
            return hashlib.sha256(
                "\n".join(entries).encode("utf-8", "replace")
            ).hexdigest()
        except OSError:
            return None

    def _maybe_run_on_change(self, job: Job) -> None:
        """Backup the source only when files changed since the last successful run."""
        if job.get("schedule_mode") != "on_change" or not job.get("enabled"):
            return
        source = Path(job.get("source_path") or "")
        if not source.is_dir():
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            if job.get("last_result") != detail:
                job["last_result"] = detail
                self._save_job(job)
            return

        signature = self._tree_signature(source)
        if signature is None:
            return
        if job.get("change_hash") is None:
            # First baseline: we don't run an unsolicited backup, we just
            # record the current state. From the next change on, we back up.
            job["change_hash"] = signature
            self._save_job(job)
            return
        if signature == job.get("change_hash"):
            return
        try:
            result = self.run_backup(job.get("id"), trigger="on_change")
            # Solo adelantar el baseline si el respaldo REALMENTE se hizo:
            # antes esto corría sin mirar result["success"], así que un
            # fallo (mount roto, restic caído) igual "marcaba como
            # respaldado" el estado actual del árbol -- si después no
            # cambiaba nada más, esos cambios sin respaldar quedaban
            # huérfanos para siempre, sin que el sistema volviera a
            # intentarlo.
            if not result.get("success"):
                logger.warning(
                    "On-change backup %s failed, baseline not advanced: %s",
                    job.get("name"), result.get("message"),
                )
                return
            # Refresh the baseline right after a successful run so the same
            # tree is not backed up again on the next tick.
            fresh = self._tree_signature(source)
            if fresh is not None:
                job["change_hash"] = fresh
                self._save_job(job)
            state = result.get("message", result)
            logger.info("On-change backup %s: %s", job.get("name"), state)
        except HTTPException as error:
            logger.warning(
                "On-change backup %s failed: %s", job.get("name"), error.detail
            )

    def _enforce_retention_count(self, job: Job) -> None:
        """Recorta el listado de versiones a `retention_count` después de
        CADA respaldo exitoso -- no solo cuando el disco se queda sin
        espacio (eso lo sigue haciendo _maybe_prune, ver abajo).

        Antes, "conserva N versiones" solo se cumplía de forma reactiva:
        con disco de sobra, se podían acumular muchas más versiones de
        las que el usuario configuró, porque nada las recortaba hasta que
        el espacio libre bajara de prune_free_pct. `forget --keep-last`
        SIN `--prune` es barato (solo quita snapshots del listado, no
        reclama espacio en disco todavía) así que hacerlo tras cada
        corrida no tiene el costo de I/O de una poda completa.
        """
        retention = max(1, int(job.get("retention_count") or 7))
        try:
            result = self._restic(
                job, ["forget", "--keep-last", str(retention)], timeout=120
            )
            if result.returncode != 0:
                logger.warning(
                    "No se pudo aplicar la retención de %s versiones para "
                    "'%s': %s",
                    retention, job.get("name"), result.stderr.strip()[:300],
                )
        except Exception as error:
            logger.warning(
                "Error aplicando retención para '%s': %s", job.get("name"), error
            )

    def _maybe_prune(self, job: Job) -> dict | None:
        repo = self._repo_path(job)
        if not repo.parent.exists():
            return None
        usage = shutil.disk_usage(repo.parent)
        if not usage.total:
            return None
        free_pct = 100 * usage.free / usage.total
        if free_pct >= float(job.get("prune_free_pct") or 15):
            return None
        return self.prune(job.get("id"))

    def prune(self, job_id: int) -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        retention = max(1, int(job.get("retention_count") or 7))
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        forget = self._restic(job, ["forget", "--keep-last", str(retention), "--prune"], timeout=7200)
        if forget.returncode != 0:
            logger.error("restic forget/prune failed: %s", forget.stderr)
        usage = shutil.disk_usage(self._repo_path(job).parent)
        free_pct = round(100 * usage.free / usage.total, 1) if usage.total else 100.0
        detail = (
            f"Se conservan las {retention} versiones más recientes y se "
            f"compactó el repositorio. Espacio libre: {free_pct}%."
            if forget.returncode == 0
            else f"La limpieza no terminó bien: {forget.stderr.strip()[:300]}"
        )
        job["last_result"] = detail[:500]
        self._save_job(job)
        return {"success": forget.returncode == 0, "message": detail, "free_pct": free_pct}

    def list_files(self, job_id: int, snapshot_id: str, prefix: str = "") -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"restic ls falló: {result.stderr.strip()[:300]}",
            )
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception:
            entries = []

        root = (job.get("source_path") or "/").rstrip("/")
        root_key = root.lstrip("/")
        prefix = (prefix or "").strip("/")
        base = prefix.split("/") if prefix else []
        folders: set[str] = set()
        files: list[dict] = []
        for entry in entries:
            rel = (entry.get("path") or "").lstrip("/")
            if root != "/":
                if rel == root_key:
                    continue
                if not rel.startswith(root_key + "/"):
                    continue
                rel = rel[len(root_key) + 1:]
            if not rel:
                continue
            parts = rel.split("/")
            if len(parts) != len(base) + 1:
                continue
            if parts[:len(base)] != base:
                continue
            item = parts[len(base)]
            full = f"{prefix}/{item}" if prefix else item
            if entry.get("type") == "dir":
                folders.add(item)
            else:
                files.append({
                    "name": item,
                    "path": full,
                    "size": entry.get("size"),
                    "size_human": _human_bytes(entry.get("size")),
                    "type": "file",
                })
            if len(folders) + len(files) > 3000:
                break

        def sort_key(item):
            return (item.get("name") or "").lower()

        return {
            "snapshot": snapshot_id,
            "prefix": prefix,
            "directories": sorted(folders, key=str.lower),
            "files": sorted(files, key=sort_key),
        }

    def _entry_is_dir(self, job: Job, snapshot_id: str, path: str) -> bool:
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            return False
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception:
            return False
        root = (job.get("source_path") or "/").rstrip("/")
        wanted = "/".join([
            seg for seg in [root, path.strip("/")] if seg.strip("/")
        ])
        for entry in entries:
            if (entry.get("path") or "").rstrip("/") == wanted.rstrip("/"):
                return entry.get("type") == "dir"
        return False

    @staticmethod
    def _parse_ndjson(stdout: str) -> list[dict]:
        rows = []
        for line in (stdout or "").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        return rows

    def restore_snapshot(
        self,
        job_id: int,
        snapshot_id: str,
        *,
        target: str | None = None,
        clean: bool = False,
    ) -> dict:
        """
        Restaura COMPLETA una versión (snapshot) del respaldo a su
        carpeta origen (o a un `target` que el usuario elija), con la
        estructura de carpetas tal cual quedó en esa foto.

        En desastre, la restauración se hace por la vía más rápida:
          - target vacío → restic escribe DIRECTAMENTE en la ruta
            absoluta original (`--target /`); una sola copia, sin
            staging intermedio.
          - target dado → restaura a staging y copia/mueve ahí (por si
            el árbol debe ir a otra raíz).

        `clean=True` vacía el destino ANTES de restaurar (restauración
        "limpia": el destino queda idéntico a la foto, sin archivos
        sobrantes). Por seguridad solo se aplica al destino elegido,
        nunca a rutas del sistema.
        """
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        if not snapshot_id:
            raise HTTPException(status_code=400, detail="Indica el snapshot a restaurar.")

        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))

        source = (job.get("source_path") or "").strip()
        if not source:
            raise HTTPException(status_code=400, detail="El respaldo no tiene origen.")

        # Destino final: el indicado o la carpeta origen del respaldo.
        destination = Path((target or source).strip() or source).resolve()
        if not str(destination).startswith(("/mnt/", "/media/", "/tmp/")):
            raise HTTPException(
                status_code=400,
                detail="El destino de restauración debe estar bajo /mnt, /media o /tmp.",
            )

        if clean and destination.exists():
            # Vacía el destino (mantiene la carpeta raíz) ANTES de restaurar.
            for item in destination.iterdir():
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                else:
                    try:
                        item.unlink()
                    except OSError:
                        pass

        import tempfile

        kwargs = {
            "env": self._env(),
            "capture_output": True,
            "timeout": 86400,
        }

        # Vía rápida (desastre): origen original -> escribir en la ruta
        # exacta. restic cuelga la ruta absoluta bajo target; con "/"
        # queda tal cual era.
        if not target:
            result = subprocess.run(
                [
                    "restic", "-r", str(self._repo_path(job)),
                    "restore", snapshot_id,
                    "--target", "/",
                ],
                **kwargs,
            )
            if result.returncode != 0:
                raise HTTPException(
                    status_code=500,
                    detail=f"restic restore falló: {result.stderr.strip()[:300]}",
                )
            return {
                "success": True,
                "job_id": job_id,
                "snapshot_id": snapshot_id,
                "restore_to": str(destination),
                "fast": True,
                "message": (
                    f"Versión {snapshot_id[:12]} restaurada directamente "
                    f"en «{destination}» con su estructura original."
                ),
            }

        # Vía con target explícito: staging + copia.
        staging = Path(tempfile.mkdtemp(prefix="stepad-restore-"))
        try:
            result = subprocess.run(
                [
                    "restic", "-r", str(self._repo_path(job)),
                    "restore", snapshot_id,
                    "--target", str(staging),
                ],
                **kwargs,
            )
            if result.returncode != 0:
                raise HTTPException(
                    status_code=500,
                    detail=f"restic restore falló: {result.stderr.strip()[:300]}",
                )

            relocated = []
            if staging.exists():
                wanted_suffix = str(Path(source)).rstrip("/").lstrip("/")
                candidates = []
                for candidate in staging.rglob("*"):
                    if candidate.is_dir():
                        candidate_rel = str(candidate.relative_to(staging)).rstrip("/")
                        if candidate_rel == wanted_suffix:
                            candidates.append(candidate)
                if candidates:
                    relocated = candidates
                else:
                    relocated = [staging]

            restored_any = False
            for tree_root in relocated:
                for item in tree_root.rglob("*"):
                    rel = item.relative_to(tree_root)
                    dest_item = (destination / rel) if rel.parts else destination
                    if item.is_dir():
                        dest_item.mkdir(parents=True, exist_ok=True)
                        continue
                    dest_item.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(item, dest_item)
                    restored_any = True

            if not restored_any:
                raise HTTPException(
                    status_code=500,
                    detail="El snapshot no contenía archivos para restaurar.",
                )
        finally:
            shutil.rmtree(staging, ignore_errors=True)

        return {
            "success": True,
            "job_id": job_id,
            "snapshot_id": snapshot_id,
            "restore_to": str(destination),
            "message": (
                f"Versión {snapshot_id[:12]} restaurada en "
                f"«{destination}» con su estructura original."
            ),
        }

    def download(self, job_id: int, snapshot_id: str, path: str):
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        root = (job.get("source_path") or "/").rstrip("/")
        rel = path.strip("/")
        abs_path = f"{root}/{rel}" if rel else root
        is_dir = self._entry_is_dir(job, snapshot_id, path)

        args = ["dump", snapshot_id, abs_path]
        if is_dir:
            args = ["dump", "--archive=tar", snapshot_id, abs_path]

        result = subprocess.run(
            ["restic", "-r", str(self._repo_path(job)), *args],
            env=self._env(),
            capture_output=True,
            timeout=3600,
        )
        if result.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"restic dump falló: {result.stderr.strip()[:300]}",
            )
        return result.stdout, is_dir, path

    # ------------------------------------------------------------------
    # reconciliation (config file is the source of truth; raise alert when
    # the source folder disappears)
    # ------------------------------------------------------------------

    def _reconcile(self, db: Session) -> None:
        for job in self._all_jobs():
            self._reconcile_job_source(db, job)
            self._reconcile_job_destination(db, job)
        self._gc_orphan_repos()

    def _reconcile_job_source(self, db: Session, job: Job) -> None:
        """Levanta una alerta cuando la carpeta origen ya no existe y la
        resuelve cuando vuelve a estar disponible."""
        source = Path(job.get("source_path") or "")
        missing = not self._dir_live(source)
        flagged = bool(job.get("source_missing_alerted"))

        if missing and not flagged:
            job["source_missing_alerted"] = True
            self._save_job(job)
            title = f"Origen de respaldo no encontrado: {job.get('name')}"
            message = (
                f"El respaldo «{job.get('name')}» no pudo comprobar su carpeta "
                f"de origen ({job.get('source_path')}). La carpeta o unidad no "
                f"está montada; el respaldo queda a la espera hasta que el "
                f"origen vuelva a estar disponible."
            )
            try:
                db.rollback()
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type=SOURCE_MISSING_ALERT,
                    severity="warning",
                    title=title,
                    message=message[:500],
                )
                db.commit()
                logger.warning("Alerta: %s", title)
            except Exception as error:
                logger.warning("Could not create source-missing alert: %s", error)
            return

        if not missing and flagged:
            job["source_missing_alerted"] = False
            self._save_job(job)
            logger.info("Origen de respaldo restaurado: %s", job.get("name"))

    def _reconcile_job_destination(self, db: Session, job: Job) -> None:
        """Levanta una alerta cuando el destino del respaldo no está disponible
        (ej: USB desconectado) y la resuelve cuando vuelve a estar disponible."""
        dest = Path(str(job.vault or self._dest_folder(job.get("source_path") or "")))
        dest_parent = dest.parent
        missing = not self._dir_live(dest_parent)
        flagged = bool(job.get("dest_missing_alerted"))

        if missing and not flagged:
            job["dest_missing_alerted"] = True
            self._save_job(job)
            title = f"Destino de respaldo no disponible: {job.get('name')}"
            message = (
                f"El respaldo «{job.get('name')}» no puede ejecutarse porque "
                f"el destino ({dest_parent}) no está disponible. "
                f"Verifique que el disco/USB esté conectado y montado."
            )
            try:
                db.rollback()
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type="BACKUP_DEST_MISSING",
                    severity="warning",
                    title=title,
                    message=message[:500],
                )
                db.commit()
                logger.warning("Alerta: %s", title)
            except Exception as error:
                logger.warning("Could not create dest-missing alert: %s", error)
            return

        if not missing and flagged:
            job["dest_missing_alerted"] = False
            self._save_job(job)
            logger.info("Destino de respaldo restaurado: %s", job.get("name"))

    def _gc_orphan_repos(self) -> None:
        """Elimina repositorios que ya no pertenecen a ningún job."""
        expected = {self._repo_path(job) for job in self._all_jobs()}
        for repo in self._repositories():
            if repo in expected:
                continue
            try:
                shutil.rmtree(repo)
                logger.info("Se eliminó un repositorio huérfano: %s", repo)
            except OSError as error:
                logger.warning(
                    "No se pudo eliminar el repositorio huérfano %s: %s",
                    repo,
                    error,
                )

    # ------------------------------------------------------------------
    # scheduler
    # ------------------------------------------------------------------

    def start_scheduler(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop = False
            self._thread = threading.Thread(
                target=self._loop,
                name="share-backup-scheduler",
                daemon=True,
            )
            self._thread.start()
            logger.info("Share backup scheduler started.")

    def stop_scheduler(self) -> None:
        self._stop = True
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=5)
        self._thread = None
        logger.info("Share backup scheduler stopped.")

    def _loop(self) -> None:
        for _ in range(4):
            if self._stop:
                return
            time.sleep(1)
        while not self._stop:
            try:
                self._tick()
            except Exception as error:
                logger.exception("Share backup tick failed: %s", error)
            for _ in range(POLL_SECONDS):
                if self._stop:
                    return
                time.sleep(1)

    def _tick(self) -> None:
        db = SessionLocal()
        try:
            if time.monotonic() - self._last_reconcile >= RECONCILE_SECONDS:
                self._reconcile(db)
                self._last_reconcile = time.monotonic()
            for job in self._all_jobs():
                if not job.get("enabled"):
                    continue
                if job.get("schedule_mode") == "on_change":
                    # Deshabilitado por seguridad (riesgo de ransomware):
                    # solo se respalda por horario.
                    continue
                if not self.is_due(job, now_ecuador()):
                    continue
                try:
                    result = self.run_backup(job.get("id"), trigger="scheduled")
                    logger.info("Scheduled backup %s: %s", job.get("name"), result.get("message", result))
                except HTTPException as error:
                    logger.warning("Scheduled backup %s failed: %s", job.get("name"), error.detail)
        finally:
            db.close()