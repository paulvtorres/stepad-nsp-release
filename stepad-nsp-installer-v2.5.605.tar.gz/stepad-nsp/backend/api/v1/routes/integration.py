from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.siem.services.syslog_service import SyslogService
from backend.siem.routes.schemas import SyslogSettingsRequest
from backend.integrations.services.webhook_service import WebhookService


router = APIRouter(
    prefix="/integration",
    tags=["Integration"]
)

service = SyslogService()
webhook_service = WebhookService()


class WebhookRequest(BaseModel):

    name: str

    url: str

    events: str = "*"


@router.get("/syslog")
def get_syslog(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_settings(db)


@router.put("/syslog")
def save_syslog(
    request: SyslogSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_settings(db, request)


@router.get("/webhooks")
def list_webhooks(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return {"webhooks": webhook_service.list(db)}


@router.post("/webhooks")
def create_webhook(
    request: WebhookRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    try:

        return webhook_service.create(
            db,
            name=request.name,
            url=request.url,
            events=request.events,
            created_by=current_user.get("id") or current_user.get("user_id"),
        )

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))


@router.delete("/webhooks/{webhook_id}")
def delete_webhook(
    webhook_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    try:

        return webhook_service.delete(db, webhook_id)

    except LookupError as error:

        raise HTTPException(status_code=404, detail=str(error))


@router.post("/syslog/test")
def test_syslog(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.test(db)
