from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.role_guard import require_role

from backend.audit.repositories.audit_repository import AuditRepository
from backend.users.models.user import User

from backend.shared.constants.user_roles import UserRoles

from backend.shared.utils.datetimes import local_to_utc


router = APIRouter(
    prefix="/audit",
    tags=["Audit"],
    dependencies=[Depends(require_role(UserRoles.ADMIN))],
)

repository = AuditRepository()


@router.get("/")
def list_audit(
    action: str | None = Query(None),
    resource: str | None = Query(None),
    start: datetime | None = Query(None),
    end: datetime | None = Query(None),
    limit: int = Query(200, ge=1, le=500),
    db: Session = Depends(get_db),
):

    rows = repository.find_filtered(
        db,
        action=action,
        resource=resource,
        start=local_to_utc(start),
        end=local_to_utc(end),
        limit=limit
    )

    result = []

    for row in rows:

        username = None

        if row.user_id:

            user = db.get(User, row.user_id)

            username = user.username if user else None

        result.append({
            "id": row.id,
            "action": row.action,
            "resource": row.resource,
            "description": row.description,
            "user_id": row.user_id,
            "username": username,
            "created_at": _utc_aware(row.created_at)
        })

    return result


def _utc_aware(value):
    """Los logs se guardan en UTC (naive); se marcan como UTC para que
    el frontend los convierta a la hora local del navegador."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


@router.get("/verify")
def verify_audit_chain(db: Session = Depends(get_db)):
    """Verify the tamper-evident chain of the audit log."""
    from backend.audit.services.audit_chain_check_service import (
        AuditChainCheckService,
    )

    return AuditChainCheckService().run(db)
