from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.notifications.services.notification_service import (
    NotificationService
)
from backend.notifications.schemas.notification_settings import (
    AlertNotificationSettingsRequest,
    NavigationReportSettingsRequest,
    NotificationSettingsRequest,
    QuarantineNotificationSettingsRequest,
)


router = APIRouter(
    prefix="/notifications",
    tags=["Notifications"]
)

service = NotificationService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_settings(db)


@router.get("/reports/settings")
def get_report_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_report_settings(db)


@router.put("/reports/settings")
def save_report_settings(
    request: NavigationReportSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_report_settings(db, request)


@router.get("/alerts/settings")
def get_alert_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_alert_settings(db)


@router.put("/alerts/settings")
def save_alert_settings(
    request: AlertNotificationSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_alert_settings(db, request)


@router.get("/quarantine/settings")
def get_quarantine_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_quarantine_settings(db)


@router.put("/quarantine/settings")
def save_quarantine_settings(
    request: QuarantineNotificationSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_quarantine_settings(db, request)


@router.get("/outbox")
def get_email_outbox(
    limit: int = 50,
    status: str = "pending",
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    from backend.notifications.services.email_outbox_service import (
        EmailOutboxService,
    )

    if status not in ("pending", "failed", "all"):

        status = "pending"

    return {"items": EmailOutboxService().list_items(db, limit, status)}


@router.post("/outbox/{outbox_id}/retry")
def retry_email_outbox(
    outbox_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    from backend.notifications.services.email_outbox_service import (
        EmailOutboxService,
    )

    try:

        return EmailOutboxService().retry_now(db, outbox_id)

    except LookupError as error:

        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail=str(error))


@router.put("/settings")
def save_settings(
    request: NotificationSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_settings(db, request)


@router.post("/test-critical")
def send_critical_test(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.notifications.services.critical_alert_email_service import (
        CriticalAlertEmailService,
    )

    sent = CriticalAlertEmailService().send(
        db,
        "Prueba de alerta crítica NSP",
        (
            "Esta es una prueba del canal de alertas críticas. "
            "Si recibís este correo, DHCP/servicios pueden notificar."
        ),
        html_body=(
            "<h3>Prueba de alerta crítica NSP</h3>"
            "<p>Este es el mismo canal usado para DHCP caído, "
            "servicios y capacidad crítica.</p>"
        ),
    )

    return {
        "success": bool(sent),
        "message": (
            "Correo de prueba enviado."
            if sent
            else "No se envió. Revisar Correo y destinatarios de Alertas."
        ),
    }


@router.post("/test")
def send_test(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.send_test(db)


@router.post("/send-now")
def send_now(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.send_report(db)
