import smtplib
import ssl

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.header import Header
from email.utils import formataddr

from pathlib import Path

from backend.notifications.utils.email_addresses import parse_email_list

from backend.shared.logging.logger import logger


class EmailService:

    def _parse_emails(self, raw: str) -> list[str]:

        # Al enviar no se aborta por una direccion mala: se entrega a las
        # validas (la validacion estricta ocurre al guardar los ajustes).
        return parse_email_list(raw, strict=False)

    def _deliver(
        self,
        settings,
        message
    ):

        try:

            port = settings.smtp_port or 587

            to_list = self._parse_emails(
                getattr(settings, "to_emails", "")
            )

            cc_list = self._parse_emails(
                getattr(settings, "cc_emails", "")
            )

            bcc_list = self._parse_emails(
                getattr(settings, "bcc_emails", "")
            )

            envelope = list(dict.fromkeys(to_list + cc_list + bcc_list))

            if not envelope:

                return {
                    "success": False,
                    "message": "No recipient emails configured",
                }

            if port == 465:

                context = ssl.create_default_context()

                server = smtplib.SMTP_SSL(
                    settings.smtp_host,
                    port,
                    context=context,
                    timeout=30
                )

            else:

                server = smtplib.SMTP(
                    settings.smtp_host,
                    port,
                    timeout=30
                )

                server.ehlo()

                server.starttls()

                server.ehlo()

            if settings.smtp_user:

                server.login(
                    settings.smtp_user,
                    settings.smtp_password or ""
                )

            server.sendmail(
                settings.from_email,
                envelope,
                message.as_string()
            )

            server.quit()

            return {
                "success": True,
                "message": "Correo enviado correctamente."
            }

        except Exception as error:
            logger.debug("email_service._deliver: %s", error)

            return {
                "success": False,
                "message": f"SMTP error: {error}"
            }

    def _recipients(self, settings):

        return self._parse_emails(getattr(settings, "to_emails", ""))

    def _cc_recipients(self, settings):

        return self._parse_emails(getattr(settings, "cc_emails", ""))

    def _bcc_recipients(self, settings):

        return self._parse_emails(getattr(settings, "bcc_emails", ""))

    def _apply_headers(self, message, settings):

        to_list = self._recipients(settings)

        cc_list = self._cc_recipients(settings)

        bcc_list = self._bcc_recipients(settings)

        message["To"] = ", ".join(
            formataddr(("", email)) for email in to_list
        )

        if cc_list:

            # "Cc" SI va en la cabecera (los destinatarios se ven entre
            # ellos), a diferencia de "Bcc" que se omite a proposito.
            message["Cc"] = ", ".join(
                formataddr(("", email)) for email in cc_list
            )

        if bcc_list:

            message["Bcc"] = ", ".join(
                formataddr(("", email)) for email in bcc_list
            )

        return to_list, cc_list, bcc_list

    def deliver_html(
        self,
        settings,
        subject: str,
        html_body: str
    ):
        """Build and deliver an HTML message once (no outbox side effects)."""

        if not settings.smtp_host or not settings.from_email:

            return {
                "success": False,
                "message": "SMTP host or from address not configured"
            }

        message = MIMEMultipart("alternative")

        message["Subject"] = Header(subject or "", "utf-8")

        message["From"] = formataddr(("", str(settings.from_email or "").strip()))

        try:

            to_list, _, _ = self._apply_headers(message, settings)

        except ValueError as error:

            return {
                "success": False,
                "message": f"Correo inválido: {error}",
            }

        if not to_list:

            return {
                "success": False,
                "message": "No recipient emails configured"
            }

        message.attach(MIMEText(html_body, "html", "utf-8"))

        return self._deliver(settings, message)

    def send_html(
        self,
        settings,
        subject: str,
        html_body: str,
        channel: str = "general"
    ):
        """Deliver immediately and persist a retryable outbox row on failure."""

        result = self.deliver_html(settings, subject, html_body)

        if not result.get("success") and getattr(settings, "smtp_host", "") and getattr(settings, "from_email", ""):

            try:

                from backend.notifications.services.email_outbox_service import (
                    EmailOutboxService,
                )

                EmailOutboxService().enqueue(
                    channel=channel,
                    to_emails=getattr(settings, "to_emails", ""),
                    cc_emails=getattr(settings, "cc_emails", ""),
                    bcc_emails=getattr(settings, "bcc_emails", ""),
                    subject=subject,
                    html_body=html_body,
                )

            except Exception as error:

                logger.debug("email outbox enqueue: %s", error)

        return result

    def send_html_with_attachment(
        self,
        settings,
        subject: str,
        html_body: str,
        attachment_bytes: bytes,
        attachment_filename: str,
        attachment_subtype: str = (
            "vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        ),
    ):

        if not settings.smtp_host or not settings.from_email:

            return {
                "success": False,
                "message": "Falta servidor SMTP o correo remitente",
            }

        message = MIMEMultipart("mixed")

        message["Subject"] = Header(subject or "", "utf-8")

        message["From"] = formataddr(("", str(settings.from_email or "").strip()))

        try:

            to_list, _, _ = self._apply_headers(message, settings)

        except ValueError as error:

            return {
                "success": False,
                "message": f"Correo inválido: {error}",
            }

        if not to_list:

            return {
                "success": False,
                "message": "No hay destinatarios configurados",
            }

        alternative = MIMEMultipart("alternative")

        alternative.attach(MIMEText(html_body, "html", "utf-8"))

        message.attach(alternative)

        part = MIMEApplication(
            attachment_bytes,
            _subtype=attachment_subtype,
        )

        part.add_header(
            "Content-Disposition",
            "attachment",
            filename=attachment_filename,
        )

        message.attach(part)

        return self._deliver(settings, message)

    def send_attachment(
        self,
        settings,
        subject: str,
        body: str,
        attachment_path: str | Path
    ):

        if not settings.smtp_host or not settings.from_email:

            return {
                "success": False,
                "message": "SMTP host or from address not configured"
            }

        path = Path(attachment_path)

        if not path.exists():

            return {
                "success": False,
                "message": f"Attachment not found: {path.name}"
            }

        message = MIMEMultipart()

        message["Subject"] = Header(subject or "", "utf-8")

        message["From"] = formataddr(("", str(settings.from_email or "").strip()))

        try:

            to_list, _, _ = self._apply_headers(message, settings)

        except ValueError as error:

            return {
                "success": False,
                "message": f"Correo inválido: {error}",
            }

        if not to_list:

            return {
                "success": False,
                "message": "No recipient emails configured"
            }

        message.attach(MIMEText(body, "plain", "utf-8"))

        with open(path, "rb") as file:

            part = MIMEApplication(
                file.read(),
                _subtype="octet-stream"
            )

        part.add_header(
            "Content-Disposition",
            "attachment",
            filename=path.name
        )

        message.attach(part)

        return self._deliver(settings, message)