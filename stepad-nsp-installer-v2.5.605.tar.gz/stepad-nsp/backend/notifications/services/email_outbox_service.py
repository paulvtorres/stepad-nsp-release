"""Persistent email outbox with retry/backoff.

Only HTML mails without attachments are queued. The outbox is a safety
net: a transient SMTP outage must not silently lose an alert.
"""

from __future__ import annotations

import hashlib
import threading
import time

from datetime import timedelta

from backend.shared.datetime_utils import utcnow


MAX_ATTEMPTS = 5
RETRY_BASE_SECONDS = 60
RETRY_MAX_SECONDS = 3600


def _dedupe_key(channel, to_emails, subject, html_body):
    raw = f"{channel}|{to_emails}|{subject}|{html_body}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class EmailOutboxService:

    _worker = None
    _stop = None

    def enqueue(
        self,
        *,
        channel: str,
        to_emails: str,
        cc_emails: str = "",
        bcc_emails: str = "",
        subject: str,
        html_body: str,
        dedupe_key: str | None = None,
        db=None,
    ):
        from backend.core.database.session import SessionLocal
        from backend.notifications.models.email_outbox import EmailOutbox
        from backend.notifications.utils.email_addresses import parse_email_list

        own = db is None
        if own:
            db = SessionLocal()

        try:
            recipients = parse_email_list(to_emails, strict=False)
            if not recipients:
                return None

            key = dedupe_key or _dedupe_key(
                channel, ", ".join(recipients), subject, html_body
            )

            existing = (
                db.query(EmailOutbox)
                .filter(
                    EmailOutbox.status == "pending",
                    EmailOutbox.dedupe_key == key,
                )
                .first()
            )
            if existing is not None:
                return existing

            row = EmailOutbox(
                channel=(channel or "general")[:40],
                to_emails=", ".join(recipients),
                cc_emails=cc_emails or "",
                bcc_emails=bcc_emails or "",
                subject=(subject or "")[:255],
                html_body=html_body or "",
                status="pending",
                attempts=0,
                next_attempt_at=utcnow(),
                dedupe_key=key,
            )
            db.add(row)
            db.commit()
            db.refresh(row)
            return row
        finally:
            if own:
                db.close()

    def process_due(self, db=None, limit: int = 20):
        from backend.core.database.session import SessionLocal
        from backend.notifications.models.email_outbox import EmailOutbox
        from backend.notifications.services.email_service import EmailService
        from backend.notifications.services.email_settings_service import (
            build_delivery_context,
        )
        from backend.shared.logging.logger import logger

        own = db is None
        if own:
            db = SessionLocal()

        sent = 0
        failed = 0
        now = utcnow()

        try:
            rows = (
                db.query(EmailOutbox)
                .filter(
                    EmailOutbox.status == "pending",
                    EmailOutbox.attempts < MAX_ATTEMPTS,
                )
                .order_by(EmailOutbox.id)
                .limit(max(1, min(int(limit), 100)))
                .all()
            )

            for row in rows:
                if row.next_attempt_at and row.next_attempt_at > now:
                    continue

                delivery = build_delivery_context(
                    db,
                    to_emails=row.to_emails,
                    cc_emails=row.cc_emails,
                    bcc_emails=row.bcc_emails,
                )

                if delivery is None:
                    row.attempts += 1
                    row.last_error = "SMTP no configurado"
                    row.next_attempt_at = now + timedelta(
                        seconds=min(
                            RETRY_MAX_SECONDS,
                            RETRY_BASE_SECONDS * (2 ** max(0, row.attempts - 1)),
                        )
                    )
                    if row.attempts >= MAX_ATTEMPTS:
                        row.status = "failed"
                    db.add(row)
                    db.commit()
                    failed += 1
                    continue

                result = EmailService().deliver_html(
                    delivery, row.subject, row.html_body
                )

                if result.get("success"):
                    row.status = "sent"
                    row.sent_at = utcnow()
                    row.last_error = None
                    row.next_attempt_at = None
                    sent += 1
                else:
                    row.attempts += 1
                    row.last_error = str(result.get("message") or "SMTP error")[:2000]
                    row.next_attempt_at = now + timedelta(
                        seconds=min(
                            RETRY_MAX_SECONDS,
                            RETRY_BASE_SECONDS * (2 ** max(0, row.attempts - 1)),
                        )
                    )
                    if row.attempts >= MAX_ATTEMPTS:
                        row.status = "failed"
                    failed += 1
                    logger.warning(
                        "Outbox correo %s falló (intento %s): %s",
                        row.id,
                        row.attempts,
                        row.last_error,
                    )

                db.add(row)
                db.commit()

            return {"sent": sent, "failed": failed}

        finally:
            if own:
                db.close()

    def list_items(self, db, limit: int = 50, status: str | None = None):
        from backend.notifications.models.email_outbox import EmailOutbox

        query = db.query(EmailOutbox)

        if status in ("pending", "failed"):

            query = query.filter(EmailOutbox.status == status)

        else:

            query = query.filter(
                EmailOutbox.status.in_(("pending", "failed"))
            )

        rows = (
            query
            .order_by(EmailOutbox.id.desc())
            .limit(max(1, min(int(limit), 200)))
            .all()
        )
        return [
            {
                "id": row.id,
                "channel": row.channel,
                "to_emails": row.to_emails,
                "subject": row.subject,
                "status": row.status,
                "attempts": row.attempts,
                "next_attempt_at": (
                    row.next_attempt_at.isoformat()
                    if row.next_attempt_at else None
                ),
                "last_error": row.last_error,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "sent_at": row.sent_at.isoformat() if row.sent_at else None,
            }
            for row in rows
        ]

    def list_pending(self, db, limit: int = 50):
        return self.list_items(db, limit, status="pending")

    def retry_now(self, db, outbox_id: int):
        from backend.notifications.models.email_outbox import EmailOutbox

        row = db.get(EmailOutbox, outbox_id)
        if row is None:
            raise LookupError("Correo no encontrado en outbox.")
        row.status = "pending"
        row.attempts = 0
        row.next_attempt_at = utcnow()
        row.last_error = None
        db.add(row)
        db.commit()
        return {"success": True, "id": outbox_id}

    def _loop(self):
        while not self._stop.is_set():
            try:
                self.process_due(limit=20)
            except Exception:
                pass
            for _ in range(30):
                if self._stop.is_set():
                    return
                time.sleep(1)

    def start_worker(self):
        if self._worker is not None and self._worker.is_alive():
            return
        self._stop = threading.Event()
        self._worker = threading.Thread(
            target=self._loop,
            daemon=True,
            name="email-outbox",
        )
        self._worker.start()

    def stop_worker(self):
        if self._stop is not None:
            self._stop.set()
        self._worker = None
