from backend.core.components.base_component import BaseComponent

from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.notifications.services.notification_service import (
    NotificationService
)
from backend.notifications.services.email_outbox_service import (
    EmailOutboxService,
)

from backend.integrations.services.webhook_service import (
    WebhookService,
)

from backend.shared.logging.logger import logger


class NotificationComponent(BaseComponent):

    name = "notifications"

    criticality = ComponentCriticality.IMPORTANT

    def __init__(self):

        self.service = NotificationService()
        self.outbox = EmailOutboxService()
        self.webhooks = WebhookService()

    def health_check(self) -> bool:
        try:
            thread = getattr(self.service, "_scheduler_thread", None)
            return bool(thread and thread.is_alive())
        except Exception as error:
            logger.warning("NotificationComponent health_check: %s", error)
            return False

    def start(self):

        logger.info("NotificationComponent started.")

        self.service.start_scheduler()
        self.outbox.start_worker()
        self.webhooks.start_worker()

    def stop(self):

        logger.info("NotificationComponent stopped.")
        self.outbox.stop_worker()
        self.webhooks.stop_worker()
