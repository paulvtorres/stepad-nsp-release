"""Detección de IPs duplicadas / estáticas dentro del pool DHCP.

Caso real: un equipo con .150 estática dentro del pool; dnsmasq se la
entregó a un portátil y quedaron dos equipos con la misma IP.
"""

from backend.dhcp.domain.conflicts import find_conflicts
from backend.dhcp.domain.leases import Lease


def _lease(mac, ip):

    return Lease(0, mac, ip)


def test_detecta_conflicto_lease_vs_arp():

    conflicts = find_conflicts(
        leases=[_lease("74:4c:a1:c5:c4:97", "192.168.1.150")],
        arp_mac_by_ip={"192.168.1.150": "00:26:73:1b:ef:32"},
        reserved_ips=[],
        pool_start="192.168.1.20",
        pool_end="192.168.1.150",
    )

    assert len(conflicts) == 1

    item = conflicts[0]

    assert item.kind == "lease_mismatch"

    assert item.ip == "192.168.1.150"

    assert item.lease_mac == "74:4c:a1:c5:c4:97"

    assert item.arp_mac == "00:26:73:1b:ef:32"


def test_detecta_estatica_dentro_del_pool():

    conflicts = find_conflicts(
        leases=[],
        arp_mac_by_ip={"192.168.1.100": "aa:bb:cc:dd:ee:ff"},
        reserved_ips=[],
        pool_start="192.168.1.20",
        pool_end="192.168.1.150",
    )

    assert [item.kind for item in conflicts] == ["static_in_pool"]


def test_no_conflicto_si_la_reserva_coincide():

    conflicts = find_conflicts(
        leases=[_lease("00:26:73:1b:ef:32", "192.168.1.150")],
        arp_mac_by_ip={"192.168.1.150": "00:26:73:1b:ef:32"},
        reserved_ips=["192.168.1.150"],
        pool_start="192.168.1.20",
        pool_end="192.168.1.150",
    )

    assert conflicts == []


def test_fuera_del_pool_no_cuenta_como_estatica():

    conflicts = find_conflicts(
        leases=[],
        arp_mac_by_ip={"192.168.1.200": "aa:bb:cc:dd:ee:ff"},
        reserved_ips=[],
        pool_start="192.168.1.20",
        pool_end="192.168.1.150",
    )

    assert conflicts == []


def test_el_conflicto_real_va_primero():

    conflicts = find_conflicts(
        leases=[_lease("74:4c:a1:c5:c4:97", "192.168.1.150")],
        arp_mac_by_ip={
            "192.168.1.100": "aa:bb:cc:dd:ee:01",
            "192.168.1.150": "00:26:73:1b:ef:32",
        },
        reserved_ips=[],
        pool_start="192.168.1.20",
        pool_end="192.168.1.150",
    )

    assert conflicts[0].kind == "lease_mismatch"

    assert conflicts[1].kind == "static_in_pool"


def test_known_dhcp_client_with_expired_lease_is_not_static_conflict():
    conflicts = find_conflicts(
        [],
        {"192.168.1.42": "84:a9:3e:06:82:9e"},
        [],
        "192.168.1.20",
        "192.168.1.119",
        {"192.168.1.42": {"84:a9:3e:06:82:9e"}},
    )
    assert conflicts == []


def test_known_dhcp_mac_en_otra_ip_no_es_conflicto_estatico():
    conflicts = find_conflicts(
        [],
        {"192.168.1.61": "84:a9:3e:06:82:9e"},
        [],
        "192.168.1.20",
        "192.168.1.119",
        {"192.168.1.42": {"84:a9:3e:06:82:9e"}},
    )
    assert conflicts == []
