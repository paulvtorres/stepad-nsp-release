from types import SimpleNamespace

import pytest

import backend.dhcp.providers.dnsmasq_reservation_provider as module
from backend.dhcp.providers.dnsmasq_reservation_provider import (
    DnsmasqReservationProvider,
)


def test_reserva_invalida_para_dnsmasq_no_reemplaza_archivo(
    tmp_path, monkeypatch
):
    destination = tmp_path / "reservations.conf"
    destination.write_text("previous\n", encoding="utf-8")

    monkeypatch.setattr(module, "DOMAINS_CONFIG", tmp_path / "domains.conf")
    monkeypatch.setattr(module, "RESERVATIONS_CONFIG", destination)
    monkeypatch.setattr(
        module.subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(
            returncode=1, stdout="", stderr="bad DHCP host"
        ),
    )

    provider = DnsmasqReservationProvider()

    with pytest.raises(ValueError, match="dnsmasq rechazó"):
        provider.write_reservations(
            [{"mac": "aa:bb:cc:dd:ee:ff", "ip": "192.168.1.42"}]
        )

    assert destination.read_text(encoding="utf-8") == "previous\n"


def test_reserva_valida_se_escribe(tmp_path, monkeypatch):
    destination = tmp_path / "reservations.conf"

    monkeypatch.setattr(module, "DOMAINS_CONFIG", tmp_path / "domains.conf")
    monkeypatch.setattr(module, "RESERVATIONS_CONFIG", destination)
    monkeypatch.setattr(
        module.subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(
            returncode=0, stdout="syntax check OK", stderr=""
        ),
    )

    result = DnsmasqReservationProvider().write_reservations(
        [{"mac": "aa:bb:cc:dd:ee:ff", "ip": "192.168.1.42"}]
    )

    assert result["total"] == 1
    assert "aa:bb:cc:dd:ee:ff,192.168.1.42," in destination.read_text()
