from backend.monitoring.services.operational_health_service import (
    OperationalHealthService,
)


def test_health_agrega_checks_y_marca_critico(monkeypatch):
    import backend.monitoring.services.navigation_health_service as nav
    import backend.notifications.services.email_settings_service as smtp
    import backend.notifications.services.email_outbox_service as outbox
    import backend.backups.services.restore_verification_service as restore

    monkeypatch.setattr(
        nav.NavigationHealthService,
        "inspect",
        lambda self, db: {
            "checks": {
                "dhcp": {"ok": True, "detail": "DHCP OK"},
                "dns": {"ok": False, "detail": "DNS caído"},
            }
        },
    )
    monkeypatch.setattr(
        smtp.EmailSettingsService,
        "get_settings",
        lambda self, db: {"config_ready": True, "config_issues": []},
    )
    monkeypatch.setattr(
        outbox.EmailOutboxService,
        "list_items",
        lambda self, db, limit, status: [],
    )
    monkeypatch.setattr(
        restore.RestoreVerificationService,
        "status",
        lambda self: {"success": True, "message": "OK"},
    )

    result = OperationalHealthService().get(None)

    assert result["status"] == "critical"
    assert result["summary"]["critical"] >= 1
    assert any(item["key"] == "dns" for item in result["checks"])
    assert any(item["key"] == "restore_verify" for item in result["checks"])


def test_health_puede_estar_ok(monkeypatch):
    import backend.monitoring.services.navigation_health_service as nav
    import backend.notifications.services.email_settings_service as smtp
    import backend.notifications.services.email_outbox_service as outbox
    import backend.backups.services.restore_verification_service as restore

    monkeypatch.setattr(
        nav.NavigationHealthService,
        "inspect",
        lambda self, db: {"checks": {"dhcp": {"ok": True, "detail": "OK"}}},
    )
    monkeypatch.setattr(
        smtp.EmailSettingsService,
        "get_settings",
        lambda self, db: {"config_ready": True, "config_issues": []},
    )
    monkeypatch.setattr(
        outbox.EmailOutboxService,
        "list_items",
        lambda self, db, limit, status: [],
    )
    monkeypatch.setattr(
        restore.RestoreVerificationService,
        "status",
        lambda self: {"success": True, "message": "OK"},
    )

    assert OperationalHealthService().get(None)["status"] == "ok"
