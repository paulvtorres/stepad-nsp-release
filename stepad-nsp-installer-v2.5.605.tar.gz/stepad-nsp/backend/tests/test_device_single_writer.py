"""Un solo escritor para el estado y la IP de los dispositivos.

`DevicePresenceService` es el dueño de `status`, `last_seen`,
`current_ip`, `assigned_ip`, `last_ip`, `ip_address`, `presence_*` e
`ip_conflict`. `IpOwnershipService` solo puede registrar la IP al crear o
actualizar un registro (`ip_address`, `last_ip`). Si otro modulo vuelve a
escribirlos, dos escritores se pisan y el listado deja de ser real.

Esta prueba falla en CI si alguien lo intenta.
"""

import ast
import re
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]

FIELDS = {
    "status",
    "ip_address",
    "last_seen",
    "current_ip",
    "last_ip",
    "assigned_ip",
    "presence_status",
    "presence_source",
    "presence_at",
    "ip_conflict",
}

# Quien puede escribir cada campo (ruta relativa a backend/).
ALLOWED = {
    "network/devices/services/device_presence_service.py": FIELDS,
    "network/devices/services/ip_ownership_service.py": {"ip_address", "last_ip"},
}

# Variables que, por convencion, son un NetworkDevice.
DEVICE_NAME = re.compile(
    r"^(device|dev|existing|leased_device|new_device|linked|other_device)$"
)


def _assignments():
    for path in BACKEND.rglob("*.py"):
        relative = path.relative_to(BACKEND).as_posix()
        if relative.startswith(("tests/", "migrations/")):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                targets = node.targets
            elif isinstance(node, (ast.AugAssign, ast.AnnAssign)):
                targets = [node.target]
            else:
                continue
            for target in targets:
                if (
                    isinstance(target, ast.Attribute)
                    and target.attr in FIELDS
                    and isinstance(target.value, ast.Name)
                    and DEVICE_NAME.match(target.value.id)
                ):
                    yield relative, node.lineno, target.attr


def test_solo_el_servicio_de_presencia_escribe_estado_e_ip():
    violations = [
        f"{relative}:{line} escribe {field}"
        for relative, line, field in _assignments()
        if field not in ALLOWED.get(relative, set())
    ]

    assert not violations, (
        "Otro modulo escribe campos que son del servicio de presencia:\n"
        + "\n".join(violations)
    )
