import io
import tarfile
from datetime import datetime, timedelta

from backend.shared.datetime_utils import utcnow

from backend.backups.services.restore_verification_service import (
    RestoreVerificationService,
)


def test_missing_state_should_run(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    assert service.should_run() is True

    assert service.status()["success"] is False


def test_recent_success_does_not_run(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    service._save({
        "success": True,
        "last_run_at": utcnow().isoformat(),
    })

    assert service.should_run() is False

    assert service.status()["success"] is True


def test_old_run_should_run_again(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    service._save({
        "success": True,
        "last_run_at": (utcnow() - timedelta(days=40)).isoformat(),
    })

    assert service.should_run() is True


def test_invalid_date_should_run(tmp_path):

    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    service._save({"success": True, "last_run_at": "no-es-fecha"})

    assert service.should_run() is True


def _archive(path, files):
    with tarfile.open(path, "w:gz") as handle:
        for name, content in files.items():
            data = content.encode("utf-8")
            info = tarfile.TarInfo(name)
            info.size = len(data)
            handle.addfile(info, io.BytesIO(data))


def test_archivo_de_respaldo_valida_archivos_esenciales(tmp_path):
    archive = tmp_path / "backup.tar.gz"
    files = {
        "./stepad.env": "DB_PASSWORD=test\n",
        "./config.yaml": "network:\n  lan_interface: enp3s0\n",
        "./stepad/dns/dnsmasq.conf": "dhcp-range=192.168.1.20,192.168.1.30\n",
    }
    for index in range(20):
        files[f"./stepad/test/file-{index}.conf"] = "x"

    _archive(archive, files)
    service = RestoreVerificationService(state_path=tmp_path / "state.json")
    result = service._validate_archive_files(archive, tmp_path / "stage")

    assert result["has_env"] is True
    assert result["has_config"] is True
    assert result["has_dnsmasq"] is True
    assert result["stepad_files"] == 21


def test_archivo_de_respaldo_sin_dnsmasq_falla(tmp_path):
    archive = tmp_path / "backup.tar.gz"
    _archive(archive, {
        "./stepad.env": "x=1\n",
        "./config.yaml": "x: 1\n",
    })
    service = RestoreVerificationService(state_path=tmp_path / "state.json")

    try:
        service._validate_archive_files(archive, tmp_path / "stage")
    except RuntimeError as error:
        assert "dnsmasq" in str(error)
    else:
        raise AssertionError("debía fallar por falta de dnsmasq")
