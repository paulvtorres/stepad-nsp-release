from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.alerts.models.alert import Alert
from backend.alerts.services.alert_service import AlertService
from backend.core.database.base import Base


def db_session():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_alerta_repetida_se_agrupa_y_cuenta_ocurrencias(monkeypatch):
    monkeypatch.setattr(
        "backend.notifications.services.critical_alert_email_service.CriticalAlertEmailService",
        type("FakeEmail", (), {"send": lambda *args, **kwargs: True}),
    )
    db = db_session()
    service = AlertService()

    service.create(db, "RESOURCE_CPU", "warning", "CPU alta", "x")
    service.create(db, "RESOURCE_CPU", "warning", "CPU alta", "y")

    alerts = db.query(Alert).all()
    assert len(alerts) == 1
    assert alerts[0].occurrences == 2
    assert alerts[0].first_seen_at is not None
    assert alerts[0].last_seen_at is not None
    assert alerts[0].last_seen_at >= alerts[0].first_seen_at
    assert alerts[0].message == "y"


def test_alertas_distintas_no_se_agrupan(monkeypatch):
    monkeypatch.setattr(
        "backend.notifications.services.critical_alert_email_service.CriticalAlertEmailService",
        type("FakeEmail", (), {"send": lambda *args, **kwargs: True}),
    )
    db = db_session()
    service = AlertService()

    service.create(db, "RESOURCE_CPU", "warning", "CPU alta", "x")
    service.create(db, "RESOURCE_RAM", "warning", "RAM alta", "x")

    assert db.query(Alert).count() == 2
