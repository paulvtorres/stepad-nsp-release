"""Pool FIJO: se recicla lo que no se usa, se avisa si no queda nada.

Reglas del operador:
- Las reservas nunca se tocan.
- Un equipo conectado nunca pierde su IP.
- Un lease de un equipo ausente se libera cuando hace falta una IP.
- Si el pool esta lleno de equipos conectados, se AVISA. Nunca se amplia.
"""

import os

os.environ.setdefault("STEPAD_ENV", "development")

from datetime import timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.network.devices.models.device_ip_observation import (
    DeviceIpObservation,
)
from backend.shared.datetime_utils import utcnow
from backend.tests.test_device_presence_service import (
    World,
    add,
    make_service,
    reach,
    stale,
)
from backend.tests.test_dhcp_reconciler import FakeConfigService, build

A = "aa:00:00:00:00:01"
B = "aa:00:00:00:00:02"
C = "aa:00:00:00:00:03"

LOW = {"low": True, "free": 2, "threshold": 5}
EXHAUSTED = {"low": True, "free": 0, "threshold": 5}


@pytest.fixture
def env(tmp_path, monkeypatch):

    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine)
    db = factory()

    import backend.core.database.session as session_module
    import backend.network.devices.services.device_presence_service as presence_module

    monkeypatch.setattr(session_module, "SessionLocal", factory)

    world = World()
    world.now = utcnow()

    # El reciclaje arma SU servicio de presencia: aqui con la red simulada.
    monkeypatch.setattr(
        presence_module,
        "DevicePresenceService",
        lambda: make_service(world),
    )

    alerts = []
    service = FakeConfigService(
        {
            "pool_reclaim_target_free": 3,
            "pool_reclaim_cooldown_seconds": 0,
            "pool_emergency_reclaim_minutes": 60,
        }
    )
    reconciler, process, _, _ = build(
        tmp_path, monkeypatch, alerts=alerts, config_service=service
    )
    reconciler._leases_path = tmp_path / "dnsmasq.leases"

    def write_leases(*pairs):
        reconciler._leases_path.write_text(
            "".join(f"9999999999 {mac} {ip} host *\n" for mac, ip in pairs),
            encoding="utf-8",
        )

    def lease_ips():
        return [
            line.split()[2]
            for line in reconciler._leases_path.read_text().splitlines()
            if line.strip()
        ]

    class Env:
        pass

    e = Env()
    e.db, e.world, e.alerts, e.reconciler = db, world, alerts, reconciler
    e.write_leases, e.lease_ips = write_leases, lease_ips
    return e


def ausente(env, mac, ip, name, minutes_ago=180, permanent_ip=None):
    """Equipo que se fue; el kernel aun recuerda su entrada ARP (STALE)."""

    device = add(
        env.db, mac, ip, name, last_seen=utcnow() - timedelta(minutes=minutes_ago)
    )
    device.permanent_ip = permanent_ip
    env.db.add(
        DeviceIpObservation(
            mac_address=mac,
            ip_address=ip,
            source="arp_stale",
            observed_at=utcnow() - timedelta(hours=3),
        )
    )
    env.db.commit()
    env.world.neigh.append(stale(ip, mac))
    return device


def test_se_libera_al_ausente_aunque_el_kernel_conserve_su_arp_stale(env):
    ausente(env, A, "192.168.1.21", "se-fue")
    add(env.db, B, "192.168.1.22", "conectado")
    env.world.neigh.append(reach("192.168.1.22", B))
    env.write_leases((A, "192.168.1.21"), (B, "192.168.1.22"))

    freed = env.reconciler._reclaim_if_needed(dict(LOW))

    assert freed == 1
    assert env.lease_ips() == ["192.168.1.22"]
    assert [a[0] for a in env.alerts] == ["DHCP_POOL_RECLAIMED"]


def test_un_equipo_conectado_nunca_pierde_su_ip(env):
    add(env.db, A, "192.168.1.21", "conectado")
    env.world.neigh.append(reach("192.168.1.21", A))
    env.write_leases((A, "192.168.1.21"))

    assert env.reconciler._reclaim_if_needed(dict(EXHAUSTED)) == 0
    assert env.lease_ips() == ["192.168.1.21"]


def test_las_reservas_nunca_se_tocan(env):
    ausente(env, A, "192.168.1.21", "reservado", permanent_ip="192.168.1.21")
    env.write_leases((A, "192.168.1.21"))

    assert env.reconciler._reclaim_if_needed(dict(EXHAUSTED)) == 0
    assert env.lease_ips() == ["192.168.1.21"]


def test_pool_agotado_no_espera_la_ventana_de_inactividad(env):
    ausente(env, A, "192.168.1.21", "se-fue-hace-poco", minutes_ago=10)
    env.write_leases((A, "192.168.1.21"))

    # Solo "bajo": se respeta la ventana (60 min).
    assert env.reconciler._reclaim_if_needed(dict(LOW)) == 0

    # Agotado: nadie puede obtener IP, se libera al ausente ya.
    assert env.reconciler._reclaim_if_needed(dict(EXHAUSTED)) == 1
    assert env.lease_ips() == []


def test_un_equipo_sin_ip_dispara_el_reciclaje_aunque_el_pool_no_figure_bajo(env):
    ausente(env, A, "192.168.1.21", "se-fue")
    env.write_leases((A, "192.168.1.21"))
    healthy = {"low": False, "free": 40, "threshold": 5}

    assert env.reconciler._reclaim_if_needed(dict(healthy)) == 0

    env.reconciler.signal_no_address()

    assert env.reconciler._reclaim_if_needed(dict(healthy)) == 1
    assert env.lease_ips() == []


def test_sin_presencia_confiable_no_se_libera_nada(env, monkeypatch):
    ausente(env, A, "192.168.1.21", "se-fue")
    env.write_leases((A, "192.168.1.21"))

    import backend.network.devices.services.device_presence_service as presence_module

    def boom():
        raise RuntimeError("sin red")

    monkeypatch.setattr(presence_module, "DevicePresenceService", boom)

    assert env.reconciler._reclaim_if_needed(dict(EXHAUSTED)) == 0
    assert env.lease_ips() == ["192.168.1.21"]


def test_si_todo_esta_conectado_se_avisa_y_el_pool_no_se_amplia(
    tmp_path, monkeypatch
):
    """Pool lleno de equipos presentes: critico, y el rango NO cambia."""

    from backend.dhcp.domain.leases import Lease
    from backend.dhcp.services.dhcp_service import DhcpService
    from backend.tests.test_dhcp_reconciler import CONFIG, module

    alerts = []
    service = FakeConfigService({"pool_reclaim_cooldown_seconds": 0})
    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, alerts=alerts, config_service=service
    )

    # Pool .20-.29 con .25 reservada: 9 dinamicas, todas con lease.
    ips = [20, 21, 22, 23, 24, 26, 27, 28, 29]
    monkeypatch.setattr(
        module,
        "read_leases",
        lambda path: [Lease(0, f"aa:{i:02d}:00:00:00:00", f"192.168.1.{i}") for i in ips],
    )
    pool_end_before = CONFIG.pool_end

    reconciler.apply()

    assert [(a[0], a[1]) for a in alerts] == [("DHCP_POOL_EXHAUSTED", "critical")]
    assert CONFIG.pool_end == pool_end_before == "192.168.1.29"
    assert all("pool_end" not in values for _, values in service.updates)
    assert not hasattr(DhcpService, "auto_expand_pool_if_enabled")
