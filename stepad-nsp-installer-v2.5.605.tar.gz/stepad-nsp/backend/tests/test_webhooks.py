import hashlib
import hmac

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.integrations.models.webhook import WebhookDelivery, WebhookEndpoint
from backend.integrations.services.webhook_service import WebhookService


def db_session():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_webhook_se_crea_y_en_encola_por_evento(monkeypatch):
    monkeypatch.setattr(
        "backend.integrations.services.webhook_service.secret_box.encrypt",
        lambda value: "enc:v1:" + value,
    )
    db = db_session()
    service = WebhookService()
    created = service.create(
        db,
        "SIEM",
        "https://example.com/hook",
        events="ALERTA, quarantine",
    )

    assert created["secret"]
    row = db.query(WebhookEndpoint).one()
    assert row.secret_encrypted.startswith("enc:v1:")
    assert "secret" not in service.list(db)[0]

    service.enqueue_alert(
        db,
        alert_type="ALERTA",
        severity="critical",
        title="Prueba",
        message="mensaje",
    )

    delivery = db.query(WebhookDelivery).one()
    assert delivery.event_type == "ALERTA"
    assert delivery.status == "pending"


def test_webhook_no_encola_evento_no_suscrito():
    db = db_session()
    service = WebhookService()
    service.create(db, "SIEM", "https://example.com/hook", events="quarantine")

    service.enqueue_alert(
        db,
        alert_type="RESOURCE_CPU",
        severity="warning",
        title="CPU",
        message="x",
    )

    assert db.query(WebhookDelivery).count() == 0


def test_firma_hmac_es_estable():
    service = WebhookService()
    payload = '{"event":"x"}'
    expected = "sha256=" + hmac.new(
        b"secret", payload.encode(), hashlib.sha256
    ).hexdigest()

    assert service._signature("secret", payload) == expected
