"""Eventos de lease de dnsmasq: de la linea del script a la presencia."""

import json
import os

os.environ.setdefault("STEPAD_ENV", "development")

import subprocess
from datetime import timedelta
from types import SimpleNamespace

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.dhcp.domain.dhcp_events import (
    DhcpEvent,
    parse_event_line,
    render_event_script,
)
from backend.dhcp.services import dhcp_event_service as service_module
from backend.dhcp.services.dhcp_event_service import (
    DhcpEventService,
    DhcpEventSpool,
    dnsmasq_capabilities,
    ensure_event_script,
    event_config_lines,
)
from backend.network.devices.services import device_presence_service as presence_module
from backend.shared.datetime_utils import utcnow
from backend.tests.test_device_presence_service import (
    World,
    add,
    make_service,
    reach,
)

NOW = 1_800_000_000
A = "aa:00:00:00:00:01"
B = "aa:00:00:00:00:02"


def line(action="old", mac=A, ip="192.168.1.30", ts=NOW, **extra):
    return json.dumps(
        {"ts": ts, "action": action, "mac": mac, "ip": ip, "iface": "enp3s0", **extra}
    )


# ----------------------------------------------------------------------
# Parser
# ----------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw, expected",
    [
        (line("add"), DhcpEvent("add", A, "192.168.1.30", NOW, "enp3s0")),
        (line("old"), DhcpEvent("old", A, "192.168.1.30", NOW, "enp3s0")),
        (line("del"), DhcpEvent("del", A, "192.168.1.30", NOW, "enp3s0")),
        # MAC en mayusculas se normaliza.
        (line(mac=A.upper()), DhcpEvent("old", A, "192.168.1.30", NOW, "enp3s0")),
        # init no es una señal del equipo.
        (line("init"), None),
        # Formatos invalidos.
        (line(mac="no-es-mac"), None),
        (line(ip="999.1.1.1"), None),
        (line(ip="fe80::1"), None),
        ("esto no es json", None),
        ("[1, 2]", None),
        ("", None),
        ("x" * 600, None),
    ],
)
def test_parse_event_line(raw, expected):
    assert parse_event_line(raw, NOW) == expected


def test_un_timestamp_del_futuro_o_muy_viejo_usa_la_hora_de_lectura():
    assert parse_event_line(line(ts=NOW + 3600), NOW).ts == NOW
    assert parse_event_line(line(ts=NOW - 3 * 86400), NOW).ts == NOW
    assert parse_event_line(line(ts=NOW - 30), NOW).ts == NOW - 30


def test_una_interfaz_con_caracteres_raros_se_descarta():
    assert parse_event_line(line(iface="eth0; rm -rf /"), NOW).iface == ""


# ----------------------------------------------------------------------
# Script (se ejecuta de verdad con sh, como lo haria dnsmasq)
# ----------------------------------------------------------------------


def run_script(tmp_path, *args, env=None):
    spool = tmp_path / "events.jsonl"
    script = tmp_path / "dhcp-event.sh"
    script.write_text(render_event_script(str(spool)), encoding="utf-8")
    script.chmod(0o750)
    result = subprocess.run(
        ["sh", str(script), *args],
        env={"PATH": os.environ["PATH"], **(env or {})},
        capture_output=True,
        timeout=5,
    )
    return result, spool


def test_el_script_escribe_una_linea_que_el_parser_acepta(tmp_path):
    result, spool = run_script(
        tmp_path, "old", A, "192.168.1.30", "mi-hostname",
        env={"DNSMASQ_INTERFACE": "enp3s0"},
    )

    assert result.returncode == 0
    lines = spool.read_text().splitlines()
    assert len(lines) == 1
    event = parse_event_line(lines[0], int(utcnow().timestamp()) + 1)
    assert (event.action, event.mac, event.ip, event.iface) == (
        "old", A, "192.168.1.30", "enp3s0",
    )
    assert "mi-hostname" not in lines[0]  # texto libre del cliente: nunca


@pytest.mark.parametrize("action", ["init", "tftp", "arp-add"])
def test_el_script_ignora_acciones_que_no_son_del_equipo(tmp_path, action):
    result, spool = run_script(tmp_path, action, A, "192.168.1.30")

    assert result.returncode == 0
    assert not spool.exists()


def test_el_script_nunca_falla_aunque_no_pueda_escribir(tmp_path):
    script = tmp_path / "dhcp-event.sh"
    script.write_text(
        render_event_script(str(tmp_path / "no-existe" / "events.jsonl")),
        encoding="utf-8",
    )

    result = subprocess.run(
        ["sh", str(script), "add", A, "192.168.1.30"], capture_output=True, timeout=5
    )

    assert result.returncode == 0  # jamas debe frenar a dnsmasq


def test_argumentos_hostiles_no_producen_eventos_validos(tmp_path):
    result, spool = run_script(tmp_path, "add", 'aa"; touch /tmp/x; "', "192.168.1.30")

    assert result.returncode == 0
    for raw in spool.read_text().splitlines():
        assert parse_event_line(raw, int(utcnow().timestamp())) is None


# ----------------------------------------------------------------------
# Spool
# ----------------------------------------------------------------------


def test_el_spool_no_reprocesa_la_historia_y_lee_lo_nuevo_una_vez(tmp_path):
    path = tmp_path / "events.jsonl"
    path.write_text(line("add") + "\n")
    spool = DhcpEventSpool(path)

    assert spool.poll(NOW) == []  # historia previa: se ignora

    with path.open("a") as handle:
        handle.write(line("old", ip="192.168.1.31") + "\n")

    first = spool.poll(NOW)
    assert [e.ip for e in first] == ["192.168.1.31"]
    assert spool.poll(NOW) == []  # sin repetir


def test_una_linea_a_medio_escribir_se_completa_en_la_siguiente_lectura(tmp_path):
    path = tmp_path / "events.jsonl"
    path.write_text("")
    spool = DhcpEventSpool(path)
    spool.poll(NOW)

    full = line("old") + "\n"
    with path.open("a") as handle:
        handle.write(full[:20])
    assert spool.poll(NOW) == []

    with path.open("a") as handle:
        handle.write(full[20:])
    assert [e.mac for e in spool.poll(NOW)] == [A]


def test_si_el_archivo_aparece_despues_se_lee_completo(tmp_path):
    path = tmp_path / "events.jsonl"
    spool = DhcpEventSpool(path)

    assert spool.poll(NOW) == []  # aun no existe

    path.write_text(line("add") + "\n")

    assert [e.action for e in spool.poll(NOW)] == ["add"]


def test_un_archivo_truncado_se_vuelve_a_leer_desde_cero(tmp_path):
    path = tmp_path / "events.jsonl"
    path.write_text(line("add") * 1 + "\n" + line("old") + "\n")
    spool = DhcpEventSpool(path)
    spool.poll(NOW)

    path.write_text(line("del") + "\n")  # mas corto que el offset

    assert [e.action for e in spool.poll(NOW)] == ["del"]


def test_el_spool_se_rota_al_pasar_el_limite(tmp_path):
    path = tmp_path / "events.jsonl"
    path.write_text("")
    spool = DhcpEventSpool(path, max_bytes=200)
    spool.poll(NOW)

    with path.open("a") as handle:
        for _ in range(5):
            handle.write(line("old") + "\n")

    assert len(spool.poll(NOW)) == 5
    assert (tmp_path / "events.jsonl.1").exists()
    assert not path.exists()

    path.write_text(line("add") + "\n")  # dnsmasq vuelve a crearlo
    assert [e.action for e in spool.poll(NOW)] == ["add"]


# ----------------------------------------------------------------------
# Configuracion de dnsmasq segun lo que soporte el binario
# ----------------------------------------------------------------------


@pytest.fixture
def lines_env(tmp_path, monkeypatch):
    monkeypatch.setattr(service_module, "DHCP_EVENT_SCRIPT", tmp_path / "dhcp-event.sh")
    monkeypatch.setattr(service_module, "DHCP_EVENT_SPOOL", tmp_path / "events.jsonl")
    monkeypatch.delenv("STEPAD_DHCP_EVENTS", raising=False)
    return tmp_path


def set_caps(monkeypatch, **caps):
    full = {"dhcp-script": False, "script-on-renewal": False, **caps}
    monkeypatch.setattr(service_module, "dnsmasq_capabilities", lambda force=False: full)


def test_con_soporte_completo_se_emiten_script_y_renovaciones(lines_env, monkeypatch):
    set_caps(monkeypatch, **{"dhcp-script": True, "script-on-renewal": True})

    text = event_config_lines()

    assert f"dhcp-script={lines_env / 'dhcp-event.sh'}\n" in text
    assert "script-on-renewal\n" in text
    script = lines_env / "dhcp-event.sh"
    assert script.exists() and oct(script.stat().st_mode & 0o777) == "0o750"


def test_sin_script_on_renewal_solo_se_emite_el_script(lines_env, monkeypatch):
    set_caps(monkeypatch, **{"dhcp-script": True})

    assert "script-on-renewal" not in event_config_lines()


def test_si_el_binario_no_lo_soporta_no_se_emite_nada(lines_env, monkeypatch):
    """Una opcion desconocida haria que `dnsmasq --test` rechace TODO."""
    set_caps(monkeypatch)

    assert event_config_lines() == ""
    assert not (lines_env / "dhcp-event.sh").exists()


def test_se_puede_desactivar_por_entorno(lines_env, monkeypatch):
    set_caps(monkeypatch, **{"dhcp-script": True, "script-on-renewal": True})
    monkeypatch.setenv("STEPAD_DHCP_EVENTS", "0")

    assert event_config_lines() == ""


def test_las_capacidades_se_leen_de_dnsmasq_help(monkeypatch):
    help_text = "Usage: dnsmasq\n --dhcp-script=<path>\n --script-on-renewal\n"
    monkeypatch.setattr(
        service_module.subprocess,
        "run",
        lambda *a, **k: SimpleNamespace(stdout=help_text, stderr="", returncode=0),
    )
    assert dnsmasq_capabilities(force=True) == {
        "dhcp-script": True,
        "script-on-renewal": True,
    }

    monkeypatch.setattr(
        service_module.subprocess,
        "run",
        lambda *a, **k: SimpleNamespace(stdout="--dhcp-script", stderr="", returncode=0),
    )
    assert dnsmasq_capabilities(force=True) == {
        "dhcp-script": True,
        "script-on-renewal": False,
    }

    def missing(*a, **k):
        raise FileNotFoundError("dnsmasq")

    monkeypatch.setattr(service_module.subprocess, "run", missing)
    assert dnsmasq_capabilities(force=True) == {
        "dhcp-script": False,
        "script-on-renewal": False,
    }


def test_ensure_event_script_es_idempotente(tmp_path):
    script, spool = tmp_path / "s.sh", tmp_path / "e.jsonl"

    first = ensure_event_script(script, spool).stat().st_mtime_ns
    second = ensure_event_script(script, spool).stat().st_mtime_ns

    assert first == second  # no se reescribe si no cambio


# ----------------------------------------------------------------------
# Efecto en la presencia (BD real + red simulada)
# ----------------------------------------------------------------------


@pytest.fixture
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    yield session
    session.close()


@pytest.fixture
def world():
    return World()


def ts_of(world, minutes_ago=0):
    return int((world.now - timedelta(minutes=minutes_ago)).timestamp())


def ev(world, action, mac=A, ip="192.168.1.30", minutes_ago=0):
    # `utcfromtimestamp` en el servicio: se arma el ts como UTC naive.
    from calendar import timegm

    stamp = timegm((world.now - timedelta(minutes=minutes_ago)).timetuple())
    return DhcpEvent(action, mac, ip, stamp)


def test_una_renovacion_pone_en_linea_a_un_equipo_que_no_responde_arp(db, world):
    phone = add(db, A, "192.168.1.30", "celular", last_seen=world.now - timedelta(hours=3))
    service = make_service(world)

    result = service.apply_events(db, [ev(world, "old")])

    db.refresh(phone)
    assert result["applied"] == 1
    assert (phone.presence_status, phone.presence_source) == ("ONLINE", "dhcp_event")
    assert phone.last_seen == world.now  # evidencia fuerte
    assert world.probed == []  # reaccion rapida: sin barrido de pings


def test_un_lease_vigente_sin_evento_sigue_sin_dar_presencia(db, world):
    """Regresion: la asignacion nunca es presencia."""
    phone = add(db, A, "192.168.1.30", "celular", last_seen=world.now - timedelta(hours=3))
    world.leases = {A: "192.168.1.30"}
    world.after_probe = []

    make_service(world).reconcile(db)

    db.refresh(phone)
    assert phone.presence_status == "OFFLINE"


def test_un_evento_viejo_da_probable_y_envejece(db, world):
    phone = add(db, A, "192.168.1.30", "celular")
    service = make_service(world)

    service.apply_events(db, [ev(world, "old", minutes_ago=10)])

    db.refresh(phone)
    assert phone.presence_status == "PROBABLE"

    world.now = world.now + timedelta(minutes=30)
    service.reconcile(db, active_probe=False)
    db.refresh(phone)
    assert phone.presence_status == "OFFLINE"


def test_un_del_retira_la_evidencia_al_instante(db, world):
    phone = add(db, A, "192.168.1.30", "celular")
    service = make_service(world)
    service.apply_events(db, [ev(world, "add")])
    db.refresh(phone)
    assert phone.presence_status == "ONLINE"

    service.apply_events(db, [ev(world, "del")])

    db.refresh(phone)
    assert phone.presence_status == "OFFLINE"
    assert phone.current_ip == ""
    assert phone.last_ip == "192.168.1.30"


def test_si_la_red_aun_ve_al_equipo_un_del_no_lo_da_de_baja(db, world):
    """La realidad (ARP alcanzable) gana a la ausencia de un lease."""
    pc = add(db, A, "192.168.1.30", "pc")
    world.neigh = [reach("192.168.1.30", A)]

    make_service(world).apply_events(db, [ev(world, "del")])

    db.refresh(pc)
    assert pc.presence_status == "ONLINE"


def test_un_evento_de_una_mac_desconocida_se_ignora(db, world):
    add(db, A, "192.168.1.30", "pc")

    result = make_service(world).apply_events(db, [ev(world, "add", mac=B)])

    assert result == {"success": True, "applied": 0}


def test_el_servicio_de_punta_a_punta(tmp_path, db, world, monkeypatch):
    """Linea en el spool -> evento -> presencia + IPAM."""
    phone = add(db, A, "192.168.1.30", "celular", last_seen=world.now - timedelta(hours=3))
    path = tmp_path / "events.jsonl"
    path.write_text("")
    spool = DhcpEventSpool(path)
    spool.poll()

    monkeypatch.setattr(presence_module, "DevicePresenceService", lambda: make_service(world))
    ipam_calls = []
    import backend.network.devices.services.ipam_service as ipam_module

    monkeypatch.setattr(
        ipam_module,
        "IpamService",
        lambda: SimpleNamespace(reconcile=lambda db: ipam_calls.append(1)),
    )

    now_ts = int(utcnow().timestamp())
    with path.open("a") as handle:
        handle.write(line("old", ts=now_ts) + "\n")

    # El reloj simulado debe coincidir con el del evento.
    world.now = utcnow()

    assert DhcpEventService(spool).process(db) == 1
    db.refresh(phone)
    assert phone.presence_source == "dhcp_event"
    assert ipam_calls == [1]

    assert DhcpEventService(spool).process(db) == 0  # nada nuevo
