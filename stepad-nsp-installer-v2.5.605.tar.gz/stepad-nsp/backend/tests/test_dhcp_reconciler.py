"""Reconciliador DHCP: único escritor, idempotente y a prueba de fallos.

- No reinicia si el contenido no cambió (un reinicio corta DHCP/DNS).
- Si la validación falla, restaura lo anterior y NO reinicia.
- El pool casi agotado se reporta; el pool es FIJO y nunca se amplía solo.
"""

import sys
from datetime import timedelta

from types import SimpleNamespace

from backend.dhcp.domain.leases import Lease

from backend.dhcp.reconciler import DhcpReconciler


module = sys.modules["backend.dhcp.reconciler"]


CONFIG = SimpleNamespace(
    interface="enp3s0",
    network="192.168.1.0",
    netmask="255.255.255.0",
    gateway="192.168.1.1",
    pool_start="192.168.1.20",
    pool_end="192.168.1.29",
    lease_time="24h",
    excluded_ips=["192.168.1.10-192.168.1.19"],
    group_ip_start="192.168.1.10",
    group_ip_end="192.168.1.19",
)


class FakeConfigProvider:

    def __init__(self):
        self.writes = 0
        self.content = "config-v1"

    def write_config(self, config):
        self.writes += 1
        (self.path).write_text(self.content, encoding="utf-8")
        return {"success": True}


class FakeReservationProvider:

    def __init__(self):
        self.content = "dhcp-host=aa:bb,192.168.1.25,\n"

    def write_reservations(self, reservations):
        self.path.write_text(self.content, encoding="utf-8")
        return {"success": True, "total": len(reservations)}


class FakeProcess:

    def __init__(self, running=True):
        self.running = running
        self.starts = 0

    def status(self):
        return {"running": self.running, "pid": 1}

    def start(self):
        self.starts += 1
        self.running = True
        return {"success": True, "pid": 2}

    def restart(self):
        self.starts += 1
        self.running = True
        return {"success": True, "pid": 2}


class FakeValidator:

    def __init__(self):
        self.ok = True

    def validate(self):
        if self.ok:
            return {"success": True}
        return {"success": False, "error": "bad conf"}


class FakeConfigService:

    def __init__(self, config=None):
        self.config = dict(config or {})
        self.updates = []

    def get_dhcp_config(self):
        return dict(self.config)

    def update_section(self, section, values):
        self.updates.append((section, dict(values)))
        self.config = dict(values)


def build(tmp_path, monkeypatch, running=True, alerts=None, emails=None, config_service=None, arp=None):

    config_provider = FakeConfigProvider()
    config_provider.path = tmp_path / "dnsmasq.conf"

    reservation_provider = FakeReservationProvider()
    reservation_provider.path = tmp_path / "reservations.conf"

    process = FakeProcess(running=running)

    validator = FakeValidator()

    reconciler = DhcpReconciler(
        config_builder=lambda: CONFIG,
        reservations_builder=lambda: [
            {"mac": "aa:bb", "ip": "192.168.1.25", "hostname": ""}
        ],
        provider=SimpleNamespace(
            write_config=config_provider.write_config,
            validate=validator.validate,
            start=process.start,
        ),
        reservation_provider=reservation_provider,
        process_manager=process,
        config_path=config_provider.path,
        reservations_path=reservation_provider.path,
        alert_notifier=(
            (lambda *args: alerts.append(args)) if alerts is not None else None
        ),
        email_notifier=(
            (lambda kind, free, threshold: emails.append((kind, free, threshold)))
            if emails is not None
            else None
        ),
        threshold_provider=lambda: 5,
        config_service=config_service,
        neighbor_verifier=lambda ips: {
            ip: mac
            for ip, mac in module.read_arp_table().items()
            if ip in set(ips)
        },
    )

    monkeypatch.setattr(module, "read_leases", lambda path: [])

    # Sin equipos reales en ARP: los tests no dependen de la LAN.
    monkeypatch.setattr(module, "read_arp_table", lambda: dict(arp or {}))

    return reconciler, process, validator, config_provider


def test_primer_apply_escribe_y_arranca(tmp_path, monkeypatch):

    reconciler, process, _, config_provider = build(tmp_path, monkeypatch)

    result = reconciler.apply()

    assert result["success"] is True
    assert result["changed"] is True
    assert process.starts == 1
    assert config_provider.path.read_text() == "config-v1"


def test_segundo_apply_sin_cambios_no_reinicia(tmp_path, monkeypatch):

    reconciler, process, _, _ = build(tmp_path, monkeypatch)

    reconciler.apply()

    result = reconciler.apply()

    assert result["skipped"] is True
    assert process.starts == 1  # no se reinició

    assert reconciler.status()["skipped"] >= 1


def test_cambio_de_contenido_reinicia(tmp_path, monkeypatch):

    reconciler, process, _, config_provider = build(tmp_path, monkeypatch)

    reconciler.apply()

    config_provider.content = "config-v2"

    reconciler.apply()

    assert process.starts == 2


def test_validacion_fallida_restaura_y_no_reinicia(tmp_path, monkeypatch):

    reconciler, process, validator, config_provider = build(tmp_path, monkeypatch)

    reconciler.apply()

    previous = config_provider.path.read_text()

    config_provider.content = "config-rota"

    validator.ok = False

    result = reconciler.apply()

    assert result["success"] is False

    assert config_provider.path.read_text() == previous

    assert process.starts == 1

    assert reconciler.status()["last_ok"] is False


def test_sin_lan_no_escribe(tmp_path, monkeypatch):

    reconciler, process, _, config_provider = build(tmp_path, monkeypatch)

    reconciler._config_builder = lambda: None

    result = reconciler.apply()

    assert result == {"success": False, "message": "LAN not detected"}

    assert process.starts == 0
    assert config_provider.writes == 0


def test_reporta_pool_bajo(tmp_path, monkeypatch):

    reconciler, _, _, _ = build(tmp_path, monkeypatch)

    # 10 dinamicas, 9 con lease -> 1 libre (< umbral 5).
    leases = [
        Lease(0, "aa:%02d" % i, "192.168.1.%d" % (21 + i))
        for i in range(9)
    ]

    monkeypatch.setattr(module, "read_leases", lambda path: leases)

    result = reconciler.apply()

    assert result["pool"]["free"] == 1

    assert result["pool"]["low"] is True


def test_alerta_solo_en_transiciones(tmp_path, monkeypatch):

    alerts = []

    reconciler, _, _, _ = build(tmp_path, monkeypatch, alerts=alerts)

    leases = [
        Lease(0, "aa:%02d" % i, "192.168.1.%d" % (21 + i))
        for i in range(9)
    ]

    monkeypatch.setattr(module, "read_leases", lambda path: leases)

    # Primera pasada: pool bajo -> 1 alerta.
    reconciler.apply()

    assert len(alerts) == 1

    assert alerts[0][0] == "DHCP_POOL_LOW"

    assert alerts[0][1] == "warning"

    # Sigue bajo: no repite.
    reconciler.apply()

    assert len(alerts) == 1

    # Se libera espacio: aviso de recuperacion.
    monkeypatch.setattr(module, "read_leases", lambda path: [])

    reconciler.apply()

    assert len(alerts) == 2

    assert alerts[1][0] == "DHCP_POOL_RECOVERED"

    assert alerts[1][1] == "info"


def test_correo_solo_en_transiciones(tmp_path, monkeypatch):

    alerts = []

    emails = []

    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, alerts=alerts, emails=emails
    )

    leases = [
        Lease(0, "aa:%02d" % i, "192.168.1.%d" % (21 + i))
        for i in range(9)
    ]

    monkeypatch.setattr(module, "read_leases", lambda path: leases)

    reconciler.apply()

    assert emails == [("low", 1, 5)]

    reconciler.apply()

    assert len(emails) == 1  # sigue bajo: no repite

    monkeypatch.setattr(module, "read_leases", lambda path: [])

    reconciler.apply()

    assert emails[1][0] == "recovered"


def test_ip_en_conflicto_persistente_se_excluye_del_pool(tmp_path, monkeypatch):

    service = FakeConfigService({"excluded_ips": ["192.168.1.10-192.168.1.19"]})

    reconciler, _, _, _ = build(
        tmp_path,
        monkeypatch,
        config_service=service,
        alerts=[],
        arp={"192.168.1.21": "00:11:22:33:44:55"},
    )

    # El lease .21 lo tiene otra MAC que la que responde en ARP.
    monkeypatch.setattr(
        module,
        "read_leases",
        lambda path: [Lease(0, "aa:bb:cc:dd:ee:ff", "192.168.1.21")],
    )

    reconciler.apply()

    assert service.updates == []  # primera vez: solo detecta

    # Persistencia medida por tiempo (10 min), no por dos applies.
    reconciler._conflict_first_seen["192.168.1.21"] -= timedelta(minutes=11)

    reconciler.apply()

    assert service.updates, "tras 10 min: debe excluir temporalmente"

    section, values = service.updates[-1]

    assert section == "dhcp"

    assert "192.168.1.21" in [item["ip"] for item in values["auto_excluded_ips"]]

    assert "192.168.1.21" not in values["excluded_ips"]

    assert reconciler.status()["auto_excluded"] == ["192.168.1.21"]


def test_ip_estatica_en_pool_se_excluye_en_el_primer_apply(
    tmp_path, monkeypatch
):

    service = FakeConfigService({"excluded_ips": []})

    reconciler, _, _, _ = build(
        tmp_path,
        monkeypatch,
        config_service=service,
        arp={"192.168.1.21": "00:11:22:33:44:55"},
    )

    reconciler.apply()

    assert service.updates, "la IP estática debe protegerse de inmediato"

    _, values = service.updates[-1]

    assert "192.168.1.21" in [
        item["ip"] for item in values["auto_excluded_ips"]
    ]


def test_conflicto_transitorio_no_excluye(tmp_path, monkeypatch):

    service = FakeConfigService({"excluded_ips": []})

    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, config_service=service, arp={}
    )

    monkeypatch.setattr(
        module,
        "read_leases",
        lambda path: [Lease(0, "aa:bb:cc:dd:ee:ff", "192.168.1.21")],
    )

    reconciler.apply()

    # Segunda pasada sin conflicto (desaparecio el ARP).
    monkeypatch.setattr(module, "read_arp_table", lambda: {})

    reconciler.apply()

    assert service.updates == []


def test_expired_auto_exclusions_are_ignored():
    from backend.dhcp.services.dhcp_service import DhcpService

    service = DhcpService.__new__(DhcpService)

    result = service._auto_excluded_ips(
        {
            "auto_excluded_ips": [
                {"ip": "192.168.1.50", "until": "2000-01-01T00:00:00+00:00"},
                {"ip": "192.168.1.51", "until": "2999-01-01T00:00:00+00:00"},
            ]
        }
    )

    assert result == ["192.168.1.51"]


def test_reclaim_no_corre_si_el_pool_no_esta_bajo():

    from backend.dhcp.reconciler import DhcpReconciler

    reconciler = DhcpReconciler.__new__(DhcpReconciler)

    assert reconciler._reclaim_if_needed({"low": False, "free": 40}) == 0
    assert reconciler._reclaim_if_needed(None) == 0
