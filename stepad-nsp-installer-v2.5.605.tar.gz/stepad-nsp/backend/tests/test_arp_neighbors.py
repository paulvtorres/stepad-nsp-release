from backend.dhcp.domain.neighbors import arp_mac_by_ip


def test_arp_conserva_varias_ips_de_la_misma_mac():
    text = """IP address       HW type     Flags       HW address            Mask     Device
192.168.1.42     0x1         0x2         84:a9:3e:06:82:9e     *        enp3s0
192.168.1.61     0x1         0x2         84:a9:3e:06:82:9e     *        enp3s0
"""
    assert arp_mac_by_ip(text) == {
        "192.168.1.42": "84:a9:3e:06:82:9e",
        "192.168.1.61": "84:a9:3e:06:82:9e",
    }
