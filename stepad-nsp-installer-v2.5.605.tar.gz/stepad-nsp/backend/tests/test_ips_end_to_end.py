"""End-to-end policy decisions without touching the real network.

Simulates the Suricata event path through ThreatResponseService, the
configured policy, alert generation and quarantine decisions.
"""

from datetime import timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.alerts.models.alert import Alert
from backend.core.database.base import Base
from backend.core.database.session import SessionLocal
from backend.ips.models.malware_event import MalwareEvent
from backend.ips.models.threat_response_setting import ThreatResponseSetting
from backend.ips.services.threat_response_service import ThreatResponseService
from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.datetime_utils import utcnow


def event(src_ip, signature="ET TROJAN Test", category="A Network Trojan was detected"):
    return {
        "alert": {
            "signature": signature,
            "category": category,
            "severity": 1,
            "signature_id": 2000001,
        },
        "src_ip": src_ip,
        "dest_ip": "8.8.8.8",
        "dst_port": 443,
    }


@pytest.fixture
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    yield session
    session.close()


@pytest.fixture
def service(db, monkeypatch):
    db.add(ThreatResponseSetting(
        quarantine_enabled=True,
        c2_block_enabled=False,
        protect_infrastructure=True,
        quarantine_max_per_window=5,
        quarantine_window_minutes=10,
    ))
    db.commit()

    svc = ThreatResponseService()
    blocked = []

    class Provider:
        def block_mac(self, mac):
            blocked.append(mac)
            return {"success": True}

    svc.provider = Provider()
    svc.blocked = blocked
    svc.audit_service = type("Audit", (), {
        "create_log": lambda *args, **kwargs: None
    })()
    svc._notify_quarantine = lambda *args, **kwargs: None
    monkeypatch.setattr(
        "backend.notifications.services.critical_alert_email_service.CriticalAlertEmailService.send",
        lambda *args, **kwargs: True,
    )
    return svc


def device(db, mac, ip, presence="ONLINE"):
    row = NetworkDevice(
        mac_address=mac,
        ip_address=ip,
        current_ip=ip,
        status="ONLINE" if presence == "ONLINE" else "OFFLINE",
        presence_status=presence,
        device_type="COMPUTER",
        last_seen=utcnow(),
    )
    db.add(row)
    db.commit()
    return row


def test_snmp_chain_alerts_but_never_quarantines(db, service):
    device(db, "aa:00:00:00:00:01", "192.168.1.42")

    result = service.handle_event(
        db,
        event(
            "192.168.1.42",
            signature="GPL SNMP public access udp",
            category="Attempted Information Leak",
        ),
    )

    assert result is not None
    assert result.quarantined is False
    assert service.blocked == []
    alert = db.query(Alert).filter(Alert.alert_type == "IPS_POLICY_ALERT").one()
    assert "SNMP" in alert.title
    assert "Política aplicada" in alert.message


def test_malware_chain_quarantines_verified_owner(db, service):
    owner = device(db, "aa:00:00:00:00:02", "192.168.1.43")

    result = service.handle_event(db, event("192.168.1.43"))

    assert result is not None
    assert result.quarantined is True
    assert service.blocked == [owner.mac_address]
    assert db.query(Alert).filter(Alert.alert_type == "quarantine").count() == 1


def test_chain_does_not_quarantine_without_verified_owner(db, service):
    device(db, "aa:00:00:00:00:03", "192.168.1.44", presence="OFFLINE")

    result = service.handle_event(db, event("192.168.1.44"))

    assert result is not None
    assert result.quarantined is False
    assert service.blocked == []
    assert db.query(MalwareEvent).count() == 1


def test_circuit_breaker_blocks_sixth_quarantine(db, service):
    for index in range(6):
        ip = f"192.168.2.{index + 1}"
        device(db, f"aa:00:00:00:01:{index:02x}", ip)

    for index in range(5):
        result = service.handle_event(
            db, event(f"192.168.2.{index + 1}")
        )
        assert result.quarantined is True

    sixth = service.handle_event(db, event("192.168.2.6"))

    assert sixth is not None
    assert sixth.quarantined is False
    assert len(service.blocked) == 5
    limit_alert = (
        db.query(Alert)
        .filter(Alert.alert_type == "QUARANTINE_LIMIT_REACHED")
        .one()
    )
    assert "límite" in limit_alert.title.lower()


def test_excepcion_por_equipo_evita_cuarentena(db, service):
    owner = device(db, "aa:00:00:00:00:09", "192.168.1.49")

    service.create_exception(
        db,
        mac_address=owner.mac_address,
        reason="Equipo crítico de producción",
    )

    result = service.handle_event(db, event("192.168.1.49"))

    assert result is not None
    assert result.quarantined is False
    assert service.blocked == []
    assert any(
        "excepción activa" in alert.message
        for alert in db.query(Alert).all()
    )
