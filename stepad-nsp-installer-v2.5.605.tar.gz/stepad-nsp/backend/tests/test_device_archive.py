from datetime import timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.services.device_lifecycle_service import (
    DeviceLifecycleService,
)
from backend.shared.datetime_utils import utcnow


def _db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def _device(db, mac, last_seen, last_ip="192.168.1.50", **kwargs):
    device = NetworkDevice(
        mac_address=mac,
        ip_address="",
        current_ip="",
        last_ip=last_ip,
        status="OFFLINE",
        device_type="COMPUTER",
        last_seen=last_seen,
        **kwargs,
    )
    db.add(device)
    db.commit()
    return device


def test_archiva_ausente_con_last_ip_conservada():
    db = _db()
    device = _device(db, "aa:00:00:00:00:01", utcnow() - timedelta(days=60))

    result = DeviceLifecycleService().reconcile(db, days=30)

    db.refresh(device)
    assert result["archived"] == 1
    assert device.archived_at is not None
    assert device.last_ip == "192.168.1.50"


def test_no_archiva_equipo_con_reserva():
    db = _db()
    device = _device(
        db,
        "aa:00:00:00:00:02",
        utcnow() - timedelta(days=60),
        permanent_ip="192.168.1.60",
    )

    result = DeviceLifecycleService().reconcile(db, days=30)

    db.refresh(device)
    assert result["archived"] == 0
    assert device.archived_at is None


def test_no_archiva_equipo_permanente_ni_vinculado():
    db = _db()
    permanent = _device(
        db,
        "aa:00:00:00:00:03",
        utcnow() - timedelta(days=60),
        is_permanent=True,
    )
    linked = _device(
        db,
        "aa:00:00:00:00:04",
        utcnow() - timedelta(days=60),
        linked_to_id=permanent.id,
    )

    result = DeviceLifecycleService().reconcile(db, days=30)

    db.refresh(permanent)
    db.refresh(linked)
    assert result["archived"] == 0
    assert permanent.archived_at is None
    assert linked.archived_at is None
