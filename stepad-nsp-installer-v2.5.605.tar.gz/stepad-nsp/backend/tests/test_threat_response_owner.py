"""Aislar solo al equipo que USA la IP ahora, nunca al que la tuvo antes.

La cuarentena es por MAC. Si el equipo se elige por la ultima IP conocida,
un equipo que se fue (y tuvo esa IP) puede quedar aislado mientras el
infectado, que la usa ahora, conserva el acceso.
"""

import os

os.environ.setdefault("STEPAD_ENV", "development")

from datetime import timedelta
from types import SimpleNamespace

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.ips.models.malware_event import MalwareEvent
from backend.ips.services.threat_response_service import ThreatResponseService
from backend.network.devices.repositories.device_repository import DeviceRepository
from backend.network.devices.services import device_presence_service as presence_module
from backend.shared.datetime_utils import utcnow
from backend.tests.test_device_presence_service import (
    World,
    add,
    make_service,
    reach,
)

OLD = "aa:00:00:00:00:01"   # tuvo la IP antes y ya se fue
NEW = "aa:00:00:00:00:02"   # la usa ahora (el infectado)
THIRD = "aa:00:00:00:00:03"
IP = "192.168.1.30"

EVENT = {
    "alert": {
        "signature": "ET TROJAN Example",
        "category": "A Network Trojan was detected",
        "severity": 1,
        "signature_id": 2000001,
    },
    "src_ip": IP,
    "dest_ip": "8.8.8.8",
    "dst_port": 443,
}


@pytest.fixture
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    yield session
    session.close()


@pytest.fixture
def world():
    w = World()
    w.now = utcnow()
    return w


class FakeProvider:
    def __init__(self):
        self.blocked = []

    def block_mac(self, mac):
        self.blocked.append(mac)
        return {"success": True}


class FakeAlerts:
    def __init__(self):
        self.created = []

    def create(self, db, **kwargs):
        self.created.append(kwargs)


@pytest.fixture
def service(monkeypatch, world):
    svc = ThreatResponseService()
    svc.provider = FakeProvider()
    svc.alert_service = FakeAlerts()
    svc.audit_service = SimpleNamespace(create_log=lambda *a, **k: None)
    svc._notify_quarantine = lambda *a, **k: None
    svc.get_settings = lambda db: {
        "quarantine_enabled": True,
        "c2_block_enabled": False,
        "protect_infrastructure": True,
    }
    monkeypatch.setattr(
        presence_module, "DevicePresenceService", lambda: make_service(world)
    )
    return svc


def former_owner(db, world):
    """Se fue hace dias: sigue figurando con esa IP como 'ultima conocida'."""
    device = add(db, OLD, IP, "ya-se-fue", last_seen=world.now - timedelta(days=3))
    device.presence_status = "OFFLINE"
    db.commit()
    return device


def current_owner(db, world, mac=NEW, name="infectado"):
    device = add(db, mac, IP, name, last_seen=world.now)
    device.current_ip = IP
    device.presence_status = "ONLINE"
    db.commit()
    return device


def test_se_aisla_al_equipo_que_usa_la_ip_no_al_que_la_tuvo_antes(db, service, world):
    # El que se fue se registro PRIMERO: con el `.first()` sin orden de antes
    # habria sido el elegido.
    former_owner(db, world)
    current_owner(db, world)

    event = service.handle_event(db, dict(EVENT))

    assert service.provider.blocked == [NEW]
    assert event.quarantined is True
    assert event.src_mac == NEW


def test_si_la_ip_la_reclaman_dos_equipos_no_se_aisla_a_ninguno(db, service, world):
    current_owner(db, world, mac=NEW)
    current_owner(db, world, mac=THIRD, name="otro")

    event = service.handle_event(db, dict(EVENT))

    assert service.provider.blocked == []
    assert event.quarantined is False
    assert event.device_id is None
    assert any(
        "más de un equipo" in alert["message"] for alert in service.alert_service.created
    )


def test_si_solo_existe_el_que_se_fue_no_se_aisla_a_nadie(db, service, world):
    former_owner(db, world)
    world.after_probe = []  # nadie contesta ARP en esa IP

    event = service.handle_event(db, dict(EVENT))

    assert service.provider.blocked == []
    assert event.device_id is None and event.src_mac is None
    assert any(
        "No se pudo verificar" in alert["message"]
        for alert in service.alert_service.created
    )


def test_un_equipo_aun_sin_presencia_se_verifica_por_arp_en_vivo(db, service, world):
    """El equipo acaba de conectarse: la presencia aun no lo registra."""
    former_owner(db, world)
    fresh = add(db, NEW, "", "recien-llegado", last_seen=world.now)
    world.after_probe = [reach(IP, NEW)]

    service.handle_event(db, dict(EVENT))

    assert service.provider.blocked == [NEW]
    assert fresh.id is not None


def test_un_equipo_que_responde_y_no_esta_en_el_inventario_no_se_aisla(
    db, service, world
):
    former_owner(db, world)
    world.after_probe = [reach(IP, "de:ad:be:ef:00:01")]

    service.handle_event(db, dict(EVENT))

    assert service.provider.blocked == []
    assert any(
        "inventario" in alert["message"] for alert in service.alert_service.created
    )


def test_una_rafaga_de_alertas_no_sondea_la_red_una_y_otra_vez(db, service, world):
    former_owner(db, world)
    world.after_probe = []

    for _ in range(5):
        service.handle_event(db, dict(EVENT))

    assert len(world.probed) == 1


def test_la_infraestructura_sigue_protegida(db, service, world):
    router = current_owner(db, world, name="router")
    router.device_type = "ROUTER"
    db.commit()

    event = service.handle_event(db, dict(EVENT))

    assert service.provider.blocked == []
    assert event.quarantined is False


# ----------------------------------------------------------------------
# find_by_ip: determinista, para todo el que atribuya trafico por IP
# ----------------------------------------------------------------------


def test_find_by_ip_prefiere_al_que_usa_la_ip_sin_importar_el_orden(db, world):
    former_owner(db, world)       # id menor
    owner = current_owner(db, world)

    assert DeviceRepository().find_by_ip(db, IP).id == owner.id


def test_find_by_ip_sin_dueño_actual_devuelve_el_visto_mas_recientemente(db, world):
    older = add(db, OLD, IP, "viejo", last_seen=world.now - timedelta(days=9))
    newer = add(db, NEW, IP, "reciente", last_seen=world.now - timedelta(days=1))

    assert DeviceRepository().find_by_ip(db, IP).id == newer.id
    assert older.id != newer.id


# ----------------------------------------------------------------------
# owner_of directamente
# ----------------------------------------------------------------------


def test_owner_of_prefiere_online_sobre_probable(db, world):
    online = current_owner(db, world, mac=NEW)
    probable = current_owner(db, world, mac=THIRD, name="probable")
    probable.presence_status = "PROBABLE"
    db.commit()

    device, reason = make_service(world).owner_of(db, IP)

    assert (device.id, reason) == (online.id, "verified")
