from datetime import timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.auth.services.api_token_service import ApiTokenService
from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


def db_session():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_token_se_crea_y_autentica():
    db = db_session()
    service = ApiTokenService()
    created = service.create(db, "script", role="OPERATOR", created_by=1)

    assert created["token"].startswith("nsp_")
    assert "token" not in service.list(db)[0]

    claims = service.authenticate(db, created["token"])
    assert claims["role"] == "OPERATOR"
    assert claims["auth_type"] == "api_token"


def test_token_revocado_no_autentica():
    db = db_session()
    service = ApiTokenService()
    created = service.create(db, "script", created_by=1)
    service.revoke(db, created["id"])

    assert service.authenticate(db, created["token"]) is None


def test_token_expirado_no_autentica():
    db = db_session()
    service = ApiTokenService()
    created = service.create(
        db,
        "script",
        created_by=1,
        expires_at=utcnow() + timedelta(seconds=1),
    )
    row = service.list(db)[0]
    # expire it directly for a deterministic test
    from backend.auth.models.api_token import ApiToken
    token = db.get(ApiToken, row["id"])
    token.expires_at = utcnow() - timedelta(minutes=1)
    db.commit()

    assert service.authenticate(db, created["token"]) is None


def test_token_no_se_guarda_en_claro():
    db = db_session()
    service = ApiTokenService()
    created = service.create(db, "script", created_by=1)

    from backend.auth.models.api_token import ApiToken
    row = db.query(ApiToken).one()
    assert created["token"] not in (row.token_hash or "")
    assert len(row.token_hash) == 64
