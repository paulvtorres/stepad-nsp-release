from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.core.database.base import Base
from backend.notifications.services.email_outbox_service import EmailOutboxService


def db_session():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_outbox_deduplica_pendientes():
    db = db_session()
    service = EmailOutboxService()

    first = service.enqueue(
        db=db,
        channel="critical",
        to_emails="soporte@empresa.com",
        subject="Alerta",
        html_body="<p>Prueba</p>",
    )
    second = service.enqueue(
        db=db,
        channel="critical",
        to_emails="soporte@empresa.com",
        subject="Alerta",
        html_body="<p>Prueba</p>",
    )

    assert first.id == second.id
    assert len(service.list_pending(db)) == 1


def test_outbox_ignora_correo_invalido():
    db = db_session()
    service = EmailOutboxService()

    assert service.enqueue(
        db=db,
        channel="critical",
        to_emails="sopòrte@empresa.com",
        subject="Alerta",
        html_body="<p>Prueba</p>",
    ) is None


def test_outbox_permite_reintento_manual():
    db = db_session()
    service = EmailOutboxService()

    row = service.enqueue(
        db=db,
        channel="quarantine",
        to_emails="soporte@empresa.com",
        subject="Cuarentena",
        html_body="<p>Prueba</p>",
    )

    assert row.status == "pending"
    assert service.retry_now(db, row.id)["success"] is True
    assert service.list_pending(db)[0]["id"] == row.id


def test_outbox_lista_fallidos_para_reintento():
    db = db_session()
    service = EmailOutboxService()
    row = service.enqueue(
        db=db,
        channel="quarantine",
        to_emails="soporte@empresa.com",
        subject="Fallido",
        html_body="<p>Prueba</p>",
    )
    row.status = "failed"
    row.attempts = 5
    db.commit()

    assert service.list_pending(db) == []
    assert service.list_items(db, status="failed")[0]["id"] == row.id
    assert service.list_items(db, status="all")[0]["status"] == "failed"
