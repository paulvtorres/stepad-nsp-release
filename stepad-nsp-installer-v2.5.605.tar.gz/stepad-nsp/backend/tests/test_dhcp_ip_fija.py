"""IP fija dentro del pool: se protege, pero solo si de verdad esta en uso.

Un equipo que se va deja una entrada ARP STALE que el kernel conserva
indefinidamente. Si eso bastara para excluir la IP, el pool (que es FIJO)
se encogeria con cada equipo que se fue.
"""

from types import SimpleNamespace

import pytest

import backend.dhcp.providers.dnsmasq_reservation_provider as provider_module
from backend.dhcp.domain.leases import Lease
from backend.dhcp.providers.dnsmasq_reservation_provider import (
    DnsmasqReservationProvider,
)
from backend.tests.test_dhcp_reconciler import (
    FakeConfigService,
    build,
    module,
)

GHOST_MAC = "00:11:22:33:44:55"
STATIC = {"192.168.1.22": GHOST_MAC}


def _service():
    return FakeConfigService({"excluded_ips": []})


def _excluded(service):
    return [
        item["ip"]
        for _, values in service.updates
        for item in values.get("auto_excluded_ips", [])
    ]


def test_arp_viejo_de_un_equipo_ausente_no_excluye_la_ip(tmp_path, monkeypatch):
    service, alerts = _service(), []
    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, config_service=service, alerts=alerts, arp=dict(STATIC)
    )
    # Tras el ping nadie responde: la entrada es un fantasma.
    reconciler._neighbor_verifier = lambda ips: {}

    reconciler.apply()
    reconciler.apply()

    assert _excluded(service) == []
    assert "DHCP_STATIC_IN_POOL" not in [a[0] for a in alerts]


def test_ip_fija_que_responde_se_excluye_y_se_avisa(tmp_path, monkeypatch):
    service, alerts = _service(), []
    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, config_service=service, alerts=alerts, arp=dict(STATIC)
    )
    reconciler._neighbor_verifier = lambda ips: {"192.168.1.22": GHOST_MAC}

    reconciler.apply()

    assert _excluded(service) == ["192.168.1.22"]
    static_alerts = [a for a in alerts if a[0] == "DHCP_STATIC_IN_POOL"]
    assert len(static_alerts) == 1 and static_alerts[0][1] == "warning"
    assert "192.168.1.22" in static_alerts[0][3]


def test_si_no_se_puede_verificar_se_protege_la_ip(tmp_path, monkeypatch):
    service = _service()
    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, config_service=service, arp=dict(STATIC)
    )

    def boom(ips):
        raise RuntimeError("sin ip neigh")

    reconciler._neighbor_verifier = boom

    reconciler.apply()

    assert _excluded(service) == ["192.168.1.22"]


def test_otra_mac_respondiendo_no_confirma_el_conflicto(tmp_path, monkeypatch):
    service = _service()
    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, config_service=service, arp=dict(STATIC)
    )
    reconciler._neighbor_verifier = lambda ips: {"192.168.1.22": "aa:aa:aa:aa:aa:aa"}

    reconciler.apply()

    assert _excluded(service) == []


def test_lease_de_uno_usado_por_otro_confirmado_es_critico(tmp_path, monkeypatch):
    alerts = []
    reconciler, _, _, _ = build(
        tmp_path, monkeypatch, alerts=alerts, config_service=_service(), arp=dict(STATIC)
    )
    monkeypatch.setattr(
        module,
        "read_leases",
        lambda path: [Lease(0, "aa:00:00:00:00:09", "192.168.1.22")],
    )
    reconciler._neighbor_verifier = lambda ips: {"192.168.1.22": GHOST_MAC}

    reconciler.apply()

    assert ("DHCP_IP_CONFLICT", "critical") in [(a[0], a[1]) for a in alerts]


# ----------------------------------------------------------------------
# Reservas: una fila mala no congela el resto
# ----------------------------------------------------------------------


def _provider(tmp_path, monkeypatch, run):
    destination = tmp_path / "reservations.conf"
    monkeypatch.setattr(provider_module, "DOMAINS_CONFIG", tmp_path / "domains.conf")
    monkeypatch.setattr(provider_module, "RESERVATIONS_CONFIG", destination)
    monkeypatch.setattr(provider_module.subprocess, "run", run)
    return DnsmasqReservationProvider(), destination


def _ok(*args, **kwargs):
    return SimpleNamespace(returncode=0, stdout="", stderr="")


def test_una_reserva_mala_se_omite_y_las_demas_se_aplican(tmp_path, monkeypatch):
    provider, destination = _provider(tmp_path, monkeypatch, _ok)

    result = provider.write_reservations(
        [
            {"mac": "aa:bb:cc:dd:ee:01", "ip": "192.168.1.40"},
            {"mac": "no-es-mac", "ip": "192.168.1.41"},
            {"mac": "aa:bb:cc:dd:ee:03", "ip": "192.168.1.40"},  # IP repetida
            {"mac": "aa:bb:cc:dd:ee:04", "ip": "192.168.1.44"},
        ]
    )

    assert result["total"] == 2
    assert [item["reason"].split(":")[0] for item in result["skipped"]] == [
        "MAC inválida",
        "IP duplicada",
    ]
    text = destination.read_text()
    assert "192.168.1.40" in text and "192.168.1.44" in text
    assert "no-es-mac" not in text


def test_sin_binario_dnsmasq_las_reservas_no_se_bloquean(tmp_path, monkeypatch):
    def missing(*args, **kwargs):
        raise FileNotFoundError("dnsmasq")

    provider, destination = _provider(tmp_path, monkeypatch, missing)

    result = provider.write_reservations(
        [{"mac": "aa:bb:cc:dd:ee:01", "ip": "192.168.1.40"}]
    )

    assert result["total"] == 1
    assert "192.168.1.40" in destination.read_text()


def test_el_reconciliador_avisa_de_las_reservas_omitidas(tmp_path, monkeypatch):
    alerts = []
    reconciler, _, _, _ = build(tmp_path, monkeypatch, alerts=alerts)
    original = reconciler._reservation_provider.write_reservations

    def with_skipped(reservations):
        result = original(reservations)
        result["skipped"] = [
            {"mac": "no-es-mac", "ip": "192.168.1.41", "reason": "MAC inválida: 'no-es-mac'"}
        ]
        return result

    reconciler._reservation_provider.write_reservations = with_skipped

    reconciler.apply()

    assert [a[0] for a in alerts] == ["DHCP_RESERVATION_INVALID"]
    assert "no-es-mac" in alerts[0][3]
