from datetime import timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import backend.core.database.models_registry  # noqa: F401
from backend.alerts.services.alert_service import AlertService
from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


def db_session():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_snooze_temporal_expira(monkeypatch):
    monkeypatch.setattr(
        "backend.audit.services.audit_service.AuditService.create_log",
        lambda *args, **kwargs: None,
    )
    db = db_session()
    service = AlertService()

    service.add_ignore_rule(
        db,
        match_field="title",
        matcher="exact",
        value="CPU alta",
        expires_at=utcnow() + timedelta(hours=1),
        reason="mantenimiento",
        remove_existing=False,
    )

    assert service.repository.is_ignored(db, "RESOURCE_CPU", "CPU alta") is True

    rule = service.repository.list_ignore_rules(db)[0]
    rule.expires_at = utcnow() - timedelta(minutes=1)
    db.commit()

    assert service.repository.is_ignored(db, "RESOURCE_CPU", "CPU alta") is False


def test_snooze_permanente_sigue_activo(monkeypatch):
    monkeypatch.setattr(
        "backend.audit.services.audit_service.AuditService.create_log",
        lambda *args, **kwargs: None,
    )
    db = db_session()
    service = AlertService()

    service.add_ignore_rule(
        db,
        match_field="alert_type",
        matcher="exact",
        value="RESOURCE_CPU",
        remove_existing=False,
    )

    assert service.repository.is_ignored(db, "RESOURCE_CPU", "CPU alta") is True
