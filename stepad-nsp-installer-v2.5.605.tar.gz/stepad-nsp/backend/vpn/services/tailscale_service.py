import json
import os
import subprocess
import urllib.error
import urllib.request

from pathlib import Path
from typing import Optional

from backend.shared.logging.logger import logger


class TailscaleService:

    TAILSCALE = Path("/usr/bin/tailscale")

    API_BASE = "https://api.tailscale.com/api/v2"

    ENV_FILE = Path("/etc/stepad/stepad.env")

    def _run(self, *args: str, timeout: int = 30) -> dict:

        if not self.TAILSCALE.exists():

            return {
                "success": False,
                "output": "",
                "error": "tailscale no instalado"
            }

        try:

            result = subprocess.run(
                [str(self.TAILSCALE), *args],
                capture_output=True,
                text=True,
                timeout=timeout
            )

            return {
                "success": result.returncode == 0,
                "output": result.stdout.strip(),
                "error": result.stderr.strip()
            }

        except subprocess.TimeoutExpired:

            return {
                "success": False,
                "output": "",
                "error": "comando tailscale tardó demasiado"
            }

    def _api_token(self) -> str:
        return os.getenv("STEPAD_TAILSCALE_API_KEY", "").strip()

    def _token_configured(self) -> bool:
        return bool(self._api_token())

    def set_api_token(self, api_key: str) -> dict:

        api_key = (api_key or "").strip()

        if not api_key.startswith("tskey-api-"):

            return {
                "success": False,
                "error": "invalid_token",
                "message": (
                    "El valor debe comenzar con tskey-api- "
                    "(API access token de Tailscale)."
                )
            }

        lines = []

        if self.ENV_FILE.exists():

            lines = self.ENV_FILE.read_text(encoding="utf-8").splitlines()

        new_lines = []
        updated = False

        for line in lines:

            stripped = line.strip()

            if not stripped or stripped.startswith("#") or "=" not in stripped:

                new_lines.append(line)
                continue

            key = stripped.split("=", 1)[0].strip()

            if key == "STEPAD_TAILSCALE_API_KEY":

                new_lines.append("STEPAD_TAILSCALE_API_KEY=" + api_key)
                updated = True
                continue

            new_lines.append(line)

        if not updated:

            new_lines.append("STEPAD_TAILSCALE_API_KEY=" + api_key)

        self.ENV_FILE.parent.mkdir(parents=True, exist_ok=True)

        self.ENV_FILE.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

        try:
            self.ENV_FILE.chmod(0o600)
        except OSError:
            pass

        os.environ["STEPAD_TAILSCALE_API_KEY"] = api_key

        logger.info("STEPAD_TAILSCALE_API_KEY guardada en %s", self.ENV_FILE)

        return {"success": True, "configured": True}

    def _device_id(self) -> Optional[str]:

        res = self._run("status", "--json")

        if not res["success"] or not res["output"]:
            return None

        try:
            data = json.loads(res["output"])
        except (ValueError, TypeError):
            return None

        self_info = data.get("Self") or {}

        return self_info.get("ID")

    def _api(self, method: str, path: str, body: Optional[dict] = None) -> dict:

        token = self._api_token()

        if not token:

            return {
                "success": False,
                "error": "not_configured",
                "configured": False,
                "message": (
                    "No hay API token de Tailscale configurado. Généralo en "
                    "login.tailscale.com (Settings → Keys) y guárdalo con el "
                    "botón 'Guardar token'."
                )
            }

        request = urllib.request.Request(self.API_BASE + path, method=method)

        request.add_header("Authorization", "Bearer " + token)

        request.add_header("Accept", "application/json")

        payload = None

        if body is not None:

            payload = json.dumps(body).encode("utf-8")

            request.add_header("Content-Type", "application/json")

        try:

            with urllib.request.urlopen(request, data=payload, timeout=30) as response:

                raw = response.read().decode("utf-8")

                parsed = json.loads(raw) if raw else {}

                return {
                    "success": True,
                    "status": response.status,
                    "data": parsed
                }

        except urllib.error.HTTPError as exc:

            detail = ""

            try:
                detail = exc.read().decode("utf-8")
            except Exception as error:
                logger.debug("tailscale_service._api: %s", error)
            logger.warning(
                "Tailscale API %s %s -> %s: %s",
                method, path, exc.code, detail
            )

            message = detail or str(exc)

            try:

                parsed = json.loads(detail) if detail else {}

                if parsed.get("message"):
                    message = parsed.get("message")

            except (ValueError, TypeError):
                pass

            return {
                "success": False,
                "status": exc.code,
                "error": "api_error",
                "message": message
            }

        except (urllib.error.URLError, OSError) as exc:

            logger.warning(
                "Tailscale API %s %s sin conexión: %s",
                method, path, exc
            )

            return {
                "success": False,
                "error": "network_error",
                "message": f"No se pudo contactar la API de Tailscale: {exc}"
            }

    def _normalize_invite(self, invite: dict) -> dict:

        return {
            "id": invite.get("id"),
            "invite_url": invite.get("inviteUrl"),
            "capacity": invite.get("capacity"),
            "state": invite.get("state"),
            "email": invite.get("email") or invite.get("acceptedByUserEmail") or "",
            "created_at": invite.get("createdAt"),
            "expires_at": invite.get("expiresAt")
        }

    def list_shares(self) -> dict:

        device_id = self._device_id()

        if not device_id:

            return {
                "success": False,
                "error": "not_connected",
                "message": "Este NSP no está conectado a Tailscale."
            }

        result = self._api("GET", f"/device/{device_id}/device-invites")

        if not result["success"]:
            return result

        invites = result["data"]

        if isinstance(invites, dict):
            invites = invites.get("invites") or invites.get("deviceInvites") or []

        return {
            "success": True,
            "configured": True,
            "invites": [self._normalize_invite(item) for item in (invites or [])]
        }

    def create_share(self, capacity: int = 1, email: Optional[str] = None) -> dict:

        device_id = self._device_id()

        if not device_id:

            return {
                "success": False,
                "error": "not_connected",
                "message": "Este NSP no está conectado a Tailscale."
            }

        body: dict = {"capacity": capacity}

        if email:
            body["email"] = email

        result = self._api("POST", f"/device/{device_id}/device-invites", body)

        if not result["success"]:
            return result

        return {"success": True, "configured": True, "invite": self._normalize_invite(result["data"])}

    def revoke_share(self, invite_id: str) -> dict:

        result = self._api("DELETE", f"/device-invites/{invite_id}")

        if not result["success"]:
            return result

        return {"success": True, "revoked": invite_id}

    def get_status(self) -> dict:

        installed = self.TAILSCALE.exists()

        if not installed:

            return {
                "installed": False,
                "state": "not_installed",
                "ip": "",
                "hostname": None,
                "web_url": None,
                "ssh": None
            }

        state = "need_login"
        ip = ""
        hostname = None

        ip_run = self._run("ip", "-4")

        if ip_run["success"] and ip_run["output"]:

            ip = ip_run["output"].splitlines()[0].strip()
            state = "connected"

        st = self._run("status")

        lines = st["output"].splitlines()

        if lines:

            parts = lines[0].split()

            if len(parts) >= 2:

                hostname = parts[1]

        logger.info("Tailscale status: state=%s ip=%s hostname=%s", state, ip, hostname)

        return {
            "installed": installed,
            "state": state,
            "ip": ip,
            "hostname": hostname,
            "web_url": f"https://{ip}:8443" if ip else None,
            "ssh": f"ssh paulan@{ip}" if ip else None
        }

    def connect(self, auth_key: str) -> dict:

        res = self._run(
            "up",
            "--authkey=" + auth_key,
            "--hostname=stepad-nsp",
            "--accept-routes",
            timeout=120
        )

        status = self.get_status()

        return {
            **status,
            "success": res["success"],
            "output": res["output"],
            "error": res["error"]
        }

    def disconnect(self) -> dict:

        res = self._run("logout", timeout=30)

        return {
            "success": res["success"],
            "output": res["output"],
            "error": res["error"]
        }