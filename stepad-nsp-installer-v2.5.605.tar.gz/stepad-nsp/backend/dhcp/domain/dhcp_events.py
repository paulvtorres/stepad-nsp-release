"""Eventos de lease de dnsmasq: parser y script (puro, sin I/O).

dnsmasq invoca `--dhcp-script` con:  <accion> <MAC> <IP> [hostname]
  add  = lease nuevo
  old  = lease existente (con `--script-on-renewal`: cada renovacion)
  del  = lease vencido o liberado
  init = volcado de leases al arrancar (se ignora: no es una señal del equipo)

Una renovacion es evidencia REAL de que el equipo esta presente en ese
instante (el cliente acaba de hablar con el servidor), a diferencia de un
lease vigente que solo dice que la IP esta asignada.

El script del lado de dnsmasq solo anota una linea JSON; el NSP la valida
aqui. Nada del contenido se confia: se exige formato estricto de MAC, IP e
interfaz.
"""

from __future__ import annotations

import ipaddress
import json
import re
from dataclasses import dataclass

ACTIONS = frozenset({"add", "old", "del"})

_MAC = re.compile(r"^[0-9a-f]{2}(:[0-9a-f]{2}){5}$")

_IFACE = re.compile(r"^[A-Za-z0-9_.:@-]{1,32}$")

# Tolerancia al reloj: un evento no puede venir del futuro ni ser antiguo.
MAX_FUTURE_SECONDS = 60

MAX_AGE_SECONDS = 24 * 3600


@dataclass(frozen=True)
class DhcpEvent:

    action: str
    mac: str
    ip: str
    ts: int
    iface: str = ""


def parse_event_line(line: str, now_ts: int) -> DhcpEvent | None:
    """Valida UNA linea del spool. Devuelve None si no es confiable."""

    line = (line or "").strip()

    if not line or len(line) > 512:

        return None

    try:

        raw = json.loads(line)

    except ValueError:

        return None

    if not isinstance(raw, dict):

        return None

    action = str(raw.get("action") or "").lower()

    if action not in ACTIONS:

        return None

    mac = str(raw.get("mac") or "").strip().lower()

    if not _MAC.match(mac):

        return None

    try:

        ip = str(ipaddress.IPv4Address(str(raw.get("ip") or "").strip()))

    except ValueError:

        return None

    try:

        ts = int(raw.get("ts"))

    except (TypeError, ValueError):

        return None

    if ts > now_ts + MAX_FUTURE_SECONDS or ts < now_ts - MAX_AGE_SECONDS:

        # Reloj descuadrado o linea reciclada: se usa la hora de lectura.
        ts = now_ts

    iface = str(raw.get("iface") or "")

    if iface and not _IFACE.match(iface):

        iface = ""

    return DhcpEvent(action, mac, ip, ts, iface)


def render_event_script(spool_path: str) -> str:
    """Script POSIX que dnsmasq ejecuta. Rapido, sin dependencias y NUNCA
    bloquea a dnsmasq: solo agrega una linea y sale con 0.

    No se incluye el hostname (texto libre del cliente): la identidad la
    resuelve el descubrimiento, no este canal.
    """

    return f"""#!/bin/sh
# Generado por STEPAD. No editar: se regenera al aplicar la configuracion DHCP.
# dnsmasq: $1=accion (add|old|del|init) $2=MAC $3=IP
SPOOL='{spool_path}'
case "$1" in
  add|old|del) ;;
  *) exit 0 ;;
esac
[ -n "$2" ] && [ -n "$3" ] || exit 0
printf '{{"ts":%s,"action":"%s","mac":"%s","ip":"%s","iface":"%s"}}\\n' \\
  "$(date +%s)" "$1" "$2" "$3" "${{DNSMASQ_INTERFACE:-}}" >> "$SPOOL" 2>/dev/null
exit 0
"""
