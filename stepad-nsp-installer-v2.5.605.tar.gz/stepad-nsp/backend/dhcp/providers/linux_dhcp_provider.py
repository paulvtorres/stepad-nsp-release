import ipaddress
import os
import subprocess

from backend.core.config.paths import (
    DNSMASQ_CONFIG,
    RESERVATIONS_CONFIG,
    DNSMASQ_PID_FILE,
    ZONES_DHCP_CONFIG,
    DNS_DIR
)

from backend.core.dnsmasq.process_manager import (
    dnsmasq_process_manager
)

from backend.dhcp.dnsmasq.dns_section_builder import DnsmasqDnsSectionBuilder

from backend.dhcp.models.dhcp_config import DhcpConfig

from backend.dhcp.services.dhcp_event_service import event_config_lines


class LinuxDhcpProvider:


    CONFIG_PATH = DNSMASQ_CONFIG


    DNSMASQ_BIN = "/usr/sbin/dnsmasq"



    def _pool_ranges(
        self,
        pool_start: str,
        pool_end: str,
        excluded_ips: list[str]
    ):
        """Rangos contiguos sin las IPs excluidas (lógica en el dominio)."""

        from backend.dhcp.domain.pool import build_ranges
        from backend.dhcp.domain.exclusions import excluded_addresses

        start = int(ipaddress.ip_address(pool_start))
        end = int(ipaddress.ip_address(pool_end))

        return [
            (str(ipaddress.ip_address(a)), str(ipaddress.ip_address(b)))
            for a, b in build_ranges(start, end, excluded_addresses(excluded_ips))
        ]

    def write_config(
        self,
        config: DhcpConfig
    ):

        dns_section = DnsmasqDnsSectionBuilder.build()


        ranges = self._pool_ranges(
            config.pool_start,
            config.pool_end,
            config.excluded_ips
        )

        range_lines = "\n".join(
            f"dhcp-range={start},{end},{config.netmask},{config.lease_time}"
            for start, end in ranges
        )

        # Eventos de lease en tiempo real (solo si este dnsmasq los soporta).
        event_lines = event_config_lines()

        content = f"""# STEPAD DHCP Configuration

interface={config.interface}

bind-dynamic

# Único DHCP autorizado en la LAN: rechaza renovaciones/leases
# que no coincidan con este servidor (no bloquea otro DHCP en L2).
dhcp-authoritative

{event_lines}
{range_lines}

dhcp-option=3,{config.gateway}

dhcp-option=6,{config.dns_server}

pid-file={DNSMASQ_PID_FILE}

{dns_section}

# DHCP Reservations (reload via SIGHUP, no restart needed)

dhcp-hostsfile={RESERVATIONS_CONFIG}

# Network Zones

conf-file={ZONES_DHCP_CONFIG}

# Group DNS assignment (per-department DNS)

conf-file={DNS_DIR / "groups_dns.conf"}
"""

        # dnsmasq errors if a conf-file is missing -- make sure the
        # group DNS file exists even when there are no groups yet.
        groups_conf = DNS_DIR / "groups_dns.conf"

        groups_conf.parent.mkdir(parents=True, exist_ok=True)

        if not groups_conf.exists():

            groups_conf.write_text(
                "# Auto-generated group DNS assignment\n"
            )


        # dnsmasq requires included configuration files to exist
        # before startup.
        ZONES_DHCP_CONFIG.parent.mkdir(
            parents=True,
            exist_ok=True
        )


        if not ZONES_DHCP_CONFIG.exists():

            ZONES_DHCP_CONFIG.write_text("")


        self.CONFIG_PATH.parent.mkdir(
            parents=True,
            exist_ok=True
        )


        tmp = self.CONFIG_PATH.with_suffix(self.CONFIG_PATH.suffix + ".tmp")

        tmp.write_text(content, encoding="utf-8")

        os.replace(tmp, self.CONFIG_PATH)


        return {
            "success": True,
            "config": str(self.CONFIG_PATH)
        }



    def start(self):

        # Centralized process management. All DHCP lifecycle actions
        # use the same dnsmasq process manager.
        return dnsmasq_process_manager.start()



    def stop(self):

        return dnsmasq_process_manager.stop()



    def status(self):

        return dnsmasq_process_manager.status()



    def validate(self):

        result = subprocess.run(
            [
                self.DNSMASQ_BIN,
                "--test",
                "--conf-file=" + str(self.CONFIG_PATH)
            ],
            capture_output=True,
            text=True,
            timeout=10
        )


        return {
            "success": result.returncode == 0,
            "output": result.stdout.strip(),
            "error": result.stderr.strip()
        }