"""Eventos de lease de dnsmasq en tiempo real.

Flujo:

    dnsmasq --dhcp-script --> dhcp-event.sh --> spool JSONL --> este servicio
                                                                   |
                       DevicePresenceService.apply_events  <-------+
                       IpamService.reconcile               <-------+

* El script solo anota una linea y sale: no puede frenar a dnsmasq.
* Cada renovacion (`old`, con `script-on-renewal`) y cada lease nuevo
  (`add`) es evidencia REAL de presencia: el equipo acaba de hablar con el
  servidor. Un `del` quita esa evidencia al instante.
* Todo es opcional y degrada con elegancia: si el dnsmasq instalado no
  soporta el script, no se emite nada y el sondeo de 60 s sigue cubriendo.
"""

from __future__ import annotations

import os
import subprocess
import time
from datetime import datetime
from pathlib import Path

from backend.core.config.paths import DHCP_EVENT_SCRIPT, DHCP_EVENT_SPOOL
from backend.dhcp.domain.dhcp_events import (
    DhcpEvent,
    parse_event_line,
    render_event_script,
)
from backend.shared.logging.logger import logger

DNSMASQ_BIN = "/usr/sbin/dnsmasq"

# El spool se rota al pasar de este tamaño (ya consumido).
SPOOL_MAX_BYTES = 256 * 1024

# Maximo que se lee por pasada (protege ante un spool inflado).
READ_CHUNK = 1024 * 1024


# ----------------------------------------------------------------------
# Provision del script y configuracion de dnsmasq
# ----------------------------------------------------------------------

_capabilities: dict[str, bool] | None = None


def dnsmasq_capabilities(force: bool = False) -> dict[str, bool]:
    """Que opciones soporta el dnsmasq instalado (se consulta una vez).

    Si una opcion no existe, `dnsmasq --test` rechazaria TODA la
    configuracion; por eso solo se emite lo que el binario declara.
    """

    global _capabilities

    if _capabilities is not None and not force:

        return _capabilities

    caps = {"dhcp-script": False, "script-on-renewal": False}

    try:

        proc = subprocess.run(
            [DNSMASQ_BIN, "--help"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        text = (proc.stdout or "") + (proc.stderr or "")

        for name in caps:

            caps[name] = f"--{name}" in text

    except (OSError, subprocess.SubprocessError) as error:

        logger.debug("dhcp events: no se pudo consultar dnsmasq: %s", error)

    _capabilities = caps

    return caps


def ensure_event_script(
    script_path: Path | None = None,
    spool_path: Path | None = None,
) -> Path:
    """Escribe el script (idempotente) con permisos de root y devuelve su ruta."""

    script_path = Path(script_path or DHCP_EVENT_SCRIPT)

    spool_path = Path(spool_path or DHCP_EVENT_SPOOL)

    content = render_event_script(str(spool_path))

    script_path.parent.mkdir(parents=True, exist_ok=True)

    current = None

    try:

        current = script_path.read_text(encoding="utf-8")

    except OSError:

        pass

    if current != content:

        tmp = script_path.with_suffix(script_path.suffix + ".tmp")

        tmp.write_text(content, encoding="utf-8")

        os.chmod(tmp, 0o750)

        os.replace(tmp, script_path)

    else:

        os.chmod(script_path, 0o750)

    return script_path


def event_config_lines() -> str:
    """Lineas de dnsmasq.conf para activar los eventos ('' si no aplica)."""

    if os.environ.get("STEPAD_DHCP_EVENTS", "1") == "0":

        return ""

    caps = dnsmasq_capabilities()

    if not caps.get("dhcp-script"):

        return ""

    try:

        script = ensure_event_script()

    except OSError as error:

        logger.warning("dhcp events: no se pudo crear el script: %s", error)

        return ""

    lines = f"dhcp-script={script}\n"

    if caps.get("script-on-renewal"):

        lines += "script-on-renewal\n"

    return lines


# ----------------------------------------------------------------------
# Lectura del spool
# ----------------------------------------------------------------------


class DhcpEventSpool:
    """Lee las lineas NUEVAS del spool, sin repetir ni perder las parciales."""

    def __init__(self, path: Path | None = None, max_bytes: int = SPOOL_MAX_BYTES):

        self.path = Path(path or DHCP_EVENT_SPOOL)

        self.max_bytes = max_bytes

        self._offset: int | None = None

        self._partial = b""

    def poll(self, now_ts: int | None = None) -> list[DhcpEvent]:

        now_ts = int(time.time()) if now_ts is None else int(now_ts)

        try:

            size = self.path.stat().st_size

        except OSError:

            # Aun no hay eventos: cuando aparezca el archivo se lee entero.
            if self._offset is None:

                self._offset = 0

            return []

        if self._offset is None:

            # Primera lectura: no se reprocesa la historia de antes del panel.
            self._offset = size

            return []

        if size < self._offset:

            # Rotado o truncado.
            self._offset = 0

            self._partial = b""

        if size == self._offset:

            return []

        try:

            with self.path.open("rb") as handle:

                handle.seek(self._offset)

                chunk = handle.read(min(size - self._offset, READ_CHUNK))

        except OSError:

            return []

        self._offset += len(chunk)

        data = self._partial + chunk

        lines = data.split(b"\n")

        # La ultima pieza puede ser una linea a medio escribir.
        self._partial = lines.pop()

        events = []

        for raw in lines:

            event = parse_event_line(raw.decode("utf-8", errors="replace"), now_ts)

            if event is not None:

                events.append(event)

        self._maybe_rotate()

        return events

    def _maybe_rotate(self) -> None:

        if self._offset is None or self._offset < self.max_bytes:

            return

        if self._partial:

            return

        try:

            os.replace(self.path, str(self.path) + ".1")

            self._offset = 0

        except OSError as error:

            logger.debug("dhcp events: no se pudo rotar el spool: %s", error)


# ----------------------------------------------------------------------
# Procesamiento
# ----------------------------------------------------------------------


class DhcpEventService:

    def __init__(self, spool: DhcpEventSpool | None = None):

        self.spool = spool or DhcpEventSpool()

    def process(self, db=None) -> int:
        """Lee los eventos nuevos y actualiza presencia e IPAM. Devuelve cuantos."""

        events = self.spool.poll()

        if not events:

            return 0

        own = db is None

        if own:

            from backend.core.database.session import SessionLocal

            db = SessionLocal()

        try:

            from backend.network.devices.services.device_presence_service import (
                DevicePresenceService,
            )
            from backend.network.devices.services.ipam_service import IpamService

            DevicePresenceService().apply_events(db, events)

            try:

                IpamService().reconcile(db)

            except Exception as error:

                logger.debug("dhcp events: ipam: %s", error)

        finally:

            if own:

                db.close()

        return len(events)

    @staticmethod
    def event_time(event: DhcpEvent) -> datetime:

        return datetime.utcfromtimestamp(event.ts)
