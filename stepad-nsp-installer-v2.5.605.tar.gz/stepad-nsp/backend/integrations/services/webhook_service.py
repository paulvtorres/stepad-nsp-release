"""Alert webhooks with HMAC signatures and retry/backoff."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import threading
import time

from datetime import timedelta
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from sqlalchemy.orm import Session

from backend.integrations.models.webhook import WebhookEndpoint, WebhookDelivery
from backend.shared.datetime_utils import utcnow
from backend.shared.security import secret_box


MAX_ATTEMPTS = 5
RETRY_BASE = 60
RETRY_MAX = 3600


class WebhookService:

    _worker = None
    _stop = None

    @staticmethod
    def _events(value):
        return {
            item.strip().lower()
            for item in str(value or "").split(",")
            if item.strip()
        }

    def _serialize(self, row):
        return {
            "id": row.id,
            "name": row.name,
            "url": row.url,
            "events": row.events,
            "enabled": bool(row.enabled),
            "created_at": row.created_at.isoformat() if row.created_at else None,
            "last_success_at": row.last_success_at.isoformat() if row.last_success_at else None,
            "last_error": row.last_error,
            "failure_count": row.failure_count,
        }

    def list(self, db: Session):
        return [
            self._serialize(row)
            for row in db.query(WebhookEndpoint).order_by(WebhookEndpoint.id.desc()).all()
        ]

    def create(self, db: Session, name: str, url: str, events: str = "*", created_by=None):
        name = str(name or "").strip()
        url = str(url or "").strip()
        if not name or not url:
            raise ValueError("Nombre y URL son obligatorios.")
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ValueError("La URL debe ser http(s) válida.")
        events = ",".join(sorted(self._events(events) or {"*"}))
        raw_secret = secrets.token_urlsafe(32)
        row = WebhookEndpoint(
            name=name[:80],
            url=url[:500],
            secret_encrypted=secret_box.encrypt(raw_secret),
            events=events[:500],
            created_by=created_by,
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        result = self._serialize(row)
        result["secret"] = raw_secret
        return result

    def delete(self, db: Session, endpoint_id: int):
        row = db.get(WebhookEndpoint, endpoint_id)
        if row is None:
            raise LookupError("Webhook no encontrado.")
        db.delete(row)
        db.commit()
        return {"success": True, "deleted": endpoint_id}

    def enqueue_alert(self, db, alert_type, severity, title, message, created_at=None):
        endpoints = (
            db.query(WebhookEndpoint)
            .filter(WebhookEndpoint.enabled.is_(True))
            .all()
        )
        event_type = str(alert_type or "alert")
        payload = json.dumps({
            "event": event_type,
            "severity": severity,
            "title": title,
            "message": message,
            "created_at": (created_at or utcnow()).isoformat(),
        }, ensure_ascii=False)
        for endpoint in endpoints:
            events = self._events(endpoint.events)
            if "*" not in events and event_type.lower() not in events:
                continue
            db.add(WebhookDelivery(
                endpoint_id=endpoint.id,
                event_type=event_type[:50],
                payload=payload,
                status="pending",
                attempts=0,
                next_attempt_at=utcnow(),
            ))
        db.commit()

    @staticmethod
    def _signature(secret: str, payload: str) -> str:
        return "sha256=" + hmac.new(
            secret.encode("utf-8"),
            payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def process_due(self, db: Session | None = None, limit: int = 20):
        from backend.core.database.session import SessionLocal

        own = db is None
        if own:
            db = SessionLocal()

        sent = 0
        failed = 0

        try:
            rows = (
                db.query(WebhookDelivery)
                .filter(
                    WebhookDelivery.status == "pending",
                    WebhookDelivery.attempts < MAX_ATTEMPTS,
                )
                .order_by(WebhookDelivery.id)
                .limit(max(1, min(int(limit), 100)))
                .all()
            )
            now = utcnow()
            for row in rows:
                if row.next_attempt_at and row.next_attempt_at > now:
                    continue
                endpoint = db.get(WebhookEndpoint, row.endpoint_id)
                if endpoint is None or not endpoint.enabled:
                    row.status = "failed"
                    row.last_error = "endpoint eliminado o inactivo"
                    db.add(row)
                    db.commit()
                    failed += 1
                    continue
                secret = secret_box.decrypt(endpoint.secret_encrypted)
                try:
                    req = Request(
                        endpoint.url,
                        data=row.payload.encode("utf-8"),
                        headers={
                            "Content-Type": "application/json",
                            "User-Agent": "STEPAD-NSP/1.0",
                            "X-STEPAD-Event": row.event_type,
                            "X-STEPAD-Signature": self._signature(secret, row.payload),
                        },
                        method="POST",
                    )
                    with urlopen(req, timeout=10) as response:
                        if response.status >= 300:
                            raise RuntimeError(f"HTTP {response.status}")
                    row.status = "sent"
                    row.sent_at = utcnow()
                    row.last_error = None
                    endpoint.last_success_at = utcnow()
                    endpoint.failure_count = 0
                    endpoint.last_error = None
                    sent += 1
                except Exception as error:
                    row.attempts += 1
                    row.last_error = str(error)[:1000]
                    row.next_attempt_at = now + timedelta(
                        seconds=min(RETRY_MAX, RETRY_BASE * (2 ** max(0, row.attempts - 1)))
                    )
                    if row.attempts >= MAX_ATTEMPTS:
                        row.status = "failed"
                    endpoint.failure_count = int(endpoint.failure_count or 0) + 1
                    endpoint.last_error = row.last_error
                    failed += 1
                db.add(row)
                db.add(endpoint)
                db.commit()
            return {"sent": sent, "failed": failed}
        finally:
            if own:
                db.close()

    def _loop(self):
        while not self._stop.is_set():
            try:
                self.process_due()
            except Exception:
                pass
            for _ in range(30):
                if self._stop.is_set():
                    return
                time.sleep(1)

    def start_worker(self):
        if self._worker is not None and self._worker.is_alive():
            return
        self._stop = threading.Event()
        self._worker = threading.Thread(
            target=self._loop, daemon=True, name="webhook-worker"
        )
        self._worker.start()

    def stop_worker(self):
        if self._stop is not None:
            self._stop.set()
        self._worker = None
