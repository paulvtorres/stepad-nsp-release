"""Secure API tokens (raw value shown once, only SHA-256 stored)."""

from __future__ import annotations

import hashlib
import secrets

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from backend.auth.models.api_token import ApiToken
from backend.shared.datetime_utils import utcnow
from backend.shared.constants.user_roles import UserRoles


PREFIX = "nsp_"


def _hash(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class ApiTokenService:

    def _serialize(self, row: ApiToken) -> dict:
        return {
            "id": row.id,
            "name": row.name,
            "prefix": row.prefix,
            "role": row.role,
            "enabled": bool(row.enabled),
            "created_at": row.created_at.isoformat() if row.created_at else None,
            "last_used_at": row.last_used_at.isoformat() if row.last_used_at else None,
            "expires_at": row.expires_at.isoformat() if row.expires_at else None,
            "revoked_at": row.revoked_at.isoformat() if row.revoked_at else None,
        }

    def list(self, db: Session) -> list[dict]:
        rows = db.query(ApiToken).order_by(ApiToken.id.desc()).all()
        return [self._serialize(row) for row in rows]

    def create(self, db: Session, name: str, role: str = UserRoles.OPERATOR, created_by: int | None = None, expires_at=None) -> dict:
        name = str(name or "").strip()
        role = str(role or UserRoles.OPERATOR).upper()
        if not name:
            raise ValueError("El nombre es obligatorio.")
        if role not in UserRoles.LEVELS:
            raise ValueError("Rol inválido.")

        expires = None
        if expires_at:
            if isinstance(expires_at, str):
                try:
                    expires = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                except ValueError as error:
                    raise ValueError("Fecha de expiración inválida.") from error
            else:
                expires = expires_at
            if expires.tzinfo is not None:
                expires = expires.astimezone(timezone.utc).replace(tzinfo=None)
            if expires <= utcnow():
                raise ValueError("La expiración debe ser futura.")

        raw = PREFIX + secrets.token_urlsafe(32)
        row = ApiToken(
            name=name[:80],
            token_hash=_hash(raw),
            prefix=raw[:12],
            role=role,
            enabled=True,
            created_by=created_by,
            expires_at=expires,
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        result = self._serialize(row)
        result["token"] = raw
        return result

    def revoke(self, db: Session, token_id: int) -> dict:
        row = db.get(ApiToken, token_id)
        if row is None:
            raise LookupError("Token no encontrado.")
        row.enabled = False
        row.revoked_at = utcnow()
        db.add(row)
        db.commit()
        return {"success": True, "id": token_id}

    def authenticate(self, db: Session, raw: str) -> dict | None:
        if not raw or not raw.startswith(PREFIX):
            return None
        row = (
            db.query(ApiToken)
            .filter(
                ApiToken.token_hash == _hash(raw),
                ApiToken.enabled.is_(True),
                ApiToken.revoked_at.is_(None),
            )
            .first()
        )
        if row is None:
            return None
        if row.expires_at is not None and row.expires_at <= utcnow():
            return None
        row.last_used_at = utcnow()
        db.add(row)
        db.commit()
        return {
            "id": row.created_by,
            "user_id": row.created_by,
            "username": f"token:{row.name}",
            "role": row.role,
            "auth_type": "api_token",
        }
