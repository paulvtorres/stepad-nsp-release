import ipaddress
import subprocess
import threading
import time

from concurrent.futures import ThreadPoolExecutor

from datetime import datetime, timedelta
from backend.shared.datetime_utils import utcnow

from sqlalchemy.orm import Session

from backend.infrastructure.network.adapters.linux.arp_provider import (
    ARPProvider
)

from backend.infrastructure.network.services.hostname_resolver import (
    HostnameResolver
)

from backend.dhcp.services.dhcp_lease_service import (
    DhcpLeaseService
)

from backend.network.configuration.services.network_configuration_service import (
    NetworkConfigurationService,
)

from backend.network.services.lan_scope_service import LanScopeService

from backend.network.devices.models.network_device import (
    NetworkDevice,
)

from backend.network.devices.services.ip_ownership_service import (
    IpOwnershipService,
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.network.devices.services.device_classifier import (
    DeviceClassifier
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.groups.services.group_service import (
    GroupService
)

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.shared.logging.logger import logger


# Ventana de "recien activo" por trafico DNS real: cubre celulares/
# tablets con ahorro de energia que no responden ARP a tiempo (quedan
# INCOMPLETE en la tabla de vecinos) pero siguen navegando -- sin esto
# se dan de baja (u nunca se agregan) pese a tener trafico continuo.
RECENT_DNS_ACTIVITY_MINUTES = 15

# Un solo barrido LAN a la vez: si se solapan (monitor + escaneo manual +
# reintentos), se multiplican los pings y la CPU se dispara.
_SWEEP_LOCK = threading.Lock()

MAX_SWEEP_WORKERS = 32


def should_clear_hostname(
    status: str | None,
    lease_name: str | None,
    display_name: str | None,
    hostname: str | None,
    is_infrastructure: bool,
    confirmed_elsewhere: bool = False,
) -> bool:

    """True si el nombre guardado pertenece a OTRO equipo.

    Solo se borra cuando el mismo nombre lo confirma otro equipo (lease
    DHCP o resolucion en vivo) y este equipo no lo declara por ninguna
    via. Asi no se muestran datos de otro equipo (caso real: el nombre
    del PC aparecia en un telefono IP por reutilizacion de IP) sin
    perder nombres unicos que solo estan desactualizados.

    Los equipos APAGADOS conservan su historico, y un nombre manual
    (`display_name`) o de infraestructura nunca se toca.
    """

    return bool(
        status == "ONLINE"
        and not (lease_name or "").strip()
        and not (display_name or "").strip()
        and (hostname or "").strip()
        and not is_infrastructure
        and confirmed_elsewhere
    )


class DeviceDiscoveryService:


    def __init__(self):

        self.provider = ARPProvider()

        self.lease_service = DhcpLeaseService()

        self.hostname_resolver = HostnameResolver()

        self.network_configuration = NetworkConfigurationService()

        self.repository = DeviceRepository()

        self.classifier = DeviceClassifier()

        self.zone_repository = NetworkZoneRepository()

        self.lan_scope = LanScopeService()

        self.dns_log_repository = DnsQueryLogRepository()

    def _sweep_lan(
        self,
        network
    ):
        """
        Ping a todos los hosts del segmento LAN (paralelo) para poblar
        la tabla ARP. Los equipos encendidos pero sin trafico hacia el
        NSP no estan en ARP y se marcarian OFFLINE; al barrer, sus
        respuestas quedan en la tabla y el estado es fiel.
        """

        try:

            interface = network.get("interface")

            if interface and not self.lan_scope.is_lan_interface(interface):

                return

            cidr = network.get("network")

            net = ipaddress.ip_network(cidr, strict=False)

        except Exception as error:
            logger.debug("device_discovery_service._sweep_lan: %s", error)

            return

        # No barrer subredes gigantes.
        if net.num_addresses > 4096:

            return

        if not _SWEEP_LOCK.acquire(blocking=False):

            logger.debug("device_discovery_service: barrido ya en curso; se omite")
            return

        try:

            hosts = [str(host) for host in net.hosts()]

            def _ping(host):

                try:
                    subprocess.run(
                        ["ping", "-c", "1", "-W", "1", "-q", host],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        timeout=2,
                    )
                except (OSError, subprocess.SubprocessError):
                    pass

            with ThreadPoolExecutor(
                max_workers=min(MAX_SWEEP_WORKERS, max(1, len(hosts)))
            ) as pool:

                list(pool.map(_ping, hosts))

            # Dejar que las respuestas llenen la tabla ARP.
            time.sleep(2)

        except Exception as error:
            logger.debug("device_discovery_service._sweep_lan: %s", error)

        finally:
            _SWEEP_LOCK.release()
    def synchronize(
        self,
        db: Session,
        *,
        deep: bool = True,
    ):
        # Este metodo hace barrido ping + resolucion de hostname por
        # cada equipo (red/subproceso, hasta ~1.5s cada uno,
        # secuencial). Si el caller ya hizo una lectura en `db` sin
        # comitear (p. ej. MonitoringComponent._check_new_devices),
        # esa transaccion queda abierta ("idle in transaction" en
        # Postgres) durante todo ese tiempo, bloqueando al scheduler y
        # pudiendo colgar la UI. Se cierra aqui antes de arrancar.
        #
        # deep=False: sin ping-storm del segmento; solo ARP/leases
        # (para el tick de monitoreo). deep=True: barrido completo
        # (boton "Escanear red").
        db.commit()

        lan_configs = self.lan_scope.lan_configurations()

        if not lan_configs:

            self._mark_all_devices_offline(db)

            return []

        devices_by_mac = {}

        for network in lan_configs:

            if deep:

                self._sweep_lan(network)

            interface = network.get("interface")

            if not interface:

                continue

            if not self.lan_scope.is_lan_interface(interface):

                continue

            for device in self.provider.list_devices(interface):

                if not self.lan_scope.is_discoverable(
                    device.ip_address,
                    interface,
                ):

                    continue

                key = device.mac_address.lower()

                devices_by_mac[key] = device

        devices = list(devices_by_mac.values())

        found_macs = set(devices_by_mac.keys())



        leases = [
            lease
            for lease in self.lease_service.list_leases()
            if self.lan_scope.is_lan_ip(lease.ip)
        ]



        leases_by_mac = {

            lease.mac.lower(): lease

            for lease in leases

            if lease.mac

        }

        leases_by_ip = {

            lease.ip: lease

            for lease in leases

            if lease.ip

        }



        saved_devices = []

        default_zone = self.zone_repository.find_default(db)

        recent_active_ips = self.dns_log_repository.recent_active_ips(
            db,
            utcnow() - timedelta(
                minutes=RECENT_DNS_ACTIVITY_MINUTES
            ),
        )

        for device in devices:

            lease = leases_by_mac.get(
                device.mac_address.lower()
            )

            if lease:

                device.hostname = lease.hostname

                device.device_type = self.classifier.classify(
                    device.hostname
                )

        # Resolucion en vivo (NetBIOS/mDNS/LLMNR), EN PARALELO para
        # todos los equipos no-infraestructura -- no solo los que
        # llegaron sin nombre. Esto es a proposito: el lease DHCP
        # puede quedar con el nombre VIEJO si el equipo cambio de
        # nombre pero todavia no renovo el lease (frecuente en
        # Windows), y antes solo se resolvia si "not device.hostname"
        # -- si ya habia un nombre (aunque fuera el viejo, desde el
        # lease) nunca se preguntaba al equipo su nombre actual. Igual
        # que "Actualizar informacion" (refresh_device), el nombre en
        # vivo manda sobre un lease desactualizado. Al ir en paralelo
        # (antes era secuencial, ~1.5s POR equipo) el costo total no
        # crece con la cantidad de equipos.
        from concurrent.futures import ThreadPoolExecutor

        resolvable = [
            device
            for device in devices
            if not DeviceClassifier.is_infrastructure(device.device_type)
        ]

        def _resolve_live_name(device):

            try:

                resolved, _source = (
                    self.hostname_resolver.resolve_with_source(
                        device.ip_address,
                        timeout=1.5,
                    )
                )

                return device.mac_address.lower(), resolved

            except Exception as error:
                logger.debug("device_discovery_service._resolve_live_name: %s", error)

                return device.mac_address.lower(), None

        live_names_by_mac = {}

        if resolvable:

            with ThreadPoolExecutor(
                max_workers=min(32, len(resolvable))
            ) as pool:

                for mac, resolved in pool.map(
                    _resolve_live_name, resolvable
                ):

                    if resolved:

                        live_names_by_mac[mac] = resolved

        # Nombres que ALGUN equipo confirma (lease DHCP o resolucion en
        # vivo). Sirve para detectar nombres heredados de otro equipo.
        confirmed_names = {
            (name or "").strip().lower()
            for name in live_names_by_mac.values()
            if (name or "").strip()
        }

        for lease in leases:

            name = (lease.hostname or "").strip().lower()

            if name:

                confirmed_names.add(name)

        for device in devices:

            live_name = live_names_by_mac.get(
                device.mac_address.lower()
            )

            if live_name and (
                not device.hostname
                or live_name.lower() != device.hostname.lower()
            ):

                device.hostname = live_name

                device.device_type = self.classifier.classify(
                    live_name
                )

            elif not live_name:

                lease = leases_by_mac.get(
                    (device.mac_address or "").lower()
                )

                lease_name = (lease.hostname or "").strip() if lease else ""

                # Nombre NO confirmado: el equipo esta en linea, no tiene
                # lease con nombre, no responde NetBIOS/mDNS/LLMNR y no
                # tiene nombre manual. Conservarlo mostraba nombres de
                # OTRO equipo (IP reutilizada) en el listado.
                if should_clear_hostname(
                    device.status,
                    lease_name,
                    getattr(device, "display_name", None),
                    device.hostname,
                    DeviceClassifier.is_infrastructure(
                        device.device_type
                    ),
                    confirmed_elsewhere=(
                        (device.hostname or "").strip().lower()
                        in confirmed_names
                    ),
                ):

                    device.hostname = None

                    mac_type = DeviceClassifier.classify_by_mac(
                        device.mac_address
                    )

                    if mac_type and mac_type != "UNKNOWN":

                        device.device_type = mac_type

            # Fallback por MAC (OUI del fabricante): muchos telefonos IP,
            # impresoras y routers no declaran hostname ni responden a
            # netbios/mDNS/LLMNR. Si la clasificacion por nombre no los
            # marco como infraestructura, se intenta por fabricante.
            # Solo se aplica si el OUI da un resultado util (nunca
            # "UNKNOWN", para no pisar el tipo derivado del nombre).
            if not DeviceClassifier.is_infrastructure(
                device.device_type
            ):

                mac_type = DeviceClassifier.classify_by_mac(
                    device.mac_address
                )

                if mac_type != "UNKNOWN":

                    device.device_type = mac_type

        # Buscar todos los equipos ya conocidos de UNA sola vez (antes:
        # 1 query por equipo detectado -- con decenas/cientos de
        # equipos eran otras tantas idas y vueltas a la base).
        existing_by_mac = self.repository.find_by_macs(
            db,
            [device.mac_address for device in devices]
        )

        for device in devices:

            existing = existing_by_mac.get(
                device.mac_address.lower()
            )

            if existing:

                # Skip IP assignment for permanent devices only
                # ALWAYS update ip_address with real current IP from ARP/DHCP
                # permanent_ip is a SEPARATE field - only the reserved IP
                IpOwnershipService().set_ip(
                    db, existing, device.ip_address, "discovery"
                )

                # NO pisar el nombre guardado (p. ej. fijado con
                # "Actualizar información") si el equipo no reporta uno
                # nuevo (lease o resolucion). Si device.hostname es None,
                # se conserva el nombre existente.
                if device.hostname:

                    # El nombre visible era un nombre fijado a mano que
                    # ya no coincide con el que reporta el equipo ahora
                    # -- igual que en "Actualizar informacion", se
                    # limpia para que se vea el nombre real y no uno
                    # congelado.
                    if (
                        existing.display_name
                        and existing.display_name.lower()
                        != device.hostname.lower()
                    ):

                        existing.display_name = None

                    existing.hostname = device.hostname

                existing.vendor = device.vendor

                existing.interface = device.interface

                existing.device_type = device.device_type

                # `status` y `last_seen` son de DevicePresenceService.



                self.repository.update(
                    db,
                    existing
                )


                saved_devices.append(existing)



            else:


                model = NetworkDevice(

                    ip_address="",

                    mac_address=device.mac_address,

                    hostname=device.hostname,

                    vendor=device.vendor,

                    interface=device.interface,

                    status="ONLINE",

                    device_type=device.device_type,

                    zone_id=default_zone.id if default_zone else None,

                    first_seen=utcnow(),

                    last_seen=utcnow()

                )



                saved = self.repository.save(
                    db,
                    model
                )

                IpOwnershipService().set_ip(
                    db, saved, device.ip_address, "discovery"
                )

                self.repository.update(db, saved)

                # New/unrecognized device lands in the default group
                # (Invitados) automatically; the admin moves it to its
                # department later. Los dispositivos de infraestructura
                # (impresoras, teléfonos IP, routers) NO pueden
                # pertenecer a grupos, así que no se asignan.
                if not DeviceClassifier.is_infrastructure(
                    model.device_type
                ):
                    try:

                        group_service = GroupService()

                        default_group = group_service.ensure_default_group(db)

                        group_service.repository.add_device(
                            db,
                            default_group.id,
                            saved.id
                        )

                    except Exception as error:

                        logger.warning(
                            f"Auto-assign to default group failed: {error}"
                        )

                saved_devices.append(saved)



        #
        # Los equipos que ya no aparecen NO se marcan OFFLINE aqui: la
        # presencia envejece por la hora de su ultima evidencia y la
        # calcula DevicePresenceService (unico escritor de estado).
        #

        #
        # NO se purgan dispositivos por IP fuera de la red LAN actual:
        # al cambiar el segmento, los equipos conservan su registro (por
        # MAC), grupo y zona; su IP se actualiza cuando reconectan. El
        # borrado es SOLO manual (caso extremo) y preserva los logs.
        #


        #
        # Refrescar nombres desde los leases DHCP (el nombre
        # autoritativo). Esto cubre equipos que renovaron su lease
        # (con un hostname nuevo) pero que en este momento no figuran
        # en el ARP -- así "Escanear Red" sí actualiza el nombre.
        #
        # OJO: debe ser SOLO para equipos que no aparecieron en el ARP
        # de esta pasada (found_macs). Los que sí aparecieron ya se
        # procesaron arriba con resolucion en vivo, que puede haber
        # detectado un nombre MAS actual que el del lease (equipo
        # renombrado pero con lease todavia sin renovar) -- si este
        # segundo pase no los excluye, pisa ese nombre recien
        # detectado con el del lease viejo.
        #

        leased_by_mac = self.repository.find_by_macs(
            db,
            [
                lease.mac for lease in leases
                if lease.mac and lease.mac.lower() not in found_macs
            ]
        )

        for lease in leases:

            if not lease.mac:

                continue

            if lease.mac.lower() in found_macs:

                continue

            leased_device = leased_by_mac.get(lease.mac.lower())

            if leased_device is None:

                # Tiene lease DHCP (el equipo pidio y usa una IP nuestra)
                # pero nunca respondio ARP a tiempo en ningun barrido --
                # p. ej. celulares/tablets con ahorro de energia. Antes
                # esto significaba que JAMAS aparecia en el inventario
                # aunque llevara dias generando trafico DNS real. Se usa
                # la actividad DNS reciente para decidir si esta online
                # ahora, en vez de asumir "nunca visto = no existe".
                device_type = self.classifier.classify(lease.hostname)

                model = NetworkDevice(
                    ip_address="",
                    mac_address=lease.mac,
                    hostname=lease.hostname,
                    vendor=None,
                    interface=None,
                    status=(
                        "ONLINE"
                        if lease.ip in recent_active_ips
                        else "OFFLINE"
                    ),
                    device_type=device_type,
                    zone_id=default_zone.id if default_zone else None,
                    first_seen=utcnow(),
                    last_seen=utcnow(),
                )

                saved = self.repository.save(db, model)

                IpOwnershipService().set_ip(
                    db, saved, lease.ip, "lease"
                )

                self.repository.update(db, saved)

                if not DeviceClassifier.is_infrastructure(device_type):

                    try:

                        group_service = GroupService()

                        default_group = (
                            group_service.ensure_default_group(db)
                        )

                        group_service.repository.add_device(
                            db,
                            default_group.id,
                            saved.id
                        )

                    except Exception as error:

                        logger.warning(
                            f"Auto-assign to default group failed "
                            f"(lease-only device): {error}"
                        )

                saved_devices.append(saved)

                continue

            # El lease es la fuente autoritativa de la IP ACTUAL --
            # si el equipo dejo de responder ARP justo cuando dnsmasq
            # le reasigno otra IP, el registro se queda con la IP
            # vieja para siempre (el "no aparece" que reporta el
            # usuario es en realidad "aparece con la IP de hace
            # horas/dias"). Se corrige aqui, junto con el estado
            # online/offline usando el trafico DNS reciente en la
            # IP NUEVA (la vieja ya no tiene por que tener trafico).
            ip_changed = leased_device.ip_address != lease.ip

            if ip_changed and leased_device.ip_address:

                IpOwnershipService().set_ip(
                    db, leased_device, lease.ip, "lease"
                )

            hostname_changed = (
                bool(lease.hostname)
                and leased_device.hostname != lease.hostname
            )

            if hostname_changed:

                if (
                    leased_device.display_name
                    and leased_device.display_name.lower()
                    != lease.hostname.lower()
                ):

                    leased_device.display_name = None

                leased_device.hostname = lease.hostname

                leased_device.device_type = self.classifier.classify(
                    lease.hostname
                )

            if ip_changed or hostname_changed:

                self.repository.update(db, leased_device)


        return saved_devices


    def _mark_all_devices_offline(
        self,
        db: Session
    ):

        from backend.network.devices.services.device_presence_service import (
            DevicePresenceService,
        )

        DevicePresenceService().mark_all_offline(db)