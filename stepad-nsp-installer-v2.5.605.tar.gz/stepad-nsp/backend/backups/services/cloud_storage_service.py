import json
import os
import subprocess
import threading
import time

from pathlib import Path
from datetime import datetime, timedelta
from backend.shared.datetime_utils import utcnow

from sqlalchemy.orm import Session

from backend.backups.models.cloud_storage_settings import (
    CloudStorageSettings
)
from backend.backups.repositories.backup_settings_repository import (
    BackupSettingsRepository
)
from backend.shared.utils.datetimes import to_iso_utc
from backend.audit.models.audit_log import AuditLog
from backend.alerts.models.alert import Alert
from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger

STEPAD_DIR = Path("/etc/stepad")
RCLONE_DIR = STEPAD_DIR / "rclone"
RCLONE_CONF = RCLONE_DIR / "rclone.conf"
UPLOAD_DIR = STEPAD_DIR / "log_uploads"
REMOTE_NAME = "stepad-logs"

RCLONE_BIN = "/usr/bin/rclone"
BACKUP_DIR = STEPAD_DIR / "backups"
ENV_FILE = STEPAD_DIR / "stepad.env"


class CloudStorageService:

    def __init__(self):

        self._scheduler_thread = None
        self._stop = False
        self._settings_repo = BackupSettingsRepository()


    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self._get_or_create(db)

        return {
            "enabled": settings.enabled,
            "provider": settings.provider,
            "endpoint": settings.endpoint or "",
            "bucket": settings.bucket or "",
            "remote_path": settings.remote_path or "",
            "host": settings.host or "",
            "user": settings.user or "",
            "has_access_key": bool(settings.access_key),
            "has_secret_key": bool(settings.secret_key),
            "has_password": bool(settings.password),
            "upload_hour": settings.upload_hour,
            "upload_minute": settings.upload_minute,
            "upload_days": settings.upload_days,
            "last_upload_at": to_iso_utc(settings.last_upload_at),
            "last_upload_result": settings.last_upload_result or "",
            "backup_upload_enabled": bool(settings.backup_upload_enabled),
            "backup_remote_path": settings.backup_remote_path or "backups",
            "backup_retention_count": settings.backup_retention_count or 7,
            "backup_last_upload_at": to_iso_utc(
                settings.backup_last_upload_at
            ),
            "backup_last_result": settings.backup_last_result or "",
        }


    def save_settings(
        self,
        db: Session,
        request
    ) -> dict:

        settings = self._get_or_create(db)

        if request.enabled is not None:
            settings.enabled = request.enabled
        if request.provider is not None:
            settings.provider = request.provider
        if request.endpoint is not None:
            settings.endpoint = request.endpoint.strip() or None
        if request.bucket is not None:
            settings.bucket = request.bucket.strip() or None
        if request.remote_path is not None:
            settings.remote_path = request.remote_path.strip() or None
        if request.host is not None:
            settings.host = request.host.strip() or None
        if request.user is not None:
            settings.user = request.user.strip() or None

        # credentials: only overwrite when the operator sends a new value.
        if request.access_key:
            settings.access_key = self._encrypt_secret(
                request.access_key.strip()
            )
        if request.secret_key:
            settings.secret_key = self._encrypt_secret(
                request.secret_key.strip()
            )
        if request.password:
            settings.password = self._encrypt_secret(
                request.password.strip()
            )

        if request.upload_hour is not None:
            settings.upload_hour = request.upload_hour
        if request.upload_minute is not None:
            settings.upload_minute = request.upload_minute
        if request.upload_days is not None:
            settings.upload_days = max(1, request.upload_days)
        if request.backup_upload_enabled is not None:
            settings.backup_upload_enabled = request.backup_upload_enabled
        if request.backup_remote_path is not None:
            settings.backup_remote_path = (
                request.backup_remote_path.strip().strip("/") or "backups"
            )
        if request.backup_retention_count is not None:
            settings.backup_retention_count = max(
                1, min(60, request.backup_retention_count)
            )

        db.add(settings)
        db.commit()
        db.refresh(settings)

        if settings.enabled or settings.backup_upload_enabled:
            self._write_rclone_config(settings)

        return self.get_settings(db)


    def test_connection(
        self,
        db: Session
    ) -> dict:

        settings = self._get_or_create(db)

        if not self._write_rclone_config(settings):
            return {
                "success": False,
                "message": "Configura primero las credenciales."
            }

        result = subprocess.run(
            [RCLONE_BIN, "lsd", f"{REMOTE_NAME}:"],
            capture_output=True,
            text=True,
            timeout=25
        )

        if result.returncode == 0:
            return {
                "success": True,
                "message": "Conexión correcta."
            }

        return {
            "success": False,
            "message": (
                result.stderr.strip()
                or result.stdout.strip()
                or "No se pudo conectar."
            )
        }


    # ------------------------------------------------------------------
    # Upload
    # ------------------------------------------------------------------

    def upload_logs(
        self,
        db: Session,
        force: bool = False
    ) -> dict:

        settings = self._get_or_create(db)

        if not settings.enabled:
            return {
                "success": False,
                "message": "Respaldo en la nube desactivado."
            }

        archive = self._build_log_archive(
            db,
            settings.upload_days or 1
        )

        if archive is None:
            return {
                "success": False,
                "message": "No hay logs que subir."
            }

        target = self._remote_target(settings)

        result = subprocess.run(
            [
                RCLONE_BIN, "copy", str(archive), target,
                "--config", str(RCLONE_CONF),
                "--log-level", "ERROR"
            ],
            capture_output=True,
            text=True,
            timeout=120
        )

        settings.last_upload_at = utcnow()

        if result.returncode == 0:
            settings.last_upload_result = (
                f"OK {utcnow().strftime('%Y-%m-%d %H:%M')}"
            )
            db.add(settings)
            db.commit()
            self._cleanup_archive(archive)
            return {
                "success": True,
                "message": (
                    f"Logs subidos a la nube: {archive.name}"
                )
            }

        settings.last_upload_result = (
            f"ERROR {utcnow().strftime('%Y-%m-%d %H:%M')}"
        )
        db.add(settings)
        db.commit()

        detail = (
            result.stderr.strip()
            or result.stdout.strip()
            or "error desconocido"
        )

        self._notify_failure(detail, db)

        return {
            "success": False,
            "message": f"No se pudieron subir los logs: {detail}"
        }


    def _build_log_archive(
        self,
        db: Session,
        days: int
    ) -> Path | None:

        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

        end = utcnow().replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        start = end - timedelta(days=days)

        staging = UPLOAD_DIR / "staging"
        staging.mkdir(parents=True, exist_ok=True)

        for path in staging.iterdir():
            if path.is_file():
                path.unlink()

        written = 0

        audit = self._export_rows(
            db, AuditLog, start, end, "created_at"
        )
        if audit:
            (staging / "audit_logs.json").write_text(
                json.dumps(audit, ensure_ascii=False, indent=1),
                encoding="utf-8"
            )
            written += 1

        alerts = self._export_rows(
            db, Alert, start, end, "created_at"
        )
        if alerts:
            (staging / "alerts.json").write_text(
                json.dumps(alerts, ensure_ascii=False, indent=1),
                encoding="utf-8"
            )
            written += 1

        eve = Path("/var/log/suricata/eve.json")
        if eve.exists():
            try:
                (staging / "eve.json").write_bytes(eve.read_bytes())
                written += 1
            except Exception as error:
                logger.debug("cloud_storage_service._build_log_archive: %s", error)
        app_log = Path.cwd() / "logs" / "stepad.log"
        if app_log.exists():
            try:
                (staging / "stepad.log").write_bytes(app_log.read_bytes())
                written += 1
            except Exception as error:
                logger.debug("cloud_storage_service._build_log_archive: %s", error)
        if written == 0:
            return None

        name = f"logs-{end.strftime('%Y-%m-%d')}.tar.gz"
        archive = UPLOAD_DIR / name

        result = subprocess.run(
            [
                "tar", "czf", str(archive),
                "-C", str(staging), "."
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return None

        return self._encrypt(archive)


    def _export_rows(
        self,
        db: Session,
        model,
        start: datetime,
        end: datetime,
        time_column: str
    ) -> list[dict]:

        rows = (
            db.query(model)
            .filter(
                getattr(model, time_column) >= start,
                getattr(model, time_column) < end
            )
            .all()
        )

        return [
            {
                col.name: (
                    getattr(row, col.name).isoformat()
                    if isinstance(getattr(row, col.name), datetime)
                    else getattr(row, col.name)
                )
                for col in model.__table__.columns
            }
            for row in rows
        ]


    def backup_target(
        self,
        settings
    ) -> str:

        """Remote folder where configuration backups are stored."""

        path = (settings.backup_remote_path or "backups").strip("/")

        if settings.provider == "s3":

            bucket = (settings.bucket or "").strip("/")

            return f"{REMOTE_NAME}:{bucket}/{path}" if path else f"{REMOTE_NAME}:{bucket}"

        return f"{REMOTE_NAME}:{path}"

    def select_prunable(self, names: list[str], keep: int) -> list[str]:

        """Remote backup names to prune (the oldest ones)."""

        backups = sorted(
            (
                name for name in names
                if name.startswith("stepad-backup-")
                and name.endswith(".tar.gz.enc")
            ),
            reverse=True,
        )

        return backups[max(1, int(keep)):]

    def upload_backup(
        self,
        db: Session,
        path,
    ) -> dict:

        """Copy the encrypted backup to the cloud and apply retention."""

        settings = self._get_or_create(db)

        if not settings.backup_upload_enabled:

            return {
                "success": False,
                "message": "Subida de respaldos desactivada.",
            }

        if not self._write_rclone_config(settings):

            return {
                "success": False,
                "message": "Configuracion de nube incompleta.",
            }

        target = self.backup_target(settings)

        result = subprocess.run(
            [
                RCLONE_BIN, "copy", str(path), target,
                "--config", str(RCLONE_CONF),
                "--log-level", "ERROR",
            ],
            capture_output=True,
            text=True,
            timeout=600,
        )

        settings.backup_last_upload_at = utcnow()

        if result.returncode != 0:

            settings.backup_last_result = (
                f"ERROR {utcnow().strftime('%Y-%m-%d %H:%M')}"
            )

            db.add(settings)

            db.commit()

            detail = (
                result.stderr.strip()
                or result.stdout.strip()
                or "error desconocido"
            )

            logger.warning("Backup: cloud upload failed: %s", detail)

            return {"success": False, "message": detail}

        settings.backup_last_result = (
            f"OK {utcnow().strftime('%Y-%m-%d %H:%M')}"
        )

        db.add(settings)

        db.commit()

        self._prune_remote_backups(
            target,
            settings.backup_retention_count or 7,
        )

        return {
            "success": True,
            "message": f"Respaldo subido a {target}",
        }

    def list_remote_backups(self, db: Session) -> list[dict]:

        settings = self._get_or_create(db)

        if not self._write_rclone_config(settings):

            return []

        target = self.backup_target(settings)

        result = subprocess.run(
            [
                RCLONE_BIN, "lsjson", target, "--files-only",
                "--config", str(RCLONE_CONF),
                "--log-level", "ERROR",
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )

        if result.returncode != 0:

            return []

        try:

            items = json.loads(result.stdout or "[]")

        except Exception:

            return []

        rows = [
            {
                "name": item.get("Name"),
                "size": item.get("Size"),
                "modified": item.get("ModTime"),
            }
            for item in items
            if (item.get("Name") or "").endswith(".tar.gz.enc")
        ]

        return sorted(rows, key=lambda row: row["name"], reverse=True)

    def download_backup(self, db: Session, name: str) -> Path | None:

        if (
            not name
            or "/" in name
            or not name.startswith("stepad-backup-")
            or not name.endswith(".tar.gz.enc")
        ):

            return None

        settings = self._get_or_create(db)

        if not self._write_rclone_config(settings):

            return None

        target = self.backup_target(settings)

        destination = BACKUP_DIR / name

        BACKUP_DIR.mkdir(parents=True, exist_ok=True)

        result = subprocess.run(
            [
                RCLONE_BIN, "copyto", f"{target}/{name}", str(destination),
                "--config", str(RCLONE_CONF),
                "--log-level", "ERROR",
            ],
            capture_output=True,
            text=True,
            timeout=600,
        )

        if result.returncode != 0 or not destination.exists():

            logger.warning(
                "Nube: no se pudo descargar %s: %s",
                name,
                result.stderr.strip(),
            )

            return None

        return destination

    def recovery_kit(self, db: Session) -> str:

        """Texto con lo necesario para recuperar en un disco nuevo."""

        settings = self._get_or_create(db)

        key = self._current_backup_key()

        secret = self._decrypt_secret(settings.secret_key or "")

        access = self._decrypt_secret(settings.access_key or "")

        lines = [
            "STEPAD NSP - Kit de recuperacion",
            "",
            "CLAVE DE RESPALDO (STEPAD_BACKUP_KEY):",
            key or "(sin clave todavia)",
            "",
            "NUBE (si esta configurada):",
            f"  proveedor: {settings.provider}",
            f"  endpoint : {settings.endpoint or ''}",
            f"  bucket   : {settings.bucket or ''}",
            f"  carpeta  : {settings.backup_remote_path or 'backups'}",
            f"  access   : {access}",
            f"  secret   : {secret}",
            "",
            "COMO RECUPERAR EN UN DISCO NUEVO:",
            "1) Instalar STEPAD NSP de cero.",
            "2) Ajustes > Copias de seguridad > Almacenamiento en la nube:",
            "   cargar endpoint/bucket/access/secret y Guardar.",
            "3) En la misma seccion, pegar esta CLAVE y pulsar",
            "   'Restaurar desde la nube'.",
            "4) Elegir el respaldo mas reciente y confirmar (reinicia el NSP).",
            "5) Revisar Interfaces si el hardware nuevo cambio de NIC.",
            "",
            "Guardar este archivo fuera de la maquina (gestor de contrasenas).",
        ]

        return "\n".join(lines) + "\n"

    def _current_backup_key(self) -> str:

        try:

            if ENV_FILE.exists():

                for line in ENV_FILE.read_text(encoding="utf-8").splitlines():

                    if line.startswith("STEPAD_BACKUP_KEY="):

                        return line.split("=", 1)[1].strip().strip('"')

        except Exception:

            pass

        return ""

    def _prune_remote_backups(self, target: str, keep: int) -> int:

        listing = subprocess.run(
            [
                RCLONE_BIN, "lsf", target, "--files-only",
                "--config", str(RCLONE_CONF),
                "--log-level", "ERROR",
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )

        if listing.returncode != 0:

            return 0

        names = [
            name.strip()
            for name in listing.stdout.splitlines()
            if name.strip()
        ]

        removed = 0

        for name in self.select_prunable(names, keep):

            result = subprocess.run(
                [
                    RCLONE_BIN, "deletefile", f"{target}/{name}",
                    "--config", str(RCLONE_CONF),
                    "--log-level", "ERROR",
                ],
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.returncode == 0:

                removed += 1

        return removed

    def _remote_target(
        self,
        settings
    ) -> str:

        provider = settings.provider
        remote_path = (settings.remote_path or "").strip("/")

        if provider == "s3":
            bucket = (settings.bucket or "").strip("/")
            if remote_path:
                return f"{REMOTE_NAME}:{bucket}/{remote_path}"
            return f"{REMOTE_NAME}:{bucket}"

        if provider == "sftp":
            return f"{REMOTE_NAME}:{remote_path or '.'}"

        return f"{REMOTE_NAME}:{remote_path or ''}"


    def _obscure(self, plain: str) -> str:

        """rclone exige `pass` oculto en el config (no texto plano)."""

        try:

            result = subprocess.run(
                [RCLONE_BIN, "obscure", plain],
                capture_output=True,
                text=True,
                timeout=15,
            )

            if result.returncode == 0 and result.stdout.strip():

                return result.stdout.strip()

            logger.warning(
                "rclone obscure fallo: %s", result.stderr.strip()
            )

        except Exception as error:

            logger.warning("rclone obscure: %s", error)

        return plain

    def _write_rclone_config(
        self,
        settings
    ) -> bool:

        provider = settings.provider

        if provider == "s3":
            if not (settings.endpoint and settings.bucket):
                return False
            if not (settings.access_key and settings.secret_key):
                return False
            body = (
                f"[{REMOTE_NAME}]\n"
                "type = s3\n"
                "provider = Other\n"
                f"endpoint = {settings.endpoint}\n"
                f"access_key_id = {self._decrypt_secret(settings.access_key)}\n"
                f"secret_access_key = {self._decrypt_secret(settings.secret_key)}\n"
                "region = us-east-1\n"
                "acl = private\n"
            )
        elif provider == "sftp":
            if not (settings.host and settings.user):
                return False
            if not settings.password:
                return False
            body = (
                f"[{REMOTE_NAME}]\n"
                "type = sftp\n"
                f"host = {settings.host}\n"
                f"user = {settings.user}\n"
                f"pass = {self._obscure(self._decrypt_secret(settings.password))}\n"
                "shell_type = unix\n"
            )
        elif provider == "webdav":
            if not (settings.host and settings.user):
                return False
            if not settings.password:
                return False
            body = (
                f"[{REMOTE_NAME}]\n"
                "type = webdav\n"
                f"url = {settings.host}\n"
                f"user = {settings.user}\n"
                f"pass = {self._obscure(self._decrypt_secret(settings.password))}\n"
                "vendor = other\n"
            )
        else:
            return False

        RCLONE_DIR.mkdir(parents=True, exist_ok=True)

        RCLONE_CONF.write_text(body, encoding="utf-8")
        RCLONE_CONF.chmod(0o600)

        return True


    # ------------------------------------------------------------------
    # Encryption helpers (reuse STEPAD_BACKUP_KEY)
    # ------------------------------------------------------------------

    def _get_key(self) -> str:

        key = os.getenv("STEPAD_BACKUP_KEY", "")

        if key:
            return key

        env_file = STEPAD_DIR / "stepad.env"
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                if line.startswith("STEPAD_BACKUP_KEY="):
                    return line.split("=", 1)[1].strip()

        return ""


    def _encrypt_secret(self, value: str) -> str:

        key = self._get_key()

        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-pbkdf2",
                "-salt", "-A", "-base64",
                "-pass", f"pass:{key}"
            ],
            input=value.encode(),
            capture_output=True
        )

        if result.returncode != 0:
            raise RuntimeError("No se pudo cifrar la credencial")

        return result.stdout.decode().strip()


    def _decrypt_secret(self, value: str) -> str:

        key = self._get_key()

        result = subprocess.run(
            [
                "openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2",
                "-A", "-base64",
                "-pass", f"pass:{key}"
            ],
            input=value.encode(),
            capture_output=True
        )

        if result.returncode != 0:
            return ""

        return result.stdout.decode()


    def _encrypt(self, source: Path) -> Path:

        key = self._get_key()

        encrypted = source.with_suffix(source.suffix + ".enc")

        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-pbkdf2",
                "-salt", "-pass", f"pass:{key}",
                "-in", str(source),
                "-out", str(encrypted)
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return source

        source.unlink(missing_ok=True)

        return encrypted


    def _cleanup_archive(self, archive: Path):

        try:
            archive.unlink(missing_ok=True)
        except Exception as error:
            logger.debug("cloud_storage_service._cleanup_archive: %s", error)
    def _notify_failure(self, detail: str, db: Session):

        try:

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            CriticalAlertEmailService().send(
                db,
                "Fallo del respaldo de logs en la nube",
                detail,
                html_body=(
                    "<p>El respaldo de logs a la nube falló:</p>"
                    f"<pre>{detail}</pre>"
                ),
            )

        except Exception as error:

            logger.error(
                f"No se pudo notificar el fallo del respaldo en la nube: "
                f"{error}"
            )


    # ------------------------------------------------------------------
    # Scheduler
    # ------------------------------------------------------------------

    def is_due(
        self,
        db: Session
    ) -> bool:

        settings = self._get_or_create(db)

        if not settings.enabled:
            return False

        now = utcnow()

        if settings.last_upload_at is not None:
            last = settings.last_upload_at.replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            today = now.replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            if last >= today:
                return False

        return (
            now.hour == settings.upload_hour
            and now.minute == settings.upload_minute
        )


    def _scheduler_loop(self):

        logger.info("Cloud storage scheduler started.")

        while not self._stop:

            db = SessionLocal()

            try:

                if self.is_due(db):

                    result = self.upload_logs(db)

                    logger.info(
                        f"Subida de logs en la nube: {result}"
                    )

            except Exception as error:

                logger.exception(
                    f"Cloud storage scheduler error: {error}"
                )

            finally:

                db.close()

            for _ in range(60):
                if self._stop:
                    break
                time.sleep(1)


    def start_scheduler(self):

        if self._scheduler_thread is not None:
            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="cloud-storage-scheduler"
        )

        self._scheduler_thread.start()


    def stop(self):

        self._stop = True


    def _get_or_create(
        self,
        db: Session
    ) -> CloudStorageSettings:

        settings = (
            db.query(CloudStorageSettings)
            .order_by(CloudStorageSettings.id)
            .first()
        )

        if settings is None:

            settings = CloudStorageSettings()
            db.add(settings)
            db.commit()
            db.refresh(settings)

        return settings