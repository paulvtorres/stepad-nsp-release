"""Unified diagnosis and safe remediation for the NSP.

The service only exposes deterministic checks and explicit actions. It
does not hide failures behind restarts; every action is verified again.
"""

from __future__ import annotations

import subprocess
import time

from datetime import timedelta

from sqlalchemy import func, text

import psutil

from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger


class SelfHealingService:

    SERVICES = (
        ("stepad-nsp", "NSP / API", "critical"),
        ("postgresql", "PostgreSQL", "critical"),
        ("pdns-recursor", "DNS recursivo", "critical"),
        ("suricata", "IPS Suricata", "important"),
        ("tailscaled", "Tailscale", "optional"),
    )

    def _service_status(self, name: str) -> str:
        try:
            result = subprocess.run(
                ["systemctl", "is-active", name],
                capture_output=True,
                text=True,
                timeout=4,
            )
            return (result.stdout or result.stderr or "unknown").strip()
        except Exception as error:
            logger.debug("self_healing._service_status %s: %s", name, error)
            return "unknown"

    def diagnose(self, db) -> dict:

        checks = []

        def add(key, label, status, detail, action="", auto_fix=False, link=""):
            checks.append({
                "key": key,
                "label": label,
                "status": status,
                "detail": detail,
                "action": action,
                "auto_fix": bool(auto_fix),
                "link": link,
            })

        # Content categories: ghost rules are the dangerous case.
        try:
            from backend.content.services.content_category_service import (
                ContentCategoryService,
            )
            report = ContentCategoryService().consistency_report(db)
            if report["ghost_rules"] or report["orphan_category_keys"]:
                add(
                    "content_consistency",
                    "Consistencia de categorías",
                    "critical",
                    (
                        f"{report['ghost_rules']} reglas fantasma; "
                        f"{len(report['orphan_category_keys'])} categorías huérfanas"
                    ),
                    "content_orphan_rules",
                    True,
                    "/security",
                )
            elif report["incomplete_rules"]:
                add(
                    "content_consistency",
                    "Consistencia de categorías",
                    "warning",
                    f"{report['incomplete_rules']} reglas faltantes en categorías activas",
                    "",
                    False,
                    "/security",
                )
            else:
                add(
                    "content_consistency",
                    "Consistencia de categorías",
                    "ok",
                    "Sin reglas heredadas ni faltantes",
                    "",
                    False,
                    "/security",
                )
        except Exception as error:
            add("content_consistency", "Consistencia de categorías", "unknown", str(error)[:250])

        # DB is the foundation; a failed SELECT is critical.
        try:
            db.execute(text("SELECT 1"))
            add("database", "PostgreSQL", "ok", "Consultas respondiendo")
        except Exception as error:
            add("database", "PostgreSQL", "critical", str(error)[:250])

        # Core services.
        for name, label, criticality in self.SERVICES:
            state = self._service_status(name)
            status = "ok" if state == "active" else (
                "critical" if criticality == "critical" else "warning"
            )
            add(
                f"service_{name}",
                label,
                status,
                f"systemd: {state}",
                "",
                False,
                "/dashboard",
            )

        # DHCP health: cheap check; the synthetic lease probe is in
        # /probe because it performs a real DISCOVER/REQUEST cycle.
        try:
            from backend.dhcp.services.dhcp_health_service import (
                DhcpHealthService,
            )
            dhcp = DhcpHealthService().inspect()
            if not dhcp.get("running"):
                add(
                    "dhcp_health",
                    "DHCP",
                    "critical",
                    "dnsmasq no está en ejecución",
                    "dhcp_reconcile",
                    True,
                    "/network",
                )
            elif dhcp.get("stuck"):
                add(
                    "dhcp_health",
                    "DHCP",
                    "critical",
                    f"dnsmasq sin procesar (cola UDP 67={dhcp.get('recv_q')} bytes)",
                    "dhcp_reconcile",
                    True,
                    "/network",
                )
            elif dhcp.get("pool_exhausted"):
                add(
                    "dhcp_health",
                    "DHCP",
                    "critical",
                    "Pool DHCP agotado; los equipos nuevos no reciben IP",
                    "dhcp_pool_reconcile",
                    True,
                    "/network",
                )
            elif dhcp.get("attention"):
                add(
                    "dhcp_health",
                    "DHCP",
                    "warning",
                    (
                        f"Pool bajo={dhcp.get('pool_low')}; "
                        f"conflictos={dhcp.get('conflicts_attention')}"
                    ),
                    "dhcp_reconcile" if dhcp.get("pool_exhausted") else "",
                    False,
                    "/network",
                )
            else:
                add(
                    "dhcp_health",
                    "DHCP",
                    "ok",
                    f"dnsmasq activo; cola UDP 67={dhcp.get('recv_q')} bytes",
                )
        except Exception as error:
            add("dhcp_health", "DHCP", "unknown", str(error)[:250])

        # WAN / internet.
        # WAN / internet.
        try:
            from backend.monitoring.services.wan_monitor_service import (
                WanMonitorService,
            )
            wan = WanMonitorService().get_status(db)
            interfaces = list((wan.get("interfaces") or {}).values())
            if not interfaces:
                add("wan", "Internet WAN", "warning", "Sin interfaz WAN configurada", "", False, "/monitoring")
            else:
                failed = [
                    item for item in interfaces
                    if not item.get("link_up") or not item.get("ping_ok")
                ]
                add(
                    "wan",
                    "Internet WAN",
                    "critical" if failed else "ok",
                    (
                        f"{len(failed)} interfaz(es) sin respuesta"
                        if failed
                        else f"{len(interfaces)} interfaz(es) respondiendo"
                    ),
                    "",
                    False,
                    "/monitoring",
                )
        except Exception as error:
            add("wan", "Internet WAN", "unknown", str(error)[:250])

        # Client navigation activity.
        try:
            now = utcnow()
            recent = (
                db.query(func.count(DnsQueryLog.id))
                .filter(DnsQueryLog.queried_at >= now - timedelta(minutes=5))
                .scalar()
                or 0
            )
            baseline = (
                db.query(func.count(DnsQueryLog.id))
                .filter(DnsQueryLog.queried_at >= now - timedelta(minutes=30))
                .scalar()
                or 0
            )
            online = (
                db.query(func.count(NetworkDevice.id))
                .filter(NetworkDevice.presence_status == "ONLINE")
                .scalar()
                or 0
            )
            if recent == 0 and baseline >= 100 and online >= 5:
                add(
                    "client_navigation",
                    "Navegación de clientes",
                    "warning",
                    f"Sin consultas DNS en 5 min; {baseline} en 30 min; {online} equipos online",
                    "",
                    False,
                    "/performance",
                )
            else:
                add(
                    "client_navigation",
                    "Navegación de clientes",
                    "ok",
                    f"{recent} consultas DNS en 5 min; {online} equipos online",
                    "",
                    False,
                    "/performance",
                )
        except Exception as error:
            add("client_navigation", "Navegación de clientes", "unknown", str(error)[:250])

        # Restore verification proves that the newest backup is restorable.
        try:
            from backend.backups.services.restore_verification_service import (
                RestoreVerificationService,
            )
            verify = RestoreVerificationService().status()
            success = bool(verify.get("success"))
            last_run = verify.get("last_run_at") or "sin fecha"
            add(
                "restore_verification",
                "Restauración de respaldos",
                "ok" if success else "warning",
                f"{verify.get('message', 'sin verificaciones')} · {last_run}",
                "",
                False,
                "/backups",
            )
        except Exception as error:
            add(
                "restore_verification",
                "Restauración de respaldos",
                "unknown",
                str(error)[:250],
                "",
                False,
                "/backups",
            )

        # Disk.
        try:
            disk = psutil.disk_usage("/")
            add(
                "disk",
                "Espacio en disco",
                "warning" if disk.percent >= 90 else "ok",
                f"{disk.percent:.1f}% usado; {disk.free / 1024**3:.1f} GB libres",
                "",
                False,
                "/hardware",
            )
        except Exception as error:
            add("disk", "Espacio en disco", "unknown", str(error)[:250])

        critical = sum(1 for check in checks if check["status"] == "critical")
        warning = sum(1 for check in checks if check["status"] == "warning")
        unknown = sum(1 for check in checks if check["status"] == "unknown")

        return {
            "status": "critical" if critical else ("warning" if warning else ("unknown" if unknown else "ok")),
            "generated_at": utcnow().isoformat(),
            "summary": {"critical": critical, "warning": warning, "unknown": unknown},
            "checks": checks,
        }

    def probe_navigation(self) -> dict:
        """Synthetic DNS + TCP + HTTPS probe from the NSP itself."""

        checks = []

        def timed(command, timeout):
            started = time.monotonic()
            try:
                result = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                )
                return result, round((time.monotonic() - started) * 1000, 1)
            except Exception:
                return None, None

        try:
            from backend.dhcp.services.dhcp_probe_service import (
                DhcpProbeService,
            )
            dhcp = DhcpProbeService().probe(timeout=4.0)
            checks.extend(dhcp.get("checks") or [])
        except Exception as error:
            checks.append({
                "key": "dhcp",
                "label": "DHCP sintético",
                "ok": False,
                "latency_ms": None,
                "detail": str(error)[:250],
            })

        dns, dns_ms = timed(
            ["dig", "+time=3", "+tries=1", "+short", "@127.0.0.1", "google.com"],
            6,
        )
        dns_ok = bool(dns and dns.returncode == 0 and dns.stdout.strip())
        checks.append({
            "key": "dns",
            "label": "DNS local",
            "ok": dns_ok,
            "latency_ms": dns_ms,
            "detail": (dns.stdout.strip().splitlines()[0] if dns_ok else "sin respuesta"),
        })

        http, http_ms = timed(
            ["curl", "-skI", "--max-time", "8", "https://www.google.com"],
            10,
        )
        http_ok = bool(http and http.returncode == 0 and "200" in (http.stdout or ""))
        checks.append({
            "key": "https",
            "label": "HTTPS externo",
            "ok": http_ok,
            "latency_ms": http_ms,
            "detail": (http.stdout.splitlines()[0] if http_ok else "sin respuesta"),
        })

        return {
            "ok": all(check["ok"] for check in checks),
            "checks": checks,
        }

    def incident_history(self, db, limit: int = 30) -> dict:
        from backend.alerts.models.alert import Alert

        types = (
            "CONTENT_ORPHAN_RULES",
            "CLIENT_NAVIGATION_STALL",
            "NAVIGATION_HEALTH",
            "RESOURCE_CPU",
            "RESOURCE_RAM",
            "RESOURCE_DISK",
            "NAVIGATION_HEALTH",
            "HEARTBEAT_MISSING",
            "DELIVERY_CHANNEL_FAILING",
        )

        rows = (
            db.query(Alert)
            .filter(Alert.alert_type.in_(types))
            .order_by(Alert.created_at.desc())
            .limit(max(1, min(limit, 100)))
            .all()
        )

        return {
            "items": [
                {
                    "id": row.id,
                    "type": row.alert_type,
                    "severity": row.severity,
                    "title": row.title,
                    "message": row.message,
                    "created_at": row.created_at.isoformat() if row.created_at else None,
                    "resolved_at": row.resolved_at.isoformat() if row.resolved_at else None,
                }
                for row in rows
            ]
        }

    def repair(self, db, action: str) -> dict:
        """Execute one whitelisted action and verify the result.

        There is deliberately no generic "restart service" action: every
        action is narrow, idempotent where possible and checked again.
        """

        if action == "content_orphan_rules":
            from backend.content.services.content_category_service import (
                ContentCategoryService,
            )
            result = ContentCategoryService().reconcile_disabled_categories(db)
            return {
                "success": True,
                "action": action,
                "result": result,
                "verified": ContentCategoryService().consistency_report(db),
            }

        if action in ("dhcp_reconcile", "dhcp_pool_reconcile"):
            from backend.dhcp.reconciler import get_dhcp_reconciler
            from backend.dhcp.services.dhcp_health_service import (
                DhcpHealthService,
            )
            result = get_dhcp_reconciler().apply(force=True)
            health = DhcpHealthService().inspect()
            verified = {
                "healthy": bool(health.get("healthy")),
                "running": bool(health.get("running")),
                "stuck": bool(health.get("stuck")),
                "pool_low": bool(health.get("pool_low")),
                "pool_exhausted": bool(health.get("pool_exhausted")),
            }
            return {
                "success": verified["healthy"],
                "action": action,
                "result": result,
                "verified": verified,
            }

        if action == "dns_rebuild":
            from backend.core.config.settings import Settings
            from backend.dns.factory import get_dns_provider
            from backend.dns.services.domain_service import DomainService
            from backend.monitoring.services.navigation_health_service import (
                probe_dns_a,
            )
            service = DomainService(get_dns_provider())
            global_result = service.synchronize(db)
            zone_result = service.synchronize_all_zones(db)
            resolver = getattr(Settings, "DNS_SERVER", "") or "127.0.0.1"
            dns_ok = probe_dns_a(resolver, "example.com", timeout=2.0)
            return {
                "success": bool(dns_ok),
                "action": action,
                "result": {
                    "global": global_result,
                    "zones": zone_result,
                },
                "verified": {
                    "dns_ok": bool(dns_ok),
                    "resolver": resolver,
                },
            }

        raise ValueError(f"Acción no permitida: {action}")
