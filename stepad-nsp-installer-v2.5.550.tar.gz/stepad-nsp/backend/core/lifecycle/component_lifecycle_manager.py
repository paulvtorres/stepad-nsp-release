import time

from backend.shared.logging.logger import logger
from backend.shared.runtime import runtime

from backend.core.lifecycle.component_status import ComponentStatus
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.shared.datetime_utils import utcnow


class ComponentLifecycleManager:
    """
    Controls lifecycle of all NSP components.
    """

    def __init__(self):
        self.components = []
        self._failures = []

    def register(self, component):
        self.components.append(component)

        runtime.set(
            component.name,
            ComponentStatus.PENDING.value
        )

        logger.info(f"Registered component: {component.name}")

    def start_all(self):
        logger.info("Starting component lifecycle...")

        for component in self.components:

            # Los componentes críticos (core/API) no se reintentan aquí:
            # si fallan, el proceso debe terminar para que systemd lo
            # reinicie. Los servicios importantes sí toleran fallos
            # transitorios de arranque.
            attempts = (
                1
                if component.criticality == ComponentCriticality.CRITICAL
                else 3
            )

            last_error = None

            for attempt in range(1, attempts + 1):

                try:
                    logger.info(
                        "Starting %s (intento %s/%s)",
                        component.name,
                        attempt,
                        attempts,
                    )

                    runtime.set(
                        component.name,
                        ComponentStatus.STARTING.value
                    )

                    component.start()

                    runtime.set(
                        component.name,
                        ComponentStatus.RUNNING.value
                    )

                    logger.info(f"{component.name} is RUNNING")

                    last_error = None

                    break

                except Exception as e:

                    last_error = e

                    logger.exception(
                        "%s fallo al iniciar (intento %s/%s): %s",
                        component.name,
                        attempt,
                        attempts,
                        e,
                    )

                    if attempt < attempts:

                        delay = min(10, attempt * 2)

                        time.sleep(delay)

            if last_error is None:

                continue

            e = last_error

            runtime.set(
                component.name,
                ComponentStatus.FAILED.value,
                error=f"{type(e).__name__}: {e}"
            )

            self._failures.append({
                "component": component.name,
                "error": f"{type(e).__name__}: {e}",
            })

            logger.critical(
                "Componente %s fallo al iniciar definitivamente: %s.",
                component.name, e,
            )

            self._emit_failure_alert(component.name, e)

            if component.criticality == ComponentCriticality.CRITICAL:

                raise RuntimeError(
                    f"Componente crítico {component.name} no pudo iniciar: {e}"
                )

        if self._failures:
            failed_names = [f["component"] for f in self._failures]
            logger.critical(
                "Arranque incompleto: %d componente(s) fallaron: %s. "
                "Revise la tabla de alertas para detalles.",
                len(self._failures),
                ", ".join(failed_names),
            )

    def stop_all(self):
        logger.info("Stopping all components...")

        for component in reversed(self.components):
            try:

                component.stop()

                runtime.set(
                    component.name,
                    ComponentStatus.STOPPED.value
                )

                logger.info(f"{component.name} stopped")

            except Exception as e:

                runtime.set(
                    component.name,
                    ComponentStatus.FAILED.value,
                    error=f"{type(e).__name__}: {e}"
                )

                logger.exception(
                    f"{component.name} stop failed: {e}"
                )

    def _emit_failure_alert(self, component_name, error):
        """Crea una alerta CRITICA en la DB cuando un componente falla."""
        try:
            from datetime import datetime
            from backend.core.database.connection import engine
            from sqlalchemy import text

            with engine.connect() as conn:
                conn.execute(
                    text(
                        "INSERT INTO alerts (alert_type, severity, title, "
                        "message, read, created_at) VALUES "
                        "(:at, :sev, :title, :msg, false, :ts)"
                    ),
                    {
                        "at": "COMPONENT_FAILURE",
                        "sev": "critical",
                        "title": f"Componente {component_name} fallo",
                        "msg": f"{type(error).__name__}: {error}"[:500],
                        "ts": utcnow(),
                    },
                )
                conn.commit()
        except Exception as alert_exc:
            logger.error(
                "No pude crear alerta de fallo de componente: %s",
                alert_exc,
            )
