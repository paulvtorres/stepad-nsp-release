import { act, renderHook } from "@testing-library/react";
import { beforeEach, describe, expect, it } from "vitest";
import { usePersistentState } from "../usePersistentState";

describe("usePersistentState", () => {
    beforeEach(() => {
        window.localStorage.clear();
    });

    it("uses the initial value when storage is empty", () => {
        const { result } = renderHook(() => usePersistentState("k", "a"));
        expect(result.current[0]).toBe("a");
    });

    it("persists and restores the value", () => {
        const first = renderHook(() => usePersistentState("k", "a"));
        act(() => first.result.current[1]("b"));
        expect(window.localStorage.getItem("k")).toBe('"b"');
        first.unmount();

        const second = renderHook(() => usePersistentState("k", "a"));
        expect(second.result.current[0]).toBe("b");
    });
});
