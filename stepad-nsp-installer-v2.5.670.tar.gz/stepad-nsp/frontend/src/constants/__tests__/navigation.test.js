import { describe, expect, it } from "vitest";

import {
    NAV_GROUPS,
    favoriteNavItems,
    searchNavGroups,
} from "../navigation";

describe("navegación · Favoritos y búsqueda", () => {
    it("devuelve solo favoritos visibles y en orden de menú", () => {
        const items = favoriteNavItems(NAV_GROUPS, ["/alerts", "/"]);

        expect(items.map((item) => item.to)).toEqual(["/", "/alerts"]);
        expect(items[0].group).toBe("Inicio");
    });

    it("ignora rutas que no existen o no están visibles", () => {
        expect(favoriteNavItems(NAV_GROUPS, ["/noexiste"])).toEqual([]);
    });

    it("filtra por etiqueta y por ruta", () => {
        const byLabel = searchNavGroups(NAV_GROUPS, "respaldo");
        expect(byLabel.length).toBeGreaterThan(0);
        expect(
            byLabel.flatMap((group) => group.items).every((item) =>
                item.label.toLowerCase().includes("respaldo"),
            ),
        ).toBe(true);

        const byPath = searchNavGroups(NAV_GROUPS, "/users");
        expect(byPath.flatMap((group) => group.items)[0].to).toBe("/users");
    });

    it("sin texto devuelve el menú completo", () => {
        expect(searchNavGroups(NAV_GROUPS, "   ")).toBe(NAV_GROUPS);
    });
});


describe("navegación · DHCP", () => {
    it("DHCP está como opción principal y no dentro de Red", () => {
        const dhcp = NAV_GROUPS.find((group) => group.id === "dhcp");
        expect(dhcp.items.map((item) => item.to)).toEqual(["/network/dhcp"]);

        const network = NAV_GROUPS.find((group) => group.id === "network");
        expect(network.items.some((item) => item.to === "/network/dhcp")).toBe(false);
    });
});
