import { describe, expect, it } from "vitest";
import {
    formatClock,
    formatDate,
    formatDateTime,
    parseUtcDate
} from "../datetime";

describe("parseUtcDate", () => {
    it("accepts ISO strings with Z", () => {
        const date = parseUtcDate("2026-01-01T12:00:00Z");
        expect(date.toISOString()).toBe("2026-01-01T12:00:00.000Z");
    });

    it("treats naive timestamps as UTC and normalizes spaces", () => {
        const date = parseUtcDate("2026-01-01 12:00:00");
        expect(date.toISOString()).toBe("2026-01-01T12:00:00.000Z");
    });

    it("truncates microseconds", () => {
        const date = parseUtcDate("2026-01-01T12:00:00.123456Z");
        expect(date.toISOString()).toBe("2026-01-01T12:00:00.123Z");
    });

    it("accepts seconds and milliseconds", () => {
        expect(parseUtcDate(1767268800).toISOString()).toBe(
            "2026-01-01T12:00:00.000Z"
        );
        expect(parseUtcDate(1767268800000).toISOString()).toBe(
            "2026-01-01T12:00:00.000Z"
        );
    });

    it("returns null for empty or invalid values", () => {
        expect(parseUtcDate(null)).toBeNull();
        expect(parseUtcDate("")).toBeNull();
        expect(parseUtcDate("nope")).toBeNull();
        expect(parseUtcDate(new Date("nope"))).toBeNull();
    });
});

describe("Ecuador display format", () => {
    it("shifts UTC to UTC-5 for dates and times", () => {
        expect(formatDateTime("2026-01-01T12:00:00Z")).toBe(
            "1/1/2026, 07:00:00"
        );
        expect(formatDate("2026-01-01T02:00:00Z")).toBe("31/12/2025");
    });

    it("uses an empty placeholder", () => {
        expect(formatDateTime(null)).toBe("");
        expect(formatDate(undefined, "sin fecha")).toBe("sin fecha");
    });

    it("formats the clock in Ecuador time", () => {
        expect(formatClock(new Date("2026-01-01T12:34:56Z"))).toBe(
            "jue, 01 ene, 07:34:56"
        );
    });
});
