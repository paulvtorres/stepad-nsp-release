import { describe, expect, it } from "vitest";
import { formatDuration } from "../duration";

describe("formatDuration", () => {
    it("handles empty values", () => {
        expect(formatDuration(null)).toBe("—");
    });

    it("formats seconds, minutes, hours and days", () => {
        expect(formatDuration(42)).toBe("42s");
        expect(formatDuration(90)).toBe("1m");
        expect(formatDuration(3700)).toBe("1h 1m");
        expect(formatDuration(90000)).toBe("1d 1h");
    });
});
