import { useCallback, useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getAttackSummary,
    saveAttackSettings,
    getAttackEvents,
    getAttackIpDetail,
    blockAttackIp,
    unblockAttackIp,
    getFirewallHardening,
    setFirewallHardening,
} from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./external-attacks.css";


const WINDOWS = [
    { label: "24 horas", hours: 24 },
    { label: "7 días", hours: 168 },
    { label: "30 días", hours: 720 },
];

const KINDS = [
    { id: "all", label: "Todos" },
    { id: "malware", label: "Malware" },
    { id: "exploit", label: "Explotación" },
    { id: "dos", label: "DoS" },
    { id: "recon", label: "Escaneo" },
    { id: "suspicious", label: "Sospechoso" },
    { id: "policy", label: "Política" },
    { id: "other", label: "Otro" },
];


const SEVERITY_LABELS = {
    critical: "Crítica",
    warning: "Advertencia",
    info: "Información",
};


function SourceBadge({ source }) {

    return (
        <span className={`attack-badge ${source === "ips" ? "ips" : "wan"}`}>
            {source === "ips" ? "IPS" : "Firewall"}
        </span>
    );

}


function ToggleRow({ label, hint, checked, disabled, busy, onChange }) {

    return (
        <div className="attack-toggle-row">
            <div>
                <strong>{label}</strong>
                {hint && <p>{hint}</p>}
            </div>
            <button
                type="button"
                className={`attack-toggle ${checked ? "on" : "off"}`}
                disabled={disabled || busy}
                onClick={onChange}
            >
                {busy ? "…" : (checked ? "Activado" : "Desactivado")}
            </button>
        </div>
    );

}


export default function ExternalAttacks() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [summary, setSummary] = useState(null);

    const [hardening, setHardening] = useState(null);

    const [windowHours, setWindowHours] = useState(24);

    const [items, setItems] = useState([]);

    const [kindFilter, setKindFilter] = useState("all");

    const [dirTab, setDirTab] = useState("inbound");

    const [loadingEvents, setLoadingEvents] = useState(true);

    const [detail, setDetail] = useState(null);

    const [detailLoading, setDetailLoading] = useState(false);

    const [busyKey, setBusyKey] = useState(null);

    const [notice, setNotice] = useState("");

    const [view, setView] = useState("defense");


    const loadSummary = useCallback(async () => {

        try {

            const data = await getAttackSummary();

            setSummary(data);

        } catch {
            // silencioso: la pagina se sigue mostrando con lo que haya
        }

    }, []);


    const loadHardening = useCallback(async () => {

        try {

            const data = await getFirewallHardening();

            setHardening(data);

        } catch {
            // silencioso
        }

    }, []);


    const loadEvents = useCallback(async () => {

        try {

            const data = await getAttackEvents(windowHours, 200);

            setItems(data.items || []);

        } catch {
            // silencioso
        } finally {

            setLoadingEvents(false);

        }

    }, [windowHours]);


    useEffect(() => {

        loadSummary();

        loadHardening();

    }, [loadSummary, loadHardening]);


    useEffect(() => {

        loadEvents();

        const timer = setInterval(loadEvents, 30000);

        return () => clearInterval(timer);

    }, [loadEvents]);


    const flash = (text) => {

        setNotice(text);

        setTimeout(() => setNotice(""), 4000);

    };


    async function toggleAutoBlock() {

        setBusyKey("auto-block");

        try {

            const next = !(summary?.auto_block_inbound ?? false);

            await saveAttackSettings({ auto_block_inbound: next });

            setSummary((prev) => ({ ...prev, auto_block_inbound: next }));

            flash(
                next
                    ? "El bloqueo automático de IPs atacantes quedó activado."
                    : "El bloqueo automático quedó desactivado (solo registro)."
            );

        } catch {

            flash("No se pudo guardar la opción.");

        } finally {

            setBusyKey(null);

        }

    }


    async function toggleHardening() {

        setBusyKey("hardening");

        try {

            const next = !(hardening?.hardening_enabled ?? false);

            await setFirewallHardening(next);

            await loadHardening();

            await loadSummary();

            flash(
                next
                    ? "Deny-all aplicado: tráfico externo sin pedido previo se descarta."
                    : "Deny-all desactivado (política por defecto)."
            );

        } catch {

            flash("No se pudo aplicar el hardening.");

        } finally {

            setBusyKey(null);

        }

    }


    async function toggleBlockP2P() {

        setBusyKey("block-p2p");

        try {

            const next = !(summary?.block_p2p ?? true);

            await saveAttackSettings({ block_p2p: next });

            setSummary((prev) => ({ ...prev, block_p2p: next }));

            flash(
                next
                    ? "El bloqueo de flujos P2P/BitTorrent quedó activado."
                    : "El bloqueo de P2P quedó desactivado (solo se registra)."
            );

        } catch {

            flash("No se pudo guardar la opción.");

        } finally {

            setBusyKey(null);

        }

    }


    async function openDetail(ip) {

        setDetail({ ip, state: "loading" });

        setDetailLoading(true);

        try {

            const data = await getAttackIpDetail(ip);

            setDetail(data);

        } catch {

            setDetail({ ip, state: "error" });

        } finally {

            setDetailLoading(false);

        }

    }


    async function doBlock(ip) {

        const reason = window.prompt(
            `Motivo del bloqueo manual de ${ip} (opcional):`,
            ""
        );

        if (reason === null) {

            return;

        }

        setBusyKey(`block-${ip}`);

        try {

            await blockAttackIp(ip, reason.trim());

            await refreshDetail(ip);

            flash(`IP ${ip} bloqueada.`);

        } catch {

            flash("No se pudo bloquear la IP.");

        } finally {

            setBusyKey(null);

        }

    }


    async function doUnblock(ip) {

        setBusyKey(`unblock-${ip}`);

        try {

            await unblockAttackIp(ip);

            await refreshDetail(ip);

            flash(`IP ${ip} desbloqueada.`);

        } catch {

            flash("No se pudo desbloquear la IP.");

        } finally {

            setBusyKey(null);

        }

    }


    async function refreshDetail(ip) {

        await loadSummary();

        await loadEvents();

        try {

            const data = await getAttackIpDetail(ip);

            setDetail(data);

        } catch {
            // silencioso
        }

    }


    const blockedIps = summary?.blocked?.ips ?? [];

    const geo = summary?.geo ?? {};

    const hardeningOn = hardening?.hardening_enabled === true;

    const hardeningApplied = hardening?.applied === true;

    const inboundItems = items.filter(
        (r) => (r.direction || "inbound") === "inbound"
    );

    const outboundItems = items.filter((r) => r.direction === "outbound");

    const tabItems = dirTab === "outbound" ? outboundItems : inboundItems;

    const shownItems = kindFilter === "all"
        ? tabItems
        : tabItems.filter((r) => (r.kind || "other") === kindFilter);


    return (
        <div className="attack-container">

            <div className="attack-page-head">
                <div>
                    <h1>Ataques externos</h1>
                    <p>
                        Intentos de acceso{" "}
                        <strong>desde Internet hacia el NSP</strong>: quién
                        intenta entrar, a qué puerto/servicio, con qué firma, de
                        qué país/organización proviene y si fue bloqueado. Las
                        alertas de tráfico <strong>saliente</strong> (respuestas
                        a conexiones de tus propios equipos) se ven aparte, en
                        la pestaña “Otros flujos”, para no confundirlas con
                        ataques reales. La decisión de bloquear cada IP la tomás
                        vos.
                    </p>
                </div>
            </div>

            {notice && <div className="attack-notice">{notice}</div>}

            <div className="attack-direction-tabs attack-view-tabs" role="tablist">

                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "defense"}
                    className={`attack-dirtab ${view === "defense" ? "active" : ""}`}
                    onClick={() => setView("defense")}
                >
                    Estado de la defensa
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "blocked"}
                    className={`attack-dirtab ${view === "blocked" ? "active" : ""}`}
                    onClick={() => setView("blocked")}
                >
                    IPs bloqueadas
                    <span className="attack-dirtab-count">{blockedIps.length}</span>
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "events"}
                    className={`attack-dirtab ${view === "events" ? "active" : ""}`}
                    onClick={() => setView("events")}
                >
                    Registro de ataques
                    <span className="attack-dirtab-count">{inboundItems.length + outboundItems.length}</span>
                </button>

            </div>

            {/* ---------------------------------------------------------- */}
            {/* Defensa                                                     */}
            {/* ---------------------------------------------------------- */}

            {view === "defense" && (
            <section className="attack-section">
                <h2>Estado de la defensa</h2>

                <div className="attack-stats">

                    <div className={`attack-stat ${hardeningOn ? "ok" : "off"}`}>
                        <span className="attack-stat-label">
                            Firewall deny-all
                        </span>
                        <strong>{hardeningOn ? "Activo" : "Desactivado"}</strong>
                        <p>
                            {hardeningApplied
                                ? "Aplicado en el borde: el tráfico externo sin conexión previa se descarta."
                                : hardeningOn
                                    ? "Configurado pero aún pendiente de aplicar."
                                    : "Sin deny-all, los servicios expuestos se ven desde Internet."}
                        </p>
                    </div>

                    <div className={`attack-stat ${summary?.suricata_running ? "ok" : "off"}`}>
                        <span className="attack-stat-label">
                            IPS (Suricata)
                        </span>
                        <strong>
                            {summary?.suricata_running
                                ? "Inspeccionando"
                                : "Detenido"}
                        </strong>
                        <p>
                            {summary?.rules_loaded
                                ? `${summary.rules_loaded} firmas de ataque cargadas.`
                                : "Sin firmas cargadas."}
                        </p>
                    </div>

                    <div className={`attack-stat ${geo.rows ? "ok" : "warn"}`}>
                        <span className="attack-stat-label">
                            Origen geográfico
                        </span>
                        <strong>
                            {geo.rows ? "Disponible" : "Cargando…"}
                        </strong>
                        <p>
                            {geo.rows
                                ? `${new Intl.NumberFormat("es").format(geo.rows)} rangos (país / ASN / organización).`
                                : "Descargando base de geolocalización (solo la primera vez)."}
                        </p>
                    </div>

                    <div className="attack-stat">
                        <span className="attack-stat-label">
                            IPs atacantes bloqueadas
                        </span>
                        <strong>{summary?.blocked?.count ?? 0}</strong>
                        <p>
                            {summary?.inbound_events_24h ?? 0} ataques IPS
                            entrantes y {summary?.wan_probes_24h ?? 0} intentos
                            WAN en las últimas 24 h.
                        </p>
                    </div>

                </div>

                <div className="attack-settings">

                    <ToggleRow
                        label="Deny-all (hardening del firewall)"
                        hint="Descarta desde Internet todo lo que no responde a una conexión iniciada por tu red. Aislá cualquier servicio que no deba ser público."
                        checked={hardeningOn}
                        disabled={!isAdmin}
                        busy={busyKey === "hardening"}
                        onChange={toggleHardening}
                    />

                    <ToggleRow
                        label="Bloquear automáticamente la IP del atacante"
                        hint="Cuando el IPS entrante detecta un ataque (crítico/advertencia), la IP origen se bloquea además de quedar registrada. Apagado: solo se registra y vos decidís por IP."
                        checked={summary?.auto_block_inbound === true}
                        disabled={!isAdmin}
                        busy={busyKey === "auto-block"}
                        onChange={toggleAutoBlock}
                    />

                    <ToggleRow
                        label="Bloquear P2P / BitTorrent"
                        hint="Bloquea los flujos de torrent detectados (peer bloqueado en ambas direcciones). Estos eventos NO se auditan como ataques externos."
                        checked={summary?.block_p2p !== false}
                        disabled={!isAdmin}
                        busy={busyKey === "block-p2p"}
                        onChange={toggleBlockP2P}
                    />

                </div>

                {!isAdmin && (
                    <p className="attack-admin-hint">
                        Solo los administradores pueden cambiar estas opciones;
                        los operadores ven el registro en modo lectura.
                    </p>
                )}

            </section>
            )}

            {/* ---------------------------------------------------------- */}
            {/* IPs bloqueadas                                              */}
            {/* ---------------------------------------------------------- */}

            {view === "blocked" && (
            <section className="attack-section">
                <h2>IPs bloqueadas</h2>

                {blockedIps.length === 0 ? (
                    <p className="attack-empty">
                        No hay IPs atacantes bloqueadas.
                    </p>
                ) : (
                    <div className="attack-chips">
                        {blockedIps.map((row) => (
                            <div className="attack-chip" key={row.ip}>
                                <button
                                    type="button"
                                    className="attack-chip-ip"
                                    onClick={() => openDetail(row.ip)}
                                >
                                    {row.ip}
                                </button>
                                <span className="attack-chip-tag">
                                    {row.rule_source === "auto"
                                        ? "automático"
                                        : "manual"}
                                </span>
                                {row.reason && (
                                    <span
                                        className="attack-chip-reason"
                                        title={row.reason}
                                    >
                                        {row.reason}
                                    </span>
                                )}
                                {isAdmin && (
                                    <button
                                        type="button"
                                        className="attack-chip-unblock"
                                        disabled={busyKey === `unblock-${row.ip}`}
                                        onClick={() => doUnblock(row.ip)}
                                    >
                                        Desbloquear
                                    </button>
                                )}
                            </div>
                        ))}
                    </div>
                )}

                {blockedIps.some((row) => !row.active) && (
                    <p className="attack-admin-hint">
                        Nota: los bloqueos automáticos solo se aplican mientras
                        la opción "bloquear automáticamente" está activa; los
                        manuales siempre se aplican.
                    </p>
                )}

            </section>
            )}

            {/* ---------------------------------------------------------- */}
            {/* Registro                                                     */}
            {/* ---------------------------------------------------------- */}

            {view === "events" && (
            <section className="attack-section">
                <div className="attack-direction-tabs">
                    <button
                        type="button"
                        className={
                            `attack-dirtab ${dirTab === "inbound" ? "active" : ""}`
                        }
                        onClick={() => setDirTab("inbound")}
                    >
                        Ataques externos reales
                        <span className="attack-dirtab-count">
                            {inboundItems.length}
                        </span>
                    </button>
                    <button
                        type="button"
                        className={
                            `attack-dirtab ${dirTab === "outbound" ? "active" : ""}`
                        }
                        onClick={() => setDirTab("outbound")}
                    >
                        Otros flujos (salientes)
                        <span className="attack-dirtab-count">
                            {outboundItems.length}
                        </span>
                    </button>
                </div>

                <div className="attack-section-head">
                    <h2>
                        {dirTab === "inbound"
                            ? "Intentos de acceso desde Internet"
                            : "Tráfico saliente marcado"}
                    </h2>
                    <div className="attack-periods">
                        {WINDOWS.map((period) => (
                            <button
                                key={period.hours}
                                type="button"
                                className={
                                    `attack-period ${windowHours === period.hours ? "active" : ""}`
                                }
                                onClick={() => setWindowHours(period.hours)}
                            >
                                {period.label}
                            </button>
                        ))}
                    </div>
                    <div className="attack-kinds">
                        <span className="attack-kinds-label">Tipo:</span>
                        {KINDS.map((k) => (
                            <button
                                key={k.id}
                                type="button"
                                className={
                                    `attack-period ${kindFilter === k.id ? "active" : ""}`
                                }
                                onClick={() => setKindFilter(k.id)}
                            >
                                {k.label}
                            </button>
                        ))}
                    </div>
                </div>

                <p className="attack-table-note">
                    {dirTab === "inbound"
                        ? "Conexiones iniciadas desde Internet contra un servicio/puerto del NSP. Haz clic en una IP para investigarla: origen, país, organización y todos sus intentos."
                        : "Flujos donde una IP pública figura como origen pero son la respuesta a una conexión SALIENTE de tus equipos (descargas, P2P, telemetría, CDN). NO son ataques entrantes; suelen ser ruido de firmas. Igual podés investigar cada IP y bloquearla si corresponde."}
                </p>

                <div className="attack-table-wrap">
                    <table className="attack-table">
                        <thead>
                            <tr>
                                <th>IP atacante</th>
                                <th>País</th>
                                <th>ASN / Organización</th>
                                <th>Fuente</th>
                                <th>Tipo</th>
                                <th>Servicio</th>
                                <th>Detalle</th>
                                <th>Severidad</th>
                                <th>Veces</th>
                                <th>Último intento</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loadingEvents && shownItems.length === 0 ? (
                                <tr>
                                    <td className="attack-empty" colSpan={11}>
                                        Cargando registro…
                                    </td>
                                </tr>
                            ) : shownItems.length === 0 ? (
                                <tr>
                                    <td className="attack-empty" colSpan={11}>
                                        {dirTab === "inbound"
                                            ? "Sin intentos de acceso desde Internet en este período. Buena señal."
                                            : "Sin flujos salientes marcados en este período."}
                                    </td>
                                </tr>
                            ) : (
                                shownItems.map((row, index) => (
                                    <tr
                                        key={`${row.source}-${row.src_ip}-${index}`}
                                        onClick={() => openDetail(row.src_ip)}
                                    >
                                        <td className="attack-ip-cell">
                                            {row.src_ip}
                                        </td>
                                        <td>
                                            {row.country
                                                ? `${row.country}${row.asn ? ` · AS${row.asn}` : ""}`
                                                : "—"}
                                        </td>
                                        <td className="attack-org-cell">
                                            {row.as_org || "—"}
                                        </td>
                                        <td>
                                            <SourceBadge source={row.source} />
                                        </td>
                                        <td>
                                            {row.kind_label ? (
                                                <span className={"attack-badge kind-" + (row.kind || "other")}>
                                                    {row.kind_label}
                                                </span>
                                            ) : "—"}
                                        </td>
                                        <td>
                                            {row.dst_port
                                                ? `${row.protocol}/${row.dst_port}`
                                                : row.protocol}
                                        </td>
                                        <td className="attack-sig-cell">
                                            {row.signature || (
                                                row.source === "wan"
                                                    ? "Puerto probado desde Internet"
                                                    : "—"
                                            )}
                                        </td>
                                        <td>
                                            <span
                                                className={
                                                    `attack-badge `
                                                    + (row.severity === "critical"
                                                        ? "critical"
                                                        : "warning")
                                                }
                                            >
                                                {SEVERITY_LABELS[row.severity] || row.severity}
                                            </span>
                                        </td>
                                        <td className="attack-num-cell">
                                            {new Intl.NumberFormat("es").format(
                                                row.hit_count || 1
                                            )}
                                        </td>
                                        <td>{formatDateTime(row.last_seen)}</td>
                                        <td>
                                            <span
                                                className={
                                                    `attack-badge ${row.blocked ? "blocked" : "free"}`
                                                }
                                            >
                                                {row.blocked ? "Bloqueada" : "No bloqueada"}
                                            </span>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </section>
            )}

            {/* ---------------------------------------------------------- */}
            {/* Dialog de investigacion                                      */}
            {/* ---------------------------------------------------------- */}

            {detail && (
                <div
                    className="attack-overlay"
                    onClick={() => setDetail(null)}
                >
                    <div
                        className="attack-dialog"
                        onClick={(event) => event.stopPropagation()}
                    >
                        {detailLoading || detailStateLoading(detail) ? (
                            <h3>Cargando detalle…</h3>
                        ) : detailStateError(detail) ? (
                            <>
                                <h3>No se pudo cargar el detalle</h3>
                                <div className="attack-dialog-actions">
                                    <button
                                        className="secondary-button"
                                        onClick={() => setDetail(null)}
                                    >
                                        Cerrar
                                    </button>
                                </div>
                            </>
                        ) : (
                            <>
                                <h3>IP atacante: {detail.ip}</h3>

                                <div className="attack-dialog-grid">

                                    <div className="attack-dialog-field">
                                        <span>País</span>
                                        <strong>{detail.geo?.country || "—"}</strong>
                                    </div>

                                    <div className="attack-dialog-field">
                                        <span>ASN</span>
                                        <strong>
                                            {detail.geo?.asn
                                                ? `AS${detail.geo.asn}`
                                                : "—"}
                                        </strong>
                                    </div>

                                    <div className="attack-dialog-field">
                                        <span>Organización</span>
                                        <strong>{detail.geo?.as_org || "—"}</strong>
                                    </div>

                                    <div className="attack-dialog-field">
                                        <span>Estado</span>
                                        <strong>
                                            {detail.blocked?.blocked
                                                ? `Bloqueada (${detail.blocked.rule_source === "auto" ? "automático" : "manual"})`
                                                : "No bloqueada"}
                                        </strong>
                                    </div>

                                </div>

                                {detail.blocked?.reason && (
                                    <p className="attack-dialog-reason">
                                        Motivo: {detail.blocked.reason}
                                    </p>
                                )}

                                <div className="attack-dialog-sub">
                                    <h4>
                                        Intentos detectados por el IPS
                                        ({detail.inbound_events?.length ?? 0})
                                    </h4>

                                    {detail.inbound_events?.length ? (
                                        <ul className="attack-dialog-list">
                                            {detail.inbound_events.map((row, index) => (
                                                <li key={`in-${index}`}>
                                                    <span
                                                        className={
                                                            `attack-badge `
                                                            + (row.severity === "critical"
                                                                ? "critical"
                                                                : "warning")
                                                        }
                                                    >
                                                        {SEVERITY_LABELS[row.severity] || row.severity}
                                                    </span>
                                                    <em>{row.signature}</em>
                                                    <span>
                                                        {row.protocol}/{row.dst_port || "?"} ·{" "}
                                                        {new Intl.NumberFormat("es").format(row.hit_count)} vez/veces
                                                    </span>
                                                    <span>{formatDateTime(row.last_seen)}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <p className="attack-empty">
                                            Sin detecciones de IPS entrantes
                                            en los últimos 7 días.
                                        </p>
                                    )}
                                </div>

                                <div className="attack-dialog-sub">
                                    <h4>
                                        Intentos de conexión (firewall)
                                        ({detail.wan_probes?.length ?? 0})
                                    </h4>

                                    {detail.wan_probes?.length ? (
                                        <ul className="attack-dialog-list">
                                            {detail.wan_probes.map((row, index) => (
                                                <li key={`wan-${index}`}>
                                                    <span className="attack-badge wan">
                                                        {row.chain === "input"
                                                            ? "Al NSP"
                                                            : "A la red"}
                                                    </span>
                                                    <span>
                                                        {row.protocol}/{row.dst_port || "?"}
                                                    </span>
                                                    <span>
                                                        {new Intl.NumberFormat("es").format(row.hit_count)} vez/veces
                                                    </span>
                                                    <span>{formatDateTime(row.last_seen)}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <p className="attack-empty">
                                            Sin intentos de conexión desde
                                            Internet en los últimos 7 días.
                                        </p>
                                    )}
                                </div>

                                <div className="attack-dialog-actions">
                                    {isAdmin ? (
                                        detail.blocked?.blocked ? (
                                            <button
                                                className="danger-button"
                                                disabled={busyKey === `unblock-${detail.ip}`}
                                                onClick={() => doUnblock(detail.ip)}
                                            >
                                                Desbloquear IP
                                            </button>
                                        ) : (
                                            <button
                                                className="primary-button"
                                                disabled={
                                                    busyKey === `block-${detail.ip}`
                                                    || detail.blocked?.rule_source === "auto"
                                                }
                                                onClick={() => doBlock(detail.ip)}
                                            >
                                                Bloquear IP
                                            </button>
                                        )
                                    ) : (
                                        <p className="attack-admin-hint">
                                            Solo administradores pueden
                                            bloquear/desbloquear.
                                        </p>
                                    )}
                                    <button
                                        className="secondary-button"
                                        onClick={() => setDetail(null)}
                                    >
                                        Cerrar
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}

        </div>
    );

}


function detailStateLoading(detail) {

    return detail && detail.state === "loading";

}


function detailStateError(detail) {

    return detail && detail.state === "error";

}