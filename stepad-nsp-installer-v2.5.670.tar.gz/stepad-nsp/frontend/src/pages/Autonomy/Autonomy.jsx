import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import {
    captureGoldenConfig,
    getAutonomyDiagnosis,
    getAutonomyDnsThreats,
    getAutonomyHistory,
    getGoldenConfigStatus,
    getAutonomyProbe,
    getAutonomyTransactions,
    runAutonomyRepair,
} from "../../services/api";
import ActionButton from "../../components/ui/ActionButton";

import "./autonomy.css";


function statusLabel(status) {

    return {
        ok: "OK",
        warning: "Atención",
        critical: "Crítico",
        unknown: "Sin datos",
    }[status] || status;

}


export default function Autonomy() {

    const [report, setReport] = useState(null);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState("");

    const [probe, setProbe] = useState(null);
    const [history, setHistory] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [dnsThreats, setDnsThreats] = useState(null);
    const [golden, setGolden] = useState(null);
    const [goldenBusy, setGoldenBusy] = useState(false);
    const [probeBusy, setProbeBusy] = useState(false);
    const [message, setMessage] = useState("");
    const [error, setError] = useState("");

    async function loadHistory() {

        try {
            const [result, tx] = await Promise.all([
                getAutonomyHistory(20),
                getAutonomyTransactions(20),
            ]);
            setHistory(result?.items || []);
            setTransactions(tx?.items || []);
        } catch {
            setHistory([]);
            setTransactions([]);
        }

    }

    async function runProbe() {

        setProbeBusy(true);
        setError("");
        try {
            setProbe(await getAutonomyProbe());
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo probar la navegación.");
        } finally {
            setProbeBusy(false);
        }

    }

    async function captureGolden() {

        setGoldenBusy(true);
        setMessage("");
        setError("");
        try {
            const result = await captureGoldenConfig(
                `Línea base ${new Date().toLocaleString("es-EC")}`
            );
            setGolden(result?.status || await getGoldenConfigStatus());
            setMessage("Línea base dorada guardada.");
            await load();
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo guardar la línea base.");
        } finally {
            setGoldenBusy(false);
        }

    }

    async function load() {

        setLoading(true);
        try {
            setReport(await getAutonomyDiagnosis());
            await loadHistory();
            try {
                setDnsThreats(await getAutonomyDnsThreats());
            } catch {
                setDnsThreats(null);
            }
            try {
                setGolden(await getGoldenConfigStatus());
            } catch {
                setGolden(null);
            }
            setError("");
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo diagnosticar.");
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        load();
        const timer = setInterval(load, 30000);
        return () => clearInterval(timer);
    }, []);

    async function repair(action) {

        setBusy(action);
        setMessage("");
        setError("");
        try {
            const result = await runAutonomyRepair(action);
            setMessage(
                result?.success
                    ? `Reparación aplicada. Reglas fantasma restantes: ${result.verified?.ghost_rules ?? 0}.`
                    : "La reparación no se completó."
            );
            await load();
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo reparar.");
        } finally {
            setBusy("");
        }
    }

    const checks = report?.checks || [];
    const critical = report?.summary?.critical || 0;
    const warning = report?.summary?.warning || 0;

    return (
        <div className="auto-page">
            <header className="auto-hero">
                <div>
                    <span className="auto-eyebrow">AUTONOMÍA DEL NSP</span>
                    <h1>Diagnóstico y reparación</h1>
                    <p>
                        Comprobaciones deterministas con evidencia. Las acciones
                        automáticas solo se ejecutan si son seguras y se validan
                        de nuevo al terminar.
                    </p>
                </div>
                <div className="auto-hero-actions">
                    <span className={`auto-status ${report?.status || "unknown"}`}>
                        {statusLabel(report?.status)}
                    </span>
                    <ActionButton variant="secondary" loading={loading} onClick={load}>
                        Revisar ahora
                    </ActionButton>
                </div>
            </header>

            {error && <div className="auto-error">{error}</div>}
            {message && <div className="auto-ok">{message}</div>}

            <div className="auto-summary">
                <div className={`auto-kpi ${critical ? "bad" : "ok"}`}>
                    <span>Críticos</span>
                    <strong>{critical}</strong>
                </div>
                <div className={`auto-kpi ${warning ? "warn" : "ok"}`}>
                    <span>Atención</span>
                    <strong>{warning}</strong>
                </div>
                <div className="auto-kpi">
                    <span>Comprobaciones</span>
                    <strong>{checks.length}</strong>
                </div>
                <div className="auto-kpi">
                    <span>Último análisis</span>
                    <strong className="auto-time">{report?.generated_at ? new Date(report.generated_at).toLocaleTimeString("es-EC") : "—"}</strong>
                </div>
            </div>

            <div className="auto-list">
                {checks.map((check) => (
                    <div className={`auto-check ${check.status}`} key={check.key}>
                        <div className="auto-check-main">
                            <span className={`auto-dot ${check.status}`} />
                            <div>
                                <strong>{check.label}</strong>
                                <p>{check.detail}</p>
                            </div>
                        </div>
                        <div className="auto-check-actions">
                            <span className={`auto-badge ${check.status}`}>{statusLabel(check.status)}</span>
                            {check.auto_fix && (
                                <ActionButton
                                    variant="primary"
                                    size="sm"
                                    loading={busy === check.action}
                                    disabled={Boolean(busy)}
                                    onClick={() => repair(check.action)}
                                >
                                    Reparar
                                </ActionButton>
                            )}
                            {check.link && (
                                <Link to={check.link}>Ver detalle</Link>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            <section className="auto-tools">

                <div>
                    <span className="auto-eyebrow">PRUEBA SINTÉTICA</span>
                    <h2>Probar navegación</h2>
                    <p>DHCP real, DNS local y HTTPS externo, sin depender de un usuario.</p>
                </div>

                <ActionButton
                    variant="primary"
                    size="sm"
                    loading={probeBusy}
                    onClick={runProbe}
                >
                    Probar ahora
                </ActionButton>

                {probe && (
                    <div className="auto-probe-list">
                        {probe.checks.map((item) => (
                            <div key={item.key} className={`auto-probe ${item.ok ? "ok" : "bad"}`}>
                                <span>{item.label}</span>
                                <strong>{item.ok ? "OK" : "FALLÓ"}</strong>
                                <small>{item.latency_ms != null ? `${item.latency_ms} ms` : "sin medición"} · {item.detail}</small>
                            </div>
                        ))}
                    </div>
                )}

            </section>

            <section className="auto-history">

                <div className="auto-history-head">
                    <div>
                        <span className="auto-eyebrow">DNS AVANZADO</span>
                        <h2>Detección pasiva</h2>
                    </div>
                    <span>{dnsThreats?.summary?.total ?? 0} hallazgos</span>
                </div>

                {!dnsThreats || (dnsThreats.findings || []).length === 0 ? (
                    <p className="auto-empty">
                        Sin túneles, DGA, beaconing ni intentos DoH en la ventana analizada.
                    </p>
                ) : (
                    <div className="auto-history-list">
                        {dnsThreats.findings.map((item, index) => (
                            <div key={`${item.kind}-${index}`} className={`auto-history-row ${item.severity}`}>
                                <span className={`auto-dot ${item.severity === "critical" ? "critical" : "warning"}`} />
                                <div>
                                    <strong>{item.title}</strong>
                                    <p>{item.message}</p>
                                    <small>
                                        {item.kind} · {item.device} · {item.domain}
                                    </small>
                                </div>
                                <span className="auto-badge warning">{item.severity}</span>
                            </div>
                        ))}
                    </div>
                )}

            </section>

            <section className="auto-history">

                <div className="auto-history-head">
                    <div>
                        <span className="auto-eyebrow">CONFIGURACIÓN DORADA</span>
                        <h2>Línea base y deriva</h2>
                    </div>
                    <div className="auto-check-actions">
                        <span className={`auto-badge ${golden?.configured ? (golden?.drift ? "warning" : "ok") : "warning"}`}>
                            {golden?.configured ? (golden?.drift ? "Deriva" : "Sin deriva") : "Sin línea base"}
                        </span>
                        <ActionButton
                            variant="secondary"
                            size="sm"
                            loading={goldenBusy}
                            onClick={captureGolden}
                        >
                            Guardar línea base
                        </ActionButton>
                    </div>
                </div>

                {!golden?.configured ? (
                    <p className="auto-empty">
                        Guardá una línea base para detectar cambios no previstos en reglas,
                        grupos, DHCP, VPN, firewalls de puertos y ajustes.
                    </p>
                ) : (
                    <>
                        <p className="auto-subtle">
                            {golden.baseline?.label} · {golden.baseline?.created_at ? new Date(golden.baseline.created_at).toLocaleString("es-EC") : "—"} · hash {golden.baseline?.hash?.slice(0, 12)}
                        </p>
                        {golden.drift ? (
                            <div className="auto-history-list">
                                {(golden.changes || []).map((item) => (
                                    <div key={item.section} className="auto-history-row warning">
                                        <span className="auto-dot warning" />
                                        <div>
                                            <strong>{item.section}</strong>
                                            <p>
                                                {item.modified} cambios · {item.added} altas · {item.removed} bajas
                                            </p>
                                            {item.modified_sample?.length > 0 && (
                                                <small>
                                                    Campos: {item.modified_sample[0].fields?.join(", ")}
                                                </small>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="auto-empty">La configuración actual coincide con la línea base.</p>
                        )}
                    </>
                )}

            </section>

            <section className="auto-history">

                <div className="auto-history-head">
                    <div>
                        <span className="auto-eyebrow">HISTORIAL</span>
                        <h2>Incidentes y acciones</h2>
                    </div>
                    <span>{history.length} recientes</span>
                </div>

                {history.length === 0 ? (
                    <p className="auto-empty">Sin incidentes de autonomía registrados.</p>
                ) : (
                    <div className="auto-history-list">
                        {history.map((item) => (
                            <div key={`${item.type}-${item.id}`} className={`auto-history-row ${item.severity}`}>
                                <span className={`auto-dot ${item.severity === "critical" ? "critical" : "warning"}`} />
                                <div>
                                    <strong>{item.title}</strong>
                                    <p>{item.message}</p>
                                    <small>
                                        {new Date(item.created_at).toLocaleString("es-EC")}
                                        {item.resolved_at ? " · resuelto" : " · abierto"}
                                    </small>
                                </div>
                                <span className={`auto-badge ${item.resolved_at ? "ok" : "warning"}`}>
                                    {item.resolved_at ? "Resuelto" : "Abierto"}
                                </span>
                            </div>
                        ))}
                    </div>
                )}

            </section>

            <section className="auto-history">

                <div className="auto-history-head">
                    <div>
                        <span className="auto-eyebrow">CAMBIOS</span>
                        <h2>Transacciones recientes</h2>
                    </div>
                    <span>{transactions.length} registradas</span>
                </div>

                {transactions.length === 0 ? (
                    <p className="auto-empty">Sin cambios transaccionales registrados.</p>
                ) : (
                    <div className="auto-history-list">
                        {transactions.map((item) => (
                            <div key={item.id} className="auto-history-row info">
                                <span className={`auto-dot ${item.status === "rolled_back" || item.status === "failed" ? "warning" : ""}`} />
                                <div>
                                    <strong>{item.action} · {item.target}</strong>
                                    <p>
                                        {item.before} → {item.after}
                                        {item.error ? ` · ${item.error}` : ""}
                                    </p>
                                    <small>
                                        {item.started_at ? new Date(item.started_at).toLocaleString("es-EC") : "—"}
                                    </small>
                                </div>
                                <span className={`auto-badge ${item.status === "applied" ? "ok" : "warning"}`}>
                                    {item.status}
                                </span>
                            </div>
                        ))}
                    </div>
                )}

            </section>

            <footer className="auto-footer">
                Actualización automática cada 30 s · no reinicia servicios sin evidencia
            </footer>
        </div>
    );
}
