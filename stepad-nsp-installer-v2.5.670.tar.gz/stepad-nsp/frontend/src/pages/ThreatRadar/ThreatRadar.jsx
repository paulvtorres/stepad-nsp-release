import { useEffect, useMemo, useState } from "react";

import { Link } from "react-router-dom";

import {
    getAdsBlocked,
    getAlerts,
    getAttackEvents,
    getAttackSummary,
    getDevices,
    getIpsStatus,
    getProtectionSummary,
} from "../../services/api";

import ActionButton from "../../components/ui/ActionButton";

import "./threat-radar.css";


function hashCode(value) {

    let hash = 0;

    const text = String(value || "");

    for (let index = 0; index < text.length; index += 1) {
        hash = ((hash << 5) - hash) + text.charCodeAt(index);
        hash |= 0;
    }

    return Math.abs(hash);
}


function blipStyle(seed, index) {

    const hash = hashCode(seed);

    const angle = ((hash % 360) + index * 37) * (Math.PI / 180);

    const radius = 18 + ((hash >> 4) % 30);

    return {
        left: `${50 + Math.cos(angle) * radius}%`,
        top: `${50 + Math.sin(angle) * radius}%`,
        animationDelay: `${(hash % 12) / 10}s`,
    };
}


function formatNumber(value) {

    return new Intl.NumberFormat("es-EC").format(Number(value || 0));

}


export default function ThreatRadar() {

    const [protection, setProtection] = useState(null);

    const [ads, setAds] = useState(null);

    const [attackSummary, setAttackSummary] = useState(null);

    const [attackEvents, setAttackEvents] = useState([]);

    const [ips, setIps] = useState(null);

    const [devices, setDevices] = useState([]);

    const [alerts, setAlerts] = useState(null);

    const [loading, setLoading] = useState(true);

    const [refreshing, setRefreshing] = useState(false);

    const [lastUpdated, setLastUpdated] = useState(null);

    const [error, setError] = useState("");


    async function load() {

        const results = await Promise.allSettled([
            getProtectionSummary(1),
            getAdsBlocked(1, 1),
            getAttackSummary(),
            getAttackEvents(24, 12),
            getIpsStatus(),
            getDevices(),
            getAlerts(5),
        ]);

        const [
            protectionResult,
            adsResult,
            attackSummaryResult,
            attackEventsResult,
            ipsResult,
            devicesResult,
            alertsResult,
        ] = results;

        if (protectionResult.status === "fulfilled") setProtection(protectionResult.value);
        if (adsResult.status === "fulfilled") setAds(adsResult.value);
        if (attackSummaryResult.status === "fulfilled") setAttackSummary(attackSummaryResult.value);
        if (attackEventsResult.status === "fulfilled") setAttackEvents(attackEventsResult.value?.items || []);
        if (ipsResult.status === "fulfilled") setIps(ipsResult.value);
        if (devicesResult.status === "fulfilled") setDevices(devicesResult.value || []);
        if (alertsResult.status === "fulfilled") setAlerts(alertsResult.value);

        if (results.every((result) => result.status === "rejected")) {
            setError("No se pudo consultar el radar.");
        } else {
            setError("");
        }

        setLastUpdated(new Date());
        setLoading(false);

    }


    async function refresh() {

        setRefreshing(true);

        await load();

        setRefreshing(false);

    }


    useEffect(() => {

        load();

        const timer = setInterval(load, 15000);

        return () => clearInterval(timer);

    }, []);


    const onlineDevices = devices.filter(
        (device) => (device.presence_status || device.status) === "ONLINE",
    ).length;

    const dnsBlocked = protection?.dns?.blocked ?? 0;

    const adsBlocked = ads?.total ?? 0;

    const attacks24h = attackSummary?.inbound_events_24h ?? 0;

    const ipsAlerts = ips?.alerts_last_24h ?? 0;

    const unreadAlerts = alerts?.unread ?? 0;

    const topDomains = protection?.top_blocked_domains || [];

    const topDevices = protection?.top_blocked_devices || [];

    const blips = useMemo(() => {

        const domainBlips = topDomains.slice(0, 9).map((row, index) => ({
            id: `domain-${row.domain}`,
            label: row.domain,
            detail: `${formatNumber(row.attempts)} intentos`,
            kind: "dns",
            style: blipStyle(row.domain, index),
        }));

        const attackBlips = attackEvents.slice(0, 6).map((row, index) => ({
            id: `attack-${row.ip}-${index}`,
            label: row.ip,
            detail: `${row.country || "—"} · ${row.kind_label || row.signature || "Intento externo"}`,
            kind: row.severity === "critical" ? "critical" : "attack",
            style: blipStyle(row.ip, index + 3),
        }));

        return [...domainBlips, ...attackBlips];

    }, [topDomains, attackEvents]);


    return (

        <div className="tr-page">

            <header className="tr-hero">

                <div className="tr-hero-glow" aria-hidden="true" />

                <div>
                    <span className="tr-eyebrow">CENTRO DE OPERACIONES</span>
                    <h1>
                        Radar de amenazas
                        <span className="tr-live"><i /> EN VIVO</span>
                    </h1>
                </div>

                <div className="tr-hero-actions">
                    <span>{lastUpdated ? lastUpdated.toLocaleTimeString("es-EC") : "Conectando…"}</span>
                    <ActionButton variant="secondary" loading={refreshing} onClick={refresh}>
                        Actualizar
                    </ActionButton>
                </div>

            </header>

            {error && <div className="tr-error">{error}</div>}

            <div className="tr-layout">

                <section className="tr-radar-panel">

                    <div className="tr-radar">

                        <span className="tr-ring r1" aria-hidden="true" />
                        <span className="tr-ring r2" aria-hidden="true" />
                        <span className="tr-ring r3" aria-hidden="true" />
                        <span className="tr-sweep" aria-hidden="true" />
                        <span className="tr-cross h" aria-hidden="true" />
                        <span className="tr-cross v" aria-hidden="true" />

                        {
                            blips.map((blip) => (
                                <span
                                    key={blip.id}
                                    className={`tr-blip ${blip.kind}`}
                                    style={blip.style}
                                    title={`${blip.label} — ${blip.detail}`}
                                />
                            ))
                        }

                        <div className="tr-core">
                            <strong>NSP</strong>
                            <span>{onlineDevices} equipos</span>
                        </div>

                    </div>

                    <div className="tr-radar-legend">
                        <span><i className="dns" /> Filtrado DNS</span>
                        <span><i className="attack" /> Ataque externo</span>
                        <span><i className="critical" /> Crítico</span>
                    </div>

                </section>

                <section className="tr-stats">

                    <div className="tr-stat danger">
                        <span>Bloqueos DNS · 1 h</span>
                        <strong>{formatNumber(dnsBlocked)}</strong>
                        <small>{formatNumber(adsBlocked)} de publicidad</small>
                    </div>

                    <div className="tr-stat attack">
                        <span>Ataques externos · 24 h</span>
                        <strong>{formatNumber(attacks24h)}</strong>
                        <small>{formatNumber(attackSummary?.real_inbound_24h ?? 0)} reales</small>
                    </div>

                    <div className="tr-stat ok">
                        <span>Firmas IPS cargadas</span>
                        <strong>{formatNumber(ips?.rules_loaded)}</strong>
                        <small>Suricata activo</small>
                    </div>

                    <div className="tr-stat warn">
                        <span>Alertas sin leer</span>
                        <strong>{formatNumber(unreadAlerts)}</strong>
                        <small>{formatNumber(ipsAlerts)} IPS en 24 h</small>
                    </div>

                </section>

            </div>

            <div className="tr-activity-grid">

                <section className="tr-activity">

                    <header>
                        <div>
                            <h2>Últimos bloqueos</h2>
                            <p>Dominios que el escudo detuvo.</p>
                        </div>
                        <Link to="/protection?view=ads">Ver todos</Link>
                    </header>

                    <div className="tr-list">

                        {
                            topDomains.slice(0, 8).map((row) => (
                                <div className="tr-row" key={row.domain}>
                                    <span className="tr-row-domain">{row.domain}</span>
                                    <strong>{formatNumber(row.attempts)}</strong>
                                </div>
                            ))
                        }

                        {
                            topDomains.length === 0 && (
                                <p className="tr-empty">Sin bloqueos en la última hora.</p>
                            )
                        }

                    </div>

                </section>

                <section className="tr-activity">

                    <header>
                        <div>
                            <h2>Actividad externa</h2>
                            <p>Intentos que llegaron desde Internet.</p>
                        </div>
                        <Link to="/external-attacks">Ver detalle</Link>
                    </header>

                    <div className="tr-list">

                        {
                            attackEvents.slice(0, 8).map((row, index) => (
                                <div className="tr-row" key={`${row.ip}-${index}`}>
                                    <span className="tr-row-domain">
                                        {row.ip}
                                        <small>{row.country || "—"} · {row.as_org || row.kind_label || "Externo"}</small>
                                    </span>
                                    <strong>{row.hit_count || 1}</strong>
                                </div>
                            ))
                        }

                        {
                            attackEvents.length === 0 && (
                                <p className="tr-empty">Sin actividad externa relevante.</p>
                            )
                        }

                    </div>

                </section>

                <section className="tr-activity">

                    <header>
                        <div>
                            <h2>Top equipos</h2>
                            <p>Equipos con más bloqueos.</p>
                        </div>
                        <Link to="/network/devices">Dispositivos</Link>
                    </header>

                    <div className="tr-list">

                        {
                            topDevices.slice(0, 8).map((row) => (
                                <div className="tr-row" key={`${row.device_id}-${row.device_name}`}>
                                    <span className="tr-row-domain">
                                        {row.device_name}
                                        <small>{row.device_ip || "—"}</small>
                                    </span>
                                    <strong>{formatNumber(row.attempts)}</strong>
                                </div>
                            ))
                        }

                        {
                            topDevices.length === 0 && (
                                <p className="tr-empty">Sin datos por equipo.</p>
                            )
                        }

                    </div>

                </section>

            </div>

            <footer className="tr-footer">
                <span>Datos reales · actualización cada 15 s</span>
                <span>{loading ? "Cargando…" : `${formatNumber(devices.length)} equipos registrados`}</span>
            </footer>

        </div>

    );

}
