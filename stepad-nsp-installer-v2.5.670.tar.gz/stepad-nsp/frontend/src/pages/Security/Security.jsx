import { useState } from "react";

import DomainRules from "./components/DomainRules";
import EncryptedDnsSecurity from "./components/EncryptedDnsSecurity";
import ContentCategories from "./components/ContentCategories";
import AdsTrackerLive from "../Protection/AdsTrackerLive";
import FirewallHardening from "./components/FirewallHardening";
import WanProbeLog from "./components/WanProbeLog";
import SecurityAdvisories from "./components/SecurityAdvisories";

import "./security.css";


const TABS = [
    { id: "advisories", label: "Avisos de seguridad" },
    { id: "domains", label: "Bloqueo de dominios" },
    { id: "dns", label: "DNS cifrado (DoT/DoH)" },
    { id: "content", label: "Filtrado por categoría" },
    { id: "ads", label: "Anuncios en vivo" },
    { id: "firewall", label: "Firewall (deny-all)" },
    { id: "wan", label: "Sondeo WAN" }
];


function Security() {

    const [tab, setTab] = useState("advisories");

    return (

        <div className="security-container">

            <h2>
                Gestión de seguridad
            </h2>

            <p className="security-description">

                Administra los bloqueos de la red en todas sus capas:
                dominios, DNS cifrado (DoT/DoH), categorías de contenido,
                firewall y sondeo WAN. Elegí una pestaña para ver solo lo que
                necesitás.

            </p>

            <div className="security-tabs" role="tablist">

                {
                    TABS.map(item => (

                        <button
                            key={item.id}
                            type="button"
                            role="tab"
                            aria-selected={tab === item.id}
                            className={`security-tab ${tab === item.id ? "active" : ""}`}
                            onClick={() => setTab(item.id)}
                        >
                            {item.label}
                        </button>

                    ))
                }

            </div>

            <div className="security-tab-panel">

                {
                    tab === "advisories" && <SecurityAdvisories />
                }

                {
                    tab === "domains" && <DomainRules />
                }

                {
                    tab === "dns" && <EncryptedDnsSecurity />
                }

                {
                    tab === "content" && <ContentCategories />
                }

                {
                    tab === "ads" && <AdsTrackerLive />
                }

                {
                    tab === "firewall" && <FirewallHardening />
                }

                {
                    tab === "wan" && <WanProbeLog />
                }

            </div>

        </div>

    );

}


export default Security;
