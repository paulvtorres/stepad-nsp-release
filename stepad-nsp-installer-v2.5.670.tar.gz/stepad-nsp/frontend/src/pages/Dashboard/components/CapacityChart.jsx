function linePoints(items, key, width, height) {
    if (!items.length) return "";
    const max = 100;
    return items.map((item, index) => {
        const x = items.length === 1 ? width / 2 : (index / (items.length - 1)) * width;
        const value = Math.max(0, Math.min(max, Number(item[key]) || 0));
        const y = height - (value / max) * height;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" ");
}

export default function CapacityChart({ items = [] }) {
    if (items.length < 2) return null;
    const width = 600;
    const height = 120;

    const series = [
        { key: "cpu_percent", label: "CPU", color: "#38bdf8" },
        { key: "ram_percent", label: "RAM", color: "#f59e0b" },
        { key: "disk_percent", label: "Disco", color: "#a78bfa" },
    ];

    return (
        <div className="capacity-chart">
            <div className="capacity-chart-head">
                <strong>Tendencia de capacidad</strong>
                <span>Últimas {items.length} muestras</span>
            </div>
            <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Tendencia de CPU, RAM y disco">
                {[25, 50, 75, 100].map((value) => {
                    const y = height - (value / 100) * height;
                    return <line key={value} x1="0" y1={y} x2={width} y2={y} className="capacity-grid-line" />;
                })}
                {series.map((entry) => (
                    <polyline
                        key={entry.key}
                        fill="none"
                        stroke={entry.color}
                        strokeWidth="2"
                        vectorEffect="non-scaling-stroke"
                        points={linePoints(items, entry.key, width, height)}
                    />
                ))}
            </svg>
            <div className="capacity-chart-legend">
                {series.map((entry) => (
                    <span key={entry.key}>
                        <i style={{ background: entry.color }} />
                        {entry.label}
                    </span>
                ))}
            </div>
        </div>
    );
}
