import { useCallback, useEffect, useState } from "react";

import { getShareBackupErrors } from "../../services/api";
import { formatDateTime } from "../../utils/datetime";

export default function BackupStatusPanel() {
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    const load = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            setData(await getShareBackupErrors());
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { load(); }, [load]);

    function downloadReport() {
        if (!data) return;
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `reporte-estado-respaldos-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
    }

    const issues = data?.issues || [];
    return (
        <section className="sh-bk-error-vault">
            <header className="sh-bk-error-head">
                <div>
                    <p className="sh-eyebrow">Estado</p>
                    <h3>Baúl de errores de respaldos</h3>
                    <p className="sh-muted">
                        Solo se muestran errores vigentes. Cuando se corrige la causa y el
                        respaldo vuelve a completarse sin incidencias, el error desaparece
                        automáticamente del baúl.
                    </p>
                </div>
                <div className="sh-actions">
                    <button type="button" className="sh-btn" onClick={load} disabled={loading}>
                        {loading ? "Actualizando…" : "Actualizar"}
                    </button>
                    <button type="button" className="sh-btn" onClick={downloadReport} disabled={!data}>
                        Descargar reporte
                    </button>
                </div>
            </header>

            {error && <div className="sh-banner error">{error}</div>}

            {data && (
                <>
                    <div className="sh-bk-error-stats">
                        <span><b>{data.total}</b> respaldos</span>
                        <span className="ok"><b>{data.ok}</b> sin errores</span>
                        <span className="warn"><b>{data.warnings}</b> advertencias</span>
                        <span className="err"><b>{data.errors}</b> errores</span>
                        <span className="sh-muted">Actualizado {formatDateTime(data.generated_at)}</span>
                    </div>

                    {issues.length === 0 ? (
                        <div className="sh-banner ok">Sin errores actuales en los respaldos.</div>
                    ) : (
                        <div className="sh-bk-error-list">
                            {issues.map((issue, index) => (
                                <article key={`${issue.job_id}-${issue.type}-${index}`} className={`sh-bk-error-item ${issue.severity}`}>
                                    <div className="sh-bk-error-title">
                                        <span className={`sh-badge ${issue.severity === "error" ? "sh-badge-failing" : "sh-badge-skipped"}`}>
                                            {issue.severity === "error" ? "ERROR" : "ADVERTENCIA"}
                                        </span>
                                        <strong>{issue.title}</strong>
                                        <span className="sh-muted">· {issue.name}</span>
                                    </div>
                                    <p>{issue.detail}</p>
                                    <p className="sh-muted">
                                        Último intento: {formatDateTime(issue.last_attempt_at)}
                                        {issue.consecutive_failures ? ` · ${issue.consecutive_failures} fallos seguidos` : ""}
                                    </p>
                                    {issue.unreadable_samples?.length > 0 && (
                                        <details>
                                            <summary>Ver rutas y motivos</summary>
                                            <ul>
                                                {issue.unreadable_samples.map((sample, sampleIndex) => (
                                                    <li key={`${sampleIndex}-${sample}`}><code>{sample}</code></li>
                                                ))}
                                            </ul>
                                        </details>
                                    )}
                                </article>
                            ))}
                        </div>
                    )}
                </>
            )}
        </section>
    );
}
