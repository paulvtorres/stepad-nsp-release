import { useEffect, useState } from "react";

import { getDeviceIpHistory } from "../../../../services/api";


function formatDate(value) {
    if (!value) return "—";
    try {
        return new Date(value).toLocaleString();
    } catch {
        return value;
    }
}


export default function DeviceIpHistory({ device }) {
    const [items, setItems] = useState([]);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!device?.id) return;

        let active = true;

        async function load() {
            setLoading(true);
            try {
                const data = await getDeviceIpHistory(device.id);
                if (active) setItems(data?.items || []);
                setError("");
            } catch (err) {
                if (active) {
                    setError(
                        err?.response?.data?.detail
                        || err.message
                        || "No se pudo leer el historial."
                    );
                }
            } finally {
                if (active) setLoading(false);
            }
        }

        load();
        return () => { active = false; };
    }, [device?.id]);

    return (
        <div className="registry-panel">
            <h3>Historial de IPs</h3>
            <p className="registry-hint">
                IPs que este equipo dejó de usar. No se borra el equipo.
            </p>

            {error && <p className="registry-message error">{error}</p>}
            {loading && <p className="registry-hint">Cargando…</p>}

            {!loading && !error && (
                <div className="dhcp-table-wrap">
                    <table className="dhcp-ip-table">
                        <thead>
                            <tr>
                                <th>IP</th>
                                <th>MAC</th>
                                <th>Desde</th>
                                <th>Hasta</th>
                                <th>Origen</th>
                            </tr>
                        </thead>
                        <tbody>
                            {items.map((item) => (
                                <tr key={item.id}>
                                    <td><code>{item.ip_address}</code></td>
                                    <td><code>{item.mac_address || "—"}</code></td>
                                    <td>{formatDate(item.started_at)}</td>
                                    <td>{formatDate(item.ended_at)}</td>
                                    <td>{item.source || "—"}</td>
                                </tr>
                            ))}
                            {items.length === 0 && (
                                <tr><td colSpan={5}>Sin historial de IPs.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
