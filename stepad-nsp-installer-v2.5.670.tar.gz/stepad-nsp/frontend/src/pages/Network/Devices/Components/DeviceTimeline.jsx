import { useEffect, useState } from "react";

import { getDeviceTimeline } from "../../../../services/api";
import { formatDateTime } from "../../../../utils/datetime";


function severityLabel(value) {
    return {
        info: "Info",
        warning: "Atención",
        critical: "Crítico",
    }[value] || value;
}


function DeviceTimeline({ device }) {

    const [hours, setHours] = useState(24);
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {

        let cancelled = false;

        async function load() {

            if (!device) return;

            setLoading(true);
            setError("");

            try {
                const result = await getDeviceTimeline(device.id, hours);
                if (!cancelled) setData(result);
            } catch (err) {
                if (!cancelled) {
                    setError(err?.response?.data?.detail || err.message || "No se pudo cargar la línea de tiempo.");
                    setData(null);
                }
            } finally {
                if (!cancelled) setLoading(false);
            }

        }

        load();

        return () => { cancelled = true; };

    }, [device, hours]);

    if (!device) return <p>Selecciona un dispositivo...</p>;

    const summary = data?.summary || {};

    return (
        <div className="card">

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                <div>
                    <h3>Línea de tiempo</h3>
                    <p style={{ color: "var(--muted)", fontSize: 13, marginTop: -8 }}>
                        DHCP/IPAM, DNS, IPS, cuarentena y cambios relevantes del equipo.
                    </p>
                </div>
                <select value={hours} onChange={(event) => setHours(Number(event.target.value))}>
                    <option value={24}>Últimas 24 h</option>
                    <option value={72}>Últimos 3 días</option>
                    <option value={168}>Últimos 7 días</option>
                </select>
            </div>

            {loading && <p>Cargando línea de tiempo...</p>}
            {error && <p style={{ color: "var(--danger)" }}>{error}</p>}

            {!loading && data && (
                <>
                    <div className="timeline-summary" style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", marginBottom: 16 }}>
                        <div className="card"><small>Consultas DNS</small><strong>{summary.dns_total || 0}</strong></div>
                        <div className="card"><small>Bloqueos DNS</small><strong>{summary.dns_blocked || 0}</strong></div>
                        <div className="card"><small>Eventos IPS</small><strong>{summary.ips_events || 0}</strong></div>
                        <div className="card"><small>Cuarentenas</small><strong>{summary.quarantines || 0}</strong></div>
                        <div className="card"><small>Cambios de IP</small><strong>{summary.ip_changes || 0}</strong></div>
                    </div>

                    {data.events.length === 0 ? (
                        <p style={{ color: "var(--muted)", fontSize: 13 }}>
                            Sin eventos en el período seleccionado.
                        </p>
                    ) : (
                        <table>
                            <thead>
                                <tr>
                                    <th>Hora</th>
                                    <th>Tipo</th>
                                    <th>Evento</th>
                                    <th>Detalle</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.events.map((event) => (
                                    <tr key={event.id}>
                                        <td>{formatDateTime(event.timestamp, "-")}</td>
                                        <td>{event.source} · {severityLabel(event.severity)}</td>
                                        <td>{event.title}</td>
                                        <td style={{ color: "var(--muted)", fontSize: 13 }}>{event.detail}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </>
            )}

        </div>
    );
}


export default DeviceTimeline;
