import { useState } from "react";

import { Link } from "react-router-dom";

import { useNetworkSegment } from "../../../network/useNetworkSegment";

import DhcpSummaryPanel from "./DhcpSummaryPanel";
import DhcpConnectedIpsPanel from "./DhcpConnectedIpsPanel";
import DhcpDiagnosticsPanel from "./DhcpDiagnosticsPanel";
import LanSegmentPanel from "./LanSegmentPanel";
import DhcpAlertPanel from "./DhcpAlertPanel";
import DhcpCleanupPanel from "./DhcpCleanupPanel";
import DhcpLogPanel from "./DhcpLogPanel";

import "../Interfaces/interfaces.css";
import "./dhcp.css";


const TABS = [
    { id: "resumen", label: "Resumen" },
    { id: "ips", label: "IPs y leases" },
    { id: "segment", label: "Segmento y pool" },
    { id: "alertas", label: "Ajustes DHCP" },
    { id: "registro", label: "Registro" }
];


function Dhcp() {

    const [tab, setTab] = useState("resumen");

    const [configTab, setConfigTab] = useState("ajustes");

    const {
        lanCards,
        selectedLan,
        selectedZones,
    } = useNetworkSegment();

    const lanLabel = selectedLan
        ? (selectedLan.display_name
            || selectedLan.current_name
            || selectedLan.last_seen_name
            || "LAN")
        : null;

    return (

        <div className="interfaces-page dhcp-page">

            <header className="interfaces-header">
                <h2>DHCP</h2>
                <p>
                    Estado del servidor, asignación de IPs, capacidad del pool,
                    alertas y limpieza. Las opciones de configuración están
                    agrupadas por tema para evitar pantallas sobrecargadas.
                </p>

                {
                    lanCards.length > 1 && lanLabel && (
                        <div className="dhcp-context">
                            Contexto: <strong>{lanLabel}</strong>
                            {
                                selectedZones.length > 0
                                    ? (
                                        selectedZones.map((zone) => (
                                            <span key={zone.id}>
                                                {" · "}{zone.name}{" "}
                                                ({zone.network_cidr})
                                            </span>
                                        ))
                                    )
                                    : null
                            }
                        </div>
                    )
                }

                {
                    lanCards.length > 1 && selectedZones.length === 0 && (
                        <div className="dhcp-segment-banner warn">
                            Esta tarjeta LAN aún no tiene zona. Creá una en{" "}
                            <Link
                                to={
                                    `/network/zones?mac=${encodeURIComponent(selectedLan?.mac_address || "")}`
                                    + `&iface=${encodeURIComponent(selectedLan?.current_name || selectedLan?.last_seen_name || "")}`
                                }
                            >
                                Zonas
                            </Link>
                            {" "}con el CIDR y el pool DHCP de ese segmento.
                        </div>
                    )
                }
            </header>

            <div className="dhcp-tabs" role="tablist">

                {
                    TABS.map(item => (
                        <button
                            key={item.id}
                            type="button"
                            role="tab"
                            aria-selected={tab === item.id}
                            className={`dhcp-tab ${tab === item.id ? "active" : ""}`}
                            onClick={() => setTab(item.id)}
                        >
                            {item.label}
                        </button>
                    ))
                }

            </div>

            <div className="dhcp-tab-body">

                {
                    tab === "resumen" && <DhcpSummaryPanel />
                }

                {
                    tab === "ips" && (
                        <>
                            <DhcpConnectedIpsPanel />
                            <DhcpDiagnosticsPanel />
                        </>
                    )
                }

                {
                    tab === "segment" && <LanSegmentPanel />
                }

                {
                    tab === "alertas" && (
                        <>
                            <div className="dhcp-subtabs dhcp-page-subtabs" role="tablist">
                                <button
                                    type="button"
                                    role="tab"
                                    aria-selected={configTab === "ajustes"}
                                    className={`dhcp-subtab ${configTab === "ajustes" ? "active" : ""}`}
                                    onClick={() => setConfigTab("ajustes")}
                                >
                                    Alertas y rendimiento
                                </button>
                                <button
                                    type="button"
                                    role="tab"
                                    aria-selected={configTab === "limpieza"}
                                    className={`dhcp-subtab ${configTab === "limpieza" ? "active" : ""}`}
                                    onClick={() => setConfigTab("limpieza")}
                                >
                                    Limpieza de reservas
                                </button>
                            </div>

                            {
                                configTab === "ajustes"
                                    ? <DhcpAlertPanel />
                                    : <DhcpCleanupPanel />
                            }
                        </>
                    )
                }

                {
                    tab === "registro" && <DhcpLogPanel />
                }

            </div>

        </div>

    );
}

export default Dhcp;