import { useEffect, useState } from "react";

import { getDhcpDiagnostics, scanRogueDhcp } from "../../../services/api";

export default function DhcpDiagnosticsPanel() {
    const [data, setData] = useState(null);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [rogue, setRogue] = useState(null);
    const [rogueBusy, setRogueBusy] = useState(false);

    async function load() {
        setLoading(true);
        try {
            setData(await getDhcpDiagnostics());
            setError("");
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo leer el diagnóstico.");
        } finally {
            setLoading(false);
        }
    }

    async function handleRogueScan() {
        setRogueBusy(true);
        try {
            setRogue(await scanRogueDhcp());
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo escanear DHCP.");
        } finally {
            setRogueBusy(false);
        }
    }

    useEffect(() => {
        load();
        const timer = setInterval(load, 60000);
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="registry-panel dhcp-diagnostics-panel">
            <div className="registry-panel-head">
                <div>
                    <h3>Diagnóstico rápido</h3>
                    <p className="registry-hint">
                        Solo lectura: no modifica DHCP, pool ni configuración. Se actualiza cada 60 s.
                    </p>
                </div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button type="button" className="secondary-button" onClick={handleRogueScan} disabled={rogueBusy}>
                        {rogueBusy ? "Escaneando DHCP…" : "Escanear DHCP no autorizado"}
                    </button>
                    <button type="button" className="secondary-button" onClick={load} disabled={loading}>
                        {loading ? "Analizando…" : "Actualizar"}
                    </button>
                </div>
            </div>

            {error && <p className="registry-message error">{error}</p>}

            {rogue && (
                <p className={rogue.unexpected?.length ? "registry-message error" : "registry-message ok"}>
                    {rogue.unexpected?.length
                        ? `DHCP no autorizado: ${rogue.unexpected.map((x) => x.server_id).join(", ")}`
                        : "No se detectaron servidores DHCP no autorizados."}
                </p>
            )}

            {data && (
                <>
                    <div className="lan-stat-row">
                        <span className="lan-stat">
                            <span>DNSMasq</span>
                            <strong className={data.health?.healthy ? "" : "err-text"}>
                                {data.health?.running ? (data.health?.healthy ? "OK" : "COLGADO") : "CAÍDO"}
                            </strong>
                        </span>
                        <span className="lan-stat"><span>NAK en log</span><strong className={data.log_tail?.naks ? "err-text" : ""}>{data.log_tail?.naks ?? 0}</strong></span>
                        <span className="lan-stat"><span>Sin direcciones</span><strong className={data.log_tail?.no_address ? "err-text" : ""}>{data.log_tail?.no_address ?? 0}</strong></span>
                        <span className="lan-stat"><span>Exclusiones activas</span><strong>{data.auto_exclusions?.active?.length ?? 0}</strong></span>
                        <span className="lan-stat"><span>Exclusiones vencidas</span><strong>{data.auto_exclusions?.expired?.length ?? 0}</strong></span>
                        <span className="lan-stat"><span>Leases sin ARP</span><strong className={data.inactive_leases?.length ? "warning-text" : ""}>{data.inactive_leases?.length ?? 0}</strong></span>
                    </div>

                    {(data.duplicates?.length > 0 || data.zones_overlap?.length > 0 || data.inactive_leases?.length > 0) && (
                        <div className="dhcp-diagnostic-alerts">
                            {data.zones_overlap?.length > 0 && (
                                <p className="registry-message warning">
                                    Zona por defecto solapada con el pool principal:{" "}
                                    {data.zones_overlap.map((z) => `${z.zone} (${z.zone_pool})`).join(", ")}
                                </p>
                            )}
                            {data.duplicates?.length > 0 && (
                                <p className="registry-message warning">
                                    IPs duplicadas en la base:{" "}
                                    {data.duplicates.map((d) => `${d.ip} ×${d.count}`).join(", ")}
                                </p>
                            )}
                            {data.inactive_leases?.length > 0 && (
                                <p className="registry-message warning">
                                    {data.inactive_leases.length} lease(s) sin ARP. Si el pool baja del umbral,
                                    STEPAD libera los de equipos sin actividad reciente.
                                </p>
                            )}
                        </div>
                    )}

                    <div className="dhcp-table-wrap">
                        <table className="dhcp-ip-table">
                            <thead>
                                <tr>
                                    <th>Exclusión automática</th>
                                    <th>Vence</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                {[...(data.auto_exclusions?.active || []), ...(data.auto_exclusions?.expired || [])].map((item, index) => (
                                    <tr key={`${item.ip}-${index}`}>
                                        <td><code>{item.ip}</code></td>
                                        <td>{item.until ? new Date(item.until).toLocaleString() : "—"}</td>
                                        <td>{item.until && new Date(item.until) > new Date() ? "Activa" : "Vencida"}</td>
                                    </tr>
                                ))}
                                {(!data.auto_exclusions?.active?.length && !data.auto_exclusions?.expired?.length) && (
                                    <tr><td colSpan={3}>Sin exclusiones automáticas.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </>
            )}
        </div>
    );
}
