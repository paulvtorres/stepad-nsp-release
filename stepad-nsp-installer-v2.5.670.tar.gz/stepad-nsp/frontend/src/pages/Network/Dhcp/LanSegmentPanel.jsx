import { useEffect, useMemo, useState } from "react";

import {
    getDhcpConfig,
    setLanSegment,
    getTemporaryLanIpStatus,
    startTemporaryLanIp,
    revertTemporaryLanIp,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function netmaskToPrefix(mask) {
    // Convierte "255.255.255.0" -> 24 (o devuelve el valor si no es máscara).
    try {
        const parts = String(mask || "").split(".");
        if (parts.length !== 4) { return mask; }
        let ones = 0;
        for (const p of parts) {
            const v = Number(p);
            if (Number.isNaN(v) || v < 0 || v > 255) { return mask; }
            for (let b = 0; b < 8; b += 1) {
                if ((v >> b) & 1) { ones += 1; }
            }
        }
        return ones;
    } catch {
        return mask;
    }
}


function cidrGateway(cidr) {
    // Devuelve la IP del primer host (.1) de un CIDR "a.b.c.d/prefix".
    try {
        const idx = String(cidr).indexOf("/");
        const ip = (idx >= 0 ? String(cidr).slice(0, idx) : String(cidr)).trim();
        let prefix = idx >= 0 ? String(cidr).slice(idx + 1).trim() : "";
        const parts = ip.split(".").map(Number);
        if (parts.length !== 4 || parts.some((p) => Number.isNaN(p) || p < 0 || p > 255)) {
            return null;
        }
        if (prefix !== "" && Number.isNaN(Number(prefix))) {
            // Permitir máscara completa también.
            const pfx = netmaskToPrefix(prefix);
            if (typeof pfx !== "number") { return null; }
            prefix = pfx;
        }
        const addr = ((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0;
        const p = prefix === "" ? 24 : Number(prefix);
        if (p < 1 || p > 32) { return null; }
        const mask = p === 32 ? 0xFFFFFFFF : (~((1 << (32 - p)) - 1)) >>> 0;
        const net = (addr & mask) >>> 0;
        const gw = (net + 1) >>> 0;
        return [(gw >>> 24) & 255, (gw >>> 16) & 255, (gw >>> 8) & 255, gw & 255].join(".");
    } catch {
        return null;
    }
}


function ipToInt(value) {
    const parts = String(value || "").trim().split(".").map(Number);
    if (parts.length !== 4 || parts.some((part) => Number.isNaN(part) || part < 0 || part > 255)) {
        return null;
    }
    return (((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3]) >>> 0;
}


function rangeCount(start, end) {
    const first = ipToInt(start);
    const last = ipToInt(end);
    if (first === null || last === null || last < first) { return 0; }
    return last - first + 1;
}


function cidrPrefix(cidr) {
    try {
        const idx = String(cidr).indexOf("/");
        const p = idx >= 0 ? String(cidr).slice(idx + 1).trim() : "";
        const n = p === "" ? 24 : Number(p);
        if (Number.isNaN(n) || n < 1 || n > 32) {
            const m = netmaskToPrefix(p);
            return typeof m === "number" ? m : null;
        }
        return n;
    } catch {
        return null;
    }
}


function LanSegmentPanel() {

    const [config, setConfig] = useState(null);

    const [network, setNetwork] = useState("");

    const [groupIpStart, setGroupIpStart] = useState("");

    const [groupIpEnd, setGroupIpEnd] = useState("");

    const [poolStart, setPoolStart] = useState("");

    const [poolEnd, setPoolEnd] = useState("");

    const [leaseTime, setLeaseTime] = useState("8h");

    const [exclusions, setExclusions] = useState("");

    const [busy, setBusy] = useState(false);

    const [section, setSection] = useState("reparto");

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");

    const [loading, setLoading] = useState(true);


    const gatewayPreview = useMemo(() => cidrGateway(network), [network]);

    const cidrOk = gatewayPreview !== null;


    const [tempStatus, setTempStatus] = useState(null);

    const [tempBusy, setTempBusy] = useState(false);


    async function load() {

        try {

            const data = await getDhcpConfig();

            setConfig(data);

            if (data) {

                setNetwork(`${data.network}/${netmaskToPrefix(data.netmask)}`);
                setGroupIpStart(data.group_ip_start || "");
                setGroupIpEnd(data.group_ip_end || "");
                setPoolStart(data.pool_start);
                setPoolEnd(data.pool_end);
                setLeaseTime(data.lease_time || "8h");
                setExclusions((data.excluded_ips || []).join(", "));

            }
            else {

                // Sin LAN primaria configurada: el backend devuelve null.
                // Se muestra un estado vacío claro, nunca un error de lectura.
                setNetwork("");
                setGroupIpStart("");
                setGroupIpEnd("");
                setPoolStart("");
                setPoolEnd("");
                setLeaseTime("8h");
                setExclusions("");

            }

        } catch {

            setError("No se pudo leer la configuración DHCP.");

        }
        finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        load();

        loadTempStatus();

    }, []);


    function parseExclusions() {

        return exclusions
            .split(",")
            .map((x) => x.trim())
            .filter(Boolean);

    }

    const networkPending = Boolean(config && gatewayPreview && gatewayPreview !== config.gateway);

    const excludedCount = parseExclusions().length;


    function groupIpCount() {
        if (!groupIpStart || !groupIpEnd) {
            return 0;
        }
        return rangeCount(groupIpStart, groupIpEnd);
    }


    async function handleChangeSegment() {

        // Cambio de segmento SOLO por red: el backend reubica el grupo y el
        // pool automáticamente y deja el NSP en la IP .1 del nuevo segmento.
        const cidr = String(network || "").trim();
        const gw = cidrGateway(cidr);
        if (gw === null) {
            setError("CIDR inválido. Usá el formato red/prefijo, ej. 192.168.10.0/24");
            return;
        }
        if (!window.confirm(
            `¿Cambiar el segmento LAN a ${cidr}?\n\n`
            + `La IP del NSP (gateway) quedará en ${gw} (la .1 del segmento).\n`
            + "Los reservas de grupos y el pool DHCP se recalculan solos.\n"
            + "La conexión LAN puede cortarse un instante mientras se "
            + "reconfigura la interfaz."
        )) {
            return;
        }
        setBusy(true);
        setMessage("");
        setError("");
        try {
            const result = await setLanSegment({ network: cidr });
            if (result?.success === false) {
                setError(result.message || "No se pudo cambiar el segmento.");
            } else {
                setMessage(`Segmento cambiado. El NSP quedó en ${gw} (.1).`);
            }
            await load();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudo cambiar el segmento."
            );
        } finally {
            setBusy(false);
        }
    }


    async function loadTempStatus() {

        try {

            const st = await getTemporaryLanIpStatus();

            setTempStatus(st && st.active ? st : null);

        } catch {

            setTempStatus(null);

        }

    }


    async function handleTestSegment() {

        const cidr = String(network || "").trim();
        const gw = cidrGateway(cidr);
        const pfx = cidrPrefix(cidr);
        if (gw === null || pfx === null) {
            setError("CIDR inválido: usá red/prefijo (ej. 192.168.10.0/24)");
            return;
        }
        if (!window.confirm(
            `¿Probar la IP temporal ${gw}/${pfx}?\n\n`
            + "Tu conexión actual a la UI se cortará. Entrá a "
            + `https://${gw}:8443 para validar. Si no confirmás, se revierte `
            + "solo en pocos minutos."
        )) {
            return;
        }
        setTempBusy(true);
        setError("");
        setMessage("");
        try {
            const res = await startTemporaryLanIp({
                temporary_ip: gw,
                temporary_prefix: pfx,
                duration_minutes: 10,
            });
            if (res?.success === false) {
                setError(res.message || "No se pudo probar la IP temporal.");
            }
            await loadTempStatus();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.message
                || "No se pudo probar la IP temporal."
            );
        } finally {
            setTempBusy(false);
        }
    }


    async function handleConfirmPermanent() {

        const cidr = String(network || "").trim();
        const gw = cidrGateway(cidr);
        if (!window.confirm(
            `¿Confirmar el cambio permanente a ${cidr}?\n\n`
            + `El NSP quedará en ${gw} (.1). Conectate ahora a `
            + `https://${gw}:8443.`
        )) {
            return;
        }
        setTempBusy(true);
        setError("");
        setMessage("");
        try {
            const res = await setLanSegment({ network: cidr });
            if (res?.success === false) {
                setError(res.message || "No se pudo confirmar el segmento.");
            } else {
                await revertTemporaryLanIp().catch(() => {});
                await load();
            }
            await loadTempStatus();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.message
                || "No se pudo confirmar el segmento."
            );
        } finally {
            setTempBusy(false);
        }
    }


    async function handleRevertTemporary() {

        setTempBusy(true);
        setError("");
        setMessage("");
        try {
            await revertTemporaryLanIp();
            await loadTempStatus();
        } catch (e) {
            setError(
                e?.response?.data?.detail
                || e?.message
                || "No se pudo revertir la IP temporal."
            );
        } finally {
            setTempBusy(false);
        }
    }


    async function handleApplySegment() {

        if (networkPending) {
            setError("El CIDR cambió. Aplicá primero el cambio de red en la pestaña “Red del segmento”.");
            setSection("red");
            return;
        }

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setLanSegment({
                network,
                pool_start: poolStart,
                pool_end: poolEnd,
                lease_time: leaseTime,
                excluded_ips: parseExclusions(),
                group_ip_start: groupIpStart || undefined,
                group_ip_end: groupIpEnd || undefined,
            });

            if (result?.success === false) {
                setError(result.message || "No se pudo aplicar el segmento.");
            } else {
                setMessage(result?.message || "Segmento aplicado.");
            }

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudo aplicar el segmento."
            );

        } finally {

            setBusy(false);

        }

    }




    return (

        <div className="registry-panel lan-segment-panel">

            <div className="registry-panel-head">

                <div>

                    <h3>Segmento LAN y DHCP</h3>

                    <p className="registry-hint">
                        Tres zonas: gateway del NSP, IPs reservadas para grupos
                        y pool DHCP de equipos. Las IPs de grupos no se entregan
                        por DHCP.
                    </p>

                </div>

                {
                    config && (
                        <span className="segment-status-pill">
                            Configurado
                        </span>
                    )
                }

            </div>

            {
                loading ? (
                    <p className="registry-hint">Cargando configuración...</p>
                ) : config ? (
                    <WriteGuard>

                        <div className="segment-hero">

                            <div className="segment-hero-main">

                                <span className="segment-eyebrow">
                                    SEGMENTO ACTUAL
                                </span>

                                <strong className="segment-cidr">
                                    {config.network}/{netmaskToPrefix(config.netmask)}
                                </strong>

                                <span className="segment-hero-sub">
                                    Máscara {config.netmask} · Gateway {config.gateway}
                                    {" · "}NSP {config.gateway}
                                </span>

                            </div>

                            <div className="segment-hero-side">

                                <span>Lease DHCP</span>

                                <strong>{config.lease_time || "—"}</strong>

                            </div>

                        </div>

                        <div className="segment-zone-grid">

                            <div className="segment-zone gateway">

                                <span className="segment-zone-kicker">GATEWAY</span>

                                <strong>{config.gateway}</strong>

                                <small>IP fija .1 del segmento</small>

                            </div>

                            <div className="segment-zone groups">

                                <span className="segment-zone-kicker">IPs DE GRUPOS</span>

                                <strong>
                                    {config.group_ip_start && config.group_ip_end
                                        ? `${config.group_ip_start}–${config.group_ip_end}`
                                        : "Sin reserva"}
                                </strong>

                                <small>
                                    {config.group_ip_count
                                        ? `${config.group_ip_count} direcciones para DNS/filtrado`
                                        : "El NSP no podrá crear más grupos"}
                                </small>

                            </div>

                            <div className="segment-zone pool">

                                <span className="segment-zone-kicker">POOL DE EQUIPOS</span>

                                <strong>{config.pool_start}–{config.pool_end}</strong>

                                <small>
                                    {rangeCount(config.pool_start, config.pool_end)} direcciones para clientes
                                </small>

                            </div>

                        </div>

                        <div className="segment-tabs" role="tablist">

                            <button
                                type="button"
                                role="tab"
                                aria-selected={section === "red"}
                                className={`segment-tab ${section === "red" ? "active" : ""}`}
                                onClick={() => setSection("red")}
                            >
                                Red del segmento
                            </button>

                            <button
                                type="button"
                                role="tab"
                                aria-selected={section === "reparto"}
                                className={`segment-tab ${section === "reparto" ? "active" : ""}`}
                                onClick={() => setSection("reparto")}
                            >
                                Grupos y pool
                            </button>

                            <button
                                type="button"
                                role="tab"
                                aria-selected={section === "excepciones"}
                                className={`segment-tab ${section === "excepciones" ? "active" : ""}`}
                                onClick={() => setSection("excepciones")}
                            >
                                Excepciones
                                {excludedCount > 0 ? ` (${excludedCount})` : ""}
                            </button>

                        </div>

                        {section === "red" && (

                            <div className="segment-form-card">

                                <div className="segment-form-heading">

                                    <div>

                                        <h4>Red del segmento</h4>

                                        <p>
                                            Cambiar la red mueve el NSP a la .1 del
                                            nuevo segmento y recalcula grupos y pool.
                                        </p>

                                    </div>

                                    {
                                        networkPending && (
                                            <span className="segment-hero-badge">
                                                Cambio pendiente
                                            </span>
                                        )
                                    }

                                </div>

                                <div className="segment-field-grid single">

                                    <label className="segment-field">
                                        Nueva red (CIDR)
                                        <input
                                            type="text"
                                            placeholder="ej. 192.168.10.0/24"
                                            value={network}
                                            onChange={(e) => setNetwork(e.target.value)}
                                        />
                                        <span className="segment-field-hint">
                                            Formato: red/prefijo, por ejemplo 192.168.10.0/24
                                        </span>
                                    </label>

                                </div>

                                {
                                    cidrOk ? (
                                        <div className="segment-callout">
                                            <span>IP del NSP en este segmento</span>
                                            <strong>{gatewayPreview}</strong>
                                            <small>Siempre la .1 del segmento</small>
                                        </div>
                                    ) : (
                                        <div className="segment-callout error">
                                            <strong>CIDR inválido</strong>
                                            <span>Usá red/prefijo, por ejemplo 192.168.10.0/24</span>
                                        </div>
                                    )
                                }

                                {
                                    tempStatus ? (
                                        <div className="segment-temp-box">

                                            <div>
                                                <strong>IP temporal activa: {tempStatus.temporary_ip || "—"}</strong>
                                                <p>
                                                    {
                                                        tempStatus.expires_at
                                                            ? `Revierte automáticamente a las ${new Date(tempStatus.expires_at).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}.`
                                                            : "La prueba se revierte automáticamente."
                                                    }
                                                    {" "}Entrá a https://{tempStatus.temporary_ip || gatewayPreview}:8443 para validar.
                                                </p>
                                            </div>

                                            <div className="segment-actions-bar">

                                                <button
                                                    type="button"
                                                    className="primary-button"
                                                    disabled={tempBusy}
                                                    onClick={handleConfirmPermanent}
                                                >
                                                    Confirmar y hacer permanente
                                                </button>

                                                <button
                                                    type="button"
                                                    className="secondary-button"
                                                    disabled={tempBusy}
                                                    onClick={handleRevertTemporary}
                                                >
                                                    Descartar prueba
                                                </button>

                                            </div>

                                        </div>
                                    ) : (
                                        <div className="segment-actions-bar">

                                            <button
                                                type="button"
                                                className="primary-button"
                                                disabled={busy || tempBusy || !cidrOk}
                                                onClick={handleChangeSegment}
                                            >
                                                Cambiar segmento permanente
                                            </button>

                                            <button
                                                type="button"
                                                className="secondary-button"
                                                disabled={busy || tempBusy || !cidrOk}
                                                onClick={handleTestSegment}
                                            >
                                                Probar antes con IP temporal
                                            </button>

                                        </div>
                                    )
                                }

                                <p className="segment-danger-note">
                                    Cambiar el segmento puede cortar la conexión LAN
                                    por unos segundos. La prueba temporal es la opción
                                    recomendada antes de hacerlo permanente.
                                </p>

                            </div>

                        )}

                        {section === "reparto" && (

                            <div className="segment-form-card">

                                <div className="segment-form-heading">

                                    <div>

                                        <h4>Distribución de direcciones</h4>

                                        <p>
                                            Separá un rango para los DNS de grupos y
                                            dejá el resto del pool para equipos.
                                        </p>

                                    </div>

                                </div>

                                <div className="segment-range-block groups">

                                    <div className="segment-range-head">

                                        <span>1. Reserva para grupos (DNS/filtrado)</span>

                                        <strong>{groupIpCount() || "0"} IPs</strong>

                                    </div>

                                    <p>
                                        Una IP por grupo. Si el rango se agota, el NSP
                                        no podrá crear más grupos.
                                    </p>

                                    <div className="segment-field-grid">

                                        <label className="segment-field">
                                            Primera IP
                                            <input
                                                type="text"
                                                placeholder="ej. 192.168.1.10"
                                                value={groupIpStart}
                                                onChange={(e) => setGroupIpStart(e.target.value)}
                                            />
                                        </label>

                                        <label className="segment-field">
                                            Última IP
                                            <input
                                                type="text"
                                                placeholder="ej. 192.168.1.19"
                                                value={groupIpEnd}
                                                onChange={(e) => setGroupIpEnd(e.target.value)}
                                            />
                                        </label>

                                    </div>

                                </div>

                                <div className="segment-range-block pool">

                                    <div className="segment-range-head">

                                        <span>2. Pool DHCP de equipos</span>

                                        <strong>{rangeCount(poolStart, poolEnd)} IPs</strong>

                                    </div>

                                    <p>
                                        Direcciones que el NSP entrega automáticamente
                                        a PCs, impresoras y otros equipos.
                                    </p>

                                    <div className="segment-field-grid">

                                        <label className="segment-field">
                                            Primera IP
                                            <input
                                                type="text"
                                                placeholder="ej. 192.168.1.20"
                                                value={poolStart}
                                                onChange={(e) => setPoolStart(e.target.value)}
                                            />
                                        </label>

                                        <label className="segment-field">
                                            Última IP
                                            <input
                                                type="text"
                                                placeholder="ej. 192.168.1.119"
                                                value={poolEnd}
                                                onChange={(e) => setPoolEnd(e.target.value)}
                                            />
                                        </label>

                                    </div>

                                </div>

                                <div className="segment-range-block lease">

                                    <div className="segment-range-head">

                                        <span>3. Tiempo de lease</span>

                                        <strong>{leaseTime}</strong>

                                    </div>

                                    <p>
                                        Se aplica a las próximas renovaciones de los equipos.
                                    </p>

                                    <div className="segment-field-grid">

                                        <label className="segment-field">
                                            Duración
                                            <select
                                                value={leaseTime}
                                                onChange={(e) => setLeaseTime(e.target.value)}
                                            >
                                                <option value="2h">2 horas</option>
                                                <option value="4h">4 horas</option>
                                                <option value="6h">6 horas</option>
                                                <option value="8h">8 horas</option>
                                                <option value="12h">12 horas</option>
                                                <option value="24h">24 horas</option>
                                            </select>
                                        </label>

                                    </div>

                                </div>

                                <div className="segment-callout">
                                    <span>Las reservas de grupos no se entregan por DHCP</span>
                                    <small>
                                        Verificá que el pool empiece después de la última
                                        IP reservada para grupos.
                                    </small>
                                </div>

                            </div>

                        )}

                        {section === "excepciones" && (

                            <div className="segment-form-card">

                                <div className="segment-form-heading">

                                    <div>

                                        <h4>Excepciones del pool</h4>

                                        <p>
                                            IPs o rangos que el DHCP nunca debe entregar.
                                        </p>

                                    </div>

                                </div>

                                <label className="segment-field segment-field-full">
                                    IPs excluidas
                                    <input
                                        type="text"
                                        placeholder="ej. 192.168.1.87, 192.168.1.100-192.168.1.105"
                                        value={exclusions}
                                        onChange={(e) => setExclusions(e.target.value)}
                                    />
                                    <span className="segment-field-hint">
                                        Separá cada IP o rango con coma.
                                        {" "}Actualmente hay {excludedCount} excepción(es).
                                    </span>
                                </label>

                                <div className="segment-callout">
                                    <span>Las IPs fijas también deben quedar fuera del pool</span>
                                    <small>
                                        Por ejemplo, impresoras o servidores con IP
                                        configurada manualmente.
                                    </small>
                                </div>

                            </div>

                        )}

                        {(section === "reparto" || section === "excepciones") && (

                            <div className="segment-save-bar">

                                <span>
                                    Los cambios se aplican al guardar y afectan
                                    las próximas asignaciones DHCP.
                                </span>

                                <button
                                    type="button"
                                    className={`primary-button${busy ? " btn-busy" : ""}`}
                                    onClick={handleApplySegment}
                                    disabled={busy}
                                >
                                    Guardar cambios
                                </button>

                            </div>

                        )}

                    </WriteGuard>
                ) : (
                    <div className="dhcp-empty">
                        Todavía no hay un segmento de DHCP configurado en esta
                        máquina. Asigná la tarjeta LAN y su zona (en{" "}
                        <a href="/network/zones">Zonas</a> / Interfaces) para
                        que el DHCP tenga segmento, pool y reservas.
                    </div>
                )
            }

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}

export default LanSegmentPanel;
