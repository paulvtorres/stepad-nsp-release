import { useEffect, useState } from "react";

import {
    getDhcpCleanupSettings,
    saveDhcpCleanupSettings,
    runDhcpCleanup,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function DhcpCleanupPanel() {

    const [enabled, setEnabled] = useState(false);

    const [days, setDays] = useState(14);

    const [runTime, setRunTime] = useState("03:00");

    const [protectInfrastructure, setProtectInfrastructure] = useState(true);

    const [pending, setPending] = useState([]);

    const [pendingCount, setPendingCount] = useState(0);

    const [lastRunAt, setLastRunAt] = useState(null);

    const [lastDeleted, setLastDeleted] = useState(0);

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpCleanupSettings();

            setEnabled(Boolean(data.enabled));
            setDays(Number(data.days) || 14);
            setRunTime(data.run_time || "03:00");
            setProtectInfrastructure(
                data.protect_infrastructure !== false
            );
            setPending(data.pending || []);
            setPendingCount(data.pending_count || 0);
            setLastRunAt(data.last_run_at || null);
            setLastDeleted(data.last_deleted || 0);

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo leer la programación de limpieza."
            );

        }

    }


    useEffect(() => {

        load();

    }, []);


    async function handleSave() {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await saveDhcpCleanupSettings({
                enabled,
                days: Number(days),
                run_time: runTime,
                protect_infrastructure: protectInfrastructure,
            });

            setPending(data.pending || []);
            setPendingCount(data.pending_count || 0);
            setRunTime(data.run_time || runTime);
            setMessage(
                data.message
                || `Programación guardada (diaria a las ${data.run_time}).`
            );

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo guardar."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handlePreview() {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await runDhcpCleanup({
                dry_run: true,
                days: Number(days),
                protect_infrastructure: protectInfrastructure,
            });

            setPending(data.candidates || []);
            setPendingCount(data.count || 0);
            setMessage(
                data.count
                    ? `${data.count} equipo(s) se eliminarían ahora.`
                    : "No hay equipos que cumplan el criterio."
            );

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo previsualizar."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleRunNow() {

        if (!window.confirm(
            `¿Eliminar ahora las reservas de equipos sin conexión `
            + `más de ${days} días?\n\n`
            + "Se borran del listado de dispositivos y se liberan "
            + "sus IPs en DHCP. Los logs de navegación se conservan."
        )) {
            return;
        }

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await runDhcpCleanup({
                dry_run: false,
                days: Number(days),
                protect_infrastructure: protectInfrastructure,
            });

            setMessage(
                data.message
                || `Eliminados: ${data.deleted || 0}`
            );
            setLastDeleted(data.deleted || 0);
            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo ejecutar la limpieza."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel dhcp-cleanup-panel">

            <div className="registry-panel-head">

                <div>

                    <h3>Limpieza de reservas</h3>

                    <p className="registry-hint">
                        Elimina reservas de equipos que llevan muchos días sin
                        conectarse. Si el equipo vuelve, se registra de nuevo.
                    </p>

                </div>

                <span className={`dhcp-health-pill ${enabled ? "ok" : "warn"}`}>
                    {enabled ? "Programada" : "Desactivada"}
                </span>

            </div>

            <div className="dhcp-summary-grid">

                <div className={`dhcp-summary-card ${enabled ? "on" : "off"}`}>
                    <span>Programación</span>
                    <strong>{enabled ? `Diario ${runTime}` : "Desactivada"}</strong>
                    <small>Hora del servidor (Ecuador)</small>
                </div>

                <div className="dhcp-summary-card">
                    <span>Pendientes ahora</span>
                    <strong>{pendingCount}</strong>
                    <small>Con el criterio actual</small>
                </div>

                <div className="dhcp-summary-card">
                    <span>Última ejecución</span>
                    <strong>{lastRunAt || "—"}</strong>
                    <small>Automática o manual</small>
                </div>

                <div className="dhcp-summary-card">
                    <span>Últimos borrados</span>
                    <strong>{lastDeleted}</strong>
                    <small>Reservas eliminadas</small>
                </div>

            </div>

            <WriteGuard>

                <div className="dhcp-config-card">

                    <div className="dhcp-config-heading">

                        <h4>Regla de limpieza</h4>

                        <p>
                            Solo se eliminan equipos sin conexión y sin reserva
                            de infraestructura.
                        </p>

                    </div>

                    <label className="dhcp-toggle-card">
                        <input
                            type="checkbox"
                            checked={enabled}
                            onChange={(e) => setEnabled(e.target.checked)}
                        />
                        <span>
                            <strong>Activar limpieza automática diaria</strong>
                            <small>Se ejecuta a la hora configurada.</small>
                        </span>
                    </label>

                    <div className="segment-field-grid">

                        <label className="segment-field">
                            Días sin conexión
                            <input
                                type="number"
                                min={3}
                                max={180}
                                value={days}
                                onChange={(e) => setDays(e.target.value)}
                            />
                            <span className="segment-field-hint">
                                Debe estar desconectado al menos este tiempo.
                            </span>
                        </label>

                        <label className="segment-field">
                            Hora diaria
                            <input
                                type="time"
                                value={runTime}
                                onChange={(e) => setRunTime(e.target.value)}
                            />
                        </label>

                    </div>

                    <label className="dhcp-toggle-card">
                        <input
                            type="checkbox"
                            checked={protectInfrastructure}
                            onChange={(e) => setProtectInfrastructure(e.target.checked)}
                        />
                        <span>
                            <strong>Proteger impresoras, routers y teléfonos IP</strong>
                            <small>No se eliminan aunque estén desconectados.</small>
                        </span>
                    </label>

                    <div className="dhcp-info-box warn">
                        <strong>Antes de ejecutar</strong>
                        <span>
                            Usá «Ver candidatos» para revisar qué equipos se
                            eliminarían. «Ejecutar ahora» aplica la limpieza
                            inmediatamente y no se puede deshacer.
                        </span>
                    </div>

                </div>

            </WriteGuard>

            <div className="dhcp-config-actions">

                <span className="registry-hint">
                    Guardá la programación antes de salir. Ver candidatos no
                    elimina nada.
                </span>

                <div className="confirm-actions">

                    <button
                        className={`primary-button${busy ? " btn-busy" : ""}`}
                        onClick={handleSave}
                        disabled={busy}
                    >
                        Guardar programación
                    </button>

                    <button
                        className={`secondary-button${busy ? " btn-busy" : ""}`}
                        onClick={handlePreview}
                        disabled={busy}
                    >
                        Ver candidatos
                    </button>

                    <button
                        className={`secondary-button${busy ? " btn-busy" : ""}`}
                        onClick={handleRunNow}
                        disabled={busy}
                    >
                        Ejecutar ahora
                    </button>

                </div>

            </div>

            {pending.length > 0 && (

                <div className="dhcp-candidates">

                    <p className="registry-section-label">
                        Candidatos (máx. 50 mostrados)
                    </p>

                    <ul>
                        {pending.map((row) => (
                            <li key={row.id}>
                                <strong>
                                    {row.hostname || "(sin nombre)"}
                                </strong>
                                {" · "}
                                {row.ip_address}
                                {" · "}
                                {row.mac_address}
                                {" · "}
                                {row.device_type}
                                {" · visto "}
                                {row.last_seen || "—"}
                            </li>
                        ))}
                    </ul>

                </div>

            )}

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpCleanupPanel;
