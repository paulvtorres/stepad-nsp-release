import { useEffect, useState } from "react";

import { getDhcpConnectedIps } from "../../../services/api";

function leaseLabel(value) {
    if (value === "infinite") return "∞";
    if (!value) return "—";
    return new Date(Number(value) * 1000).toLocaleTimeString();
}

export default function DhcpConnectedIpsPanel() {
    const [data, setData] = useState(null);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    async function load() {
        setLoading(true);
        try {
            setData(await getDhcpConnectedIps());
            setError("");
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo leer el listado.");
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        load();
        const timer = setInterval(load, 20000);
        return () => clearInterval(timer);
    }, []);

    function download(format) {
        if (!data) return;
        const rows = data.rows || [];
        let blob;
        let name;
        if (format === "json") {
            blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
            name = "dhcp-ips.json";
        } else {
            const header = ["ip", "mac", "hostname", "online", "source", "leased", "reserved", "conflict", "lease_expires_at"];
            const csv = [
                header.join(","),
                ...rows.map((row) => header.map((key) => JSON.stringify(row[key] ?? "")).join(",")),
            ].join("\n");
            blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
            name = "dhcp-ips.csv";
        }
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = name;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
    }

    return (
        <div className="registry-panel dhcp-connected-panel">
            <div className="registry-panel-head">
                <div>
                    <h3>IPs conectadas / leases</h3>
                    <p className="registry-hint">
                        Vista temporal: ARP, DHCP, reservas y conflictos. Se actualiza cada 20 s.
                    </p>
                </div>
                <div className="actions" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button type="button" className="secondary-button" onClick={() => download("csv")} disabled={!data}>
                        Exportar CSV
                    </button>
                    <button type="button" className="secondary-button" onClick={() => download("json")} disabled={!data}>
                        Exportar JSON
                    </button>
                    <button type="button" className="secondary-button" onClick={load} disabled={loading}>
                        {loading ? "Actualizando…" : "Actualizar"}
                    </button>
                </div>
            </div>

            {error && <p className="registry-message error">{error}</p>}

            {data && (
                <>
                    <div className="lan-stat-row">
                        <span className="lan-stat"><span>IPs vistas</span><strong>{data.total}</strong></span>
                        <span className="lan-stat"><span>Online</span><strong>{data.online}</strong></span>
                        <span className="lan-stat"><span>Con lease</span><strong>{data.leased}</strong></span>
                        <span className="lan-stat"><span>Reservadas</span><strong>{data.reserved}</strong></span>
                        <span className="lan-stat"><span>Conflictos</span><strong className={data.conflicts ? "err-text" : ""}>{data.conflicts}</strong></span>
                    </div>

                    <div className="dhcp-table-wrap">
                        <table className="dhcp-ip-table">
                            <thead>
                                <tr>
                                    <th>IP</th>
                                    <th>MAC</th>
                                    <th>Equipo</th>
                                    <th>Estado</th>
                                    <th>Origen</th>
                                    <th>Lease</th>
                                    <th>Reserva</th>
                                </tr>
                            </thead>
                            <tbody>
                                {(data.rows || []).map((row) => (
                                    <tr key={row.ip} className={row.conflict ? "row-conflict" : ""}>
                                        <td><code>{row.ip}</code></td>
                                        <td><code>{row.mac || "—"}</code></td>
                                        <td>{row.hostname || "—"}</td>
                                        <td>{row.online ? "ONLINE" : "NO VISIBLE"}</td>
                                        <td>{row.source}</td>
                                        <td>{leaseLabel(row.lease_expires_at)}</td>
                                        <td>{row.reserved ? "Sí" : "No"}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </>
            )}
        </div>
    );
}
