import { useEffect, useState } from "react";

import { useNavigate } from "react-router-dom";

import {
    getRegisteredInterfaces,
    rescanInterfaces,
    assignInterfaceRole,
    unassignInterfaceRole,
    deleteRegisteredInterface,
    testInterfaceConnectivity,
    compareWan,
    updateZone,
} from "../../../services/api";

import { useNetworkSegment } from "../../../network/useNetworkSegment";

import NetworkDiagnosis from "../../../components/network/NetworkDiagnosis";

import WriteGuard from "../../../components/WriteGuard";

import "./interfaces.css";


function LinkStatus({ up, labelUp, labelDown }) {

    return (
        <span className={`iface-link-status ${up ? "up" : "down"}`}>
            <span className="iface-link-dot" />
            {up ? labelUp : labelDown}
        </span>
    );

}


function DetailChip({ label, value, mono }) {

    return (
        <span className={`iface-chip ${mono ? "mono" : ""}`}>
            <span className="iface-chip-label">{label}</span>
            <span className="iface-chip-value">{value}</span>
        </span>
    );

}


function RoleGlyph({ role }) {

    const normalized = (role || "none").toLowerCase();
    const label = normalized === "wan" ? "W" : normalized === "lan" ? "L" : "?";

    return (
        <span className={`iface-role-glyph ${normalized}`} aria-hidden="true">
            {label}
        </span>
    );

}


function InterfaceCard({ item, busyId, testResults, onTest, onUnassign, onPriorityChange }) {

    const name = item.current_name || item.last_seen_name || "-";
    const role = (item.role || "").toLowerCase();
    const test = testResults[item.id];

    return (

        <div className={`registry-card role-${role} ${item.link_detected ? "live" : "offline"}`}>

            <div className="registry-card-main">

                <div className="registry-card-title-row">
                    <RoleGlyph role={role} />
                    <div className="registry-card-heading">
                        <div className="registry-card-name">
                            {name}
                            {item.display_name && (
                                <span className="registry-card-label"> · {item.display_name}</span>
                            )}
                        </div>
                        <span className={`registry-card-state ${item.link_detected ? "online" : "offline"}`}>
                            {item.link_detected ? "En línea" : "Sin enlace"}
                        </span>
                    </div>
                    <span className={`iface-role-badge ${role}`}>{item.role}</span>
                </div>

                <div className="registry-card-details">
                    <LinkStatus
                        up={item.link_detected}
                        labelUp="Enlace activo"
                        labelDown="Sin cable"
                    />
                    <DetailChip label="MAC" value={item.mac_address} mono />
                    <DetailChip label="IP" value={item.ip_address || "sin IP"} mono />
                </div>

            </div>

            <div className="registry-card-priority">
                <span className="priority-label">Prioridad</span>
                <div className="priority-stepper">
                    <WriteGuard>
                        <button
                            type="button"
                            disabled={busyId === item.id}
                            title="Subir prioridad (preferir esta tarjeta primero)"
                            onClick={() => onPriorityChange(item.id, item.priority - 10)}
                        >
                            ▲
                        </button>
                    </WriteGuard>
                    <span className="priority-value">{item.priority}</span>
                    <WriteGuard>
                        <button
                            type="button"
                            disabled={busyId === item.id}
                            title="Bajar prioridad"
                            onClick={() => onPriorityChange(item.id, item.priority + 10)}
                        >
                            ▼
                        </button>
                    </WriteGuard>
                </div>
            </div>

            <div className="registry-card-actions">

                {
                    item.role === "WAN" && (
                        <WriteGuard>
                            <button
                                type="button"
                                className="iface-action-btn"
                                disabled={busyId === item.id}
                                onClick={() => onTest(item.id)}
                            >
                                {busyId === item.id ? "Probando..." : "Probar internet"}
                            </button>
                        </WriteGuard>
                    )
                }

                <WriteGuard>
                    <button
                        type="button"
                        className="iface-action-btn ghost"
                        disabled={busyId === item.id}
                        onClick={() => onUnassign(item.id)}
                    >
                        Quitar rol
                    </button>
                </WriteGuard>

                {
                    test && (
                        <div
                            className={
                                test.has_internet
                                    ? "registry-test-result-ok"
                                    : "registry-test-result-no"
                            }
                        >
                            {test.message}
                        </div>
                    )
                }

            </div>

        </div>

    );

}


function UnassignedCard({ item, busyId, testResults, onTest, onAssign, onDelete }) {

    const [selectedRole, setSelectedRole] = useState("");


    function handleRoleChange(value) {

        if (!value) return;

        onAssign(item.id, value);

        setSelectedRole("");

    }


    return (

        <div className={`registry-card registry-card-unassigned ${item.status === "missing" ? "missing" : ""}`}>

            <div className="registry-card-main">

                <div className="registry-card-title-row">
                    <RoleGlyph role="none" />
                    <div className="registry-card-heading">
                        <div className="registry-card-name">
                            {item.current_name || item.last_seen_name || "-"}
                        </div>
                        <span className={`registry-card-state ${item.link_detected ? "online" : "offline"}`}>
                            {item.link_detected ? "En línea" : "Sin enlace"}
                        </span>
                    </div>
                    <span className={`iface-role-badge ${item.status === "missing" ? "missing" : "none"}`}>
                        {item.status === "missing" ? "Ausente" : "Sin rol"}
                    </span>
                </div>

                <div className="registry-card-details">
                    <LinkStatus
                        up={item.link_detected}
                        labelUp="Enlace activo"
                        labelDown="Sin cable"
                    />
                    <DetailChip label="MAC" value={item.mac_address} mono />
                    <DetailChip label="IP" value={item.ip_address || "sin IP"} mono />
                </div>

                {
                    item.status === "missing" && (
                        <div className="registry-missing-tag">
                            No detectada -- esta tarjeta tenía un rol asignado y ya no aparece.
                        </div>
                    )
                }

                {
                    item.suggested_replacement && (

                        <div className="registry-suggestion">

                            ¿Reemplazaste la tarjeta{" "}
                            {item.suggested_replacement.suggested_role}
                            {" "}(antes{" "}
                            {item.suggested_replacement.replaces_last_seen_name}
                            {")? "}

                            <WriteGuard>
                                <button
                                    disabled={busyId === item.id}
                                    onClick={() =>
                                        onAssign(
                                            item.id,
                                            item.suggested_replacement.suggested_role,
                                            item.suggested_replacement.suggested_display_name,
                                            item.suggested_replacement.replaces_mac
                                        )
                                    }
                                >
                                    Sí, asignar el mismo rol
                                </button>
                            </WriteGuard>

                        </div>

                    )
                }

            </div>

            <div className="registry-card-actions">

                {
                    item.link_detected && (
                        <WriteGuard>
                            <button
                                type="button"
                                className="iface-action-btn"
                                disabled={busyId === item.id}
                                onClick={() => onTest(item.id)}
                            >
                                {busyId === item.id ? "Probando..." : "Probar internet"}
                            </button>
                        </WriteGuard>
                    )
                }

                <WriteGuard>
                    <div className="registry-assign-row">

                        {
                            item.status !== "missing" && (
                                <select
                                    value={selectedRole}
                                    onChange={(e) => handleRoleChange(e.target.value)}
                                >
                                    <option value="">Elegir rol...</option>
                                    <option value="WAN">WAN (internet)</option>
                                    <option value="LAN">LAN (red interna)</option>
                                </select>
                            )
                        }

                        {
                            item.status === "missing" && (
                                <button
                                    type="button"
                                    className="iface-action-btn danger"
                                    disabled={busyId === item.id}
                                    onClick={() => onDelete(item.id)}
                                    title="Eliminar del registro -- ya no está conectada"
                                >
                                    Eliminar
                                </button>
                            )
                        }

                    </div>
                </WriteGuard>

                {
                    testResults[item.id] && (
                        <div
                            className={
                                testResults[item.id].has_internet
                                    ? "registry-test-result-ok"
                                    : "registry-test-result-no"
                            }
                        >
                            {testResults[item.id].message}
                        </div>
                    )
                }

            </div>

        </div>

    );

}


function InterfaceRegistryPanel({ onRegistryChange }) {

    const navigate = useNavigate();

    const { refresh: refreshSegments, setSelectedMac } = useNetworkSegment();

    const [registered, setRegistered] = useState([]);

    const [busyId, setBusyId] = useState(null);

    const [testResults, setTestResults] = useState({});

    const [compareResults, setCompareResults] = useState([]);

    const [compareBusy, setCompareBusy] = useState(false);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState("");

    const [notice, setNotice] = useState("");


    async function handleCompareWan() {

        setCompareBusy(true);

        try {

            const res = await compareWan();

            setCompareResults(res || []);

        } catch (requestError) {

            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudo comparar la conectividad WAN."
            );

        } finally {

            setCompareBusy(false);

        }

    }


    useEffect(() => {

        loadRegistered();

    }, []);


    async function loadRegistered() {

        setLoading(true);
        setError("");

        try {

            const data = await getRegisteredInterfaces();

            setRegistered(Array.isArray(data) ? data : []);

        } catch (requestError) {

            setRegistered([]);
            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudieron cargar las tarjetas de red."
            );

        } finally {

            setLoading(false);

        }

    }


    const [rescanBusy, setRescanBusy] = useState(false);

    async function handleRescan() {

        setRescanBusy(true);
        setError("");
        setNotice("");

        try {

            const data = await rescanInterfaces();

            setRegistered(Array.isArray(data) ? data : []);
            setNotice("Tarjetas actualizadas desde el hardware.");

        } catch (requestError) {

            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudo rescanear las tarjetas."
            );

        } finally {

            setRescanBusy(false);

        }

    }


    async function handleTestConnectivity(id) {

        setBusyId(id);

        try {

            const result = await testInterfaceConnectivity(id);

            setTestResults((previous) => ({
                ...previous,
                [id]: result
            }));

        } catch (requestError) {

            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudo probar la conexión."
            );

        } finally {

            setBusyId(null);

        }

    }


    async function handleAssign(id, role, displayName, replacesMac) {

        setBusyId(id);

        try {

            const payload = {
                role,
                ...(displayName ? { display_name: displayName } : {}),
                ...(replacesMac ? { replaces_mac: replacesMac } : {}),
            };

            const result = await assignInterfaceRole(id, payload);

            if (result?.success === false) {
                setError(result.message || "No se pudo asignar el rol.");
                return;
            }

            setNotice(`Rol ${role} asignado.`);

            await loadRegistered();

            onRegistryChange?.();

            await refreshSegments();

            const setup = result?.zone_setup;

            if (role === "LAN" && setup) {

                if (setup.interface_mac) {

                    setSelectedMac(setup.interface_mac);

                }

                if (setup.needs_zone_setup) {

                    const mac = setup.interface_mac || "";

                    const iface = setup.physical_interface || "";

                    const choices = Array.isArray(setup.zone_choices)
                        ? setup.zone_choices
                        : [];

                    if (choices.length > 0) {

                        // Varias zonas libres: mostrar un selector para
                        // asignar la tarjeta a la zona elegida.
                        const lines = choices.map(
                            (z, i) => `${i + 1} = ${z.zone_name} (${z.network_cidr})`
                        );
                        const answer = window.prompt(
                            "Varias zonas libres. Elige la zona para esta tarjeta LAN:\n\n"
                            + lines.join("\n"),
                            "1"
                        );
                        if (answer !== null) {
                            const idx = parseInt(answer, 10) - 1;
                            const chosen = choices[idx];
                            if (chosen) {
                                try {
                                    await updateZone(chosen.zone_id, {
                                        interface_mac: mac,
                                        physical_interface: iface,
                                    });
                                    await loadRegistered();
                                    window.alert(
                                        `Asignada la zona «${chosen.zone_name}».`
                                    );
                                } catch (err2) {
                                    window.alert(
                                        (err2 && err2.message) || String(err2) ||
                                        "No se pudo asignar la zona."
                                    );
                                }
                            } else {
                                window.alert("Opción de zona no válida.");
                            }
                        }

                    } else {

                        const go = window.confirm(
                            `${setup.message || "Esta tarjeta LAN no tiene zona."}\n\n`
                            + "¿Ir ahora a Zonas para configurarla?"
                        );

                        if (go) {

                            navigate(
                                `/network/zones?mac=${encodeURIComponent(mac)}&iface=${encodeURIComponent(iface)}`
                            );

                        }

                    }

                } else if (setup.created && setup.message) {

                    window.alert(setup.message);

                }

            }

        } catch (requestError) {

            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudo asignar el rol."
            );

        } finally {

            setBusyId(null);

        }

    }


    async function handlePriorityChange(id, newPriority) {

        setBusyId(id);

        try {

            const item = registered.find((entry) => entry.id === id);

            const result = await assignInterfaceRole(id, {
                role: item.role,
                priority: newPriority,
            });

            if (result?.success === false) {
                setError(result.message || "No se pudo cambiar la prioridad.");
                return;
            }

            setNotice("Prioridad actualizada.");

            await loadRegistered();

        } catch (requestError) {

            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudo cambiar la prioridad."
            );

        } finally {

            setBusyId(null);

        }

    }


    async function handleUnassign(id) {

        setBusyId(id);

        try {

            const result = await unassignInterfaceRole(id);

            if (result?.success === false) {
                setError(result.message || "No se pudo quitar el rol.");
                return;
            }

            setNotice("Rol retirado.");

            await loadRegistered();

            onRegistryChange?.();

        } catch (requestError) {

            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudo quitar el rol."
            );

        } finally {

            setBusyId(null);

        }

    }


    async function handleDelete(id) {

        setBusyId(id);

        try {

            const result = await deleteRegisteredInterface(id);

            if (result?.success === false) {
                setError(result.message || "No se pudo eliminar la tarjeta.");
                return;
            }

            setNotice("Tarjeta eliminada del registro.");

            await loadRegistered();

            onRegistryChange?.();

        } catch (requestError) {

            setError(
                requestError?.response?.data?.detail
                || requestError.message
                || "No se pudo eliminar la tarjeta."
            );

        } finally {

            setBusyId(null);

        }

    }


    const wanCards = registered
        .filter((item) => item.role === "WAN")
        .sort((a, b) => a.priority - b.priority);

    const lanCards = registered
        .filter((item) => item.role === "LAN")
        .sort((a, b) => a.priority - b.priority);

    const unassignedCards = registered.filter(
        (item) => item.status === "pending_assignment" || item.status === "missing"
    );


    return (

        <div className="registry-panel">

            <div className="registry-panel-head">
                <div>
                    <h3>Tarjetas de red</h3>
                    <p className="registry-hint">
                        Cada tarjeta se identifica por su MAC, no por el nombre
                        que le da Linux — así el rol sobrevive a un cambio de
                        máquina o un reinicio. La prioridad decide cuál se usa primero.
                    </p>
                </div>
                <div className="confirm-actions">
                    <button className="secondary-button" onClick={handleRescan} disabled={rescanBusy}>
                        {rescanBusy ? "Rescaneando..." : "Rescanear"}
                    </button>
                    <button className="secondary-button" onClick={handleCompareWan} disabled={compareBusy}>
                        {compareBusy ? "Midiendo..." : "Comparar internet"}
                    </button>
                </div>
            </div>

            {loading && (
                <p className="registry-message">Cargando tarjetas de red...</p>
            )}
            {error && (
                <div className="registry-message error" role="alert">
                    {error}
                </div>
            )}
            {notice && (
                <div className="registry-message ok" role="status">
                    {notice}
                </div>
            )}

            <div className="iface-summary">
                <span className="iface-summary-chip wan">
                    <strong>{wanCards.length}</strong> WAN
                </span>
                <span className="iface-summary-chip lan">
                    <strong>{lanCards.length}</strong> LAN
                </span>
                <span className="iface-summary-chip none">
                    <strong>{unassignedCards.length}</strong> sin asignar
                </span>
            </div>

            {
                compareResults.length > 0 && (
                    <div className="registry-compare">
                        <h4>Comparación de proveedores (mejor primero)</h4>
                        {
                            compareResults.map((r, i) => (
                                <div
                                    key={r.mac_address || r.name}
                                    className={
                                        i === 0 && r.has_internet
                                            ? "registry-compare-item best"
                                            : "registry-compare-item"
                                    }
                                >
                                    <strong>{r.name}</strong>
                                    <span>
                                        {
                                            r.has_internet
                                                ? `Internet OK · ${r.latency_ms ? r.latency_ms.toFixed(0) : "—"} ms · pérdida ${r.packet_loss}%`
                                                : "Sin internet"
                                        }
                                        {i === 0 && r.has_internet && " · Recomendada"}
                                    </span>
                                </div>
                            ))
                        }
                    </div>
                )
            }

            <div className="registry-section">

                <h4 className="registry-section-title wan">
                    <span className="iface-role-badge wan">WAN</span>
                    Internet
                    {wanCards.length > 0 && <em>{wanCards.length}</em>}
                </h4>

                {
                    wanCards.length === 0 ? (
                        <p className="registry-empty">Ninguna tarjeta asignada como WAN todavía.</p>
                    ) : (
                        wanCards.map((item) => (
                            <InterfaceCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onUnassign={handleUnassign}
                                onPriorityChange={handlePriorityChange}
                            />
                        ))
                    )
                }

            </div>

            <div className="registry-section">

                <h4 className="registry-section-title lan">
                    <span className="iface-role-badge lan">LAN</span>
                    Red interna
                    {lanCards.length > 0 && <em>{lanCards.length}</em>}
                </h4>

                {
                    lanCards.length === 0 ? (
                        <p className="registry-empty">Ninguna tarjeta asignada como LAN todavía.</p>
                    ) : (
                        lanCards.map((item) => (
                            <InterfaceCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onUnassign={handleUnassign}
                                onPriorityChange={handlePriorityChange}
                            />
                        ))
                    )
                }

            </div>

            <div className="registry-section">

                <h4 className="registry-section-title none">
                    <span className="iface-role-badge none">Libre</span>
                    Sin asignar
                    {unassignedCards.length > 0 && <em>{unassignedCards.length}</em>}
                </h4>

                {
                    unassignedCards.length === 0 ? (
                        <p className="registry-empty">No hay tarjetas pendientes de asignar.</p>
                    ) : (
                        unassignedCards.map((item) => (
                            <UnassignedCard
                                key={item.id}
                                item={item}
                                busyId={busyId}
                                testResults={testResults}
                                onTest={handleTestConnectivity}
                                onAssign={handleAssign}
                                onDelete={handleDelete}
                            />
                        ))
                    )
                }

            </div>

        </div>

    );

}


function Interfaces() {

    const [diagKey, setDiagKey] = useState(0);

    const [tab, setTab] = useState("cards");


    return (

        <div className="interfaces-page">

            <header className="interfaces-hero">
                <div className="interfaces-hero-copy">
                    <span className="interfaces-eyebrow">RED FÍSICA</span>
                    <h2>Interfaces de red</h2>
                    <p>
                        Asigna roles WAN/LAN por tarjeta. La identidad se
                        mantiene por MAC aunque cambie el nombre de Linux.
                    </p>
                </div>
                <div className="interfaces-hero-note">
                    <span className="interfaces-hero-note-icon">⌁</span>
                    <div>
                        <strong>Asignación segura</strong>
                        <small>El DHCP y las zonas se configuran en Red → DHCP / Zonas.</small>
                    </div>
                </div>
            </header>

            <div className="interfaces-tabs" role="tablist">

                <button
                    type="button"
                    role="tab"
                    aria-selected={tab === "cards"}
                    className={`interfaces-tab ${tab === "cards" ? "active" : ""}`}
                    onClick={() => setTab("cards")}
                >
                    Tarjetas y roles
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={tab === "diagnosis"}
                    className={`interfaces-tab ${tab === "diagnosis" ? "active" : ""}`}
                    onClick={() => setTab("diagnosis")}
                >
                    Diagnóstico de red
                </button>

            </div>

            {
                tab === "cards"
                    ? <InterfaceRegistryPanel onRegistryChange={() => setDiagKey((k) => k + 1)} />
                    : <NetworkDiagnosis refreshKey={diagKey} />
            }

        </div>

    );

}


export default Interfaces;