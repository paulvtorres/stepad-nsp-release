import { useState, useEffect, useCallback } from "react";
import {
    getSystemBackupStatus,
    getSystemBackupConfig,
    saveSystemBackupConfig,
    createSystemBackup,
    listSystemBackupSnapshots,
    restoreSystemBackup,
    detectSystemBackupUsb,
    exportReplacementBundle,
    verifySystemRestore,
    getRollbackPoints,
    verifyRollbackPoints,
} from "../../services/api";
import "./system-backup.css";

function formatWhen(iso) {
    if (!iso) return "Nunca";
    const d = new Date(iso);
    return d.toLocaleString("es-EC", {
        dateStyle: "medium",
        timeStyle: "short",
    });
}

function elapsedSince(iso) {
    if (!iso) return "";
    const ms = Date.now() - new Date(iso).getTime();
    const mins = Math.round(ms / 60000);
    if (mins < 60) return `hace ${mins}m`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `hace ${hrs}h`;
    return `hace ${Math.round(hrs / 24)}d`;
}

export default function SystemBackup() {
    const [status, setStatus] = useState(null);
    const [config, setConfig] = useState(null);
    const [snapshots, setSnapshots] = useState([]);
    const [loading, setLoading] = useState(true);
    const [creating, setCreating] = useState(false);
    const [restoring, setRestoring] = useState(null);
    const [feedback, setFeedback] = useState(null);
    const [usbAvailable, setUsbAvailable] = useState(false);
    const [replacePass, setReplacePass] = useState("");
    const [replacePass2, setReplacePass2] = useState("");
    const [exportingReplace, setExportingReplace] = useState(false);
    const [replacementFile, setReplacementFile] = useState(null);
    const [verifyingRestore, setVerifyingRestore] = useState(false);
    const [rollback, setRollback] = useState(null);
    const [verifyingRollback, setVerifyingRollback] = useState(false);
    const [tab, setTab] = useState("history");

    const load = useCallback(async () => {
        try {
            const [s, c, sn, usb, rb] = await Promise.all([
                getSystemBackupStatus(),
                getSystemBackupConfig(),
                listSystemBackupSnapshots(),
                detectSystemBackupUsb(),
                getRollbackPoints(),
            ]);
            setStatus(s);
            setConfig(c);
            setSnapshots(sn?.snapshots || []);
            setUsbAvailable(usb?.available || false);
            setRollback(rb || {});
        } catch (e) {
            setFeedback({ type: "error", msg: "Error cargando datos: " + e.message });
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { load(); }, [load]);

    async function handleCreate() {
        setCreating(true);
        setFeedback({ type: "info", msg: "Creando backup del sistema..." });
        try {
            const result = await createSystemBackup();
            if (result?.success) {
                setFeedback({ type: "success", msg: "Backup creado exitosamente." });
                await load();
            } else {
                setFeedback({ type: "error", msg: "Fallo: " + (result?.error || "Error desconocido") });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setCreating(false);
        }
    }

    async function handleRestore(snapshotId) {
        if (!window.confirm(`¿Restaurar backup ${snapshotId}? El NSP se reiniciará.`)) return;
        setRestoring(snapshotId);
        setFeedback({ type: "info", msg: "Restaurando... el NSP se reiniciará." });
        try {
            const result = await restoreSystemBackup(snapshotId);
            if (result?.success) {
                setFeedback({ type: "success", msg: "Restaurado. El NSP se está reiniciando..." });
            } else {
                setFeedback({ type: "error", msg: "Fallo: " + (result?.error || "") });
            }
        } catch (e) {
            setFeedback({ type: "error", msg: "Error: " + e.message });
        } finally {
            setRestoring(null);
        }
    }

    async function handleSaveConfig() {
        try {
            await saveSystemBackupConfig(config);
            setFeedback({ type: "success", msg: "Configuración guardada." });
        } catch (e) {
            setFeedback({ type: "error", msg: "Error guardando: " + e.message });
        }
    }

    async function handleVerifyRollback() {

        setVerifyingRollback(true);
        setFeedback(null);
        try {
            const result = await verifyRollbackPoints();
            setFeedback({
                type: result?.ok ? "success" : "error",
                msg: result?.message || (result?.ok ? "Puntos íntegros" : "Hay puntos dañados"),
            });
            await load();
        } catch (e) {
            setFeedback({ type: "error", msg: e.message || String(e) });
        } finally {
            setVerifyingRollback(false);
        }

    }

    async function handleVerifyRestore() {

        setVerifyingRestore(true);
        setFeedback(null);
        try {
            const result = await verifySystemRestore();
            setFeedback({
                type: result?.success ? "success" : "error",
                msg: result?.message || (result?.success ? "Verificación OK" : "La verificación falló"),
            });
            await load();
        } catch (e) {
            setFeedback({ type: "error", msg: e.message || String(e) });
        } finally {
            setVerifyingRestore(false);
        }

    }

    async function handleReplacementExport() {

        if (replacePass.length < 12) {
            setFeedback({ type: "error", msg: "La frase debe tener al menos 12 caracteres." });
            return;
        }
        if (replacePass !== replacePass2) {
            setFeedback({ type: "error", msg: "Las frases no coinciden." });
            return;
        }
        setExportingReplace(true);
        setFeedback(null);
        try {
            const { blob, filename } = await exportReplacementBundle(replacePass);
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(url);
            setReplacementFile(filename);
            setReplacePass("");
            setReplacePass2("");
            setFeedback({ type: "success", msg: "Paquete generado. Guárdalo de forma segura." });
        } catch (e) {
            setFeedback({ type: "error", msg: e.message || String(e) });
        } finally {
            setExportingReplace(false);
        }

    }

    if (loading) return <div className="sb-page"><div className="sb-loading">Cargando...</div></div>;

    return (
        <div className="sb-page">
            <h1>Respaldo del sistema</h1>
            <p className="sb-subtitle">
                Copias de seguridad de la configuración completa del NSP: base de datos,
                archivos de configuración, reglas de firewall y claves.
            </p>

            {feedback && (
                <div className={`sb-feedback ${feedback.type}`}>
                    {feedback.msg}
                    <button className="sb-btn" style={{ marginLeft: 12, padding: "4px 10px" }}
                        onClick={() => setFeedback(null)}>×</button>
                </div>
            )}

            {/* Status cards */}
            <div className="sb-status-grid">
                <div className="sb-status-card">
                    <div className="label">Último backup</div>
                    <div className={`value ${status?.last_backup ? "ok" : "warn"}`}>
                        {formatWhen(status?.last_backup)}
                    </div>
                    {status?.last_backup && (
                        <div style={{ fontSize: "0.8rem", color: "#64748b", marginTop: 2 }}>
                            {elapsedSince(status?.last_backup)}
                        </div>
                    )}
                </div>
                <div className="sb-status-card">
                    <div className="label">Total backups</div>
                    <div className="value">{status?.total_backups || 0}</div>
                </div>
                <div className="sb-status-card">
                    <div className="label">Destino</div>
                    <div className="value">
                        {status?.destination === "usb" ? "USB" :
                         status?.destination === "cloud" ? "Nube" : "Local"}
                    </div>
                    {status?.destination === "usb" && !status?.usb_available && (
                        <div style={{ fontSize: "0.8rem", color: "#d97706", marginTop: 2 }}>
                            USB no conectado
                        </div>
                    )}
                </div>
                <div className="sb-status-card">
                    <div className="label">Estado</div>
                    <div className={`value ${status?.enabled ? "ok" : "warn"}`}>
                        {status?.enabled ? "Activo" : "Inactivo"}
                    </div>
                    {status?.schedule_enabled !== false ? (
                        <div style={{ fontSize: "0.8rem", color: "var(--muted)", marginTop: 2 }}>
                            Diario a las {String(status?.schedule_hour ?? 3).padStart(2, "0")}:
                            {String(status?.schedule_minute ?? 0).padStart(2, "0")}
                        </div>
                    ) : (
                        <div style={{ fontSize: "0.8rem", color: "var(--muted)", marginTop: 2 }}>
                            Automático desactivado
                        </div>
                    )}
                </div>
                <div className="sb-status-card">
                    <div className="label">Verificación de restauración</div>
                    <div className={`value ${status?.restore_verify?.success ? "ok" : status?.restore_verify?.skipped ? "warn" : status?.restore_verify ? "error" : "warn"}`}>
                        {status?.restore_verify
                            ? (status.restore_verify.success
                                ? "OK"
                                : status.restore_verify.skipped ? "Omitida" : "Falló")
                            : "Sin datos"}
                    </div>
                    {status?.restore_verify?.last_run_at && (
                        <div style={{ fontSize: "0.8rem", color: "var(--muted)", marginTop: 2 }}>
                            {formatWhen(status.restore_verify.last_run_at)}
                            {status.restore_verify.tables ? ` · ${status.restore_verify.tables} tablas` : ""}
                        </div>
                    )}
                    <button
                        className="sb-btn"
                        style={{ marginTop: 8 }}
                        onClick={handleVerifyRestore}
                        disabled={verifyingRestore}
                    >
                        {verifyingRestore ? "Verificando..." : "Verificar ahora"}
                    </button>
                </div>
            </div>

            {/* Actions */}
            <div className="sb-actions">
                <button className="sb-btn primary" onClick={handleCreate} disabled={creating}>
                    {creating ? "Creando..." : "+ Crear backup ahora"}
                </button>
                <button className="sb-btn" onClick={load}>Actualizar</button>
            </div>

            <div className="sb-tabs" role="tablist">
                <button
                    type="button"
                    role="tab"
                    aria-selected={tab === "history"}
                    className={`sb-tab ${tab === "history" ? "active" : ""}`}
                    onClick={() => setTab("history")}
                >
                    Historial y puntos de retorno
                </button>
                <button
                    type="button"
                    role="tab"
                    aria-selected={tab === "config"}
                    className={`sb-tab ${tab === "config" ? "active" : ""}`}
                    onClick={() => setTab("config")}
                >
                    Configuración
                </button>
                <button
                    type="button"
                    role="tab"
                    aria-selected={tab === "replace"}
                    className={`sb-tab ${tab === "replace" ? "active" : ""}`}
                    onClick={() => setTab("replace")}
                >
                    Reemplazo de equipo
                </button>
            </div>

            {tab === "history" && (
                <>
            {/* Snapshots */}
            <div className="sb-snapshots">
                <h2>Historial de respaldos ({snapshots.length})</h2>
                {snapshots.length === 0 ? (
                    <div className="sb-empty">
                        No hay backups aún. Creá el primero con el botón de arriba.
                    </div>
                ) : (
                    snapshots.slice().reverse().map((snap) => (
                        <div key={snap.id} className="sb-snapshot-row">
                            <div className="sb-snapshot-info">
                                <div className="id">{snap.id?.slice(0, 8)}</div>
                                <div className="meta">
                                    {formatWhen(snap.time)} · {snap.tree?.total_files || "?"} archivos
                                </div>
                                <div className="tags">
                                    {(snap.tags || []).map((tag) => (
                                        <span key={tag} className={`sb-tag ${tag}`}>
                                            {tag}
                                        </span>
                                    ))}
                                </div>
                            </div>
                            <button
                                className="sb-btn"
                                onClick={() => handleRestore(snap.id)}
                                disabled={restoring === snap.id}
                            >
                                {restoring === snap.id ? "Restaurando..." : "Restaurar"}
                            </button>
                        </div>
                    ))
                )}
            </div>

            {/* Config */}
            <div className="sb-snapshots">
                <h2>Puntos de retorno ({rollback?.count || 0})</h2>
                <p className="sb-subtitle">
                    Copias del código y de la base que permiten volver a una
                    versión anterior si una actualización falla.
                    {rollback?.last_run_at
                        ? ` Última verificación: ${formatWhen(rollback.last_run_at)}.`
                        : ""}
                </p>
                <div className="sb-actions" style={{ marginBottom: 10 }}>
                    <button
                        className="sb-btn primary"
                        onClick={handleVerifyRollback}
                        disabled={verifyingRollback}
                    >
                        {verifyingRollback ? "Verificando..." : "Verificar integridad"}
                    </button>
                </div>
                {(rollback?.points || []).length === 0 ? (
                    <div className="sb-empty">No hay puntos de retorno guardados.</div>
                ) : (
                    (rollback.points || []).map((point) => (
                        <div key={point.name} className="sb-snapshot-row">
                            <div className="sb-snapshot-info">
                                <strong>{point.name}</strong>
                                <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>
                                    {point.version}
                                    {" · "}
                                    {Math.round((Number(point.app_size) || 0) / 1024 / 1024)} MB código
                                    {" · "}
                                    {Math.round((Number(point.db_size) || 0) / 1024 / 1024)} MB base
                                </div>
                                {point.error && (
                                    <div style={{ fontSize: "0.8rem", color: "#dc2626" }}>
                                        {point.error}
                                    </div>
                                )}
                            </div>
                            <span className={`sb-badge ${point.ok ? "green" : "readonly"}`}>
                                {point.ok ? "OK" : "Dañado"}
                            </span>
                        </div>
                    ))
                )}
            </div>

                </>
            )}

            {tab === "config" && config && (
                <div className="sb-config">
                    <h2>Configuración</h2>
                    <div className="sb-form-row">
                        <label>Destino:</label>
                        <select
                            value={config.destination || "local"}
                            onChange={(e) => setConfig({ ...config, destination: e.target.value })}
                        >
                            <option value="local">Local (/var/backups/stepad)</option>
                            <option value="usb" disabled={!usbAvailable}>
                                USB {usbAvailable ? "" : "(no detectado)"}
                            </option>
                            <option value="cloud">Nube (S3/B2)</option>
                        </select>
                    </div>
                    {config.destination === "cloud" && (
                        <div className="sb-form-row">
                            <label>Backend:</label>
                            <input
                                value={config.cloud_backend || ""}
                                onChange={(e) => setConfig({ ...config, cloud_backend: e.target.value })}
                                placeholder="s3:bucket-name"
                            />
                        </div>
                    )}
                    <div className="sb-form-row">
                        <label>Retener diarios:</label>
                        <input
                            type="number"
                            min="1"
                            max="90"
                            value={config.keep_daily || 7}
                            onChange={(e) => setConfig({ ...config, keep_daily: parseInt(e.target.value) || 7 })}
                        />
                    </div>
                    <div className="sb-form-row">
                        <label>Retener semanales:</label>
                        <input
                            type="number"
                            min="1"
                            max="52"
                            value={config.keep_weekly || 4}
                            onChange={(e) => setConfig({ ...config, keep_weekly: parseInt(e.target.value) || 4 })}
                        />
                    </div>
                    <div className="sb-form-row">
                        <label>Retener mensuales:</label>
                        <input
                            type="number"
                            min="1"
                            max="24"
                            value={config.keep_monthly || 6}
                            onChange={(e) => setConfig({ ...config, keep_monthly: parseInt(e.target.value) || 6 })}
                        />
                    </div>
                    <div className="sb-form-row" style={{ display: "flex", alignItems: "center" }}>
                        <label>
                            Respaldo automático diario:
                        </label>
                        <input
                            type="checkbox"
                            checked={config.schedule_enabled !== false}
                            onChange={(e) => setConfig({ ...config, schedule_enabled: e.target.checked })}
                            style={{ width: "auto", marginRight: 12 }}
                        />
                        {config.schedule_enabled !== false && (
                            <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                                a las
                                <input
                                    type="number"
                                    min="0"
                                    max="23"
                                    value={config.schedule_hour || 3}
                                    onChange={(e) => setConfig({ ...config, schedule_hour: parseInt(e.target.value) || 3 })}
                                    style={{ width: 60 }}
                                />
                                :
                                <input
                                    type="number"
                                    min="0"
                                    max="59"
                                    value={config.schedule_minute || 0}
                                    onChange={(e) => setConfig({ ...config, schedule_minute: parseInt(e.target.value) || 0 })}
                                    style={{ width: 60 }}
                                />
                            </span>
                        )}
                    </div>
                    <div style={{ marginTop: 12 }}>
                        <button className="sb-btn primary" onClick={handleSaveConfig}>
                            Guardar configuración
                        </button>
                    </div>
                </div>
            )}

            {tab === "replace" && (
            <div className="sb-snapshots">
                <h2>Reemplazo de equipo</h2>
                <p className="sb-subtitle">
                    Crea un paquete cifrado con la base de datos, los secretos
                    y la configuración para mover el NSP a otra máquina.
                    Contiene credenciales: guárdalo de forma segura y bórralo
                    después de importarlo.
                </p>
                <div className="sb-config">
                    <div className="sb-form-row">
                        <label>Frase de seguridad (mínimo 12 caracteres)</label>
                        <input
                            type="password"
                            aria-label="Frase de seguridad"
                            value={replacePass}
                            onChange={(e) => setReplacePass(e.target.value)}
                            autoComplete="new-password"
                            style={{ width: 280 }}
                        />
                    </div>
                    <div className="sb-form-row">
                        <label>Repetir frase</label>
                        <input
                            type="password"
                            aria-label="Repetir frase"
                            value={replacePass2}
                            onChange={(e) => setReplacePass2(e.target.value)}
                            autoComplete="new-password"
                            style={{ width: 280 }}
                        />
                    </div>
                    <div style={{ marginTop: 12 }}>
                        <button
                            className="sb-btn primary"
                            onClick={handleReplacementExport}
                            disabled={exportingReplace}
                        >
                            {exportingReplace
                                ? "Generando paquete…"
                                : "Crear paquete de reemplazo"}
                        </button>
                    </div>
                    {replacementFile && (
                        <div style={{ marginTop: 14 }}>
                            <p>
                                Paquete: <code>{replacementFile}</code>
                            </p>
                            <p className="sb-subtitle">
                                En la máquina nueva (STEPAD ya instalado),
                                copia el paquete y ejecuta como root:
                            </p>
                            <pre style={{ whiteSpace: "pre-wrap", background: "#f8fafc", padding: 10, borderRadius: 6 }}>
{`sudo bash /home/paulan/stepad-nsp/scripts/import-replacement.sh --dry-run /ruta/${replacementFile}
sudo bash /home/paulan/stepad-nsp/scripts/import-replacement.sh /ruta/${replacementFile}`}
                            </pre>
                        </div>
                    )}
                </div>
            </div>
            )}
        </div>
    );
}
