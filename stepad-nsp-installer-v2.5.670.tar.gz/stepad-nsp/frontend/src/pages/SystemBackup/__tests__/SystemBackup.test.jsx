import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import SystemBackup from "../SystemBackup";
import {
    exportReplacementBundle,
    getSystemBackupStatus,
    verifySystemRestore,
    getRollbackPoints,
    verifyRollbackPoints,
} from "../../../services/api";

vi.mock("../../../services/api", () => ({
    getSystemBackupStatus: vi.fn().mockResolvedValue({ enabled: true }),
    getSystemBackupConfig: vi.fn().mockResolvedValue({ destination: "local" }),
    listSystemBackupSnapshots: vi.fn().mockResolvedValue({ snapshots: [] }),
    detectSystemBackupUsb: vi.fn().mockResolvedValue({ available: false }),
    createSystemBackup: vi.fn(),
    saveSystemBackupConfig: vi.fn(),
    restoreSystemBackup: vi.fn(),
    exportReplacementBundle: vi.fn(),
    verifySystemRestore: vi.fn(),
    getRollbackPoints: vi.fn().mockResolvedValue({}),
    verifyRollbackPoints: vi.fn(),
}));

describe("SystemBackup paquete de reemplazo", () => {
    beforeEach(() => {
        exportReplacementBundle.mockReset();
        getRollbackPoints.mockResolvedValue({});
        URL.createObjectURL = vi.fn(() => "blob:test");
        URL.revokeObjectURL = vi.fn();
        HTMLAnchorElement.prototype.click = vi.fn();
    });

    it("genera el paquete y muestra las instrucciones", async () => {
        exportReplacementBundle.mockResolvedValue({
            blob: new Blob(["x"]),
            filename: "stepad-replacement-test.enc",
        });
        render(<SystemBackup />);

        fireEvent.click(await screen.findByRole("tab", { name: "Reemplazo de equipo" }));
        fireEvent.change(screen.getByLabelText("Frase de seguridad"), {
            target: { value: "FraseSegura123" },
        });
        fireEvent.change(screen.getByLabelText("Repetir frase"), {
            target: { value: "FraseSegura123" },
        });
        fireEvent.click(screen.getByRole("button", { name: "Crear paquete de reemplazo" }));

        expect(await screen.findByText(/Paquete generado/)).toBeInTheDocument();
        expect(screen.getByText("stepad-replacement-test.enc")).toBeInTheDocument();
        expect(screen.getByText(/import-replacement\.sh --dry-run/)).toBeInTheDocument();
        expect(exportReplacementBundle).toHaveBeenCalledWith("FraseSegura123");
    });

    it("muestra la verificación de restauración y permite ejecutarla", async () => {
        getSystemBackupStatus.mockResolvedValue({
            enabled: true,
            restore_verify: {
                success: true,
                tables: 52,
                last_run_at: "2026-11-08T19:46:32",
            },
        });
        verifySystemRestore.mockResolvedValue({
            success: true,
            message: "respaldo verificado",
        });
        render(<SystemBackup />);

        await screen.findByText("Verificación de restauración");
        expect(screen.getByText("OK")).toBeInTheDocument();
        expect(screen.getByText(/52 tablas/)).toBeInTheDocument();

        fireEvent.click(screen.getByRole("button", { name: "Verificar ahora" }));

        expect(await screen.findByText("respaldo verificado")).toBeInTheDocument();
        expect(verifySystemRestore).toHaveBeenCalled();
    });

    it("lista y verifica puntos de rollback", async () => {
        getRollbackPoints.mockResolvedValue({
            count: 1,
            ok: true,
            last_run_at: "2026-11-09T00:10:41",
            points: [
                {
                    name: "v2.5.491-20261108-190616",
                    version: "v2.5.491",
                    ok: true,
                    app_size: 1425245,
                    db_size: 206122964,
                },
            ],
        });
        verifyRollbackPoints.mockResolvedValue({
            ok: true,
            message: "1 punto(s) íntegros",
        });
        render(<SystemBackup />);

        expect(await screen.findByText("Puntos de retorno (1)")).toBeInTheDocument();
        expect(screen.getByText("v2.5.491-20261108-190616")).toBeInTheDocument();
        expect(screen.getAllByText("OK").length).toBeGreaterThan(0);

        fireEvent.click(screen.getByRole("button", { name: "Verificar integridad" }));

        expect(await screen.findByText("1 punto(s) íntegros")).toBeInTheDocument();
        expect(verifyRollbackPoints).toHaveBeenCalled();
    });

    it("rechaza frases distintas", async () => {
        render(<SystemBackup />);

        fireEvent.click(await screen.findByRole("tab", { name: "Reemplazo de equipo" }));
        fireEvent.change(screen.getByLabelText("Frase de seguridad"), {
            target: { value: "FraseSegura123" },
        });
        fireEvent.change(screen.getByLabelText("Repetir frase"), {
            target: { value: "OtraFrase123" },
        });
        fireEvent.click(screen.getByRole("button", { name: "Crear paquete de reemplazo" }));

        expect(await screen.findByText("Las frases no coinciden.")).toBeInTheDocument();
        expect(exportReplacementBundle).not.toHaveBeenCalled();
    });
});
