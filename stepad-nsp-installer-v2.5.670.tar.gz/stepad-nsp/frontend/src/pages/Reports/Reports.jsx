import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";

import {
    listVulnerabilityReports,
    listVulnerabilitySent,
    runVulnerabilityReport,
    downloadVulnerabilityReport,
    downloadVulnerabilitySent,
} from "../../services/api";
import { formatDateTime } from "../../utils/datetime";

import "../Shares/shares.css";

export default function Reports() {
    const [reports, setReports] = useState([]);
    const [sent, setSent] = useState([]);
    const [last, setLast] = useState(null);
    const [running, setRunning] = useState(false);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);

    const load = useCallback(async () => {
        try {
            const [listing, sentList] = await Promise.all([
                listVulnerabilityReports(),
                listVulnerabilitySent(),
            ]);
            setReports(listing?.reports || []);
            setSent(sentList?.sent || []);
        } catch (err) {
            setError(err.message || String(err));
        }
    }, []);

    useEffect(() => { load(); }, [load]);

    async function handleGenerate() {
        setRunning(true);
        setError(null);
        setNotice(null);
        try {
            const result = await runVulnerabilityReport(false);
            if (result?.success) {
                setLast(result);
                if (result.summary_pdf) {
                    await handleDownload(result.summary_pdf);
                }
            }
            setNotice(
                result?.success
                    ? `Informe generado · score ${result.score} · ${result.hosts ?? 0} equipos`
                    : `No se pudo generar: ${result?.message || "error"}`
            );
            await load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setRunning(false);
        }
    }

    async function handleDownload(name, fromSent = false) {
        if (!name) return;
        try {
            const blob = fromSent
                ? await downloadVulnerabilitySent(name)
                : await downloadVulnerabilityReport(name);
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = name;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(url);
        } catch (err) {
            setError(err.message || String(err));
        }
    }

    async function handleView(name) {
        if (!name) return;
        try {
            const blob = await downloadVulnerabilityReport(name);
            const url = URL.createObjectURL(new Blob([blob], { type: "text/html" }));
            const opened = window.open(url, "_blank");
            if (!opened) {
                setError("Permite ventanas emergentes para ver el informe.");
            }
            setTimeout(() => URL.revokeObjectURL(url), 60000);
        } catch (err) {
            setError(err.message || String(err));
        }
    }

    return (
        <div className="sh-page">
            <section className="sh-bk-panel">
                <header className="sh-bk-head">
                    <div>
                        <p className="sh-eyebrow">Reportes</p>
                        <h2>Vulnerabilidades de la red</h2>
                        <p className="sh-lede">
                            Genera y descarga el informe cuando lo necesites.
                            La programación de envío al responsable se configura
                            en Ajustes.
                        </p>
                    </div>
                </header>

                {error && <div className="sh-banner error">{error}</div>}
                {notice && <div className="sh-banner ok">{notice}</div>}

                <div className="sh-bk-body">
                    <div className="sh-actions" style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <button className="sh-btn primary" onClick={handleGenerate} disabled={running}>
                            {running ? "Evaluando…" : "Generar y descargar PDF"}
                        </button>
                        <Link className="sh-btn" to="/settings?tab=vulnerabilidades">
                            Programar envío / destinatarios
                        </Link>
                    </div>

                    {last?.summary_pdf && (
                        <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
                            <button className="sh-btn" onClick={() => handleDownload(last.summary_pdf)}>
                                PDF resumen
                            </button>
                            <button className="sh-btn" onClick={() => handleDownload(last.technical_pdf)}>
                                PDF técnico
                            </button>
                            <button className="sh-btn" onClick={() => handleView(last.summary_html)}>
                                Ver resumen
                            </button>
                            <button className="sh-btn" onClick={() => handleView(last.technical_html)}>
                                Ver técnico
                            </button>
                        </div>
                    )}
                </div>

                <div className="sh-bk-body">
                    <h3>Últimos informes</h3>
                    {reports.length === 0 ? (
                        <p className="sh-muted">Aún no hay informes generados.</p>
                    ) : (
                        reports.map((report) => (
                            <div key={report.id} className="sh-bk-job">
                                <div className="sh-bk-job-head">
                                    <strong>{formatDateTime(report.created_at)}</strong>
                                </div>
                                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                                    {report.summary_pdf && (
                                        <button className="sh-btn sh-btn-sm" onClick={() => handleDownload(report.summary_pdf)}>
                                            PDF resumen
                                        </button>
                                    )}
                                    {report.technical_pdf && (
                                        <button className="sh-btn sh-btn-sm" onClick={() => handleDownload(report.technical_pdf)}>
                                            PDF técnico
                                        </button>
                                    )}
                                    {report.summary_html && (
                                        <button className="sh-btn sh-btn-sm" onClick={() => handleView(report.summary_html)}>
                                            Ver resumen
                                        </button>
                                    )}
                                    {report.technical_html && (
                                        <button className="sh-btn sh-btn-sm" onClick={() => handleView(report.technical_html)}>
                                            Ver técnico
                                        </button>
                                    )}
                                    {report.summary && (
                                        <button className="sh-btn sh-btn-sm" onClick={() => handleDownload(report.summary)}>
                                            Excel resumen
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))
                    )}
                </div>

                <div className="sh-bk-body">
                    <h3>Correos enviados (evidencia)</h3>
                    {sent.length === 0 ? (
                        <p className="sh-muted">Aún no se han enviado correos.</p>
                    ) : (
                        sent.map((item) => (
                            <div key={item.id} className="sh-bk-job">
                                <div className="sh-bk-job-head">
                                    <strong>{formatDateTime(item.sent_at)}</strong>
                                    <span className="sh-muted">{item.to} · {item.success ? "Enviado" : "No enviado"}</span>
                                </div>
                                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                                    {item.files?.["email.html"]?.file && (
                                        <button
                                            className="sh-btn sh-btn-sm"
                                            onClick={() => handleDownload(item.files["email.html"].file, true)}
                                        >
                                            Ver correo
                                        </button>
                                    )}
                                    {item.files?.["resumen.xlsx"]?.file && (
                                        <button
                                            className="sh-btn sh-btn-sm"
                                            onClick={() => handleDownload(item.files["resumen.xlsx"].file, true)}
                                        >
                                            Adjunto resumen
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </section>
        </div>
    );
}
