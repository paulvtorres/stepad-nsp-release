import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    createApiToken,
    getApiTokens,
    revokeApiToken,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";


const EMPTY = { name: "", role: "OPERATOR", expires_at: "" };


export default function ApiTokensSection() {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";
    const [items, setItems] = useState([]);
    const [form, setForm] = useState(EMPTY);
    const [created, setCreated] = useState(null);
    const [error, setError] = useState("");
    const [busy, setBusy] = useState(false);


    async function load() {

        try {
            const result = await getApiTokens();
            setItems(result?.tokens || []);
        } catch (err) {
            setError(err.message || "No se pudieron cargar los tokens.");
        }

    }


    useEffect(() => {
        load();
    }, []);


    async function submit(event) {

        event.preventDefault();

        if (!isAdmin) return;

        setBusy(true);
        setError("");

        try {

            const result = await createApiToken({
                ...form,
                expires_at: form.expires_at || null,
            });

            setCreated(result);
            setForm(EMPTY);
            await load();

        } catch (err) {

            setError(err.message || "No se pudo crear el token.");

        } finally {

            setBusy(false);

        }

    }


    async function revoke(item) {

        if (!isAdmin) return;
        if (!window.confirm(`¿Revocar el token "${item.name}"?`)) return;

        setBusy(true);

        try {

            await revokeApiToken(item.id);
            await load();

        } catch (err) {

            setError(err.message || "No se pudo revocar el token.");

        } finally {

            setBusy(false);

        }

    }


    return (
        <SettingsPanel
            title="Tokens de API"
            lead="Tokens para automatización y scripts. Se muestran una sola vez; en la base solo queda un hash. Usá el rol mínimo necesario."
            badge={`${items.filter((item) => item.enabled).length} activos`}
            badgeVariant="complete"
            error={error}
        >
            {created?.token && (
                <SettingsBlock title="Token creado" first>
                    <p className="org-section-hint">
                        Copialo ahora. No se volverá a mostrar.
                    </p>
                    <pre className="api-token-raw">{created.token}</pre>
                    <SettingsActions>
                        <button
                            type="button"
                            className="secondary-button"
                            onClick={() => navigator.clipboard?.writeText(created.token)}
                        >
                            Copiar token
                        </button>
                        <button
                            type="button"
                            className="secondary-button"
                            onClick={() => setCreated(null)}
                        >
                            Ocultar
                        </button>
                    </SettingsActions>
                </SettingsBlock>
            )}

            <SettingsBlock title="Tokens existentes">
                {items.length === 0 ? (
                    <p className="org-section-hint">Sin tokens creados.</p>
                ) : (
                    <div className="table-card">
                        <table className="protection-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Prefijo</th>
                                    <th>Rol</th>
                                    <th>Último uso</th>
                                    <th>Expira</th>
                                    <th>Estado</th>
                                    <th />
                                </tr>
                            </thead>
                            <tbody>
                                {items.map((item) => (
                                    <tr key={item.id}>
                                        <td>{item.name}</td>
                                        <td>{item.prefix}…</td>
                                        <td>{item.role}</td>
                                        <td>{item.last_used_at ? new Date(item.last_used_at).toLocaleString() : "nunca"}</td>
                                        <td>{item.expires_at ? new Date(item.expires_at).toLocaleString() : "sin vencimiento"}</td>
                                        <td>{item.enabled && !item.revoked_at ? "Activo" : "Revocado"}</td>
                                        <td>
                                            {isAdmin && item.enabled && (
                                                <button
                                                    type="button"
                                                    className="secondary-button danger"
                                                    onClick={() => revoke(item)}
                                                    disabled={busy}
                                                >
                                                    Revocar
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </SettingsBlock>

            {isAdmin && (
                <SettingsBlock title="Crear token">
                    <form onSubmit={submit}>
                        <div className="org-form-grid">
                            <label>
                                Nombre
                                <input
                                    value={form.name}
                                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                                    placeholder="monitoreo-externo"
                                    required
                                />
                            </label>
                            <label>
                                Rol
                                <select
                                    value={form.role}
                                    onChange={(e) => setForm({ ...form, role: e.target.value })}
                                >
                                    <option value="OPERATOR">Operador (solo lectura/operación)</option>
                                    <option value="ADMIN">Administrador</option>
                                </select>
                            </label>
                            <label>
                                Expira (opcional)
                                <input
                                    type="datetime-local"
                                    value={form.expires_at}
                                    onChange={(e) => setForm({ ...form, expires_at: e.target.value })}
                                />
                            </label>
                        </div>
                        <SettingsActions>
                            <button type="submit" className="primary-button" disabled={busy}>
                                {busy ? "Creando…" : "Crear token"}
                            </button>
                        </SettingsActions>
                    </form>
                </SettingsBlock>
            )}
        </SettingsPanel>
    );

}
