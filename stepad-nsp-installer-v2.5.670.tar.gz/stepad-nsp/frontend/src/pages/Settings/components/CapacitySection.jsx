import { useEffect, useState } from "react";

import { getMonitoringSettings, saveMonitoringSettings } from "../../../services/api";
import { SettingsPanel, SettingsBlock, SettingsActions } from "./SettingsPanel";


export default function CapacitySection() {
    const [cpu, setCpu] = useState(90);
    const [ram, setRam] = useState(90);
    const [disk, setDisk] = useState(90);
    const [windowMinutes, setWindowMinutes] = useState(10);
    const [diskFreeMin, setDiskFreeMin] = useState(5);
    const [rogueScanEnabled, setRogueScanEnabled] = useState(true);
    const [rogueScanMinutes, setRogueScanMinutes] = useState(15);
    const [deviceArchiveDays, setDeviceArchiveDays] = useState(30);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");

    useEffect(() => {
        getMonitoringSettings()
            .then((data) => {
                setCpu(Number(data?.cpu_threshold) || 90);
                setRam(Number(data?.ram_threshold) || 90);
                setDisk(Number(data?.disk_threshold) || 90);
                setWindowMinutes(Number(data?.window_minutes) || 10);
                setDiskFreeMin(Number(data?.disk_free_min_gb) || 5);
                setRogueScanEnabled(data?.rogue_dhcp_scan_enabled !== false);
                setRogueScanMinutes(Number(data?.rogue_dhcp_scan_minutes) || 15);
                setDeviceArchiveDays(Number(data?.device_archive_days) || 30);
            })
            .catch((err) => setError(err.message || "No se pudieron leer los ajustes."));
    }, []);

    async function handleSave() {
        setBusy(true);
        setError("");
        setNotice("");
        try {
            const data = await saveMonitoringSettings({
                cpu_threshold: Number(cpu),
                ram_threshold: Number(ram),
                disk_threshold: Number(disk),
                window_minutes: Number(windowMinutes),
                disk_free_min_gb: Number(diskFreeMin),
                rogue_dhcp_scan_enabled: rogueScanEnabled,
                rogue_dhcp_scan_minutes: Number(rogueScanMinutes),
                device_archive_days: Number(deviceArchiveDays),
            });
            setCpu(Number(data.cpu_threshold) || 90);
            setRam(Number(data.ram_threshold) || 90);
            setDisk(Number(data.disk_threshold) || 90);
            setWindowMinutes(Number(data.window_minutes) || 10);
            setDiskFreeMin(Number(data.disk_free_min_gb) || 5);
            setRogueScanEnabled(data.rogue_dhcp_scan_enabled !== false);
            setRogueScanMinutes(Number(data.rogue_dhcp_scan_minutes) || 15);
            setDeviceArchiveDays(Number(data.device_archive_days) || 30);
            setNotice("Ajustes de capacidad guardados.");
        } catch (err) {
            setError(err?.response?.data?.detail || err.message || "No se pudo guardar.");
        } finally {
            setBusy(false);
        }
    }

    return (
        <SettingsPanel
            title="Capacidad del servidor"
            lead="El NSP alerta cuando el consumo se mantiene alto durante la ventana configurada, no por picos momentáneos."
            badge="Configurable"
            error={error}
            notice={notice}
        >
            <SettingsBlock title="Umbrales de alerta" hint="Porcentaje sostenido que se considera capacidad insuficiente." first>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }}>
                    <label>CPU (%)
                        <input type="number" min="50" max="100" value={cpu} onChange={(e) => setCpu(e.target.value)} />
                    </label>
                    <label>Memoria (%)
                        <input type="number" min="50" max="100" value={ram} onChange={(e) => setRam(e.target.value)} />
                    </label>
                    <label>Disco (%)
                        <input type="number" min="50" max="100" value={disk} onChange={(e) => setDisk(e.target.value)} />
                    </label>
                    <label>Ventana de sostenimiento (min)
                        <input type="number" min="1" max="60" value={windowMinutes} onChange={(e) => setWindowMinutes(e.target.value)} />
                    </label>
                    <label>Disco libre mínimo (GB)
                        <input type="number" min="1" max="1000" value={diskFreeMin} onChange={(e) => setDiskFreeMin(e.target.value)} />
                    </label>
                    <label>Archivar dispositivos sin IP (días)
                        <input type="number" min="1" max="365" value={deviceArchiveDays} onChange={(e) => setDeviceArchiveDays(e.target.value)} />
                    </label>
                    <label>Escanear DHCP no autorizado cada (min)
                        <input type="number" min="5" max="120" value={rogueScanMinutes} onChange={(e) => setRogueScanMinutes(e.target.value)} disabled={!rogueScanEnabled} />
                    </label>
                </div>
                <label className="dhcp-toggle-row" style={{ marginTop: 12 }}>
                    <input type="checkbox" checked={rogueScanEnabled} onChange={(e) => setRogueScanEnabled(e.target.checked)} />
                    Escaneo automático de DHCP no autorizado
                </label>
            </SettingsBlock>
            <SettingsActions>
                <button type="button" className="primary-button" disabled={busy} onClick={handleSave}>
                    {busy ? "Guardando…" : "Guardar capacidad"}
                </button>
            </SettingsActions>
        </SettingsPanel>
    );
}
