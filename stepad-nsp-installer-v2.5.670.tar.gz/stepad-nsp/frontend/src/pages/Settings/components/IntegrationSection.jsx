import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getSyslogSettings,
    saveSyslogSettings,
    testSyslog,
    getLogsReview,
    saveLogsReview,
    markLogsReview,
    getWebhooks,
    createWebhook,
    deleteWebhook,
} from "../../../services/api";

import { formatDateTime } from "../../../utils/datetime";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function IntegrationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [syslog, setSyslog] = useState({
        enabled: false,
        server: "",
        port: 514,
        protocol: "udp",
    });

    const [reviewerEmail, setReviewerEmail] = useState("");

    const [reviewFreq, setReviewFreq] = useState(7);

    const [reviewLast, setReviewLast] = useState(null);

    const [reviewOverdue, setReviewOverdue] = useState(false);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);

    const [loading, setLoading] = useState(true);

    const [webhooks, setWebhooks] = useState([]);

    const [webhookForm, setWebhookForm] = useState({
        name: "",
        url: "",
        events: "*",
    });

    const [webhookSecret, setWebhookSecret] = useState(null);


    useEffect(() => {

        let cancelled = false;

        Promise.all([
            getSyslogSettings(),
            getLogsReview().catch(() => null),
        ])

            .then(([syslogData, reviewData]) => {

                if (cancelled) return;

                setSyslog({
                    enabled: syslogData.enabled,
                    server: syslogData.server || "",
                    port: syslogData.port,
                    protocol: syslogData.protocol || "udp",
                });

                if (reviewData) {
                    setReviewerEmail(reviewData.reviewer_email || "");
                    setReviewFreq(reviewData.frequency_days || 7);
                    setReviewLast(reviewData.last_review);
                    setReviewOverdue(reviewData.overdue);
                }

            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => { cancelled = true; };

    }, []);


    useEffect(() => {

        getWebhooks()
            .then((result) => setWebhooks(result?.webhooks || []))
            .catch(() => {});

    }, []);


    async function handleCreateWebhook(event) {

        event.preventDefault();

        setBusy(true);
        setError(null);
        setNotice(null);

        try {

            const result = await createWebhook(webhookForm);
            setWebhookSecret(result.secret);
            setWebhookForm({ name: "", url: "", events: "*" });
            const data = await getWebhooks();
            setWebhooks(data?.webhooks || []);
            setNotice("Webhook creado. Copiá el secreto antes de cerrar.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDeleteWebhook(item) {

        if (!window.confirm(`¿Eliminar el webhook "${item.name}"?`)) return;

        setBusy(true);

        try {

            await deleteWebhook(item.id);
            const data = await getWebhooks();
            setWebhooks(data?.webhooks || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveSyslog() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveSyslogSettings({
                enabled: syslog.enabled,
                server: syslog.server,
                port: Number(syslog.port),
                protocol: syslog.protocol,
            });

            setSyslog((previous) => ({
                ...previous,
                enabled: saved.enabled,
            }));

            setNotice("Configuración SIEM guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleTestSyslog() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await testSyslog();

            setNotice(result.message || "Mensaje de prueba enviado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }



    async function handleSaveReviewer() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveLogsReview({
                reviewer_email: reviewerEmail,
                frequency_days: Number(reviewFreq),
            });

            setReviewLast(saved.last_review);

            setReviewOverdue(saved.overdue);

            setNotice("Responsable de revisión guardado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleMarkReview() {

        setBusy(true);

        try {

            const saved = await markLogsReview();

            setReviewLast(saved.last_review);

            setReviewOverdue(saved.overdue);

            setNotice("Revisión de logs marcada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const badge = loading
        ? "Cargando…"
        : syslog.enabled
            ? "SIEM activo"
            : "Sin SIEM";

    const badgeVariant = loading
        ? ""
        : syslog.enabled
            ? "complete"
            : "partial";


    return (

        <SettingsPanel
            title="Integraciones y cumplimiento"
            lead="Conecta el NSP con tu SIEM y designa quién revisa los logs periódicamente."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Syslog"
                    value={syslog.enabled ? "Enviando" : "Desactivado"}
                    meta={syslog.server ? `${syslog.server}:${syslog.port}` : "Sin servidor configurado"}
                    variant={syslog.enabled ? "ok" : "muted"}
                />

                <SettingsStatusCard
                    label="Revisión de logs"
                    value={reviewOverdue ? "Pendiente" : reviewLast ? "Al día" : "Sin registrar"}
                    meta={reviewLast
                        ? `Última: ${formatDateTime(reviewLast)}`
                        : reviewerEmail || "Sin responsable"}
                    variant={reviewOverdue ? "warn" : reviewLast ? "ok" : "muted"}
                />

            </SettingsStatusGrid>

            <SettingsBlock
                title="Integración SIEM (Syslog)"
                hint="Reenvía eventos de seguridad a tu SOC (Splunk, Elastic, Graylog…) por syslog."
                first
            >

                <label className="org-checkbox-row">
                    <input
                        type="checkbox"
                        checked={syslog.enabled}
                        disabled={!isAdmin}
                        onChange={(e) => setSyslog({ ...syslog, enabled: e.target.checked })}
                    />
                    Reenvío a SIEM habilitado
                </label>

                <div className="org-form-grid">

                    <label>
                        Servidor syslog
                        <input
                            type="text"
                            value={syslog.server}
                            disabled={!isAdmin}
                            onChange={(e) => setSyslog({ ...syslog, server: e.target.value })}
                            placeholder="ej. 10.0.0.10"
                        />
                    </label>

                    <label>
                        Puerto
                        <input
                            type="number"
                            value={syslog.port}
                            disabled={!isAdmin}
                            onChange={(e) => setSyslog({ ...syslog, port: e.target.value })}
                            placeholder="514"
                        />
                    </label>

                    <label>
                        Protocolo
                        <select
                            value={syslog.protocol}
                            disabled={!isAdmin}
                            onChange={(e) => setSyslog({ ...syslog, protocol: e.target.value })}
                        >
                            <option value="udp">UDP</option>
                            <option value="tcp">TCP</option>
                        </select>
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleSaveSyslog}
                        disabled={busy || !isAdmin}
                    >
                        {busy ? "Guardando…" : "Guardar SIEM"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleTestSyslog}
                        disabled={busy || !isAdmin}
                    >
                        Enviar prueba
                    </button>

                </SettingsActions>

            </SettingsBlock>

            <SettingsBlock
                title="Webhooks de alertas"
                hint="Envía alertas a n8n, Slack, SIEM u otro sistema. Cada entrega lleva firma HMAC-SHA256."
            >
                {webhookSecret && (
                    <div className="maintenance-warning">
                        Secreto del webhook (se muestra una sola vez):
                        <pre className="api-token-raw">{webhookSecret}</pre>
                    </div>
                )}

                {webhooks.length === 0 ? (
                    <p className="org-section-hint">Sin webhooks configurados.</p>
                ) : (
                    <ul className="email-usage-list">
                        {webhooks.map((item) => (
                            <li key={item.id}>
                                <strong>{item.name}</strong> · {item.url} · eventos: {item.events}
                                {item.last_error ? ` · último error: ${item.last_error}` : ""}
                                {isAdmin && (
                                    <button
                                        type="button"
                                        className="secondary-button danger"
                                        onClick={() => handleDeleteWebhook(item)}
                                        disabled={busy}
                                        style={{ marginLeft: 10 }}
                                    >
                                        Eliminar
                                    </button>
                                )}
                            </li>
                        ))}
                    </ul>
                )}

                {isAdmin && (
                    <form onSubmit={handleCreateWebhook}>
                        <div className="org-form-grid">
                            <label>
                                Nombre
                                <input
                                    value={webhookForm.name}
                                    onChange={(e) => setWebhookForm({ ...webhookForm, name: e.target.value })}
                                    placeholder="n8n / SIEM"
                                    required
                                />
                            </label>
                            <label>
                                URL
                                <input
                                    type="url"
                                    value={webhookForm.url}
                                    onChange={(e) => setWebhookForm({ ...webhookForm, url: e.target.value })}
                                    placeholder="https://servidor/webhook"
                                    required
                                />
                            </label>
                            <label>
                                Eventos
                                <input
                                    value={webhookForm.events}
                                    onChange={(e) => setWebhookForm({ ...webhookForm, events: e.target.value })}
                                    placeholder="* o quarantine,DHCP_POOL_LOW"
                                />
                            </label>
                        </div>
                        <SettingsActions>
                            <button type="submit" className="primary-button" disabled={busy}>
                                {busy ? "Creando…" : "Crear webhook"}
                            </button>
                        </SettingsActions>
                    </form>
                )}
            </SettingsBlock>

            <SettingsBlock
                title="Responsable de revisión de logs"
                hint="Persona designada para revisar periódicamente los registros de auditoría."
            >

                {
                    reviewOverdue && (
                        <div className="org-warning-banner">
                            Revisión de logs pendiente (más de {reviewFreq} días).
                        </div>
                    )
                }

                <div className="org-form-grid">

                    <label>
                        Correo del responsable
                        <input
                            type="email"
                            value={reviewerEmail}
                            disabled={!isAdmin}
                            onChange={(e) => setReviewerEmail(e.target.value)}
                            placeholder="admin@empresa.com"
                        />
                    </label>

                    <label>
                        Recordatorio cada (días)
                        <input
                            type="number"
                            min={1}
                            max={365}
                            value={reviewFreq}
                            disabled={!isAdmin}
                            onChange={(e) => setReviewFreq(e.target.value)}
                        />
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleSaveReviewer}
                        disabled={busy || !isAdmin}
                    >
                        Guardar responsable
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleMarkReview}
                        disabled={busy || !isAdmin}
                    >
                        Marcar revisión hecha
                    </button>

                </SettingsActions>

            </SettingsBlock>

        </SettingsPanel>

    );

}


export default IntegrationSection;
