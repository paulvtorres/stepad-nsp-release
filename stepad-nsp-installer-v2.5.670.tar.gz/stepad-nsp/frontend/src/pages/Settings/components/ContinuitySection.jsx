import { useEffect, useState } from "react";

import { getDisasterRecovery } from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
} from "./SettingsPanel";


export default function ContinuitySection() {

    const [state, setState] = useState(null);
    const [error, setError] = useState("");


    useEffect(() => {

        getDisasterRecovery()
            .then(setState)
            .catch((err) => setError(err.message || "No se pudo cargar DR."));

    }, []);


    if (error) {
        return (
            <SettingsPanel title="Continuidad / DR" error={error} badge="Error" badgeVariant="warn">
                <p className="org-section-hint">No se pudo consultar el estado.</p>
            </SettingsPanel>
        );
    }

    if (!state) {
        return (
            <SettingsPanel title="Continuidad / DR" badge="Cargando…">
                <p className="org-section-hint">Consultando respaldos y restauración…</p>
            </SettingsPanel>
        );
    }

    return (
        <SettingsPanel
            title="Continuidad / DR"
            lead="Estado de recuperación ante desastre basado en respaldos reales y pruebas de restauración. La HA activa con un segundo nodo requiere infraestructura adicional."
            badge={state.ready ? "Listo para recuperar" : "Requiere atención"}
            badgeVariant={state.ready ? "complete" : "warn"}
        >
            <SettingsStatusGrid>
                <SettingsStatusCard
                    label="RPO"
                    value={state.rpo_minutes == null ? "—" : `${state.rpo_minutes} min`}
                    meta={`Objetivo ≤ ${state.rpo_target_minutes} min`}
                    variant={state.ready ? "ok" : "warn"}
                />
                <SettingsStatusCard
                    label="Restauración"
                    value={state.ready ? "Probada" : "Pendiente"}
                    meta="Última verificación real"
                    variant={state.ready ? "ok" : "warn"}
                />
                <SettingsStatusCard
                    label="Modo"
                    value="DR"
                    meta="La HA activa requiere segundo nodo"
                />
            </SettingsStatusGrid>

            <SettingsBlock title="Controles" first>
                <ul className="email-usage-list">
                    {(state.checks || []).map((check) => (
                        <li key={check.key}>
                            <strong>
                                {check.ok ? "OK" : "PENDIENTE"} · {check.label}
                            </strong>
                            <div className="org-section-hint">{check.detail}</div>
                            {!check.ok && check.action && (
                                <div className="org-section-hint">{check.action}</div>
                            )}
                        </li>
                    ))}
                </ul>
            </SettingsBlock>

            {state.recommendations?.length > 0 && (
                <SettingsBlock title="Recomendaciones">
                    <ul className="email-usage-list">
                        {state.recommendations.map((item) => (
                            <li key={item}>{item}</li>
                        ))}
                    </ul>
                </SettingsBlock>
            )}

            <SettingsBlock title="Runbook mínimo">
                <ol className="email-usage-list">
                    <li>Ejecutar un respaldo completo y confirmar el destino.</li>
                    <li>Ejecutar verificación real de restauración.</li>
                    <li>Si el NSP no arranca: usar rollback o restaurar el sistema desde el último respaldo.</li>
                    <li>Validar DB, DHCP, DNS, panel y correo después de recuperar.</li>
                </ol>
            </SettingsBlock>

        </SettingsPanel>
    );

}
