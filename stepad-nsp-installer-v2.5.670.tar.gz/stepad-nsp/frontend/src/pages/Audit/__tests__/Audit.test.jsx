import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import Audit from "../Audit";
import { verifyAuditChain } from "../../../services/api";

vi.mock("../../../services/api", () => ({
    getAuditLogs: vi.fn().mockResolvedValue([]),
    exportComplianceReport: vi.fn(),
    verifyAuditChain: vi.fn(),
}));

describe("Audit verificación de integridad", () => {
    beforeEach(() => {
        verifyAuditChain.mockReset();
    });

    it("muestra la cadena íntegra", async () => {
        verifyAuditChain.mockResolvedValue({ ok: true, checked: 5, legacy: 2 });
        render(<Audit />);

        const button = await screen.findByRole("button", { name: "Verificar integridad" });
        fireEvent.click(button);

        expect(await screen.findByText(/Cadena íntegra: 5 registro\(s\) verificado\(s\)/))
            .toBeInTheDocument();
        expect(screen.getByText(/2 registro\(s\) antiguos sin cadena/)).toBeInTheDocument();
    });

    it("muestra dónde se rompió la cadena", async () => {
        verifyAuditChain.mockResolvedValue({ ok: false, checked: 3, broken_at: 42 });
        render(<Audit />);

        fireEvent.click(await screen.findByRole("button", { name: "Verificar integridad" }));

        expect(await screen.findByText(/Cadena rota en el registro 42/)).toBeInTheDocument();
    });
});
