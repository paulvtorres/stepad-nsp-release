import { useEffect, useRef, useState } from "react";

import {
    createShareBackup,
    updateShareBackup,
    runShareBackup,
    skipShareBackup,
    pruneShareBackup,
    getShareBackupSnapshots,
    getShareBackupHistory,
    getShareBackupSnapshotFiles,
    restoreShareBackup,
} from "../../services/api";

import { getToken } from "../../auth/authStorage";
import UnreadableBackupAlert from "../../components/backups/UnreadableBackupAlert";

const _API_URL = import.meta.env.VITE_API_URL || "/api/v1";

async function fetchSilent(endpoint, options) {
    const token = getToken();
    const sep = endpoint.includes("?") ? "&" : "?";
    const response = await fetch(`${_API_URL}${endpoint}${sep}_t=${Date.now()}`, {
        cache: "no-store",
        method: (options && options.method) || "GET",
        headers: {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
        },
    });
if (!response.ok) throw new Error(`API Error ${response.status}`);
    return response.json();
}

function isErrorResult(result) {
    if (!result) return false;
    const r = String(result).toLowerCase();
    // La desactivación mientras corre NO es un error (es una pausa).
    if (r.includes("pausado") || r.includes("se desactivó")) return false;
    return r.includes("error") || r.includes("falló") || r.includes("fallo")
        || r.includes("fatal") || r.includes("no se pudo") || r.includes("abort")
        || r.includes("failed") || r.includes("cancelled") || r.includes("cancelado")
        || r.includes("cancel") || r.includes("no se pudo");
}

function isCancelledResult(result) {
    if (!result) return false;
    const r = String(result).toLowerCase();
    return r.includes("cancel") || r.includes("pausado") || r.includes("se desactivó");
}

function fmtDuration(seconds) {
    if (seconds == null || isNaN(seconds)) return "";
    const s = Math.round(seconds);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${sec}s`;
    return `${sec}s`;
}

function summarizeResult(result) {
    if (!result) return "";
    let text = String(result).trim();
    // Restic JSON errors: extract the message
    const m = text.match(/"message"\s*:\s*"([^"]+)"/);
    if (m) {
        return m[1].slice(0, 300);
    }
    // Single-line JSON: show first meaningful part
    if (text.startsWith("{")) {
        return text.slice(0, 300);
    }
    return text.length > 300 ? text.slice(0, 300) + "..." : text;
}

export default function ShareBackupsPanel({ anchorSource = null, destinationVaults = [], folders = [] }) {
    // El ancla puede venir como string (path) o como objeto
    // {path, folderId, jobId} para enlazar por job aunque el path
    // no coincida textualmente (hardlinks, montajes).
    const anchorPath = typeof anchorSource === "string" ? anchorSource : (anchorSource?.path || null);
    const anchorJobId = typeof anchorSource === "object" ? (anchorSource?.jobId || null) : null;
    const anchor = anchorPath;

    const [data, setData] = useState(null);   // { installed, store_*, jobs }
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);
    const [progress, setProgress] = useState({});

    const [form, setForm] = useState(() => {
        return {
            name: "",
            source_path: "",
            destination_path: "",
            schedule_mode: "daily",
            schedule_times: ["13:30", "18:00"],
            schedule_hour: "13",
            schedule_minute: "30",
            retention_count: "7",
            prune_free_pct: "15",
        };
    });

    const [editingId, setEditingId] = useState(null);   // job existente en edición
    const prefilledSource = useRef(null);               // fuente ya cargada en el form

    const [snapOpen, setSnapOpen] = useState(null);          // jobId
    const [snapshots, setSnapshots] = useState({});          // jobId -> list
    const [snapLoading, setSnapLoading] = useState(null);    // jobId
    const [histOpen, setHistOpen] = useState(null);          // jobId
    const [history, setHistory] = useState({});              // jobId -> list
    const [histLoading, setHistLoading] = useState(null);
    const [spaceInfo, setSpaceInfo] = useState(null);    // jobId
    const [browse, setBrowse] = useState(null);
    const [browseLoading, setBrowseLoading] = useState(false);
    const [restorePending, setRestorePending] = useState(null); // {job, snap}
    const [restoreProgress, setRestoreProgress] = useState(null); // {target, running, progress, message}
    // Folder browser
    const [folderBrowserOpen, setFolderBrowserOpen] = useState(false);
    const [folderBrowserPath, setFolderBrowserPath] = useState("/mnt");
    const [folderBrowserItems, setFolderBrowserItems] = useState([]);
    const [folderBrowserLoading, setFolderBrowserLoading] = useState(false);
    const [folderBrowserError, setFolderBrowserError] = useState(null);
    const [folderBrowserTarget, setFolderBrowserTarget] = useState("destination");

    // Folder browser
    useEffect(() => {
        if (!notice) return undefined;
        const timer = setTimeout(() => setNotice(null), 6000);
        return () => clearTimeout(timer);
    }, [notice]);

    useEffect(() => {
        if (!error) return undefined;
        const timer = setTimeout(() => setError(null), 8000);
        return () => clearTimeout(timer);
    }, [error]);

    function jobForSource(source) {
        if (!source || !data?.jobs) return null;
        return data.jobs.find((j) => j.source_path === source) || null;
    }

    const editJob = editingId
        ? (data?.jobs || []).find((j) => j.id === editingId) || null
        : null;

    const formSource = (editJob
        ? editJob.source_path
        : (form.source_path || anchor || "").trim()) || "";

    // Al elegir la fuente (carpeta anclada o combo) se precarga el job que ya
    // exista para esa ruta: una sola programación por respaldo se edita y
    // nunca se duplica. El guard evita pisar la selección del usuario en los
    // polls (el origen NO se reescribe una vez elegido).
    useEffect(() => {
        const id = setTimeout(() => {
            const source = (form.source_path || anchor || "").trim();
            if (!source || !data) return;
            if (prefilledSource.current === source) return;
            prefilledSource.current = source;
            const existing = data.jobs.find((j) => j.source_path === source) || null;
            if (existing) {
                setEditingId(existing.id);
                setForm((f) => ({
                    ...f,
                    source_path: existing.source_path || f.source_path,
                    schedule_mode: existing.schedule_mode || f.schedule_mode,
                    schedule_times:
                        existing.schedule_times && existing.schedule_times.length > 0
                            ? existing.schedule_times
                            : f.schedule_times,
                    schedule_hour: String(existing.schedule_hour ?? f.schedule_hour),
                    schedule_minute: String(existing.schedule_minute ?? f.schedule_minute),
                    retention_count: String(existing.retention_count ?? f.retention_count),
                    prune_free_pct: String(existing.prune_free_pct ?? f.prune_free_pct),
                }));
            } else {
                setEditingId(null);
            }
        }, 0);
        return () => clearTimeout(id);
    }, [anchor, form.source_path, data]);

    function load() {
        return fetchSilent("/shares/backups")
            .then(setData)
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(() => {
            fetchSilent("/shares/backups")
                .then(setData)
                .catch(() => {});
        }, 30000);
        return () => clearInterval(timer);
    }, []);

    // Destino por defecto: si hay UNA sola partición de respaldo, se
    // preselecciona automáticamente (sin pedir elegir). Al crear (no
    // editando) y mientras el usuario no haya elegido otro destino.
    const autoDestRef = useRef(false);
    useEffect(() => {
        if (editJob) return;
        if (!data) return;
        const backups = (destinationVaults || []).filter((d) => d.path);
        if (backups.length !== 1) return;
        if (autoDestRef.current) return;
        if (form.destination_path && form.destination_path !== backups[0].path) return;
        autoDestRef.current = true;
        setForm((f) => ({ ...f, destination_path: backups[0].path }));
    }, [data, editJob, destinationVaults, form.destination_path]);

    // Poll progress for running backups
    useEffect(() => {
        const runningJobs = (data?.jobs || []).filter(j => j.running);
        if (runningJobs.length === 0) return;

        const timer = setInterval(() => {
            for (const job of runningJobs) {
                fetchSilent(`/shares/backups/${job.id}/progress`)
                    .then(p => setProgress(prev => ({ ...prev, [job.id]: p })))
                    .catch(() => {});
            }
        }, 2000);
        return () => clearInterval(timer);
    }, [data?.jobs]);

    // Chequeo de espacio del destino (advertencia, el backend bloquea al guardar):
    // se mide el origen y se compara con lo libre de la carpeta destino elegida.
    const checkSource = (form.source_path || anchor || "").trim();
    const checkDest = (form.destination_path || "").trim();
    useEffect(() => {
        if (editJob || !checkSource || !checkDest) {
            const reset = setTimeout(() => setSpaceInfo(null), 0);
            return () => clearTimeout(reset);
        }
        const handler = setTimeout(async () => {
            try {
                const res = await fetchSilent(
                    `/shares/backups/space-check?source=${encodeURIComponent(checkSource)}&destination=${encodeURIComponent(checkDest)}`
                );
                setSpaceInfo(res);
            } catch {
                setSpaceInfo(null);
            }
        }, 600);
        return () => clearTimeout(handler);
    }, [editJob, checkSource, checkDest]);

    async function handleCreate(event) {
        event.preventDefault();
        const source = editJob
            ? editJob.source_path
            : (form.source_path || anchor || "").trim();
        if (!source) {
            setError("Indica la ruta a respaldar (ej. una unidad compartida).");
            return;
        }
        // El destino NO es obligatorio: el sistema lo elige solo (la carpeta
        // de respaldo de una unidad local con espacio). El usuario no
        // necesita conocer internamente dónde se guarda.
        const destination = (form.destination_path || "").trim();
        const existing = editJob || jobForSource(source);
        // Al EDITAR SOLO el horario no se reenvía el origen: el job ya tiene
        // su fuente fijada (para la red, desmontada por demanda, revalidarla
        // al guardar fallaría aunque sea el mismo origen).
        const payload = {
            name: form.name.trim() || undefined,
            source_path: existing ? undefined : source,
            destination_path: editJob ? undefined : (destination || undefined),
            schedule_mode: form.schedule_mode || "daily",
            schedule_hour: Number(form.schedule_hour) || 13,
            schedule_minute: Number(form.schedule_minute) || 30,
            schedule_times: form.schedule_times || undefined,
            retention_count: Number(form.retention_count) || 7,
            prune_free_pct: Number(form.prune_free_pct) || 15,
            smb_user: undefined,
            smb_password: undefined,
        };
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            if (existing) {
                await updateShareBackup(existing.id, payload);
                setNotice("Respaldo actualizado.");
            } else {
                await createShareBackup(payload);
                setNotice("Respaldo creado.");
            }
            setForm({
                name: "",
                source_path: anchor || "",
                destination_path: "",
                schedule_mode: "daily",
                schedule_times: ["13:30", "18:00"],
                schedule_hour: "13",
                schedule_minute: "30",
                retention_count: "7",
                prune_free_pct: "15",
            });
            await load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleRun(job) {
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const res = await runShareBackup(job.id);
            await load();
            if (res && res.skipped) {
                setNotice("Sin cambios desde el último respaldo. No se creó versión.");
            } else {
                setNotice("Respaldo ejecutado.");
            }
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleSkip(job) {
        if (job.running) {
            if (!window.confirm(
                "Hay un respaldo en curso.\n\n" +
                "«Saltar a próx. horario» lo cancelará ahora y el próximo " +
                "respaldo correrá en el siguiente horario programado. " +
                "Lo ya respaldado se conserva (restic retoma sin resubir)."
            )) {
                return;
            }
        }
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const res = await skipShareBackup(job.id);
            await load();
            if (res?.cancelled) {
                setNotice(
                    `Respaldo en curso cancelado. Próximo respaldo: ${res.next_label}.`
                );
            } else {
                setNotice(
                    res?.next_label
                        ? `Programación saltada. Próximo respaldo: ${res.next_label}.`
                        : "Programación saltada."
                );
            }
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handlePrune(job) {
        if (!window.confirm(
            `¿Compactar el repositorio de «${job.name}»?\n\n`
            + `Se borran las versiones más antiguas y solo las ${job.retention_count} más recientes quedan.`
        )) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const result = await pruneShareBackup(job.id);
            await load();
            setNotice(result?.message || "Repositorio compactado.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleToggle(job) {
        const willDisable = job.enabled;
        if (willDisable && job.running) {
            if (!window.confirm(
                "Hay un respaldo en curso.\n\n" +
                "«Desactivar» lo cancelará ahora y este respaldo quedará " +
                "apagado hasta que lo vuelvas a activar. Lo ya respaldado " +
                "se conserva (restic retoma sin resubir)."
            )) {
                return;
            }
        }
        setBusy(true);
        setError(null);
        try {
            await updateShareBackup(job.id, { enabled: !job.enabled });
            await load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function openSnapshots(job) {
        if (snapLoading) return;
        const willOpen = snapOpen === job.id;
        setSnapOpen(willOpen ? null : job.id);
        if (willOpen) {
            setBrowse(null);
            return;
        }
        if (snapshots[job.id]) return;
        setSnapLoading(job.id);
        setError(null);
        try {
            const res = await getShareBackupSnapshots(job.id);
            setSnapshots((prev) => ({ ...prev, [job.id]: res?.snapshots || [] }));
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setSnapLoading(null);
        }
    }

    async function openHistory(job) {
        if (histLoading) return;
        const willOpen = histOpen === job.id;
        setHistOpen(willOpen ? null : job.id);
        if (willOpen) return;
        if (history[job.id]) return;
        setHistLoading(job.id);
        setError(null);
        try {
            const res = await getShareBackupHistory(job.id);
            setHistory((prev) => ({ ...prev, [job.id]: res?.history || [] }));
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setHistLoading(null);
        }
    }

    function elapsedSince(iso) {
        if (!iso) return "";
        const started = new Date(iso).getTime();
        if (!Number.isFinite(started)) return "";
        const minutes = Math.max(0, Math.round((Date.now() - started) / 60000));
        if (minutes < 1) return "hace instantes";
        if (minutes === 1) return "hace 1 min";
        return `hace ${minutes} min`;
    }

    function formatEta(seconds) {
        if (!Number.isFinite(seconds) || seconds < 0) return "";
        if (seconds < 60) {
            return `~${Math.round(seconds)}s rest.`;
        }
        const minutes = Math.round(seconds / 60);
        if (minutes < 60) return `~${minutes} min rest.`;
        const hours = Math.floor(minutes / 60);
        const rest = minutes % 60;
        return `~${hours}h ${rest}m rest.`;
    }

    function progressPercent(p) {
        if (!p) return 0;
        if (typeof p.percent === "number") return Math.min(100, Math.max(0, p.percent));
        if (p.bytes_total > 0) return Math.min(100, Math.round(p.bytes_done / p.bytes_total * 100));
        if (p.files_total > 0) return Math.min(100, Math.round(p.files_done / p.files_total * 100));
        return 0;
    }

    async function browseSnapshot(jobId, snapshotId, prefix) {
        if (browseLoading) return;
        setBrowseLoading(true);
        setError(null);
        try {
            const listing = await getShareBackupSnapshotFiles(jobId, snapshotId, prefix || "");
            setBrowse({ jobId, snapshotId, prefix: prefix || "", listing });
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBrowseLoading(false);
        }
    }

    async function handleDownloadEntry(jobId, snapshotId, entry) {
        if (busy) return;
        const isDir = entry.type === "dir";
        const name = (entry.path.split("/").pop() || "restauracion").trim() || "restauracion";
        const filename = isDir ? `${name}.tar` : name;
        setError(null);
        if (isDir) {
            const ok = window.confirm(
                "IMPORTANTE:\n\nDescargar una carpeta puede transferir MUCHOS GB y " +
                "SATURAR la red (sobre todo por WAN), afectando el rendimiento " +
                "de los demás.\n\nSe recomienda hacer las descargas en HORAS NO " +
                "LABORALES y de a una por vez.\n\n¿Descargar la carpeta «" +
                name + "» (como .tar) igualmente?"
            );
            if (!ok) return;
        }
        try {
            // Token de descarga (2 min) obtenido por API con header auth
            // (funciona siempre), luego la URL se abre directa con ?dl=:
            // el navegador inicia la descarga y transmite en vivo.
            const tokenRes = await fetchSilent(
                `/shares/backups/${jobId}/snapshots/${snapshotId}/download-token`,
                { method: "POST" },
            );
            if (!tokenRes) throw new Error("No se pudo preparar la descarga.");
            const dl = tokenRes.token || "";
            const url =
                `${_API_URL}/shares/backups/${jobId}/snapshots/${snapshotId}/download` +
                `?path=${encodeURIComponent(entry.path)}&dl=${encodeURIComponent(dl)}`;
            window.location.href = url;
            setNotice(`Descargando ${filename}…`);
            setTimeout(() => setNotice(null), 6000);
        } catch (err) {
            setError(err.message || String(err));
        }
    }


    // Ejecuta la restauración (compartida por "elegir destino" y "al origen")
    async function runRestoreJob(job, snap, target) {
        setBusy(true);
        setError(null);
        setRestoreProgress({ target, running: true, progress: null, message: `Iniciando restauración en ${target || "el origen"}…` });
        try {
            await restoreShareBackup(job.id, snap.id, target);
            // Polling: progreso de la restauración hasta que termine
            // (running false). restic --json reporta message_type "restore".
            const started = Date.now();
            while (true) {
                const st = await fetchSilent(`/shares/backups/${job.id}/restore-status`);
                const prog = st?.progress || {};
                if (prog) {
                    const pct = typeof prog.percent === "number" ? prog.percent
                        : (prog.bytes_total ? Math.min(100, Math.round((prog.bytes_done / prog.bytes_total) * 100)) : null);
                    setRestoreProgress({
                        target,
                        running: true,
                        progress: { pct, files_done: prog.files_done, files_total: prog.files_total,
                                    bytes_done: prog.bytes_done, bytes_total: prog.bytes_total, current_file: prog.current_file },
                        message: `Restaurando en ${target || "el origen"}…`,
                    });
                }
                if (st?.running === false || !prog) {
                    setRestoreProgress({ target, running: false, progress: null, message: null });
                    if (st?.error) {
                        setError(String(st.error));
                    } else if (st?.result?.message) {
                        setNotice(st.result.message);
                    }
                    break;
                }
                if (Date.now() - started > 24 * 3600 * 1000) break; // tope 24h
                await new Promise(r => setTimeout(r, 1200));
            }
        } catch (err) {
            setError(err.message || String(err));
            setRestoreProgress(null);
        } finally {
            setBusy(false);
        }
    }


    async function handleRestoreSnapshot(job, snap) {
        if (busy) return;
        // Elegir el destino con el explorador (privada, compartida, remota,
        // USB, etc.). Si se cancela, no pasa nada.
        setRestorePending({ job, snap });
        openFolderBrowser("restore");
    }


    // Restauración de DESASTRE: disco origen reemplazado por uno vacío. Se
    // restaura TAL CUAL a la ruta absoluta original (el backend solo lo
    // permite si el origen está VACÍO; véase restore_snapshot).
    async function openFolderBrowser(target) {
        setFolderBrowserTarget(target);
        setFolderBrowserOpen(true);
        setFolderBrowserError(null);
        setFolderBrowserLoading(true);
        try {
            // RESTAURACIÓN: NUNCA se listan particiones de respaldo como destino.
            const mpURL =
                target === "restore"
                    ? "/disks/mount-points?exclude_backup=true"
                    : "/disks/mount-points";
            const mpRes = await fetchSilent(mpURL);
            let mountPoints = mpRes.mount_points || [];
            if (target === "restore") {
                mountPoints = mountPoints.filter(
                    (mp) => (mp.purpose || mp.role) !== "backup"
                );
            }

            // RESTAURACIÓN: listar TODAS las unidades (locales, de red M,
            // USB, privadas, compartidas, respaldo) + el explorador.
            // El filtro que reemplaza mountPoints por "destinos de Respaldo"
            // solo aplica al destino de respaldo (target "destination").
            let destCandidates = null;
            if (target === "destination") {
                destCandidates = (destinationVaults || [])
                    .map((d) => {
                        const vaultPath = String(d.path || "").replace(/\/+$/, "");
                        if (!vaultPath.endsWith("/Respaldo")) return null;
                        return vaultPath.substring(0, vaultPath.length - "/Respaldo".length);
                    })
                    .filter(Boolean);
                destCandidates = [...new Set(destCandidates)];
                if (destCandidates.length === 0) {
                    setFolderBrowserError(
                        "No hay particiones de tipo Respaldo para usar como destino."
                    );
                    setFolderBrowserLoading(false);
                    return;
                }
                if (destCandidates.length === 1) {
                    const res = await fetchSilent("/disks/explore?path=" + encodeURIComponent(destCandidates[0]));
                    setFolderBrowserItems((res.items || []).filter(i => i.type === "dir" || i.is_directory));
                    setFolderBrowserPath(destCandidates[0]);
                    setFolderBrowserLoading(false);
                    return;
                }
                mountPoints = destCandidates.map((p) => ({ path: p }));
            }

            if (mountPoints.length === 1) {
                const res = await fetchSilent("/disks/explore?path=" + encodeURIComponent(mountPoints[0].path));
                setFolderBrowserItems((res.items || []).filter(i => i.type === "dir" || i.is_directory));
                setFolderBrowserPath(mountPoints[0].path);
            } else {
                setFolderBrowserItems(mountPoints.map(mp => ({
                    name: mp.path,
                    path: mp.path,
                    label: mp.label || null,
                    purpose: mp.purpose || null,
                    free_bytes: mp.free_bytes ?? null,
                    total_bytes: mp.total_bytes ?? null,
                    is_directory: true,
                })));
                setFolderBrowserPath("/");
            }
        } catch (err) {
            setFolderBrowserError(err.message);
        } finally {
            setFolderBrowserLoading(false);
        }
    }

    async function loadFolderBrowser(p) {
        setFolderBrowserLoading(true);
        setFolderBrowserError(null);
        try {
            const res = await fetchSilent("/disks/explore?path=" + encodeURIComponent(p));
            setFolderBrowserPath(p);
            setFolderBrowserItems((res.items || []).filter(i => i.type === "dir" || i.is_directory));
        } catch (err) {
            // Si es una UNIDAD de primer nivel (p. ej. una partición privada
            // aún desmontada, que se monta por demanda al restaurar), se
            // permite seleccionarla igual: el backend la monta al restaurar.
            const depth = p.split("/").filter(Boolean).length;
            if (p.startsWith("/") && depth <= 2) {
                setFolderBrowserPath(p);
                setFolderBrowserItems([]);
            }
            setFolderBrowserError(err.message);
        } finally {
            setFolderBrowserLoading(false);
        }
    }

    async function selectFolderBrowser() {
        if (folderBrowserTarget === "source") {
            setForm(f => ({ ...f, source_path: folderBrowserPath }));
            setFolderBrowserOpen(false);
            return;
        }
        if (folderBrowserTarget === "restore" && restorePending) {
            const { job, snap } = restorePending;
            const target = folderBrowserPath || "";
            setFolderBrowserOpen(false);
            setRestorePending(null);
            const confirmOk = window.confirm(
                `Restaurar la versión ${snap.short_id} «${snap.total_bytes_human || "tamaño desconocido"}» en:\n\n  ${target || "(origen)"}\n\n` +
                "Se restauran los archivos TAL CUAL (planos en el destino, sin " +
                "prefijos /mnt/... ni carpetas fantasma).\n" +
                "Se verificará que el destino esté VACÍO y con ESPACIO SUFICIENTE " +
                "(se necesita al menos " + (snap.total_bytes_human || "?") + " libres en el destino)."
            );
            if (!confirmOk) return;
            await runRestoreJob(job, snap, target);
            return;
        }
        setForm(f => ({ ...f, destination_path: folderBrowserPath }));
        setFolderBrowserOpen(false);
    }

    const jobs = (data?.jobs || []).filter(
        (job) => (anchorPath ? (job.source_path === anchorPath || (anchorJobId && job.id === anchorJobId)) : true)
    );

    const folderByPath = {};
    for (const fl of folders || []) {
        if (fl.path) folderByPath[fl.path] = fl;
    }
    function labelForVault(path) {
        const fl = folderByPath[path];
        if (fl && !fl.shared) {
            return fl.unc_path ? `${fl.name} — ${fl.unc_path}` : fl.name;
        }
        const dv = (destinationVaults || []).find((d) => d.path === path);
        if (dv && dv.label) {
            return `Unidad · ${dv.label} (Respaldo)`;
        }
        return null;
    }

    const localVaults = (data?.vaults || []).filter(
        (v) => !(v.path || "").includes("/stepad-network/")
    );
    const vaultSeen = new Set();
    const vaultOptions = [];
    for (const v of localVaults) {
        if (!v.path || vaultSeen.has(v.path)) continue;
        vaultSeen.add(v.path);
        vaultOptions.push({ path: v.path, label: labelForVault(v.path), free_pct: v.free_pct });
    }
    for (const dv of destinationVaults || []) {
        if (!dv.path || vaultSeen.has(dv.path)) continue;
        vaultSeen.add(dv.path);
        vaultOptions.push({ path: dv.path, label: labelForVault(dv.path), free_pct: null });
    }
    for (const fl of folders || []) {
        // Shared folders are now included as destinations
        if (!fl.path || (fl.path || "").includes("/stepad-network/")) continue;
        if (vaultSeen.has(fl.path)) continue;
        vaultSeen.add(fl.path);
        vaultOptions.push({
            path: fl.path,
            label: labelForVault(fl.path) || fl.name || fl.path,
            free_pct: null,
        });
    }

    return (
        <>
        <section className="sh-bk-panel">
            <div className="sh-bk-head">
                <div>
                    <p className="sh-eyebrow">Protección de datos</p>
                    <h2>{anchor ? `Respaldo de «${anchor.split("/").pop() || "esta carpeta"}»` : "Resguardos versionados"}</h2>
                    <p className="sh-lede">
                        Copias cifradas y versionadas; podés restaurar una versión anterior.
                    </p>
                </div>
            </div>

            {!loading && data?.installed === false && (
                <div className="sh-banner warn">
                    Falta restic en el servidor. Instala: <code>sudo apt-get install -y restic</code>
                </div>
            )}

            {notice && (
                <div className="sh-banner ok">{notice}</div>
            )}
            {error && (
                <div className="sh-banner error">{error}</div>
            )}

            {restoreProgress && restoreProgress.running && (
                <div className="sh-bk-restore-progress">
                    <div className="sh-bk-restore-line">
                        <span>
                            {restoreProgress.message || "Restaurando…"}
                        </span>
                        {typeof restoreProgress.progress?.pct === "number" && (
                            <strong>{Math.round(restoreProgress.progress.pct)}%</strong>
                        )}
                    </div>
                    <div className="sh-usage-bar" style={{ height: 10 }}>
                        <div
                            className={"sh-usage-fill" + (typeof restoreProgress.progress?.pct === "number" && restoreProgress.progress.pct >= 90 ? " danger" : " warning")}
                            style={{ width: `${typeof restoreProgress.progress?.pct === "number" ? Math.min(100, restoreProgress.progress.pct) : 3}%` }}
                        ></div>
                    </div>
                    <div className="sh-usage-text">
                        <span>
                            {restoreProgress.progress?.files_done != null
                                ? `${restoreProgress.progress.files_done} archivos`
                                : ""}
                            {restoreProgress.progress?.bytes_done
                                ? ` · ${(restoreProgress.progress.bytes_done / 1073741824).toFixed(1)} GB${restoreProgress.progress?.bytes_total ? ` / ${(restoreProgress.progress.bytes_total / 1073741824).toFixed(1)} GB` : ""}`
                                : ""}
                        </span>
                        <span className="sh-muted">
                            Destino: {restoreProgress.target || "el origen"}
                        </span>
                    </div>
                </div>
            )}
            <div className="sh-bk-body">
                <div className="sh-bk-form">
                    <h3>{editingId ? (editJob?.last_backup_at ? "Ajustar horario" : "Configurar respaldo") : anchor ? "Programar respaldo" : "Programar nuevo respaldo"}</h3>
                    <form className="sh-bk-form-grid" onSubmit={handleCreate}>
                        <label className="sh-bk-source-field">
                            <span className="sh-bk-label">Origen</span>
                            {editJob ? (
                                <input type="text" value={editJob.source_path} readOnly disabled={busy} />
                            ) : (
                                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                                    <input type="text" value={form.source_path || ""} readOnly disabled={busy} placeholder="Seleccioná una carpeta..." style={{ flex: 1 }} />
                                    <button type="button" className="sh-btn sh-btn-sm" disabled={busy} onClick={() => openFolderBrowser("source")}>Examinar...</button>
                                    {form.source_path && (
                                        <button type="button" className="sh-btn sh-btn-sm danger" disabled={busy} onClick={() => setForm(f => ({ ...f, source_path: "" }))}>Limpiar</button>
                                    )}
                                </div>
                            )}
                        </label>

                        {!editJob && formSource && form.destination_path && spaceInfo && (
                            <div className={"sh-bk-space-note " + (spaceInfo.sufficient === false || (spaceInfo.source_size == null && spaceInfo.free_human) ? "sh-bk-space-bad" : "sh-bk-space-ok")}>
                                {spaceInfo.sufficient === false ? (
                                    <>
                                        No alcanza el espacio: el origen pesa{" "}
                                        <strong>{spaceInfo.source_size_human}</strong> y en el destino quedan{" "}
                                        <strong>{spaceInfo.free_human}</strong> libres (falta{" "}
                                        {spaceInfo.missing_pct}%). Elige otro destino o libera espacio.
                                    </>
                                ) : spaceInfo.sufficient === true ? (
                                    <>
                                        Alcanza el espacio
                                        {spaceInfo.source_size_human
                                            ? `: origen ${spaceInfo.source_size_human}, destino con ${spaceInfo.free_human} libres.`
                                            : " en el destino elegido."}
                                    </>
                                ) : spaceInfo.source_size == null && spaceInfo.free_human ? (
                                    <>
                                        Destino: {spaceInfo.free_human} libres.
                                        {spaceInfo.note ? ` ${spaceInfo.note}` : " No se pudo medir el origen."}
                                    </>
                                ) : (
                                    <>{spaceInfo.note || "Verificando espacio…"}</>
                                )}
                            </div>
                        )}

                        <div className="sh-bk-times">
                                <p className="sh-bk-label">Horario</p>
                                {(form.schedule_times || []).map((t, index) => (
                                    <div key={index} className="sh-bk-time-row">
                                        <input
                                            type="time"
                                            value={t}
                                            disabled={busy}
                                            onChange={(e) => {
                                                const next = [...(form.schedule_times || [])];
                                                next[index] = e.target.value;
                                                setForm((f) => ({ ...f, schedule_times: next }));
                                            }}
                                        />
                                        <button
                                            type="button"
                                            className="sh-btn sh-btn-sm danger"
                                            disabled={busy || (form.schedule_times || []).length <= 1}
                                            onClick={() => {
                                                const next = (form.schedule_times || []).filter(
                                                    (_, i) => i !== index
                                                );
                                                setForm((f) => ({ ...f, schedule_times: next }));
                                            }}
                                        >
                                            Quitar
                                        </button>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    className="sh-btn sh-btn-sm"
                                    disabled={busy}
                                    onClick={() =>
                                        setForm((f) => ({
                                            ...f,
                                            schedule_times: [...(f.schedule_times || []), "12:00"],
                                        }))
                                    }
                                >
                                    + Agregar hora
                                </button>
                            </div>

                        <div className="sh-bk-form-row">
                            <label>
                                Conservar
                                <input
                                    type="number"
                                    min="1"
                                    max="365"
                                    value={form.retention_count}
                                    disabled={busy}
                                    title="Número de versiones recientes que se conservan al compactar"
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, retention_count: e.target.value }))
                                    }
                                />
                            </label>
                            <label>
                                Compactar bajo %
                                <input
                                    type="number"
                                    min="5"
                                    max="80"
                                    value={form.prune_free_pct}
                                    disabled={busy}
                                    title="Compacta cuando quede menos de este % de espacio libre"
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, prune_free_pct: e.target.value }))
                                    }

                                />
                            </label>
                        </div>
                        <button type="submit" className="sh-btn primary" disabled={busy}>
                            {editingId ? "Actualizar respaldo" : "Guardar respaldo"}
                        </button>
                    </form>
                </div>

                <div className="sh-bk-list">
                    {loading ? (
                        <p className="sh-loading">Cargando…</p>
                    ) : jobs.length === 0 ? (
                        <p className="sh-empty">
                            {anchor
                                ? `Esta carpeta aún no está respaldada: ${anchor}. Programala a la izquierda.`
                                : "Aún no hay jobs. Crea uno indicando la raíz de la unidad o carpeta a proteger."}
                        </p>
                    ) : (
                        jobs.map((job) => {
                            const isOpen = snapOpen === job.id;
                            const snaps = snapshots[job.id];
                            const isHistOpen = histOpen === job.id;
                            const hist = history[job.id];
                            return (
                                <article key={job.id} className="sh-bk-job">
                                    <div className="sh-bk-job-head">
                                        <div className="sh-bk-job-title">
                                            <strong>{job.name}</strong>
                                            <span className="sh-bk-pathline">
                                                <span className="sh-muted">Origen:</span>{" "}
                                                <code className="sh-inline-code">{job.source_path}</code>
                                            </span>
                                            <span className="sh-bk-pathline">
                                                <span className="sh-muted">Destino:</span>{" "}
                                                <code className="sh-inline-code">
                                                    {job.destination_path || job.repository_path || "(sin crear aún)"}
                                                </code>
                                            </span>
                                            <span className={`sh-badge ${job.enabled ? "green" : "readonly"}`}>
                                                {job.enabled ? "programado" : "apagado"}
                                            </span>
                                            {job.skip_until && new Date(job.skip_until) > new Date() && (
                                                <span className="sh-badge sh-badge-skipped" title="Pausado hasta la próxima hora programada">
                                                    ⏸ Saltado hasta{" "}
                                                    {new Date(job.skip_until).toLocaleString("es-EC", {
                                                        day: "2-digit",
                                                        month: "2-digit",
                                                        hour: "2-digit",
                                                        minute: "2-digit",
                                                    })}
                                                </span>
                                            )}
                                            {job.running && (
                                                <span className="sh-badge sh-badge-running" title="Respaldo en ejecución">
                                                    🔄 Respaldando{job.running_since ? ` · ${elapsedSince(job.running_since)}` : "…"}
                                                </span>
                                            )}
                                            {job.running && progress[job.id] && (
                                                <span className="sh-muted" style={{fontSize: "0.78rem", marginLeft: 4}}>
                                                    {progressPercent(progress[job.id]) > 0 && `${progressPercent(progress[job.id])}% · `}
                                                    {progress[job.id].files_total > 0 && `${progress[job.id].files_done}/${progress[job.id].files_total} archivos`}
                                                    {progress[job.id].current_file && ` · ${progress[job.id].current_file.split("/").pop()}`}
                                                    {progress[job.id].eta_seconds != null && formatEta(progress[job.id].eta_seconds)}
                                                </span>
                                            )}
                                            {job.unreadable_count > 0 && (
                                                <span
                                                    className="sh-badge sh-badge-skipped"
                                                    title={"Archivos ilegibles (se omitieron):\n" + (job.unreadable_samples || []).join("\n")}
                                                >
                                                    ⚠️ {job.unreadable_count} omitido{job.unreadable_count === 1 ? "" : "s"}
                                                </span>
                                            )}
                                            
                                            {job.failing && !job.running && (
                                                <span
                                                    className="sh-badge sh-badge-failing"
                                                    title="Este respaldo lleva varios intentos fallidos seguidos"
                                                >
                                                    ⚠️ Fallando ({job.consecutive_failures})
                                                </span>
                                            )}
                                            {job.source_exists === false && (
                                                <span
                                                    className="sh-badge sh-badge-failing"
                                                    title="La carpeta origen ya no existe (la unidad no está montada)"
                                                >
                                                    ⚠️ Origen no disponible
                                                </span>
                                            )}
                                            <UnreadableBackupAlert job={job} />
                                            {job.enabled && (
                                                <span className="sh-muted">
                                                    {job.schedule_mode === "on_change"
                                                        ? "respaldando al cambiar archivos"
                                                        : (job.schedule_times && job.schedule_times.length > 0
                                                            ? `todos los días a las ${job.schedule_times.join(", ")}`
                                                            : `todos los días ${String(job.schedule_hour).padStart(2, "0")}:${String(job.schedule_minute).padStart(2, "0")}`)}
                                                    {" · conserva "}
                                                    {`${job.retention_count}`} versiones
                                                </span>
                                            )}
                                        </div>
                                        <div className="sh-bk-job-actions">
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm primary"
                                                disabled={busy || job.running}
                                                onClick={() => handleRun(job)}
                                                title={job.running ? "Ya hay un respaldo en ejecución para este job" : undefined}
                                            >
                                                {job.running ? "Respaldando…" : "Ejecutar ahora"}
                                            </button>
                                            {job.schedule_mode !== "on_change" && (
                                                <button
                                                    type="button"
                                                    className="sh-btn sh-btn-sm"
                                                    disabled={busy}
                                                    onClick={() => handleSkip(job)}
                                                    title={job.running
                                                        ? "Cancela el respaldo en curso y lo reprograma para el siguiente horario (no se pierde lo ya respaldado)"
                                                        : "Pausa el job: el próximo respaldo corre en la siguiente hora programada"}
                                                >
                                                    {job.running ? "Saltar a próx. horario" : "Saltar a próx. horario"}
                                                </button>
                                            )}
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy || snapLoading === job.id}
                                                onClick={() => openSnapshots(job)}
                                            >
                                                {isOpen ? "Cerrar versiones" : "Versiones"}
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy || histLoading === job.id}
                                                onClick={() => openHistory(job)}
                                                title="Historial de corridas (éxito/fallo)"
                                            >
                                                {isHistOpen ? "Cerrar historial" : "Historial"}
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => handlePrune(job)}
                                                title="Borrar versiones antiguas según retención"
                                            >
                                                Compactar
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => handleToggle(job)}
                                            >
                                                {job.enabled ? "Desactivar" : "Activar"}
                                            </button>
                                        </div>
                                    </div>
                                    {job.running && progress[job.id] && (
                                        <div style={{ padding: "4px 0", borderTop: "1px solid rgba(255,255,255,0.1)" }}>
                                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.75rem", color: "#94a3b8", marginBottom: 4 }}>
                                                <span>
                                                    {progressPercent(progress[job.id]) > 0 && `${progressPercent(progress[job.id])}% · `}
                                                    {progress[job.id].files_total > 0 ? `${progress[job.id].files_done} / ${progress[job.id].files_total} archivos` : "procesando…"}
                                                </span>
                                                <span>
                                                    {progress[job.id].bytes_total > 0 ? `${Math.round(progress[job.id].bytes_done / 1024 / 1024)}MB / ${Math.round(progress[job.id].bytes_total / 1024 / 1024)}MB` : ""}
                                                    {" "}
                                                    {progress[job.id].eta_seconds != null && formatEta(progress[job.id].eta_seconds)}
                                                </span>
                                            </div>
                                            <div style={{ height: 6, background: "rgba(255,255,255,0.1)", borderRadius: 3, overflow: "hidden" }}>
                                                <div style={{
                                                    height: "100%",
                                                    width: `${progressPercent(progress[job.id])}%`,
                                                    background: "linear-gradient(90deg, #3b82f6, #60a5fa)",
                                                    borderRadius: 3,
                                                    transition: "width 0.5s ease"
                                                }} />
                                            </div>
                                        </div>
                                    )}
                                    {job.last_result && (
                                        (job.source_ok && isErrorResult(job.last_result) && /Host is down|Errno|Network is unreachable|Connection timed out|caída/i.test(job.last_result)) ? (
                                            <p className="sh-bk-last">
                                                <span className="sh-bk-last-status">✅ Unidad disponible</span>
                                                <span className="sh-muted">
                                                    {" · En la última corrida el origen se cayó; ahora está disponible y el próximo horario lo respalda."}
                                                </span>
                                            </p>
                                        ) : (
                                        <p className={"sh-bk-last " + (isErrorResult(job.last_result) ? "has-error" : "")}>
                                            <span className="sh-bk-last-status">
                                                {isCancelledResult(job.last_result)
                                                    ? "⏸ Pausado"
                                                    : isErrorResult(job.last_result)
                                                    ? "❌ Error"
                                                    : (job.last_snapshot_id ? "✅ Respaldado" : (job.last_bytes === 0 ? "⏸ Sin cambios" : "✅ Respaldado"))}
                                            </span>
                                            {job.last_backup_at && (
                                                <span className="sh-bk-last-date">
                                                    {" · "}
                                                    {new Date(job.last_backup_at).toLocaleString("es-EC", {
                                                        day: "2-digit",
                                                        month: "short",
                                                        hour: "2-digit",
                                                        minute: "2-digit",
                                                    })}
                                                </span>
                                            )}
                                            <span className={isErrorResult(job.last_result) ? "sh-bk-result-error" : "sh-muted"}>
                                                {summarizeResult(job.last_result)}
                                            </span>
                                        </p>
                                        )
                                    )}

                                    {isOpen && (
                                        <div className="sh-bk-snapshots">
                                            {snapLoading === job.id ? (
                                                <p className="sh-loading">Cargando versiones…</p>
                                            ) : !snaps ? null : snaps.length === 0 ? (
                                                <p className="sh-empty">
                                                    Sin versiones todavía. Pulsa «Ejecutar ahora».
                                                </p>
                                            ) : (
                                                <table className="sh-bk-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Fecha</th>
                                                            <th>Snapshot</th>
                                                            <th>Tamaño</th>
                                                            <th>Cambios</th>
                                                            <th />
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {snaps.map((snap) => (
                                                            <tr key={snap.id}>
                                                                <td>{snap.time}</td>
                                                                <td>
                                                                    <code className="sh-muted">
                                                                        {snap.short_id}
                                                                    </code>
                                                                </td>
                                                                <td>{snap.total_bytes_human || "—"}</td>
                                                                <td className="sh-muted">
                                                                    +{snap.files_new ?? "?"} ·
                                                                    {snap.data_added_human
                                                                        ? `${snap.data_added_human} nuevos`
                                                                        : "—"}
                                                                </td>
                                                                <td>
                                                                    <button
                                                                        type="button"
                                                                        className="sh-btn sh-btn-sm"
                                                                        disabled={busy || browseLoading}
                                                                        title="Navegar el snapshot y descargar solo las carpetas y archivos que necesitas. Es la vía recomendada: rápida y sin saturar el servidor."
                                                                        onClick={() =>
                                                                            browseSnapshot(
                                                                                job.id,
                                                                                snap.id,
                                                                                ""
                                                                            )
                                                                        }
                                                                    >
                                                                        Explorar y descargar
                                                                    </button>
                                                                    <button
                                                                        type="button"
                                                                        className="sh-btn sh-btn-sm danger"
                                                                        disabled={busy || browseLoading}
                                                                        title="Elige la unidad o carpeta donde restaurar (puede ser el lugar original si está vacío). El sistema monta por demanda, verifica la identidad y restaura tal cual."
                                                                        onClick={() =>
                                                                            handleRestoreSnapshot(
                                                                                job,
                                                                                snap
                                                                            )
                                                                        }
                                                                    >
                                                                        Restaurar versión completa
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            )}

                                            {browse
                                                && browse.jobId === job.id
                                                && (
                                                <div className="sh-bk-browse">
                                                    <div className="fx-warn sh-bk-dl-warn">
                                                        IMPORTANTE: descargar volúmenes grandes puede <strong>saturar la red</strong> (más aún por WAN) y afectar el rendimiento de los demás. Hacelo de preferencia en <strong>HORAS NO LABORALES</strong> y de a una descarga.
                                                    </div>
                                                    <div className="sh-bk-crumbs">
                                                        <button
                                                            type="button"
                                                            className="sh-btn sh-btn-sm"
                                                            disabled={busy || browseLoading}
                                                            onClick={() =>
                                                                browseSnapshot(
                                                                    job.id,
                                                                    browse.snapshotId,
                                                                    ""
                                                                )
                                                            }
                                                        >
                                                            raíz
                                                        </button>
                                                        {browse.prefix.split("/").filter(Boolean)
                                                            .map((part, idx) => {
                                                                const up = browse.prefix
                                                                    .split("/")
                                                                    .filter(Boolean)
                                                                    .slice(0, idx + 1);
                                                                return (
                                                                    <span key={`${part}-${idx}`}>
                                                                        {" / "}
                                                                        <button
                                                                            type="button"
                                                                            className="sh-btn sh-btn-sm"
                                                                            disabled={busy || browseLoading}
                                                                            onClick={() =>
                                                                                browseSnapshot(
                                                                                    job.id,
                                                                                    browse.snapshotId,
                                                                                    up.join("/")
                                                                                )
                                                                            }
                                                                        >
                                                                            {part}
                                                                        </button>
                                                                    </span>
                                                                );
                                                            })}
                                                    </div>
                                                    {browseLoading && (
                                                        <p className="sh-loading">Cargando…</p>
                                                    )}
                                                    {(browse.listing?.directories || []).map(
                                                        (dir) => (
                                                            <div key={dir} className="sh-bk-entry">
<button
                                                                        type="button"
                                                                        className="sh-bk-dir"
                                                                        disabled={busy || browseLoading}
                                                                        onClick={() =>
                                                                            browseSnapshot(
                                                                                job.id,
                                                                                browse.snapshotId,
                                                                                [browse.prefix, dir].filter(Boolean).join("/")
                                                                            )
                                                                        }
                                                                    >
                                                                    📁 {dir}/
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    className="sh-btn sh-btn-sm"
                                                                    disabled={busy}
                                                                    onClick={() =>
                                                                        handleDownloadEntry(
                                                                            job.id,
                                                                            browse.snapshotId,
                                                                            {
                                                                                path: [browse.prefix, dir].filter(Boolean).join("/"),
                                                                                type: "dir",
                                                                            }
                                                                        )
                                                                    }
                                                                >
                                                                    {busy ? "Descargando…" : "Descargar carpeta (.tar)"}
                                                                </button>
                                                            </div>
                                                        )
                                                    )}
                                                    {(browse.listing?.files || []).map((file) => (
                                                        <div key={file.path} className="sh-bk-entry">
                                                            <span className="sh-bk-file">
                                                                📄 {file.name}
                                                                <span className="sh-muted">
                                                                    {" "}
                                                                    ({file.size_human})
                                                                </span>
                                                            </span>
                                                            <button
                                                                type="button"
                                                                className="sh-btn sh-btn-sm"
                                                                disabled={busy}
                                                                onClick={() =>
                                                                    handleDownloadEntry(
                                                                        job.id,
                                                                        browse.snapshotId,
                                                                        { path: file.path, type: "file" }
                                                                    )
                                                                }
                                                            >
                                                                {busy ? "Descargando…" : "Descargar"}
                                                            </button>
                                                        </div>
                                                    ))}
                                                    {browse.listing
                                                        && (browse.listing.directories || []).length === 0
                                                        && (browse.listing.files || []).length === 0
                                                        && (
                                                        <p className="sh-empty">Carpeta vacía.</p>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    {isHistOpen && (
                                        <div className="sh-bk-snapshots">
                                            {histLoading === job.id ? (
                                                <p className="sh-loading">Cargando historial…</p>
                                            ) : !hist ? null : hist.length === 0 ? (
                                                <p className="sh-empty">
                                                    Todavía no hay corridas registradas para este job.
                                                </p>
                                            ) : (
                                                <ul className="sh-bk-history-list">
                                                    {hist.map((entry, idx) => (
                                                        <li
                                                            key={idx}
                                                            className={
                                                                "sh-bk-history-item " +
                                                                (entry.success ? "ok" : "has-error")
                                                            }
                                                        >
                                                            <span className="sh-bk-history-status">
                                                                {entry.success
                                                                    ? (entry.snapshot_id
                                                                        ? "✅ Éxito"
                                                                        : (entry.bytes_added === 0 ? "⏸ Sin cambios" : "✅ Éxito"))
                                                                    : "❌ Falló"}
                                                            </span>
                                                            <span className="sh-bk-history-date">
                                                                {entry.at
                                                                    ? new Date(entry.at).toLocaleString("es-EC", {
                                                                          day: "2-digit",
                                                                          month: "short",
                                                                          hour: "2-digit",
                                                                          minute: "2-digit",
                                                                      })
                                                                    : ""}
                                                            </span>
                                                            <span className="sh-muted">
                                                                {entry.trigger === "scheduled"
                                                                    ? "por horario"
                                                                    : entry.trigger === "manual"
                                                                    ? "manual"
                                                                    : entry.trigger === "on_change"
                                                                    ? "al detectar cambio"
                                                                    : entry.trigger}
                                                                {entry.duration_seconds != null &&
                                                                    ` · ${fmtDuration(entry.duration_seconds)}`}
                                                            </span>
                                                            <span
                                                                className={
                                                                    entry.success ? "sh-muted" : "sh-bk-result-error"
                                                                }
                                                            >
                                                                {summarizeResult(entry.message)}
                                                            </span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            )}
                                        </div>
                                    )}
                                </article>
                            );
                        })
                    )}
                </div>
            </div>
        </section>

        {folderBrowserOpen && (
            <div className="fx-overlay" onClick={() => setFolderBrowserOpen(false)}>
                <div className="fx-dialog" onClick={e => e.stopPropagation()} style={{ maxWidth: 600, maxHeight: "80vh", display: "flex", flexDirection: "column" }}>
                    <h4>Seleccionar carpeta</h4>
                    {folderBrowserError && <p className="fx-warn">{folderBrowserError}</p>}
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, flexWrap: "wrap" }}>
                        <code style={{ fontSize: "0.8rem", color: "#93c5fd", wordBreak: "break-all" }}>{folderBrowserPath}</code>
                        {folderBrowserPath !== "/" && (
                            <button type="button" className="fx-btn" disabled={folderBrowserLoading}
                                onClick={() => { const parts = folderBrowserPath.split("/").filter(Boolean); parts.pop(); loadFolderBrowser("/" + parts.join("/")); }}>
                                Subir
                            </button>
                        )}
                    </div>
                    <div style={{ flex: 1, overflowY: "auto", maxHeight: "50vh", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, padding: 4 }}>
                        {folderBrowserLoading ? (
                            <p className="fx-loading">Cargando...</p>
                        ) : folderBrowserItems.length === 0 ? (
                            <p className="fx-empty">Sin subcarpetas</p>
                        ) : (
                            folderBrowserItems.map(item => (
                                <div key={item.path || item.name} className="fx-row" style={{ cursor: "pointer", padding: "4px 8px", borderRadius: 4 }}
                                    onClick={() => {
                                        const target = item.path || item.name;
                                        if (target.startsWith("/")) {
                                            loadFolderBrowser(target);
                                        } else {
                                            loadFolderBrowser(folderBrowserPath + "/" + target);
                                        }
                                    }}>
                                    {item.label ? (
                                        <span>
                                            <strong>{item.label}</strong>
                                            {item.free_bytes != null && (
                                                <span className="fx-muted">
                                                    {" "}
                                                    · {Math.round(item.free_bytes / 1024 / 1024 / 1024)} GiB libres
                                                </span>
                                            )}
                                            <br />
                                            <span className="fx-muted" style={{ fontSize: "0.78rem" }}>
                                                {item.name}
                                            </span>
                                        </span>
                                    ) : (
                                        item.name
                                    )}
                                </div>
                            ))
                        )}
                    </div>
                    <div style={{ display: "flex", gap: 8, marginTop: 12, justifyContent: "flex-end" }}>
                        <button type="button" className="fx-btn" onClick={() => setFolderBrowserOpen(false)}>Cancelar</button>
                        <button type="button" className="fx-btn primary" onClick={selectFolderBrowser}>Seleccionar</button>
                    </div>
                </div>
            </div>
        )}
        </>
    );
}