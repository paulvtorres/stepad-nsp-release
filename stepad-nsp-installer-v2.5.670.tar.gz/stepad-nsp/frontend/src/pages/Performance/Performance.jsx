import { useEffect, useMemo, useState } from "react";

import { Link } from "react-router-dom";

import {
    getAlerts,
    getBandwidthLive,
    getDevices,
    getDhcpPoolStats,
    getDhcpStatus,
    getProtectionSummary,
    getSystemMonitoring,
    getSystemVersion,
    getWanMonitorHistory,
    getWanMonitorStatus,
} from "../../services/api";

import ActionButton from "../../components/ui/ActionButton";

import "./performance.css";


function formatMbps(value) {

    const number = Number(value || 0);

    if (number >= 1000) return `${(number / 1000).toFixed(2)} Gb/s`;

    return `${number.toFixed(number >= 10 ? 1 : 2)} Mb/s`;

}


function formatPercent(value) {

    return `${Number(value || 0).toFixed(1)}%`;

}


function formatUptime(seconds) {

    if (!seconds) return "—";

    const days = Math.floor(seconds / 86400);

    const hours = Math.floor((seconds % 86400) / 3600);

    const minutes = Math.floor((seconds % 3600) / 60);

    if (days > 0) return `${days}d ${hours}h`;

    if (hours > 0) return `${hours}h ${minutes}m`;

    return `${minutes}m`;

}


function formatClock(value) {

    if (!value) return "—";

    return new Date(value).toLocaleTimeString("es-EC", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
    });

}


function Sparkline({ values, values2, color, color2, fill, maxValue, unit = "" }) {

    const width = 720;

    const height = 150;

    const safeValues = (values || [])
        .map((value) => Number(value))
        .filter((value) => Number.isFinite(value));

    const safeValues2 = (values2 || [])
        .map((value) => Number(value))
        .filter((value) => Number.isFinite(value));

    if (safeValues.length < 2 && safeValues2.length < 2) {

        return (
            <div className="perf-chart-empty">
                Sin muestras suficientes todavía.
            </div>
        );

    }

    const maximum = Math.max(
        Number(maxValue || 0),
        ...safeValues,
        ...safeValues2,
        1,
    );

    function buildLine(source) {

        if (source.length < 2) return "";

        const step = width / Math.max(1, source.length - 1);

        return source.map((value, index) => {
            const x = index * step;
            const y = height - ((value / maximum) * (height - 16)) - 8;
            return `${index === 0 ? "M" : "L"} ${x.toFixed(2)} ${y.toFixed(2)}`;
        }).join(" ");

    }

    const line = buildLine(safeValues);

    const line2 = buildLine(safeValues2);

    const area = `${line} L ${width} ${height} L 0 ${height} Z`;

    return (
        <div className="perf-chart">

            <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" role="img">

                <defs>
                    <linearGradient id={`perf-fill-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={fill || color} stopOpacity="0.32" />
                        <stop offset="100%" stopColor={fill || color} stopOpacity="0" />
                    </linearGradient>
                </defs>

                <path
                    d={area}
                    fill={`url(#perf-fill-${color.replace("#", "")})`}
                />

                <path
                    d={line}
                    fill="none"
                    stroke={color}
                    strokeWidth="2.5"
                    vectorEffect="non-scaling-stroke"
                    strokeLinejoin="round"
                    strokeLinecap="round"
                />

                {line2 && (
                    <path
                        d={line2}
                        fill="none"
                        stroke={color2 || "#a78bfa"}
                        strokeWidth="2.5"
                        vectorEffect="non-scaling-stroke"
                        strokeLinejoin="round"
                        strokeLinecap="round"
                    />
                )}

            </svg>

            <div className="perf-chart-scale">
                <span>0</span>
                <span>{unit ? `${maximum.toFixed(1)} ${unit}` : maximum.toFixed(1)}</span>
            </div>

        </div>
    );

}


export default function Performance() {

    const [traffic, setTraffic] = useState(null);

    const [wanStatus, setWanStatus] = useState(null);

    const [wanHistory, setWanHistory] = useState(null);

    const [hardware, setHardware] = useState(null);

    const [devices, setDevices] = useState([]);

    const [dhcp, setDhcp] = useState(null);

    const [dhcpStatus, setDhcpStatus] = useState(null);

    const [protection, setProtection] = useState(null);

    const [alertData, setAlertData] = useState(null);

    const [version, setVersion] = useState(null);

    const [loading, setLoading] = useState(true);

    const [refreshing, setRefreshing] = useState(false);

    const [error, setError] = useState("");

    const [lastUpdated, setLastUpdated] = useState(null);


    async function loadTraffic() {

        try {

            setTraffic(await getBandwidthLive(true));

            setLastUpdated(new Date());

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo leer el tráfico de la red."
            );

        }

    }


    async function loadCore() {

        const results = await Promise.allSettled([
            getWanMonitorStatus(),
            getWanMonitorHistory(1),
            getSystemMonitoring(),
            getDevices(),
            getDhcpPoolStats(),
            getDhcpStatus(),
            getProtectionSummary(1),
            getAlerts(5),
            getSystemVersion(),
        ]);

        const [
            wanStatusResult,
            wanHistoryResult,
            hardwareResult,
            devicesResult,
            dhcpResult,
            dhcpStatusResult,
            protectionResult,
            alertsResult,
            versionResult,
        ] = results;

        if (wanStatusResult.status === "fulfilled") setWanStatus(wanStatusResult.value);
        if (wanHistoryResult.status === "fulfilled") setWanHistory(wanHistoryResult.value);
        if (hardwareResult.status === "fulfilled") setHardware(hardwareResult.value);
        if (devicesResult.status === "fulfilled") setDevices(devicesResult.value || []);
        if (dhcpResult.status === "fulfilled") setDhcp(dhcpResult.value);
        if (dhcpStatusResult.status === "fulfilled") setDhcpStatus(dhcpStatusResult.value);
        if (protectionResult.status === "fulfilled") setProtection(protectionResult.value);
        if (alertsResult.status === "fulfilled") setAlertData(alertsResult.value);
        if (versionResult.status === "fulfilled") setVersion(versionResult.value);

        setLoading(false);

    }


    async function refreshAll() {

        setRefreshing(true);

        await Promise.all([loadTraffic(), loadCore()]);

        setRefreshing(false);

    }


    useEffect(() => {

        loadTraffic();

        loadCore();

        const trafficTimer = setInterval(loadTraffic, 5000);

        const coreTimer = setInterval(loadCore, 15000);

        return () => {

            clearInterval(trafficTimer);

            clearInterval(coreTimer);

        };

    }, []);


    const wan = useMemo(() => {

        const entries = Object.values(wanStatus?.interfaces || {});

        return entries[0] || {};

    }, [wanStatus]);


    const wanSeries = useMemo(() => {

        const entries = Object.values(wanHistory?.series || {});

        return entries[0] || [];

    }, [wanHistory]);


    const latencyValues = useMemo(
        () => wanSeries.map((row) => row.latency_ms).filter((value) => value != null),
        [wanSeries],
    );

    const trafficRx = useMemo(
        () => (traffic?.history || []).map((row) => row.rx),
        [traffic],
    );

    const trafficTx = useMemo(
        () => (traffic?.history || []).map((row) => row.tx),
        [traffic],
    );

    const latestLatency = wan.latency_ms ?? latencyValues[latencyValues.length - 1] ?? 0;

    const latestLoss = wan.packet_loss ?? 0;

    const onlineDevices = devices.filter(
        (device) => (device.presence_status || device.status) === "ONLINE",
    ).length;

    const totalDevices = devices.length;

    const dnsTotal = protection?.dns?.total ?? 0;

    const dnsBlocked = protection?.dns?.blocked ?? 0;

    const dnsPercent = dnsTotal > 0 ? (dnsBlocked / dnsTotal) * 100 : 0;

    const unreadAlerts = alertData?.unread ?? 0;

    const dhcpFree = dhcp?.overall?.free ?? "—";

    const dhcpRunning = Boolean(
        dhcpStatus?.running
        ?? dhcpStatus?.service?.running
        ?? dhcpStatus?.pid
    );

    const internetOk = Boolean(wan.link_up && wan.ping_ok);

    const dnsOk = Boolean(wan.dns_ok);

    const topDevices = useMemo(
        () => [...(traffic?.devices || [])]
            .filter((device) => device.name !== "Este equipo (NSP)")
            .sort((a, b) => (b.rx_mbps + b.tx_mbps) - (a.rx_mbps + a.tx_mbps))
            .slice(0, 6),
        [traffic],
    );

    const maxDeviceTraffic = Math.max(
        1,
        ...topDevices.map((device) => device.rx_mbps + device.tx_mbps),
    );


    return (

        <div className="perf-page">

            <header className="perf-hero">

                <div className="perf-hero-glow" aria-hidden="true" />

                <div className="perf-hero-copy">

                    <span className="perf-eyebrow">
                        RENDIMIENTO DE RED
                    </span>

                    <h1>
                        El pulso del NSP
                        <span className="perf-live">
                            <span className="perf-live-dot" />
                            EN VIVO
                        </span>
                    </h1>

                    <p>
                        Tráfico, latencia, equipos y filtrado en una sola vista.
                        Actualización automática cada {5} segundos en las métricas rápidas.
                    </p>

                </div>

                <div className="perf-hero-actions">

                    <span className="perf-updated">
                        {lastUpdated
                            ? `Actualizado ${formatClock(lastUpdated)}`
                            : "Conectando con la red…"}
                    </span>

                    <ActionButton
                        variant="secondary"
                        loading={refreshing}
                        onClick={refreshAll}
                    >
                        Actualizar ahora
                    </ActionButton>

                </div>

                <div className="perf-flow" aria-label="Flujo Internet, NSP y LAN">

                    <span>Internet</span>

                    <div className="perf-flow-line">
                        <i />
                        <i />
                        <i />
                    </div>

                    <strong>NSP</strong>

                    <div className="perf-flow-line">
                        <i />
                        <i />
                        <i />
                    </div>

                    <span>LAN</span>

                </div>

            </header>

            {error && <div className="perf-error">{error}</div>}

            <div className="perf-kpis">

                <div className="perf-kpi accent">

                    <span>Descarga WAN</span>

                    <strong>{formatMbps(traffic?.wan?.rx_mbps)}</strong>

                    <small>Ahora mismo</small>

                </div>

                <div className="perf-kpi accent">

                    <span>Subida WAN</span>

                    <strong>{formatMbps(traffic?.wan?.tx_mbps)}</strong>

                    <small>Ahora mismo</small>

                </div>

                <div className={`perf-kpi ${latestLatency > 80 ? "warn" : "ok"}`}>

                    <span>Latencia</span>

                    <strong>{latestLatency ? `${latestLatency.toFixed(1)} ms` : "—"}</strong>

                    <small>{wan.quality?.label_es || "Sin medición"}</small>

                </div>

                <div className={`perf-kpi ${latestLoss > 1 ? "warn" : "ok"}`}>

                    <span>Pérdida</span>

                    <strong>{formatPercent(latestLoss)}</strong>

                    <small>Paquetes perdidos</small>

                </div>

                <div className="perf-kpi">

                    <span>Equipos online</span>

                    <strong>{onlineDevices}<em>/{totalDevices || "—"}</em></strong>

                    <small>Visibles en la red</small>

                </div>

                <div className="perf-kpi">

                    <span>Bloqueos DNS · 1 h</span>

                    <strong>{dnsBlocked.toLocaleString("es-EC")}</strong>

                    <small>{dnsPercent.toFixed(1)}% de las consultas</small>

                </div>

            </div>

            <div className="perf-main-grid">

                <section className="perf-card perf-chart-card">

                    <header className="perf-card-head">

                        <div>

                            <h2>Tráfico de la red</h2>

                            <p>Últimos minutos · Mb/s</p>

                        </div>

                        <span className="perf-card-pill">
                            {formatMbps((traffic?.devices_total_rx_mbps || 0) + (traffic?.devices_total_tx_mbps || 0))}
                        </span>

                    </header>

                    <div className="perf-chart-layout">

                        <div className="perf-chart-main">

                            <Sparkline
                                values={trafficRx}
                                values2={trafficTx}
                                color="#38bdf8"
                                color2="#a78bfa"
                                unit="Mb/s"
                            />

                        </div>

                        <div className="perf-chart-legend">

                            <span><i className="rx" /> Descarga</span>

                            <span><i className="tx" /> Subida</span>

                        </div>

                    </div>

                </section>

                <section className="perf-card perf-chart-card">

                    <header className="perf-card-head">

                        <div>

                            <h2>Calidad de la WAN</h2>

                            <p>Latencia de los últimos minutos</p>

                        </div>

                        <span className={`perf-card-pill ${latestLatency > 80 ? "warn" : "ok"}`}>
                            {internetOk ? "Internet OK" : "Revisar WAN"}
                        </span>

                    </header>

                    <div className="perf-chart-layout">

                        <div className="perf-chart-main">

                            <Sparkline
                                values={latencyValues}
                                color="#a78bfa"
                                unit="ms"
                            />

                        </div>

                        <div className="perf-chart-legend">

                            <span><i className="latency" /> Latencia</span>

                            <span>{wan.public_ip || "Sin IP pública"}</span>

                        </div>

                    </div>

                </section>

            </div>

            <div className="perf-lower-grid">

                <section className="perf-card">

                    <header className="perf-card-head">

                        <div>

                            <h2>Equipos con más tráfico</h2>

                            <p>Lectura del uso actual por equipo</p>

                        </div>

                        <Link to="/network/devices" className="perf-link">
                            Ver todos
                        </Link>

                    </header>

                    <div className="perf-device-list">

                        {
                            topDevices.length === 0 ? (
                                <p className="perf-empty">Sin equipos con tráfico medible.</p>
                            ) : (
                                topDevices.map((device) => {

                                    const total = device.rx_mbps + device.tx_mbps;

                                    return (
                                        <div className="perf-device-row" key={device.ip}>

                                            <div className="perf-device-top">

                                                <strong>{device.name || device.ip}</strong>
                                                <span>{formatMbps(total)}</span>

                                            </div>

                                            <div className="perf-device-bar">
                                                <i style={{ width: `${(total / maxDeviceTraffic) * 100}%` }} />
                                            </div>

                                            <small>{device.ip}</small>

                                        </div>
                                    );

                                })
                            )
                        }

                    </div>

                </section>

                <section className="perf-card">

                    <header className="perf-card-head">

                        <div>

                            <h2>Salud y actividad</h2>
                            <p>Servicios clave del NSP</p>

                        </div>

                        <span className={`perf-card-pill ${internetOk ? "ok" : "warn"}`}>
                            {internetOk ? "Operativo" : "Con alerta"}
                        </span>

                    </header>

                    <div className="perf-health-list">

                        <div>
                            <span><i className={`dot ${internetOk ? "ok" : "warn"}`} /> Internet</span>
                            <strong>{internetOk ? "Respondiendo" : "Sin respuesta"}</strong>
                        </div>

                        <div>
                            <span><i className={`dot ${dhcpRunning ? "ok" : "warn"}`} /> DHCP</span>
                            <strong>{dhcpRunning ? `${dhcpFree} IPs libres` : "Detenido"}</strong>
                        </div>

                        <div>
                            <span><i className={`dot ${dnsOk ? "ok" : "warn"}`} /> DNS</span>
                            <strong>{dnsOk ? "Resolviendo" : "Con problemas"}</strong>
                        </div>

                        <div>
                            <span><i className="dot ok" /> IPS</span>
                            <strong>Protección activa</strong>
                        </div>

                        <div>
                            <span><i className={`dot ${unreadAlerts > 0 ? "warn" : "ok"}`} /> Alertas</span>
                            <strong>{unreadAlerts} sin leer</strong>
                        </div>

                        <div>
                            <span><i className="dot ok" /> NSP</span>
                            <strong>{version?.version || "—"} · {formatUptime(hardware?.uptime_seconds)}</strong>
                        </div>

                    </div>

                    <div className="perf-host-stats">

                        <span>CPU <strong>{formatPercent(hardware?.cpu_percent)}</strong></span>
                        <span>RAM <strong>{formatPercent(hardware?.ram_percent)}</strong></span>
                        <span>Temp. <strong>{hardware?.temperature_c != null ? `${hardware.temperature_c.toFixed(0)}°C` : "—"}</strong></span>

                    </div>

                </section>

            </div>

            <footer className="perf-footer">

                <span>Datos reales del NSP · sin estimaciones</span>
                <span>
                    <Link to="/monitoring">Ver monitorización WAN</Link>
                    {" · "}
                    <Link to="/protection?view=ads">Anuncios en vivo</Link>
                </span>

            </footer>

        </div>

    );

}
