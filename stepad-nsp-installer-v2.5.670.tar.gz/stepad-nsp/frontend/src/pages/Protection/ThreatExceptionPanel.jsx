import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    createThreatException,
    deleteThreatException,
    getThreatExceptions,
} from "../../services/api";


const EMPTY = { mac_address: "", reason: "", expires_at: "" };


export default function ThreatExceptionPanel() {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";
    const [items, setItems] = useState([]);
    const [form, setForm] = useState(EMPTY);
    const [error, setError] = useState("");
    const [busy, setBusy] = useState(false);


    async function load() {

        try {
            const result = await getThreatExceptions();
            setItems(result?.exceptions || []);
        } catch (err) {
            setError(err.message || "No se pudieron cargar las excepciones.");
        }

    }


    useEffect(() => {
        load();
    }, []);


    async function submit(event) {

        event.preventDefault();

        if (!isAdmin) return;

        setBusy(true);
        setError("");

        try {

            await createThreatException({
                ...form,
                expires_at: form.expires_at || null,
            });
            setForm(EMPTY);
            await load();

        } catch (err) {

            setError(err.message || "No se pudo crear la excepción.");

        } finally {

            setBusy(false);

        }

    }


    async function remove(item) {

        if (!isAdmin) return;
        if (!window.confirm(`¿Eliminar la excepción de ${item.mac_address}?`)) return;

        setBusy(true);

        try {

            await deleteThreatException(item.id);
            await load();

        } catch (err) {

            setError(err.message || "No se pudo eliminar la excepción.");

        } finally {

            setBusy(false);

        }

    }


    return (

        <section className="threat-exception-panel">

            <div className="threat-policy-head">
                <div>
                    <h4>Excepciones por equipo</h4>
                    <p>
                        Un equipo exento nunca se aísla automáticamente,
                        aunque coincida con una política. Usalo solo para
                        servidores o equipos críticos.
                    </p>
                </div>
            </div>

            {error && <div className="threat-message">{error}</div>}

            {items.length === 0 ? (
                <p className="protection-empty">Sin excepciones activas.</p>
            ) : (
                <div className="threat-policy-table-wrap">
                    <table className="protection-table threat-policy-table">
                        <thead>
                            <tr>
                                <th>Equipo</th>
                                <th>MAC</th>
                                <th>Motivo</th>
                                <th>Expira</th>
                                <th />
                            </tr>
                        </thead>
                        <tbody>
                            {items.map((item) => (
                                <tr key={item.id}>
                                    <td>{item.device_name || "—"}</td>
                                    <td>{item.mac_address}</td>
                                    <td>{item.reason}</td>
                                    <td>
                                        {item.expires_at
                                            ? new Date(item.expires_at).toLocaleString()
                                            : "Sin vencimiento"}
                                    </td>
                                    <td>
                                        {isAdmin && (
                                            <button
                                                type="button"
                                                className="secondary-button danger"
                                                onClick={() => remove(item)}
                                                disabled={busy}
                                            >
                                                Eliminar
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {isAdmin && (
                <form className="threat-exception-form" onSubmit={submit}>

                    <div className="threat-simulation-grid">
                        <label>
                            MAC del equipo
                            <input
                                value={form.mac_address}
                                onChange={(e) => setForm({ ...form, mac_address: e.target.value })}
                                placeholder="aa:bb:cc:dd:ee:ff"
                                required
                            />
                        </label>
                        <label>
                            Motivo
                            <input
                                value={form.reason}
                                onChange={(e) => setForm({ ...form, reason: e.target.value })}
                                placeholder="Servidor de producción"
                                required
                            />
                        </label>
                        <label>
                            Expira (opcional)
                            <input
                                type="datetime-local"
                                value={form.expires_at}
                                onChange={(e) => setForm({ ...form, expires_at: e.target.value })}
                            />
                        </label>
                    </div>

                    <div className="threat-policy-form-actions">
                        <button type="submit" className="primary-button" disabled={busy}>
                            {busy ? "Guardando…" : "Crear excepción"}
                        </button>
                    </div>

                </form>
            )}

        </section>

    );

}
