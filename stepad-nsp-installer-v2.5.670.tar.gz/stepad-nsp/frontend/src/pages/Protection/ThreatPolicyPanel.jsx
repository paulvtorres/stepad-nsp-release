import { useEffect, useState } from "react";

import {
    createThreatPolicy,
    deleteThreatPolicy,
    getThreatPolicies,
    getThreatPolicyHistory,
    restoreThreatPolicyRevision,
    simulateThreatPolicy,
    updateThreatPolicy,
} from "../../services/api";


const EMPTY_SIMULATION = {
    signature: "",
    category: "",
    severity: "warning",
    src_ip: "",
    dst_ip: "",
    dst_port: "",
};

const EMPTY_FORM = {
    name: "",
    match_type: "category",
    match_value: "",
    action: "alert",
    priority: 100,
    enabled: true,
    description: "",
};

const MATCH_LABELS = {
    category: "Categoría",
    signature: "Firma",
    default: "Default",
};

const ACTION_LABELS = {
    ignore: "Ignorar",
    alert: "Solo alerta",
    quarantine: "Cuarentena automática",
    block_c2: "Bloquear C2",
    quarantine_and_block_c2: "Cuarentena + bloquear C2",
};


function matchText(policy) {

    if (policy.match_type === "default") return "Cualquier detección";

    return `${MATCH_LABELS[policy.match_type]}: ${policy.match_value}`;

}


export default function ThreatPolicyPanel({ isAdmin }) {

    const [policies, setPolicies] = useState([]);

    const [history, setHistory] = useState([]);

    const [form, setForm] = useState(EMPTY_FORM);

    const [editingId, setEditingId] = useState(null);

    const [loading, setLoading] = useState(true);

    const [working, setWorking] = useState(false);

    const [error, setError] = useState("");

    const [simForm, setSimForm] = useState(EMPTY_SIMULATION);

    const [simulation, setSimulation] = useState(null);

    const [simulating, setSimulating] = useState(false);

    const [view, setView] = useState("policies");


    async function simulate(event) {

        event.preventDefault();

        setSimulating(true);

        setSimulation(null);

        try {

            const result = await simulateThreatPolicy({
                ...simForm,
                dst_port: simForm.dst_port ? Number(simForm.dst_port) : null,
            });

            setSimulation(result);

        } catch (err) {

            setError(err.message || "No se pudo simular la detección.");

        } finally {

            setSimulating(false);

        }

    }


    async function load() {

        setLoading(true);

        try {

            const [result, historyResult] = await Promise.all([
                getThreatPolicies(),
                getThreatPolicyHistory(20),
            ]);

            setPolicies(result?.policies || []);
            setHistory(historyResult?.history || []);

            setError("");

        } catch (err) {

            setError(err.message || "No se pudieron cargar las políticas.");

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {
        load();
    }, []);


    function edit(policy) {

        setEditingId(policy.id);

        setForm({
            name: policy.name,
            match_type: policy.match_type,
            match_value: policy.match_value || "",
            action: policy.action,
            priority: policy.priority,
            enabled: policy.enabled,
            description: policy.description || "",
        });

        setView("editor");

    }


    function reset() {

        setEditingId(null);

        setForm(EMPTY_FORM);

        setView("policies");

    }


    async function submit(event) {

        event.preventDefault();

        if (!isAdmin) return;

        setWorking(true);

        setError("");

        try {

            const payload = {
                ...form,
                priority: Number(form.priority),
            };

            if (editingId) {

                await updateThreatPolicy(editingId, payload);

            } else {

                await createThreatPolicy(payload);

            }

            reset();

            await load();

        } catch (err) {

            setError(err.message || "No se pudo guardar la política.");

        } finally {

            setWorking(false);

        }

    }


    async function toggle(policy) {

        if (!isAdmin) return;

        setWorking(true);

        try {

            await updateThreatPolicy(policy.id, {
                ...policy,
                enabled: !policy.enabled,
            });

            await load();

        } catch (err) {

            setError(err.message || "No se pudo cambiar la política.");

        } finally {

            setWorking(false);

        }

    }


    async function restore(revision) {

        if (!isAdmin) return;

        if (!window.confirm(
            `¿Revertir "${revision.policy_name || "esta política"}" al estado anterior?`
        )) return;

        setWorking(true);

        try {

            await restoreThreatPolicyRevision(revision.id);

            await load();

        } catch (err) {

            setError(err.message || "No se pudo revertir la política.");

        } finally {

            setWorking(false);

        }

    }


    async function remove(policy) {

        if (!isAdmin) return;

        if (!window.confirm(`¿Eliminar la política "${policy.name}"?`)) return;

        setWorking(true);

        try {

            await deleteThreatPolicy(policy.id);

            await load();

        } catch (err) {

            setError(err.message || "No se pudo eliminar la política.");

        } finally {

            setWorking(false);

        }

    }


    const activeCount = policies.filter((policy) => policy.enabled).length;

    const quarantineCount = policies.filter(
        (policy) => policy.action === "quarantine"
            || policy.action === "quarantine_and_block_c2"
    ).length;


    return (

        <section className="threat-policy-panel">

            <div className="threat-policy-head">

                <div>
                    <h4>Políticas de respuesta IPS</h4>
                    <p>
                        Definí qué detecciones generan alerta, cuarentena o
                        bloqueo. La cuarentena global sigue siendo el interruptor
                        maestro del sistema.
                    </p>
                </div>

                <span className="threat-status-pill">
                    {activeCount} activa{activeCount === 1 ? "" : "s"}
                </span>

            </div>

            {error && <div className="threat-message">{error}</div>}

            <div className="threat-summary-grid">

                <div className="threat-summary-card">
                    <span>Políticas</span>
                    <strong>{policies.length}</strong>
                    <small>Reglas configuradas</small>
                </div>

                <div className="threat-summary-card ok">
                    <span>Activas</span>
                    <strong>{activeCount}</strong>
                    <small>Se evalúan al detectar</small>
                </div>

                <div className="threat-summary-card warn">
                    <span>Con cuarentena</span>
                    <strong>{quarantineCount}</strong>
                    <small>Aíslan el equipo</small>
                </div>

                <div className="threat-summary-card">
                    <span>Cambios</span>
                    <strong>{history.length}</strong>
                    <small>En el historial reciente</small>
                </div>

            </div>

            <div className="threat-policy-tabs" role="tablist">

                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "policies"}
                    className={`threat-policy-tab ${view === "policies" ? "active" : ""}`}
                    onClick={() => setView("policies")}
                >
                    Políticas
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "simulator"}
                    className={`threat-policy-tab ${view === "simulator" ? "active" : ""}`}
                    onClick={() => setView("simulator")}
                >
                    Simulador
                </button>

                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "history"}
                    className={`threat-policy-tab ${view === "history" ? "active" : ""}`}
                    onClick={() => setView("history")}
                >
                    Historial
                </button>

                {
                    isAdmin && (
                        <button
                            type="button"
                            role="tab"
                            aria-selected={view === "editor"}
                            className={`threat-policy-tab ${view === "editor" ? "active" : ""}`}
                            onClick={() => setView("editor")}
                        >
                            {editingId ? "Editar política" : "Nueva política"}
                        </button>
                    )
                }

            </div>

            {view === "policies" && (

                <div className="threat-tab-body">

                    <div className="threat-toolbar">

                        <span className="registry-hint">
                            Se aplican por prioridad. La cuarentena automática
                            solo actúa si la política coincide.
                        </span>

                        {
                            isAdmin && (
                                <button
                                    type="button"
                                    className="primary-button"
                                    onClick={() => {
                                        reset();
                                        setView("editor");
                                    }}
                                >
                                    + Nueva política
                                </button>
                            )
                        }

                    </div>

                    {loading ? (
                        <p className="protection-empty">Cargando políticas…</p>
                    ) : policies.length === 0 ? (
                        <p className="protection-empty">
                            No hay políticas configuradas. Creá una para definir
                            qué hacer ante una detección.
                        </p>
                    ) : (
                        <div className="threat-policy-table-wrap">
                            <table className="protection-table threat-policy-table">
                                <thead>
                                    <tr>
                                        <th>Prioridad</th>
                                        <th>Nombre</th>
                                        <th>Coincidencia</th>
                                        <th>Acción</th>
                                        <th>Estado</th>
                                        <th />
                                    </tr>
                                </thead>
                                <tbody>
                                    {policies.map((policy) => (
                                        <tr key={policy.id}>
                                            <td>{policy.priority}</td>
                                            <td>
                                                <strong>{policy.name}</strong>
                                                {policy.description && (
                                                    <div className="threat-policy-description">
                                                        {policy.description}
                                                    </div>
                                                )}
                                            </td>
                                            <td>{matchText(policy)}</td>
                                            <td>{ACTION_LABELS[policy.action] || policy.action}</td>
                                            <td>
                                                <span className={`threat-policy-state ${policy.enabled ? "on" : "off"}`}>
                                                    {policy.enabled ? "Activa" : "Inactiva"}
                                                </span>
                                            </td>
                                            <td className="threat-policy-actions">
                                                {isAdmin && (
                                                    <>
                                                        <button
                                                            type="button"
                                                            className="secondary-button"
                                                            onClick={() => edit(policy)}
                                                            disabled={working}
                                                        >
                                                            Editar
                                                        </button>
                                                        <button
                                                            type="button"
                                                            className="secondary-button"
                                                            onClick={() => toggle(policy)}
                                                            disabled={working}
                                                        >
                                                            {policy.enabled ? "Desactivar" : "Activar"}
                                                        </button>
                                                        <button
                                                            type="button"
                                                            className="secondary-button danger"
                                                            onClick={() => remove(policy)}
                                                            disabled={working}
                                                        >
                                                            Eliminar
                                                        </button>
                                                    </>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                </div>

            )}

            {view === "simulator" && (

                <div className="threat-tab-body">

                    <form className="threat-simulation-form threat-config-card" onSubmit={simulate}>

                        <div className="threat-config-heading">
                            <div>
                                <h5>Probar una detección</h5>
                                <p>
                                    Simulá una firma antes de recibirla. No aísla,
                                    no bloquea y no modifica la política.
                                </p>
                            </div>
                        </div>

                        <div className="threat-simulation-grid">
                            <label>
                                Firma
                                <input
                                    value={simForm.signature}
                                    onChange={(e) => setSimForm({ ...simForm, signature: e.target.value })}
                                    placeholder="GPL SNMP public access udp"
                                    required
                                />
                            </label>
                            <label>
                                Categoría
                                <input
                                    value={simForm.category}
                                    onChange={(e) => setSimForm({ ...simForm, category: e.target.value })}
                                    placeholder="Attempted Information Leak"
                                />
                            </label>
                            <label>
                                Severidad
                                <select
                                    value={simForm.severity}
                                    onChange={(e) => setSimForm({ ...simForm, severity: e.target.value })}
                                >
                                    <option value="warning">Warning</option>
                                    <option value="critical">Critical</option>
                                    <option value="info">Info</option>
                                </select>
                            </label>
                            <label>
                                IP origen
                                <input
                                    value={simForm.src_ip}
                                    onChange={(e) => setSimForm({ ...simForm, src_ip: e.target.value })}
                                    placeholder="192.168.1.50"
                                />
                            </label>
                            <label>
                                IP destino
                                <input
                                    value={simForm.dst_ip}
                                    onChange={(e) => setSimForm({ ...simForm, dst_ip: e.target.value })}
                                    placeholder="8.8.8.8"
                                />
                            </label>
                            <label>
                                Puerto destino
                                <input
                                    type="number"
                                    value={simForm.dst_port}
                                    onChange={(e) => setSimForm({ ...simForm, dst_port: e.target.value })}
                                    placeholder="443"
                                />
                            </label>
                        </div>

                        <div className="threat-policy-form-actions">
                            <button type="submit" className="primary-button" disabled={simulating}>
                                {simulating ? "Simulando…" : "Simular detección"}
                            </button>
                        </div>

                        {simulation && (
                            <div className={`threat-simulation-result ${simulation.quarantine ? "danger" : "safe"}`}>
                                <strong>
                                    {simulation.matched
                                        ? `${simulation.policy?.name}: ${simulation.action_label}`
                                        : "Sin política coincidente"}
                                </strong>
                                <p>{simulation.reason}</p>
                                <ul>
                                    <li>Alerta: {simulation.alert ? "sí" : "no"}</li>
                                    <li>Cuarentena: {simulation.quarantine ? "sí" : "no"}</li>
                                    <li>Bloqueo C2: {simulation.block_c2 ? "sí" : "no"}</li>
                                </ul>
                            </div>
                        )}

                    </form>

                </div>

            )}

            {view === "history" && (

                <div className="threat-tab-body">

                    <div className="threat-toolbar">

                        <span className="registry-hint">
                            Cada cambio queda registrado y puede revertirse.
                        </span>

                    </div>

                    {history.length === 0 ? (
                        <p className="protection-empty">Sin cambios registrados.</p>
                    ) : (
                        <div className="threat-policy-table-wrap">
                            <table className="protection-table threat-policy-table">
                                <thead>
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Acción</th>
                                        <th>Política</th>
                                        <th>Usuario</th>
                                        <th />
                                    </tr>
                                </thead>
                                <tbody>
                                    {history.map((revision) => (
                                        <tr key={revision.id}>
                                            <td>
                                                {revision.created_at
                                                    ? new Date(revision.created_at).toLocaleString()
                                                    : "—"}
                                            </td>
                                            <td>{revision.action}</td>
                                            <td>{revision.policy_name || "—"}</td>
                                            <td>{revision.username || "sistema"}</td>
                                            <td>
                                                {isAdmin && (
                                                    <button
                                                        type="button"
                                                        className="secondary-button"
                                                        onClick={() => restore(revision)}
                                                        disabled={working}
                                                    >
                                                        Revertir
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                </div>

            )}

            {view === "editor" && isAdmin && (

                <div className="threat-tab-body">

                    <form className="threat-policy-form threat-config-card" onSubmit={submit}>

                        <div className="threat-config-heading">

                            <div>
                                <h5>{editingId ? "Editar política" : "Nueva política"}</h5>
                                <p>
                                    La prioridad más baja se evalúa primero.
                                    Las coincidencias se separan por coma.
                                </p>
                            </div>

                            {editingId && (
                                <span className="threat-edit-pill">
                                    Editando
                                </span>
                            )}

                        </div>

                        <div className="threat-policy-grid">

                            <label>
                                Nombre
                                <input
                                    value={form.name}
                                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                                    maxLength={80}
                                    required
                                />
                            </label>

                            <label>
                                Tipo de coincidencia
                                <select
                                    value={form.match_type}
                                    onChange={(e) => setForm({ ...form, match_type: e.target.value })}
                                >
                                    <option value="category">Categoría</option>
                                    <option value="signature">Firma</option>
                                    <option value="default">Default</option>
                                </select>
                            </label>

                            <label>
                                Valor
                                <input
                                    value={form.match_value}
                                    onChange={(e) => setForm({ ...form, match_value: e.target.value })}
                                    disabled={form.match_type === "default"}
                                    placeholder="ej. snmp public access"
                                />
                            </label>

                            <label>
                                Acción
                                <select
                                    value={form.action}
                                    onChange={(e) => setForm({ ...form, action: e.target.value })}
                                >
                                    {Object.entries(ACTION_LABELS).map(([value, label]) => (
                                        <option key={value} value={value}>{label}</option>
                                    ))}
                                </select>
                            </label>

                            <label>
                                Prioridad
                                <input
                                    type="number"
                                    min={0}
                                    max={10000}
                                    value={form.priority}
                                    onChange={(e) => setForm({ ...form, priority: e.target.value })}
                                />
                            </label>

                            <label className="threat-policy-check">
                                <input
                                    type="checkbox"
                                    checked={form.enabled}
                                    onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                                />
                                Activa
                            </label>

                            <label className="threat-policy-wide">
                                Descripción
                                <input
                                    value={form.description}
                                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                                    maxLength={255}
                                />
                            </label>

                        </div>

                        <div className="threat-policy-form-actions">
                            <button type="submit" className="primary-button" disabled={working}>
                                {working ? "Guardando…" : editingId ? "Guardar cambios" : "Crear política"}
                            </button>
                            <button
                                type="button"
                                className="secondary-button"
                                onClick={reset}
                                disabled={working}
                            >
                                Cancelar
                            </button>
                        </div>

                    </form>

                </div>

            )}

        </section>

    );

}
