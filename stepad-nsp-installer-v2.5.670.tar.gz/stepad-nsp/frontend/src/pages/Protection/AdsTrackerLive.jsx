import { useEffect, useMemo, useState } from "react";

import { getAdsBlocked } from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./AdsTrackerLive.css";


const PERIODS = [
    { label: "Última hora", hours: 1 },
    { label: "24 horas", hours: 24 },
];


export default function AdsTrackerLive() {

    const [data, setData] = useState(null);

    const [hours, setHours] = useState(1);

    const [domainFilter, setDomainFilter] = useState("");

    const [deviceFilter, setDeviceFilter] = useState("");

    const [autoRefresh, setAutoRefresh] = useState(true);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState("");

    const [lastUpdated, setLastUpdated] = useState(null);


    async function load() {

        try {

            const result = await getAdsBlocked(hours, 200);

            setData(result);

            setLastUpdated(new Date());

            setError("");

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudieron leer los bloqueos de publicidad."
            );

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        setLoading(true);

        load();

        if (!autoRefresh) {

            return undefined;

        }

        const timer = setInterval(load, 8000);

        return () => clearInterval(timer);

    }, [hours, autoRefresh]);


    const recent = useMemo(() => {

        const domain = domainFilter.trim().toLowerCase();

        const device = deviceFilter.trim().toLowerCase();

        return (data?.recent || []).filter((row) => {

            const domainOk = domain === ""
                || (row.domain || "").toLowerCase().includes(domain);

            const deviceOk = device === ""
                || (row.device_name || "").toLowerCase().includes(device)
                || (row.client_ip || "").toLowerCase().includes(device);

            return domainOk && deviceOk;

        });

    }, [data, domainFilter, deviceFilter]);


    const category = data?.category;

    const active = Boolean(category?.enabled);


    return (

        <div className="ads-live">

            <div className="ads-live-head">

                <div>

                    <h3>Anuncios y rastreadores en vivo</h3>

                    <p>
                        Bloqueos DNS de la categoría, en el mismo estilo que el
                        flujo de IPS. No activa ni modifica la categoría.
                    </p>

                </div>

                <span className={`ads-live-status ${active ? "on" : "off"}`}>
                    {category
                        ? (active ? "Categoría activa" : "Categoría inactiva")
                        : "Sin categoría"}
                </span>

            </div>

            {
                !active && (
                    <div className="ads-live-warning">
                        <strong>La categoría está inactiva.</strong>
                        {" "}No habrá bloqueos nuevos de publicidad hasta activarla
                        en <a href="/security">Seguridad → Filtrado por categoría</a>.
                        Esta vista queda lista para cuando la actives.
                    </div>
                )
            }

            {error && <div className="threat-message">{error}</div>}

            <div className="ads-live-stats">

                <div className="ads-live-stat">
                    <span>Bloqueos</span>
                    <strong>{data?.total ?? 0}</strong>
                    <small>Intentos en el período</small>
                </div>

                <div className="ads-live-stat">
                    <span>Top dominios</span>
                    <strong>{data?.top_domains?.length ?? 0}</strong>
                    <small>Con más intentos</small>
                </div>

                <div className="ads-live-stat">
                    <span>Top equipos</span>
                    <strong>{data?.top_devices?.length ?? 0}</strong>
                    <small>Con más intentos</small>
                </div>

                <div className="ads-live-stat">
                    <span>Feed cargado</span>
                    <strong>{category?.domains ?? 0}</strong>
                    <small>Dominios en la categoría</small>
                </div>

            </div>

            <div className="ads-live-toolbar">

                <div className="ads-live-periods">

                    {
                        PERIODS.map((period) => (
                            <button
                                key={period.hours}
                                type="button"
                                className={hours === period.hours ? "active" : ""}
                                onClick={() => setHours(period.hours)}
                            >
                                {period.label}
                            </button>
                        ))
                    }

                </div>

                <input
                    type="search"
                    placeholder="Filtrar dominio..."
                    value={domainFilter}
                    onChange={(event) => setDomainFilter(event.target.value)}
                    autoComplete="off"
                />

                <input
                    type="search"
                    placeholder="Filtrar equipo o IP..."
                    value={deviceFilter}
                    onChange={(event) => setDeviceFilter(event.target.value)}
                    autoComplete="off"
                />

                <label className="ads-live-auto">
                    <input
                        type="checkbox"
                        checked={autoRefresh}
                        onChange={(event) => setAutoRefresh(event.target.checked)}
                    />
                    Auto 8 s
                </label>

                <button
                    type="button"
                    className="secondary-button"
                    onClick={load}
                    disabled={loading}
                >
                    {loading ? "Actualizando…" : "Actualizar ahora"}
                </button>

            </div>

            <p className="ads-live-updated">
                {lastUpdated
                    ? `Actualizado ${lastUpdated.toLocaleTimeString("es-EC")}`
                    : "Cargando bloqueos…"}
                {" · "}
                Mostrando {recent.length} de {data?.recent?.length ?? 0} bloqueos recientes.
            </p>

            <div className="ads-live-table-wrap">

                <table className="ads-live-table">

                    <thead>
                        <tr>
                            <th>Hora</th>
                            <th>Dominio bloqueado</th>
                            <th>Regla</th>
                            <th>Equipo</th>
                            <th>IP</th>
                        </tr>
                    </thead>

                    <tbody>

                        {
                            recent.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="ads-live-empty">
                                        {active
                                            ? "Sin bloqueos de publicidad en este período."
                                            : "La categoría está inactiva; todavía no hay bloqueos."}
                                    </td>
                                </tr>
                            ) : (
                                recent.map((row, index) => (
                                    <tr key={`${row.queried_at}-${row.domain}-${index}`}>
                                        <td>{formatDateTime(row.queried_at, "—")}</td>
                                        <td className="ads-live-domain">{row.domain}</td>
                                        <td className="ads-live-rule">{row.matched_rule || "—"}</td>
                                        <td>{row.device_name || "Desconocido"}</td>
                                        <td className="ads-live-ip">{row.client_ip || "—"}</td>
                                    </tr>
                                ))
                            )
                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}
