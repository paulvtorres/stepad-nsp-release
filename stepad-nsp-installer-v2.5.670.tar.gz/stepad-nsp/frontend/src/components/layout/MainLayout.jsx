import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import TopBar from "./TopBar";
import RestoreProgressBar from "./RestoreProgressBar";
import SecurityPostureBanner from "./SecurityPostureBanner";
import IdleTimeout from "../IdleTimeout";
import OrgSetupBanner from "../OrgSetupBanner";
import { useAuth } from "../../auth/useAuth";
import { usePersistentState } from "../../hooks/usePersistentState";
import { NetworkSegmentProvider } from "../../network/NetworkSegmentProvider";
import {
    favoriteNavItems,
    groupForPath,
    searchNavGroups,
    visibleNavGroups,
} from "../../constants/navigation";

const FAVORITES_KEY = "stepad.nav.favorites";

function FavoriteStar({ active, onToggle, label }) {
    return (
        <button
            type="button"
            className={`nav-star ${active ? "active" : ""}`}
            onClick={onToggle}
            aria-label={active ? `Quitar ${label} de favoritos` : `Añadir ${label} a favoritos`}
            title={active ? "Quitar de favoritos" : "Añadir a favoritos"}
        >
            {active ? "★" : "☆"}
        </button>
    );
}

function MainLayout() {

    const { user } = useAuth();

    const location = useLocation();

    const [sidebarOpen, setSidebarOpen] = useState(false);

    const [favorites, setFavorites] = usePersistentState(FAVORITES_KEY, []);

    const [query, setQuery] = useState("");

    const navGroups = visibleNavGroups(user);

    const favoritesVisible = favoriteNavItems(navGroups, favorites);

    const filteredGroups = searchNavGroups(navGroups, query);

    const searching = query.trim().length > 0;

    useEffect(() => {

        setSidebarOpen(false);

    }, [location.pathname]);

    const [openGroups, setOpenGroups] = useState(
        () => new Set([groupForPath(location.pathname, navGroups)])
    );

    useEffect(() => {

        setOpenGroups((prev) => {
            const next = new Set(prev);
            next.add(groupForPath(location.pathname, navGroups));
            return next;
        });

    }, [location.pathname, user?.role]);

    function toggleGroup(label) {

        setOpenGroups((prev) => {
            const next = new Set(prev);
            if (next.has(label)) {
                next.delete(label);
            } else {
                next.add(label);
            }
            return next;
        });
    }

    function toggleFavorite(path, event) {

        event.preventDefault();
        event.stopPropagation();

        setFavorites((prev) => (
            prev.includes(path)
                ? prev.filter((item) => item !== path)
                : [...prev, path]
        ));
    }

    function renderItem(item, keyPrefix = "") {

        return (
            <div className="nav-item-row" key={`${keyPrefix}${item.to}`}>
                <NavLink to={item.to} end={item.end}>
                    {item.label}
                </NavLink>
                <FavoriteStar
                    active={favorites.includes(item.to)}
                    label={item.label}
                    onToggle={(event) => toggleFavorite(item.to, event)}
                />
            </div>
        );
    }

    return (
        <NetworkSegmentProvider>
        <IdleTimeout>
            <div className="layout">

                <button
                    className={`hamburger ${sidebarOpen ? "open" : ""}`}
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                    aria-label="Abrir menú"
                    type="button"
                >
                    <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                    >
                        <line x1="3" y1="6" x2="21" y2="6" />
                        <line x1="3" y1="12" x2="21" y2="12" />
                        <line x1="3" y1="18" x2="21" y2="18" />
                    </svg>
                </button>

                {
                    sidebarOpen && (
                        <div
                            className="sidebar-backdrop"
                            onClick={() => setSidebarOpen(false)}
                        />
                    )
                }

                <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
                    <div className="sidebar-brand">
                        <h2>STEPAD NSP</h2>
                        <p className="sidebar-tagline">Network Security</p>
                    </div>

                    <div className="nav-search">
                        <input
                            type="search"
                            value={query}
                            onChange={(event) => setQuery(event.target.value)}
                            placeholder="Buscar opción…"
                            aria-label="Buscar opción del menú"
                        />
                        {query && (
                            <button
                                type="button"
                                className="nav-search-clear"
                                onClick={() => setQuery("")}
                                aria-label="Limpiar búsqueda"
                            >
                                ×
                            </button>
                        )}
                    </div>

                    {!searching && favoritesVisible.length > 0 && (
                        <div className="nav-favorites">
                            <div className="nav-favorites-title">Favoritos</div>
                            {favoritesVisible.map((item) => renderItem(item, "fav-"))}
                        </div>
                    )}

                    <nav className="sidebar-nav" aria-label="Menú principal">
                        {filteredGroups.map((group) => {
                            const isOpen = searching || openGroups.has(group.label);
                            const isSingle = group.items.length === 1;

                            if (isSingle) {
                                const item = group.items[0];

                                return (
                                    <div className="nav-single-wrap" key={group.id}>
                                        <NavLink
                                            to={item.to}
                                            end={item.end}
                                            className="nav-single"
                                        >
                                            {item.label}
                                        </NavLink>
                                        <FavoriteStar
                                            active={favorites.includes(item.to)}
                                            label={item.label}
                                            onToggle={(event) => toggleFavorite(item.to, event)}
                                        />
                                    </div>
                                );
                            }

                            return (
                                <div key={group.id} className="nav-group">
                                    <button
                                        className="nav-group-title"
                                        onClick={() => toggleGroup(group.label)}
                                        type="button"
                                        aria-expanded={isOpen}
                                    >
                                        <span>{group.label}</span>
                                        <span className="nav-group-chevron">
                                            {isOpen ? "▾" : "▸"}
                                        </span>
                                    </button>

                                    {
                                        isOpen && (
                                            <div className="nav-group-items">
                                                {group.items.map((item) => renderItem(item))}
                                            </div>
                                        )
                                    }
                                </div>
                            );
                        })}

                        {searching && filteredGroups.length === 0 && (
                            <p className="nav-empty">Sin resultados.</p>
                        )}
                    </nav>
                </aside>

                <div className="main-area">

                    <TopBar />
                    <RestoreProgressBar />
                    <SecurityPostureBanner />

                    <main className="content">
                        <OrgSetupBanner />
                        <Outlet />
                    </main>

                </div>

            </div>
        </IdleTimeout>
        </NetworkSegmentProvider>
    );
}

export default MainLayout;
