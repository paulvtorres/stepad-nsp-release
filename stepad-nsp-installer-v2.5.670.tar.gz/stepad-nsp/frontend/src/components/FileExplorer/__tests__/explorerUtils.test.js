import { describe, expect, it } from "vitest";
import {
    fileTypeLabel,
    formatBytes,
    iconFor,
    isDirItem,
    itemKey,
    previewKind,
    sortItems
} from "../explorerUtils";

describe("formatBytes", () => {
    it("handles invalid and zero values", () => {
        expect(formatBytes(null)).toBe("—");
        expect(formatBytes(-1)).toBe("—");
        expect(formatBytes("x")).toBe("—");
        expect(formatBytes(0)).toBe("0 B");
    });

    it("scales binary units", () => {
        expect(formatBytes(512)).toBe("512 B");
        expect(formatBytes(1024)).toBe("1.0 KB");
        expect(formatBytes(1536)).toBe("1.5 KB");
        expect(formatBytes(5 * 1024 ** 3)).toBe("5.0 GB");
    });
});

describe("item helpers", () => {
    it("detects directories by flag or type", () => {
        expect(isDirItem({ is_directory: true })).toBe(true);
        expect(isDirItem({ type: "dir" })).toBe(true);
        expect(isDirItem({ type: "file" })).toBe(false);
        expect(isDirItem(null)).toBe(false);
    });

    it("builds unique keys for search results", () => {
        expect(itemKey({ name: "a.txt" })).toBe("a.txt");
        expect(itemKey({ parent: "sub", name: "a.txt" })).toBe("sub/a.txt");
    });

    it("picks icons and labels", () => {
        expect(iconFor({ type: "dir" })).toBe("📁");
        expect(iconFor({ ext: "pdf" })).toBe("📕");
        expect(iconFor({ ext: "weird" })).toBe("📄");
        expect(fileTypeLabel({ type: "dir" })).toBe("Carpeta de archivos");
        expect(fileTypeLabel({ ext: "pdf" })).toBe("Documento PDF");
        expect(fileTypeLabel({ ext: "png" })).toBe("Imagen PNG");
        expect(fileTypeLabel({ ext: "" })).toBe("Archivo");
    });
});

describe("previewKind", () => {
    it("allows small previewable files", () => {
        expect(previewKind({ ext: "png", size: 1024 })).toEqual({
            kind: "image",
            mime: "image/png"
        });
        expect(previewKind({ ext: "pdf", size: 1024 }).kind).toBe("pdf");
        expect(previewKind({ ext: "txt", size: 10 }).kind).toBe("text");
    });

    it("rejects directories, unknown and oversized files", () => {
        expect(previewKind({ type: "dir" })).toBeNull();
        expect(previewKind({ ext: "exe", size: 10 })).toBeNull();
        expect(previewKind({ ext: "png", size: 100 * 1024 ** 2 })).toBeNull();
    });
});

describe("sortItems", () => {
    const items = [
        { name: "b.txt", size: 2, modified: "2026-01-02T00:00:00Z" },
        { name: "a.txt", size: 1, modified: "2026-01-01T00:00:00Z" },
        { name: "dir", type: "dir", item_count: 3, modified: "2025-01-01T00:00:00Z" }
    ];

    it("keeps folders first and sorts by name", () => {
        expect(sortItems(items, { key: "name", dir: "asc" }).map((i) => i.name))
            .toEqual(["dir", "a.txt", "b.txt"]);
    });

    it("sorts by size, items and modified", () => {
        expect(sortItems(items, { key: "size", dir: "asc" }).map((i) => i.name))
            .toEqual(["dir", "a.txt", "b.txt"]);
        expect(sortItems(items, { key: "items", dir: "desc" })[0].name).toBe("dir");
        expect(sortItems(items, { key: "modified", dir: "desc" })[1].name).toBe("b.txt");
    });
});
