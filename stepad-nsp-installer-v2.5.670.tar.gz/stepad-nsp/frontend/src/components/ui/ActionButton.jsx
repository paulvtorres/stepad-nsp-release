import { useState } from "react";

import "./ActionButton.css";


export default function ActionButton({

    children,

    variant = "primary",

    size = "md",

    loading = false,

    disabled = false,

    type = "button",

    onClick,

    className = "",

    ...rest

}) {

    const [pressed, setPressed] = useState(false);


    return (

        <button

            {...rest}

            type={type}

            className={[

                "action-button",

                `action-button-${variant}`,

                `action-button-${size}`,

                pressed ? "is-pressed" : "",

                loading ? "is-loading" : "",

                className,

            ].filter(Boolean).join(" ")}

            disabled={disabled || loading}

            aria-busy={loading || undefined}

            onPointerDown={(event) => {

                setPressed(true);

                rest.onPointerDown?.(event);

            }}

            onPointerUp={(event) => {

                setPressed(false);

                rest.onPointerUp?.(event);

            }}

            onPointerLeave={() => setPressed(false)}

            onPointerCancel={() => setPressed(false)}

            onClick={onClick}

        >

            {loading && <span className="action-button-spinner" aria-hidden="true" />}

            <span className="action-button-label">{children}</span>

        </button>

    );

}
