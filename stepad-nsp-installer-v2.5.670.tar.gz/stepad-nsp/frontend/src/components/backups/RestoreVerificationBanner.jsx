import { formatDateTime } from "../../utils/datetime";

export default function RestoreVerificationBanner({ check, checking, onVerify }) {
    return (
        <div className={`sh-banner ${check?.success ? "ok" : "warn"}`}>
            <strong>Verificación de restauración: </strong>
            {check
                ? (check.success
                    ? `OK · ${check.tables || 0} tablas · ${formatDateTime(check.last_run_at)}`
                    : (check.message || "falló"))
                : "sin datos"}
            <button
                type="button"
                className="sh-btn sh-btn-sm"
                style={{ marginLeft: 12 }}
                onClick={onVerify}
                disabled={checking}
            >
                {checking ? "Verificando…" : "Verificar ahora"}
            </button>
        </div>
    );
}
