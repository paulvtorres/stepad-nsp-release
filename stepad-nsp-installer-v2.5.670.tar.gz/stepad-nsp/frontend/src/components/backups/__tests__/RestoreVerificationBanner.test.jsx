import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import RestoreVerificationBanner from "../RestoreVerificationBanner";

describe("RestoreVerificationBanner", () => {
    it("muestra el éxito con tablas y fecha", () => {
        render(
            <RestoreVerificationBanner
                check={{ success: true, tables: 52, last_run_at: "2026-11-04T04:16:41Z" }}
                checking={false}
                onVerify={() => {}}
            />
        );

        expect(screen.getByText(/OK · 52 tablas/)).toBeInTheDocument();
    });

    it("muestra el error y dispara la verificación", () => {
        const onVerify = vi.fn();
        render(
            <RestoreVerificationBanner
                check={{ success: false, message: "falló la restauración" }}
                checking={false}
                onVerify={onVerify}
            />
        );

        expect(screen.getByText(/falló la restauración/)).toBeInTheDocument();
        fireEvent.click(screen.getByRole("button", { name: "Verificar ahora" }));
        expect(onVerify).toHaveBeenCalledTimes(1);
    });

    it("deshabilita el botón mientras verifica", () => {
        render(<RestoreVerificationBanner check={null} checking onVerify={() => {}} />);

        expect(screen.getByRole("button", { name: "Verificando…" })).toBeDisabled();
        expect(screen.getByText(/sin datos/)).toBeInTheDocument();
    });
});
