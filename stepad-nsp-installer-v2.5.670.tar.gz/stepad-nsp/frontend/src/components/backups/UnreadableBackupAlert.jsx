export default function UnreadableBackupAlert({ job }) {
    const count = Number(job?.unreadable_count || 0);
    if (count <= 0) return null;
    const samples = Array.isArray(job?.unreadable_samples) ? job.unreadable_samples : [];

    return (
        <div
            className="sh-bk-unreadable"
            role="alert"
            aria-live="polite"
            onClick={(event) => event.stopPropagation()}
        >
            <strong>
                ⚠️ {count} archivo{count === 1 ? "" : "s"} no se pudo leer y quedó fuera del respaldo
            </strong>
            <p>
                El snapshot se completó, pero esos archivos <b>no están incluidos</b>.
                El respaldo no está corrupto: el problema está en el origen.
            </p>
            <p className="sh-muted">
                Posibles causas: permisos/ACL, unidad de red desconectada, archivo bloqueado
                por otra aplicación o archivo que cambió durante el respaldo.
            </p>
            {samples.length > 0 && (
                <details>
                    <summary>Ver rutas y motivos ({samples.length} muestra{samples.length === 1 ? "" : "s"})</summary>
                    <ul>
                        {samples.map((sample, index) => (
                            <li key={`${index}-${sample}`}><code>{sample}</code></li>
                        ))}
                    </ul>
                </details>
            )}
            <p className="sh-muted">
                Revisa el acceso con el usuario del respaldo y vuelve a ejecutarlo después de corregir permisos o el montaje.
            </p>
        </div>
    );
}
