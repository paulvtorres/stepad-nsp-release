import { beforeEach, describe, expect, it } from "vitest";
import {
    clearSession,
    hasSession,
    markSession,
    removeToken,
    saveToken,
} from "../authStorage";

describe("authStorage", () => {
    beforeEach(() => {
        window.localStorage.clear();
    });

    it("tracks the session marker", () => {
        expect(hasSession()).toBe(false);
        markSession();
        expect(hasSession()).toBe(true);
        clearSession();
        expect(hasSession()).toBe(false);
    });

    it("removes the legacy token", () => {
        saveToken("x");
        expect(hasSession()).toBe(true);
        removeToken();
        expect(hasSession()).toBe(false);
    });
});
