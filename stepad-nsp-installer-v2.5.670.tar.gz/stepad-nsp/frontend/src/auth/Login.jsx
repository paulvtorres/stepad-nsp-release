import { useRef, useState } from "react";

import { useNavigate } from "react-router-dom";

import { loginMfa } from "../services/api";
import { login as loginRequest } from "./authService";
import { useAuth } from "./useAuth";


function ShieldMark() {

    return (
        <svg viewBox="0 0 48 54" fill="none" aria-hidden="true">
            <path
                d="M24 2.5 43 9v14.6c0 12.6-7.7 22.8-19 27.9C12.7 46.4 5 36.2 5 23.6V9l19-6.5Z"
                stroke="currentColor"
                strokeWidth="2.4"
                strokeLinejoin="round"
            />
            <path
                d="M24 13v18M15.5 22h17"
                stroke="currentColor"
                strokeWidth="2.4"
                strokeLinecap="round"
            />
        </svg>
    );
}


function UserIcon() {

    return (
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="12" cy="8" r="3.5" stroke="currentColor" strokeWidth="1.8" />
            <path d="M4.5 20c.8-4 3.4-6 7.5-6s6.7 2 7.5 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
    );
}


function LockIcon() {

    return (
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <rect x="5" y="10" width="14" height="10" rx="2.5" stroke="currentColor" strokeWidth="1.8" />
            <path d="M8 10V7.5a4 4 0 0 1 8 0V10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
    );
}


function EyeIcon({ hidden }) {

    return hidden ? (
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M2.5 12s3.6-6 9.5-6 9.5 6 9.5 6-3.6 6-9.5 6-9.5-6-9.5-6Z" stroke="currentColor" strokeWidth="1.8" />
            <circle cx="12" cy="12" r="2.7" stroke="currentColor" strokeWidth="1.8" />
        </svg>
    ) : (
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="m3 3 18 18M10.6 10.7a2.8 2.8 0 0 0 3.7 3.7M6.2 6.5C4 8 2.5 12 2.5 12s3.6 6 9.5 6c1.7 0 3.2-.5 4.5-1.2M17.4 17.2c2.1-1.4 3.6-5.2 3.6-5.2s-3.6-6-9.5-6c-.8 0-1.5.1-2.2.3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
    );
}


function Login() {

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [mfaToken, setMfaToken] = useState(null);
    const [mfaCode, setMfaCode] = useState("");
    const [error, setError] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [capsLock, setCapsLock] = useState(false);

    const codeRef = useRef(null);
    const { login } = useAuth();
    const navigate = useNavigate();


    function finish(result) {

        login(result.access_token);

        navigate(
            result.password_expired
                ? "/change-password"
                : result.mfa_setup_required
                    ? "/settings"
                    : "/"
        );
    }


    async function handleSubmit(event) {

        event.preventDefault();

        if (submitting) {
            return;
        }

        setError(null);
        setSubmitting(true);

        try {

            if (mfaToken) {

                const result = await loginMfa(
                    mfaToken,
                    mfaCode.trim()
                );

                finish(result);
                return;
            }

            const result = await loginRequest(
                username,
                password
            );

            if (result.mfa_required) {

                setMfaToken(result.mfa_token);
                setPassword("");
                setMfaCode("");
                setTimeout(
                    () => codeRef.current && codeRef.current.focus(),
                    0
                );
                return;
            }

            finish(result);

        } catch (requestError) {

            setError(
                requestError?.message
                || "No se pudo iniciar sesión. Intenta nuevamente."
            );

        } finally {

            setSubmitting(false);
        }
    }


    function handleMfaCode(value) {

        setMfaCode(
            value.replace(/\D/g, "").slice(0, 6)
        );
    }


    function backToCredentials() {

        setMfaToken(null);
        setMfaCode("");
        setError(null);
    }


    return (
        <main className="login-shell">
            <section className="login-card" aria-label="Acceso a STEPAD NSP">

                <aside className="login-visual">
                    <div>
                        <div className="login-brand">
                            <span className="login-brand-mark">
                                <ShieldMark />
                            </span>
                            <span>
                                <strong>STEPAD NSP</strong>
                                <small>Network Security Platform</small>
                            </span>
                        </div>

                        <div className="login-visual-copy">
                            <span className="login-kicker">ACCESO RESTRINGIDO</span>
                            <h1>Control total de tu red, en una sola consola.</h1>
                            <p>
                                Filtrado DNS, IPS, DHCP, cuarentena y auditoría
                                trabajando juntos para proteger cada equipo.
                            </p>
                        </div>

                        <ul className="login-features">
                            <li>
                                <span />
                                Visibilidad y bloqueo en tiempo real
                            </li>
                            <li>
                                <span />
                                Respuesta automática con evidencia
                            </li>
                            <li>
                                <span />
                                Acceso remoto protegido y auditado
                            </li>
                        </ul>
                    </div>

                    <div className="login-visual-foot">
                        <span className="login-live-dot" />
                        Plataforma operativa
                        <span className="login-visual-sep">·</span>
                        Sesión cifrada
                    </div>
                </aside>

                <section className="login-form-panel">
                    <div className="login-form-inner">

                        <div className="login-mobile-brand">
                            <span className="login-brand-mark">
                                <ShieldMark />
                            </span>
                            <strong>STEPAD NSP</strong>
                        </div>

                        <span className="login-kicker">
                            {mfaToken ? "VERIFICACIÓN EN DOS PASOS" : "BIENVENIDO"}
                        </span>

                        <h2>
                            {mfaToken ? "Confirma tu identidad" : "Inicia sesión"}
                        </h2>

                        <p className="login-form-copy">
                            {mfaToken
                                ? "Ingresa el código de 6 dígitos de tu aplicación de autenticación."
                                : "Usa tus credenciales corporativas para continuar."}
                        </p>

                        <form onSubmit={handleSubmit} aria-busy={submitting}>

                            {!mfaToken ? (
                                <>
                                    <div className="login-field">
                                        <label htmlFor="login-username">Usuario</label>
                                        <div className="login-input-wrap">
                                            <span className="login-input-icon"><UserIcon /></span>
                                            <input
                                                id="login-username"
                                                type="text"
                                                value={username}
                                                onChange={(event) => setUsername(event.target.value)}
                                                autoComplete="username"
                                                autoCapitalize="none"
                                                spellCheck="false"
                                                autoFocus
                                                required
                                                disabled={submitting}
                                            />
                                        </div>
                                    </div>

                                    <div className="login-field">
                                        <label htmlFor="login-password">Contraseña</label>
                                        <div className="login-input-wrap">
                                            <span className="login-input-icon"><LockIcon /></span>
                                            <input
                                                id="login-password"
                                                type={showPassword ? "text" : "password"}
                                                value={password}
                                                onChange={(event) => setPassword(event.target.value)}
                                                onKeyUp={(event) => setCapsLock(event.getModifierState?.("CapsLock") || false)}
                                                onKeyDown={(event) => setCapsLock(event.getModifierState?.("CapsLock") || false)}
                                                autoComplete="current-password"
                                                required
                                                disabled={submitting}
                                            />
                                            <button
                                                type="button"
                                                className="login-eye"
                                                onClick={() => setShowPassword((shown) => !shown)}
                                                aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                                                title={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                                            >
                                                <EyeIcon hidden={showPassword} />
                                            </button>
                                        </div>
                                        {capsLock && (
                                            <p className="login-caps">Bloq Mayús está activado.</p>
                                        )}
                                    </div>
                                </>
                            ) : (
                                <div className="login-field">
                                    <label htmlFor="login-mfa">Código de verificación</label>
                                    <div className="login-input-wrap login-input-mfa">
                                        <span className="login-input-icon"><LockIcon /></span>
                                        <input
                                            ref={codeRef}
                                            id="login-mfa"
                                            type="text"
                                            inputMode="numeric"
                                            autoComplete="one-time-code"
                                            value={mfaCode}
                                            onChange={(event) => handleMfaCode(event.target.value)}
                                            placeholder="000000"
                                            maxLength={6}
                                            required
                                            disabled={submitting}
                                        />
                                    </div>
                                    <p className="login-mfa-hint">
                                        El código cambia cada 30 segundos.
                                    </p>
                                </div>
                            )}

                            {error && (
                                <div className="login-error" role="alert" aria-live="polite">
                                    <span>!</span>
                                    <p>{error}</p>
                                </div>
                            )}

                            <button
                                type="submit"
                                className="login-submit"
                                disabled={submitting || (mfaToken && mfaCode.length !== 6)}
                            >
                                {submitting
                                    ? "Verificando..."
                                    : mfaToken
                                        ? "Verificar código"
                                        : "Iniciar sesión"}
                            </button>

                            {mfaToken && (
                                <button
                                    type="button"
                                    className="login-back"
                                    onClick={backToCredentials}
                                    disabled={submitting}
                                >
                                    Volver a las credenciales
                                </button>
                            )}
                        </form>

                        <div className="login-security-note">
                            <LockIcon />
                            <span>
                                Conexión cifrada. El acceso queda registrado en auditoría.
                            </span>
                        </div>

                        <p className="login-help">
                            ¿Problemas para acceder? Contacta al administrador del NSP.
                        </p>

                    </div>
                </section>

            </section>

            <p className="login-footer">
                STEPAD NSP · Plataforma de seguridad de red
            </p>
        </main>
    );
}


export default Login;
