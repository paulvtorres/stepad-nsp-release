import { getToken } from "../auth/authStorage";
import { notifyAuthExpired } from "../auth/authEvents";
import { begin, end } from "./busyStore";

// Matches userService.js's hardcoded "/api/v1" -- this needs the
// same default. Without it, every page except login/auth (which
// uses userService.js, not this file) silently breaks: fetch()
// resolves "undefined/interfaces/..." as a relative path that never
// reaches Vite's "/api" proxy rule, and Vite serves its own
// index.html for the unmatched route instead -- which is why the
// error in the browser console is a JSON parse failure on HTML
// ("Unexpected token '<'"), not a network error.
const API_URL = import.meta.env.VITE_API_URL || "/api/v1";

const BUSY_LABELS = [
    [/\/mkdir/, "Creando carpeta"],
    [/\/upload/, "Subiendo archivos"],
    [/\/download/, "Descargando"],
    [/\/move/, "Moviendo"],
    [/\/copy/, "Copiando"],
    [/\/rename/, "Renombrando"],
    [/\/search/, "Buscando"],
    [/\/shares\/web$/, "Eliminando"],
    [/\/delete/, "Eliminando"],
    [/\/share$/, "Actualizando acceso"],
    [/\/format/, "Formateando"],
    [/\/activate/, "Activando unidad"],
    [/\/deactivate/, "Desactivando unidad"],
    [/\/partition/, "Creando partición"],
    [/\/restore/, "Restaurando respaldo"],
    [/\/backups\/\d+\/run|backup\/(?!.*restore)/, "Ejecutando respaldo"],
    [/backup/, "Procesando respaldo"],
    [/\/integrity/, "Verificando"],
    [/\/pause/, "Editando"],
];

function busyLabel(endpoint = "") {
    const path = String(endpoint).split("?")[0];
    for (const [pattern, label] of BUSY_LABELS) {
        if (pattern.test(path)) {
            return label;
        }
    }
    return "Procesando";
}

function busyKey(method, endpoint) {
    return `${method}:${endpoint}`;
}


async function request(
    endpoint,
    options = {}
) {

    const token = getToken();

    const timeoutMs = options.timeoutMs;

    const controller = timeoutMs ? new AbortController() : null;

    const timeoutId = controller
        ? setTimeout(() => controller.abort(), timeoutMs)
        : null;

    const key = busyKey(options.method || "GET", endpoint);
    const label = options.busyLabel || busyLabel(endpoint);
    begin(key, label);

    try {

        const response = await fetch(

            `${API_URL}${endpoint}${endpoint.includes("?") ? "&" : "?"}_t=${Date.now()}`,

            {
                ...options,

                credentials: "same-origin",

                signal: controller?.signal,

                headers: {

                    "Content-Type":
                        "application/json",


                    ...(token && {

                        Authorization:
                            `Bearer ${token}`

                    }),


                    ...options.headers

                }

            }

        );



        if (response.status === 401) {

            notifyAuthExpired();

            throw new Error("Unauthorized");

        }

        if (!response.ok) {

            let detail = `API Error ${response.status}`;

            try {

                const body = await response.json();

                if (body && body.detail) {

                    detail = body.detail;

                }

            } catch {

                // response wasn't JSON -- keep the generic message

            }

            throw new Error(detail);

        }



        const contentType = response.headers.get("content-type") || "";

        if (!contentType.includes("application/json")) {

            throw new Error(
                `Respuesta inesperada (${contentType || "no JSON"}) en ${endpoint}`
            );

        }



        return response.json();

    } catch (error) {

        if (error?.name === "AbortError") {

            throw new Error(
                "La operación tardó demasiado. Revise la conexión SMTP "
                + "o intente de nuevo.",
                { cause: error }
            );

        }

        throw error;

    } finally {

        if (timeoutId) {

            clearTimeout(timeoutId);

        }

        end(key);

    }

}



export const apiClient = {


    get(endpoint) {

        return request(
            endpoint
        );

    },


    post(endpoint, data, options = {}) {

        return request(

            endpoint,

            {

                method: "POST",

                body:
                    JSON.stringify(data),

                ...options,

                credentials: "same-origin",

            }

        );

    },


    patch(endpoint, data) {

        return request(

            endpoint,

            {

                method: "PATCH",

                body:
                    JSON.stringify(data)

            }

        );

    },


    put(endpoint, data, options = {}) {

        return request(

            endpoint,

            {

                method: "PUT",

                body:
                    JSON.stringify(data),

                ...options,

                credentials: "same-origin",

            }

        );

    },


    delete(endpoint) {

        return request(

            endpoint,

            {

                method: "DELETE"

            }

        );

    },


    async download(endpoint) {

        const key = busyKey("GET", endpoint);
        const label = busyLabel(endpoint);
        begin(key, label);

        try {

            const token = getToken();

            const response = await fetch(

                `${API_URL}${endpoint}${endpoint.includes("?") ? "&" : "?"}_t=${Date.now()}`,

                {
                    headers: {

                        ...(token && {

                            Authorization:
                                `Bearer ${token}`

                        })

                    }
                }

            );

            if (response.status === 401) {

                notifyAuthExpired();

                throw new Error("Unauthorized");

            }

            if (!response.ok) {

                throw new Error(`API Error ${response.status}`);

            }

            return response.blob();

        } finally {
            end(key);
        }

    },

    async downloadPost(endpoint, data) {

        const key = busyKey("POST", endpoint);
        const label = busyLabel(endpoint);
        begin(key, label);

        try {

            const token = getToken();

            const response = await fetch(

                `${API_URL}${endpoint}${endpoint.includes("?") ? "&" : "?"}_t=${Date.now()}`,

                {
                    method: "POST",
                    headers: {

                        "Content-Type": "application/json",

                        ...(token && {

                            Authorization:
                                `Bearer ${token}`

                        })

                    },
                    body: JSON.stringify(data || {}),
                    credentials: "same-origin"
                }

            );

            if (response.status === 401) {

                notifyAuthExpired();

                throw new Error("Unauthorized");

            }

            if (!response.ok) {

                let detail = `API Error ${response.status}`;

                try {

                    const body = await response.json();

                    if (body && body.detail) {

                        detail = body.detail;

                    }

                } catch {

                    // not JSON

                }

                throw new Error(detail);

            }

            const disposition =
                response.headers.get("content-disposition") || "";
            const match = /filename="?([^";]+)"?/.exec(disposition);

            return {
                blob: await response.blob(),
                filename: match ? match[1] : "stepad-download.bin"
            };

        } finally {
            end(key);
        }

    },


    async upload(endpoint, formData) {

        const key = busyKey("POST", endpoint);
        const label = busyLabel(endpoint);
        begin(key, label);

        try {

            const token = getToken();

            const response = await fetch(

                `${API_URL}${endpoint}${endpoint.includes("?") ? "&" : "?"}_t=${Date.now()}`,

                {
                    method: "POST",
                    headers: {

                        ...(token && {

                            Authorization:
                                `Bearer ${token}`

                        })

                    },
                    body: formData
                }

            );

            if (response.status === 401) {

                notifyAuthExpired();

                throw new Error("Unauthorized");

            }

            if (!response.ok) {

                let detail = `API Error ${response.status}`;

                try {

                    const body = await response.json();

                    if (body && body.detail) {

                        detail = body.detail;

                    }

                } catch {

                    // not JSON

                }

                throw new Error(detail);

            }

            return response.json();

        } finally {
            end(key);
        }

    }


};