# Laboratorio de integración

Las pruebas unitarias simulan la red y usan sqlite. El laboratorio comprueba
contra componentes **reales** lo que de otro modo solo se supone.

    sudo -E scripts/integration-lab.sh          # en un host Debian/Ubuntu
    docker build -f docker/lab/Dockerfile -t stepad-lab . \
      && docker run --rm --cap-add=NET_ADMIN --cap-add=SYS_ADMIN stepad-lab

## Qué cubre
1. **Suite unitaria** (sqlite).
2. **PostgreSQL real**: `alembic upgrade head` desde cero y las pruebas de
   presencia, eventos, IPAM, alertas y cuarentena con el esquema de las
   *migraciones* (índices únicos parciales, FK y tipos reales).
   `STEPAD_TEST_DB_URL=postgresql+psycopg2://...` activa este modo en
   cualquier prueba que use `backend/tests/db_support.py::make_session`.
3. **dnsmasq y dhclient reales** en dos espacios de red unidos por veth
   (`backend/tests/integration/`):
   - la configuración que genera el NSP pasa `dnsmasq --test`;
   - lease nuevo, renovación y liberación llegan como eventos
     (`add` / `old` / `del`);
   - una reserva en `dhcp-hostsfile` se aplica con SIGHUP **sin** reiniciar;
   - sin direcciones, el log real contiene lo que busca el monitor;
   - los eventos reales ponen al equipo ONLINE;
   - el caso central: pool lleno, un equipo ausente retiene la IP, se libera
     su lease y otro equipo la obtiene;
   - un script sin permiso de ejecución se detecta con `DHCP_EVENTS_SILENT`;
   - **carga:** 120 equipos nuevos piden IP en el mismo instante (cliente de
     carga propio, `dhcp_storm.py`): todos reciben IP única en < 1 s, llegan
     sus 120 eventos y el servicio los procesa; con un pool de 40 y 55 equipos
     nadie recibe una IP repetida;
   - activar `ping_check` hace que los equipos nuevos se demoren (se mide).

Si falta root, `ip`, `dnsmasq`, `dhclient` o `CAP_NET_ADMIN`, las pruebas de red
se **omiten** solas. `pytest -m "not integration"` las excluye.

## Verificado con dnsmasq 2.91 / PostgreSQL 16
- `--dhcp-script`, `--script-on-renewal`, `--dhcp-hostsfile` y
  `--bind-dynamic` existen y funcionan como supone el NSP.
- `dnsmasq --no-daemon` (como lo lanza el NSP) **no escribe pid-file ni cambia
  de usuario**; el PID es el del proceso hijo.
- dnsmasq ejecuta el script como **root** por defecto (`--dhcp-scriptuser`).
- Las migraciones 0001→0061 se aplican desde cero en ~2 s.
