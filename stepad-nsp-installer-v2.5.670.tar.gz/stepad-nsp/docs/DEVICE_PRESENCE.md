# Presencia de dispositivos

El listado de dispositivos muestra **lo que se observó en la red**, con su
fuente y antigüedad. Un solo servicio escribe el estado:
`DevicePresenceService` (`backend/network/devices/services/device_presence_service.py`).
La regla de decisión es una función pura, `derive_presence`
(`backend/network/devices/domain/presence.py`), probada en tabla.

## Reglas

| Concepto | Regla |
|---|---|
| Lease DHCP | Es una **asignación** (`assigned_ip`). Nunca decide si el equipo está conectado. |
| ONLINE | Evidencia fuerte de hace ≤ 5 min: ARP alcanzable (`REACHABLE/DELAY/PROBE`) o consulta DNS de esa IP. |
| PROBABLE | Evidencia de hace ≤ 30 min, o una entrada ARP `STALE` vista por primera vez. |
| OFFLINE | Sin evidencia dentro de la ventana. `current_ip` queda vacía y `last_ip` se conserva. |
| ARP `STALE` | El kernel solo recuerda al vecino (no purga con pocas entradas). Se registra **una vez**; nunca renueva la presencia. |
| Evento DHCP | Lease nuevo (`add`) o renovación (`old`): el cliente acaba de hablar con el servidor. Evidencia **fuerte** (ONLINE ≤ 5 min). Un `del` (vencido/liberado) la retira al instante; si el ARP aún ve al equipo, el ARP gana. |
| DNS | Se atribuye solo si la IP tiene **un único** reclamante (lease o ARP). |
| Conflicto | La IP la usa (ARP alcanzable) una MAC distinta de la del lease. Se marca `ip_conflict` en ambos equipos; **no** se le quita la IP a nadie. |

Los TTL están en `PresencePolicy`. El estado envejece por la hora de la
**última evidencia** (`presence_at`), no por la hora en que corre el
reconciliador.

## Quién escribe qué

* `DevicePresenceService`: `current_ip`, `assigned_ip`, `last_ip`,
  `presence_*`, `ip_conflict` y, por compatibilidad, `status`, `last_seen`
  e `ip_address` (espejo de la última IP).
* Descubrimiento (`DeviceDiscoveryService`): identidad (nombre, fabricante,
  tipo, interfaz). **No** escribe estado ni `last_seen`.
* `IpOwnershipService`: guarda la IP y su historial; no expulsa a nadie.

Esto se hace cumplir en CI: `backend/tests/test_device_single_writer.py`
falla si otro módulo asigna esos campos en un dispositivo. La antigua
deduplicación de dueños de IP (`deduplicate_ip_owners`) se retiró: limpiaba
`ip_address` y marcaba OFFLINE a un equipo que podía estar conectado,
ocultando justo el conflicto.

`last_seen` solo avanza con evidencia **fuerte** (lo usan el reciclaje de
leases del DHCP y la limpieza programada).

## Verificación activa

En cada pasada, los equipos sin evidencia fresca reciben un ping en paralelo
(máx. 128). Sirve para que el kernel resuelva ARP: un equipo que bloquea
ICMP igual contesta ARP, y queda como `arp_reachable`.

## Depuración

```sql
-- Por qué un equipo está como está
SELECT source, ip_address, observed_at
FROM device_ip_observations
WHERE mac_address = 'aa:bb:cc:dd:ee:ff'
ORDER BY observed_at DESC;
```

Las observaciones se purgan a los 7 días.

## Rendimiento
Una pasada lee todos los equipos y las observaciones de los últimos 7 días y
escribe solo lo que cambia. Medido con red simulada y sqlite: 500 equipos
0,05 s; 2000 equipos 0,18 s; 8000 equipos 0,8 s (la segunda pasada, 0,5 s).
El crecimiento es lineal (antes el registro de entradas ARP STALE recorría
todas las observaciones por cada entrada y era cuadrático).
