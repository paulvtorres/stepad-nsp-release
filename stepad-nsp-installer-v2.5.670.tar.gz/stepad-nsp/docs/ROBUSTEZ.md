# Robustez operativa

## El NSP vigila su propia salida de alertas
El monitor revisa la bandeja persistente de correos y de webhooks cada ciclo:
- **Correo** con filas fallidas (24 h) o pendientes hace más de 30 min →
  alerta `EMAIL_DELIVERY_FAILING` (aviso). Sale por webhook y queda en el panel.
- **Webhooks** con entregas fallidas o pendientes → alerta
  `WEBHOOK_DELIVERY_FAILING` (crítica). Llega por correo.
- Se resuelven solas al normalizarse. El aviso de webhooks no se reenvía por
  webhook (evita bucles).
- Reintentos: correo 12 intentos (~10 h de espera creciente), webhooks 8 (~5 h).

## Latido externo (dead-man switch)
Si el NSP cae, nadie recibe alertas. Un servicio externo avisa cuando el NSP
**deja de latir**:

    STEPAD_HEARTBEAT_URL=https://hc-ping.com/<uuid>     # vacía = desactivado
    STEPAD_HEARTBEAT_INTERVAL=300                        # 60..3600 s

Solo late con la base de datos accesible (un NSP que no puede consultar su base
no dice que está bien). Usa las mismas reglas de destino que los webhooks
(sin loopback ni metadata) y no sigue redirecciones.

## Salvaguarda de la cuarentena
`protect_infrastructure` se puede apagar, pero **nunca** se aísla (aunque esté
apagada) al propio NSP (sus IPs o MACs) ni a la puerta de enlace / DNS del
segmento. Solo se aísla a un dueño de IP **verificado** (ver `owner_of`).

## subprocess siempre con timeout
Todo comando corto (`nft`, `ip`, `tc`, `dnsmasq`, `openssl`...) lleva
`timeout=30`. `backend/tests/test_subprocess_timeouts.py` falla si aparece una
llamada nueva sin timeout; la lista de excepciones (respaldos, descarga de
listas) solo puede bajar.

## Esquema = modelos
`alembic check` (en `scripts/integration-lab.sh`) falla si los modelos y las
migraciones difieren. `backend/tests/test_models_registry_complete.py` exige que
todo modelo esté en `core/database/models_registry.py`.
