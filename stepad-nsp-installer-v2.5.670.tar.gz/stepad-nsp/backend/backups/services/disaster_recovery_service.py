"""Disaster-recovery readiness based on real backups and restore tests."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from backend.shared.datetime_utils import utcnow


class DisasterRecoveryService:

    BACKUP_MAX_AGE_HOURS = 36
    RESTORE_MAX_AGE_DAYS = 30

    @staticmethod
    def _parse(value):
        if not value:
            return None
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return None
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
        return parsed

    def get(self, db):

        from backend.backups.services.backup_service import BackupService
        from backend.backups.services.restore_verification_service import (
            RestoreVerificationService,
        )

        checks = []
        recommendations = []
        backup_settings = BackupService().get_settings(db)
        last_backup_raw = backup_settings.get("last_backup_at")
        last_backup = self._parse(last_backup_raw)
        now = utcnow()
        age_hours = None

        if last_backup:
            age_hours = max(0, (now - last_backup).total_seconds() / 3600)

        backup_ok = age_hours is not None and age_hours <= self.BACKUP_MAX_AGE_HOURS
        checks.append({
            "key": "backup_age",
            "label": "Respaldo reciente",
            "ok": backup_ok,
            "detail": (
                f"Último respaldo hace {age_hours:.1f} h"
                if age_hours is not None
                else "Sin respaldos registrados"
            ),
            "action": "Ejecutar un respaldo ahora." if not backup_ok else "",
        })
        if not backup_ok:
            recommendations.append("Ejecutar un respaldo completo y verificar el destino.")

        restore = RestoreVerificationService().status()
        restore_last = self._parse(restore.get("last_run_at"))
        restore_age_days = (
            (utcnow() - restore_last).total_seconds() / 86400
            if restore_last else None
        )
        restore_ok = bool(restore.get("success")) and (
            restore_age_days is None
            or restore_age_days <= self.RESTORE_MAX_AGE_DAYS
        )
        checks.append({
            "key": "restore_test",
            "label": "Prueba de restauración",
            "ok": restore_ok,
            "detail": restore.get("message") or "sin verificaciones",
            "action": (
                "Ejecutar una verificación de restauración."
                if not restore_ok else ""
            ),
        })
        if not restore_ok:
            recommendations.append("Ejecutar una verificación real de restauración.")

        try:
            from backend.backups.services.system_restore_verification_service import (
                SystemRestoreVerificationService,
            )

            sys_state = SystemRestoreVerificationService().status()
            sys_last = self._parse(sys_state.get("last_run_at"))
            sys_ok = bool(sys_state.get("success")) or bool(sys_state.get("skipped"))
            checks.append({
                "key": "system_restore",
                "label": "Respaldo del sistema",
                "ok": sys_ok,
                "detail": sys_state.get("message") or "sin verificaciones",
                "action": "" if sys_ok else "Revisar respaldo del sistema.",
            })
        except Exception as error:

            checks.append({
                "key": "system_restore",
                "label": "Respaldo del sistema",
                "ok": False,
                "detail": str(error)[:300],
                "action": "Revisar respaldo del sistema.",
            })

        ready = all(check["ok"] for check in checks)

        return {
            "ready": ready,
            "status": "ready" if ready else "degraded",
            "rpo_minutes": (
                round(age_hours * 60, 1) if age_hours is not None else None
            ),
            "rpo_target_minutes": self.BACKUP_MAX_AGE_HOURS * 60,
            "checks": checks,
            "recommendations": recommendations,
            "generated_at": utcnow().isoformat(),
        }
