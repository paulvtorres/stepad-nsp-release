from __future__ import annotations

import json

from backend.shared.datetime_utils import utcnow
from backend.autonomy.models.change_transaction import ChangeTransaction


class ChangeTransactionService:

    def begin(self, db, action: str, target: str, before: dict) -> ChangeTransaction:
        tx = ChangeTransaction(
            action=action,
            target=target,
            status="pending",
            before_json=json.dumps(before, ensure_ascii=False),
        )
        db.add(tx)
        db.commit()
        db.refresh(tx)
        return tx

    def finish(
        self,
        db,
        tx: ChangeTransaction,
        status: str,
        after: dict | None = None,
        error: str | None = None,
    ) -> ChangeTransaction:
        tx.status = status
        tx.after_json = json.dumps(after or {}, ensure_ascii=False)
        tx.error = (error or "")[:2000] or None
        tx.finished_at = utcnow()
        db.add(tx)
        db.commit()
        db.refresh(tx)
        return tx

    def list(self, db, limit: int = 30) -> list[dict]:
        rows = (
            db.query(ChangeTransaction)
            .order_by(ChangeTransaction.started_at.desc())
            .limit(max(1, min(limit, 100)))
            .all()
        )
        return [
            {
                "id": row.id,
                "action": row.action,
                "target": row.target,
                "status": row.status,
                "before": row.before_json,
                "after": row.after_json,
                "error": row.error,
                "started_at": row.started_at.isoformat() if row.started_at else None,
                "finished_at": row.finished_at.isoformat() if row.finished_at else None,
            }
            for row in rows
        ]
