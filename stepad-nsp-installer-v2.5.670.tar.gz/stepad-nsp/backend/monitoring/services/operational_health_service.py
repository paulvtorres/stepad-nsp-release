"""Single operational-health view for the dashboard."""

from __future__ import annotations

from backend.shared.datetime_utils import utcnow


class OperationalHealthService:

    LABELS = {
        "internet": "Internet",
        "dhcp": "DHCP",
        "dns": "DNS",
        "log_listener": "Registro DNS",
        "forwarding": "NAT / forwarding",
        "suricata": "IPS / Suricata",
        "disk": "Disco",
        "zones_dns": "DNS por zonas",
        "conflicto": "Conflictos de red",
        "postgres": "PostgreSQL",
        "tailscale": "Tailscale",
    }

    ACTIONS = {
        "internet": "Revisar WAN, gateway o DNS.",
        "dhcp": "Revisar dnsmasq, pool y leases.",
        "dns": "Revisar dnsmasq/pdns-recursor.",
        "log_listener": "Revisar listener DNS 4242.",
        "forwarding": "Revisar net.ipv4.ip_forward y NAT.",
        "suricata": "Revisar Suricata/NFQUEUE.",
        "disk": "Liberar espacio o ampliar disco.",
        "zones_dns": "Revisar zonas y resolución.",
        "conflicto": "Revisar IPs duplicadas/ARP.",
        "postgres": "Revisar PostgreSQL.",
        "tailscale": "Revisar tailscaled.",
    }

    def get(self, db):

        checks = []

        def add(key, label, ok, detail, action="", link=""):

            checks.append({
                "key": key,
                "label": label,
                "status": "ok" if ok else "critical",
                "detail": detail or "",
                "action": action,
                "link": link,
            })

        try:

            from backend.monitoring.services.navigation_health_service import (
                NavigationHealthService,
            )

            nav = NavigationHealthService().inspect(db)

        except Exception as error:

            add("network_health", "Salud de red", False, str(error)[:300])

            nav = {"checks": {}}

        for key, item in (nav.get("checks") or {}).items():

            add(
                key,
                self.LABELS.get(key, key.replace("_", " ").title()),
                bool(item.get("ok")),
                item.get("detail"),
                self.ACTIONS.get(key, ""),
                "/network",
            )

        try:

            from backend.notifications.services.email_settings_service import (
                EmailSettingsService,
            )

            smtp = EmailSettingsService().get_settings(db)

            add(
                "smtp",
                "Correo / SMTP",
                bool(smtp.get("config_ready")),
                (
                    "Cuenta SMTP configurada"
                    if smtp.get("config_ready")
                    else ", ".join(smtp.get("config_issues") or [])
                ),
                "Revisar Ajustes → Correo.",
                "/settings",
            )

        except Exception as error:

            add("smtp", "Correo / SMTP", False, str(error)[:300])

        try:

            from backend.notifications.services.email_outbox_service import (
                EmailOutboxService,
            )

            outbox = EmailOutboxService().list_items(db, 100, status="all")
            failed = [item for item in outbox if item.get("status") == "failed"]

            add(
                "email_outbox",
                "Cola de correo",
                not failed,
                (
                    f"{len(failed)} correo(s) fallido(s)"
                    if failed
                    else f"{len(outbox)} pendiente(s)"
                ),
                "Revisar Ajustes → Correo → Cola de salida.",
                "/settings",
            )

        except Exception as error:

            add("email_outbox", "Cola de correo", False, str(error)[:300])

        try:

            from backend.backups.services.restore_verification_service import (
                RestoreVerificationService,
            )

            restore = RestoreVerificationService().status()

            add(
                "restore_verify",
                "Verificación de restauración",
                bool(restore.get("success")),
                restore.get("message", "sin verificaciones"),
                "Ejecutar una verificación de restauración.",
                "/backups",
            )

        except Exception as error:

            add(
                "restore_verify",
                "Verificación de restauración",
                False,
                str(error)[:300],
            )

        counts = {"ok": 0, "warning": 0, "critical": 0}

        for check in checks:

            counts[check["status"]] = counts.get(check["status"], 0) + 1

        if counts["critical"]:

            status = "critical"

        elif counts["warning"]:

            status = "warning"

        else:

            status = "ok"

        return {
            "status": status,
            "generated_at": utcnow().isoformat(),
            "summary": counts,
            "checks": checks,
        }
