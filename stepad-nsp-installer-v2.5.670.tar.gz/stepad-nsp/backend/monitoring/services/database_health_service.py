"""Database growth visibility for capacity planning."""

from __future__ import annotations

from sqlalchemy import text

from backend.shared.datetime_utils import utcnow


SIZE_WARNING_BYTES = 2 * 1024 * 1024 * 1024
DEAD_RATIO_WARNING = 0.20


class DatabaseHealthService:

    def get(self, db, limit: int = 15):

        rows = db.execute(
            text(
                """
                SELECT relname,
                       n_live_tup,
                       n_dead_tup,
                       pg_total_relation_size(relid) AS total_bytes,
                       pg_size_pretty(pg_total_relation_size(relid)) AS pretty,
                       last_vacuum,
                       last_autovacuum
                FROM pg_stat_user_tables
                ORDER BY pg_total_relation_size(relid) DESC
                LIMIT :limit
                """
            ),
            {"limit": max(1, min(int(limit), 50))},
        ).mappings().all()

        tables = []
        warnings = []
        total_bytes = 0

        for row in rows:

            live = int(row["n_live_tup"] or 0)
            dead = int(row["n_dead_tup"] or 0)
            size = int(row["total_bytes"] or 0)
            total_bytes += size
            ratio = (dead / (live + dead)) if (live + dead) else 0

            item = {
                "table": row["relname"],
                "rows": live,
                "dead_rows": dead,
                "dead_ratio": round(ratio, 3),
                "bytes": size,
                "size": row["pretty"],
                "last_vacuum": (
                    row["last_vacuum"].isoformat()
                    if row["last_vacuum"] else None
                ),
                "last_autovacuum": (
                    row["last_autovacuum"].isoformat()
                    if row["last_autovacuum"] else None
                ),
            }
            tables.append(item)

            if size >= SIZE_WARNING_BYTES:

                warnings.append(
                    f"{row['relname']} ocupa {row['pretty']}; "
                    "revisar retención o particionado."
                )

            if live + dead >= 10000 and ratio >= DEAD_RATIO_WARNING:

                warnings.append(
                    f"{row['relname']} tiene {dead} filas muertas "
                    f"({ratio:.0%}); ejecutar VACUUM ANALYZE."
                )

        return {
            "generated_at": utcnow().isoformat(),
            "tables": tables,
            "total_bytes": total_bytes,
            "warnings": warnings,
        }
