"""Latido externo ("dead-man switch").

Si el NSP se cae, deja de avisar: las alertas no llegan a nadie. Un latido
periodico a un servicio EXTERNO (healthchecks.io, Uptime Kuma, un monitor
propio en otra maquina) invierte el problema: es ese servicio el que avisa
cuando el NSP deja de latir.

Configuracion (variables de entorno):
    STEPAD_HEARTBEAT_URL        URL a la que se hace GET (vacia = desactivado)
    STEPAD_HEARTBEAT_INTERVAL   segundos entre latidos (60..3600, defecto 300)

Solo se late cuando el monitor llega a este punto con la base de datos
accesible: un NSP que no puede consultar su base NO late.
"""

from __future__ import annotations

import os
import threading
import time
import urllib.request

from backend.integrations.services.webhook_service import (
    _NoRedirect,
    validate_webhook_url,
)
from backend.shared.logging.logger import logger

DEFAULT_INTERVAL = 300


class HeartbeatService:

    # Compartido: el monitor puede crear instancias nuevas.
    _last_sent: float = float("-inf")

    _failures: int = 0

    _lock = threading.Lock()

    def __init__(self, url: str | None = None, interval: int | None = None,
                 clock=time.monotonic, opener=None):

        self.url = (url if url is not None else os.environ.get("STEPAD_HEARTBEAT_URL", "")).strip()

        raw = interval if interval is not None else os.environ.get("STEPAD_HEARTBEAT_INTERVAL")

        try:

            self.interval = max(60, min(3600, int(raw))) if raw else DEFAULT_INTERVAL

        except (TypeError, ValueError):

            self.interval = DEFAULT_INTERVAL

        self._clock = clock

        self._opener = opener or self._default_open

    @staticmethod
    def _default_open(url: str) -> int:

        request = urllib.request.Request(url, headers={"User-Agent": "STEPAD-NSP-heartbeat/1.0"})

        with urllib.request.build_opener(_NoRedirect).open(request, timeout=10) as response:

            return response.status

    @classmethod
    def reset(cls) -> None:

        with cls._lock:

            cls._last_sent = float("-inf")

            cls._failures = 0

    def tick(self, db=None) -> str | None:
        """Late si toca. Devuelve "sent", "failed" o None (no corresponde)."""

        if not self.url:

            return None

        now = self._clock()

        with self._lock:

            if now - self._last_sent < self.interval:

                return None

            self.__class__._last_sent = now

        if db is not None:

            try:

                from sqlalchemy import text

                db.execute(text("SELECT 1"))

            except Exception as error:

                # Sin base de datos el NSP no esta sano: NO late.
                logger.warning("Heartbeat omitido: base de datos inaccesible (%s)", error)

                return None

        try:

            validate_webhook_url(self.url)

            status = self._opener(self.url)

            if int(status) >= 300:

                raise RuntimeError(f"HTTP {status}")

            with self._lock:

                self.__class__._failures = 0

            return "sent"

        except Exception as error:

            with self._lock:

                self.__class__._failures += 1

                failures = self._failures

            # No inundar el log: un aviso al primer fallo y luego cada 10.
            if failures == 1 or failures % 10 == 0:

                logger.warning("Heartbeat fallido (%s seguidos): %s", failures, error)

            return "failed"
