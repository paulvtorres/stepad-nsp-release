from dataclasses import dataclass, field


@dataclass
class DhcpConfig:

    interface: str

    network: str

    netmask: str

    gateway: str

    dns_server: str

    pool_start: str

    pool_end: str

    lease_time: str

    # IPs que el DHCP no debe entregar nunca (dispositivos con IP estatica).
    excluded_ips: list[str] = field(default_factory=list)

    # Subrango exclusivo para alias DNS de grupos (no se mezcla con equipos).
    group_ip_start: str | None = None

    group_ip_end: str | None = None

    group_ip_count: int | None = None

    # Ping previo de dnsmasq antes de ofrecer una IP NUEVA. Medido con dnsmasq
    # real: 30 equipos nuevos tardan 18 s con el ping y 120 equipos tardan
    # 0,6 s sin el (el ping espera hasta 3 s por tanda). Tras un corte de luz
    # eso deja equipos sin IP (Windows cae a 169.254.x.x y reintenta cada 5
    # min). Los conflictos de IP fija los cubre el NSP (ARP verificado).
    ping_check: bool = False