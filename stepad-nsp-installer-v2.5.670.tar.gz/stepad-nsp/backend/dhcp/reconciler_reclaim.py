"""Reciclaje de leases de equipos ausentes cuando el pool se queda sin IPs.
Se mezcla en DhcpReconciler.
"""

from __future__ import annotations

from backend.shared.logging.logger import logger
from backend.dhcp.domain.leases import parse_leases
from backend.dhcp.domain.interfaces import interface_for_ip
from backend.dhcp.domain.pool import lease_in_range
from backend.dhcp.domain.reclaim import select_reclaimable
from datetime import timedelta
from backend.shared.datetime_utils import utcnow


# Cuánto se espera a que dnsmasq reescriba su archivo tras `dhcp_release`.
RELEASE_VERIFY_SECONDS = 2.0


class LeaseReclaimMixin:

    def signal_no_address(self, seconds: int = 120) -> None:
        """Un equipo pidio IP y no habia: durante `seconds` el reciclaje
        trata el pool como agotado, aunque las cifras digan otra cosa."""

        import time

        self._no_address_until = time.monotonic() + max(1, int(seconds))

    def _get_release_provider(self):

        provider = getattr(self, "_release_provider", None)

        if provider is not None:

            return provider

        try:

            from backend.dhcp.providers.dhcp_release_provider import (
                DhcpReleaseProvider,
            )

            return DhcpReleaseProvider()

        except Exception as error:

            logger.debug("DHCP: sin proveedor dhcp_release: %s", error)

            return None

    def _lease_ips_in_file(self) -> set[str] | None:

        try:

            text = self._leases_path.read_text(encoding="utf-8", errors="replace")

        except OSError:

            return None

        return {lease.ip for lease in parse_leases(text)}

    def _release_leases(self, by_ip: dict) -> set[str]:
        """Libera leases con `dhcp_release`; devuelve SOLO los confirmados.

        Confirmado = la IP ya no está en el archivo de leases (dnsmasq lo
        reescribe al liberar). Que la herramienta salga con código 0 no
        alcanza para darlo por hecho.
        """

        provider = self._get_release_provider()

        if provider is None or not by_ip:

            return set()

        try:

            if not provider.available():

                return set()

            if not self._process.status().get("running"):

                # Sin dnsmasq vivo no hay a quién avisar: se edita el archivo.
                return set()

            addrs = provider.interfaces()

        except Exception as error:

            logger.debug("DHCP: dhcp_release no disponible: %s", error)

            return set()

        attempted: set[str] = set()

        for ip, lease in by_ip.items():

            iface = interface_for_ip(ip, addrs)

            if not iface:

                continue

            try:

                if provider.release(iface, ip, lease.mac, lease.client_id):

                    attempted.add(ip)

            except Exception as error:

                logger.debug("DHCP: dhcp_release %s falló: %s", ip, error)

        if not attempted:

            return set()

        import time as _time

        deadline = _time.monotonic() + RELEASE_VERIFY_SECONDS

        while True:

            still = self._lease_ips_in_file()

            if still is None:

                return set()

            confirmed = attempted - still

            if confirmed == attempted or _time.monotonic() >= deadline:

                break

            _time.sleep(0.25)

        return confirmed

    def _restart_after_reclaim(self) -> bool:
        """Arranca dnsmasq de nuevo; dos intentos, nunca silencioso."""

        import time

        for attempt in range(2):

            started = self._process.start()

            if started.get("success"):

                return True

            logger.error(
                "DHCP: dnsmasq no arrancó tras reclamar leases (intento %d/2): %s",
                attempt + 1,
                started,
            )

            if attempt == 0:

                time.sleep(0.5)

        return False


    def _reclaim_by_file(self, remaining: set[str]) -> bool:
        """Método de respaldo: detener dnsmasq, editar leases y arrancar.

        True si quedó aplicado. Relee el archivo: `dhcp_release` pudo
        haberlo reescrito hace un instante.
        """

        try:

            text = self._leases_path.read_text(encoding="utf-8", errors="replace")

        except OSError:

            return False

        keep = [
            line
            for line in text.splitlines()
            if not (len(line.split()) >= 3 and line.split()[2] in remaining)
        ]

        # dnsmasq mantiene los leases en memoria; editar el archivo con el
        # proceso vivo permite que los reescriba y se pierda la reclamación.
        was_running = bool(self._process.status().get("running"))

        if was_running:

            stopper = getattr(self._process, "stop", None)

            if stopper is not None:

                stopped = stopper()

                if not stopped.get("success", True):

                    logger.warning(
                        "DHCP: no se pudo detener dnsmasq para reclamar leases: %s",
                        stopped,
                    )

                    return False

        try:

            self._write_atomic(self._leases_path, "\n".join(keep) + "\n")

        except Exception as error:

            logger.exception(
                "DHCP: fallo escribiendo leases durante la reclamación: %s",
                error,
            )

            if was_running:

                self._restart_after_reclaim()

            return False

        if was_running and not self._restart_after_reclaim():

            return False

        return True

    def _reclaim_targets(
        self, pool: dict, config: dict, signaled: bool, minutes: int
    ) -> list[dict]:
        """Qué pools necesitan IPs y cuántas: el principal y cada zona baja.

        - Principal: como siempre; `signaled` ("no address available") lo
          trata como agotado.
        - Zona: solo por su propio estado medido (el aviso de dnsmasq no
          dice de qué rango fue).
        """

        configured_target = int(config.get("pool_reclaim_target_free", 10) or 10)

        base_target = max(1, min(500, configured_target))

        targets: list[dict] = []

        if signaled or pool.get("low"):

            free = 0 if signaled else int(pool.get("free") or 0)

            threshold = int(pool.get("threshold") or 0)

            needed = max(0, max(threshold, base_target) - free)

            if needed > 0:

                targets.append(
                    {
                        "name": "principal",
                        "start": pool.get("start"),
                        "end": pool.get("end"),
                        "needed": needed,
                        "exhausted": free <= 0,
                    }
                )

        for zone in pool.get("zones") or []:

            if not zone.get("low"):

                continue

            free = int(zone.get("free") or 0)

            threshold = int(zone.get("threshold") or 0)

            # Una zona chica no puede pedir más de la mitad de sus IPs.
            cap = max(1, int(zone.get("dynamic") or 0) // 2)

            needed = max(0, max(threshold, min(base_target, cap)) - free)

            if needed > 0:

                targets.append(
                    {
                        "name": zone.get("name") or "zona",
                        "start": zone.get("start"),
                        "end": zone.get("end"),
                        "needed": needed,
                        "exhausted": free <= 0,
                    }
                )

        now = utcnow()

        for target in targets:

            # Con el pool AGOTADO no se espera a la ventana de inactividad:
            # alcanza con que la presencia diga OFFLINE (sin ARP/DNS/ping en
            # los ultimos 30 min). Un equipo conectado nunca se libera.
            target["cutoff"] = (
                now if target["exhausted"] else now - timedelta(minutes=minutes)
            )

        return targets

    def _reclaim_if_needed(self, pool: dict | None = None, config=None) -> int:

        """Libera leases de equipos inactivos cuando el pool esta bajo."""

        import time as _time

        signaled = _time.monotonic() < getattr(
            self, "_no_address_until", float("-inf")
        )

        pool = pool or {}

        zones_low = [
            zone for zone in (pool.get("zones") or []) if zone.get("low")
        ]

        if not signaled and not pool.get("low") and not zones_low:

            return 0

        try:

            config = self._get_config_service().get_dhcp_config() or {}

            if not config.get("pool_reclaim_enabled", True):

                return 0

            # La reclamación solo corre cuando un pool cruzó el umbral.
            # En ese momento no se puede esperar 7 días: se liberan leases
            # de equipos que no están en ARP y no se vieron en la red en
            # los últimos `pool_emergency_reclaim_minutes` minutos.
            import time

            minutes = max(
                1,
                int(
                    config.get("pool_emergency_reclaim_minutes")
                    or 60
                ),
            )

            targets = self._reclaim_targets(pool, config, signaled, minutes)

            if not targets:
                return 0

            exhausted = any(item["exhausted"] for item in targets)

            raw_cooldown = config.get("pool_reclaim_cooldown_seconds")

            cooldown = max(
                0,
                min(3600, 60 if raw_cooldown is None else int(raw_cooldown)),
            )
            now = time.monotonic()
            last_attempt = getattr(self, "_last_reclaim_attempt", float("-inf"))
            if (
                cooldown
                and not signaled
                and not exhausted
                and now - last_attempt < cooldown
            ):
                return 0
            self._last_reclaim_attempt = now

        except Exception as error:

            logger.debug("DhcpReconciler: sin config de reclamacion: %s", error)

            return 0

        live_ips: set[str] = set()

        meta: dict = {}

        try:

            from backend.core.database.session import SessionLocal
            from backend.network.devices.models.network_device import (
                NetworkDevice,
            )
            from backend.network.devices.services.device_classifier import (
                DeviceClassifier,
            )
            from backend.network.devices.services.device_presence_service import (
                DevicePresenceService,
            )

            db = SessionLocal()

            try:

                # Presencia FRESCA antes de decidir (ARP + DNS + ping). El
                # ARP crudo no sirve: el kernel conserva entradas STALE de
                # equipos que ya se fueron, y eso bloquearia justo lo que se
                # quiere liberar. Un lease tampoco prueba presencia.
                DevicePresenceService().reconcile(db)

                for device in db.query(NetworkDevice).all():

                    mac = (device.mac_address or "").lower()

                    meta[mac] = {
                        "last_seen": device.last_seen,
                        "permanent": device.permanent_ip or "",
                        "presence": device.presence_status,
                        "protected": bool(
                            device.is_permanent
                            or DeviceClassifier.is_infrastructure(
                                device.device_type
                            )
                        ),
                    }

                    if (
                        device.presence_status in ("ONLINE", "PROBABLE")
                        and device.current_ip
                    ):

                        live_ips.add(device.current_ip)

            finally:

                db.close()

        except Exception as error:

            # Sin presencia confiable no se puede demostrar que una IP
            # esta sin uso: no se libera nada.
            logger.warning(
                "DhcpReconciler: sin presencia confiable, no se libera: %s",
                error,
            )

            return 0

        try:

            text = self._leases_path.read_text(encoding="utf-8", errors="replace")

        except OSError:

            return 0

        leases = parse_leases(text)

        reclaimable: set[str] = set()

        for target in targets:

            # Cada pool recicla SOLO sus propios leases: liberar IPs de otra
            # zona no le daría espacio a la que está llena.
            scoped = [
                lease
                for lease in leases
                if target["start"] is None
                or lease_in_range(lease, target["start"], target["end"])
            ]

            candidates = select_reclaimable(
                scoped,
                live_ips,
                meta,
                target["cutoff"],
                # Margen para descartar por ping sin quedarse sin candidatos.
                limit=max(target["needed"] + 10, target["needed"] * 3),
            )

            # La confirmación activa (ping/ARP) vive en DevicePresenceService,
            # fuera del lock de dnsmasq. Aquí usamos ARP/observaciones y no
            # mantenemos el servicio bloqueado mientras se sondean equipos.
            reclaimable.update(candidates[: target["needed"]])

        if not reclaimable:

            return 0

        # 1) En caliente: `dhcp_release` con dnsmasq corriendo. No se corta
        #    el DHCP de nadie justo cuando el pool está agotado.
        by_ip = {
            lease.ip: lease for lease in leases if lease.ip in reclaimable
        }

        released = self._release_leases(by_ip)

        remaining = reclaimable - released

        self._reclaim_reload_needed = False

        # 2) Respaldo: lo que no se pudo liberar en caliente (herramienta
        #    ausente, lease con client-id raro, etc.) se quita del archivo
        #    con dnsmasq detenido, como antes.
        if remaining:

            if not self._reclaim_by_file(remaining):

                if not released:

                    return 0

                reclaimable = set(released)

            else:

                self._reclaim_reload_needed = True

        if released and not remaining:

            logger.info(
                "DHCP: %d lease(s) liberados en caliente (sin reiniciar dnsmasq)",
                len(released),
            )

        self._no_address_until = float("-inf")

        self._state["reclaimed_last"] = len(reclaimable)

        self._state["reclaimed_total"] += len(reclaimable)

        logger.warning(
            "DHCP: %s, liberadas %d IPs de equipos sin señal reciente",
            "pool agotado" if exhausted else "pool bajo",
            len(reclaimable),
        )

        self._alert_notifier(
            "DHCP_POOL_RECLAIMED",
            "info",
            "DHCP: IPs liberadas por falta de espacio",
            (
                f"Se liberaron {len(reclaimable)} direcciones de equipos "
                "ausentes (sin ARP, DNS ni respuesta a ping). Se conservan "
                "las reservas y todo equipo presente en la red."
            ),
        )

        return len(reclaimable)
