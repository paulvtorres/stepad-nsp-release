"""Sonda DHCP sintética de extremo a extremo.

No configura interfaces ni modifica el sistema: envía un ciclo DHCP
estándar (DISCOVER/OFFER/REQUEST/ACK/RELEASE) con una MAC local
aleatoria, valida las opciones entregadas y comprueba que el DNS
anunciado por DHCP responde. El lease se libera al terminar.
"""

from __future__ import annotations

import ipaddress
import random
import socket
import struct
import time

from backend.monitoring.services.navigation_health_service import probe_dns_a
from backend.shared.config.config_service import ConfigService
from backend.shared.logging.logger import logger


DHCP_MAGIC = b"\x63\x82\x53\x63"


def _mac_bytes(mac: str) -> bytes:
    return bytes(int(part, 16) for part in mac.split(":"))


def _option(code: int, value: bytes) -> bytes:
    return bytes([code, len(value)]) + value


def _build_packet(
    xid: int,
    mac: str,
    hostname: str,
    message_type: int,
    ciaddr: str = "",
    requested_ip: str = "",
    server_id: str = "",
) -> bytes:
    fixed = struct.pack(
        "!BBBBIHH4s4s4s4s16s64s128s",
        1,
        1,
        6,
        0,
        xid,
        0,
        0x8000,
        socket.inet_aton(ciaddr) if ciaddr else b"\0" * 4,
        b"\0" * 4,
        b"\0" * 4,
        b"\0" * 4,
        _mac_bytes(mac) + b"\0" * 10,
        b"\0" * 64,
        b"\0" * 128,
    )

    options = _option(53, bytes([message_type]))
    options += _option(12, hostname.encode("ascii", errors="ignore")[:63])
    options += _option(55, bytes([1, 3, 6, 15, 28, 51, 54, 58, 59]))

    if requested_ip:
        options += _option(50, socket.inet_aton(requested_ip))

    if server_id:
        options += _option(54, socket.inet_aton(server_id))

    return fixed + DHCP_MAGIC + options + b"\xff"


def build_discover(xid: int, mac: str, hostname: str) -> bytes:
    return _build_packet(xid, mac, hostname, 1)


def build_request(
    xid: int,
    mac: str,
    hostname: str,
    requested_ip: str,
    server_id: str,
) -> bytes:
    return _build_packet(
        xid,
        mac,
        hostname,
        3,
        requested_ip=requested_ip,
        server_id=server_id,
    )


def build_release(
    xid: int,
    mac: str,
    hostname: str,
    ciaddr: str,
    server_id: str,
) -> bytes:
    return _build_packet(
        xid,
        mac,
        hostname,
        7,
        ciaddr=ciaddr,
        server_id=server_id,
    )


def _ipv4_options(value: bytes) -> list[str]:
    return [
        socket.inet_ntoa(value[index:index + 4])
        for index in range(0, len(value) - 3, 4)
    ]


def parse_packet(data: bytes) -> dict:
    """Parse a DHCP/BOOTP packet without trusting any field."""

    if len(data) < 240 or data[236:240] != DHCP_MAGIC:
        return {}

    xid = struct.unpack("!I", data[4:8])[0]
    yiaddr = socket.inet_ntoa(data[16:20])
    siaddr = socket.inet_ntoa(data[20:24])
    options: dict[int, bytes] = {}
    index = 240

    while index < len(data):

        code = data[index]

        if code == 255:
            break

        if code == 0:
            index += 1
            continue

        if index + 1 >= len(data):
            break

        length = data[index + 1]
        value = data[index + 2:index + 2 + length]
        options[code] = value
        index += 2 + length

    message_type = None

    if options.get(53):
        message_type = options[53][0]

    lease_time = None

    if len(options.get(51, b"")) == 4:
        lease_time = struct.unpack("!I", options[51])[0]

    return {
        "xid": xid,
        "op": data[0],
        "message_type": message_type,
        "yiaddr": yiaddr,
        "siaddr": siaddr,
        "server_id": (
            socket.inet_ntoa(options[54])
            if len(options.get(54, b"")) == 4
            else ""
        ),
        "subnet_mask": (
            socket.inet_ntoa(options[1])
            if len(options.get(1, b"")) == 4
            else ""
        ),
        "routers": _ipv4_options(options.get(3, b"")),
        "dns_servers": _ipv4_options(options.get(6, b"")),
        "lease_time": lease_time,
    }


class DhcpProbeService:

    def _interface_name(self) -> str:
        try:
            from backend.network.interfaces.services.interface_service import (
                InterfaceService,
            )

            lan = InterfaceService().get_primary_lan()
            return getattr(lan, "name", "") or ""

        except Exception as error:
            logger.debug("dhcp_probe interface: %s", error)
            return ""

    def _open_socket(self, interface: str) -> socket.socket:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        if interface:
            sock.setsockopt(
                socket.SOL_SOCKET,
                getattr(socket, "SO_BINDTODEVICE", 25),
                interface.encode(),
            )

        sock.bind(("0.0.0.0", 68))
        return sock

    @staticmethod
    def _receive(
        sock: socket.socket,
        xid: int,
        message_types: set[int],
        timeout: float,
    ) -> tuple[dict, float | None]:
        started = time.monotonic()
        deadline = started + timeout

        while time.monotonic() < deadline:

            sock.settimeout(max(0.1, deadline - time.monotonic()))

            try:
                data, _ = sock.recvfrom(4096)
            except socket.timeout:
                break

            packet = parse_packet(data)

            if packet.get("xid") != xid:
                continue

            if packet.get("message_type") in message_types:
                return packet, round((time.monotonic() - started) * 1000, 1)

        return {}, None

    def probe(self, timeout: float = 4.0) -> dict:
        interface = self._interface_name()
        mac = "02:53:55:%02x:%02x:%02x" % tuple(
            random.randint(0, 255) for _ in range(3)
        )
        hostname = "stepad-probe-%04x" % random.randint(0, 0xFFFF)
        xid = random.randint(1, 0xFFFFFFFF)
        checks = []

        def add(key, label, ok, detail, latency_ms=None):
            checks.append({
                "key": key,
                "label": label,
                "ok": bool(ok),
                "latency_ms": latency_ms,
                "detail": detail,
            })

        config = ConfigService().get_dhcp_config() or {}
        expected_servers = {
            str(config.get("gateway") or "").strip(),
            str(config.get("secondary_dhcp_ip") or "").strip(),
        }
        expected_servers.discard("")

        sock = None
        offer = {}
        lease = {}
        release_sent = False

        try:
            sock = self._open_socket(interface)
        except OSError as error:
            add(
                "dhcp_socket",
                "DHCP sintético",
                False,
                f"No se pudo abrir puerto DHCP 68: {error}",
            )
            return {
                "ok": False,
                "checks": checks,
                "interface": interface,
                "mac": mac,
                "error": str(error),
            }

        try:
            sock.sendto(
                build_discover(xid, mac, hostname),
                ("255.255.255.255", 67),
            )
            offer, offer_ms = self._receive(sock, xid, {2}, timeout)
            add(
                "dhcp_offer",
                "DHCP OFFER",
                bool(offer),
                (
                    f"{offer.get('yiaddr')} desde {offer.get('server_id')}"
                    if offer
                    else "Sin OFFER"
                ),
                offer_ms,
            )

            if offer:
                sock.sendto(
                    build_request(
                        xid,
                        mac,
                        hostname,
                        offer["yiaddr"],
                        offer["server_id"],
                    ),
                    ("255.255.255.255", 67),
                )
                lease, ack_ms = self._receive(sock, xid, {5, 6}, timeout)
                add(
                    "dhcp_ack",
                    "DHCP ACK",
                    bool(lease and lease.get("message_type") == 5),
                    (
                        f"{lease.get('yiaddr') or offer['yiaddr']} confirmada"
                        if lease and lease.get("message_type") == 5
                        else "Sin ACK"
                    ),
                    ack_ms,
                )

                if lease and lease.get("message_type") == 5:

                    server_id = lease.get("server_id") or offer.get("server_id")
                    router = (lease.get("routers") or [""])[0]
                    dns_server = (lease.get("dns_servers") or [""])[0]
                    subnet = lease.get("subnet_mask") or ""
                    lease_ip = lease.get("yiaddr") or offer.get("yiaddr")
                    lease["server_id"] = server_id
                    lease["routers"] = lease.get("routers") or []
                    lease["dns_servers"] = lease.get("dns_servers") or []
                    lease["yiaddr"] = lease_ip

                    server_ok = (
                        not expected_servers or server_id in expected_servers
                    )
                    add(
                        "dhcp_server",
                        "Servidor DHCP esperado",
                        server_ok,
                        (
                            f"{server_id} autorizado"
                            if server_ok
                            else f"{server_id} no está en la configuración"
                        ),
                    )

                    lease_ip_ok = bool(lease_ip) and lease_ip != "0.0.0.0"

                    try:
                        if router and subnet:
                            network = ipaddress.ip_network(
                                f"{router}/{subnet}",
                                strict=False,
                            )
                            lease_ip_ok = (
                                ipaddress.ip_address(lease_ip) in network
                                and lease_ip != router
                            )
                    except ValueError:
                        lease_ip_ok = False

                    add(
                        "dhcp_lease_ip",
                        "IP entregada válida",
                        lease_ip_ok,
                        (
                            f"{lease_ip} dentro de {router}/{subnet}"
                            if lease_ip_ok
                            else f"{lease_ip} fuera de la red esperada"
                        ),
                    )

                    subnet_ok = bool(subnet)
                    add(
                        "dhcp_subnet",
                        "Máscara entregada",
                        subnet_ok,
                        subnet or "sin opción 1",
                    )

                    router_ok = bool(router)
                    add(
                        "dhcp_gateway",
                        "Gateway entregado",
                        router_ok,
                        router or "sin opción 3",
                    )

                    dns_lookup_ms = None
                    dns_lookup_ok = False

                    if dns_server:
                        dns_started = time.monotonic()
                        dns_lookup_ok = probe_dns_a(
                            dns_server,
                            "example.com",
                            timeout=2.0,
                        )
                        dns_lookup_ms = round(
                            (time.monotonic() - dns_started) * 1000,
                            1,
                        )

                    add(
                        "dhcp_dns",
                        "DNS entregado por DHCP",
                        dns_lookup_ok,
                        (
                            f"{dns_server} resolvió example.com"
                            if dns_lookup_ok
                            else (
                                f"{dns_server} no resolvió"
                                if dns_server
                                else "sin opción 6"
                            )
                        ),
                        dns_lookup_ms,
                    )

                    try:
                        sock.sendto(
                            build_release(
                                xid,
                                mac,
                                hostname,
                                lease_ip,
                                server_id,
                            ),
                            ("255.255.255.255", 67),
                        )
                        release_sent = True
                    except OSError as error:
                        logger.debug("dhcp_probe release: %s", error)

        finally:
            if sock is not None:
                sock.close()

        lease_summary = {
            "ip": lease.get("yiaddr") or offer.get("yiaddr") or "",
            "server_id": lease.get("server_id") or offer.get("server_id") or "",
            "gateway": (lease.get("routers") or [""])[0],
            "dns": (lease.get("dns_servers") or [""])[0],
            "subnet_mask": lease.get("subnet_mask") or "",
            "lease_seconds": lease.get("lease_time"),
            "released": release_sent,
        }

        return {
            "ok": all(check["ok"] for check in checks),
            "checks": checks,
            "lease": lease_summary,
            "interface": interface,
            "mac": mac,
        }
