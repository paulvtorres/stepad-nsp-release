"""Eventos de lease de dnsmasq en tiempo real.

Flujo:

    dnsmasq --dhcp-script --> dhcp-event.sh --> spool JSONL --> este servicio
                                                                   |
                       DevicePresenceService.apply_events  <-------+
                       IpamService.reconcile               <-------+

* El script solo anota una linea y sale: no puede frenar a dnsmasq.
* Cada renovacion (`old`, con `script-on-renewal`) y cada lease nuevo
  (`add`) es evidencia REAL de presencia: el equipo acaba de hablar con el
  servidor. Un `del` quita esa evidencia al instante.
* Todo es opcional y degrada con elegancia: si el dnsmasq instalado no
  soporta el script, no se emite nada y el sondeo de 60 s sigue cubriendo.
"""

from __future__ import annotations

import os
import subprocess
import time
from datetime import datetime
from pathlib import Path

from backend.core.config.paths import (
    DHCP_EVENT_SCRIPT,
    DHCP_EVENT_SPOOL,
    DNSMASQ_CONFIG,
    DNSMASQ_LEASES_FILE,
)
from backend.dhcp.domain.dhcp_events import (
    DhcpEvent,
    events_look_silent,
    parse_event_line,
    render_event_script,
)
from backend.shared.logging.logger import logger

DNSMASQ_BIN = "/usr/sbin/dnsmasq"

# El spool se rota al pasar de este tamaño (ya consumido).
SPOOL_MAX_BYTES = 256 * 1024

# Maximo que se lee por pasada (protege ante un spool inflado).
READ_CHUNK = 1024 * 1024


# ----------------------------------------------------------------------
# Provision del script y configuracion de dnsmasq
# ----------------------------------------------------------------------

_capabilities: dict[str, bool] | None = None


def dnsmasq_capabilities(force: bool = False) -> dict[str, bool]:
    """Que opciones soporta el dnsmasq instalado (se consulta una vez).

    Si una opcion no existe, `dnsmasq --test` rechazaria TODA la
    configuracion; por eso solo se emite lo que el binario declara.
    """

    global _capabilities

    if _capabilities is not None and not force:

        return _capabilities

    caps = {"dhcp-script": False, "script-on-renewal": False}

    try:

        proc = subprocess.run(
            [DNSMASQ_BIN, "--help"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        text = (proc.stdout or "") + (proc.stderr or "")

        for name in caps:

            caps[name] = f"--{name}" in text

    except (OSError, subprocess.SubprocessError) as error:

        logger.debug("dhcp events: no se pudo consultar dnsmasq: %s", error)

    _capabilities = caps

    return caps


def ensure_event_script(
    script_path: Path | None = None,
    spool_path: Path | None = None,
) -> Path:
    """Escribe el script (idempotente) con permisos de root y devuelve su ruta."""

    script_path = Path(script_path or DHCP_EVENT_SCRIPT)

    spool_path = Path(spool_path or DHCP_EVENT_SPOOL)

    content = render_event_script(str(spool_path))

    script_path.parent.mkdir(parents=True, exist_ok=True)

    current = None

    try:

        current = script_path.read_text(encoding="utf-8")

    except OSError:

        pass

    if current != content:

        tmp = script_path.with_suffix(script_path.suffix + ".tmp")

        tmp.write_text(content, encoding="utf-8")

        os.chmod(tmp, 0o750)

        os.replace(tmp, script_path)

    else:

        os.chmod(script_path, 0o750)

    return script_path


def event_config_lines() -> str:
    """Lineas de dnsmasq.conf para activar los eventos ('' si no aplica)."""

    if os.environ.get("STEPAD_DHCP_EVENTS", "1") == "0":

        return ""

    caps = dnsmasq_capabilities()

    if not caps.get("dhcp-script"):

        return ""

    try:

        script = ensure_event_script()

    except OSError as error:

        logger.warning("dhcp events: no se pudo crear el script: %s", error)

        return ""

    lines = f"dhcp-script={script}\n"

    if caps.get("script-on-renewal"):

        lines += "script-on-renewal\n"

    return lines


# ----------------------------------------------------------------------
# Lectura del spool
# ----------------------------------------------------------------------


class DhcpEventSpool:
    """Lee las lineas NUEVAS del spool, sin repetir ni perder las parciales."""

    def __init__(self, path: Path | None = None, max_bytes: int = SPOOL_MAX_BYTES):

        self.path = Path(path or DHCP_EVENT_SPOOL)

        self.max_bytes = max_bytes

        self._offset: int | None = None

        self._partial = b""

    def poll(self, now_ts: int | None = None) -> list[DhcpEvent]:

        now_ts = int(time.time()) if now_ts is None else int(now_ts)

        try:

            size = self.path.stat().st_size

        except OSError:

            # Aun no hay eventos: cuando aparezca el archivo se lee entero.
            if self._offset is None:

                self._offset = 0

            return []

        if self._offset is None:

            # Primera lectura: no se reprocesa la historia de antes del panel.
            self._offset = size

            return []

        if size < self._offset:

            # Rotado o truncado.
            self._offset = 0

            self._partial = b""

        if size == self._offset:

            return []

        try:

            with self.path.open("rb") as handle:

                handle.seek(self._offset)

                chunk = handle.read(min(size - self._offset, READ_CHUNK))

        except OSError:

            return []

        self._offset += len(chunk)

        data = self._partial + chunk

        lines = data.split(b"\n")

        # La ultima pieza puede ser una linea a medio escribir.
        self._partial = lines.pop()

        events = []

        for raw in lines:

            event = parse_event_line(raw.decode("utf-8", errors="replace"), now_ts)

            if event is not None:

                events.append(event)

        self._maybe_rotate()

        return events

    def _maybe_rotate(self) -> None:

        if self._offset is None or self._offset < self.max_bytes:

            return

        if self._partial:

            return

        try:

            os.replace(self.path, str(self.path) + ".1")

            self._offset = 0

        except OSError as error:

            logger.debug("dhcp events: no se pudo rotar el spool: %s", error)


# ----------------------------------------------------------------------
# Procesamiento
# ----------------------------------------------------------------------


SILENT_ALERT_TYPE = "DHCP_EVENTS_SILENT"

SILENT_ALERT_TITLE = "DHCP: dnsmasq no está enviando eventos de lease"

CHECK_INTERVAL_SECONDS = 60


class DhcpEventService:

    def __init__(
        self,
        spool: DhcpEventSpool | None = None,
        *,
        config_path: Path | None = None,
        leases_path: Path | None = None,
        clock=time.time,
        alert=None,
        resolve=None,
    ):

        self.spool = spool or DhcpEventSpool()

        self._config_path = Path(config_path or DNSMASQ_CONFIG)

        self._leases_path = Path(leases_path or DNSMASQ_LEASES_FILE)

        self._clock = clock

        self._alert = alert or self._default_alert

        self._resolve = resolve or self._default_resolve

        self._started_at = clock()

        self._last_event_ts: float | None = None

        self._last_check = 0.0

        self._silent_reported = False

    # -- autochequeo -----------------------------------------------------

    def _armed_since(self) -> float | None:
        """Desde cuando dnsmasq.conf activa el script (None si no esta)."""

        try:

            text = self._config_path.read_text(encoding="utf-8")

            if "dhcp-script=" not in text:

                return None

            return self._config_path.stat().st_mtime

        except OSError:

            return None

    def tick(self) -> bool | None:
        """Vigila que los eventos lleguen. Se llama en cada vuelta del hilo.

        Devuelve True si acaba de alertar, False si todo bien, None si no
        corresponde evaluar todavia.
        """

        now = self._clock()

        if now - self._last_check < CHECK_INTERVAL_SECONDS:

            return None

        self._last_check = now

        try:

            leases_mtime = self._leases_path.stat().st_mtime

        except OSError:

            leases_mtime = None

        silent = events_look_silent(
            self._armed_since(),
            self._started_at,
            leases_mtime,
            self._last_event_ts,
            now,
        )

        if silent and not self._silent_reported:

            self._silent_reported = True

            self._alert(
                SILENT_ALERT_TYPE,
                "warning",
                SILENT_ALERT_TITLE,
                (
                    "El archivo de leases de dnsmasq cambió y no llegó ningún "
                    "evento en los últimos minutos. La presencia sigue "
                    "funcionando por sondeo (cada 60 s), pero sin reacción en "
                    "tiempo real. Causas habituales: AppArmor/SELinux impide "
                    "que dnsmasq ejecute el script, o permisos del script o "
                    f"del spool. Prueba: sh {DHCP_EVENT_SCRIPT} add "
                    "aa:bb:cc:dd:ee:ff 192.168.1.50 y revisa que aparezca una "
                    f"línea en {DHCP_EVENT_SPOOL}."
                ),
            )

            return True

        return False

    @staticmethod
    def _default_alert(alert_type, severity, title, message) -> None:

        try:

            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                AlertService().create(
                    db,
                    alert_type=alert_type,
                    severity=severity,
                    title=title,
                    message=message,
                )

            finally:

                db.close()

        except Exception as error:

            logger.warning("dhcp events: no se pudo crear la alerta: %s", error)

    @staticmethod
    def _default_resolve(alert_type) -> None:

        try:

            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                AlertService().resolve(db, alert_type)

            finally:

                db.close()

        except Exception as error:

            logger.warning("dhcp events: no se pudo resolver la alerta: %s", error)

    def process(self, db=None) -> int:
        """Lee los eventos nuevos y actualiza presencia e IPAM. Devuelve cuantos."""

        events = self.spool.poll()

        if not events:

            return 0

        # Llego un evento: el canal funciona.
        self._last_event_ts = self._clock()

        if self._silent_reported:

            self._silent_reported = False

            self._resolve(SILENT_ALERT_TYPE)

        own = db is None

        if own:

            from backend.core.database.session import SessionLocal

            db = SessionLocal()

        try:

            from backend.network.devices.services.device_presence_service import (
                DevicePresenceService,
            )
            from backend.network.devices.services.ipam_service import IpamService

            DevicePresenceService().apply_events(db, events)

            try:

                IpamService().reconcile(db)

            except Exception as error:

                logger.debug("dhcp events: ipam: %s", error)

        finally:

            if own:

                db.close()

        return len(events)

    @staticmethod
    def event_time(event: DhcpEvent) -> datetime:

        return datetime.utcfromtimestamp(event.ts)
