"""Detección read-only de otros servidores DHCP en la LAN."""

from __future__ import annotations

import random
import socket
import struct
import time

from backend.shared.config.config_service import ConfigService
from backend.shared.logging.logger import logger


def _mac_bytes(mac: str) -> bytes:
    return bytes(int(part, 16) for part in mac.split(":"))


def build_discover(xid: int, mac: str, hostname: str = "stepad-probe") -> bytes:
    fixed = struct.pack(
        "!BBBBIHH4s4s4s4s16s64s128s",
        1, 1, 6, 0, xid, 0, 0x8000,
        b"\0" * 4, b"\0" * 4, b"\0" * 4, b"\0" * 4,
        _mac_bytes(mac) + b"\0" * 10,
        b"\0" * 64,
        b"\0" * 128,
    )
    options = (
        b"\x35\x01\x01"
        + b"\x0c" + bytes([len(hostname)]) + hostname.encode()
        + b"\x37\x04\x01\x03\x06\x0f"
        + b"\xff"
    )
    return fixed + b"\x63\x82\x53\x63" + options


def parse_dhcp_offer(data: bytes) -> dict:
    if len(data) < 240 or data[236:240] != b"\x63\x82\x53\x63":
        return {}
    yiaddr = socket.inet_ntoa(data[16:20])
    servers = []
    i = 240
    while i < len(data):
        code = data[i]
        if code == 255:
            break
        if code == 0:
            i += 1
            continue
        if i + 1 >= len(data):
            break
        length = data[i + 1]
        value = data[i + 2:i + 2 + length]
        if code == 53 and value == b"\x02":
            pass
        if code == 54 and length == 4:
            servers.append(socket.inet_ntoa(value))
        i += 2 + length
    return {"server_id": servers[0] if servers else "", "offered_ip": yiaddr}


class RogueDhcpService:

    def scan(self, timeout: float = 4.0) -> dict:
        config = ConfigService().get_dhcp_config() or {}
        expected = {
            str(config.get("gateway") or "").strip(),
            str(config.get("secondary_dhcp_ip") or "").strip(),
        }
        expected.discard("")
        mac = "02:53:54:45:50:01"
        xid = random.randint(1, 0xFFFFFFFF)
        packet = build_discover(xid, mac)
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        interface = ""

        try:
            from backend.network.interfaces.services.interface_service import (
                InterfaceService,
            )

            lan = InterfaceService().get_primary_lan()
            interface = getattr(lan, "name", "") or ""

            if interface:
                sock.setsockopt(
                    socket.SOL_SOCKET,
                    getattr(socket, "SO_BINDTODEVICE", 25),
                    interface.encode(),
                )

        except Exception as error:
            logger.debug("rogue dhcp interface: %s", error)

        try:
            sock.bind(("0.0.0.0", 68))
        except OSError as error:
            sock.close()
            return {"success": False, "error": str(error)}
        found = {}
        try:
            sock.sendto(packet, ("255.255.255.255", 67))
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                sock.settimeout(max(0.1, deadline - time.monotonic()))
                try:
                    data, _ = sock.recvfrom(4096)
                except socket.timeout:
                    break
                offer = parse_dhcp_offer(data)
                if offer.get("server_id"):
                    found[offer["server_id"]] = offer
        except OSError as error:
            logger.debug("rogue dhcp scan: %s", error)
        finally:
            sock.close()
        unexpected = {
            ip: data for ip, data in found.items() if ip not in expected
        }
        return {
            "success": True,
            "servers": list(found.values()),
            "unexpected": list(unexpected.values()),
            "interface": interface,
            "expected": sorted(expected),
        }
