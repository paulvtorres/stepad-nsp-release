"""Historial de leases DHCP por IP.

Un equipo que ya recibio una IP por DHCP y sigue usando esa IP tras
vencerse el lease no debe clasificarse como IP fija. No es una amenaza
nueva: es un cliente DHCP conocido.
"""

from __future__ import annotations

from backend.shared.logging.logger import logger


def known_dhcp_macs_by_ip() -> dict[str, set[str]]:

    try:

        from backend.core.database.session import SessionLocal
        from backend.network.devices.models.ip_assignment import IpAssignment

        db = SessionLocal()

        try:

            rows = (
                db.query(
                    IpAssignment.ip_address,
                    IpAssignment.mac_address,
                )
                .filter(
                    IpAssignment.kind == "lease",
                    IpAssignment.source == "dhcp",
                )
                .all()
            )

            owners: dict[str, set[str]] = {}

            for ip, mac in rows:

                ip = str(ip or "").strip()
                mac = str(mac or "").strip().lower()

                if ip and mac:
                    owners.setdefault(ip, set()).add(mac)

            return owners

        finally:

            db.close()

    except Exception as error:

        logger.debug("dhcp_lease_owners: %s", error)
        return {}
