"""Liberación automática de leases viejos cuando el pool se agota.

Solo se liberan direcciones que NO pueden estar en uso:

- su equipo esta OFFLINE segun la presencia (sin ARP/DNS/ping recientes;
  el ARP crudo no sirve: el kernel conserva entradas de equipos ausentes),
- no son reservas (permanent_ip),
- su equipo se vio por última vez antes del corte (N días).

Funciones puras: reciben los datos y devuelven qué IPs liberar.
"""

from __future__ import annotations

from datetime import datetime


def select_reclaimable(
    leases,
    arp_ips,
    meta_by_mac,
    cutoff,
    limit: int | None = None,
) -> list[str]:
    """IPs de leases liberables.

    `meta_by_mac`: {mac: {"last_seen": datetime|None, "permanent": str}}
    `cutoff`: fecha/hora; los equipos vistos antes se consideran inactivos.
    """

    arp_ips = set(arp_ips or ())

    candidates = []

    for lease in leases:

        if lease.ip in arp_ips:

            continue

        meta = (meta_by_mac or {}).get(lease.mac)

        if not meta:

            # Sin registro en la base no se puede demostrar inactividad.
            continue

        if (meta.get("permanent") or "").strip():

            continue

        if meta.get("protected"):

            continue

        # La presencia (ARP + DNS + ping, ver DevicePresenceService) manda:
        # solo se libera a un equipo OFFLINE. PROBABLE/UNKNOWN no se tocan.
        # Sin el dato (tests/compat) se asume OFFLINE.
        if (meta.get("presence") or "OFFLINE") != "OFFLINE":

            continue

        last_seen = meta.get("last_seen")

        if last_seen is None or last_seen >= cutoff:

            continue

        candidates.append(
            (
                last_seen,
                lease.ip,
                lease.mac,
            )
        )

    candidates.sort(
        key=lambda item: (
            item[0] is None,
            item[0] or datetime.min,
            item[1],
        )
    )

    result = [item[1] for item in candidates]

    if limit is not None:

        return result[: max(0, int(limit))]

    return result
