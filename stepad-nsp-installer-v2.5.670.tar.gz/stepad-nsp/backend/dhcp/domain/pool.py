"""Segmento DHCP: capacidad, rangos dinámicos y estadísticas.

Un `PoolSpec` describe el segmento completo en direcciones enteras:

- `dynamic`: direcciones que dnsmasq puede repartir (pool menos
  exclusiones y reservas).
- `reserved`: direcciones con reserva (`dhcp-host`), servidas solo a su
  MAC.
- `ranges`: los `dhcp-range` contiguos que se escriben en dnsmasq.conf.

`pool_stats` calcula el panel con la misma información: nunca se suman
`ip_address` de la base (quedan viejas cuando el equipo se apaga), se
cuenta lo que dnsmasq realmente tiene.
"""

from __future__ import annotations

import ipaddress

from dataclasses import dataclass

from backend.dhcp.domain.exclusions import excluded_addresses
from backend.dhcp.domain.leases import Lease


def ip_to_int(value: str | None) -> int | None:

    if not value:

        return None

    try:

        return int(ipaddress.ip_address(str(value)))

    except ValueError:

        return None


def int_to_ip(value: int) -> str:

    return str(ipaddress.ip_address(value))


@dataclass(frozen=True)
class PoolSpec:

    start: int

    end: int

    netmask: str

    lease_time: str

    dynamic: frozenset[int]

    reserved: frozenset[int]

    ranges: tuple[tuple[int, int], ...]

    group_start: int

    group_end: int

    @property
    def total(self) -> int:

        return max(0, self.end - self.start + 1)

    @property
    def group_total(self) -> int:

        return max(0, self.group_end - self.group_start + 1)


def build_ranges(
    start: int,
    end: int,
    excluded: set[int]
) -> list[tuple[int, int]]:
    """Divide [start, end] en tramos contiguos sin las direcciones excluidas."""

    ranges: list[tuple[int, int]] = []

    cursor = start

    for value in sorted(v for v in excluded if start <= v <= end):

        if cursor < value:

            ranges.append((cursor, value - 1))

        cursor = value + 1

    if cursor <= end:

        ranges.append((cursor, end))

    return ranges


def build_pool_spec(dhcp: dict, reserved_ips=()) -> PoolSpec:
    """Construye el segmento a partir de la config + las IPs reservadas."""

    start = ip_to_int(dhcp.get("pool_start")) or 0

    end = ip_to_int(dhcp.get("pool_end")) or 0

    group_start = ip_to_int(dhcp.get("group_ip_start")) or 0

    group_end = ip_to_int(dhcp.get("group_ip_end")) or 0

    reserved = {
        value
        for value in (ip_to_int(ip) for ip in reserved_ips or ())
        if value is not None and start <= value <= end
    }

    excluded = excluded_addresses(dhcp.get("excluded_ips") or [])

    excluded.update(reserved)

    dynamic = frozenset(
        value
        for value in range(start, end + 1)
        if value not in excluded
    )

    return PoolSpec(
        start=start,
        end=end,
        netmask=str(dhcp.get("netmask") or "255.255.255.0"),
        lease_time=str(dhcp.get("lease_time") or "24h"),
        dynamic=dynamic,
        reserved=frozenset(reserved),
        ranges=tuple(build_ranges(start, end, excluded)),
        group_start=group_start,
        group_end=group_end,
    )


def pool_stats(
    spec: PoolSpec,
    leases: list[Lease],
    online_macs: set[str],
    static_ips=()
) -> dict:
    """Estadísticas honestas del pool de equipos.

    - online: direcciones con lease activo cuyo equipo está ONLINE.
    - offline: direcciones ocupadas por equipos no online + reservas
      que nadie está usando ahora (quedan bloqueadas para ese equipo).
    - free: direcciones dinámicas sin lease Y sin un equipo con IP fija
      (una fija dentro del pool ocupa la dirección aunque dnsmasq no
      tenga el lease: si se contara como libre, el panel mentiría).

    Invariante: online + offline + free == total del pool.
    """

    leased: set[int] = set()

    online: set[int] = set()

    for lease in leases:

        value = ip_to_int(lease.ip)

        if value is None or not (spec.start <= value <= spec.end):

            continue

        leased.add(value)

        if lease.mac in online_macs:

            online.add(value)

    leased_dynamic = leased - spec.reserved

    static = set()

    for ip in static_ips or ():

        value = ip_to_int(ip)

        if value is not None and spec.start <= value <= spec.end:

            static.add(value)

    # Una IP fija ya cuenta por su lease si lo tiene, o por reserva.
    static_only = {
        value
        for value in static
        if value in spec.dynamic
    } - leased - spec.reserved

    # Leases sobre IPs reservadas: ocupan la reserva, no el pool dinamico.
    leased_reserved = leased & spec.reserved

    free = max(0, len(spec.dynamic) - len(leased_dynamic) - len(static_only))

    # Ocupadas = todo lo que no esta libre ni en linea. Se calcula asi (y
    # no sumando casos) para que el invariante se cumpla siempre, incluidas
    # las IPs excluidas manualmente que no son reserva de ningun equipo.
    offline = max(0, spec.total - free - len(online))

    return {
        "total": spec.total,
        "dynamic": len(spec.dynamic),
        "reserved": len(spec.reserved),
        # `leased` = leases que ocupan espacio DINAMICO; los de una IP
        # reservada se informan aparte porque no consumen pool.
        "leased": len(leased_dynamic),
        "reserved_in_use": len(leased_reserved),
        "static": len(static_only),
        "online": len(online),
        "offline": offline,
        "free": free,
    }


def range_pool_status(
    spec: PoolSpec,
    leases: list[Lease],
    configured_threshold: int = 0,
    absolute: int = 5,
    ratio: float = 0.05,
    cap_ratio: float | None = None,
    static_ips=(),
) -> dict:
    """Capacidad de UN rango DHCP (el principal o el de una zona/VLAN).

    Pura: recibe el `PoolSpec` ya armado y los leases de dnsmasq. Solo se
    cuentan los leases que caen dentro del rango (`pool_stats` descarta el
    resto), así que cada zona se mide con lo suyo y no con el pool de otra.

    `threshold`: el configurado si es > 0; si no, max(absolute, ratio de las
    dinámicas). `cap_ratio` evita que un rango pequeño (un /27) quede
    permanentemente "bajo": el umbral nunca supera esa fracción de sus
    direcciones dinámicas.
    """

    stats = pool_stats(spec, leases, online_macs=set(), static_ips=static_ips)

    dynamic = len(spec.dynamic)

    threshold = (
        int(configured_threshold)
        if configured_threshold and configured_threshold > 0
        else max(int(absolute), int(dynamic * ratio))
    )

    if cap_ratio is not None:

        threshold = min(threshold, max(1, int(dynamic * cap_ratio)))

    free = stats["free"]

    return {
        "start": spec.start,
        "end": spec.end,
        "dynamic": dynamic,
        "free": free,
        "threshold": threshold,
        "low": free < threshold,
        "exhausted": free <= 0 and dynamic > 0,
        "static": stats.get("static", 0),
    }


def lease_in_range(lease: Lease, start: int, end: int) -> bool:
    """¿La IP del lease cae en [start, end]? (sin rango válido => False)."""

    value = ip_to_int(lease.ip)

    return value is not None and start <= value <= end
