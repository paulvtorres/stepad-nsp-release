"""Interfaces de red del servidor: a qué interfaz pertenece una IP (puro).

`dhcp_release` necesita el nombre de la interfaz por la que dnsmasq atiende
al cliente. Para el pool principal es una; para zonas/VLAN son otras (o la
misma con alias). En vez de adivinarla desde la configuración, se deduce de
las direcciones reales del kernel: la interfaz cuya red contiene la IP.
"""

from __future__ import annotations

import ipaddress


def parse_ipv4_addrs(text: str) -> list[tuple[str, ipaddress.IPv4Interface]]:
    """Parsea `ip -o -4 addr show` => [(interfaz, IPv4Interface)] (puro)."""

    result: list[tuple[str, ipaddress.IPv4Interface]] = []

    for line in (text or "").splitlines():

        parts = line.split()

        # 2: enp3s0    inet 192.168.1.1/24 brd ... scope global enp3s0
        if len(parts) < 4 or "inet" not in parts:

            continue

        iface = parts[1].rstrip(":")

        # `ip -o` marca los alias como "enp3s0    inet ..." con la misma
        # interfaz; una VLAN aparece como "enp3s0.20@enp3s0".
        iface = iface.split("@", 1)[0]

        try:

            cidr = parts[parts.index("inet") + 1]

            result.append((iface, ipaddress.IPv4Interface(cidr)))

        except (IndexError, ValueError):

            continue

    return result


def interface_for_ip(ip: str, addrs) -> str | None:
    """Interfaz cuya red contiene `ip`; la de prefijo más largo si hay varias."""

    try:

        target = ipaddress.IPv4Address(str(ip))

    except ValueError:

        return None

    best: tuple[int, str] | None = None

    for iface, interface in addrs or ():

        if target in interface.network:

            prefix = interface.network.prefixlen

            if best is None or prefix > best[0]:

                best = (prefix, iface)

    return best[1] if best else None
