"""Liberación de leases en caliente con `dhcp_release` (paquete dnsmasq-utils).

`dhcp_release <interfaz> <ip> <mac> [client-id]` le avisa a dnsmasq, que
sigue corriendo, que el cliente devolvió su dirección. dnsmasq borra el
lease y reescribe su archivo: no hace falta detener el servicio, que era lo
que dejaba sin DHCP a todos justo cuando el pool estaba agotado.

El proveedor nunca asume que funcionó: el llamador verifica contra el
archivo de leases y, si la IP sigue ahí, usa el método de respaldo.
"""

from __future__ import annotations

import ipaddress
import re
import shutil
import subprocess

from backend.dhcp.domain.interfaces import parse_ipv4_addrs
from backend.shared.logging.logger import logger

_MAC = re.compile(r"^[0-9a-f]{2}(:[0-9a-f]{2}){5}$")

_IFACE = re.compile(r"^[A-Za-z0-9_.\-]{1,15}$")

_CLIENT_ID = re.compile(r"^[0-9A-Fa-f:]{1,255}$")


class DhcpReleaseProvider:

    BIN_NAME = "dhcp_release"

    TIMEOUT_SECONDS = 3

    def binary(self) -> str | None:

        return shutil.which(self.BIN_NAME)

    def available(self) -> bool:

        return self.binary() is not None

    def interfaces(self) -> list:
        """Direcciones IPv4 del servidor (interfaz + red)."""

        try:

            result = subprocess.run(
                ["ip", "-o", "-4", "addr", "show"],
                capture_output=True,
                text=True,
                timeout=self.TIMEOUT_SECONDS,
            )

        except (OSError, subprocess.SubprocessError) as error:

            logger.debug("dhcp_release: no pude leer interfaces: %s", error)

            return []

        return parse_ipv4_addrs(result.stdout)

    def release(
        self,
        interface: str,
        ip: str,
        mac: str,
        client_id: str | None = None,
    ) -> bool:
        """True si la herramienta terminó sin error (no prueba que dnsmasq
        haya borrado el lease: eso lo verifica el llamador)."""

        binary = self.binary()

        if binary is None:

            return False

        # Los datos vienen del archivo de leases: se validan igual, y se
        # ejecuta sin shell con argumentos separados.
        try:

            ipaddress.IPv4Address(ip)

        except ValueError:

            return False

        if not _IFACE.match(interface or "") or not _MAC.match((mac or "").lower()):

            return False

        command = [binary, interface, ip, mac.lower()]

        if client_id:

            if not _CLIENT_ID.match(client_id):

                return False

            command.append(client_id)

        try:

            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.TIMEOUT_SECONDS,
            )

        except (OSError, subprocess.SubprocessError) as error:

            logger.debug("dhcp_release %s: %s", ip, error)

            return False

        if result.returncode != 0:

            logger.debug(
                "dhcp_release %s falló (%s): %s",
                ip,
                result.returncode,
                (result.stderr or result.stdout).strip()[:200],
            )

            return False

        return True
