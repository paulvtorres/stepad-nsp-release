"""Remove legacy per-domain category rules.

Revision ID: 0066
Revises: 0065
Create Date: 2026-11-26 19:00:00.000000
"""
from alembic import op


revision = "0066"
down_revision = "0065"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        "DELETE FROM device_access_rules WHERE source = 'category'"
    )


def downgrade() -> None:
    pass
