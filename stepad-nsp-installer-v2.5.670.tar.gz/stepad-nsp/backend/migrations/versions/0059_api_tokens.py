"""API tokens

Revision ID: 0059
Revises: 0058
Create Date: 2026-11-20 16:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0059"
down_revision = "0058"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "api_tokens",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("name", sa.String(length=80), nullable=False),
        sa.Column("token_hash", sa.String(length=64), nullable=False),
        sa.Column("prefix", sa.String(length=16), nullable=False),
        sa.Column("role", sa.String(length=20), nullable=False, server_default="OPERATOR"),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("last_used_at", sa.DateTime(), nullable=True),
        sa.Column("expires_at", sa.DateTime(), nullable=True),
        sa.Column("revoked_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_api_tokens_hash", "api_tokens", ["token_hash"], unique=True)
    op.create_index("ix_api_tokens_active", "api_tokens", ["enabled", "revoked_at"])


def downgrade() -> None:
    op.drop_index("ix_api_tokens_active", table_name="api_tokens")
    op.drop_index("ix_api_tokens_hash", table_name="api_tokens")
    op.drop_table("api_tokens")
