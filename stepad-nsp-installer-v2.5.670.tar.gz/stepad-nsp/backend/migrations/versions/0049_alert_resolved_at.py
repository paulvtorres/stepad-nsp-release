"""Alert resolution timestamp

Revision ID: 0049
Revises: 0048
Create Date: 2026-11-13 13:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0049"
down_revision = "0048"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "alerts",
        sa.Column("resolved_at", sa.DateTime(), nullable=True),
    )
    op.create_index(
        "ix_alerts_resolved_at", "alerts", ["resolved_at"]
    )


def downgrade() -> None:
    op.drop_index("ix_alerts_resolved_at", table_name="alerts")
    op.drop_column("alerts", "resolved_at")
