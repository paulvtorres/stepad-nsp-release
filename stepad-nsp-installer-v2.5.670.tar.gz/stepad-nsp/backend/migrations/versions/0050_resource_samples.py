"""Resource capacity samples

Revision ID: 0050
Revises: 0049
Create Date: 2026-11-13 14:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0050"
down_revision = "0049"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "resource_samples",
        sa.Column("id", sa.Integer(), primary_key=True, nullable=False),
        sa.Column("cpu_percent", sa.Float(), nullable=False),
        sa.Column("ram_percent", sa.Float(), nullable=False),
        sa.Column("disk_percent", sa.Float(), nullable=False),
        sa.Column("load_1", sa.Float(), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index(
        "ix_resource_samples_created_at",
        "resource_samples",
        ["created_at"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_resource_samples_created_at", table_name="resource_samples"
    )
    op.drop_table("resource_samples")
