"""Device archive lifecycle

Revision ID: 0051
Revises: 0050
Create Date: 2026-11-13 15:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0051"
down_revision = "0050"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_devices",
        sa.Column("archived_at", sa.DateTime(), nullable=True),
    )
    op.add_column(
        "network_devices",
        sa.Column("archive_reason", sa.String(length=255), nullable=True),
    )
    op.create_index(
        "ix_network_devices_archived_at", "network_devices", ["archived_at"]
    )


def downgrade() -> None:
    op.drop_index("ix_network_devices_archived_at", table_name="network_devices")
    op.drop_column("network_devices", "archive_reason")
    op.drop_column("network_devices", "archived_at")
