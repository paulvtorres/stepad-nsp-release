"""Schema alignment: NOT NULL columns and a missing foreign key

`alembic check` contra una base creada solo con migraciones mostro que el
modelo y el esquema real difieren en:

* 6 columnas que el modelo declara NOT NULL pero la base permite NULL
  (se rellenan los NULL existentes y luego se exige NOT NULL);
* `network_share_backup_jobs.folder_id`: el modelo declara la clave foranea
  (ON DELETE SET NULL) y la base no la tenia, asi que podian quedar jobs
  apuntando a una carpeta borrada (huerfanos se ponen a NULL).

Los nombres de indices y restricciones se alinearon en los MODELOS (no hay
cambios de esquema para eso: la base ya tenia los indices correctos).

Revision ID: 0062
Revises: 0061
Create Date: 2026-11-21 12:00:00.000000
"""
from alembic import op


revision = "0062"
down_revision = "0061"
branch_labels = None
depends_on = None


# (tabla, columna, valor de relleno para los NULL existentes)
NOT_NULL_COLUMNS = [
    ("alert_ignore_rules", "created_at", "CURRENT_TIMESTAMP"),
    ("attack_blocked_ips", "created_at", "CURRENT_TIMESTAMP"),
    ("data_retention_settings", "updated_at", "CURRENT_TIMESTAMP"),
    ("email_settings", "updated_at", "CURRENT_TIMESTAMP"),
    ("device_ip_history", "started_at", "CURRENT_TIMESTAMP"),
    ("device_ip_history", "source", "'unknown'"),
]


def upgrade() -> None:
    for table, column, fill in NOT_NULL_COLUMNS:
        op.execute(f"UPDATE {table} SET {column} = {fill} WHERE {column} IS NULL")
        op.alter_column(table, column, nullable=False)

    # Jobs que apuntan a una carpeta que ya no existe: se desligan (SET NULL
    # es justo lo que la clave foranea hara de aqui en adelante).
    op.execute(
        "UPDATE network_share_backup_jobs SET folder_id = NULL "
        "WHERE folder_id IS NOT NULL AND folder_id NOT IN "
        "(SELECT id FROM network_share_folders)"
    )
    op.create_foreign_key(
        "fk_network_share_backup_jobs_folder_id",
        "network_share_backup_jobs",
        "network_share_folders",
        ["folder_id"],
        ["id"],
        ondelete="SET NULL",
    )


def downgrade() -> None:
    op.drop_constraint(
        "fk_network_share_backup_jobs_folder_id",
        "network_share_backup_jobs",
        type_="foreignkey",
    )

    for table, column, _ in NOT_NULL_COLUMNS:
        op.alter_column(table, column, nullable=True)
