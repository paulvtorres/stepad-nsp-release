"""Critical alert escalation

Revision ID: 0061
Revises: 0060
Create Date: 2026-11-21 10:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0061"
down_revision = "0060"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "notification_settings",
        sa.Column("alert_escalation_enabled", sa.Boolean(), nullable=False, server_default=sa.text("false")),
    )
    op.add_column(
        "notification_settings",
        sa.Column("alert_escalation_minutes", sa.Integer(), nullable=False, server_default="30"),
    )
    op.add_column(
        "notification_settings",
        sa.Column("alert_escalation_emails", sa.String(length=1000), nullable=False, server_default=""),
    )
    op.add_column(
        "notification_settings",
        sa.Column("alert_escalation_cc_emails", sa.String(length=1000), nullable=False, server_default=""),
    )
    op.add_column(
        "notification_settings",
        sa.Column("alert_escalation_bcc_emails", sa.String(length=1000), nullable=False, server_default=""),
    )
    op.add_column(
        "alerts",
        sa.Column("escalated_at", sa.DateTime(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("alerts", "escalated_at")
    op.drop_column("notification_settings", "alert_escalation_bcc_emails")
    op.drop_column("notification_settings", "alert_escalation_cc_emails")
    op.drop_column("notification_settings", "alert_escalation_emails")
    op.drop_column("notification_settings", "alert_escalation_minutes")
    op.drop_column("notification_settings", "alert_escalation_enabled")
