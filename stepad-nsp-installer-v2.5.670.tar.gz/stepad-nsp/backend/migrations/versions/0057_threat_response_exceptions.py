"""Device-level threat response exceptions

Revision ID: 0057
Revises: 0056
Create Date: 2026-11-19 13:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0057"
down_revision = "0056"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "threat_response_exceptions",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("device_id", sa.Integer(), sa.ForeignKey("network_devices.id", ondelete="SET NULL"), nullable=True),
        sa.Column("mac_address", sa.String(length=17), nullable=False),
        sa.Column("reason", sa.String(length=255), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("expires_at", sa.DateTime(), nullable=True),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_threat_exceptions_mac", "threat_response_exceptions", ["mac_address"])


def downgrade() -> None:
    op.drop_index("ix_threat_exceptions_mac", table_name="threat_response_exceptions")
    op.drop_table("threat_response_exceptions")
