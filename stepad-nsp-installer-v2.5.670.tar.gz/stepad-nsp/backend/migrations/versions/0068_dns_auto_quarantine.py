"""DNS auto-quarantine settings.

Revision ID: 0068
Revises: 0067
Create Date: 2026-11-26 22:25:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0068"
down_revision = "0067"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "threat_response_settings",
        sa.Column(
            "dns_auto_quarantine_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )
    op.add_column(
        "threat_response_settings",
        sa.Column(
            "dns_auto_quarantine_confidence",
            sa.Integer(),
            nullable=False,
            server_default="90",
        ),
    )


def downgrade() -> None:
    op.drop_column("threat_response_settings", "dns_auto_quarantine_confidence")
    op.drop_column("threat_response_settings", "dns_auto_quarantine_enabled")
