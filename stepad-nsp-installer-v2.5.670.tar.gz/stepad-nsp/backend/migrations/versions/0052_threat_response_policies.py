"""Threat response policy engine

Revision ID: 0052
Revises: 0051
Create Date: 2026-11-19 08:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0052"
down_revision = "0051"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "threat_response_policies",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("name", sa.String(length=80), nullable=False),
        sa.Column("match_type", sa.String(length=20), nullable=False),
        sa.Column("match_value", sa.String(length=500), nullable=True),
        sa.Column("action", sa.String(length=30), nullable=False, server_default="alert"),
        sa.Column("priority", sa.Integer(), nullable=False, server_default="100"),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("description", sa.String(length=255), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index(
        "ix_threat_response_policies_priority",
        "threat_response_policies",
        ["enabled", "priority"],
    )
    op.add_column(
        "threat_response_settings",
        sa.Column(
            "protect_infrastructure",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("true"),
        ),
    )
    op.add_column(
        "malware_events",
        sa.Column("action", sa.String(length=30), nullable=True),
    )
    op.add_column(
        "malware_events",
        sa.Column("policy_name", sa.String(length=80), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("malware_events", "policy_name")
    op.drop_column("malware_events", "action")
    op.drop_column("threat_response_settings", "protect_infrastructure")
    op.drop_index(
        "ix_threat_response_policies_priority",
        table_name="threat_response_policies",
    )
    op.drop_table("threat_response_policies")
