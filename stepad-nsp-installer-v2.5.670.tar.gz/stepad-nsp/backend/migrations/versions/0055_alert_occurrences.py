"""Alert occurrence grouping

Revision ID: 0055
Revises: 0054
Create Date: 2026-11-19 11:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0055"
down_revision = "0054"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "alerts",
        sa.Column("occurrences", sa.Integer(), nullable=False, server_default="1"),
    )
    op.add_column("alerts", sa.Column("first_seen_at", sa.DateTime(), nullable=True))
    op.add_column("alerts", sa.Column("last_seen_at", sa.DateTime(), nullable=True))
    op.execute(
        "UPDATE alerts SET first_seen_at = created_at, last_seen_at = created_at "
        "WHERE first_seen_at IS NULL"
    )
    op.create_index("ix_alerts_last_seen", "alerts", ["last_seen_at"])


def downgrade() -> None:
    op.drop_index("ix_alerts_last_seen", table_name="alerts")
    op.drop_column("alerts", "last_seen_at")
    op.drop_column("alerts", "first_seen_at")
    op.drop_column("alerts", "occurrences")
