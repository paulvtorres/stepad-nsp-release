"""Persistent email outbox

Revision ID: 0054
Revises: 0053
Create Date: 2026-11-19 10:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0054"
down_revision = "0053"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "email_outbox",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("channel", sa.String(length=40), nullable=False, server_default="general"),
        sa.Column("to_emails", sa.Text(), nullable=False),
        sa.Column("cc_emails", sa.Text(), nullable=False, server_default=""),
        sa.Column("bcc_emails", sa.Text(), nullable=False, server_default=""),
        sa.Column("subject", sa.String(length=255), nullable=False),
        sa.Column("html_body", sa.Text(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="pending"),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("next_attempt_at", sa.DateTime(), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("dedupe_key", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("sent_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_email_outbox_status", "email_outbox", ["status", "next_attempt_at"])
    op.create_index("ix_email_outbox_dedupe", "email_outbox", ["dedupe_key"])


def downgrade() -> None:
    op.drop_index("ix_email_outbox_dedupe", table_name="email_outbox")
    op.drop_index("ix_email_outbox_status", table_name="email_outbox")
    op.drop_table("email_outbox")
