"""Indexes for DNS live blocking and category counts.

Revision ID: 0063
Revises: 0062
Create Date: 2026-11-26 14:00:00.000000
"""
from alembic import op


revision = "0063"
down_revision = "0062"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # These two indexes were created concurrently on the production table
    # before this migration; IF NOT EXISTS keeps the migration idempotent.
    op.execute(
        "CREATE INDEX IF NOT EXISTS ix_dns_query_logs_policy_hit_lower "
        "ON dns_query_logs (lower(policy_hit))"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS ix_dns_query_logs_blocked_time "
        "ON dns_query_logs (queried_at) WHERE blocked IS TRUE"
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_dns_query_logs_blocked_time")
    op.execute("DROP INDEX IF EXISTS ix_dns_query_logs_policy_hit_lower")
