"""Track whether a category domain came from a remote feed.

Revision ID: 0064
Revises: 0063
Create Date: 2026-11-26 16:00:00.000000
"""
import sqlalchemy as sa
from alembic import op


revision = "0064"
down_revision = "0063"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "category_domains",
        sa.Column(
            "managed_by_feed",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )

    # Existing feed-managed categories. Manual domains added before this
    # migration are rare and can only be distinguished going forward.
    op.execute(
        "UPDATE category_domains SET managed_by_feed = TRUE "
        "WHERE category_id IN ("
        "SELECT id FROM content_categories "
        "WHERE key IN ('ads_trackers', 'malware')"
        ")"
    )


def downgrade() -> None:
    op.drop_column("category_domains", "managed_by_feed")
