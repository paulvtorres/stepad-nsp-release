"""Temporary alert snooze

Revision ID: 0058
Revises: 0057
Create Date: 2026-11-20 14:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0058"
down_revision = "0057"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "alert_ignore_rules",
        sa.Column("reason", sa.String(length=255), nullable=True),
    )
    op.add_column(
        "alert_ignore_rules",
        sa.Column("created_by", sa.Integer(), nullable=True),
    )
    op.add_column(
        "alert_ignore_rules",
        sa.Column("expires_at", sa.DateTime(), nullable=True),
    )
    op.create_index(
        "ix_alert_ignore_rules_expires",
        "alert_ignore_rules",
        ["expires_at"],
    )


def downgrade() -> None:
    op.drop_index("ix_alert_ignore_rules_expires", table_name="alert_ignore_rules")
    op.drop_column("alert_ignore_rules", "expires_at")
    op.drop_column("alert_ignore_rules", "created_by")
    op.drop_column("alert_ignore_rules", "reason")
