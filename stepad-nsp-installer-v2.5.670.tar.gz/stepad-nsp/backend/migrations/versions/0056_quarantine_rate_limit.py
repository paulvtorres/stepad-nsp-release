"""Quarantine circuit breaker

Revision ID: 0056
Revises: 0055
Create Date: 2026-11-19 12:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0056"
down_revision = "0055"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "threat_response_settings",
        sa.Column(
            "quarantine_max_per_window",
            sa.Integer(),
            nullable=False,
            server_default="5",
        ),
    )
    op.add_column(
        "threat_response_settings",
        sa.Column(
            "quarantine_window_minutes",
            sa.Integer(),
            nullable=False,
            server_default="10",
        ),
    )


def downgrade() -> None:
    op.drop_column("threat_response_settings", "quarantine_window_minutes")
    op.drop_column("threat_response_settings", "quarantine_max_per_window")
