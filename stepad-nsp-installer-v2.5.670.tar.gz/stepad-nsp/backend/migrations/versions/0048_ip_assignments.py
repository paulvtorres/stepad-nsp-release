"""Formal IP assignments (IPAM)

Revision ID: 0048
Revises: 0047
Create Date: 2026-11-13 12:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0048"
down_revision = "0047"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "ip_assignments",
        sa.Column("id", sa.Integer(), primary_key=True, nullable=False),
        sa.Column("ip_address", sa.String(length=45), nullable=False),
        sa.Column("mac_address", sa.String(length=17), nullable=False),
        sa.Column("device_id", sa.Integer(), nullable=True),
        sa.Column("kind", sa.String(length=20), nullable=False, server_default="lease"),
        sa.Column("source", sa.String(length=20), nullable=False, server_default="dhcp"),
        sa.Column("assigned_at", sa.DateTime(), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=True),
        sa.Column("released_at", sa.DateTime(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="active"),
        sa.ForeignKeyConstraint(
            ["device_id"], ["network_devices.id"], ondelete="SET NULL"
        ),
    )
    op.create_index("ix_ip_assignments_ip_address", "ip_assignments", ["ip_address"])
    op.create_index("ix_ip_assignments_mac_address", "ip_assignments", ["mac_address"])
    # Una sola asignación activa por IP. Las observaciones NO están aquí.
    op.create_index(
        "ux_ip_assignments_active_ip",
        "ip_assignments",
        ["ip_address"],
        unique=True,
        postgresql_where=sa.text("released_at IS NULL"),
    )


def downgrade() -> None:
    op.drop_index("ux_ip_assignments_active_ip", table_name="ip_assignments")
    op.drop_index("ix_ip_assignments_mac_address", table_name="ip_assignments")
    op.drop_index("ix_ip_assignments_ip_address", table_name="ip_assignments")
    op.drop_table("ip_assignments")
