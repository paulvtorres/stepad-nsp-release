"""Threat response policy audit history

Revision ID: 0053
Revises: 0052
Create Date: 2026-11-19 09:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0053"
down_revision = "0052"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "threat_response_policy_revisions",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("policy_id", sa.Integer(), nullable=True),
        sa.Column("action", sa.String(length=20), nullable=False),
        sa.Column("before_data", sa.Text(), nullable=True),
        sa.Column("after_data", sa.Text(), nullable=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index(
        "ix_threat_policy_revisions_created",
        "threat_response_policy_revisions",
        ["created_at"],
    )
    op.create_index(
        "ix_threat_policy_revisions_policy",
        "threat_response_policy_revisions",
        ["policy_id"],
    )


def downgrade() -> None:
    op.drop_index("ix_threat_policy_revisions_policy", table_name="threat_response_policy_revisions")
    op.drop_index("ix_threat_policy_revisions_created", table_name="threat_response_policy_revisions")
    op.drop_table("threat_response_policy_revisions")
