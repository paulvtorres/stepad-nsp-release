"""Auto-diagnostico y auto-reparacion del NSP al arrancar.

Corre despues de que la API arranca. Verifica:
1. PostgreSQL responde
2. Schema de DB consistente (alembic_version)
3. Tablas criticas existen
4. Archivos de configuracion validos
5. nftables chains aplicados
6. Procesos criticos corriendo
7. Filesystem escribible

Si encuentra problemas:
- Intenta auto-reparar si es posible
- Genera alerta CRITICA con pasos a seguir
- Loguea todo para revision posterior
"""

import os
import subprocess
import time

from datetime import datetime
from backend.shared.datetime_utils import utcnow
from pathlib import Path

from sqlalchemy import text

from backend.shared.logging.logger import logger


EXPECTED_ALEMBIC_VERSION = "0032"

# Espera antes de reintentar las comprobaciones de estado (nftables,
# procesos, puertos): tras el arranque los servicios se aplican en
# segundo plano y se reportaba como caída lo que aún no había subido.
SETTLE_SECONDS = 30

CRITICAL_TABLES = [
    "users", "alerts", "firewall_settings", "threat_response_settings",
    "alembic_version", "attack_blocked_ips", "ip_geo_asn",
    "inbound_attack_events", "network_zones", "managed_interfaces",
]

CONFIG_FILES = [
    "/etc/stepad/stepad.env",
    "/etc/stepad/dns/dnsmasq.conf",
]

NFT_CHAINS = ["harden-forward", "harden-input", "attack-block", "c2-block"]

CRITICAL_PROCESSES = ["postgres", "suricata"]


def _expected_alembic_version() -> str:

    """Revisión Alembic esperada: la más alta presente en el repo.

    Antes era un valor fijo ("0032") que quedó viejo y generaba una
    alerta falsa de "Version de schema desactualizada" en CADA arranque.
    """

    versions_dir = (
        Path(__file__).resolve().parents[2] / "migrations" / "versions"
    )

    try:

        revisions = [
            path.name.split("_", 1)[0]
            for path in versions_dir.glob("*.py")
            if path.name.split("_", 1)[0].isdigit()
        ]

    except Exception as error:
        logger.debug("boot_health_check._expected_alembic_version: %s", error)

        revisions = []

    if revisions:

        return max(revisions)

    return EXPECTED_ALEMBIC_VERSION


class BootHealthCheck:

    def __init__(self):
        self._issues = []

    def run(self):
        logger.info("Health check: iniciando auto-diagnostico de arranque...")

        self._check_filesystem()
        self._check_postgres()
        self._check_schema()
        self._check_tables()
        self._check_config_files()
        self._check_watchdog_marker()

        # Comprobaciones de estado: pueden fallar justo tras el arranque
        # porque los servicios se aplican en segundo plano. Se reintentan
        # una vez tras una pausa y solo se reportan los problemas que
        # persisten (evita las alertas falsas de cada reinicio).
        self._check_state()

        if self._issues:
            self._generate_alerts()
            logger.warning(
                "Health check: %d problema(s) detectado(s). "
                "Revise la tabla de alertas.",
                len(self._issues),
            )
        else:
            logger.info("Health check: todo OK, sin problemas detectados.")

        return self._issues

    def _check_filesystem(self):
        critical_paths = ["/etc/stepad", "/var/log"]
        for path_str in critical_paths:
            path = Path(path_str)
            if not path.exists():
                self._issues.append({
                    "check": "filesystem",
                    "severity": "critical",
                    "title": "Directorio faltante: %s" % path_str,
                    "message": (
                        "El directorio %s no existe. "
                        "Esto puede indicar corrupcion del filesystem "
                        "o una instalacion incompleta." % path_str
                    ),
                    "repair": "Ejecute: sudo mkdir -p %s && sudo chown root:root %s" % (path_str, path_str),
                })
                return
            test_file = path / ".stepad_health_check"
            try:
                test_file.write_text("test")
                test_file.unlink()
            except Exception as exc:
                logger.debug("boot_health_check._check_filesystem: %s", exc)
                self._issues.append({
                    "check": "filesystem",
                    "severity": "critical",
                    "title": "Filesystem no escribible: %s" % path_str,
                    "message": (
                        "No se pudo escribir en %s: %s. "
                        "Esto puede indicar filesystem corrupto "
                        "o montado como solo-lectura." % (path_str, exc)
                    ),
                    "repair": (
                        "1) Reinicie en modo recovery (GRUB)\n"
                        "2) Ejecute: fsck -y /dev/sda1\n"
                        "3) Reinicie normalmente\n"
                        "Si persiste, verifique: mount | grep '%s'" % path_str
                    ),
                })

    def _check_postgres(self):
        try:
            from backend.core.database.connection import engine
            with engine.connect() as conn:
                result = conn.execute(text("SELECT 1"))
                result.fetchone()
        except Exception as exc:
            logger.debug("boot_health_check._check_postgres: %s", exc)
            self._issues.append({
                "check": "postgres",
                "severity": "critical",
                "title": "PostgreSQL no responde",
                "message": (
                    "No se pudo conectar a PostgreSQL: %s. "
                    "La base de datos puede estar caida o corrupta." % exc
                ),
                "repair": (
                    "1) Verifique: sudo systemctl status postgresql\n"
                    "2) Si esta detenido: sudo systemctl start postgresql\n"
                    "3) Si no inicia, revise logs: "
                    "sudo journalctl -u postgresql -n 50\n"
                    "4) Si hay corrupcion, ejecute: "
                    "sudo pg_resetwal -f /var/lib/postgresql/*/main"
                ),
            })
            return

    def _check_schema(self):
        try:
            from backend.core.database.connection import engine
            with engine.connect() as conn:
                result = conn.execute(
                    text("SELECT version_num FROM alembic_version")
                )
                row = result.fetchone()
                if not row:
                    self._issues.append({
                        "check": "schema",
                        "severity": "critical",
                        "title": "Tabla alembic_version vacia",
                        "message": (
                            "La tabla alembic_version no tiene registros. "
                            "El esquema de la DB puede estar incompleto."
                        ),
                        "repair": (
                            "1) Verifique: psql -U stepad_app -d stepad_nsp "
                            "-c 'SELECT * FROM alembic_version'\n"
                            "2) Si esta vacia, el servicio intentara "
                            "re-aplicar las migraciones al reiniciar.\n"
                            "3) Si falla, restaurar desde backup de DB."
                        ),
                    })
                    return
                version = row[0]
                expected_version = _expected_alembic_version()
                if version != expected_version:
                    self._issues.append({
                        "check": "schema",
                        "severity": "warning",
                        "title": "Version de schema desactualizada",
                        "message": (
                            "La DB esta en version %s pero se espera %s. "
                            "Las migraciones pendientes se aplicaran "
                            "automaticamente." % (version, expected_version)
                        ),
                        "repair": (
                            "El servicio deberia aplicar las migraciones "
                            "al reiniciar. Si no lo hace, verifique: "
                            "psql -U stepad_app -d stepad_nsp "
                            "-c 'SELECT * FROM alembic_version'"
                        ),
                    })
        except Exception as exc:
            logger.warning("Health check: no pude verificar schema: %s", exc)

    def _check_tables(self):
        try:
            from backend.core.database.connection import engine
            with engine.connect() as conn:
                result = conn.execute(text(
                    "SELECT table_name FROM information_schema.tables "
                    "WHERE table_schema = 'public'"
                ))
                existing = {row[0] for row in result.fetchall()}

                missing = [t for t in CRITICAL_TABLES if t not in existing]
                if missing:
                    self._issues.append({
                        "check": "tables",
                        "severity": "critical",
                        "title": "Tablas faltantes: %s" % ", ".join(missing),
                        "message": (
                            "Las siguientes tablas criticas no existen: %s. "
                            "Esto puede indicar una migracion fallida."
                            % ", ".join(missing)
                        ),
                        "repair": (
                            "1) El servicio intentara re-aplicar las "
                            "migraciones al reiniciar.\n"
                            "2) Si falla, verifique: "
                            "psql -U stepad_app -d stepad_nsp "
                            "-c '\\dt'\n"
                            "3) Si persiste, restaurar desde backup."
                        ),
                    })

                for table in ["users", "alerts"]:
                    if table in existing:
                        result = conn.execute(text(
                            "SELECT count(*) FROM %s" % table
                        ))
                        count = result.scalar()
                        if count == 0 and table == "users":
                            self._issues.append({
                                "check": "tables",
                                "severity": "critical",
                                "title": "Tabla users vacia",
                                "message": (
                                    "La tabla users no tiene registros. "
                                    "No hay usuarios administradores."
                                ),
                                "repair": (
                                    "Ejecute: python3 install.py "
                                    "para recrear el usuario admin."
                                ),
                            })
        except Exception as exc:
            logger.warning("Health check: no pude verificar tablas: %s", exc)

    def _check_config_files(self):
        for filepath in CONFIG_FILES:
            path = Path(filepath)
            if not path.exists():
                self._issues.append({
                    "check": "config",
                    "severity": "critical",
                    "title": "Archivo de config faltante: %s" % filepath,
                    "message": (
                        "El archivo %s no existe. "
                        "El servicio puede no funcionar correctamente."
                        % filepath
                    ),
                    "repair": (
                        "1) Restaure desde backup: "
                        "cp /etc/stepad/backup/%s %s\n"
                        "2) O re-instale el paquete."
                        % (path.name, filepath)
                    ),
                })
                continue
            try:
                content = path.read_text()
                if not content.strip():
                    self._issues.append({
                        "check": "config",
                        "severity": "critical",
                        "title": "Archivo de config vacio: %s" % filepath,
                        "message": (
                            "El archivo %s esta vacio. "
                            "Esto puede indicar corrupcion por corte "
                            "de energia." % filepath
                        ),
                        "repair": (
                            "1) Restaure desde backup: "
                            "cp /etc/stepad/backup/%s %s\n"
                            "2) Si no hay backup, re-instale el paquete."
                            % (path.name, filepath)
                        ),
                    })
            except Exception as exc:
                logger.debug("boot_health_check._check_config_files: %s", exc)
                self._issues.append({
                    "check": "config",
                    "severity": "warning",
                    "title": "No se pudo leer: %s" % filepath,
                    "message": "Error al leer %s: %s" % (filepath, exc),
                    "repair": "Verifique permisos: ls -la %s" % filepath,
                })

    def _check_state(self):
        """Ejecuta las comprobaciones de estado con un reintento.

        Los servicios (dnsmasq, pdns, nftables, Suricata) se levantan en
        segundo plano tras el arranque: informar de inmediato generaba
        alertas falsas. Se espera un momento y se vuelve a comprobar; solo
        se reportan los problemas que persisten.
        """

        static_count = len(self._issues)

        self._check_nftables()
        self._check_processes()
        self._check_ports()

        if len(self._issues) == static_count:

            return

        logger.info(
            "Health check: reintentando comprobaciones de estado en %ds...",
            SETTLE_SECONDS,
        )

        time.sleep(SETTLE_SECONDS)

        self._issues = self._issues[:static_count]

        self._check_nftables()
        self._check_processes()
        self._check_ports()

    def _check_nftables(self):
        try:
            # "nft list chains inet stepad" NO es sintaxis valida de nft
            # (fallaba siempre y se reportaban cadenas "faltantes" que si
            # existian). Se lista la tabla y, si no responde, el ruleset.
            result = subprocess.run(
                ["/usr/sbin/nft", "list", "table", "inet", "stepad"],
                capture_output=True, text=True, timeout=5,
            )

            if result.returncode == 0:
                output = result.stdout
            else:
                result = subprocess.run(
                    ["/usr/sbin/nft", "list", "ruleset"],
                    capture_output=True, text=True, timeout=5,
                )
                output = result.stdout

            missing = [
                chain for chain in NFT_CHAINS
                if ("chain %s" % chain) not in output
            ]
            if missing:
                self._issues.append({
                    "check": "nftables",
                    "severity": "warning",
                    "title": "Cadenas nftables faltantes: %s" % ", ".join(missing),
                    "message": (
                        "Las cadenas nftables %s no existen. "
                        "El firewall puede no estar protegiendo correctamente."
                        % ", ".join(missing)
                    ),
                    "repair": (
                        "Re-aplique el hardening desde el panel: "
                        "Proteccion -> Firewall -> Aplicar hardening\n"
                        "O ejecute manualmente: "
                        "nft -f /etc/stepad/nftables.conf"
                    ),
                })
        except Exception as exc:
            logger.warning("Health check: no pude verificar nftables: %s", exc)

    def _check_processes(self):
        """Verifica que los procesos criticos esten disponibles.

        No alerta durante los primeros 120s post-arranque para evitar
        falsos positivos (suricata/dnsmasq pueden estar iniciando).
        El monitoreo periodico (monitoring_component) detecta caidas
        reales y genera alertas persistentes.
        """
        import time

        try:
            from backend.shared.runtime import runtime
            start_ts = runtime.get("_start_time") or 0
        except Exception as error:
            logger.debug("boot_health_check._check_processes: %s", error)
            start_ts = 0

        uptime = time.time() - start_ts if start_ts else 999
        if uptime < 120:
            logger.info(
                "Health check: saltando verif. de procesos "
                "(uptime=%.0fs, tolerancia 120s).",
                uptime,
            )
            return

        for proc_name in CRITICAL_PROCESSES:
            try:
                result = subprocess.run(
                    self._process_command(proc_name),
                    capture_output=True, text=True, timeout=5,
                )
                if result.returncode != 0:
                    if proc_name == "suricata" and self._suricata_pid_alive():
                        continue
                    self._issues.append({
                        "check": "process",
                        "severity": "warning",
                        "title": "Proceso no encontrado: %s" % proc_name,
                        "message": (
                            "El proceso %s no esta corriendo. "
                            "El monitoreo periodico reintentara automaticamente."
                            % proc_name
                        ),
                        "repair": self._get_process_repair(proc_name),
                    })
            except Exception as exc:
                logger.warning(
                    "Health check: no pude verificar %s: %s",
                    proc_name, exc,
                )

    def _process_command(self, proc_name):
        """Comando para detectar el proceso.

        Suricata renombra su proceso principal a "Suricata-Main" (por eso
        `pgrep -x suricata` nunca lo encontraba y se reportaba como
        caído). Para Suricata se busca por su linea de comandos.
        """

        if proc_name == "suricata":

            return ["pgrep", "-f", "/usr/bin/suricata -D"]

        return ["pgrep", "-x", proc_name]

    def _suricata_pid_alive(self) -> bool:

        """Respaldo: el daemon está vivo según su pidfile."""

        try:

            pid = int(Path("/run/suricata.pid").read_text().strip())

            os.kill(pid, 0)

            return True

        except PermissionError:

            # Existe pero pertenece a otro usuario (root): sigue vivo.
            return True

        except Exception as error:
            logger.debug("boot_health_check._suricata_pid_alive: %s", error)

            return False

    def _get_process_repair(self, proc_name):
        repairs = {
            "postgres": (
                "1) sudo systemctl status postgresql\n"
                "2) sudo systemctl start postgresql\n"
                "3) Si falla: sudo journalctl -u postgresql -n 50"
            ),
            "suricata": (
                "1) sudo systemctl status suricata\n"
                "2) sudo systemctl start suricata\n"
                "3) Si falla, verifique configuracion: "
                "suricata -T -c /etc/suricata/suricata.yaml"
            ),
        }
        return repairs.get(proc_name, (
            "1) sudo systemctl status %s\n"
            "2) sudo systemctl start %s" % (proc_name, proc_name)
        ))

    def _check_ports(self):
        """Verifica puertos abiertos contra lista de permitidos/prohibidos."""
        try:
            from backend.core.health.ports_check import check_ports
            self._issues.extend(check_ports())
        except Exception as exc:
            logger.warning("Health check: no pude verificar puertos: %s", exc)

    def _check_watchdog_marker(self):
        marker = Path("/run/stepad-watchdog-restarted")

        if not marker.exists():
            return

        try:
            value = marker.read_text(encoding="utf-8").strip()
        except OSError:
            value = ""

        try:
            marker.unlink()
        except OSError:
            pass

        self._issues.append({
            "check": "watchdog",
            "severity": "warning",
            "title": "NSP reiniciado por watchdog externo",
            "message": (
                "El watchdog externo detectó que el NSP no respondía y "
                f"reinició el servicio. Marca: {value or 'sin fecha'}."
            ),
            "repair": (
                "Revisar el historial de alertas y los logs del NSP. "
                "Si se repite, revisar CPU, memoria, PostgreSQL y disco."
            ),
        })

    def _generate_alerts(self):
        try:
            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()
            try:
                for issue in self._issues:
                    severity = issue.get("severity", "warning")
                    title = issue.get("title", "Problema detectado")
                    message = (
                        "Check: %s\n"
                        "Detalle: %s\n"
                        "Pasos para resolver:\n%s"
                        % (
                            issue.get("check", "unknown"),
                            issue.get("message", ""),
                            issue.get("repair", "No hay pasos disponibles."),
                        )
                    )
                    AlertService().create(
                        db,
                        alert_type="BOOT_HEALTH_%s"
                        % issue.get("check", "unknown").upper(),
                        severity=severity,
                        title="Auto-diagnostico: %s" % title,
                        message=message[:1000],
                    )
                db.commit()
            finally:
                db.close()
        except Exception as exc:
            logger.error(
                "Health check: no pude generar alertas en DB: %s", exc,
            )
