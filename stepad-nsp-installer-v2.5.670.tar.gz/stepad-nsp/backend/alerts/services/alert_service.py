import threading

from sqlalchemy.orm import Session

from datetime import datetime
from backend.shared.datetime_utils import utcnow

from backend.alerts.models.alert import Alert
from backend.alerts.repositories.alert_repository import AlertRepository
from backend.alerts.services.alert_device_resolver import (
    client_ip_from_ips_message,
)
from backend.shared.utils.datetimes import (
    format_ecuador_datetime,
    to_iso_utc,
)


class AlertService:

    # Audit actions that deserve an alert, with severity.
    SEVERITY = {
        "ACCOUNT_LOCKED": "critical",
        "USER_LOGIN_FAILED": "warning",
        "USER_CREATED": "warning",
        "USER_STATUS_CHANGED": "warning",
        "PASSWORD_CHANGED": "info",
        "MFA_ENABLED": "info",
        "MFA_DISABLED": "warning",
        "VPN_PEER_CREATED": "info",
        "VPN_PEER_UPDATED": "info",
        "VPN_PEER_DELETED": "warning",
        "VPN_PEER_EXPIRED": "warning",
        "PORT_FORWARD_CREATED": "info",
        "PORT_FORWARD_DELETED": "warning",
        "DEVICE_BLOCKED": "warning",
        "DEVICE_UNBLOCKED": "info",
        "SHARE_MASS_CHANGE": "critical",
        "SHARE_DISK_HEALTH": "critical",
        "RULE_CREATED": "info",
        "RULE_DELETED": "warning",
        "ZONE_CREATED": "info",
        "ZONE_DELETED": "warning",
        "ENCRYPTED_DNS_ENABLED": "info",
        "ENCRYPTED_DNS_DISABLED": "warning",
    }

    # Hourly email limit and per-alert cooldown: prevents flooding the
     # mailbox while a critical condition persists.
    EMAIL_COOLDOWN_SECONDS = 1800
    EMAIL_MAX_PER_HOUR = 20

    # Una repeticion de webhook por alerta y hora como maximo.
    WEBHOOK_REPEAT_SECONDS = 3600

    # COMPARTIDO por todas las instancias: el sistema crea AlertService()
    # nuevo en cada llamada (40 sitios), asi que un cooldown por instancia
    # no limitaba nada y una alerta critica que se repite enviaba un correo
    # por cada repeticion.
    _email_sent: dict[str, float] = {}

    _webhook_sent: dict[str, float] = {}

    _state_lock = threading.Lock()

    @classmethod
    def reset_rate_limits(cls) -> None:

        with cls._state_lock:

            cls._email_sent.clear()

            cls._webhook_sent.clear()

    def __init__(self):

        self.repository = AlertRepository()

    def create(
        self,
        db: Session,
        alert_type: str,
        severity: str,
        title: str,
        message: str = ""
    ):

        if self.repository.is_ignored(db, alert_type, title):

            return None

        # Evita inundar la pantalla: si ya hay una alerta SIN LEER
        # idéntica (mismo tipo + título), se actualiza en lugar de
        # crear otra copia. Una condición que persiste queda como una
        # sola entrada viva, no como cientos de repetidos.
        existing = self.repository.find_recent_unread(
            db, alert_type, title
        )

        now = utcnow()

        if existing is not None:

            existing.severity = severity

            existing.message = message or title

            existing.occurrences = int(existing.occurrences or 1) + 1

            existing.first_seen_at = existing.first_seen_at or existing.created_at or now

            existing.last_seen_at = now

            saved = self.repository.save(db, existing)

            if severity == "critical":

                # Si sigue sin resolverse, AlertService reenvía como
                # máximo una vez por hora (cooldown interno).
                self._maybe_email(db, alert_type, title, existing.message)

            self._dispatch_webhook(db, saved, repeat=True)

            return saved

        alert = Alert(
            alert_type=alert_type,
            severity=severity,
            title=title,
            message=message or title,
            occurrences=1,
            first_seen_at=now,
            last_seen_at=now,
        )

        saved = self.repository.create(db, alert)

        if severity == "critical":

            self._maybe_email(db, alert_type, title, alert.message)

        self._dispatch_webhook(db, alert)

        return saved

    def _dispatch_webhook(self, db, alert, repeat: bool = False):

        # El aviso de que los webhooks fallan no se reenvia por webhook (el
        # de correo si: es justo el otro canal).
        if alert.alert_type == "WEBHOOK_DELIVERY_FAILING":

            return

        # Una condicion que persiste se repite en cada ciclo (cada minuto):
        # el webhook de una REPETICION se limita a una por hora.
        import time

        key = f"{alert.alert_type}:{alert.title}"

        now = time.monotonic()

        with self._state_lock:

            last = self._webhook_sent.get(key)

            if repeat and last and now - last < self.WEBHOOK_REPEAT_SECONDS:

                return

            self._webhook_sent[key] = now

        try:

            from backend.integrations.services.webhook_service import (
                WebhookService,
            )

            WebhookService().enqueue_alert(
                db,
                alert_type=alert.alert_type,
                severity=alert.severity,
                title=alert.title,
                message=alert.message,
                created_at=alert.last_seen_at or alert.created_at,
            )

        except Exception as error:

            from backend.shared.logging.logger import logger

            logger.debug("alert_service webhook: %s", error)

    def _maybe_email(
        self,
        db: Session,
        alert_type: str,
        title: str,
        message: str,
    ) -> None:

        """Send email for critical alerts, with anti-spam control."""

        import time

        now = time.monotonic()

        key = f"{alert_type}:{title}"

        with self._state_lock:

            last = self._email_sent.get(key)

            if last and now - last < self.EMAIL_COOLDOWN_SECONDS:

                return

            recent = [
                stamp for stamp in self._email_sent.values()
                if now - stamp < 3600
            ]

            if len(recent) >= self.EMAIL_MAX_PER_HOUR:

                return

        try:

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            if CriticalAlertEmailService().send(db, title, message):

                with self._state_lock:

                    self._email_sent[key] = now

        except Exception as error:

            from backend.shared.logging.logger import logger

            logger.debug("alert_service._maybe_email: %s", error)

    def resolve(self, db: Session, alert_type: str, title: str | None = None) -> int:
        """Marca como resueltas las alertas activas de un tipo."""

        from backend.alerts.models.alert import Alert

        query = db.query(Alert).filter(
            Alert.alert_type == alert_type,
            Alert.resolved_at.is_(None),
        )
        if title:
            query = query.filter(Alert.title == title)
        now = utcnow()
        updated = query.update(
            {Alert.resolved_at: now, Alert.read: True},
            synchronize_session=False,
        )
        db.commit()
        return int(updated or 0)

    def list(
        self,
        db: Session,
        limit: int = 50,
        unread_only: bool = False
    ):

        alerts = self.repository.list(
            db,
            limit=limit,
            unread_only=unread_only
        )

        from backend.network.devices.repositories.device_repository import (
            DeviceRepository
        )

        from backend.alerts.services.alert_guidance import alert_guidance

        device_repo = DeviceRepository()

        result = []

        for alert in alerts:

            device_name = None

            device_ip = client_ip_from_ips_message(alert.message)

            if device_ip:

                device = device_repo.find_by_ip(db, device_ip)

                if device:

                    device_name = (
                        device.display_name
                        or device.hostname
                        or device_ip
                    )

            result.append({
                "id": alert.id,
                "type": alert.alert_type,
                "severity": alert.severity,
                "title": alert.title,
                "message": alert.message,
                "read": alert.read,
                "created_at": to_iso_utc(alert.created_at),
                "first_seen_at": to_iso_utc(alert.first_seen_at),
                "last_seen_at": to_iso_utc(alert.last_seen_at),
                "occurrences": int(alert.occurrences or 1),
                "resolved_at": to_iso_utc(alert.resolved_at),
                "created_at_ec": format_ecuador_datetime(alert.created_at),
                "device_name": device_name,
                "device_ip": device_ip,
                "guidance": alert_guidance(alert.title, alert.message),
            })

        return result

    def unread_count(
        self,
        db: Session
    ):

        return self.repository.unread_count(db)


    def critical_unread_count(
        self,
        db: Session
    ):

        from backend.alerts.models.alert import Alert

        return (
            db.query(Alert)
            .filter(
                Alert.severity == "critical",
                Alert.read == False  # noqa: E712
            )
            .count()
        )

    def mark_read(
        self,
        db: Session,
        alert_id: int
    ):

        alert = self.repository.mark_read(db, alert_id)

        if alert is None:

            return {"success": False, "message": "Alert not found"}

        return {"success": True}

    def mark_all_read(
        self,
        db: Session
    ):

        self.repository.mark_all_read(db)

        return {"success": True}

    def list_ignore_rules(
        self,
        db: Session
    ):

        rules = self.repository.list_ignore_rules(db)

        return [
            {
                "id": rule.id,
                "match_field": rule.match_field,
                "matcher": rule.matcher,
                "value": rule.value,
                "created_at": to_iso_utc(rule.created_at),
                "expires_at": to_iso_utc(rule.expires_at),
                "reason": rule.reason or "",
                "active": (
                    rule.expires_at is None
                    or rule.expires_at > utcnow()
                ),
            }
            for rule in rules
        ]

    def add_ignore_rule(
        self,
        db: Session,
        match_field: str,
        matcher: str,
        value: str,
        expires_at=None,
        reason: str | None = None,
        user_id: int | None = None,
        remove_existing: bool = True,
    ):

        rule = self.repository.add_ignore_rule(
            db,
            match_field=match_field,
            matcher=matcher,
            value=(value or "").strip(),
            expires_at=expires_at,
            reason=(reason or "").strip() or None,
            created_by=user_id,
        )

        removed = 0

        if remove_existing:

            removed = self.repository.delete_ignored_alerts_for_rule(
                db,
                rule.id
            )

        try:

            from backend.audit.services.audit_service import AuditService

            AuditService().create_log(
                db=db,
                user_id=user_id,
                action="ALERT_SNOOZE_CREATED",
                resource="ALERT",
                description=(
                    f"Silenciado temporal/permanente: {rule.value} "
                    f"({rule.reason or 'sin motivo'})"
                )[:255],
            )

        except Exception as error:

            logger.debug("alert snooze audit: %s", error)

        return {
            "rule": {
                "id": rule.id,
                "match_field": rule.match_field,
                "matcher": rule.matcher,
                "value": rule.value,
                "created_at": to_iso_utc(rule.created_at),
                "expires_at": to_iso_utc(rule.expires_at),
                "reason": rule.reason or "",
                "active": True,
            },
            "removed": removed,
        }

    def delete_ignore_rule(
        self,
        db: Session,
        rule_id: int
    ):

        return self.repository.delete_ignore_rule(db, rule_id)

    def ignored_count(
        self,
        db: Session
    ):

        return len(self.list_ignore_rules(db))
