from sqlalchemy import Boolean, DateTime, Integer, String, Index
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime
from backend.shared.datetime_utils import utcnow

from backend.core.database.base import Base


class Alert(Base):

    __tablename__ = "alerts"
    __table_args__ = (
        Index("ix_alerts_last_seen", "last_seen_at"),
        Index("ix_alerts_resolved_at", "resolved_at"),
    )


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )


    alert_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False
    )


    # info | warning | critical
    severity: Mapped[str] = mapped_column(
        String(10),
        nullable=False,
        default="info"
    )


    title: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )


    message: Mapped[str] = mapped_column(
        String(500),
        nullable=False
    )


    read: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utcnow
    )

    occurrences: Mapped[int] = mapped_column(
        Integer,
        default=1,
        nullable=False,
    )

    first_seen_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    last_seen_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    escalated_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )
