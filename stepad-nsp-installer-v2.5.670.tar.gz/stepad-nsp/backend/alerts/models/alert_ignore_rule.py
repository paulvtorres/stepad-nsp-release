from datetime import datetime
from backend.shared.datetime_utils import utcnow

from sqlalchemy import Boolean, DateTime, Integer, String, Index
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class AlertIgnoreRule(Base):

    __tablename__ = "alert_ignore_rules"
    __table_args__ = (
        Index("ix_alert_ignore_rules_expires", "expires_at"),
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # title | alert_type
    match_field: Mapped[str] = mapped_column(
        String(20),
        nullable=False
    )

    # exact | contains
    matcher: Mapped[str] = mapped_column(
        String(20),
        nullable=False
    )

    value: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )

    reason: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    created_by: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    # NULL = permanente; si vence, la regla deja de aplicar.
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utcnow
    )
