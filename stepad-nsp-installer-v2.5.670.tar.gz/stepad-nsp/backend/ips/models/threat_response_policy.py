from sqlalchemy import Boolean, DateTime, Integer, String, Index
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


class ThreatResponsePolicy(Base):

    __tablename__ = "threat_response_policies"
    __table_args__ = (
        Index("ix_threat_response_policies_priority", "enabled", "priority"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    name: Mapped[str] = mapped_column(String(80), nullable=False)

    # category | signature | default
    match_type: Mapped[str] = mapped_column(String(20), nullable=False)

    # Comma-separated, case-insensitive substrings. NULL for default.
    match_value: Mapped[str | None] = mapped_column(String(500), nullable=True)

    # ignore | alert | quarantine | block_c2 | quarantine_and_block_c2
    action: Mapped[str] = mapped_column(
        String(30), nullable=False, default="alert"
    )

    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=100)

    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    description: Mapped[str | None] = mapped_column(String(255), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )
