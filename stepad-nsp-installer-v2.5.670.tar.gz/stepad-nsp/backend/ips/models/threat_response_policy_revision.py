from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, Index
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base
from backend.shared.datetime_utils import utcnow


class ThreatResponsePolicyRevision(Base):

    __tablename__ = "threat_response_policy_revisions"
    __table_args__ = (
        Index("ix_threat_policy_revisions_created", "created_at"),
        Index("ix_threat_policy_revisions_policy", "policy_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    policy_id: Mapped[int | None] = mapped_column(Integer, nullable=True)

    action: Mapped[str] = mapped_column(String(20), nullable=False)

    before_data: Mapped[str | None] = mapped_column(Text, nullable=True)

    after_data: Mapped[str | None] = mapped_column(Text, nullable=True)

    user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id"), nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
