from sqlalchemy import Boolean, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime
from backend.shared.datetime_utils import utcnow

from backend.core.database.base import Base


class ThreatResponseSetting(Base):

    __tablename__ = "threat_response_settings"


    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # Aisla (bloquea la MAC) el dispositivo que genera una deteccion
    # de malware/C2 en el IPS.
    quarantine_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )

    # Agrega la IP destino (C2) a la lista de bloqueo del cortafuegos.
    c2_block_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )

    # Si True, NFQUEUE no usa bypass: el trafico se pierde si Suricata
    # no esta leyendo la cola.
    ips_fail_closed: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )

    # Si True, el IPS entrante bloquea automaticamente la IP del
    # atacante (ademas de registrarla). Si False, solo queda en el log.
    auto_block_inbound: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )

    # Nunca aislar automaticamente servidores, impresoras, switches,
    # APs ni equipos de infraestructura, aunque una firma coincida.
    protect_infrastructure: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )

    # Circuit breaker: max auto-quarantines in a rolling window.
    quarantine_max_per_window: Mapped[int] = mapped_column(
        Integer,
        default=5,
    )

    quarantine_window_minutes: Mapped[int] = mapped_column(
        Integer,
        default=10,
    )

    # Cuarentena automática por detección DNS avanzada (túnel/beaconing).
    # Desactivada por defecto: es una acción destructiva.
    dns_auto_quarantine_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
    )

    # Confianza mínima 0-100 para aislar por DNS.
    dns_auto_quarantine_confidence: Mapped[int] = mapped_column(
        Integer,
        default=90,
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=utcnow,
        onupdate=utcnow
    )
