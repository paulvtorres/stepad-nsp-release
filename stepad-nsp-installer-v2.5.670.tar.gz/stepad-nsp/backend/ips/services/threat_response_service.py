import ipaddress
import json
import re

from sqlalchemy import func

from datetime import datetime, timedelta, timezone

import subprocess

from backend.core.database.session import SessionLocal

from backend.alerts.services.alert_service import AlertService

from backend.audit.services.audit_service import AuditService

from backend.ips.models.threat_response_setting import ThreatResponseSetting

from backend.ips.models.threat_response_policy import ThreatResponsePolicy
from backend.ips.models.threat_response_policy_revision import (
    ThreatResponsePolicyRevision,
)
from backend.ips.models.threat_response_exception import (
    ThreatResponseException,
)

from backend.ips.models.malware_event import MalwareEvent

from backend.ips.repositories.malware_event_repository import (
    MalwareEventRepository
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.network.devices.services.device_classifier import (
    DeviceClassifier,
)

from backend.firewall.adapters.linux.linux_firewall_provider import (
    LinuxFirewallProvider
)

from backend.notifications.services.critical_alert_email_service import (
    CriticalAlertEmailService,
)
from backend.notifications.services.quarantine_email_service import (
    QuarantineEmailService,
)

from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


# Categorias de Suricata que indican malware/controlador (C2).
# Categorias de Suricata que indican malware/controlador (C2) de ALTA
# confianza. Se excluyen etiquetas amplias como "potentially bad
# traffic": incluyen firmas INFO (ej. versiones viejas de Java) que no
# son malware y provocaban falsos positivos (aislar equipos y bloquear
# IPs de CDN legitimos).
MALWARE_CATEGORIES = (
    "trojan",
    "malware",
    "botnet",
    "ransomware",
    "spyware",
    "keylogger",
    "command and control",
    "cnc",
    "a network trojan was detected",
)

# Marcas de firma (reglas ET) de malware/C2 de alta confianza.
POLICY_MATCH_TYPES = frozenset({"category", "signature", "default"})

POLICY_ACTIONS = frozenset({
    "ignore",
    "alert",
    "quarantine",
    "block_c2",
    "quarantine_and_block_c2",
})

DEFAULT_POLICIES = (
    {
        "name": "SNMP público / descubrimiento",
        "match_type": "signature",
        "match_value": "snmp public access",
        "action": "alert",
        "priority": 10,
        "description": (
            "Consultas SNMP con comunidad public (impresoras y "
            "descubrimiento). Alerta, nunca cuarentena automática."
        ),
    },
    {
        "name": "Malware/C2 de alta confianza",
        "match_type": "category",
        "match_value": (
            "trojan, malware, botnet, ransomware, spyware, keylogger, "
            "command and control, cnc, a network trojan was detected"
        ),
        "action": "quarantine_and_block_c2",
        "priority": 20,
        "description": (
            "Categorías de malware/C2 de alta confianza. Aísla el equipo "
            "y bloquea el destino externo."
        ),
    },
    {
        "name": "Information leak / escaneo",
        "match_type": "category",
        "match_value": "attempted information leak",
        "action": "alert",
        "priority": 30,
        "description": (
            "Categoría amplia de intento de fuga de información. "
            "Genera alerta para revisión manual; no aísla por sí sola."
        ),
    },
    {
        "name": "Default seguro",
        "match_type": "default",
        "match_value": None,
        "action": "ignore",
        "priority": 1000,
        "description": "Sin acción automática para detecciones no clasificadas.",
    },
)

SIGNATURE_MARKERS = (
    "et trojan",
    "et malware",
    "et cnc",
    "et c2",
    "et botnet",
    "et ransomware",
    "et banking",
    "malware",
    "trojan",
    "botnet",
    "ransomware",
    "banking trojan",
    "packed executable",
    "cobalt strike",
    "command and control",
    "cmd and control",
    "qakbot",
    "emotet",
    "trickbot",
    "njrat",
)


class ThreatResponseService:


    def __init__(self):

        self.repo = MalwareEventRepository()

        self.device_repo = DeviceRepository()

        self.alert_service = AlertService()

        self.audit_service = AuditService()

        self.provider = LinuxFirewallProvider()

        self.critical_alert_email = CriticalAlertEmailService()

        self.quarantine_email = QuarantineEmailService()

        self._last_resync = 0.0

        self._last_state = {}

        # ip -> (expira, id del equipo, motivo): una rafaga de alertas de
        # la misma IP no debe sondear la red por cada una.
        self._owner_cache: dict = {}


    # ------------------------------------------------------------------
    # Clasificacion
    # ------------------------------------------------------------------

    def is_malware_event(
        self,
        category: str,
        signature: str
    ):

        haystack = f"{category} {signature}".lower()

        return any(
            marker in haystack
            for marker in (
                MALWARE_CATEGORIES + SIGNATURE_MARKERS
            )
        )


    # ------------------------------------------------------------------
    # Políticas de respuesta
    # ------------------------------------------------------------------

    @staticmethod
    def _policy_dict(row):

        return {
            "id": row.id,
            "name": row.name,
            "match_type": row.match_type,
            "match_value": row.match_value or "",
            "action": row.action,
            "priority": int(row.priority or 0),
            "enabled": bool(row.enabled),
            "description": row.description or "",
            "created_at": (
                row.created_at.isoformat() if row.created_at else None
            ),
            "updated_at": (
                row.updated_at.isoformat() if row.updated_at else None
            ),
        }

    def ensure_default_policies(self, db):

        if db.query(ThreatResponsePolicy).count():
            return

        for item in DEFAULT_POLICIES:
            db.add(ThreatResponsePolicy(**item))

        db.commit()

    def get_policies(self, db):

        self.ensure_default_policies(db)

        rows = (
            db.query(ThreatResponsePolicy)
            .order_by(ThreatResponsePolicy.priority, ThreatResponsePolicy.id)
            .all()
        )

        return [self._policy_dict(row) for row in rows]

    @staticmethod
    def _validate_policy_values(name, match_type, match_value, action, priority):

        name = str(name or "").strip()
        match_type = str(match_type or "").strip().lower()
        match_value = str(match_value or "").strip()
        action = str(action or "").strip().lower()

        if not name or len(name) > 80:
            raise ValueError("El nombre es obligatorio (máx. 80 caracteres).")

        if match_type not in POLICY_MATCH_TYPES:
            raise ValueError("Tipo de coincidencia inválido.")

        if match_type == "default":
            match_value = ""
        elif not match_value:
            raise ValueError("La coincidencia requiere un valor.")
        elif len(match_value) > 500:
            raise ValueError("La coincidencia supera 500 caracteres.")

        if action not in POLICY_ACTIONS:
            raise ValueError("Acción inválida.")

        try:
            priority = int(priority)
        except (TypeError, ValueError):
            raise ValueError("La prioridad debe ser numérica.")

        if not 0 <= priority <= 10000:
            raise ValueError("La prioridad debe estar entre 0 y 10000.")

        return name, match_type, match_value, action, priority

    def _policy_snapshot(self, db, policy_id):
        row = db.get(ThreatResponsePolicy, policy_id)
        return self._policy_dict(row) if row is not None else None

    def _record_policy_revision(
        self, db, action, policy_id, before, after, user_id
    ):
        revision = ThreatResponsePolicyRevision(
            policy_id=policy_id,
            action=action,
            before_data=json.dumps(before, ensure_ascii=False) if before else None,
            after_data=json.dumps(after, ensure_ascii=False) if after else None,
            user_id=user_id,
        )
        db.add(revision)
        db.commit()
        try:
            self.audit_service.create_log(
                db=db,
                user_id=user_id,
                action=f"THREAT_POLICY_{action.upper()}",
                resource="THREAT_POLICY",
                description=(
                    f"Política IPS #{policy_id or '-'} {action}: "
                    f"{(after or before or {}).get('name', 'sin nombre')}"
                )[:255],
            )
        except Exception as error:
            logger.debug("policy audit log: %s", error)

    def create_policy(self, db, **values):

        user_id = values.pop("user_id", None)

        name, match_type, match_value, action, priority = (
            self._validate_policy_values(
                values.get("name"),
                values.get("match_type"),
                values.get("match_value"),
                values.get("action"),
                values.get("priority", 100),
            )
        )

        row = ThreatResponsePolicy(
            name=name,
            match_type=match_type,
            match_value=match_value or None,
            action=action,
            priority=priority,
            enabled=bool(values.get("enabled", True)),
            description=str(values.get("description") or "").strip() or None,
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        after = self._policy_dict(row)
        self._record_policy_revision(
            db, "create", row.id, None, after, user_id
        )
        return after

    def update_policy(self, db, policy_id: int, **values):

        user_id = values.pop("user_id", None)

        row = db.get(ThreatResponsePolicy, policy_id)

        if row is None:
            raise LookupError("Política no encontrada.")

        before = self._policy_dict(row)

        name, match_type, match_value, action, priority = (
            self._validate_policy_values(
                values.get("name", row.name),
                values.get("match_type", row.match_type),
                values.get("match_value", row.match_value),
                values.get("action", row.action),
                values.get("priority", row.priority),
            )
        )

        row.name = name
        row.match_type = match_type
        row.match_value = match_value or None
        row.action = action
        row.priority = priority
        row.enabled = bool(values.get("enabled", row.enabled))
        row.description = str(
            values.get("description", row.description or "")
        ).strip() or None
        db.commit()
        db.refresh(row)
        after = self._policy_dict(row)
        self._record_policy_revision(
            db, "update", row.id, before, after, user_id
        )
        return after

    def delete_policy(self, db, policy_id: int, user_id=None):

        row = db.get(ThreatResponsePolicy, policy_id)

        if row is None:
            raise LookupError("Política no encontrada.")

        before = self._policy_dict(row)
        db.delete(row)
        db.commit()
        self._record_policy_revision(
            db, "delete", policy_id, before, None, user_id
        )
        return {"success": True, "deleted": policy_id}

    def get_policy_history(self, db, limit: int = 50):

        rows = (
            db.query(ThreatResponsePolicyRevision)
            .order_by(ThreatResponsePolicyRevision.id.desc())
            .limit(max(1, min(int(limit), 200)))
            .all()
        )

        from backend.users.models.user import User

        result = []
        for row in rows:
            username = None
            if row.user_id:
                user = db.get(User, row.user_id)
                username = user.username if user else None
            before = json.loads(row.before_data) if row.before_data else None
            after = json.loads(row.after_data) if row.after_data else None
            result.append({
                "id": row.id,
                "policy_id": row.policy_id,
                "action": row.action,
                "policy_name": (after or before or {}).get("name", ""),
                "username": username,
                "before": before,
                "after": after,
                "created_at": to_iso_utc(row.created_at),
            })
        return result

    def restore_policy_revision(self, db, revision_id: int, user_id=None):

        revision = db.get(ThreatResponsePolicyRevision, revision_id)

        if revision is None:
            raise LookupError("Revisión no encontrada.")

        target = json.loads(revision.before_data) if revision.before_data else None
        current = self._policy_snapshot(db, revision.policy_id)
        policy_id = revision.policy_id

        if target is None:
            if current is not None:
                row = db.get(ThreatResponsePolicy, policy_id)
                if row is not None:
                    db.delete(row)
                    db.commit()
            after = None
        else:
            name, match_type, match_value, action, priority = (
                self._validate_policy_values(
                    target.get("name"),
                    target.get("match_type"),
                    target.get("match_value"),
                    target.get("action"),
                    target.get("priority", 100),
                )
            )
            row = db.get(ThreatResponsePolicy, policy_id)
            if row is None:
                row = ThreatResponsePolicy(id=policy_id)
                db.add(row)
            row.name = name
            row.match_type = match_type
            row.match_value = match_value or None
            row.action = action
            row.priority = priority
            row.enabled = bool(target.get("enabled", True))
            row.description = str(target.get("description") or "").strip() or None
            db.commit()
            db.refresh(row)
            after = self._policy_dict(row)

        self._record_policy_revision(
            db, "restore", policy_id, current, after, user_id
        )
        return {"success": True, "policy": after}

    @staticmethod
    def select_policy(policies, category, signature):

        text = f"{category or ''} {signature or ''}".lower()

        for policy in sorted(
            policies,
            key=lambda item: (
                int(item.priority if hasattr(item, "priority") else item.get("priority", 0)),
                int(item.id if hasattr(item, "id") else item.get("id", 0)),
            ),
        ):

            if not (policy.enabled if hasattr(policy, "enabled") else policy.get("enabled", True)):
                continue

            match_type = policy.match_type if hasattr(policy, "match_type") else policy.get("match_type")
            match_value = policy.match_value if hasattr(policy, "match_value") else policy.get("match_value")

            if match_type == "default":
                return policy

            values = [
                value.strip().lower()
                for value in str(match_value or "").split(",")
                if value.strip()
            ]

            if any(value in text for value in values):
                return policy

        return None

    def policy_for(self, db, category, signature):

        rows = (
            db.query(ThreatResponsePolicy)
            .filter(ThreatResponsePolicy.enabled.is_(True))
            .order_by(ThreatResponsePolicy.priority, ThreatResponsePolicy.id)
            .all()
        )

        if not rows:
            self.ensure_default_policies(db)
            rows = (
                db.query(ThreatResponsePolicy)
                .filter(ThreatResponsePolicy.enabled.is_(True))
                .order_by(ThreatResponsePolicy.priority, ThreatResponsePolicy.id)
                .all()
            )

        return self.select_policy(rows, category, signature)

    def simulate_event(
        self,
        db,
        *,
        signature: str,
        category: str = "",
        severity: str = "warning",
        src_ip: str = "",
        dst_ip: str = "",
        dst_port=None,
    ):

        """Preview a policy decision without applying any action."""

        settings = self.get_settings(db)
        policy = self.policy_for(db, category, signature)

        if policy is None:

            return {
                "matched": False,
                "policy": None,
                "action": "ignore",
                "action_label": "sin política",
                "alert": False,
                "quarantine": False,
                "block_c2": False,
                "reason": "Ninguna política coincide; no se aplica acción.",
            }

        action = policy.action
        wants_quarantine = action in (
            "quarantine",
            "quarantine_and_block_c2",
        )
        wants_c2 = action in (
            "block_c2",
            "quarantine_and_block_c2",
        )
        quarantine = False
        block_c2 = False
        reasons = []

        if action == "alert":

            reasons.append(
                "La política indica alerta; no se aislará el equipo."
            )

        if wants_quarantine:

            if not settings["quarantine_enabled"]:

                reasons.append("La cuarentena automática global está desactivada.")

            elif severity not in ("critical", "warning"):

                reasons.append("La severidad no autoriza cuarentena.")

            elif src_ip:

                try:

                    from backend.network.devices.services.device_presence_service import (
                        DevicePresenceService,
                    )

                    device, owner_reason = DevicePresenceService().owner_of(
                        db, src_ip, probe=False
                    )

                except Exception as error:

                    device, owner_reason = None, "unverified"
                    logger.debug("policy simulation owner_of: %s", error)

                if device is None:

                    reasons.append(
                        "No se pudo verificar el dueño actual de la IP; "
                        "no se aislará automáticamente."
                    )

                elif self._active_exception(db, device):

                    reasons.append(
                        "El equipo tiene una excepción activa; no se "
                        "aislará automáticamente."
                    )

                elif self._is_protected_device(device, settings):

                    reasons.append(
                        "El equipo es infraestructura o está protegido; "
                        "no se aislará automáticamente."
                    )

                else:

                    quarantine = True

            else:

                reasons.append(
                    "Se verificará el dueño de la IP al recibir el evento."
                )

        if wants_c2:

            if not settings["c2_block_enabled"]:

                reasons.append("El bloqueo C2 global está desactivado.")

            elif not dst_ip or not self._is_external(dst_ip):

                reasons.append(
                    "El destino no es externo; no se bloqueará C2."
                )

            elif severity not in ("critical", "warning"):

                reasons.append("La severidad no autoriza bloqueo C2.")

            else:

                block_c2 = True

        if not reasons:

            reasons.append("La política se aplicaría según lo configurado.")

        return {
            "matched": True,
            "policy": self._policy_dict(policy),
            "action": action,
            "action_label": self._action_label(action),
            "alert": True,
            "quarantine": quarantine,
            "block_c2": block_c2,
            "reason": " ".join(reasons),
        }

    def _severity(
        self,
        suricata_severity
    ):

        mapping = {
            1: "critical",
            2: "warning",
        }

        return mapping.get(suricata_severity, "info")


    def _is_actionable(self, severity: str):

        return severity in ("critical", "warning")


    def _is_external(self, ip: str):

        try:

            return ipaddress.ip_address(ip).is_global

        except ValueError:

            return False


    # ------------------------------------------------------------------
    # Ajustes
    # ------------------------------------------------------------------

    def get_settings(
        self,
        db
    ):

        row = db.query(ThreatResponseSetting).first()

        if row is None:

            row = ThreatResponseSetting()

            db.add(row)

            db.commit()

            db.refresh(row)

        return {
            "quarantine_enabled": row.quarantine_enabled,
            "c2_block_enabled": row.c2_block_enabled,
            "ips_fail_closed": row.ips_fail_closed,
            "auto_block_inbound": bool(
                getattr(row, "auto_block_inbound", False)
            ),
            "protect_infrastructure": bool(
                getattr(row, "protect_infrastructure", True)
            ),
            "quarantine_max_per_window": int(
                getattr(row, "quarantine_max_per_window", 5) or 5
            ),
            "quarantine_window_minutes": int(
                getattr(row, "quarantine_window_minutes", 10) or 10
            ),
            "dns_auto_quarantine_enabled": bool(
                getattr(row, "dns_auto_quarantine_enabled", False)
            ),
            "dns_auto_quarantine_confidence": int(
                getattr(row, "dns_auto_quarantine_confidence", 90) or 90
            ),
            "updated_at": row.updated_at,
        }


    def update_settings(
        self,
        db,
        quarantine_enabled,
        c2_block_enabled,
        ips_fail_closed=None,
        auto_block_inbound=None,
        protect_infrastructure=None,
        quarantine_max_per_window=None,
        quarantine_window_minutes=None,
        dns_auto_quarantine_enabled=None,
        dns_auto_quarantine_confidence=None,
    ):

        row = db.query(ThreatResponseSetting).first()

        if row is None:

            row = ThreatResponseSetting()

            db.add(row)

        if quarantine_enabled is not None:

            row.quarantine_enabled = quarantine_enabled

        if c2_block_enabled is not None:

            row.c2_block_enabled = c2_block_enabled

        if ips_fail_closed is not None:

            row.ips_fail_closed = ips_fail_closed

        if auto_block_inbound is not None:

            row.auto_block_inbound = auto_block_inbound

        if protect_infrastructure is not None:

            row.protect_infrastructure = bool(protect_infrastructure)

        if quarantine_max_per_window is not None:

            value = int(quarantine_max_per_window)

            if value < 1 or value > 100:

                raise ValueError("El límite de cuarentenas debe estar entre 1 y 100.")

            row.quarantine_max_per_window = value

        if quarantine_window_minutes is not None:

            value = int(quarantine_window_minutes)

            if value < 1 or value > 1440:

                raise ValueError("La ventana debe estar entre 1 y 1440 minutos.")

            row.quarantine_window_minutes = value

        if dns_auto_quarantine_enabled is not None:

            row.dns_auto_quarantine_enabled = bool(
                dns_auto_quarantine_enabled
            )

        if dns_auto_quarantine_confidence is not None:

            value = int(dns_auto_quarantine_confidence)

            if value < 50 or value > 100:

                raise ValueError(
                    "La confianza DNS debe estar entre 50 y 100."
                )

            row.dns_auto_quarantine_confidence = value

        db.commit()

        db.refresh(row)

        if ips_fail_closed is not None:

            try:

                from backend.firewall.services.nfqueue_service import (
                    NfqueueService,
                )

                NfqueueService().sync(fail_closed=row.ips_fail_closed)

            except Exception as error:

                logger.warning(
                    "No pude aplicar modo NFQUEUE: %s",
                    error,
                )

        if auto_block_inbound is not None:

            try:

                from backend.ips.services.attack_response_service import (
                    attack_response_service,
                )

                attack_response_service.sync(db)

            except Exception as error:

                logger.warning(
                    "No pude sincronizar bloqueo de atacantes: %s",
                    error,
                )

        return {
            "quarantine_enabled": row.quarantine_enabled,
            "c2_block_enabled": row.c2_block_enabled,
            "ips_fail_closed": row.ips_fail_closed,
            "auto_block_inbound": bool(
                getattr(row, "auto_block_inbound", False)
            ),
            "protect_infrastructure": bool(
                getattr(row, "protect_infrastructure", True)
            ),
            "quarantine_max_per_window": int(
                getattr(row, "quarantine_max_per_window", 5) or 5
            ),
            "quarantine_window_minutes": int(
                getattr(row, "quarantine_window_minutes", 10) or 10
            ),
            "dns_auto_quarantine_enabled": bool(
                getattr(row, "dns_auto_quarantine_enabled", False)
            ),
            "dns_auto_quarantine_confidence": int(
                getattr(row, "dns_auto_quarantine_confidence", 90) or 90
            ),
            "updated_at": row.updated_at,
        }


    # ------------------------------------------------------------------
    # Respuesta ante el evento
    # ------------------------------------------------------------------

    def process_dns_threats(self, db, findings: list[dict]) -> dict:
        """Quarantine only high-confidence DNS findings when armed.

        Disabled by default. Every destructive action still goes through
        the same infrastructure/exception/rate-limit checks as IPS
        quarantine, and creates a MalwareEvent for the audit trail.
        """

        settings = self.get_settings(db)
        threshold = int(
            settings.get("dns_auto_quarantine_confidence", 90) or 90
        )
        enabled = bool(
            settings.get("quarantine_enabled")
            and settings.get("dns_auto_quarantine_enabled")
        )
        result = {
            "enabled": enabled,
            "threshold": threshold,
            "quarantined": [],
            "skipped": [],
        }

        if not enabled:
            return result

        seen_devices = set()

        for finding in findings or []:

            kind = str(finding.get("kind") or "")

            if kind not in ("dns_tunneling", "dns_beaconing", "dns_dga"):
                continue

            confidence = int(finding.get("confidence") or 0)

            if confidence < threshold:
                continue

            domain = str(finding.get("domain") or "")
            client_ip = str(finding.get("client_ip") or "")
            device_id = finding.get("device_id")
            device = None

            if device_id is not None:
                device = self.device_repo.find_by_id(db, int(device_id))
            elif client_ip:
                device, _reason = self._resolve_source_device(db, client_ip)

            if device is None:
                result["skipped"].append({
                    "kind": kind,
                    "domain": domain,
                    "reason": "equipo no verificado",
                })
                continue

            if device.id in seen_devices:
                continue

            seen_devices.add(device.id)

            if device.blocked:
                result["skipped"].append({
                    "kind": kind,
                    "domain": domain,
                    "device": getattr(device, "hostname", None),
                    "reason": "ya estaba aislado",
                })
                continue

            if self._is_protected_device(device, settings):
                result["skipped"].append({
                    "kind": kind,
                    "domain": domain,
                    "device": getattr(device, "hostname", None),
                    "reason": "infraestructura protegida",
                })
                continue

            if self._is_never_isolate(device, client_ip):
                result["skipped"].append({
                    "kind": kind,
                    "domain": domain,
                    "device": getattr(device, "hostname", None),
                    "reason": "equipo nunca aislable",
                })
                continue

            if self._active_exception(db, device):
                result["skipped"].append({
                    "kind": kind,
                    "domain": domain,
                    "device": getattr(device, "hostname", None),
                    "reason": "excepción activa",
                })
                continue

            limit_reason = self._quarantine_limit_reason(db, settings)

            if limit_reason:
                result["skipped"].append({
                    "kind": kind,
                    "domain": domain,
                    "device": getattr(device, "hostname", None),
                    "reason": limit_reason,
                })
                continue

            signature = f"DNS {kind}: {domain}"[:255]
            ok = self._quarantine_device(
                db,
                device,
                client_ip or getattr(device, "ip_address", "") or "",
                signature,
                category=f"dns_{kind}",
                policy=None,
                source_label="detección DNS avanzada",
            )

            if not ok:
                result["skipped"].append({
                    "kind": kind,
                    "domain": domain,
                    "device": getattr(device, "hostname", None),
                    "reason": "la cuarentena no pudo aplicarse",
                })
                continue

            try:
                self.repo.save(
                    db,
                    MalwareEvent(
                        src_ip=client_ip or getattr(device, "ip_address", "") or "",
                        src_mac=getattr(device, "mac_address", None),
                        device_id=device.id,
                        device_name=(
                            getattr(device, "display_name", None)
                            or getattr(device, "hostname", None)
                            or client_ip
                        ),
                        dst_ip=None,
                        dst_port=None,
                        signature=signature,
                        category=f"dns_{kind}",
                        severity="critical",
                        quarantined=True,
                        c2_blocked=False,
                        action="dns_auto_quarantine",
                        policy_name="DNS avanzado",
                    ),
                )
            except Exception as error:
                logger.warning(
                    "No se pudo registrar evento de cuarentena DNS: %s",
                    error,
                )

            result["quarantined"].append({
                "kind": kind,
                "confidence": confidence,
                "domain": domain,
                "device_id": device.id,
                "device": (
                    getattr(device, "display_name", None)
                    or getattr(device, "hostname", None)
                    or client_ip
                ),
            })

        return result

    def handle_event(
        self,
        db,
        event: dict
    ):

        alert = event.get("alert", {})

        signature = str(alert.get("signature") or "")

        category = str(alert.get("category") or "")

        sid = alert.get("signature_id") or alert.get("sid")

        severity = self._severity(alert.get("severity"))

        policy = self.policy_for(db, category, signature)

        if policy is None:

            return None

        policy_name = policy.name

        action = policy.action

        if action == "ignore":

            return None

        src_ip = event.get("src_ip", "")

        dst_ip = event.get("dest_ip", "")

        dst_port = event.get("dst_port", "")

        settings = self.get_settings(db)

        device, owner_reason = self._resolve_source_device(db, src_ip)

        protected = self._is_protected_device(
            device, settings
        ) or self._is_never_isolate(device, src_ip)

        wants_quarantine = action in (
            "quarantine",
            "quarantine_and_block_c2",
        )

        wants_c2 = action in (
            "block_c2",
            "quarantine_and_block_c2",
        )

        quarantined = False

        c2_blocked = False

        quarantine_blocked_reason = None

        if wants_quarantine:

            if not settings["quarantine_enabled"]:

                quarantine_blocked_reason = (
                    "La cuarentena automática global está desactivada."
                )

            elif device is None:

                quarantine_blocked_reason = self._unverified_reason(
                    src_ip, owner_reason
                )

            elif device.blocked:

                quarantine_blocked_reason = "El equipo ya estaba aislado."

            elif self._active_exception(db, device):

                quarantine_blocked_reason = (
                    "El equipo tiene una excepción activa y no se aísla automáticamente."
                )

            elif protected:

                quarantine_blocked_reason = (
                    "El equipo es infraestructura o está protegido y no "
                    "se aísla automáticamente."
                )

            elif not self._is_actionable(severity):

                quarantine_blocked_reason = (
                    "La severidad de la detección no autoriza cuarentena."
                )

            else:

                limit_reason = self._quarantine_limit_reason(db, settings)

                if limit_reason:

                    quarantine_blocked_reason = limit_reason

                    self._raise_quarantine_limit_alert(
                        db, src_ip, signature, settings, policy
                    )

                else:

                    quarantined = self._quarantine_device(
                    db,
                    device,
                    src_ip,
                    signature,
                    category=category,
                    policy=policy,
                    dst_ip=dst_ip,
                    dst_port=dst_port,
                    sid=sid,
                )

        if wants_c2:

            if not settings["c2_block_enabled"]:

                pass

            elif dst_ip and self._is_external(dst_ip) and self._is_actionable(severity):

                c2_blocked = self._block_c2_ip(
                    db,
                    dst_ip,
                    signature
                )

        # Alert-only policies, and policies whose automatic action could
        # not be applied, must still be visible and understandable.
        if action == "alert" or action == "block_c2" or (
            wants_quarantine and not quarantined
        ) or (
            wants_c2 and not c2_blocked and action == "block_c2"
        ):

            self._raise_policy_alert(
                db,
                signature=signature,
                category=category,
                sid=sid,
                severity=severity,
                src_ip=src_ip,
                dst_ip=dst_ip,
                dst_port=dst_port,
                policy=policy,
                action=action,
                reason=quarantine_blocked_reason,
            )

        event_row = MalwareEvent(
            src_ip=src_ip,
            src_mac=device.mac_address if device else None,
            device_id=device.id if device else None,
            device_name=(
                device.display_name or device.hostname
                if device else None
            ),
            dst_ip=dst_ip,
            dst_port=str(dst_port) if dst_port else None,
            signature=signature[:255],
            category=category[:128] or None,
            severity=severity,
            quarantined=quarantined,
            c2_blocked=c2_blocked,
            action=action,
            policy_name=policy_name,
        )

        self.repo.save(db, event_row)

        return event_row


    OWNER_CACHE_SECONDS = 20.0

    def _resolve_source_device(self, db, src_ip: str):
        """Equipo que usa AHORA `src_ip` (o None + motivo).

        Aislar es destructivo y se hace por MAC: si se identifica por la
        ultima IP conocida, un equipo que se fue y tuvo esa IP antes puede
        ser aislado mientras el infectado sigue con acceso. Solo se actua
        sobre un dueño verificado (presencia o ARP en vivo).
        """

        import time

        now = time.monotonic()

        cached = self._owner_cache.get(src_ip)

        if cached and cached[0] > now:

            _, device_id, reason = cached

            device = (
                self.device_repo.find_by_id(db, device_id)
                if device_id is not None
                else None
            )

            if device_id is None or device is not None:

                return device, reason

        from backend.network.devices.services.device_presence_service import (
            DevicePresenceService,
        )

        try:

            device, reason = DevicePresenceService().owner_of(db, src_ip)

        except Exception as error:

            logger.warning("owner_of(%s) fallo: %s", src_ip, error)

            device, reason = None, "no_owner"

        if len(self._owner_cache) > 512:

            self._owner_cache.clear()

        self._owner_cache[src_ip] = (
            now + self.OWNER_CACHE_SECONDS,
            device.id if device else None,
            reason,
        )

        return device, reason

    @staticmethod
    def _unverified_reason(src_ip: str, owner_reason: str) -> str:

        if owner_reason == "ambiguous":

            return (
                f"La IP {src_ip} figura en uso por más de un equipo: no se "
                "puede identificar al responsable y no se aísla a ninguno."
            )

        if owner_reason == "unknown_device":

            return "No se encontró el equipo de origen en el inventario."

        return (
            f"No se pudo verificar qué equipo usa la IP {src_ip} en este "
            "momento (puede que la haya tenido otro antes): no se aísla "
            "automáticamente."
        )

    def _quarantine_limit_reason(self, db, settings):

        maximum = max(
            1, int(settings.get("quarantine_max_per_window", 5) or 5)
        )
        minutes = max(
            1, int(settings.get("quarantine_window_minutes", 10) or 10)
        )
        cutoff = utcnow() - timedelta(minutes=minutes)
        count = (
            db.query(MalwareEvent)
            .filter(
                MalwareEvent.quarantined.is_(True),
                MalwareEvent.created_at >= cutoff,
            )
            .count()
        )

        if count >= maximum:

            return (
                f"Límite de cuarentenas alcanzado: {count}/{maximum} "
                f"en {minutes} minutos. Se pausan los aislamientos "
                "automáticos para evitar cortar la red."
            )

        return None

    def _raise_quarantine_limit_alert(
        self, db, src_ip, signature, settings, policy
    ):

        maximum = max(
            1, int(settings.get("quarantine_max_per_window", 5) or 5)
        )
        minutes = max(
            1, int(settings.get("quarantine_window_minutes", 10) or 10)
        )
        self.alert_service.create(
            db,
            alert_type="QUARANTINE_LIMIT_REACHED",
            severity="critical",
            title="CUARENTENA PAUSADA: límite de aislamientos",
            message=(
                f"Se alcanzó el límite de {maximum} aislamientos en "
                f"{minutes} minutos. La detección {signature} desde "
                f"{src_ip} no aisló el equipo. Revisar suricata/políticas "
                "antes de reanudar."
            )[:2000],
        )

    MAC_RE = re.compile(r"^[0-9a-f]{2}(:[0-9a-f]{2}){5}$")

    @staticmethod
    def _parse_exception_expiry(value):

        if not value:

            return None

        if isinstance(value, datetime):

            return value

        try:

            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))

        except ValueError:

            raise ValueError("Fecha de expiración inválida.")

        if parsed.tzinfo is not None:

            parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)

        return parsed

    def _exception_dict(self, db, row):

        from backend.network.devices.models.network_device import NetworkDevice

        device = (
            db.get(NetworkDevice, row.device_id)
            if row.device_id else None
        )

        return {
            "id": row.id,
            "device_id": row.device_id,
            "device_name": (
                (device.display_name or device.hostname)
                if device else ""
            ),
            "mac_address": row.mac_address,
            "reason": row.reason,
            "enabled": bool(row.enabled),
            "expires_at": to_iso_utc(row.expires_at),
            "created_at": to_iso_utc(row.created_at),
        }

    def get_exceptions(self, db, include_expired: bool = False):

        rows = (
            db.query(ThreatResponseException)
            .filter(ThreatResponseException.enabled.is_(True))
            .order_by(ThreatResponseException.id.desc())
            .all()
        )
        now = utcnow()
        result = []
        for row in rows:
            if (
                not include_expired
                and row.expires_at is not None
                and row.expires_at <= now
            ):
                continue
            result.append(self._exception_dict(db, row))
        return result

    def create_exception(
        self,
        db,
        mac_address: str,
        reason: str,
        expires_at=None,
        user_id=None,
    ):

        mac = str(mac_address or "").strip().lower()
        if not self.MAC_RE.fullmatch(mac):
            raise ValueError("MAC inválida.")

        reason = str(reason or "").strip()
        if not reason:
            raise ValueError("El motivo es obligatorio.")

        now = utcnow()
        existing = (
            db.query(ThreatResponseException)
            .filter(
                ThreatResponseException.mac_address == mac,
                ThreatResponseException.enabled.is_(True),
            )
            .all()
        )
        for row in existing:
            if row.expires_at is None or row.expires_at > now:
                raise ValueError("Ese equipo ya tiene una excepción activa.")

        from backend.network.devices.models.network_device import NetworkDevice
        device = (
            db.query(NetworkDevice)
            .filter(func.lower(NetworkDevice.mac_address) == mac)
            .order_by(NetworkDevice.id.desc())
            .first()
        )
        expires = self._parse_exception_expiry(expires_at)
        row = ThreatResponseException(
            device_id=device.id if device else None,
            mac_address=mac,
            reason=reason[:255],
            enabled=True,
            expires_at=expires,
            created_by=user_id,
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        try:
            self.audit_service.create_log(
                db=db,
                user_id=user_id,
                action="THREAT_EXCEPTION_CREATED",
                resource="THREAT_EXCEPTION",
                description=f"Excepción para {mac}: {reason}"[:255],
            )
        except Exception as error:
            logger.debug("exception audit: %s", error)
        return self._exception_dict(db, row)

    def delete_exception(self, db, exception_id: int, user_id=None):

        row = db.get(ThreatResponseException, exception_id)
        if row is None:
            raise LookupError("Excepción no encontrada.")
        mac = row.mac_address
        db.delete(row)
        db.commit()
        try:
            self.audit_service.create_log(
                db=db,
                user_id=user_id,
                action="THREAT_EXCEPTION_DELETED",
                resource="THREAT_EXCEPTION",
                description=f"Excepción eliminada para {mac}"[:255],
            )
        except Exception as error:
            logger.debug("exception audit: %s", error)
        return {"success": True, "deleted": exception_id}

    def _active_exception(self, db, device):

        if device is None:
            return None

        mac = (getattr(device, "mac_address", "") or "").lower()
        rows = (
            db.query(ThreatResponseException)
            .filter(
                ThreatResponseException.enabled.is_(True),
                (
                    ThreatResponseException.device_id == device.id
                ) | (
                    func.lower(ThreatResponseException.mac_address) == mac
                ),
            )
            .all()
        )
        now = utcnow()
        return next(
            (
                row for row in rows
                if row.expires_at is None or row.expires_at > now
            ),
            None,
        )

    def _local_identity(self):
        """IPv4 y MAC propias del NSP (todas sus interfaces)."""

        import socket

        import psutil

        ips, macs = set(), set()

        for addresses in psutil.net_if_addrs().values():

            for address in addresses:

                if address.family == socket.AF_INET:

                    ips.add(address.address)

                elif address.family == psutil.AF_LINK:

                    macs.add(address.address.lower().replace("-", ":"))

        return ips, macs

    def _segment_infrastructure_ips(self) -> set[str]:
        """Puerta de enlace y DNS del segmento (segun la configuracion DHCP)."""

        from backend.shared.config.config_service import ConfigService

        dhcp = ConfigService().get_dhcp_config() or {}

        return {
            str(dhcp.get(key)).strip()
            for key in ("gateway", "dns_server")
            if dhcp.get(key)
        }

    def _is_never_isolate(self, device, src_ip: str) -> bool:
        """Salvaguarda que NO se puede desactivar.

        `protect_infrastructure` se puede apagar; aun asi, aislar al propio
        NSP o a la puerta de enlace/DNS del segmento dejaria TODA la red sin
        servicio por una sola firma. Nunca se aisla a:
        - el propio NSP (sus IPs o MACs),
        - la puerta de enlace ni el DNS configurados.
        """

        try:

            own_ips, own_macs = self._local_identity()

            if src_ip in own_ips:

                return True

            if device is not None and (device.mac_address or "").lower() in own_macs:

                return True

        except Exception as error:

            logger.debug("never_isolate (identidad propia): %s", error)

        try:

            infrastructure = self._segment_infrastructure_ips()

            if src_ip in infrastructure:

                return True

            if device is not None and (
                (device.current_ip or device.ip_address) in infrastructure
            ):

                return True

        except Exception as error:

            logger.debug("never_isolate (infraestructura): %s", error)

        return False

    def _is_protected_device(self, device, settings) -> bool:

        if device is None:

            return False

        if not settings.get("protect_infrastructure", True):

            return False

        return bool(
            getattr(device, "is_permanent", False)
            or DeviceClassifier.is_infrastructure(
                getattr(device, "device_type", None)
            )
        )

    @staticmethod
    def _action_label(action: str) -> str:

        return {
            "alert": "solo alerta",
            "quarantine": "cuarentena automática",
            "block_c2": "bloqueo de destino C2",
            "quarantine_and_block_c2": "cuarentena y bloqueo C2",
            "ignore": "sin acción",
        }.get(action, action)

    def _policy_message(
        self,
        *,
        signature,
        category,
        sid,
        severity,
        src_ip,
        dst_ip,
        dst_port,
        policy,
        action,
        reason=None,
    ):

        lines = [
            f"Detección: {signature}",
            f"Categoría: {category or 'sin categoría'}",
            f"Severidad: {severity}",
            f"Flujo: {src_ip} → {dst_ip}:{dst_port or '—'}",
            f"Política aplicada: "
            f"{getattr(policy, 'name', 'DNS avanzado')} "
            f"({self._action_label(action)})",
        ]

        if sid:

            lines.append(f"Regla/SID: {sid}")

        if getattr(policy, "description", ""):

            lines.append(f"Motivo: {policy.description}")

        if reason:

            lines.append(f"Acción automática no aplicada: {reason}")

        lines.append(
            "Acción recomendada: revisar el equipo y el flujo antes de "
            "aislarlo o liberar la IP."
        )

        return "\n".join(lines)

    def _raise_policy_alert(
        self,
        db,
        *,
        signature,
        category,
        sid,
        severity,
        src_ip,
        dst_ip,
        dst_port,
        policy,
        action,
        reason=None,
    ):

        message = self._policy_message(
            signature=signature,
            category=category,
            sid=sid,
            severity=severity,
            src_ip=src_ip,
            dst_ip=dst_ip,
            dst_port=dst_port,
            policy=policy,
            action=action,
            reason=reason,
        )

        self.alert_service.create(
            db,
            alert_type="IPS_POLICY_ALERT",
            severity=severity if severity in ("critical", "warning") else "warning",
            title=f"IPS: {signature}"[:255],
            message=message[:2000],
        )

    def _quarantine_device(
        self,
        db,
        device,
        src_ip: str,
        signature: str,
        *,
        category: str = "",
        policy=None,
        dst_ip: str = "",
        dst_port=None,
        sid=None,
        source_label="IPS",
    ):

        try:

            result = self.provider.block_mac(device.mac_address)

            if not result.get("success"):

                logger.warning(
                    "Cuarentena fallo: %s (%s): %s",
                    device.mac_address,
                    src_ip,
                    result.get("stderr")
                )

                return False

            device.blocked = True

            self.device_repo.update(db, device)

            name = device.display_name or device.hostname or src_ip

            title = f"CUARENTENA: {name} aislado por {source_label}"

            message = self._policy_message(
                signature=signature,
                category=category,
                sid=sid,
                severity="critical",
                src_ip=src_ip,
                dst_ip=dst_ip,
                dst_port=dst_port,
                policy=policy,
                action=(policy.action if policy else "quarantine"),
            ) + (
                "\nAcción ejecutada: equipo aislado por MAC. "
                "Revisar y desaislar desde Cuarentena cuando sea seguro."
            )

            self.alert_service.create(
                db,
                alert_type="quarantine",
                severity="critical",
                title=title,
                message=message[:2000]
            )

            try:

                self.audit_service.create_log(
                    db,
                    None,
                    "QUARANTINE",
                    "device",
                    message,
                )

            except Exception as error:

                logger.warning(
                    "Auditoria de cuarentena fallo: %s",
                    error,
                )

            self._notify_quarantine(
                db,
                title,
                message,
                device_name=name,
                ip=src_ip,
                mac=device.mac_address or "",
                signature=signature,
            )

            return True

        except Exception as error:

            db.rollback()

            logger.exception(
                "Error en cuarentena de %s: %s",
                src_ip,
                error,
            )

            return False

    def _notify_quarantine(
        self,
        db,
        title: str,
        message: str,
        *,
        device_name: str = "",
        ip: str = "",
        mac: str = "",
        signature: str = "",
    ):

        try:

            self.quarantine_email.send(
                db,
                title,
                message,
                device_name=device_name,
                ip=ip,
                mac=mac,
                signature=signature,
            )

        except Exception as error:

            logger.error(
                "Fallo el correo de cuarentena: %s",
                error,
            )


    def list_quarantined(
        self,
        db,
    ) -> dict:

        from backend.network.devices.models.network_device import (
            NetworkDevice,
        )

        devices = (
            db.query(NetworkDevice)
            .filter(NetworkDevice.blocked.is_(True))
            .order_by(NetworkDevice.id.asc())
            .all()
        )

        items = []

        for device in devices:

            last_event = (
                db.query(MalwareEvent)
                .filter(
                    MalwareEvent.device_id == device.id,
                    MalwareEvent.quarantined.is_(True),
                )
                .order_by(MalwareEvent.id.desc())
                .first()
            )

            if last_event is None and device.mac_address:

                last_event = (
                    db.query(MalwareEvent)
                    .filter(
                        MalwareEvent.src_mac == device.mac_address,
                        MalwareEvent.quarantined.is_(True),
                    )
                    .order_by(MalwareEvent.id.desc())
                    .first()
                )

            items.append({
                "id": device.id,
                "hostname": device.hostname,
                "display_name": device.display_name,
                "name": (
                    device.display_name
                    or device.hostname
                    or device.ip_address
                    or device.mac_address
                ),
                "ip_address": device.ip_address,
                "mac_address": device.mac_address,
                "status": device.status,
                "quarantined_at": (
                    to_iso_utc(last_event.created_at)
                    if last_event else None
                ),
                "signature": last_event.signature if last_event else None,
                "category": last_event.category if last_event else None,
                "dst_ip": last_event.dst_ip if last_event else None,
            })

        return {
            "count": len(items),
            "devices": items,
        }


    def release_quarantine(
        self,
        db,
        device_id: int,
        actor: str | None = None,
    ) -> dict:

        device = self.device_repo.find_by_id(db, device_id)

        if device is None:

            return {
                "success": False,
                "message": "Dispositivo no encontrado",
            }

        if not device.mac_address:

            return {
                "success": False,
                "message": "El dispositivo no tiene MAC",
            }

        result = self.provider.unblock_mac(device.mac_address)

        if not result.get("success"):

            logger.warning(
                "Desaislamiento nft (puede estar ya libre): %s",
                result,
            )

        device.blocked = False

        self.device_repo.update(db, device)

        name = device.display_name or device.hostname or device.ip_address

        message = (
            f"Equipo {name} ({device.ip_address or 'sin IP'}, "
            f"{device.mac_address}) desaislado"
            + (f" por {actor}" if actor else "")
            + "."
        )

        try:

            self.audit_service.create_log(
                db,
                None,
                "UNQUARANTINE",
                "device",
                message,
            )

        except Exception as error:

            logger.warning("Auditoria de desaislamiento fallo: %s", error)

        self.alert_service.create(
            db,
            alert_type="quarantine_release",
            severity="info",
            title=f"Desaislado: {name}",
            message=message,
        )

        return {
            "success": True,
            "message": message,
            "device": name,
            "id": device.id,
        }


    def _block_c2_ip(
        self,
        db,
        ip: str,
        signature: str
    ):

        try:

            self._ensure_chain()

            self._add_c2_rule(ip)

            title = f"BLOQUEO C2: {ip} en lista de bloqueo"

            message = (
                f"IP {ip} bloqueada automaticamente por actividad "
                f"de malware/controlador: {signature}."
            )

            self.alert_service.create(
                db,
                alert_type="c2_block",
                severity="warning",
                title=title,
                message=message
            )

            try:

                self.audit_service.create_log(
                    db,
                    None,
                    "C2_BLOCK",
                    "network",
                    message
                )

            except Exception as error:

                logger.warning("Auditoria de bloqueo C2 fallo: %s", error)

            self._notify_critical(title, message)

            return True

        except Exception as error:

            db.rollback()

            logger.exception(
                "Error al bloquear C2 %s: %s",
                ip,
                error
            )

            return False


    def _notify_critical(
        self,
        title: str,
        message: str
    ):

        try:

            db = SessionLocal()

            try:

                self.critical_alert_email.send(
                    db,
                    title,
                    message,
                    html_body=f"<h3>{title}</h3><pre>{message}</pre>",
                )

            finally:

                db.close()

        except Exception as error:

            logger.error(
                "Fallo la notificacion critica: %s",
                error
            )


    # ------------------------------------------------------------------
    # Cortafuegos: cadena de bloqueo C2
    # ------------------------------------------------------------------

    def _run(self, args):

        result = subprocess.run(
            ["/usr/sbin/nft", *args], timeout=30,
            capture_output=True,
            text=True
        )

        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip()
        }


    def _ensure_chain(self):

        self._run(["add", "table", "inet", "stepad"])

        self._run([
            "add", "set", "inet", "stepad", "stepad_wan_ifaces",
            "{", "type", "ifname", ";", "}"
        ])

        self._run([
            "add", "chain", "inet", "stepad", "c2-block"
        ])

        result = self._run([
            "list", "chain", "inet", "stepad", "forward"
        ])

        if "jump c2-block" not in result["stdout"]:

            self._run([
                "add", "rule", "inet", "stepad", "forward",
                "jump", "c2-block"
            ])


    def _flush(self):

        self._run([
            "flush", "chain", "inet", "stepad", "c2-block"
        ])


    def _populate_wan_set(self, wan_interfaces: list[str]):

        self._run([
            "flush", "set", "inet", "stepad", "stepad_wan_ifaces"
        ])

        if not wan_interfaces:

            return

        elements = ", ".join(wan_interfaces)

        self._run([
            "add", "element", "inet", "stepad", "stepad_wan_ifaces",
            "{", elements, "}"
        ])


    def _add_c2_rule(self, ip):

        result = self._run([
            "list", "chain", "inet", "stepad", "c2-block"
        ])

        if f"{ip} drop" in result["stdout"]:

            return

        if ":" in ip:

            self._run([
                "add", "rule", "inet", "stepad", "c2-block",
                "iifname", "!=", "@stepad_wan_ifaces",
                "ip6", "daddr", ip, "drop"
            ])

        else:

            self._run([
                "add", "rule", "inet", "stepad", "c2-block",
                "iifname", "!=", "@stepad_wan_ifaces",
                "ip", "daddr", ip, "drop"
            ])


    def sync_c2_rules(
        self,
        db=None
    ):

        try:

            own_db = db is None

            if own_db:

                db = SessionLocal()

            try:

                self._ensure_chain()

                from backend.network.interfaces.services.interface_service import (
                    InterfaceService,
                )

                wan_names = [
                    interface.name
                    for interface in InterfaceService().get_wan_interfaces()
                ]

                self._populate_wan_set(wan_names)

                self._flush()

                ips = self.repo.find_blocked_c2_ips(db)

                for ip in ips:

                    self._add_c2_rule(ip)

                return {"synced": len(ips)}

            finally:

                if own_db:

                    db.close()

        except Exception as error:

            logger.exception("Sync de bloqueo C2 fallo: %s", error)

            return {"synced": 0, "error": str(error)}


    def resync_if_stale(self, stale_after=300.0):

        import time

        now = time.time()

        if now - self._last_resync < stale_after:

            return

        self._last_resync = now

        self.sync_c2_rules()

        try:

            from backend.ips.services.attack_response_service import (
                attack_response_service,
            )

            attack_response_service.sync()

        except Exception as error:

            logger.warning(
                "Sync de bloqueo de atacantes fallo: %s",
                error,
            )


    # ------------------------------------------------------------------
    # Consulta de eventos
    # ------------------------------------------------------------------

    def list_malware_events(
        self,
        db,
        limit: int = 10,
        device: str | None = None,
    ):

        rows = self.repo.find_recent(db, limit, device)

        from datetime import timezone

        return [
            {
                "id": row.id,
                "src_ip": row.src_ip,
                "src_mac": row.src_mac,
                "device_id": row.device_id,
                "device_name": row.device_name,
                "dst_ip": row.dst_ip,
                "dst_port": row.dst_port,
                "signature": row.signature,
                "category": row.category,
                "severity": row.severity,
                "quarantined": row.quarantined,
                "c2_blocked": row.c2_blocked,
                "action": getattr(row, "action", None),
                "policy_name": getattr(row, "policy_name", None),
                "created_at": row.created_at.replace(
                    tzinfo=timezone.utc
                ).isoformat(),
            }
            for row in rows
        ]


threat_response_service = ThreatResponseService()
