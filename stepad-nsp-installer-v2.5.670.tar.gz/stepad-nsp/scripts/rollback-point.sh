#!/bin/bash
#
# Save a rollback point BEFORE an update: the current code tree (without
# .venv/.git/node_modules) plus a plain SQL dump of the database.
# Non-blocking: if the DB dump fails, the code snapshot is still kept and
# the rollback will refuse to run without a database unless overridden.
#
set -uo pipefail

APP_DIR="${STEPAD_APP_DIR:-/home/paulan/stepad-nsp}"
RB_DIR="${STEPAD_ROLLBACK_DIR:-/var/lib/stepad/rollback}"
KEEP="${STEPAD_ROLLBACK_KEEP:-3}"

if [ "$(id -u)" -ne 0 ]; then
    echo "    AVISO: rollback point requiere root; se omite."
    exit 0
fi

if [ ! -d "${APP_DIR}/backend" ]; then
    echo "    AVISO: no hay instalación en ${APP_DIR}; se omite el punto de retorno."
    exit 0
fi

mkdir -p "${RB_DIR}"
chmod 0700 "${RB_DIR}"

VER="$(cat /etc/stepad/version 2>/dev/null || true)"
if [ -z "${VER}" ]; then
    VER="$(cat "${APP_DIR}/VERSION" 2>/dev/null || true)"
fi
VER="${VER:-unknown}"
TS="$(date +%Y%m%d-%H%M%S)"
BASE="${RB_DIR}/${VER}-${TS}"

echo "==> Punto de retorno: ${VER} (${TS})"

if tar czf "${BASE}.app.tar.gz" -C "${APP_DIR}" \
    --exclude=.venv --exclude=.git --exclude=node_modules \
    --exclude=__pycache__ --exclude=.pytest_cache \
    --exclude='*.pyc' . 2>/dev/null; then
    echo "    Código guardado: ${BASE}.app.tar.gz"
else
    echo "    AVISO: no se pudo guardar el código; no habrá rollback."
    rm -f "${BASE}.app.tar.gz"
    exit 0
fi

echo "${VER}" > "${BASE}.version"
date -Is > "${BASE}.meta"

if [ -r /etc/stepad/stepad.env ]; then
    set -a
    # shellcheck disable=SC1091
    . /etc/stepad/stepad.env
    set +a
fi

if [ -n "${DB_NAME:-}" ] && command -v pg_dump >/dev/null 2>&1; then
    if PGPASSWORD="${DB_PASSWORD:-}" pg_dump \
        -h "${DB_HOST:-127.0.0.1}" \
        -p "${DB_PORT:-5432}" \
        -U "${DB_USER:-stepad_nsp}" \
        --no-owner --no-privileges \
        "${DB_NAME}" 2>/dev/null | gzip -c > "${BASE}.db.sql.gz"; then
        echo "    Base de datos guardada: ${BASE}.db.sql.gz"
    else
        rm -f "${BASE}.db.sql.gz"
        echo "    AVISO: no se pudo volcar la base; el rollback pedirá confirmación."
    fi
else
    echo "    AVISO: sin datos de BD; el rollback pedirá confirmación."
fi

# Keep only the newest N complete points (app + sidecars).
ls -1t "${RB_DIR}"/*.app.tar.gz 2>/dev/null | tail -n +$((KEEP + 1)) | \
while read -r file; do
    stem="${file%.app.tar.gz}"
    rm -f "${file}" "${stem}.db.sql.gz" "${stem}.version" "${stem}.meta"
done

echo "    Puntos conservados: $(ls -1 "${RB_DIR}"/*.app.tar.gz 2>/dev/null | wc -l)"
