#!/bin/bash
# Local last-good PostgreSQL dump used by the boot guard.
set -u

ENV_FILE="${STEPAD_ENV_FILE:-/etc/stepad/stepad.env}"
DIR="${STEPAD_DB_SNAPSHOT_DIR:-/var/lib/stepad/db-snapshots}"
KEEP="${STEPAD_DB_SNAPSHOT_KEEP:-7}"
LOCK="${STEPAD_DB_SNAPSHOT_LOCK:-/run/stepad-db-snapshot.lock}"

mkdir -p "$DIR" "$(dirname "$LOCK")" 2>/dev/null || true
chmod 0700 "$DIR" 2>/dev/null || true

exec 9>"$LOCK" || exit 1
flock -n 9 || exit 0

if [ ! -r "$ENV_FILE" ]; then
    logger -t stepad-db-snapshot "No se puede leer $ENV_FILE"
    exit 1
fi

set -a
# shellcheck disable=SC1090
. "$ENV_FILE" >/dev/null 2>&1
set +a

DB_NAME="${DB_NAME:-stepad_nsp}"
DB_USER="${DB_USER:-stepad_nsp}"
DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5432}"

if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" >/dev/null 2>&1; then
    logger -t stepad-db-snapshot "PostgreSQL no responde"
    exit 1
fi

tmp="$(mktemp "${DIR}/.stepad-db.XXXXXX")" || exit 1
target="${DIR}/stepad-$(date +%Y%m%d-%H%M%S).sql.gz"

if ! PGPASSWORD="${DB_PASSWORD:-}" pg_dump \
    -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" \
    --no-owner --no-privileges "$DB_NAME" \
    | gzip -c > "$tmp"; then
    rm -f "$tmp"
    logger -t stepad-db-snapshot "pg_dump falló"
    exit 1
fi

if ! gzip -t "$tmp" >/dev/null 2>&1; then
    rm -f "$tmp"
    logger -t stepad-db-snapshot "gzip inválido"
    exit 1
fi

chmod 0600 "$tmp" 2>/dev/null || true
mv -f "$tmp" "$target" || exit 1

# Solo se conservan los dumps completos más nuevos.
ls -1t "$DIR"/stepad-*.sql.gz 2>/dev/null | tail -n +$((KEEP + 1)) | \
while read -r old; do
    rm -f "$old"
done

logger -t stepad-db-snapshot "Snapshot creado: $(basename "$target")"
exit 0
