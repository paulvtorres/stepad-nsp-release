#!/usr/bin/env bash
# Laboratorio de integracion de STEPAD NSP.
#
#   1. Suite unitaria (sqlite).
#   2. Pruebas contra PostgreSQL REAL con el esquema de las MIGRACIONES.
#   3. Pruebas con dnsmasq y dhclient REALES en espacios de red.
#
# Requisitos (Debian/Ubuntu):
#   apt install iproute2 dnsmasq isc-dhcp-client iputils-ping postgresql
# Ejecutar como root:   sudo -E scripts/integration-lab.sh
# Variables:
#   STEPAD_LAB_PG_PORT   puerto del PostgreSQL temporal (por defecto 5433)
#   STEPAD_LAB_SKIP_PG=1 omite el paso de PostgreSQL
set -uo pipefail

cd "$(dirname "$0")/.."

export STEPAD_ENV=development
PORT="${STEPAD_LAB_PG_PORT:-5433}"
FAILED=0
PGDIR=""

step() { printf '\n\033[1m== %s\033[0m\n' "$1"; }

cleanup() {
    if [ -n "$PGDIR" ]; then
        su postgres -c "$PGBIN/pg_ctl -D $PGDIR/data -m immediate stop" >/dev/null 2>&1 || true
        rm -rf "$PGDIR"
    fi
}
trap cleanup EXIT

step "1/3 Suite unitaria (sqlite)"
python3 -m pytest backend/tests -m "not integration" -q -p no:cacheprovider || FAILED=1

if [ "${STEPAD_LAB_SKIP_PG:-0}" != "1" ]; then
    PGBIN="$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | sort -V | tail -1)"
    if [ -z "$PGBIN" ] || [ "$(id -u)" != "0" ]; then
        step "2/3 PostgreSQL: OMITIDO (falta postgresql o no eres root)"
    else
        step "2/3 PostgreSQL real: migraciones + pruebas"
        PGDIR="$(mktemp -d)"
        chown postgres:postgres "$PGDIR"
        su postgres -c "$PGBIN/initdb -D $PGDIR/data -A trust -U postgres" >/dev/null
        su postgres -c "$PGBIN/pg_ctl -D $PGDIR/data -o '-p $PORT -k $PGDIR -c listen_addresses=127.0.0.1' -l $PGDIR/log -w start" >/dev/null
        psql -h 127.0.0.1 -p "$PORT" -U postgres -qc "CREATE USER stepad WITH PASSWORD 'lab' SUPERUSER;"
        psql -h 127.0.0.1 -p "$PORT" -U postgres -qc "CREATE DATABASE stepad_lab OWNER stepad;"

        export DB_HOST=127.0.0.1 DB_PORT="$PORT" DB_NAME=stepad_lab DB_USER=stepad DB_PASSWORD=lab
        echo "-- alembic upgrade head (desde cero)"
        python3 -m alembic upgrade head >/dev/null 2>&1 || { echo "FALLO: alembic upgrade head"; FAILED=1; }
        echo "-- revision: $(python3 -m alembic current 2>/dev/null | tail -1)"
        echo "-- alembic check (modelos == migraciones)"
        if ! python3 -m alembic check >"$PGDIR/check.txt" 2>&1; then
            echo "FALLO: hay deriva entre los modelos y las migraciones:"
            grep "Detected" "$PGDIR/check.txt" | grep -v "Detected sequence" | head -20
            FAILED=1
        fi

        export STEPAD_TEST_DB_URL="postgresql+psycopg2://stepad:lab@127.0.0.1:$PORT/stepad_lab"
        python3 -m pytest -q -p no:cacheprovider -m "not integration" \
            backend/tests/test_device_presence_service.py backend/tests/test_dhcp_events.py \
            backend/tests/test_threat_response_owner.py backend/tests/test_alert_pipeline_hardening.py \
            backend/tests/test_dhcp_alert_resolution.py backend/tests/test_ipam_service.py || FAILED=1
        unset STEPAD_TEST_DB_URL
    fi
fi

step "3/3 dnsmasq y dhclient reales (espacios de red)"
python3 -m pytest backend/tests/integration -v -p no:cacheprovider || FAILED=1

if [ "$FAILED" = "0" ]; then
    printf '\n\033[32mLaboratorio: TODO OK\033[0m\n'
else
    printf '\n\033[31mLaboratorio: HAY FALLOS\033[0m\n'
fi
exit "$FAILED"
