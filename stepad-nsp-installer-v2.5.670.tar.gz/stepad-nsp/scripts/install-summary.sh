#!/bin/bash
#
# Final install/update summary: verify that the NSP actually came up and
# print a short recap. Exits non-zero when a critical piece is down, so
# silent failures surface immediately instead of days later.
#
set -uo pipefail

APP_USER="${APP_USER:-paulan}"
APP_DIR="${STEPAD_APP_DIR:-/home/${APP_USER}/stepad-nsp}"
HEALTH_URL="${STEPAD_HEALTH_URL:-https://127.0.0.1:8443/healthz}"

fail=0

ok()   { echo "  [OK]    $*"; }
warn() { echo "  [AVISO] $*"; }
bad()  { echo "  [FALLO] $*"; fail=1; }

service_state() {
    systemctl is-active --quiet "$1" && echo active || echo inactive
}

echo
echo "======================================================"
echo "  RESUMEN DE ESTADO"
echo "======================================================"

VERSION="$(cat /etc/stepad/version 2>/dev/null || true)"
echo "  Versión instalada: ${VERSION:-desconocida}"

# Critical: the application itself.
if [ "$(service_state stepad-nsp)" = "active" ]; then
    ok "Servicio NSP activo"
else
    bad "Servicio NSP NO activo"
    systemctl --no-pager -n 8 status stepad-nsp 2>/dev/null || true
fi

# Critical: database (local installs).
if [ "$(service_state postgresql)" = "active" ]; then
    ok "PostgreSQL activo"
else
    warn "PostgreSQL no activo (¿base externa?)"
fi

# Supporting services: report, but do not fail the update. dnsmasq is
# spawned by the NSP with its own config (the distro unit is masked), so
# check the process as well as the unit.
process_running() {
    pgrep -x "$1" >/dev/null 2>&1
}
if [ "$(service_state dnsmasq)" = "active" ] || process_running dnsmasq; then
    ok "DNS/DHCP (dnsmasq) activo"
else
    warn "DNS/DHCP (dnsmasq) no está corriendo"
fi
if [ "$(service_state pdns-recursor)" = "active" ] || process_running pdns_recursor; then
    ok "DNS recursivo (pdns) activo"
else
    warn "DNS recursivo (pdns) no activo"
fi
for pair in "IPS (suricata):suricata" "Tailscale:tailscaled"; do
    name="${pair%%:*}"
    unit="${pair##*:}"
    if [ "$(service_state "${unit}")" = "active" ]; then
        ok "${name} activo"
    else
        warn "${name} no activo (${unit})"
    fi
done

# Web/API health: allow startup time, then require a healthy answer.
health=""
for _ in $(seq 1 90); do
    health="$(curl -sk --max-time 3 "${HEALTH_URL}" 2>/dev/null || true)"
    case "${health}" in
        *'"status":"ok"'*) break ;;
    esac
    sleep 2
done
case "${health}" in
    *'"status":"ok"'*) ok "Web/API responde: ${HEALTH_URL}" ;;
    *)
        bad "Web/API NO responde en ${HEALTH_URL}"
        echo "         Última respuesta: ${health:-<vacía>}"
        ;;
esac

# Database connectivity through the app credentials.
if [ -r /etc/stepad/stepad.env ]; then
    set -a
    # shellcheck disable=SC1091
    . /etc/stepad/stepad.env
    set +a
fi
if command -v psql >/dev/null 2>&1 && [ -n "${DB_NAME:-}" ]; then
    if PGPASSWORD="${DB_PASSWORD:-}" psql -h "${DB_HOST:-127.0.0.1}" \
        -p "${DB_PORT:-5432}" -U "${DB_USER:-stepad_nsp}" \
        -d "${DB_NAME}" -tAc "SELECT 1" >/dev/null 2>&1; then
        ok "Base de datos accesible (${DB_NAME})"
    else
        bad "No se pudo consultar la base de datos (${DB_NAME})"
    fi
fi

# Disk headroom (the OS disk, where the app/logs live).
free_pct="$(df -P / | awk 'NR==2 {gsub("%","",$5); print 100-$5}')"
if [ -n "${free_pct}" ] && [ "${free_pct}" -lt 5 ] 2>/dev/null; then
    warn "Poco espacio libre en / (${free_pct}%)"
elif [ -n "${free_pct}" ]; then
    ok "Espacio libre en /: ${free_pct}%"
fi

echo "------------------------------------------------------"
if [ "${fail}" -eq 0 ]; then
    echo "  RESULTADO: OK — el NSP quedó operativo."
else
    echo "  RESULTADO: CON FALLOS — revisa los mensajes [FALLO]."
    echo "  Logs: journalctl -u stepad-nsp -n 100 --no-pager"
fi
echo "======================================================"

exit "${fail}"
