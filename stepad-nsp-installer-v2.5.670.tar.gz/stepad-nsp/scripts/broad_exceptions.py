#!/usr/bin/env python3
"""Ratchet against broad `except Exception` blocks.

Counts occurrences in backend/ and compares with
scripts/broad_exceptions.baseline. Fails CI when the count grows, so new
code must catch specific exceptions instead of swallowing everything.

    python scripts/broad_exceptions.py            # check
    python scripts/broad_exceptions.py --update   # accept the current count
"""

import re
import sys

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BASELINE = ROOT / "scripts" / "broad_exceptions.baseline"
PATTERN = re.compile(r"except\s+Exception\b")


def count() -> int:

    total = 0

    for path in (ROOT / "backend").rglob("*.py"):

        total += len(PATTERN.findall(path.read_text("utf-8")))

    return total


def main() -> int:

    current = count()

    if "--update" in sys.argv:

        BASELINE.write_text(f"{current}\n", "utf-8")

        print(f"baseline actualizada: {current}")

        return 0

    try:

        allowed = int(BASELINE.read_text("utf-8").strip())

    except (OSError, ValueError):

        allowed = current

    print(f"except Exception: {current} (límite {allowed})")

    if current > allowed:

        print("ERROR: aumentó el número de capturas genéricas.")

        print("Captura errores concretos (OSError, ValueError, SQLAlchemyError...).")

        return 1

    return 0


if __name__ == "__main__":

    raise SystemExit(main())
