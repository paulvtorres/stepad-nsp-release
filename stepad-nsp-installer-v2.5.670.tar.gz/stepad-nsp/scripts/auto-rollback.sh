#!/bin/bash
# Restore the pre-update code tree and DB after a failed update.
# Only invoked with a rollback point captured before extraction.
set -uo pipefail

APP_USER="${APP_USER:-paulan}"
APP_DIR="${STEPAD_APP_DIR:-/home/${APP_USER}/stepad-nsp}"
POINT="${1:-}"
HEALTH_URL="${STEPAD_HEALTH_URL:-https://127.0.0.1:8443/healthz}"

if [ -z "${POINT}" ] || [ ! -f "${POINT}" ]; then
    echo "AUTO-ROLLBACK: punto de retorno inválido: ${POINT:-<vacío>}"
    exit 1
fi

if [ "${STEPAD_AUTO_ROLLBACK_DRY_RUN:-0}" = "1" ]; then
    echo "AUTO-ROLLBACK dry-run: punto=${POINT} app_dir=${APP_DIR}"
    exit 0
fi

stem="${POINT%.app.tar.gz}"
db="${stem}.db.sql.gz"
version="$(cat "${stem}.version" 2>/dev/null || echo '?')"

echo "AUTO-ROLLBACK: restaurando ${version} desde $(basename "${POINT}")"
systemctl stop stepad-nsp 2>/dev/null || true

mkdir -p "/var/lib/stepad/rollback"
safety="/var/lib/stepad/rollback/pre-auto-rollback-$(date +%Y%m%d-%H%M%S).tar.gz"
if [ -d "${APP_DIR}/backend" ]; then
    tar czf "${safety}" -C "${APP_DIR}" \
        --exclude=.venv --exclude=.git --exclude=node_modules \
        --exclude=__pycache__ --exclude=.pytest_cache . 2>/dev/null || true
fi

rm -rf "${APP_DIR}/backend" "${APP_DIR}/frontend" "${APP_DIR}/scripts" \
    "${APP_DIR}/docs" "${APP_DIR}/install.sh" "${APP_DIR}/install.py" \
    "${APP_DIR}/requirements.txt" "${APP_DIR}/VERSION" \
    "${APP_DIR}/alembic.ini" "${APP_DIR}/stepad-nsp.service" 2>/dev/null || true

if ! tar xzf "${POINT}" -C "${APP_DIR}"; then
    echo "AUTO-ROLLBACK: no se pudo restaurar el código."
    exit 1
fi
chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}" 2>/dev/null || true
cp -f "${stem}.version" /etc/stepad/version 2>/dev/null || true

if [ -f "${db}" ]; then
    if [ -r /etc/stepad/stepad.env ]; then
        set -a
        # shellcheck disable=SC1091
        . /etc/stepad/stepad.env
        set +a
    fi
    db_name="${DB_NAME:-stepad_nsp}"
    db_user="${DB_USER:-stepad_nsp}"
    if command -v runuser >/dev/null 2>&1 && runuser -u postgres -- true >/dev/null 2>&1; then
        runuser -u postgres -- dropdb --if-exists "${db_name}" || true
        runuser -u postgres -- createdb -O "${db_user}" "${db_name}" || exit 1
        if ! gunzip -c "${db}" | PGPASSWORD="${DB_PASSWORD:-}" psql \
            -h 127.0.0.1 -p "${DB_PORT:-5432}" -U "${db_user}" \
            -q -v ON_ERROR_STOP=1 -d "${db_name}" >/dev/null; then
            echo "AUTO-ROLLBACK: falló la restauración de la base."
            exit 1
        fi
    fi
fi

systemctl restart stepad-nsp 2>/dev/null || true
for _ in $(seq 1 90); do
    if curl -sk --max-time 3 "${HEALTH_URL}" 2>/dev/null | grep -q '"status":"ok"'; then
        echo "AUTO-ROLLBACK: recuperado y healthy."
        exit 0
    fi
    sleep 2
done

echo "AUTO-ROLLBACK: la versión anterior no quedó healthy."
exit 1
