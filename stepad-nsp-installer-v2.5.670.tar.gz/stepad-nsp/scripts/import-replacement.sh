#!/bin/bash
#
# Import a replacement bundle created by the NSP ("Reemplazo de equipo").
# Run on the NEW machine, after installing the base NSP:
#
#   sudo bash scripts/import-replacement.sh /ruta/stepad-replacement-....enc
#   sudo bash scripts/import-replacement.sh --dry-run paquete.enc
#
set -uo pipefail

APP_USER="${APP_USER:-paulan}"
APP_DIR="${STEPAD_APP_DIR:-/home/${APP_USER}/stepad-nsp}"
RB_DIR="${STEPAD_ROLLBACK_DIR:-/var/lib/stepad/rollback}"
HEALTH_URL="${STEPAD_HEALTH_URL:-https://127.0.0.1:8443/healthz}"

DRY_RUN=0
if [ "${1:-}" = "--dry-run" ]; then
    DRY_RUN=1
    shift
fi
BUNDLE="${1:-}"

if [ -z "${BUNDLE}" ] || [ ! -f "${BUNDLE}" ]; then
    echo "Uso: sudo bash $0 [--dry-run] <paquete.enc>" >&2
    exit 1
fi
if [ "$(id -u)" -ne 0 ]; then
    echo "Ejecuta como root (sudo)." >&2
    exit 1
fi

read -r -s -p "Frase de seguridad del paquete: " PASSPHRASE
echo
if [ -z "${PASSPHRASE}" ]; then
    echo "ERROR: frase vacía." >&2
    exit 1
fi

WORK="$(mktemp -d /tmp/stepad-import.XXXXXX)"
chmod 0700 "${WORK}"
cleanup() { rm -rf "${WORK}"; }
trap cleanup EXIT

echo "==> Descifrando paquete..."
if ! printf '%s\n' "${PASSPHRASE}" | openssl enc -d -aes-256-cbc -pbkdf2 \
        -in "${BUNDLE}" -out "${WORK}/bundle.tar.gz" -pass stdin 2>/dev/null; then
    echo "ERROR: no se pudo descifrar (frase incorrecta o archivo dañado)." >&2
    exit 1
fi

echo "==> Validando contenido..."
if ! tar -tzf "${WORK}/bundle.tar.gz" | grep -qE '(^|/)manifest\.json$'; then
    echo "ERROR: el paquete no tiene manifest.json." >&2
    exit 1
fi
if tar -tzf "${WORK}/bundle.tar.gz" | grep -qE '(^|/)\.\.(/|$)'; then
    echo "ERROR: el paquete contiene rutas no seguras." >&2
    exit 1
fi
tar xzf "${WORK}/bundle.tar.gz" -C "${WORK}"

for required in manifest.json database.sql.gz etc/stepad.env; do
    if [ ! -f "${WORK}/${required}" ]; then
        echo "ERROR: falta ${required} en el paquete." >&2
        exit 1
    fi
done

python3 - "${WORK}/manifest.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1], encoding="utf-8"))
print("  Origen:   ", data.get("hostname"))
print("  Versión:  ", data.get("version"))
print("  Creado:   ", data.get("created_at"))
print("  Base:     ", data.get("database"))
print("  Archivos: ", ", ".join(sorted((data.get("files") or {}).keys())))
PY

if [ "${DRY_RUN}" = "1" ]; then
    echo "==> DRY-RUN: paquete válido. No se modificó nada."
    exit 0
fi

echo
echo "ATENCIÓN: esto REEMPLAZA la base de datos y la configuración de este equipo."
read -r -p "Escribe REEMPLAZAR para continuar: " CONFIRM
if [ "${CONFIRM}" != "REEMPLAZAR" ]; then
    echo "Cancelado."
    exit 1
fi

# Save the current state (best effort) before touching anything.
TS="$(date +%Y%m%d-%H%M%S)"
SAFE="${RB_DIR}/pre-replacement-${TS}"
mkdir -p "${SAFE}"
chmod 0700 "${SAFE}"
if [ -r /etc/stepad/stepad.env ]; then
    cp -a /etc/stepad/stepad.env "${SAFE}/stepad.env"
fi
if [ -r /etc/stepad/config.yaml ]; then
    cp -a /etc/stepad/config.yaml "${SAFE}/config.yaml"
fi
echo "==> Estado actual guardado en ${SAFE}"

set -a
. "${WORK}/etc/stepad.env"
set +a

echo "==> Deteniendo servicio..."
systemctl stop stepad-nsp 2>/dev/null || true

echo "==> Restaurando secretos y configuración..."
install -m 0600 -o root -g root "${WORK}/etc/stepad.env" /etc/stepad/stepad.env
if [ -f "${WORK}/etc/config.yaml" ]; then
    install -m 0640 -o "${APP_USER}" -g "${APP_USER}" \
        "${WORK}/etc/config.yaml" /etc/stepad/config.yaml
fi

echo "==> Restaurando base de datos..."
DB_HOST="${DB_HOST:-127.0.0.1}"
DB_NAME="${DB_NAME:-stepad_nsp}"
DB_USER="${DB_USER:-stepad_app}"
LOCAL=0
case "${DB_HOST}" in ""|localhost|127.0.0.1|::1) LOCAL=1 ;; esac
if [ "${LOCAL}" = "1" ] && runuser -u postgres -- true >/dev/null 2>&1; then
    runuser -u postgres -- dropdb --if-exists "${DB_NAME}" || true
    runuser -u postgres -- createdb -O "${DB_USER}" "${DB_NAME}" || {
        echo "ERROR: no se pudo crear ${DB_NAME}." >&2; exit 1;
    }
    if ! gunzip -c "${WORK}/database.sql.gz" | PGPASSWORD="${DB_PASSWORD:-}" psql \
        -h 127.0.0.1 -p "${DB_PORT:-5432}" -U "${DB_USER}" \
        -q -v ON_ERROR_STOP=1 -d "${DB_NAME}" >/dev/null; then
        echo "ERROR: falló la restauración de la base." >&2
        exit 1
    fi
else
    export PGPASSWORD="${DB_PASSWORD:-}"
    psql -h "${DB_HOST}" -p "${DB_PORT:-5432}" -U "${DB_USER}" -d postgres \
        -v ON_ERROR_STOP=1 -c "DROP DATABASE IF EXISTS \"${DB_NAME}\";" || true
    psql -h "${DB_HOST}" -p "${DB_PORT:-5432}" -U "${DB_USER}" -d postgres \
        -v ON_ERROR_STOP=1 -c "CREATE DATABASE \"${DB_NAME}\";" || {
        echo "ERROR: no se pudo crear ${DB_NAME}." >&2; exit 1;
    }
    if ! gunzip -c "${WORK}/database.sql.gz" | psql \
        -h "${DB_HOST}" -p "${DB_PORT:-5432}" -U "${DB_USER}" \
        -q -v ON_ERROR_STOP=1 -d "${DB_NAME}" >/dev/null; then
        echo "ERROR: falló la restauración de la base." >&2
        exit 1
    fi
    unset PGPASSWORD
fi

echo "==> Aplicando migraciones..."
if ! "${APP_DIR}/.venv/bin/python3" -m backend.scripts.migrate_schema; then
    echo "ERROR: fallaron las migraciones. Servicio detenido." >&2
    exit 1
fi

echo "==> Reiniciando servicio..."
systemctl restart stepad-nsp || true
ok=0
for _ in $(seq 1 90); do
    if systemctl is-active --quiet stepad-nsp \
       && curl -sk --max-time 3 "${HEALTH_URL}" 2>/dev/null \
          | grep -q '"status":"ok"'; then
        ok=1
        break
    fi
    sleep 2
done

if [ "${ok}" = "1" ]; then
    echo "==> Importación completada: el NSP está operativo."
    echo "    Revisa Interfaces (MAC de la máquina nueva), usuarios y MFA."
    echo "    Estado previo guardado en ${SAFE}"
    exit 0
fi

echo "ERROR: el servicio no respondió /healthz tras 180 s." >&2
systemctl status stepad-nsp --no-pager -n 20 2>/dev/null || true
echo "El estado previo está en ${SAFE}" >&2
exit 1
