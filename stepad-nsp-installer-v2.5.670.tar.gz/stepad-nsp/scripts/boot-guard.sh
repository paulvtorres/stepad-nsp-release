#!/bin/bash
# STEPAD NSP boot guard.
#
# Runs before stepad-nsp.service. It validates critical runtime files,
# brings PostgreSQL up, and restores the newest verified local DB dump
# only when the database is genuinely unreadable. Healthy boots are
# read-only apart from refreshing the last-good copies.
set -u

APP_DIR="${STEPAD_APP_DIR:-/home/paulan/stepad-nsp}"
ENV_FILE="${STEPAD_ENV_FILE:-/etc/stepad/stepad.env}"
CONFIG_FILE="${STEPAD_CONFIG_FILE:-/etc/stepad/config.yaml}"
DNSMASQ_CONF="${STEPAD_DNSMASQ_CONF:-/etc/stepad/dns/dnsmasq.conf}"
LOG="${STEPAD_BOOT_GUARD_LOG:-/var/log/stepad/boot-guard.log}"
STATE="${STEPAD_BOOT_GUARD_STATE:-/var/lib/stepad/boot-guard-state.json}"
ALERT_CACHE="${STEPAD_EMERGENCY_ALERT_CACHE:-/etc/stepad/emergency-alert.json}"
ALERT_STAMP="${STEPAD_BOOT_GUARD_ALERT_STAMP:-/var/lib/stepad/boot-guard-alert.last}"
SNAPSHOT_DIRS="${STEPAD_DB_SNAPSHOT_DIRS:-/var/lib/stepad/db-snapshots /var/lib/stepad/rollback}"
DRY_RUN="${STEPAD_BOOT_GUARD_DRY_RUN:-0}"
AUTO_RESTORE="${STEPAD_AUTO_DB_RESTORE:-1}"

PYTHON="${APP_DIR}/.venv/bin/python3"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3 2>/dev/null || true)"

ACTIONS=""
EXTERNAL=0
RECOVERED=0

mkdir -p "$(dirname "$LOG")" "$(dirname "$STATE")" 2>/dev/null || true
chmod 0700 "$(dirname "$STATE")" 2>/dev/null || true

log() {
    local line
    line="$(date -Is) $*"
    printf '%s\n' "$line" >> "$LOG" 2>/dev/null || true
    logger -t stepad-boot-guard -- "$*" 2>/dev/null || true
}

add_action() {
    ACTIONS="${ACTIONS}${ACTIONS:+; }$1"
    log "$1"
}

write_state() {
    local status="$1"
    if [ "$DRY_RUN" = "1" ]; then
        return 0
    fi
    mkdir -p "$(dirname "$STATE")" 2>/dev/null || true
    printf '{"status":"%s","at":"%s","actions":"%s"}\n' \
        "$status" "$(date -Is)" "$(printf '%s' "$ACTIONS" | sed 's/"/\\"/g')" \
        > "$STATE" 2>/dev/null || true
    chmod 0600 "$STATE" 2>/dev/null || true
}

load_env() {
    if [ ! -r "$ENV_FILE" ]; then
        return 1
    fi
    set -a
    # shellcheck disable=SC1090
    . "$ENV_FILE" >/dev/null 2>&1
    set +a
    DB_NAME="${DB_NAME:-stepad_nsp}"
    DB_USER="${DB_USER:-stepad_nsp}"
    DB_HOST="${DB_HOST:-127.0.0.1}"
    DB_PORT="${DB_PORT:-5432}"
    return 0
}

validate_env_file() {
    bash -n "$ENV_FILE" >/dev/null 2>&1 || return 1
    (
        set -a
        # shellcheck disable=SC1090
        . "$ENV_FILE" >/dev/null 2>&1
        [ -n "${DB_NAME:-}" ] && [ -n "${DB_USER:-}" ]
    )
}

restore_latest_env() {
    local candidate=""
    local file
    for file in $(ls -1t /etc/stepad/env-backups/* /etc/stepad/stepad.env.bak* 2>/dev/null); do
        if [ -r "$file" ] && bash -n "$file" >/dev/null 2>&1; then
            candidate="$file"
            break
        fi
    done
    if [ -z "$candidate" ]; then
        return 1
    fi
    if [ "$DRY_RUN" = "1" ]; then
        add_action "DRY-RUN: restauraría env desde $(basename "$candidate")"
        return 0
    fi
    cp -p "$ENV_FILE" "${ENV_FILE}.pre-boot-guard-$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
    cp -p "$candidate" "$ENV_FILE" || return 1
    add_action "env restaurado desde $(basename "$candidate")"
    return 0
}

validate_config_yaml() {
    [ -r "$CONFIG_FILE" ] || return 1
    [ -n "$PYTHON" ] || return 1
    "$PYTHON" - "$CONFIG_FILE" >/dev/null 2>&1 <<'PY'
import sys
import yaml
with open(sys.argv[1], "r", encoding="utf-8") as fh:
    data = yaml.safe_load(fh)
if not isinstance(data, dict) or not data:
    raise SystemExit(1)
PY
}

restore_config_yaml() {
    local candidate="/etc/stepad/config.yaml.last-good"
    [ -r "$candidate" ] || return 1
    validate_candidate_config "$candidate" || return 1
    if [ "$DRY_RUN" = "1" ]; then
        add_action "DRY-RUN: restauraría config.yaml desde last-good"
        return 0
    fi
    cp -p "$CONFIG_FILE" "/etc/stepad/config.yaml.pre-boot-guard-$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
    cp -p "$candidate" "$CONFIG_FILE" || return 1
    add_action "config.yaml restaurado desde last-good"
    return 0
}

validate_candidate_config() {
    [ -r "$1" ] || return 1
    [ -n "$PYTHON" ] || return 1
    "$PYTHON" - "$1" >/dev/null 2>&1 <<'PY'
import sys
import yaml
with open(sys.argv[1], "r", encoding="utf-8") as fh:
    data = yaml.safe_load(fh)
if not isinstance(data, dict) or not data:
    raise SystemExit(1)
PY
}

validate_dnsmasq() {
    [ -r "$DNSMASQ_CONF" ] || return 0
    command -v dnsmasq >/dev/null 2>&1 || return 0
    dnsmasq --test --conf-file="$DNSMASQ_CONF" >/dev/null 2>&1
}

restore_dnsmasq() {
    local candidate="/etc/stepad/dns/dnsmasq.conf.last-good"
    [ -r "$candidate" ] || return 1
    command -v dnsmasq >/dev/null 2>&1 || return 1
    dnsmasq --test --conf-file="$candidate" >/dev/null 2>&1 || return 1
    if [ "$DRY_RUN" = "1" ]; then
        add_action "DRY-RUN: restauraría dnsmasq.conf desde last-good"
        return 0
    fi
    cp -p "$DNSMASQ_CONF" "/etc/stepad/dns/dnsmasq.conf.pre-boot-guard-$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
    cp -p "$candidate" "$DNSMASQ_CONF" || return 1
    add_action "dnsmasq.conf restaurado desde last-good"
    return 0
}

refresh_last_good() {
    [ "$DRY_RUN" = "1" ] && return 0
    if validate_config_yaml; then
        cp -p "$CONFIG_FILE" "/etc/stepad/config.yaml.last-good" 2>/dev/null || true
    fi
    if [ -r "$DNSMASQ_CONF" ] && validate_dnsmasq; then
        cp -p "$DNSMASQ_CONF" "/etc/stepad/dns/dnsmasq.conf.last-good" 2>/dev/null || true
    fi
    if [ -r "$ENV_FILE" ] && validate_env_file; then
        mkdir -p /etc/stepad/env-backups 2>/dev/null || true
        cp -p "$ENV_FILE" "/etc/stepad/env-backups/stepad.env.$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
        ls -1t /etc/stepad/env-backups/stepad.env.* 2>/dev/null | tail -n +11 | xargs -r rm -f 2>/dev/null || true
    fi
}

psql_cmd() {
    PGPASSWORD="${DB_PASSWORD:-}" PGCONNECT_TIMEOUT=5 \
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" "$@" 2>&1
}

db_ready() {
    pg_isready -h "$DB_HOST" -p "$DB_PORT" >/dev/null 2>&1
}

db_query() {
    [ -n "$DB_NAME" ] && [ -n "$DB_USER" ] || return 1
    local out
    out="$(psql_cmd -tAc 'SELECT 1' 2>&1)"
    [ "$(printf '%s' "$out" | tr -d '[:space:]')" = "1" ]
}

latest_db_backup() {
    local file
    file="$(
        find $SNAPSHOT_DIRS -maxdepth 1 -type f \
            \( -name '*.db.sql.gz' -o -name 'stepad-*.sql.gz' \) \
            -printf '%T@ %p\n' 2>/dev/null \
        | sort -nr | head -n1 | cut -d' ' -f2-
    )"
    [ -n "$file" ] && [ -r "$file" ] || return 1
    gzip -t "$file" >/dev/null 2>&1 || return 1
    printf '%s\n' "$file"
}

restore_database() {
    local backup="$1"
    local db_user_escaped role_exists
    [ "$AUTO_RESTORE" = "1" ] || return 1
    [ -n "$DB_NAME" ] && [ -n "$DB_USER" ] || return 1
    command -v runuser >/dev/null 2>&1 || return 1
    runuser -u postgres -- true >/dev/null 2>&1 || return 1

    if [ "$DRY_RUN" = "1" ]; then
        add_action "DRY-RUN: restauraría base desde $(basename "$backup")"
        return 0
    fi

    add_action "restaurando base desde $(basename "$backup")"
    systemctl stop stepad-nsp.service >/dev/null 2>&1 || true

    role_exists="$(runuser -u postgres -- psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER//\'/\'\'}'" 2>/dev/null || true)"
    if [ "$(printf '%s' "$role_exists" | tr -d '[:space:]')" != "1" ]; then
        db_user_escaped="${DB_USER//\'/\'\'}"
        runuser -u postgres -- psql -v ON_ERROR_STOP=1 -c \
            "CREATE ROLE \"${db_user_escaped}\" LOGIN PASSWORD '${DB_PASSWORD//\'/\'\'}';" >/dev/null 2>&1 || true
    fi

    runuser -u postgres -- dropdb --if-exists "$DB_NAME" >/dev/null 2>&1 || true
    runuser -u postgres -- createdb -O "$DB_USER" "$DB_NAME" >/dev/null 2>&1 || return 1

    if ! gunzip -c "$backup" | PGPASSWORD="${DB_PASSWORD:-}" psql \
        -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -q -v ON_ERROR_STOP=1 >/dev/null 2>&1; then
        add_action "falló la restauración de la base"
        return 1
    fi

    if db_query; then
        RECOVERED=1
        add_action "base restaurada y verificada"
        return 0
    fi
    add_action "la base restaurada no responde"
    return 1
}

cache_emergency_contact() {
    [ "$DRY_RUN" = "1" ] && return 0
    [ -n "$PYTHON" ] || return 0
    db_query || return 0

    local row
    row="$(psql_cmd -tA -F $'\t' -c \
        "SELECT COALESCE(e.smtp_host,''), COALESCE(e.smtp_port::text,''), COALESCE(e.smtp_user,''), COALESCE(e.smtp_password,''), COALESCE(e.from_email,''), COALESCE(NULLIF(n.alert_emails,''), n.to_emails, '') FROM email_settings e LEFT JOIN notification_settings n ON true LIMIT 1" \
        2>/dev/null)"
    [ -n "$row" ] || return 0

    ROW="$row" TARGET="$ALERT_CACHE" "$PYTHON" >/dev/null 2>&1 <<'PY'
import json
import os
from pathlib import Path

row = os.environ.get("ROW", "").split("\t")
if len(row) < 6 or not row[0] or not row[4] or not row[5]:
    raise SystemExit(0)
data = {
    "smtp_host": row[0],
    "smtp_port": int(row[1] or 587),
    "smtp_user": row[2],
    "smtp_password": row[3],
    "from_email": row[4],
    "to_emails": row[5],
}
path = Path(os.environ["TARGET"])
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(data), encoding="utf-8")
path.chmod(0o600)
PY
    [ -r "$ALERT_CACHE" ] && add_action "contacto de emergencia actualizado"
}

send_external_alert() {
    local reason="$1"
    [ "$DRY_RUN" = "1" ] && return 0
    if [ -r "$ALERT_STAMP" ]; then
        local last now
        last="$(stat -c %Y "$ALERT_STAMP" 2>/dev/null || echo 0)"
        now="$(date +%s)"
        [ "$last" -gt 0 ] && [ $((now - last)) -lt 3600 ] && return 0
    fi
    [ -n "$PYTHON" ] || return 0
    REASON="$reason" CACHE="$ALERT_CACHE" HOSTNAME_VAL="$(hostname 2>/dev/null || echo NSP)" \
        "$PYTHON" >/dev/null 2>&1 <<'PY'
import json
import os
import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path

cache = Path(os.environ.get("CACHE", ""))
if not cache.is_file():
    raise SystemExit(0)
data = json.loads(cache.read_text(encoding="utf-8"))
to_list = [email.strip() for email in (data.get("to_emails") or "").split(",") if email.strip()]
if not to_list:
    raise SystemExit(0)
message = EmailMessage()
message["Subject"] = f"[{os.environ.get('HOSTNAME_VAL', 'NSP')}] Intervención externa requerida"
message["From"] = data["from_email"]
message["To"] = ", ".join(to_list)
message.set_content(
    "El NSP intentó recuperarse automáticamente y no pudo completar el arranque.\n\n"
    + os.environ.get("REASON", "Requiere revisión manual.") + "\n"
)
port = int(data.get("smtp_port") or 587)
if port == 465:
    server = smtplib.SMTP_SSL(data["smtp_host"], port, context=ssl.create_default_context(), timeout=20)
else:
    server = smtplib.SMTP(data["smtp_host"], port, timeout=20)
    server.ehlo()
    server.starttls()
    server.ehlo()
if data.get("smtp_user"):
    server.login(data["smtp_user"], data.get("smtp_password") or "")
server.send_message(message)
server.quit()
PY
    if [ $? -eq 0 ]; then
        date -Is > "$ALERT_STAMP" 2>/dev/null || true
        chmod 0600 "$ALERT_STAMP" 2>/dev/null || true
    fi
}

main() {
    add_action "inicio"

    if ! load_env; then
        add_action "falta o no se puede leer stepad.env"
        EXTERNAL=1
    elif ! validate_env_file; then
        add_action "stepad.env inválido"
        if ! restore_latest_env || ! load_env; then
            EXTERNAL=1
        fi
    fi

    if ! validate_config_yaml; then
        add_action "config.yaml inválido"
        if ! restore_config_yaml || ! validate_config_yaml; then
            EXTERNAL=1
        fi
    fi

    if ! validate_dnsmasq; then
        add_action "dnsmasq.conf inválido"
        if ! restore_dnsmasq || ! validate_dnsmasq; then
            EXTERNAL=1
        fi
    fi

    refresh_last_good

    if ! systemctl is-active postgresql >/dev/null 2>&1; then
        add_action "PostgreSQL detenido; iniciando"
        systemctl start postgresql >/dev/null 2>&1 || true
    fi

    for _ in $(seq 1 20); do
        db_ready && break
        sleep 1
    done

    local db_error=""
    if ! db_ready; then
        add_action "PostgreSQL no responde; reiniciando"
        systemctl restart postgresql >/dev/null 2>&1 || true
        for _ in $(seq 1 20); do
            db_ready && break
            sleep 1
        done
    fi

    if db_ready; then
        db_error="$(psql_cmd -tAc 'SELECT 1' 2>&1)"
    else
        db_error="PostgreSQL no responde"
    fi

    if [ "$(printf '%s' "$db_error" | tr -d '[:space:]')" != "1" ]; then
        add_action "base no responde: $(printf '%s' "$db_error" | head -c 180)"
        case "$db_error" in
            *"authentication failed"*|*"role"*"does not exist"*|*"password"*)
                add_action "fallo de credenciales; no se restaura automáticamente"
                EXTERNAL=1
                ;;
            *"database"*"does not exist"*|*"invalid page"*|*"could not read block"*|*"corrupt"*|*"Corruption"*|*"invalid"*"page"*)
                if ! backup="$(latest_db_backup)"; then
                    add_action "sin respaldo local verificado"
                    EXTERNAL=1
                elif ! restore_database "$backup"; then
                    EXTERNAL=1
                fi
                ;;
            *)
                add_action "no hay señal clara de corrupción; no se restaura automáticamente"
                EXTERNAL=1
                ;;
        esac
    else
        cache_emergency_contact
    fi

    if [ "$EXTERNAL" = "1" ]; then
        write_state "external_required"
        send_external_alert "El NSP no pudo reparar el arranque automáticamente. Revisar PostgreSQL y los respaldos locales."
        log "ESTADO: requiere intervención externa"
        return 1
    fi

    if [ "$RECOVERED" = "1" ]; then
        write_state "recovered"
        log "ESTADO: recuperado automáticamente"
        return 0
    fi

    write_state "ok"
    log "ESTADO: arranque validado"
    return 0
}

main
exit $?
