"""Segmento DHCP: capacidad, rangos dinámicos y estadísticas.

Un `PoolSpec` describe el segmento completo en direcciones enteras:

- `dynamic`: direcciones que dnsmasq puede repartir (pool menos
  exclusiones y reservas).
- `reserved`: direcciones con reserva (`dhcp-host`), servidas solo a su
  MAC.
- `ranges`: los `dhcp-range` contiguos que se escriben en dnsmasq.conf.

`pool_stats` calcula el panel con la misma información: nunca se suman
`ip_address` de la base (quedan viejas cuando el equipo se apaga), se
cuenta lo que dnsmasq realmente tiene.
"""

from __future__ import annotations

import ipaddress

from dataclasses import dataclass

from backend.dhcp.domain.exclusions import excluded_addresses
from backend.dhcp.domain.leases import Lease


def ip_to_int(value: str | None) -> int | None:

    if not value:

        return None

    try:

        return int(ipaddress.ip_address(str(value)))

    except ValueError:

        return None


def int_to_ip(value: int) -> str:

    return str(ipaddress.ip_address(value))


@dataclass(frozen=True)
class PoolSpec:

    start: int

    end: int

    netmask: str

    lease_time: str

    dynamic: frozenset[int]

    reserved: frozenset[int]

    ranges: tuple[tuple[int, int], ...]

    group_start: int

    group_end: int

    @property
    def total(self) -> int:

        return max(0, self.end - self.start + 1)

    @property
    def group_total(self) -> int:

        return max(0, self.group_end - self.group_start + 1)


def build_ranges(
    start: int,
    end: int,
    excluded: set[int]
) -> list[tuple[int, int]]:
    """Divide [start, end] en tramos contiguos sin las direcciones excluidas."""

    ranges: list[tuple[int, int]] = []

    cursor = start

    for value in sorted(v for v in excluded if start <= v <= end):

        if cursor < value:

            ranges.append((cursor, value - 1))

        cursor = value + 1

    if cursor <= end:

        ranges.append((cursor, end))

    return ranges


def build_pool_spec(dhcp: dict, reserved_ips=()) -> PoolSpec:
    """Construye el segmento a partir de la config + las IPs reservadas."""

    start = ip_to_int(dhcp.get("pool_start")) or 0

    end = ip_to_int(dhcp.get("pool_end")) or 0

    group_start = ip_to_int(dhcp.get("group_ip_start")) or 0

    group_end = ip_to_int(dhcp.get("group_ip_end")) or 0

    reserved = {
        value
        for value in (ip_to_int(ip) for ip in reserved_ips or ())
        if value is not None and start <= value <= end
    }

    excluded = excluded_addresses(dhcp.get("excluded_ips") or [])

    excluded.update(reserved)

    dynamic = frozenset(
        value
        for value in range(start, end + 1)
        if value not in excluded
    )

    return PoolSpec(
        start=start,
        end=end,
        netmask=str(dhcp.get("netmask") or "255.255.255.0"),
        lease_time=str(dhcp.get("lease_time") or "24h"),
        dynamic=dynamic,
        reserved=frozenset(reserved),
        ranges=tuple(build_ranges(start, end, excluded)),
        group_start=group_start,
        group_end=group_end,
    )


def pool_stats(
    spec: PoolSpec,
    leases: list[Lease],
    online_macs: set[str]
) -> dict:
    """Estadísticas honestas del pool de equipos.

    - online: direcciones con lease activo cuyo equipo está ONLINE.
    - offline: direcciones ocupadas por equipos no online + reservas
      que nadie está usando ahora (quedan bloqueadas para ese equipo).
    - free: direcciones dinámicas sin lease.

    Invariante: online + offline + free == total del pool.
    """

    leased: set[int] = set()

    online: set[int] = set()

    for lease in leases:

        value = ip_to_int(lease.ip)

        if value is None or not (spec.start <= value <= spec.end):

            continue

        leased.add(value)

        if lease.mac in online_macs:

            online.add(value)

    leased_dynamic = leased - spec.reserved

    idle_reserved = spec.reserved - leased

    free = max(0, len(spec.dynamic) - len(leased_dynamic))

    offline = len(leased) - len(online) + len(idle_reserved)

    return {
        "total": spec.total,
        "dynamic": len(spec.dynamic),
        "reserved": len(spec.reserved),
        "leased": len(leased),
        "online": len(online),
        "offline": offline,
        "free": free,
    }
