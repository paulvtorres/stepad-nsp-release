"""Estadísticas del segmento DHCP para el panel.

Antes sumaba `ip_address` de la base de datos: como esa IP se conserva
cuando el equipo se apaga (para el reporte), el panel marcaba "ocupadas"
direcciones que dnsmasq ya no tiene prestadas y el "libre" salía mal
(1 libre cuando había ~25).

Ahora todo sale de la capa de dominio:

- `build_pool_spec`: capacidad dinámica (pool menos exclusiones/reservas).
- `read_leases`: lo que dnsmasq tiene prestado AHORA.
- `pool_stats`: online / offline / libres con invariante
  online + offline + free == total.
"""

from __future__ import annotations

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.session import SessionLocal
from backend.dhcp.domain.leases import read_leases
from backend.dhcp.domain.conflicts import find_conflicts
from backend.dhcp.domain.neighbors import arp_mac_by_ip
from backend.dhcp.domain.pool import build_pool_spec, ip_to_int, pool_stats
from backend.groups.constants.group_dns_ip_reserve import (
    free_group_ip_count,
    group_ip_capacity,
)
from backend.groups.models.device_group import DeviceGroup
from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.config.config_service import ConfigService
from backend.shared.logging.logger import logger



def arp_table_now() -> dict[str, str]:
    """{ip: mac} de la tabla ARP (equipos presentes ahora mismo)."""

    try:

        with open("/proc/net/arp", encoding="utf-8", errors="replace") as file:

            return arp_mac_by_ip(file.read())

    except OSError as error:

        logger.debug("dhcp_pool_stats_service: ARP ilegible: %s", error)

        return {}


class DhcpPoolStatsService:

    def __init__(self):

        self.config_service = ConfigService()

    def get_stats(self) -> dict:

        dhcp = self.config_service.get_dhcp_config() or {}

        reserved_ips: list[str] = []

        known_macs: set[str] = set()

        group_used_ips: set[str] = set()

        db = SessionLocal()

        try:

            for mac, permanent_ip in db.query(
                NetworkDevice.mac_address,
                NetworkDevice.permanent_ip,
            ).all():

                mac = (mac or "").lower()

                if mac:

                    known_macs.add(mac)

                if permanent_ip:

                    reserved_ips.append(permanent_ip)

            group_used_ips = {
                alias
                for (alias,) in db.query(DeviceGroup.dns_alias_ip).filter(
                    DeviceGroup.dns_alias_ip.isnot(None)
                ).all()
                if alias
            }

        finally:

            db.close()

        spec = build_pool_spec(dhcp, reserved_ips)

        arp = arp_table_now()

        online_macs = set(arp.values())

        leases = read_leases(DNSMASQ_LEASES_FILE)

        # IPs fijas dentro del pool (equipos sin lease ni reserva):
        # ocupan direccion aunque dnsmasq no las tenga prestadas.
        static_ips = [
            item.ip
            for item in find_conflicts(
                leases,
                arp,
                reserved_ips,
                dhcp.get("pool_start"),
                dhcp.get("pool_end"),
            )
            if item.kind == "static_in_pool"
        ]

        stats = pool_stats(spec, leases, online_macs, static_ips)

        # Presencia real (ARP): dentro y fuera del pool. "En linea" no debe
        # confundirse con "en el pool".
        present = set(arp)
        in_pool_bounds = 0

        for ip in present:

            value = ip_to_int(ip)

            if value is not None and spec.start <= value <= spec.end:

                in_pool_bounds += 1

        # Reserva de alias de grupos (subrango separado del pool).
        try:

            group_total = group_ip_capacity(dhcp)

        except Exception as error:

            logger.warning("dhcp_pool_stats_service: capacidad de grupos: %s", error)

            group_total = 0

        try:

            group_free = free_group_ip_count(group_used_ips, dhcp)

            group_used = max(0, group_total - group_free)

        except Exception as error:

            logger.debug("dhcp_pool_stats_service.get_stats: %s", error)

            group_used = min(group_total, len(group_used_ips))

            group_free = max(0, group_total - group_used)

        leases_not_in_db = len(
            {
                lease.ip
                for lease in leases
                if lease.mac not in known_macs
                and spec.start <= (ip_to_int(lease.ip) or -1) <= spec.end
            }
        )

        return {
            "gateway": dhcp.get("gateway"),
            "pool_start": dhcp.get("pool_start"),
            "pool_end": dhcp.get("pool_end"),
            "group_ip_start": dhcp.get("group_ip_start"),
            "group_ip_end": dhcp.get("group_ip_end"),
            "devices": {
                "total": stats["total"],
                "dynamic": stats["dynamic"],
                "leased": stats["leased"],
                "reserved_in_use": stats.get("reserved_in_use", 0),
                "static": stats["static"],
                "online": stats["online"],
                "offline": stats["offline"],
                "reserved": stats["reserved"],
                "free": stats["free"],
            },
            "groups": {
                "total": group_total,
                "used": group_used,
                "free": group_free,
            },
            "overall": {
                "total": stats["total"] + group_total,
                "used": stats["online"] + stats["offline"] + group_used,
                "online": stats["online"],
                "offline": stats["offline"],
                "free": stats["free"] + group_free,
            },
            "network": {
                "present": len(present),
                "in_pool": in_pool_bounds,
                "outside_pool": max(0, len(present) - in_pool_bounds),
            },
            "dnsmasq_leases": len(leases),
            "leases_not_in_db": leases_not_in_db,
        }
