from sqlalchemy import Boolean, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class BackupSettings(Base):

    __tablename__ = "backup_settings"


    id: Mapped[int] = mapped_column(
        primary_key=True
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    send_hour: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=3
    )


    send_minute: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0
    )


    # keep the newest N backups; older ones are deleted
    retention_count: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=7
    )


    # send a copy of each encrypted backup to the notification
    # recipients (off-site retention).
    email_backup: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    to_emails: Mapped[str] = mapped_column(
        String(1000),
        nullable=False,
        default=""
    )


    bcc_emails: Mapped[str] = mapped_column(
        String(1000),
        nullable=False,
        default=""
    )


    last_backup_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
