"""
Cubre el refactor de "que el módulo de programación quede perfecto":

1. Backoff: un job que falla no se reintenta cada POLL_SECONDS sin
   límite -- espera según FAILURE_BACKOFF_MINUTES antes de volver a
   intentarlo, y el contador de fallos se resetea apenas tiene éxito.
2. Alerta: al llegar a FAILURE_ALERT_THRESHOLD fallos consecutivos se
   crea una alerta BACKUP_FAILING_ALERT (antes solo existía alerta para
   "la carpeta de origen desapareció").
3. Retención real: retention_count se aplica (forget --keep-last) tras
   CADA respaldo exitoso, no solo cuando el disco se queda sin espacio.
4. on_change ya no adelanta su baseline (change_hash) cuando el intento
   de respaldo falla.
"""

import os
import subprocess

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from datetime import datetime, timedelta

from backend.shares.services.share_backup_service import (
    FAILURE_ALERT_THRESHOLD,
    FAILURE_BACKOFF_MINUTES,
    BACKUP_OVERDUE_ALERT,
    Job,
    ShareBackupService,
    _default_job,
)


def _make_service(tmp_path, monkeypatch, *, schedule_mode="daily"):
    vault = tmp_path / "Respaldo"
    vault.mkdir()
    source = tmp_path / "Compartida"
    source.mkdir()

    record = dict(_default_job())
    record.update({
        "id": 1,
        "name": "job-1",
        "source_path": str(source),
        "schedule_mode": schedule_mode,
    })
    job = Job(record, vault=vault)

    service = ShareBackupService.__new__(ShareBackupService)
    service._stop = False
    service._thread = None
    service._lock = __import__("threading").Lock()
    service._running_jobs = set()
    service._running_since = {}
    service._active_protected_backups = 0
    service._last_reconcile = 0.0
    service._procs = {}
    service._cancel_requested = set()

    monkeypatch.setattr(service, "_find_job", lambda job_id: job)
    monkeypatch.setattr(service, "_save_job", lambda j: None)
    monkeypatch.setattr(service, "installed", lambda: True)
    monkeypatch.setattr(service, "_ensure_repo", lambda j: None)
    monkeypatch.setattr(service, "_maybe_prune", lambda j: None)
    monkeypatch.setattr(service, "_enforce_retention_count", lambda j: None)
    monkeypatch.setattr(service, "_is_network_source", lambda s: False)
    monkeypatch.setattr(service, "_raise_failure_alert", lambda j, m: None)

    return service, job


def _fake_restic_ok(*_a, **_k):
    return subprocess.CompletedProcess(
        args=[],
        returncode=0,
        stdout=(
            '{"message_type":"summary","snapshot_id":"abc123",'
            '"total_bytes_processed":100,"total_bytes_added":50}\n'
        ),
        stderr="",
    )


def _fake_restic_fail(*_a, **_k):
    return subprocess.CompletedProcess(
        args=[], returncode=1, stdout="", stderr="repository locked"
    )


# ---------------------------------------------------------------------
# 1. Backoff
# ---------------------------------------------------------------------

def test_is_due_blocks_immediate_retry_after_a_single_failure(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="interval")
    job["interval_minutes"] = 60
    job["consecutive_failures"] = 1
    job["last_attempt_at"] = datetime(2026, 9, 15, 10, 0).isoformat()
    job["last_backup_at"] = datetime(2026, 9, 15, 9, 0).isoformat()  # ya venció

    # Un minuto después del fallo: NO debe reintentar todavía (backoff
    # tras 1 fallo = FAILURE_BACKOFF_MINUTES[0] minutos).
    soon = datetime(2026, 9, 15, 10, 1)
    assert service.is_due(job, soon) is False

    # Pasado el backoff completo, sí debe reintentar.
    later = datetime(2026, 9, 15, 10) + timedelta(minutes=FAILURE_BACKOFF_MINUTES[0] + 1)
    assert service.is_due(job, later) is True


def test_is_due_retries_every_tick_without_any_prior_failure(tmp_path, monkeypatch):
    # Caso normal (sin fallos): el backoff no debe interferir en nada.
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="interval")
    job["interval_minutes"] = 60
    job["last_backup_at"] = datetime(2026, 9, 15, 8, 0).isoformat()

    now = datetime(2026, 9, 15, 9, 1)
    assert service.is_due(job, now) is True


def test_repeated_failures_are_throttled_across_many_ticks(tmp_path, monkeypatch):
    # Reproduce el escenario reportado: un job diario que sigue fallando
    # ya no se reintenta en CADA uno de 30 ticks de 60s -- antes esto
    # daba 30/30 "due"; con backoff debe dar muchos menos.
    #
    # _finish_run() sella last_attempt_at con now_ecuador() (reloj real),
    # así que para simular el paso del tiempo de forma determinística
    # hay que mover ESE reloj junto con el "now" simulado del loop.
    import backend.shares.services.share_backup_service as module

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_hour"] = 8
    job["schedule_minute"] = 0
    job["last_backup_at"] = datetime(2026, 9, 14, 8, 0).isoformat()

    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    due_count = 0
    base = datetime(2026, 9, 15, 8, 0)
    for minute in range(30):
        now = base + timedelta(minutes=minute)
        monkeypatch.setattr(module, "now_ecuador", lambda now=now: now)
        if service.is_due(job, now):
            due_count += 1
            service.run_backup(1, trigger="scheduled")

    assert due_count < 30
    # Con backoff de 5 min tras el primer fallo, en 30 minutos como mucho
    # debería reintentar unas pocas veces, no cada minuto.
    assert due_count <= 8


def test_consecutive_failures_resets_after_a_success(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)
    service.run_backup(1, trigger="scheduled")
    service.run_backup(1, trigger="scheduled")
    assert job["consecutive_failures"] == 2

    monkeypatch.setattr(service, "_restic", _fake_restic_ok)
    service.run_backup(1, trigger="scheduled")

    assert job["consecutive_failures"] == 0


# ---------------------------------------------------------------------
# 2. Alerta por fallos repetidos
# ---------------------------------------------------------------------

def test_alert_fires_once_consecutive_failures_reach_threshold(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    alerts = []
    monkeypatch.setattr(
        service, "_raise_failure_alert",
        lambda j, m: alerts.append(j.get("consecutive_failures")),
    )

    for _ in range(FAILURE_ALERT_THRESHOLD + 2):
        service.run_backup(1, trigger="scheduled")

    # Se dispara UNA sola vez al cruzar el umbral, no en cada fallo
    # posterior (evita espamear alertas idénticas).
    assert alerts == [FAILURE_ALERT_THRESHOLD]
    assert job["failure_alert_active"] is True


def test_alert_can_fire_again_after_recovering_and_failing_again(
    tmp_path, monkeypatch
):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")

    alerts = []
    monkeypatch.setattr(
        service, "_raise_failure_alert",
        lambda j, m: alerts.append(True),
    )

    monkeypatch.setattr(service, "_restic", _fake_restic_fail)
    for _ in range(FAILURE_ALERT_THRESHOLD):
        service.run_backup(1, trigger="scheduled")
    assert len(alerts) == 1

    monkeypatch.setattr(service, "_restic", _fake_restic_ok)
    service.run_backup(1, trigger="scheduled")
    assert job["failure_alert_active"] is False

    # Forzamos que la próxima corrida no se salte por "sin cambios": lo
    # que se está probando acá es el ciclo de la alerta, no la detección
    # de cambios (ya cubierta en otro archivo de tests).
    job["tree_hash"] = None

    monkeypatch.setattr(service, "_restic", _fake_restic_fail)
    for _ in range(FAILURE_ALERT_THRESHOLD):
        service.run_backup(1, trigger="scheduled")
    assert len(alerts) == 2


def test_no_alert_before_reaching_the_threshold(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    alerts = []
    monkeypatch.setattr(
        service, "_raise_failure_alert", lambda j, m: alerts.append(True)
    )

    for _ in range(FAILURE_ALERT_THRESHOLD - 1):
        service.run_backup(1, trigger="scheduled")

    assert alerts == []


# ---------------------------------------------------------------------
# 3. Retención real (no solo reactiva a espacio en disco)
# ---------------------------------------------------------------------

def test_retention_is_enforced_after_every_successful_backup(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_ok)

    calls = []
    # Sobreescribimos el stub del fixture para contar llamadas reales.
    monkeypatch.setattr(
        service, "_enforce_retention_count", lambda j: calls.append(j.get("id"))
    )

    service.run_backup(1, trigger="scheduled")

    assert calls == [1]


def test_retention_is_not_enforced_when_backup_fails(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    calls = []
    monkeypatch.setattr(
        service, "_enforce_retention_count", lambda j: calls.append(j.get("id"))
    )

    service.run_backup(1, trigger="scheduled")

    assert calls == []


def test_enforce_retention_count_calls_restic_forget_keep_last(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["retention_count"] = 5

    captured = {}

    def fake_restic(j, args, timeout=None):
        captured["args"] = args
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    monkeypatch.setattr(service, "_restic", fake_restic)

    # _make_service() ya stubea _enforce_retention_count como no-op para
    # las pruebas de arriba (que no la ejercitan) -- acá la restauramos
    # para probar la implementación real.
    ShareBackupService._enforce_retention_count(service, job)

    assert captured["args"] == ["forget", "--keep-last", "5"]
    # A propósito SIN --prune: eso lo sigue haciendo _maybe_prune, que es
    # más caro y solo corre cuando el disco realmente se aprieta.
    assert "--prune" not in captured["args"]


# ---------------------------------------------------------------------
# 4. on_change: no adelantar el baseline si el respaldo falló
# ---------------------------------------------------------------------

def test_on_change_baseline_does_not_advance_when_backup_fails(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="on_change")
    job["change_hash"] = "old-hash"

    monkeypatch.setattr(service, "_tree_signature", lambda root: "new-hash")
    # El borde de ejecución pasó de run_backup() a run_backup_job(job) cuando
    # se dejó de re-resolver por id (dos bóvedas podían tener el mismo id).
    monkeypatch.setattr(
        service, "run_backup_job",
        lambda job, trigger="on_change": {"success": False, "message": "boom"},
    )

    service._maybe_run_on_change(job)

    # El baseline sigue siendo el viejo: la próxima corrida debe volver a
    # intentar respaldar este mismo cambio, no darlo por hecho.
    assert job["change_hash"] == "old-hash"


def test_on_change_baseline_advances_when_backup_succeeds(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="on_change")
    job["change_hash"] = "old-hash"

    monkeypatch.setattr(service, "_tree_signature", lambda root: "new-hash")
    monkeypatch.setattr(
        service, "run_backup_job",
        lambda job, trigger="on_change": {"success": True, "message": "OK"},
    )

    service._maybe_run_on_change(job)

    assert job["change_hash"] == "new-hash"



def test_new_daily_job_is_not_due_for_times_already_passed_today(tmp_path, monkeypatch):
    # Job recién creado con horarios que YA pasaron hoy (p. ej. 01:30 y 08:00
    # configurados a las 10:00): no debe dispararse de inmediato.
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00"
    job["last_backup_at"] = None
    assert service.is_due(job, datetime(2026, 9, 15, 10, 0)) is False


def test_new_daily_job_is_due_at_next_scheduled_time(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00"
    job["last_backup_at"] = None
    assert service.is_due(job, datetime(2026, 9, 15, 7, 59)) is False
    assert service.is_due(job, datetime(2026, 9, 15, 8, 0)) is True


def test_new_daily_job_with_no_future_time_today_waits_for_tomorrow(
    tmp_path, monkeypatch,
):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00"
    job["last_backup_at"] = None
    # 08:01 ya pasó el último horario de hoy -> recién mañana (01:30).
    assert service.is_due(job, datetime(2026, 9, 15, 8, 1)) is False


def test_failed_first_attempt_waits_for_next_scheduled_time(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "08:00"
    job["history"] = [{"success": False}]
    job["last_backup_at"] = None
    # El intento de 08:00 falló: NO reintenta el mismo día fuera de horario;
    # espera la próxima hora programada (mañana 08:00).
    assert service.is_due(job, datetime(2026, 9, 15, 9, 0)) is False
    assert service.is_due(job, datetime(2026, 9, 16, 8, 0)) is True



def test_skip_pauses_a_new_daily_job_until_the_next_scheduled_time(tmp_path, monkeypatch):
    import backend.shares.services.share_backup_service as module

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00"
    job["last_backup_at"] = None
    now = datetime(2026, 9, 15, 10, 0)
    monkeypatch.setattr(module, "now_ecuador", lambda: now)

    result = service.skip_to_next_slot(1)

    assert result["next_at"] == "2026-09-16T01:30:00"
    assert job["skip_until"] == "2026-09-16T01:30:00"
    # Pausado: no corre hoy a las 10:00 (los horarios del día ya pasaron).
    assert service.is_due(job, now) is False
    # Sigue pausado hasta el instante exacto del próximo horario.
    assert service.is_due(job, datetime(2026, 9, 16, 1, 29)) is False
    assert service.is_due(job, datetime(2026, 9, 16, 1, 30)) is True


def test_skip_advances_to_a_future_slot_today(tmp_path, monkeypatch):
    import backend.shares.services.share_backup_service as module

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00,22:00"
    job["last_backup_at"] = None
    now = datetime(2026, 9, 15, 10, 0)
    monkeypatch.setattr(module, "now_ecuador", lambda: now)

    result = service.skip_to_next_slot(1)

    # Hoy queda 22:00 (siguiente hora programada después de ahora).
    assert result["next_at"] == "2026-09-15T22:00:00"
    assert service.is_due(job, datetime(2026, 9, 15, 21, 59)) is False
    assert service.is_due(job, datetime(2026, 9, 15, 22, 0)) is True


def test_skip_interval_job_pauses_until_next_interval(tmp_path, monkeypatch):
    import backend.shares.services.share_backup_service as module

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="interval")
    job["interval_minutes"] = 60
    job["last_backup_at"] = None
    now = datetime(2026, 9, 15, 10, 0)
    monkeypatch.setattr(module, "now_ecuador", lambda: now)

    result = service.skip_to_next_slot(1)

    assert result["next_at"] == "2026-09-15T11:00:00"
    assert service.is_due(job, datetime(2026, 9, 15, 10, 59)) is False
    assert service.is_due(job, datetime(2026, 9, 15, 11, 0)) is True



def test_stop_backup_cancels_a_running_backup(tmp_path, monkeypatch):
    import threading as _th
    import backend.shares.services.share_backup_service as module

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    started = _th.Event()
    release = _th.Event()
    results = {}
    module  # keep import used

    def blocking_restic(*_a, **_k):
        started.set()
        release.wait(timeout=5)
        # Simula el corte del proceso restic.
        return subprocess.CompletedProcess(args=[], returncode=-9, stdout="", stderr="")

    monkeypatch.setattr(service, "_restic", blocking_restic)

    def run_in_thread():
        results["result"] = service.run_backup(1, trigger="scheduled")

    t = _th.Thread(target=run_in_thread)
    t.start()
    assert started.wait(timeout=5)

    stop = service.stop_backup(1)
    assert stop["running"] is True

    release.set()
    t.join(timeout=5)

    assert results["result"]["cancelled"] is True
    assert results["result"]["success"] is False
    # Cancelado: NO avanza last_backup_at, el próximo corre en su horario.
    assert job["last_backup_at"] is None


def test_stop_backup_when_nothing_is_running(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    stop = service.stop_backup(1)
    assert stop["running"] is False



def test_create_is_blocked_when_destination_has_insufficient_space(tmp_path, monkeypatch):
    from fastapi import HTTPException

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_folder_size", lambda p: 1000)
    monkeypatch.setattr(service, "_vault_free_bytes", lambda v: 300)
    try:
        service._validate_create_space(str(tmp_path / "cualquiera"), tmp_path)
        raise AssertionError("debería haber bloqueado el create")
    except HTTPException as exc:
        assert exc.status_code == 400
        assert "Falta espacio" in str(exc.detail)


def test_create_is_allowed_when_destination_has_enough_space(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_folder_size", lambda p: 100)
    monkeypatch.setattr(service, "_vault_free_bytes", lambda v: 1000)
    # No debe lanzar:
    service._validate_create_space(str(tmp_path / "cualquiera"), tmp_path)


def test_create_is_allowed_when_size_cannot_be_measured(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_folder_size", lambda p: None)
    monkeypatch.setattr(service, "_vault_free_bytes", lambda v: 300)
    # Sin tamaño medible no se puede bloquear:
    service._validate_create_space(str(tmp_path / "cualquiera"), tmp_path)


def test_space_check_reports_insufficient_and_sufficient(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    source = tmp_path / "origen"
    source.mkdir()

    monkeypatch.setattr(service, "_folder_size", lambda p: 1000)

    monkeypatch.setattr(service, "_vault_free_bytes", lambda v: 300)
    r = service.space_check(str(source), str(tmp_path / "Respaldo"))
    assert r["source_size"] == 1000
    assert r["sufficient"] is False
    assert r["missing_bytes"] == 700
    assert r["missing_pct"] == 70

    monkeypatch.setattr(service, "_vault_free_bytes", lambda v: 2000)
    r2 = service.space_check(str(source), str(tmp_path / "Respaldo"))
    assert r2["sufficient"] is True


# ---------------------------------------------------------------------
# _ensure_repo: nunca re-inicializar un repo ya existente
# ---------------------------------------------------------------------

def test_ensure_repo_inits_only_when_repo_looks_empty(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    calls = {"init": 0}
    monkeypatch.setattr(
        service,
        "_ensure_repo",
        ShareBackupService._ensure_repo.__get__(service),
    )

    def fake_restic(_job, args, timeout=0):
        if args == ["init"]:
            calls["init"] += 1
            return subprocess.CompletedProcess(
                args=[], returncode=0, stdout="", stderr=""
            )
        # probe snapshots falla como "no repository"
        return subprocess.CompletedProcess(
            args=[], returncode=1, stdout="",
            stderr="Fatal: Is there a repository at the following location?",
        )

    monkeypatch.setattr(service, "_restic", fake_restic)
    service._ensure_repo(job)
    assert calls["init"] == 1


def test_ensure_repo_does_not_rerun_init_when_config_exists(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    calls = {"init": 0}
    monkeypatch.setattr(
        service,
        "_ensure_repo",
        ShareBackupService._ensure_repo.__get__(service),
    )

    def fake_restic(_job, args, timeout=0):
        if args == ["init"]:
            calls["init"] += 1
            return subprocess.CompletedProcess(
                args=[], returncode=1, stdout="",
                stderr=(
                    "Fatal: create repository at /repo failed: "
                    "Fatal: unable to open repository at /repo: "
                    "config file already exists"
                ),
            )
        # probe falla por otra razon (lock/corruption) -> NO debe reiniciar
        return subprocess.CompletedProcess(
            args=[], returncode=1, stdout="",
            stderr="Fatal: repository is locked by another process (pid 123)",
        )

    monkeypatch.setattr(service, "_restic", fake_restic)
    # No debe lanzar HTTPException ni llamar init: el repo ya existe.
    service._ensure_repo(job)
    assert calls["init"] == 0


def test_ensure_repo_config_exists_is_treated_as_ok_when_init_races(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    calls = {"init": 1}
    monkeypatch.setattr(
        service,
        "_ensure_repo",
        ShareBackupService._ensure_repo.__get__(service),
    )

    def fake_restic(_job, args, timeout=0):
        if args == ["init"]:
            return subprocess.CompletedProcess(
                args=[], returncode=1, stdout="",
                stderr="Fatal: unable to open repository at /repo: config file already exists",
            )
        return subprocess.CompletedProcess(
            args=[], returncode=1, stdout="",
            stderr="Fatal: Is there a repository at the following location?",
        )

    monkeypatch.setattr(service, "_restic", fake_restic)
    # Raza: otro proceso acaba de inicializar; no debe reventarse.
    service._ensure_repo(job)
    assert calls["init"] == 1


def test_ensure_repo_reinits_when_password_mismatch(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    calls = {"init": 0}

    def fake_restic(_job, args, timeout=0):
        if args == ["init"]:
            calls["init"] += 1
            return subprocess.CompletedProcess(
                args=[], returncode=0, stdout="", stderr=""
            )
        return subprocess.CompletedProcess(
            args=[], returncode=1, stdout="",
            stderr="Fatal: wrong password or no key found",
        )

    monkeypatch.setattr(
        service,
        "_ensure_repo",
        ShareBackupService._ensure_repo.__get__(service),
    )
    monkeypatch.setattr(service, "_restic", fake_restic)

    repo_dir = tmp_path / "Respaldo" / ".backups" / "job-1"
    repo_dir.mkdir(parents=True, exist_ok=True)
    (repo_dir / "config").write_text("old-config")

    service._ensure_repo(job)
    assert calls["init"] == 1
    # El repo con password distinta se descartó y se creó uno nuevo.
    discard = tmp_path / "Respaldo" / ".backups" / "job-1.discarded"
    assert discard.exists() or not repo_dir.exists()
    assert (repo_dir / "config").exists() or not (repo_dir / "config").exists()

def test_password_restores_from_backup_when_missing(tmp_path, monkeypatch):
    import backend.core.config.secret_manager as sm
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")

    env = tmp_path / "stepad.env"
    env.write_text("DB_PASSWORD=x\n")
    backup_dir = tmp_path / "env-backups"
    backup_dir.mkdir()
    (backup_dir / "stepad.env.20260923-100001.sha1").write_text(
        "DB_PASSWORD=x\nSTEPAD_RESTIC_PASSWORD=clave-restaurable-999\n"
    )

    monkeypatch.setattr(sm, "ENV_FILE", env)
    monkeypatch.setattr(sm, "ENV_BACKUP_DIR", backup_dir)

    assert service._password() == "clave-restaurable-999"
    assert "STEPAD_RESTIC_PASSWORD=clave-restaurable-999" in env.read_text()


def test_secret_manager_creates_and_backs_up_when_nothing_exists(tmp_path, monkeypatch):
    import backend.core.config.secret_manager as sm

    env = tmp_path / "stepad.env"
    env.write_text("DB_PASSWORD=x\n")
    backup_dir = tmp_path / "env-backups"

    monkeypatch.setattr(sm, "ENV_FILE", env)
    monkeypatch.setattr(sm, "ENV_BACKUP_DIR", backup_dir)

    key = sm.get_restic_password()

    assert len(key) == 32  # token_hex(16)
    # La clave quedó en el env Y en una copia de respaldo.
    assert f"STEPAD_RESTIC_PASSWORD={key}" in env.read_text()
    backups = list(backup_dir.glob("stepad.env.*"))
    assert len(backups) >= 1
    assert key in backups[0].read_text()


# ---------------------------------------------------------------------
# restore_snapshot: restaura la estructura completa tal cual quedó.
# ---------------------------------------------------------------------

def test_restore_snapshot_rebuilds_tree(tmp_path, monkeypatch):
    import subprocess
    from backend.shares.services.share_backup_service import ShareBackupService

    origen = tmp_path / "origen"
    sub = origen / "Carpeta Gran" / "Nivel2"
    sub.mkdir(parents=True)
    (origen / "a.txt").write_text("a")
    (sub / "b.md").write_text("b")

    svc = ShareBackupService.__new__(ShareBackupService)
    job = {"id": 1, "source_path": str(origen), "name": "j", "repo": str(tmp_path / "repo")}
    svc._find_job = lambda jid: job
    svc.installed = lambda: True
    svc._ensure_repo = lambda j: None
    svc._repo_path = lambda j: str(tmp_path / "repo")
    env = {"RESTIC_PASSWORD": "k"}

    def fake_run(cmd, **kw):
        # Modo directo: restic restore --target / escribe en la ruta
        # absoluta original. Simulamos escribiendo en el origen real.
        import shutil
        target = cmd[cmd.index("--target") + 1]
        assert target == "/"
        shutil.copy2(origen / "a.txt", sub / "nuevo.txt")
        return subprocess.CompletedProcess(cmd, 0, "", "")

    monkeypatch.setattr(subprocess, "run", fake_run)
    svc._env = lambda: env

    r = svc.restore_snapshot(1, "fake-snap")
    assert r["success"] is True
    assert r.get("fast") is True
    # El modo directo no borra el origen; restic escribe sobre él.
    assert (sub / "nuevo.txt").read_text() == "a"


def test_restore_snapshot_target_copies_tree(tmp_path, monkeypatch):
    import subprocess
    from backend.shares.services.share_backup_service import ShareBackupService

    origen = tmp_path / "origen"
    (origen / "Carpeta" / "Nivel").mkdir(parents=True)
    (origen / "a.txt").write_text("a")
    (origen / "Carpeta" / "Nivel" / "b.md").write_text("b")

    svc = ShareBackupService.__new__(ShareBackupService)
    job = {"id": 1, "source_path": str(origen), "name": "j", "repo": str(tmp_path / "repo")}
    svc._find_job = lambda jid: job
    svc.installed = lambda: True
    svc._ensure_repo = lambda j: None
    svc._repo_path = lambda j: str(tmp_path / "repo")
    svc._env = lambda: {"RESTIC_PASSWORD": "k"}

    def fake_run(cmd, **kw):
        # Con target: restic vuelca a un staging; simulamos que bajo el
        # staging aparece la ruta absoluta del origen del job.
        staging = cmd[cmd.index("--target") + 1]
        import shutil, pathlib
        dest = pathlib.Path(staging) / str(origen).strip("/")
        dest.mkdir(parents=True, exist_ok=True)
        (dest / "Carpeta" / "Nivel").mkdir(parents=True, exist_ok=True)
        shutil.copy2(origen / "a.txt", dest / "a.txt")
        shutil.copy2(origen / "Carpeta" / "Nivel" / "b.md", dest / "Carpeta" / "Nivel" / "b.md")
        return subprocess.CompletedProcess(cmd, 0, "", "")

    monkeypatch.setattr(subprocess, "run", fake_run)

    destino = tmp_path / "recuperado"
    r = svc.restore_snapshot(1, "fake-snap", target=str(destino))
    assert r["success"] is True
    assert r.get("fast") is None
    assert (destino / "Carpeta" / "Nivel" / "b.md").read_text() == "b"


def test_restore_snapshot_clean_wipes_destination(tmp_path, monkeypatch):
    import subprocess
    from backend.shares.services.share_backup_service import ShareBackupService

    origen = tmp_path / "origen"
    origen.mkdir(parents=True)
    (origen / "a.txt").write_text("a")
    (origen / "basura.txt").write_text("zz")  # archivo sobrante
    (origen / "viejo").mkdir()
    (origen / "viejo" / "f").write_text("f")

    svc = ShareBackupService.__new__(ShareBackupService)
    job = {"id": 1, "source_path": str(origen), "name": "j", "repo": str(tmp_path / "repo")}
    svc._find_job = lambda jid: job
    svc.installed = lambda: True
    svc._ensure_repo = lambda j: None
    svc._repo_path = lambda j: str(tmp_path / "repo")
    svc._env = lambda: {"RESTIC_PASSWORD": "k"}

    calls = []
    def fake_run(cmd, **kw):
        calls.append(cmd)
        # El vaciado ocurre ANTES del restore; aquí solo devolvemos ok.
        return subprocess.CompletedProcess(cmd, 0, "", "")

    monkeypatch.setattr(subprocess, "run", fake_run)

    r = svc.restore_snapshot(1, "fake-snap", clean=True)
    assert r["success"] is True
    # clean vació el destino: no queda basura antes de restaurar.
    assert list(origen.iterdir()) == []
    assert calls and "restore" in calls[0]


# ---------------------------------------------------------------------
# _assert_destination_is_backup: solo destinos en particiones backup
# ---------------------------------------------------------------------

def test_destination_shared_is_rejected(tmp_path, monkeypatch):
    import os, sys
    sys.path.insert(0, "/home/paulan/stepad-nsp")
    os.chdir("/home/paulan/stepad-nsp")
    from datetime import datetime
    from backend.shares.models.network_share_volume import NetworkShareVolume
    from backend.shares.services.share_backup_service import ShareBackupService
    from fastapi import HTTPException

    mp_shared = tmp_path / "sh"
    mp_shared.mkdir()
    vol = NetworkShareVolume(name="s", device_path="/dev/sdz1",
                             device_uuid="u1", mountpoint=str(mp_shared),
                             sharing=True, mount_on_boot=True, purpose="shared",
                             updated_at=datetime.utcnow())
    class FakeSession:
        def query(self, model): return self
        def all(self): return [vol]
        def close(self): pass
    svc = ShareBackupService.__new__(ShareBackupService)
    try:
        svc._assert_destination_is_backup(FakeSession(), str(mp_shared / "Respaldo"))
        assert False, "se esperaba rechazo"
    except HTTPException:
        pass


# ---------------------------------------------------------------------
# Eliminar programación NO borra datos; purgar sí (con confirmación)
# ---------------------------------------------------------------------

def test_delete_job_keeps_repo(tmp_path, monkeypatch):
    import os, sys, json
    sys.path.insert(0, "/home/paulan/stepad-nsp")
    os.chdir("/home/paulan/stepad-nsp")
    from backend.shares.services.share_backup_service import (
        ShareBackupService, Job, _default_job,
    )

    vault = tmp_path / "Respaldo"
    repo = vault / ".backups" / "job-9"
    repo.mkdir(parents=True)
    (repo / "config").write_text("x")

    rec = dict(_default_job())
    rec.update({"id": 9, "source_path": str(tmp_path / "src"),
                "schedule_mode": "daily"})
    (vault / ".respaldo.json").write_text(json.dumps({"jobs": [dict(rec)]}))
    job = Job(rec, vault=vault)

    svc = ShareBackupService.__new__(ShareBackupService)
    svc._lock = __import__("threading").Lock()
    svc._find_job = lambda jid: job if jid == 9 else None
    svc._load_config = lambda v: {"jobs": [dict(rec)]}
    svc._save_config = lambda v, c: None

    svc.delete_job(9)
    # El repo DEBE seguir existiendo.
    assert repo.exists()
    assert (repo / "config").read_text() == "x"


def test_delete_job_and_repo_requires_confirm(tmp_path, monkeypatch):
    import os, sys, json
    sys.path.insert(0, "/home/paulan/stepad-nsp")
    os.chdir("/home/paulan/stepad-nsp")
    from fastapi import HTTPException
    from backend.shares.services.share_backup_service import (
        ShareBackupService, Job, _default_job,
    )

    vault = tmp_path / "Respaldo"
    repo = vault / ".backups" / "job-10"
    repo.mkdir(parents=True)
    (repo / "config").write_text("x")

    rec = dict(_default_job())
    rec.update({"id": 10, "source_path": str(tmp_path / "src"),
                "schedule_mode": "daily"})
    job = Job(rec, vault=vault)

    svc = ShareBackupService.__new__(ShareBackupService)
    svc._lock = __import__("threading").Lock()
    svc._running_jobs = set()
    svc._find_job = lambda jid: job
    svc._load_config = lambda v: {"jobs": [dict(rec)]}
    svc._save_config = lambda v, c: None
    svc._repo_path = lambda j: repo

    # Sin confirmación correcta -> 400 y el repo sigue.
    try:
        svc.delete_job_and_repo(10, confirm="borrar")
        assert False, "debería exigir confirmación"
    except HTTPException:
        pass
    assert repo.exists()

    # Con confirmación -> se eliminan programación y repo.
    svc.delete_job_and_repo(10, confirm="ELIMINAR")
    assert not repo.exists()


# ---------------------------------------------------------------------
# Samba apply: nunca bloquea el boot rechazando restart a ciegas
# ---------------------------------------------------------------------

def test_samba_apply_starts_when_inactive(tmp_path, monkeypatch):
    import os, sys
    sys.path.insert(0, "/home/paulan/stepad-nsp")
    os.chdir("/home/paulan/stepad-nsp")
    from backend.shares.providers.samba_share_provider import SambaShareProvider

    calls = []
    svc = SambaShareProvider()
    svc.is_installed = lambda: True
    svc._service_active = lambda unit: False
    def fake_systemctl(action, unit):
        calls.append((action, unit))
        return True
    svc._systemctl = fake_systemctl

    svc.apply(True)
    assert ("start", "smbd") in calls
    assert ("restart", "smbd") not in calls


def test_samba_apply_short_timeout(monkeypatch):
    import os, sys, subprocess
    sys.path.insert(0, "/home/paulan/stepad-nsp")
    os.chdir("/home/paulan/stepad-nsp")
    from backend.shares.providers.samba_share_provider import SambaShareProvider

    svc = SambaShareProvider.__new__(SambaShareProvider)
    captured = {}
    original_run = subprocess.run
    def fake_run(cmd, **kw):
        captured["timeout"] = kw.get("timeout")
        return original_run(["true"], **kw)
    monkeypatch.setattr(subprocess, "run", fake_run)
    svc._systemctl("start", "smbd")
    assert captured.get("timeout") == 8, f"timeout fue {captured.get(timeout)}"


# ---------------------------------------------------------------------
# 5. Regresión (v2.5.301): ids duplicados entre bóvedas y resolución del job
# ---------------------------------------------------------------------

def _service_with_vaults(tmp_path, monkeypatch, configs_by_vault):
    """Service real (sin __init__) con _vaults/_load_config apuntando a
    bóvedas de tmp_path dictadas por configs_by_vault: {vault_path: [jobs]}"""
    import threading as _th
    service = ShareBackupService.__new__(ShareBackupService)
    service._stop = False
    service._thread = None
    service._lock = _th.Lock()
    service._ids_renumbered = False
    service._running_jobs = set()
    service._running_since = {}
    service._active_protected_backups = 0
    service._last_reconcile = 0.0
    service._procs = {}
    service._cancel_requested = set()
    service._size_cache = {}
    service._progress = {}
    service._restore_status = {}
    service._last_size_error = None

    vaults = [__import__("pathlib").Path(v) for v in configs_by_vault]
    monkeypatch.setattr(service, "_vaults", lambda db=None: vaults)
    monkeypatch.setattr(
        service, "_load_config",
        lambda vault: {"schema": 1, "next_job_id": len(configs_by_vault[str(vault)]) + 1, "jobs": configs_by_vault[str(vault)]},
    )
    monkeypatch.setattr(service, "_save_config", lambda vault, cfg: None)
    monkeypatch.setattr(service, "_ensure_backup_vaults_mounted", lambda: None)
    monkeypatch.setattr(service, "installed", lambda: True)
    return service


def test_duplicate_job_ids_run_backup_job_executes_the_requested_vault(tmp_path, monkeypatch):
    src_a = tmp_path / "srcA"; src_a.mkdir()
    src_b = tmp_path / "srcB"; src_b.mkdir()
    vault_a = tmp_path / "a" / "Respaldo"; vault_a.mkdir(parents=True)
    vault_b = tmp_path / "b" / "Respaldo"; vault_b.mkdir(parents=True)
    jb = dict(_default_job())
    jb.update({"id": 1, "name": "job-B", "source_path": str(src_b), "schedule_mode": "daily"})
    service = _service_with_vaults(tmp_path, monkeypatch, {str(vault_a): [dict(jb, name="job-A", source_path=str(src_a))], str(vault_b): [jb]})

    executed = []
    monkeypatch.setattr(service, "_launch_run_thread", lambda job, **kw: executed.append(job.get("name")) or {"success": True, "running": True})

    job_b = Job(jb, vault=vault_b)
    service.run_backup_job(job_b, trigger="scheduled")
    assert executed == ["job-B"], "run_backup_job debe ejecutar EL job pedido, no el primero con ese id"


def test_ensure_unique_job_ids_renumbers_duplicates_and_renames_repo(tmp_path, monkeypatch):
    vault_a = tmp_path / "a" / "Respaldo"; vault_a.mkdir(parents=True)
    vault_b = tmp_path / "b" / "Respaldo"; vault_b.mkdir(parents=True)
    (vault_b / ".backups" / "job-1").mkdir(parents=True)

    ja = dict(_default_job()); ja.update({"id": 1, "name": "job-A"})
    jb = dict(_default_job()); jb.update({"id": 1, "name": "job-B"})
    configs = {str(vault_a): [ja], str(vault_b): [jb]}
    service = _service_with_vaults(tmp_path, monkeypatch, configs)

    service._ensure_unique_job_ids()

    # El segundo id=1 debe re-numerarse y su repo `.backups/job-1` moverse.
    assert configs[str(vault_a)][0]["id"] == 1
    assert configs[str(vault_b)][0]["id"] == 2
    assert not (vault_b / ".backups" / "job-1").exists()
    assert (vault_b / ".backups" / "job-2").exists()


# ---------------------------------------------------------------------
# 6. Mantenimiento dinámico por job (check / test-restore) + watchdog
# ---------------------------------------------------------------------

def test_maintenance_due_is_dynamic_per_job(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch)
    now = datetime(2026, 10, 3, 12, 0)

    # Nunca corrió y sin snapshot → NO due (no se verifica un repo vacío).
    job["last_check_at"] = None
    job["last_snapshot_id"] = None
    monkeypatch.setattr(service, "_latest_snapshot_id", lambda job: None)
    assert service._maintenance_due(job, "check", now) is False

    # Nunca corrió pero YA hay snapshot → due (primera vez con base).
    job["last_snapshot_id"] = "abc123"
    assert service._maintenance_due(job, "check", now) is True

    # Corrió hace 1 día (intervalo 7) → NO due.
    job["last_check_at"] = (now - timedelta(days=1)).isoformat()
    assert service._maintenance_due(job, "check", now) is False

    # Corrió hace 8 días → due.
    job["last_check_at"] = (now - timedelta(days=8)).isoformat()
    assert service._maintenance_due(job, "check", now) is True

    # Intervalo configurable por job (2 días): madura distinto.
    job["check_interval_days"] = 2
    job["last_check_at"] = (now - timedelta(days=3)).isoformat()
    assert service._maintenance_due(job, "check", now) is True
    job["last_check_at"] = (now - timedelta(days=1)).isoformat()
    assert service._maintenance_due(job, "check", now) is False

    # test_restore SIN scratch → nunca due (por más que esté habilitado).
    job["test_restore_enabled"] = True
    job["test_restore_scratch"] = ""
    job["test_restore_interval_days"] = 1
    job["last_test_restore_at"] = None
    assert service._maintenance_due(job, "test_restore", now) is False

    # Con scratch + intervalo cumplido → due.
    job["test_restore_scratch"] = "/var/tmp/mi-test"
    job["last_test_restore_at"] = (now - timedelta(days=2)).isoformat()
    assert service._maintenance_due(job, "test_restore", now) is True

    # Disabled explícito → NO due.
    job["check_enabled"] = False
    job["last_check_at"] = (now - timedelta(days=40)).isoformat()
    assert service._maintenance_due(job, "check", now) is False


def test_overdue_watchdog_alerts_once_and_resets(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "08:00"
    job["overdue_alerted"] = False
    alerts = []
    monkeypatch.setattr(service, "_raise_alert", lambda t, title, msg: alerts.append(t))
    monkeypatch.setattr(service, "_save_job", lambda j: None)

    now = datetime(2026, 10, 3, 9, 30)  # pasó la ventana 08:00

    # Nunca corrió hoy y ya pasó la ventana → overdue → alerta.
    job["last_backup_at"] = datetime(2026, 10, 2, 8, 0).isoformat()
    service._check_overdue_backup(job, now)
    assert BACKUP_OVERDUE_ALERT in alerts
    assert job["overdue_alerted"] is True

    # Segunda pasada: NO vuelve a alertar (una sola vez por evento).
    service._check_overdue_backup(job, now)
    assert alerts.count(BACKUP_OVERDUE_ALERT) == 1

    # Job corrió su ventana (last >= slot) → ya no overdue y el flag se limpia.
    job["last_backup_at"] = datetime(2026, 10, 3, 8, 0).isoformat()
    service._check_overdue_backup(job, now)
    assert job["overdue_alerted"] is False
    assert alerts.count(BACKUP_OVERDUE_ALERT) == 1

    # Intervalo: solo overdue si pasó >2x el intervalo.
    job2 = dict(job)
    job2["schedule_mode"] = "interval"
    job2["interval_minutes"] = 60
    job2["last_backup_at"] = (now - timedelta(minutes=121)).isoformat()
    service._check_overdue_backup(job2, now)
    assert job2["overdue_alerted"] is True


# ---------------------------------------------------------------------
# 7. Restauración "tal cual" sin directorios fantasmas (repo restic real)
# ---------------------------------------------------------------------

def _make_restic_service(vault):
    import threading as _th
    service = ShareBackupService.__new__(ShareBackupService)
    service._stop = False
    service._thread = None
    service._lock = _th.Lock()
    service._running_jobs = set()
    service._running_since = {}
    service._active_protected_backups = 0
    service._last_reconcile = 0.0
    service._procs = {}
    service._cancel_requested = set()
    service._size_cache = {}
    service._progress = {}
    service._restore_status = {}
    service._last_size_error = None
    service._ids_renumbered = False
    service._maintenance_active = set()
    service._maintenance_lock = _th.Lock()
    return service


def test_restore_flattens_absolute_paths_no_fantasma_dirs(tmp_path):
    import os, json as _json, subprocess as _sp
    from backend.shares.services.share_backup_service import BACKUP_SUBDIR

    os.environ["RESTIC_PASSWORD"] = "test"
    vault = tmp_path / "vault" / "Respaldo"
    repo = vault / BACKUP_SUBDIR / "job-1"
    repo.mkdir(parents=True)

    def restic(*args, cwd=tmp_path):
        env = {**os.environ, "RESTIC_PASSWORD": "test"}
        return _sp.run(["restic", "-r", str(repo), *args], capture_output=True, text=True, env=env, cwd=cwd)

    r = restic("init")
    assert r.returncode == 0, r.stderr

    # Origen con ruta absoluta "común" (simula /mnt/.../<M>): el snapshot
    # guarda esa ruta absoluta; al restaurar sin aplanar aparecerían los
    # prefijos anidados (directorios fantasmas).
    source = tmp_path / "M"
    (source / "dirA").mkdir(parents=True)
    (source / "dirA" / "a.txt").write_text("hola")
    (source / "b.txt").write_text("mundo")

    r = restic("backup", str(source), "--host", "stepad", "--tag", "job:1", "--json")
    assert r.returncode == 0, r.stderr
    snap = None
    for line in r.stdout.splitlines():
        payload = _json.loads(line)
        if payload.get("message_type") == "summary":
            snap = payload.get("snapshot_id")
    assert snap, "no se creó snapshot"

    service = _make_restic_service(vault)
    record = dict(_default_job())
    record.update({"id": 1, "name": "job-1", "source_path": str(source)})
    job = Job(record, vault=vault)
    monkeypatch = __import__("unittest.mock", fromlist=["monkeypatch"])
    service._find_job = lambda job_id: job
    service.installed = lambda: True
    service._password = lambda: "test"

    target = tmp_path / "target_destino"
    res = service.restore_snapshot(1, snap, target=str(target))
    assert res.get("running") is True

    for _ in range(120):
        st = service._restore_status.get(1) or {}
        if not st.get("running"):
            break
        __import__("time").sleep(0.5)
    st = service._restore_status.get(1) or {}
    assert st.get("error") is None, st.get("error")
    assert st.get("result", {}).get("success") is True

    # "tal cual": los archivos quedan EN LA RAÍZ del destino, sin prefijos
    # fantasma (tmp/.../M/...) y sin staging oculto.
    assert (target / "dirA" / "a.txt").read_text() == "hola"
    assert (target / "b.txt").read_text() == "mundo"
    assert not (target / ".stepad-restore.tmp").exists()
    leftovers = [p for p in target.rglob("*") if str(p).endswith("/M")
                 or "tmp" == p.name and p.is_dir()]
    assert not any(getattr(p, "name", "") == "mnt" and p.is_dir() for p in target.iterdir())


def test_find_restored_root_localiza_contenido_real(tmp_path):
    service = ShareBackupService.__new__(ShareBackupService)
    staging = tmp_path / "staging"
    (staging / "mnt" / "stepad-network" / "M" / "docs").mkdir(parents=True)
    (staging / "mnt" / "stepad-network" / "M" / "docs" / "x.txt").write_text("1")
    root = service._find_restored_root(staging, "/mnt/stepad-network/M")
    assert root is not None
    assert root == staging / "mnt" / "stepad-network" / "M"
    assert (root / "docs" / "x.txt").exists()


def _restic_wrap(tmp_path, vault):
    import os, json as _json, subprocess as _sp
    from backend.shares.services.share_backup_service import BACKUP_SUBDIR
    repo = vault / BACKUP_SUBDIR / "job-1"
    repo.mkdir(parents=True)
    def restic(*args):
        env = {**os.environ, "RESTIC_PASSWORD": "test"}
        return _sp.run(["restic", "-r", str(repo), *args], capture_output=True, text=True, env=env, cwd=tmp_path)
    r = restic("init")
    assert r.returncode == 0, r.stderr
    return restic, repo


def _make_svc_and_backup(tmp_path, name="M"):
    import os, json as _json
    from backend.shares.services.share_backup_service import BACKUP_SUBDIR
    vault = tmp_path / "vault" / "Respaldo"
    restic, repo = _restic_wrap(tmp_path, vault)
    source = tmp_path / name
    (source / "dirA").mkdir(parents=True, exist_ok=True)
    (source / "dirA" / "a.txt").write_text("hola")
    (source / "b.txt").write_text("mundo")
    r = restic("backup", str(source), "--host", "stepad", "--tag", "job:1", "--json")
    assert r.returncode == 0, r.stderr
    snap = None
    for line in r.stdout.splitlines():
        p = _json.loads(line)
        if p.get("message_type") == "summary":
            snap = p.get("snapshot_id")
    assert snap
    service = _make_restic_service(vault)
    record = dict(_default_job())
    record.update({"id": 1, "name": "job-1", "source_path": str(source)})
    job = Job(record, vault=vault)
    service._find_job = lambda job_id: job
    service.installed = lambda: True
    service._password = lambda: "test"
    return service, job, source, snap


def _await_restore(service, job_id):
    import time as _t
    for _ in range(120):
        st = service._restore_status.get(job_id) or {}
        if not st.get("running"):
            return st
        _t.sleep(0.5)
    return service._restore_status.get(job_id) or {}


def test_restore_to_origin_empty_is_allowed(tmp_path):
    import shutil as _sh
    service, job, source, snap = _make_svc_and_backup(tmp_path, name="M")
    # Simula disco origen reemplazado por uno VACÍO (mismo punto de montaje).
    _sh.rmtree(source, ignore_errors=True)
    source.mkdir(parents=True, exist_ok=True)
    res = service.restore_snapshot(1, snap, target="")
    assert res.get("running") is True
    st = _await_restore(service, 1)
    assert st.get("error") is None, st.get("error")
    assert st.get("result", {}).get("success") is True
    # "tal cual" en la ruta original (sin prefijos fantasma).
    assert (source / "dirA" / "a.txt").read_text() == "hola"
    assert (source / "b.txt").read_text() == "mundo"


def test_restore_to_origin_nonempty_is_rejected(tmp_path):
    service, job, source, snap = _make_svc_and_backup(tmp_path, name="N")
    try:
        service.restore_snapshot(1, snap, target="")
        assert False, "no debió permitir restaurar sobre el origen con datos"
    except Exception as exc:
        assert "ORIGEN" in str(exc) or "origen" in str(exc)


# ---------------------------------------------------------------------
# 8. Jobs óptimos: solo en la ventana del horario, sin catch-up fuera de hora
# ---------------------------------------------------------------------

def _daily_job(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_hour"] = 22
    job["schedule_minute"] = 0
    job["schedule_times"] = "22:00"
    job["last_backup_at"] = datetime(2026, 10, 2, 22, 0).isoformat()
    return service, job


def test_daily_job_runs_only_within_schedule_slot_window(tmp_path, monkeypatch):
    service, job = _daily_job(tmp_path, monkeypatch)
    base = datetime(2026, 10, 3, 22, 0)
    # Antes del horario: NO.
    assert service.is_due(job, base - timedelta(minutes=1)) is False
    # En el horario (dentro de la ventana): SÍ.
    assert service.is_due(job, base) is True
    assert service.is_due(job, base + timedelta(minutes=25)) is True
    # Fuera de la ventana (catch-up tarde): NO.
    assert service.is_due(job, base + timedelta(minutes=31)) is False
    assert service.is_due(job, base + timedelta(hours=1)) is False
    assert service.is_due(job, datetime(2026, 10, 3, 23, 30)) is False


def test_daily_job_runs_once_per_slot_even_inside_window(tmp_path, monkeypatch):
    service, job = _daily_job(tmp_path, monkeypatch)
    job["last_backup_at"] = datetime(2026, 10, 3, 22, 0).isoformat()  # ya corrió hoy
    # Dentro de la ventana pero ya respaldó el horario: NO repetir.
    assert service.is_due(job, datetime(2026, 10, 3, 22, 10)) is False


def test_daily_job_never_runs_late_after_a_missed_slot(tmp_path, monkeypatch):
    # Mismo horario pero múltiples slots: un slot perdido NO corre tarde;
    # el próximo slot de HOY todavía puede correr dentro de su ventana.
    service, job = _daily_job(tmp_path, monkeypatch)
    job["schedule_times"] = "13:30,20:00"
    job["last_backup_at"] = datetime(2026, 10, 2, 20, 0).isoformat()
    # A las 14:30 el slot 13:30 ya venció su ventana → NO corre.
    assert service.is_due(job, datetime(2026, 10, 3, 14, 30)) is False
    # Dentro de la ventana del 20:00 sí corre.
    assert service.is_due(job, datetime(2026, 10, 3, 20, 10)) is True
