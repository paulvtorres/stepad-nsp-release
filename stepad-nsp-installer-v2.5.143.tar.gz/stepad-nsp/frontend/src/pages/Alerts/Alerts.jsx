import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getAlerts,
    markAlertRead,
    markAllAlertsRead,
    quarantineAlert,
    downloadIntrusionDiagnosticScript,
    getAlertIgnoreRules,
    addAlertIgnoreRule,
    deleteAlertIgnoreRule
} from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./alerts.css";


function Alerts() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [alerts, setAlerts] = useState([]);

    const [unread, setUnread] = useState(0);

    const [loading, setLoading] = useState(false);

    const [severityFilter, setSeverityFilter] = useState("all");

    const [typeFilter, setTypeFilter] = useState("all");

    const [ignoredRules, setIgnoredRules] = useState([]);

    const [ignoredCount, setIgnoredCount] = useState(0);

    const [ignoreDialog, setIgnoreDialog] = useState(null);

    const [ignoreText, setIgnoreText] = useState("");

    const [ignoreMode, setIgnoreMode] = useState("exact");

    const [showIgnored, setShowIgnored] = useState(false);

    const [ignoring, setIgnoring] = useState(false);


    useEffect(() => {

        load();

        const timer = setInterval(load, 15000);

        return () => clearInterval(timer);

    }, []);


    async function load() {

        setLoading(true);

        try {

            const data = await getAlerts(200, false);

            setAlerts(data.alerts || []);

            setUnread(data.unread || 0);

            setIgnoredCount(data.ignored || 0);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    async function handleMarkRead(id) {

        await markAlertRead(id);

        setAlerts((prev) =>
            prev.map((a) => (a.id === id ? { ...a, read: true } : a))
        );

        setUnread((u) => Math.max(0, u - 1));

    }


    async function handleMarkAllRead() {

        await markAllAlertsRead();

        setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));

        setUnread(0);

    }


    useEffect(() => {

        loadIgnoreRules();

    }, []);


    async function loadIgnoreRules() {

        try {

            const data = await getAlertIgnoreRules();

            const rules = data.rules || [];

            setIgnoredRules(rules);

            setIgnoredCount(data.count || rules.length || 0);

        } catch (error) {

            console.error(error);

        }

    }


    function openIgnoreDialog(alert) {

        const signature = String(alert.title || alert.message || "");

        setIgnoreDialog(alert);

        setIgnoreText(signature.startsWith("IPS: ") ? signature.slice(5) : signature);

        setIgnoreMode("exact");

    }


    async function handleConfirmIgnore() {

        if (!ignoreDialog || !ignoreText.trim()) return;

        setIgnoring(true);

        try {

            const result = await addAlertIgnoreRule({

                match_field: "title",

                matcher: ignoreMode,

                value: ignoreMode === "exact"
                    ? String(ignoreDialog.title || "")
                    : ignoreText.trim(),

            });

            setIgnoreDialog(null);

            setIgnoreText("");

            await load();

            await loadIgnoreRules();

            window.alert(
                "Tipo de mensaje silenciado.\n\n" +
                (result.removed
                    ? `Se eliminaron ${result.removed} alertas guardadas de este tipo.`
                    : "De ahora en más, este tipo de mensaje ya no genera alertas.")
            );

        } catch (error) {

            window.alert("No se pudo silenciar: " + (error.message || "error"));

        } finally {

            setIgnoring(false);

        }

    }


    async function handleUnignore(rule) {

        if (!window.confirm(`¿Dejar de ignorar el tipo "${rule.value}"?`)) return;

        try {

            await deleteAlertIgnoreRule(rule.id);

            await loadIgnoreRules();

            await load();

        } catch (error) {

            window.alert("No se pudo quitar: " + (error.message || "error"));

        }

    }


    async function handleDownloadIntrusionScript() {

        try {

            const blob = await downloadIntrusionDiagnosticScript();

            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");

            link.href = url;

            link.download = "diagnostico_intrusos.ps1";

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        } catch (error) {

            window.alert(
                "No se pudo descargar el script: " + (error.message || "error")
            );

        }

    }


    async function handleQuarantine(alert) {

        const ok = window.confirm(
            "¿Aislar el equipo que originó esta alerta?\n\n" +
            alert.title + "\n\n" +
            "Se bloqueará su acceso a la red hasta que lo desbloquees."
        );

        if (!ok) return;

        try {

            const result = await quarantineAlert(alert.id);

            window.alert(
                "Equipo aislado: " + (result.device || "") +
                " (" + (result.ip || "") + ")"
            );

            load();

        } catch (error) {

            window.alert(
                "No se pudo aislar: " + (error.message || "error")
            );

        }

    }


    const SEVERITY_RANK = { critical: 0, warning: 1, info: 2 };


    const filtered = alerts
        .filter((alert) => {

            if (severityFilter !== "all" && alert.severity !== severityFilter) {

                return false;

            }

            if (typeFilter !== "all" && alert.type !== typeFilter) {

                return false;

            }

            return true;

        })
        // Prioridad primero: no leídas antes que leídas, y dentro de
        // cada grupo, críticas antes que advertencias/info. Así una
        // amenaza (mineria/malware) aparece siempre arriba sin importar
        // cuando llegaron otras alertas menores.
        .sort((a, b) => {

            if (a.read !== b.read) return a.read ? 1 : -1;

            const rankDiff = (SEVERITY_RANK[a.severity] ?? 3) -
                (SEVERITY_RANK[b.severity] ?? 3);

            if (rankDiff !== 0) return rankDiff;

            return b.id - a.id;

        });


    const types = [...new Set(alerts.map((a) => a.type || "otro"))];


    function consultSignature(alert) {

        const signature = (alert.message || alert.title || "")
            .split("|")[0]
            .trim();

        window.open(
            "https://www.google.com/search?q=" +
            encodeURIComponent(signature),
            "_blank"
        );

    }


    return (

        <div className="alerts-page">

            <div className="alerts-page-header">

                <div>

                    <h2>Alertas</h2>

                    <p>
                        Alertas de seguridad del IPS y del sistema. En las del IPS puedes
                        <strong> aislar el equipo</strong> que las originó de inmediato.
                    </p>

                </div>

                <div className="alerts-page-controls">

                    <label>
                        Severidad
                        <select
                            value={severityFilter}
                            onChange={(e) => setSeverityFilter(e.target.value)}
                        >
                            <option value="all">Todas</option>
                            <option value="critical">Crítica</option>
                            <option value="warning">Advertencia</option>
                            <option value="info">Info</option>
                        </select>
                    </label>

                    <label>
                        Tipo
                        <select
                            value={typeFilter}
                            onChange={(e) => setTypeFilter(e.target.value)}
                        >
                            <option value="all">Todos</option>
                            {
                                types.map((t) => (
                                    <option key={t} value={t}>{t}</option>
                                ))
                            }
                        </select>
                    </label>

                    {
                        unread > 0 && (
                            <button
                                className="alerts-mark-read"
                                onClick={handleMarkAllRead}
                            >
                                Marcar todas leídas ({unread})
                            </button>
                        )
                    }

                    {
                        ignoredCount > 0 && (
                            <button
                                className="alerts-mark-read"
                                onClick={() => setShowIgnored(true)}
                                title="Ver los tipos de mensaje silenciados"
                            >
                                Silenciados ({ignoredCount})
                            </button>
                        )
                    }

                </div>

            </div>


            <div className="alerts-page-help">

                <div className="alerts-page-help-title">
                    ¿Qué significa una alerta y cómo actuar?
                </div>

                <p>
                    Cada alerta es una firma de seguridad (de Suricata/IPS) detectada en un
                    equipo. Para entender <strong>el detalle específico</strong> de una alerta,
                    pulsa <strong>"Consultar firma"</strong> en ella: busca el mensaje exacto
                    en internet y verás qué indica y cómo se conoce.
                </p>

                <ol>
                    <li>Revisa el <strong>equipo origen</strong> indicado en la alerta.</li>
                    <li>Pulsa <strong>"Consultar firma"</strong> para leer qué significa ese mensaje concreto.</li>
                    <li>Si es crítica o se repite, <strong>"Aislar equipo"</strong> para cortar al equipo de la red.</li>
                    <li>Escanea el equipo con antivirus y decide si desbloquearlo.</li>
                </ol>

            </div>

            {
                isAdmin && (
                    <div className="alerts-page-tools">

                        <div>
                            <div className="alerts-page-tools-title">
                                ¿Sospechas que un equipo Windows fue intervenido?
                            </div>
                            <p>
                                Descarga este script y ejecútalo en el equipo sospechoso.
                                Revisa acceso remoto no autorizado (AnyDesk, TeamViewer, RDP),
                                cuentas de administrador nuevas e inicios de sesión remotos.
                                Es solo de diagnóstico: no borra ni detiene nada.
                            </p>
                        </div>

                        <button
                            className="alerts-page-tools-download"
                            onClick={handleDownloadIntrusionScript}
                        >
                            Descargar script de diagnóstico de intrusos
                        </button>

                    </div>
                )
            }


            {
                !loading && filtered.length === 0 ? (
                    <p className="alerts-empty">Sin alertas.</p>
                ) : (
                    <ul className="alerts-page-list">

                        {
                            filtered.map((alert) => (

                                <li
                                    key={alert.id}
                                    className={`alerts-page-item severity-${alert.severity} ${alert.read ? "read" : ""}`}
                                >

                                    <div className="alerts-page-sev">
                                        {alert.severity}
                                    </div>

                                    <div className="alerts-page-body">

                                        <div className="alerts-page-title">
                                            {
                                                alert.severity === "critical" && !alert.read && (
                                                    <span className="alerts-page-priority-badge">
                                                        Prioridad
                                                    </span>
                                                )
                                            }
                                            {alert.title}
                                        </div>

                                        {
                                            alert.device_name && (
                                                <div className="alerts-page-device">
                                                    Equipo: <strong>{alert.device_name}</strong>
                                                    {alert.device_ip ? ` (${alert.device_ip})` : ""}
                                                </div>
                                            )
                                        }

                                        {
                                            alert.message && alert.message !== alert.title && (
                                                <div className="alerts-page-message">
                                                    {alert.message}
                                                </div>
                                            )
                                        }

                                        {
                                            alert.guidance &&
                                            (alert.type === "suricata" ||
                                                alert.type === "SECURITY_DNS_THREAT") && (
                                                <details className="alerts-page-guidance">
                                                    <summary>
                                                        {alert.guidance.tipo} — qué hacer
                                                    </summary>
                                                    <p>{alert.guidance.explicacion}</p>
                                                    <ul>
                                                        {
                                                            (alert.guidance.acciones || []).map((accion, idx) => (
                                                                <li key={idx}>{accion}</li>
                                                            ))
                                                        }
                                                    </ul>
                                                </details>
                                            )
                                        }

                                        <div className="alerts-page-meta">
                                            {alert.created_at_ec || formatDateTime(alert.created_at)}
                                            {" · "}
                                            hora Ecuador
                                            {" · "}
                                            tipo: {alert.type || "otro"}
                                        </div>

                                    </div>

                                    <div className="alerts-page-actions">

                                        {
                                            isAdmin && (
                                                <button
                                                    className="alerts-page-ignore"
                                                    onClick={() => openIgnoreDialog(alert)}
                                                    title="No crear más mensajes de este tipo"
                                                >
                                                    Silenciar tipo
                                                </button>
                                            )
                                        }

                                        {
                                            alert.type === "suricata" && (
                                                <button
                                                    className="alerts-page-consult"
                                                    onClick={() => consultSignature(alert)}
                                                    title="Buscar el detalle específico de esta firma"
                                                >
                                                    Consultar firma
                                                </button>
                                            )
                                        }

                                        {
                                            alert.type === "suricata" && isAdmin &&
                                            (alert.severity === "critical" || alert.severity === "warning") && (
                                                <button
                                                    className="alerts-page-quarantine"
                                                    onClick={() => handleQuarantine(alert)}
                                                    title="Aislar el equipo que originó esta alerta"
                                                >
                                                    Aislar equipo
                                                </button>
                                            )
                                        }

                                        {
                                            !alert.read && (
                                                <button
                                                    className="alerts-page-read"
                                                    onClick={() => handleMarkRead(alert.id)}
                                                >
                                                    Marcar leída
                                                </button>
                                            )
                                        }

                                    </div>

                                </li>

                            ))
                        }

                    </ul>
                )
            }

            {
                ignoreDialog && (
                    <div className="alerts-overlay">
                        <div className="alerts-dialog">
                            <h3>Silenciar este tipo de mensaje</h3>
                            <p className="alerts-dialog-sub">
                                {ignoreDialog.title}
                            </p>
                            <p>
                                Los mensajes de este tipo dejarán de crearse de aquí en
                                adelante. Las alertas ya guardadas que coincidan se
                                eliminarán del panel.
                            </p>

                            {
                                ignoreDialog.severity === "critical" && (
                                    <p className="alerts-dialog-warn">
                                        Alerta de severidad crítica: silenciar este tipo
                                        ocultará posibles amenazas reales. Verificá que no sea un
                                        falso positivo antes de continuar.
                                    </p>
                                )
                            }

                            <label className="alerts-radio-row">
                                <input
                                    type="radio"
                                    name="ignore-mode"
                                    checked={ignoreMode === "exact"}
                                    onChange={() => setIgnoreMode("exact")}
                                />
                                <span>Solo este mensaje exacto</span>
                            </label>

                            <label className="alerts-radio-row">
                                <input
                                    type="radio"
                                    name="ignore-mode"
                                    checked={ignoreMode === "contains"}
                                    onChange={() => setIgnoreMode("contains")}
                                />
                                <span>Los mensajes que contengan el texto:</span>
                            </label>

                            <input
                                className="alerts-dialog-input"
                                type="text"
                                value={ignoreText}
                                onChange={(e) => setIgnoreText(e.target.value)}
                                placeholder="firma o fragmento"
                            />

                            <div className="alerts-dialog-actions">
                                <button
                                    className="alerts-btn-cancel"
                                    onClick={() => setIgnoreDialog(null)}
                                >
                                    Cancelar
                                </button>
                                <button
                                    className="alerts-btn-go"
                                    onClick={handleConfirmIgnore}
                                    disabled={ignoring || !ignoreText.trim()}
                                >
                                    {ignoring ? "Silenciando..." : "Silenciar"}
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {
                showIgnored && (
                    <div className="alerts-overlay">
                        <div className="alerts-dialog">
                            <h3>Tipos de mensaje silenciados</h3>

                            {
                                ignoredRules.length === 0 ? (
                                    <p className="alerts-empty">No hay tipos silenciados.</p>
                                ) : (
                                    <ul className="alerts-ignored-list">
                                        {
                                            ignoredRules.map((rule) => (
                                                <li key={rule.id}>
                                                    <div>
                                                        <strong>{rule.value}</strong>
                                                        <span>
                                                            {rule.matcher === "contains" ? "contiene" : "exacto"} · campo {rule.match_field}
                                                        </span>
                                                    </div>
                                                    <button
                                                        className="alerts-btn-unignore"
                                                        onClick={() => handleUnignore(rule)}
                                                    >
                                                        Dejar de ignorar
                                                    </button>
                                                </li>
                                            ))
                                        }
                                    </ul>
                                )
                            }

                            <div className="alerts-dialog-actions">
                                <button
                                    className="alerts-btn-cancel"
                                    onClick={() => setShowIgnored(false)}
                                >
                                    Cerrar
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

        </div>

    );

}


export default Alerts;
