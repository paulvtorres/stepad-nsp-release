from sqlalchemy.orm import Session

from backend.alerts.models.alert import Alert
from backend.alerts.models.alert_ignore_rule import AlertIgnoreRule


class AlertRepository:

    MAX_ALERTS = 500

    def create(
        self,
        db: Session,
        alert: Alert
    ):

        db.add(alert)

        db.commit()

        db.refresh(alert)

        # Keep the table bounded.
        stale = (
            db.query(Alert.id)
            .order_by(Alert.id.desc())
            .offset(self.MAX_ALERTS)
            .all()
        )

        if stale:

            oldest_keep = stale[-1][0]

            db.query(Alert).filter(Alert.id < oldest_keep).delete(
                synchronize_session=False
            )

            db.commit()

        return alert

    def list(
        self,
        db: Session,
        limit: int = 50,
        unread_only: bool = False
    ):

        query = db.query(Alert)

        if unread_only:

            query = query.filter(Alert.read.is_(False))

        return (
            query
            .order_by(Alert.id.desc())
            .limit(limit)
            .all()
        )

    def unread_count(
        self,
        db: Session
    ):

        return (
            db.query(Alert.id)
            .filter(Alert.read.is_(False))
            .count()
        )

    def mark_read(
        self,
        db: Session,
        alert_id: int
    ):

        alert = db.get(Alert, alert_id)

        if alert is None:

            return None

        alert.read = True

        db.commit()

        db.refresh(alert)

        return alert

    def mark_all_read(
        self,
        db: Session
    ):

        db.query(Alert).filter(Alert.read.is_(False)).update(
            {Alert.read: True},
            synchronize_session=False
        )

        db.commit()

    def list_ignore_rules(
        self,
        db: Session
    ):

        return (
            db.query(AlertIgnoreRule)
            .order_by(AlertIgnoreRule.id.desc())
            .all()
        )

    def add_ignore_rule(
        self,
        db: Session,
        match_field: str,
        matcher: str,
        value: str
    ):

        rule = AlertIgnoreRule(
            match_field=match_field,
            matcher=matcher,
            value=value
        )

        db.add(rule)

        db.commit()

        db.refresh(rule)

        return rule

    def delete_ignore_rule(
        self,
        db: Session,
        rule_id: int
    ):

        rule = db.get(AlertIgnoreRule, rule_id)

        if rule is None:

            return False

        db.delete(rule)

        db.commit()

        return True

    def is_ignored(
        self,
        db: Session,
        alert_type: str,
        title: str
    ):

        rules = db.query(AlertIgnoreRule).all()

        for rule in rules:

            target = alert_type if rule.match_field == "alert_type" else title

            if not target:
                continue

            if rule.matcher == "contains":

                if rule.value and rule.value.lower() in target.lower():
                    return True

            elif target == rule.value:

                return True

        return False

    def delete_ignored_alerts_for_rule(
        self,
        db: Session,
        rule_id: int
    ):

        rule = db.get(AlertIgnoreRule, rule_id)

        if rule is None:
            return 0

        query = db.query(Alert)

        if rule.match_field == "alert_type":
            column = Alert.alert_type
        else:
            column = Alert.title

        if rule.matcher == "contains":
            query = query.filter(column.ilike(f"%{rule.value}%"))
        else:
            query = query.filter(column == rule.value)

        rows = query.delete(synchronize_session=False)

        db.commit()

        return int(rows or 0)
