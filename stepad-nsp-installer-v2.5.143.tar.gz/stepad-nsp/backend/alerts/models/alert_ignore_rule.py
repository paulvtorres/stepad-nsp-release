from datetime import datetime

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class AlertIgnoreRule(Base):

    __tablename__ = "alert_ignore_rules"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # title | alert_type
    match_field: Mapped[str] = mapped_column(
        String(20),
        nullable=False
    )

    # exact | contains
    matcher: Mapped[str] = mapped_column(
        String(20),
        nullable=False
    )

    value: Mapped[str] = mapped_column(
        String(255),
        nullable=False
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
