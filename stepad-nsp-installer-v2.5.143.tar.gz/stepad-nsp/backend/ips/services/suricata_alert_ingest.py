import json
import time
import ipaddress

from datetime import datetime

from pathlib import Path

from sqlalchemy.dialects.postgresql import insert as pg_insert

from backend.core.database.session import SessionLocal

from backend.alerts.services.alert_service import AlertService

from backend.notifications.services.critical_alert_email_service import (
    CriticalAlertEmailService,
)

from backend.siem.services.syslog_service import SyslogService

from backend.shared.logging.logger import logger

from backend.ips.services.threat_response_service import (
    threat_response_service
)

from backend.ips.services.attack_response_service import (
    attack_response_service
)

from backend.ips.models.inbound_attack_event import InboundAttackEvent


EVE_LOG = Path("/var/log/suricata/eve.json")

STATE_FILE = Path("/etc/stepad/ips/eve_offset")

DEDUPE_WINDOW_SECONDS = 1800

POLL_INTERVAL = 20


class SuricataAlertIngest:


    def __init__(self):

        self.alert_service = AlertService()

        self.critical_alert_email = CriticalAlertEmailService()

        self.syslog_service = SyslogService()

        self._recent = {}

        self._offset = 0

        self._load_offset()


    def _load_offset(self):

        try:

            self._offset = int(
                STATE_FILE.read_text().strip()
            )

        except Exception:

            # Primera vez: empezar desde el final del archivo para no
            # ingestar el historial anterior a la instalacion.
            try:

                if EVE_LOG.exists():

                    self._offset = EVE_LOG.stat().st_size

            except Exception:

                self._offset = 0


    def _save_offset(self):

        try:

            STATE_FILE.parent.mkdir(
                parents=True,
                exist_ok=True
            )

            STATE_FILE.write_text(str(self._offset))

        except Exception as error:

            logger.warning(
                "No pude guardar el offset de eve.json: %s",
                error
            )


    def _severity(
        self,
        suricata_severity
    ):

        mapping = {
            1: "critical",
            2: "warning",
        }

        return mapping.get(suricata_severity, "info")


    def _is_external(self, ip: str) -> bool:

        try:

            return ipaddress.ip_address(ip).is_global

        except ValueError:

            return False


    def _is_own_ip(self, ip: str) -> bool:

        try:

            import socket

            if ip == socket.gethostbyname(socket.gethostname()):

                return True

            addresses = socket.gethostbyname_ex(
                socket.gethostname()
            )[2]

            return ip in addresses

        except Exception:

            return False


    def _is_inbound_attack(
        self,
        src_ip: str,
        dst_ip: str
    ) -> bool:

        if not self._is_external(src_ip):

            return False

        if not dst_ip:

            return False

        try:

            dst = ipaddress.ip_address(dst_ip)

        except ValueError:

            return False

        if dst.is_global:

            # Un destino "global" puede ser el propio IP del NSP: los
            # ataques directos a este equipo también interesan.
            return self._is_own_ip(dst_ip)

        return True


    def _record_inbound_event(
        self,
        db,
        event: dict,
        severity: str
    ):

        alert = event.get("alert", {})

        signature = (alert.get("signature") or "Deteccion IPS")[:255]

        category = (alert.get("category") or "")[:128] or None

        src_ip = event.get("src_ip", "")

        src_port = event.get("src_port")

        dst_port = event.get("dest_port")

        protocol = (event.get("proto") or "tcp")[:16]

        now = datetime.utcnow()

        statement = pg_insert(InboundAttackEvent).values(
            src_ip=src_ip,
            src_port=src_port,
            dst_port=dst_port,
            protocol=protocol,
            signature=signature,
            category=category,
            severity=severity,
            action="alert",
            first_seen=now,
            last_seen=now,
            hit_count=1,
        )

        statement = statement.on_conflict_do_update(
            constraint="uq_inbound_attack_agg",
            set_={
                "hit_count": InboundAttackEvent.hit_count + 1,
                "last_seen": now,
                "severity": severity,
            },
        )

        db.execute(statement)

        db.commit()


    def _handle_inbound(
        self,
        db,
        event: dict,
        severity: str
    ):

        src_ip = event.get("src_ip", "")

        dst_ip = event.get("dest_ip", "")

        if not self._is_inbound_attack(src_ip, dst_ip):

            return

        try:

            self._record_inbound_event(db, event, severity)

            if not attack_response_service.get_auto_block(db):

                return

            if attack_response_service.is_blocked(db, src_ip) is not None:

                return

            signature = (
                event.get("alert", {}).get("signature", "")
            )[:200]

            attack_response_service.block(
                db,
                src_ip,
                source="auto",
                reason=signature,
            )

        except Exception as error:

            logger.warning(
                "Captura de ataque entrante fallo: %s",
                error,
            )


    def _process_event(
        self,
        event
    ):

        if event.get("event_type") != "alert":

            return

        alert = event.get("alert", {})

        signature = alert.get("signature", "Deteccion IPS")

        category = alert.get("category", "")

        src_ip = event.get("src_ip", "")

        dst_ip = event.get("dest_ip", "")

        dst_port = event.get("dest_port", "")

        key = (
            signature,
            src_ip,
            dst_ip
        )

        now = time.time()

        last = self._recent.get(key)

        if last and now - last < DEDUPE_WINDOW_SECONDS:

            return

        self._recent[key] = now

        severity = self._severity(alert.get("severity"))

        title = f"IPS: {signature}"[:255]

        message = (
            f"{signature} | {category} | "
            f"{src_ip} -> {dst_ip}:{dst_port}"
        )[:500]

        db = SessionLocal()

        try:

            try:

                threat_response_service.handle_event(db, event)

            except Exception as error:

                logger.exception(
                    "Fallo la respuesta ante amenazas: %s",
                    error
                )

            alert_created = self.alert_service.create(
                db,
                alert_type="suricata",
                severity=severity,
                title=title,
                message=message
            )

            # Si el tipo de mensaje está silenciado en Alertas, no se
            # crea la alerta ni se reenvía al buzón syslog/SIEM.
            if alert_created is not None:

                try:

                    self.syslog_service.forward_ips_alert(
                        db,
                        event,
                        severity,
                    )

                except Exception as error:

                    logger.warning(
                        "Fallo reenvio syslog de alerta IPS: %s",
                        error,
                    )

            # Ataque entrante: queda registrado y, si el admin lo
            # activo, la IP del atacante se bloquea automaticamente.
            if severity in ("critical", "warning"):

                self._handle_inbound(db, event, severity)

        finally:

            db.close()

        threat_response_service.resync_if_stale()

        if severity == "critical":

            self._notify_critical(title, message)


    def _notify_critical(
        self,
        title: str,
        message: str
    ):

        try:

            db = SessionLocal()

            try:

                self.critical_alert_email.send(
                    db,
                    title,
                    message,
                    html_body=f"<h3>{title}</h3><pre>{message}</pre>",
                )

            finally:

                db.close()

        except Exception as error:

            logger.error(
                "Fallo la notificacion critica del IPS: %s",
                error
            )


    def poll_once(self):

        try:

            if not EVE_LOG.exists():

                return

            size = EVE_LOG.stat().st_size

            if size < self._offset:
                logger.warning(
                    "eve.json (alertas) rotado o truncado "
                    f"(size={size}, offset={self._offset}); "
                    "se reinicia el offset al final del fichero."
                )
                self._offset = size
                self._save_offset()

            if size <= self._offset:

                return

            with open(EVE_LOG, "r") as file:

                file.seek(self._offset)

                for line in file:

                    line = line.strip()

                    if not line:

                        continue

                    try:

                        event = json.loads(line)

                    except ValueError:

                        continue

                    self._process_event(event)

                self._offset = file.tell()

            self._save_offset()

        except Exception as error:

            logger.error(
                "Error al leer eve.json de Suricata: %s",
                error
            )


    def run_forever(self):

        logger.info(
            "Ingesta de alertas Suricata iniciada (eve.json)."
        )

        while True:

            try:

                self.poll_once()

            except Exception as error:

                logger.exception(
                    "Error en el bucle de Suricata: %s",
                    error
                )

            time.sleep(POLL_INTERVAL)
