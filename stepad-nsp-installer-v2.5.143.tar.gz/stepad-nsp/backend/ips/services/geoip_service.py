import urllib.request
import threading
import gzip

from datetime import datetime

from pathlib import Path

import sqlalchemy as sa

from backend.core.database.connection import engine
from backend.core.database.session import SessionLocal
from backend.ips.models.ip_geo_asn import IpGeoAsn
from backend.shared.logging.logger import logger


DATASET_URL = "https://iptoasn.com/data/ip2asn-v4.tsv.gz"

GEO_DIR = Path("/etc/stepad/geoip")

DATASET_FILE = GEO_DIR / "ip2asn-v4.tsv.gz"

REFRESH_AFTER_DAYS = 7


class GeoipService:
    """
    Geolocalizacion SIN depender de APIs externas en cada consulta:
    descarga el dataset publico de iptoasn.com (rangos -> ASN + pais +
    organizacion, ~1M filas) a disco y lo importa a la tabla ip_geo_asn.
    La busqueda por IP es local, con indice sobre start_ip.
    """

    def __init__(self):

        self._lock = threading.Lock()

        self._importing = False

        self._cache = {}

        self.meta = {
            "rows": 0,
            "updated_at": None,
            "source": DATASET_URL,
            "loading": False,
            "path": str(DATASET_FILE),
        }

        self._count_rows()

    def _count_rows(self):

        try:

            db = SessionLocal()

            try:

                self.meta["rows"] = db.query(IpGeoAsn).count()

                self.meta["updated_at"] = self._file_mtime()

            finally:

                db.close()

        except Exception:

            self.meta["rows"] = 0

    def _file_mtime(self):

        try:

            import time

            return datetime.utcfromtimestamp(
                DATASET_FILE.stat().st_mtime
            )

        except Exception:

            return None

    # ------------------------------------------------------------------
    # Dataset
    # ------------------------------------------------------------------

    def ensure_dataset(self, force: bool = False):

        if self._importing:

            return

        if not force and self.meta.get("rows", 0) > 0 and not self._stale():

            return

        with self._lock:

            if self._importing:

                return

            self._importing = True

            self.meta["loading"] = True

        threading.Thread(
            target=self._import_worker,
            name="geoip-import",
            daemon=True,
        ).start()

    def _stale(self) -> bool:

        updated = self.meta.get("updated_at")

        if not updated or self.meta.get("rows", 0) == 0:

            return True

        return (datetime.utcnow() - updated).days >= REFRESH_AFTER_DAYS

    def _download(self):

        GEO_DIR.mkdir(parents=True, exist_ok=True)

        tmp = DATASET_FILE.with_suffix(".gz.tmp")

        request = urllib.request.Request(
            DATASET_URL,
            headers={"User-Agent": "STEPAD-NSP/1.0"},
        )

        with urllib.request.urlopen(request, timeout=90) as response:

            tmp.write_bytes(response.read())

        tmp.replace(DATASET_FILE)

    def _parse(self) -> list[tuple]:

        rows = []

        with gzip.open(DATASET_FILE, "rt", encoding="utf-8", errors="ignore") as handle:

            for line in handle:

                if not line.strip():

                    continue

                parts = line.rstrip("\n").split("\t")

                if len(parts) < 4:

                    continue

                start = self._ip_int(parts[0])

                end = self._ip_int(parts[1])

                if start is None or end is None:

                    continue

                try:

                    asn = int(parts[2]) if parts[2] != "-" else None

                except ValueError:

                    asn = None

                country = (parts[3] or "").upper()[:2] or None

                org = (parts[4] if len(parts) > 4 else "").strip()

                rows.append((start, end, asn, country, (org[:255] or None)))

        return rows

    def _import_worker(self):

        try:

            try:

                self._download()

            except Exception as error:

                logger.warning(
                    "GeoIP: no pude descargar el dataset (%s); "
                    "uso el local si existe.",
                    error,
                )

            if not DATASET_FILE.exists():

                logger.warning(
                    "GeoIP: sin dataset de paises/ASN (iptoasn). "
                    "Las IPs se mostraran sin origen geografico."
                )

                return

            rows = self._parse()

            self._replace_table(rows)

            self._cache.clear()

            self.meta["rows"] = len(rows)

            self.meta["updated_at"] = self._file_mtime() or datetime.utcnow()

            logger.info(
                "GeoIP: %s rangos importados (pais/ASN/organizacion).",
                len(rows),
            )

        except Exception as error:

            logger.error("GeoIP: fallo la importacion: %s", error)

        finally:

            self._importing = False

            self.meta["loading"] = False

    def _replace_table(self, rows: list[tuple]):

        db = SessionLocal()

        try:

            db.execute(sa.text("DELETE FROM ip_geo_asn"))

            db.commit()

        finally:

            db.close()

        connection = engine.raw_connection()

        try:

            import psycopg2.extras

            cursor = connection.cursor()

            psycopg2.extras.execute_values(
                cursor,
                "INSERT INTO ip_geo_asn"
                " (start_ip, end_ip, asn, country, as_org)"
                " VALUES %s",
                rows,
                page_size=10000,
            )

            connection.commit()

        finally:

            connection.close()

    # ------------------------------------------------------------------
    # Consulta
    # ------------------------------------------------------------------

    @staticmethod
    def _ip_int(value: str) -> int | None:

        try:

            address = __import__("ipaddress").ip_address(value.strip())

            if address.version != 4:

                return None

            return int(address)

        except ValueError:

            return None

    def lookup(self, ip: str) -> dict | None:

        key = (ip or "").strip()

        if not key:

            return None

        if key in self._cache:

            return self._cache[key]

        result = None

        ip_int = self._ip_int(key)

        if ip_int is not None:

            db = SessionLocal()

            try:

                row = (
                    db.query(IpGeoAsn)
                    .filter(
                        IpGeoAsn.start_ip <= ip_int,
                        IpGeoAsn.end_ip >= ip_int,
                    )
                    .order_by((IpGeoAsn.end_ip - IpGeoAsn.start_ip).asc())
                    .first()
                )

                if row is not None:

                    result = {
                        "ip": key,
                        "country": row.country,
                        "asn": row.asn,
                        "as_org": row.as_org,
                    }

            except Exception:

                result = None

            finally:

                db.close()

        self._cache[key] = result

        if len(self._cache) > 5000:

            self._cache.clear()

        return result

    def enrich(self, ip: str) -> dict:

        info = self.lookup(ip) or {}

        country = info.get("country")

        org = info.get("as_org")

        asn = info.get("asn")

        return {
            "ip": ip,
            "country": country,
            "asn": asn,
            "as_org": org,
            "geo_known": bool(country or org),
        }


geoip_service = GeoipService()