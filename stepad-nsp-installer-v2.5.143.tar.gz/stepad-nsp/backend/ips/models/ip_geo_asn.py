from sqlalchemy import BigInteger, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class IpGeoAsn(Base):
    """Rangos IP -> ASN/pais/organizacion (dataset publico iptoasn.com)."""

    __tablename__ = "ip_geo_asn"

    id: Mapped[int] = mapped_column(
        BigInteger,
        primary_key=True,
        autoincrement=True
    )

    start_ip: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True
    )

    end_ip: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False
    )

    asn: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    country: Mapped[str | None] = mapped_column(String(2), nullable=True)

    as_org: Mapped[str | None] = mapped_column(String(255), nullable=True)