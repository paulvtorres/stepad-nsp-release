from datetime import datetime

from sqlalchemy import String, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class AttackBlockedIp(Base):

    __tablename__ = "attack_blocked_ips"

    ip: Mapped[str] = mapped_column(
        String(45),
        primary_key=True
    )

    # "manual" (accion del admin en la UI) | "auto" (IPS entrante con
    # la opcion "bloquear IP atacante" activada).
    rule_source: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        default="manual"
    )

    reason: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    created_by: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=datetime.utcnow
    )