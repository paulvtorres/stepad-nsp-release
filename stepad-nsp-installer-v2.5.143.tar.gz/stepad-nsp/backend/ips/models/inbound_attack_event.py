from datetime import datetime

from sqlalchemy import String, Integer, DateTime, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class InboundAttackEvent(Base):

    __tablename__ = "inbound_attack_events"

    __table_args__ = (
        UniqueConstraint(
            "src_ip",
            "signature",
            "dst_port",
            name="uq_inbound_attack_agg",
        ),
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # IP del atacante (origen externo).
    src_ip: Mapped[str] = mapped_column(
        String(45),
        nullable=False,
        index=True
    )

    src_port: Mapped[int | None] = mapped_column(Integer, nullable=True)

    dst_port: Mapped[int | None] = mapped_column(Integer, nullable=True)

    protocol: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        default="tcp"
    )

    signature: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )

    category: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True
    )

    severity: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        default="warning"
    )

    # "alert" (solo registrado) | "blocked" (se bloqueo la IP).
    action: Mapped[str] = mapped_column(
        String(16),
        nullable=False,
        default="alert"
    )

    hit_count: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1
    )

    first_seen: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False
    )

    last_seen: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        index=True
    )