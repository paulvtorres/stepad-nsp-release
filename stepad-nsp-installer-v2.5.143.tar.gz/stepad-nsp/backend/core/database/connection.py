from sqlalchemy import create_engine, event

from backend.core.config.settings import Settings


def _database_url() -> str:

    host = Settings.DB_HOST

    if host.startswith("/"):

        return (
            f"postgresql+psycopg2://"
            f"{Settings.DB_USER}:{Settings.DB_PASSWORD}@"
            f"/{Settings.DB_NAME}?host={host}&port={Settings.DB_PORT}"
        )

    return (
        f"postgresql+psycopg2://"
        f"{Settings.DB_USER}:{Settings.DB_PASSWORD}@"
        f"{host}:{Settings.DB_PORT}/"
        f"{Settings.DB_NAME}"
    )


DATABASE_URL = _database_url()


engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=10,
)


@event.listens_for(engine, "checkout")
def _reset_connection_on_checkout(dbapi_conn, connection_record, connection_proxy):
    """Rollback automatico al sacar una conexion del pool.

    Si una conexion devuelve al pool sin COMMIT/ROLLBACK, queda en
    estado "idle in transaction" sosteniendo AccessShareLocks.  Esos
    locks bloquean DDL (CREATE TABLE, ALTER TABLE) que necesita
    ACCESS EXCLUSIVE lock, causando que el servicio se cuelgue al
    arrancar (Alembic migration).
    """
    cursor = dbapi_conn.cursor()
    try:
        cursor.execute("ROLLBACK")
    except Exception:
        pass
    finally:
        cursor.close()
