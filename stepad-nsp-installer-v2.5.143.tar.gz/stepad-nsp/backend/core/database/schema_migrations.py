import os
import time

from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory

from sqlalchemy import inspect, text

from backend.shared.logging.logger import logger


REPO_ROOT = Path(__file__).resolve().parents[3]

MAX_RETRIES = 3
RETRY_DELAY_BASE = 2


def _load_env_file():

    env_file = Path("/etc/stepad/stepad.env")

    if "DB_PASSWORD" in os.environ or not env_file.exists():

        return

    try:

        for line in env_file.read_text().splitlines():

            line = line.strip()

            if line and not line.startswith("#") and "=" in line:

                key, _, value = line.partition("=")

                os.environ.setdefault(key, value)

    except Exception:

        pass


def _config():

    cfg = Config(str(REPO_ROOT / "alembic.ini"))

    cfg.set_main_option(
        "prepend_sys_path",
        str(REPO_ROOT)
    )

    cfg.set_main_option(
        "script_location",
        str(REPO_ROOT / "backend" / "migrations")
    )

    return cfg


def _table_exists(engine, table: str) -> bool:

    return table in inspect(engine).get_table_names()


def _head_revision(cfg) -> str:

    script = ScriptDirectory.from_config(cfg)

    heads = script.get_heads()

    return heads[0] if heads else None


def _kill_stale_sessions(engine):
    """Termina sesiones idle-in-transaction que bloquearian DDL."""
    try:
        with engine.connect() as conn:
            result = conn.execute(
                text(
                    "SELECT pg_terminate_backend(pid), "
                    "pid, "
                    "left(query, 80) "
                    "FROM pg_stat_activity "
                    "WHERE state = idle in transaction "
                    "AND pid != pg_backend_pid() "
                    "AND datname = current_database()"
                )
            )
            rows = result.fetchall()
            terminated = sum(1 for r in rows if r[0])
            if terminated:
                for row in rows:
                    logger.warning(
                        "Migraciones: sesion idle-in-transaction terminada "
                        "PID=%s query=%s",
                        row[1], row[2],
                    )
                logger.warning(
                    "Migraciones: terminadas %d sesion(es) que bloqueaban DDL.",
                    terminated,
                )
            return terminated
    except Exception as exc:
        logger.error(
            "Migraciones: fallo al terminar sesiones idle-in-transaction: %s",
            exc,
        )
        return 0


def _try_ddl(engine, cfg, operation, description):
    """Ejecuta una operacion DDL con reintentos y manejo de bloqueos.

    Si el DDL se bloquea (lock_timeout), mata sesiones stale y reintenta.
    """
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            _kill_stale_sessions(engine)

            with engine.connect() as conn:
                conn.execute(text("SET lock_timeout = '15s'"))

            try:
                if operation == "upgrade":
                    command.upgrade(cfg, "head")
                elif operation == "stamp_head":
                    head = _head_revision(cfg)
                    command.stamp(cfg, head)
                elif operation == "stamp_0001":
                    command.stamp(cfg, "0001")
                else:
                    raise ValueError(f"Operacion desconocida: {operation}")
            finally:
                try:
                    with engine.connect() as conn:
                        conn.execute(text("RESET lock_timeout"))
                except Exception:
                    pass

            return True

        except Exception as exc:
            error_msg = str(exc).lower()

            is_lock_timeout = (
                "lock timeout" in error_msg
                or "deadlock detected" in error_msg
                or "still waiting" in error_msg
            )

            if is_lock_timeout and attempt < MAX_RETRIES:
                delay = RETRY_DELAY_BASE ** attempt
                logger.warning(
                    "Migraciones: %s bloqueada (intento %d/%d). "
                    "Esperando %ds y reintentando... Error: %s",
                    description, attempt, MAX_RETRIES, delay, exc,
                )
                time.sleep(delay)
                continue

            logger.critical(
                "Migraciones: FALLO CRITICO en %s tras %d intento(s). "
                "La base de datos puede tener sesiones bloqueantes o "
                "un problema de concurrencia. Error: %s",
                description, attempt, exc,
            )
            _emit_startup_alert(
                "CRITICAL",
                f"Migracion {description} fallo: {exc}",
            )
            return False

    return False


def _emit_startup_alert(severity, message):
    """Intenta crear una alerta en la tabla de alertas para revision posterior."""
    try:
        from backend.core.database.connection import engine
        from datetime import datetime

        with engine.connect() as conn:
            conn.execute(
                text(
                    "INSERT INTO alerts (alert_type, severity, title, message, "
                    "read, created_at) VALUES "
                    "(:alert_type, :severity, :title, :message, :read, :created_at)"
                ),
                {
                    "alert_type": "STARTUP_ERROR",
                    "severity": severity,
                    "title": "Error critico en arranque",
                    "message": message,
                    "read": False,
                    "created_at": datetime.utcnow(),
                },
            )
            conn.commit()
    except Exception as exc:
        logger.error(
            "No pude crear alerta de arranque: %s", exc,
        )


def run_migrations():
    """Aplica las migraciones pendientes con Alembic.

    Fuente unica de verdad del esquema. Incluye:
    - Eliminacion de sesiones idle-in-transaction que bloquean DDL
    - Reintentos automaticos con backoff exponencial
    - Logs CRITICOS para revision posterior
    - Alertas en la tabla de alertas
    """

    _load_env_file()

    from backend.core.database.connection import engine

    cfg = _config()

    logger.info("Migraciones: verificando estado de la base de datos...")

    if not _table_exists(engine, "alembic_version"):

        if _table_exists(engine, "users"):

            if (
                _table_exists(engine, "malware_events")
                and _table_exists(engine, "threat_response_settings")
            ):

                logger.info(
                    "Migraciones: esquema completo sin historial Alembic; "
                    "marcando head."
                )
                _try_ddl(engine, cfg, "stamp_head", "marcar head")

            else:

                logger.info(
                    "Migraciones: BD existente sin historial Alembic; "
                    "marcando baseline (0001)."
                )
                _try_ddl(engine, cfg, "stamp_0001", "marcar baseline 0001")

        else:

            logger.info(
                "Migraciones: base de datos nueva; esquema completo."
            )

    logger.info("Migraciones: aplicando upgrade head...")
    success = _try_ddl(engine, cfg, "upgrade", "upgrade head")

    if success:
        logger.info("Migraciones: esquema sincronizado correctamente.")
    else:
        logger.critical(
            "Migraciones: NO se pudo sincronizar el esquema. "
            "El servicio podria no funcionar correctamente. "
            "Revise los logs y la tabla de alertas."
        )


if __name__ == "__main__":

    run_migrations()
