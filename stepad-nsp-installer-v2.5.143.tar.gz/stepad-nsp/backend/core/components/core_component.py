from backend.shared.logging.logger import logger

from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality


class CoreComponent(BaseComponent):
    name = "core"
    criticality = ComponentCriticality.CRITICAL

    def start(self):
        logger.info("CoreComponent started.")
        try:
            self._run_schema_migrations()
        except Exception as exc:
            logger.critical(
                "CoreComponent: FALLO CRITICO en migraciones de esquema: %s. "
                "La base de datos podria estar en estado inconsistente. "
                "Revise los logs y la tabla de alertas.",
                exc,
            )
            self._emit_critical_alert(
                "Migraciones de esquema fallaron: %s" % exc,
            )
            raise

    def stop(self):
        logger.info("CoreComponent stopped.")

    def _run_schema_migrations(self):
        from backend.core.database.schema_migrations import run_migrations
        run_migrations()

    def _emit_critical_alert(self, message):
        """Crea una alerta CRITICA en la DB para revision posterior."""
        try:
            from datetime import datetime
            from backend.core.database.connection import engine
            from sqlalchemy import text

            with engine.connect() as conn:
                conn.execute(
                    text(
                        "INSERT INTO alerts (alert_type, severity, title, "
                        "message, read, created_at) VALUES "
                        "(:at, :sev, :title, :msg, false, :ts)"
                    ),
                    {
                        "at": "STARTUP_CRITICAL",
                        "sev": "critical",
                        "title": "NSP: error critico en arranque",
                        "msg": message[:500],
                        "ts": datetime.utcnow(),
                    },
                )
                conn.commit()
        except Exception as alert_exc:
            logger.error(
                "No pude crear alerta critica en DB: %s", alert_exc,
            )
