from backend.core.health.boot_health_check import BootHealthCheck

boot_health_check = BootHealthCheck()
