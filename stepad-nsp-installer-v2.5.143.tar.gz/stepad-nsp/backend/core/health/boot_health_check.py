"""Auto-diagnostico y auto-reparacion del NSP al arrancar.

Corre despues de que la API arranca. Verifica:
1. PostgreSQL responde
2. Schema de DB consistente (alembic_version)
3. Tablas criticas existen
4. Archivos de configuracion validos
5. nftables chains aplicados
6. Procesos criticos corriendo
7. Filesystem escribible

Si encuentra problemas:
- Intenta auto-reparar si es posible
- Genera alerta CRITICA con pasos a seguir
- Loguea todo para revision posterior
"""

import os
import subprocess

from datetime import datetime
from pathlib import Path

from sqlalchemy import text

from backend.shared.logging.logger import logger


EXPECTED_ALEMBIC_VERSION = "0032"

CRITICAL_TABLES = [
    "users", "alerts", "firewall_settings", "threat_response_settings",
    "alembic_version", "attack_blocked_ips", "ip_geo_asn",
    "inbound_attack_events", "network_zones", "managed_interfaces",
]

CONFIG_FILES = [
    "/etc/stepad/stepad.env",
    "/etc/stepad/dns/dnsmasq.conf",
]

NFT_CHAINS = ["harden-forward", "harden-input", "attack-block", "c2-block"]

CRITICAL_PROCESSES = ["postgres", "suricata"]


class BootHealthCheck:

    def __init__(self):
        self._issues = []

    def run(self):
        logger.info("Health check: iniciando auto-diagnostico de arranque...")

        self._check_filesystem()
        self._check_postgres()
        self._check_schema()
        self._check_tables()
        self._check_config_files()
        self._check_nftables()
        self._check_processes()

        if self._issues:
            self._generate_alerts()
            logger.warning(
                "Health check: %d problema(s) detectado(s). "
                "Revise la tabla de alertas.",
                len(self._issues),
            )
        else:
            logger.info("Health check: todo OK, sin problemas detectados.")

        return self._issues

    def _check_filesystem(self):
        critical_paths = ["/etc/stepad", "/var/log"]
        for path_str in critical_paths:
            path = Path(path_str)
            if not path.exists():
                self._issues.append({
                    "check": "filesystem",
                    "severity": "critical",
                    "title": "Directorio faltante: %s" % path_str,
                    "message": (
                        "El directorio %s no existe. "
                        "Esto puede indicar corrupcion del filesystem "
                        "o una instalacion incompleta." % path_str
                    ),
                    "repair": "Ejecute: sudo mkdir -p %s && sudo chown root:root %s" % (path_str, path_str),
                })
                return
            test_file = path / ".stepad_health_check"
            try:
                test_file.write_text("test")
                test_file.unlink()
            except Exception as exc:
                self._issues.append({
                    "check": "filesystem",
                    "severity": "critical",
                    "title": "Filesystem no escribible: %s" % path_str,
                    "message": (
                        "No se pudo escribir en %s: %s. "
                        "Esto puede indicar filesystem corrupto "
                        "o montado como solo-lectura." % (path_str, exc)
                    ),
                    "repair": (
                        "1) Reinicie en modo recovery (GRUB)\n"
                        "2) Ejecute: fsck -y /dev/sda1\n"
                        "3) Reinicie normalmente\n"
                        "Si persiste, verifique: mount | grep '%s'" % path_str
                    ),
                })

    def _check_postgres(self):
        try:
            from backend.core.database.connection import engine
            with engine.connect() as conn:
                result = conn.execute(text("SELECT 1"))
                result.fetchone()
        except Exception as exc:
            self._issues.append({
                "check": "postgres",
                "severity": "critical",
                "title": "PostgreSQL no responde",
                "message": (
                    "No se pudo conectar a PostgreSQL: %s. "
                    "La base de datos puede estar caida o corrupta." % exc
                ),
                "repair": (
                    "1) Verifique: sudo systemctl status postgresql\n"
                    "2) Si esta detenido: sudo systemctl start postgresql\n"
                    "3) Si no inicia, revise logs: "
                    "sudo journalctl -u postgresql -n 50\n"
                    "4) Si hay corrupcion, ejecute: "
                    "sudo pg_resetwal -f /var/lib/postgresql/*/main"
                ),
            })
            return

    def _check_schema(self):
        try:
            from backend.core.database.connection import engine
            with engine.connect() as conn:
                result = conn.execute(
                    text("SELECT version_num FROM alembic_version")
                )
                row = result.fetchone()
                if not row:
                    self._issues.append({
                        "check": "schema",
                        "severity": "critical",
                        "title": "Tabla alembic_version vacia",
                        "message": (
                            "La tabla alembic_version no tiene registros. "
                            "El esquema de la DB puede estar incompleto."
                        ),
                        "repair": (
                            "1) Verifique: psql -U stepad_app -d stepad_nsp "
                            "-c 'SELECT * FROM alembic_version'\n"
                            "2) Si esta vacia, el servicio intentara "
                            "re-aplicar las migraciones al reiniciar.\n"
                            "3) Si falla, restaurar desde backup de DB."
                        ),
                    })
                    return
                version = row[0]
                if version != EXPECTED_ALEMBIC_VERSION:
                    self._issues.append({
                        "check": "schema",
                        "severity": "warning",
                        "title": "Version de schema desactualizada",
                        "message": (
                            "La DB esta en version %s pero se espera %s. "
                            "Las migraciones pendientes se aplicaran "
                            "automaticamente." % (version, EXPECTED_ALEMBIC_VERSION)
                        ),
                        "repair": (
                            "El servicio deberia aplicar las migraciones "
                            "al reiniciar. Si no lo hace, verifique: "
                            "psql -U stepad_app -d stepad_nsp "
                            "-c 'SELECT * FROM alembic_version'"
                        ),
                    })
        except Exception as exc:
            logger.warning("Health check: no pude verificar schema: %s", exc)

    def _check_tables(self):
        try:
            from backend.core.database.connection import engine
            with engine.connect() as conn:
                result = conn.execute(text(
                    "SELECT table_name FROM information_schema.tables "
                    "WHERE table_schema = 'public'"
                ))
                existing = {row[0] for row in result.fetchall()}

                missing = [t for t in CRITICAL_TABLES if t not in existing]
                if missing:
                    self._issues.append({
                        "check": "tables",
                        "severity": "critical",
                        "title": "Tablas faltantes: %s" % ", ".join(missing),
                        "message": (
                            "Las siguientes tablas criticas no existen: %s. "
                            "Esto puede indicar una migracion fallida."
                            % ", ".join(missing)
                        ),
                        "repair": (
                            "1) El servicio intentara re-aplicar las "
                            "migraciones al reiniciar.\n"
                            "2) Si falla, verifique: "
                            "psql -U stepad_app -d stepad_nsp "
                            "-c '\\dt'\n"
                            "3) Si persiste, restaurar desde backup."
                        ),
                    })

                for table in ["users", "alerts"]:
                    if table in existing:
                        result = conn.execute(text(
                            "SELECT count(*) FROM %s" % table
                        ))
                        count = result.scalar()
                        if count == 0 and table == "users":
                            self._issues.append({
                                "check": "tables",
                                "severity": "critical",
                                "title": "Tabla users vacia",
                                "message": (
                                    "La tabla users no tiene registros. "
                                    "No hay usuarios administradores."
                                ),
                                "repair": (
                                    "Ejecute: python3 install.py "
                                    "para recrear el usuario admin."
                                ),
                            })
        except Exception as exc:
            logger.warning("Health check: no pude verificar tablas: %s", exc)

    def _check_config_files(self):
        for filepath in CONFIG_FILES:
            path = Path(filepath)
            if not path.exists():
                self._issues.append({
                    "check": "config",
                    "severity": "critical",
                    "title": "Archivo de config faltante: %s" % filepath,
                    "message": (
                        "El archivo %s no existe. "
                        "El servicio puede no funcionar correctamente."
                        % filepath
                    ),
                    "repair": (
                        "1) Restaure desde backup: "
                        "cp /etc/stepad/backup/%s %s\n"
                        "2) O re-instale el paquete."
                        % (path.name, filepath)
                    ),
                })
                continue
            try:
                content = path.read_text()
                if not content.strip():
                    self._issues.append({
                        "check": "config",
                        "severity": "critical",
                        "title": "Archivo de config vacio: %s" % filepath,
                        "message": (
                            "El archivo %s esta vacio. "
                            "Esto puede indicar corrupcion por corte "
                            "de energia." % filepath
                        ),
                        "repair": (
                            "1) Restaure desde backup: "
                            "cp /etc/stepad/backup/%s %s\n"
                            "2) Si no hay backup, re-instale el paquete."
                            % (path.name, filepath)
                        ),
                    })
            except Exception as exc:
                self._issues.append({
                    "check": "config",
                    "severity": "warning",
                    "title": "No se pudo leer: %s" % filepath,
                    "message": "Error al leer %s: %s" % (filepath, exc),
                    "repair": "Verifique permisos: ls -la %s" % filepath,
                })

    def _check_nftables(self):
        try:
            result = subprocess.run(
                ["/usr/sbin/nft", "list", "chains", "inet", "stepad"],
                capture_output=True, text=True, timeout=5,
            )
            output = result.stdout
            missing = [
                chain for chain in NFT_CHAINS
                if chain not in output
            ]
            if missing:
                self._issues.append({
                    "check": "nftables",
                    "severity": "warning",
                    "title": "Cadenas nftables faltantes: %s" % ", ".join(missing),
                    "message": (
                        "Las cadenas nftables %s no existen. "
                        "El firewall puede no estar protegiendo correctamente."
                        % ", ".join(missing)
                    ),
                    "repair": (
                        "Re-aplique el hardening desde el panel: "
                        "Proteccion -> Firewall -> Aplicar hardening\n"
                        "O ejecute manualmente: "
                        "nft -f /etc/stepad/nftables.conf"
                    ),
                })
        except Exception as exc:
            logger.warning("Health check: no pude verificar nftables: %s", exc)

    def _check_processes(self):
        for proc_name in CRITICAL_PROCESSES:
            try:
                result = subprocess.run(
                    ["pgrep", "-x", proc_name],
                    capture_output=True, text=True, timeout=5,
                )
                if result.returncode != 0:
                    self._issues.append({
                        "check": "process",
                        "severity": "critical",
                        "title": "Proceso critico no encontrado: %s" % proc_name,
                        "message": (
                            "El proceso %s no esta corriendo. "
                            "Esto afecta funcionalidad critica del NSP."
                            % proc_name
                        ),
                        "repair": self._get_process_repair(proc_name),
                    })
            except Exception as exc:
                logger.warning(
                    "Health check: no pude verificar %s: %s",
                    proc_name, exc,
                )

    def _get_process_repair(self, proc_name):
        repairs = {
            "postgres": (
                "1) sudo systemctl status postgresql\n"
                "2) sudo systemctl start postgresql\n"
                "3) Si falla: sudo journalctl -u postgresql -n 50"
            ),
            "suricata": (
                "1) sudo systemctl status suricata\n"
                "2) sudo systemctl start suricata\n"
                "3) Si falla, verifique configuracion: "
                "suricata -T -c /etc/suricata/suricata.yaml"
            ),
        }
        return repairs.get(proc_name, (
            "1) sudo systemctl status %s\n"
            "2) sudo systemctl start %s" % (proc_name, proc_name)
        ))

    def _generate_alerts(self):
        try:
            from backend.core.database.connection import engine

            with engine.connect() as conn:
                for issue in self._issues:
                    severity = issue.get("severity", "warning")
                    title = issue.get("title", "Problema detectado")
                    message = (
                        "Check: %s\n"
                        "Detalle: %s\n"
                        "Pasos para resolver:\n%s"
                        % (
                            issue.get("check", "unknown"),
                            issue.get("message", ""),
                            issue.get("repair", "No hay pasos disponibles."),
                        )
                    )

                    conn.execute(
                        text(
                            "INSERT INTO alerts "
                            "(alert_type, severity, title, message, "
                            "read, created_at) VALUES "
                            "(:at, :sev, :title, :msg, false, :ts)"
                        ),
                        {
                            "at": "BOOT_HEALTH_%s" % issue.get("check", "unknown").upper(),
                            "sev": severity,
                            "title": "Auto-diagnostico: %s" % title,
                            "msg": message[:1000],
                            "ts": datetime.utcnow(),
                        },
                    )

                conn.commit()

        except Exception as exc:
            logger.error(
                "Health check: no pude generar alertas en DB: %s", exc,
            )
