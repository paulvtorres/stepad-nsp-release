from backend.shared.logging.logger import logger
from backend.shared.runtime import runtime

from backend.core.lifecycle.component_status import ComponentStatus


class ComponentLifecycleManager:
    """
    Controls lifecycle of all NSP components.
    """

    def __init__(self):
        self.components = []
        self._failures = []

    def register(self, component):
        self.components.append(component)

        runtime.set(
            component.name,
            ComponentStatus.PENDING.value
        )

        logger.info(f"Registered component: {component.name}")

    def start_all(self):
        logger.info("Starting component lifecycle...")

        for component in self.components:
            try:
                logger.info(f"Starting {component.name}")

                runtime.set(
                    component.name,
                    ComponentStatus.STARTING.value
                )

                component.start()

                if component.name == "api":
                    runtime.set(
                        component.name,
                        ComponentStatus.RUNNING.value
                    )
                    continue

                runtime.set(
                    component.name,
                    ComponentStatus.RUNNING.value
                )

                logger.info(f"{component.name} is RUNNING")

            except Exception as e:

                runtime.set(
                    component.name,
                    ComponentStatus.FAILED.value,
                    error=f"{type(e).__name__}: {e}"
                )

                self._failures.append({
                    "component": component.name,
                    "error": f"{type(e).__name__}: {e}",
                })

                logger.exception(
                    f"{component.name} failed: {e}"
                )

                logger.critical(
                    "Componente %s fallo al iniciar: %s. "
                    "El servicio continuara con los demas componentes.",
                    component.name, e,
                )

                self._emit_failure_alert(component.name, e)

        if self._failures:
            failed_names = [f["component"] for f in self._failures]
            logger.critical(
                "Arranque incompleto: %d componente(s) fallaron: %s. "
                "Revise la tabla de alertas para detalles.",
                len(self._failures),
                ", ".join(failed_names),
            )

    def stop_all(self):
        logger.info("Stopping all components...")

        for component in reversed(self.components):
            try:

                component.stop()

                runtime.set(
                    component.name,
                    ComponentStatus.STOPPED.value
                )

                logger.info(f"{component.name} stopped")

            except Exception as e:

                runtime.set(
                    component.name,
                    ComponentStatus.FAILED.value,
                    error=f"{type(e).__name__}: {e}"
                )

                logger.exception(
                    f"{component.name} stop failed: {e}"
                )

    def _emit_failure_alert(self, component_name, error):
        """Crea una alerta CRITICA en la DB cuando un componente falla."""
        try:
            from datetime import datetime
            from backend.core.database.connection import engine
            from sqlalchemy import text

            with engine.connect() as conn:
                conn.execute(
                    text(
                        "INSERT INTO alerts (alert_type, severity, title, "
                        "message, read, created_at) VALUES "
                        "(:at, :sev, :title, :msg, false, :ts)"
                    ),
                    {
                        "at": "COMPONENT_FAILURE",
                        "sev": "critical",
                        "title": f"Componente {component_name} fallo",
                        "msg": f"{type(error).__name__}: {error}"[:500],
                        "ts": datetime.utcnow(),
                    },
                )
                conn.commit()
        except Exception as alert_exc:
            logger.error(
                "No pude crear alerta de fallo de componente: %s",
                alert_exc,
            )
