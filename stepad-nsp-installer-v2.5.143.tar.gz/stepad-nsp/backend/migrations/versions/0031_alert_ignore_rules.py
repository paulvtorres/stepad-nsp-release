"""Add alert_ignore_rules table

Revision ID: 0031
Revises: 0030
Create Date: 2026-09-15 13:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0031"
down_revision = "0030"
branch_labels = None
depends_on = None


def upgrade() -> None:

    from sqlalchemy import inspect
    with op.get_context().autocommit_block():
        conn = op.get_bind()
        inspector = inspect(conn)
        if "alert_ignore_rules" not in inspector.get_table_names():
            op.create_table(
                "alert_ignore_rules",
                sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
                sa.Column("match_field", sa.String(20), nullable=False),
                sa.Column("matcher", sa.String(20), nullable=False),
                sa.Column("value", sa.String(255), nullable=False),
                sa.Column("created_at", sa.DateTime(), nullable=True),
            )


def downgrade() -> None:
    op.drop_table("alert_ignore_rules")
