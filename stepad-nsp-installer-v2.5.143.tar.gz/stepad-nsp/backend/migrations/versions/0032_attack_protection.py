"""Ataques externos: bloqueo de IPs atacantes + registro + geolocalizacion

Revision ID: 0032
Revises: 0031
Create Date: 2026-09-16 10:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0032"
down_revision = "0031"
branch_labels = None
depends_on = None


def upgrade() -> None:

    from sqlalchemy import inspect

    with op.get_context().autocommit_block():

        conn = op.get_bind()

        inspector = inspect(conn)

        tables = set(inspector.get_table_names())

        if "ip_geo_asn" not in tables:

            op.create_table(
                "ip_geo_asn",
                sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
                sa.Column("start_ip", sa.BigInteger(), nullable=False),
                sa.Column("end_ip", sa.BigInteger(), nullable=False),
                sa.Column("asn", sa.BigInteger(), nullable=True),
                sa.Column("country", sa.String(2), nullable=True),
                sa.Column("as_org", sa.String(255), nullable=True),
            )

            op.create_index(
                "ix_ip_geo_asn_start_ip",
                "ip_geo_asn",
                ["start_ip"],
            )

        if "attack_blocked_ips" not in tables:

            op.create_table(
                "attack_blocked_ips",
                sa.Column("ip", sa.String(45), primary_key=True),
                sa.Column(
                    "rule_source",
                    sa.String(16),
                    nullable=False,
                    server_default="manual",
                ),
                sa.Column("reason", sa.String(255), nullable=True),
                sa.Column("created_by", sa.String(64), nullable=True),
                sa.Column("created_at", sa.DateTime(), nullable=True),
            )

        if "inbound_attack_events" not in tables:

            op.create_table(
                "inbound_attack_events",
                sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
                sa.Column("src_ip", sa.String(45), nullable=False),
                sa.Column("src_port", sa.Integer(), nullable=True),
                sa.Column("dst_port", sa.Integer(), nullable=True),
                sa.Column(
                    "protocol",
                    sa.String(16),
                    nullable=False,
                    server_default="tcp",
                ),
                sa.Column(
                    "signature",
                    sa.String(255),
                    nullable=False,
                    server_default="",
                ),
                sa.Column("category", sa.String(128), nullable=True),
                sa.Column(
                    "severity",
                    sa.String(16),
                    nullable=False,
                    server_default="warning",
                ),
                sa.Column(
                    "action",
                    sa.String(16),
                    nullable=False,
                    server_default="alert",
                ),
                sa.Column(
                    "hit_count",
                    sa.Integer(),
                    nullable=False,
                    server_default="1",
                ),
                sa.Column("first_seen", sa.DateTime(), nullable=False),
                sa.Column("last_seen", sa.DateTime(), nullable=False),
            )

            op.create_index(
                "ix_inbound_attack_events_src_ip",
                "inbound_attack_events",
                ["src_ip"],
            )

            op.create_index(
                "ix_inbound_attack_events_last_seen",
                "inbound_attack_events",
                ["last_seen"],
            )

            op.create_unique_constraint(
                "uq_inbound_attack_agg",
                "inbound_attack_events",
                ["src_ip", "signature", "dst_port"],
            )

        if "auto_block_inbound" not in [
            column["name"]
            for column in inspector.get_columns("threat_response_settings")
        ]:

            op.add_column(
                "threat_response_settings",
                sa.Column(
                    "auto_block_inbound",
                    sa.Boolean(),
                    nullable=False,
                    server_default=sa.false(),
                ),
            )


def downgrade() -> None:

    op.drop_table("ip_geo_asn")

    op.drop_table("attack_blocked_ips")

    op.drop_table("inbound_attack_events")

    op.drop_column("threat_response_settings", "auto_block_inbound")