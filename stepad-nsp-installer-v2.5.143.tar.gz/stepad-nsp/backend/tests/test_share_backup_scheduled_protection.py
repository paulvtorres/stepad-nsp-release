"""
Cubre los tres pedidos sobre el respaldo "por horario" (daily/interval):

1. El watch antiransomware (`ShareIntegrityWatchService`) debe saltarse su
   escaneo mientras dure un respaldo por horario, y reactivarse solo al
   terminar -- nunca durante "on_change" (deliberadamente fuera de esto).
2. El estado "en curso" (`running`/`running_since`) debe reflejar
   exactamente lo que el scheduler real está haciendo -- lo que requiere
   que exista un único `ShareBackupService` compartido (ver el fix del
   singleton en `NetworkShareComponent`).
3. Cada corrida (éxito o fallo) debe quedar en una bitácora consultable,
   no solo sobrescribir el último resultado.
"""

import os
import subprocess

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from backend.shares.services.share_backup_service import (
    Job,
    ShareBackupService,
    _default_job,
)


def _make_service(tmp_path, monkeypatch, *, schedule_mode="daily"):
    vault = tmp_path / "Respaldo"
    vault.mkdir()
    source = tmp_path / "Compartida"
    source.mkdir()

    record = dict(_default_job())
    record.update({
        "id": 1,
        "name": "job-1",
        "source_path": str(source),
        "schedule_mode": schedule_mode,
    })
    job = Job(record, vault=vault)

    service = ShareBackupService.__new__(ShareBackupService)
    service._stop = False
    service._thread = None
    service._lock = __import__("threading").Lock()
    service._running_jobs = set()
    service._running_since = {}
    service._active_protected_backups = 0
    service._last_reconcile = 0.0
    service._procs = {}
    service._cancel_requested = set()

    monkeypatch.setattr(service, "_find_job", lambda job_id: job)
    monkeypatch.setattr(service, "_save_job", lambda j: None)
    monkeypatch.setattr(service, "installed", lambda: True)
    monkeypatch.setattr(service, "_ensure_repo", lambda j: None)
    monkeypatch.setattr(service, "_maybe_prune", lambda j: None)
    monkeypatch.setattr(service, "_is_network_source", lambda s: False)

    return service, job


def _fake_restic_ok(*_a, **_k):
    return subprocess.CompletedProcess(
        args=[],
        returncode=0,
        stdout=(
            '{"message_type":"summary","snapshot_id":"abc123",'
            '"total_bytes_processed":100,"total_bytes_added":50}\n'
        ),
        stderr="",
    )


def _fake_restic_fail(*_a, **_k):
    return subprocess.CompletedProcess(
        args=[], returncode=1, stdout="", stderr="repository locked"
    )


def test_scheduled_backup_is_protected_while_running_and_unprotected_after(
    tmp_path, monkeypatch
):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")

    seen_during_run = {}

    def fake_restic(*_a, **_k):
        # Capturamos el estado "protegido" justo en medio de la corrida.
        seen_during_run["active"] = service.has_active_protected_backup()
        return _fake_restic_ok()

    monkeypatch.setattr(service, "_restic", fake_restic)

    assert service.has_active_protected_backup() is False

    result = service.run_backup(1, trigger="scheduled")

    assert result["success"] is True
    assert seen_during_run["active"] is True
    # Se desactiva sola apenas termina, sin esperar nada más.
    assert service.has_active_protected_backup() is False


def test_on_change_backup_never_activates_protection(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="on_change")

    seen_during_run = {}

    def fake_restic(*_a, **_k):
        seen_during_run["active"] = service.has_active_protected_backup()
        return _fake_restic_ok()

    monkeypatch.setattr(service, "_restic", fake_restic)

    service.run_backup(1, trigger="on_change")

    assert seen_during_run["active"] is False
    assert service.has_active_protected_backup() is False


def test_running_flag_and_since_are_set_during_execution(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="interval")

    seen = {}

    def fake_restic(*_a, **_k):
        seen["running"] = 1 in service._running_jobs
        seen["since"] = service._running_since.get(1)
        return _fake_restic_ok()

    monkeypatch.setattr(service, "_restic", fake_restic)

    service.run_backup(1, trigger="scheduled")

    assert seen["running"] is True
    assert seen["since"] is not None
    # Al terminar, se limpia -- la UI no debe seguir mostrando "en curso".
    assert 1 not in service._running_jobs
    assert 1 not in service._running_since


def test_successful_run_is_logged_in_history(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_ok)

    result = service.run_backup(1, trigger="scheduled")

    assert result["success"] is True
    assert len(job["history"]) == 1
    entry = job["history"][0]
    assert entry["success"] is True
    assert entry["trigger"] == "scheduled"
    assert entry["bytes_added"] == 50
    assert entry["duration_seconds"] is not None
    assert job["last_backup_at"] is not None


def test_failed_restic_run_is_logged_and_does_not_advance_last_backup_at(
    tmp_path, monkeypatch
):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    result = service.run_backup(1, trigger="scheduled")

    assert result["success"] is False
    assert len(job["history"]) == 1
    entry = job["history"][0]
    assert entry["success"] is False
    assert "repository locked" in entry["message"]
    # Un fallo no debe contar como "ya se respaldó hoy": el scheduler
    # tiene que poder reintentar en el siguiente tick.
    assert job["last_backup_at"] is None
    # Tampoco debe quedar "en curso" ni protegido tras el fallo.
    assert service.has_active_protected_backup() is False
    assert 1 not in service._running_jobs


def test_missing_source_is_logged_without_running_restic(tmp_path, monkeypatch):
    vault = tmp_path / "Respaldo"
    vault.mkdir()
    record = dict(_default_job())
    record.update({
        "id": 2,
        "name": "job-2",
        "source_path": str(tmp_path / "no-existe"),
        "schedule_mode": "daily",
    })
    job = Job(record, vault=vault)

    service = ShareBackupService.__new__(ShareBackupService)
    service._stop = False
    service._thread = None
    service._lock = __import__("threading").Lock()
    service._running_jobs = set()
    service._running_since = {}
    service._active_protected_backups = 0
    service._last_reconcile = 0.0
    monkeypatch.setattr(service, "_find_job", lambda job_id: job)
    monkeypatch.setattr(service, "_save_job", lambda j: None)
    monkeypatch.setattr(service, "installed", lambda: True)
    monkeypatch.setattr(service, "_is_network_source", lambda s: False)

    def boom(*_a, **_k):
        raise AssertionError("restic no debería ejecutarse sin origen")

    monkeypatch.setattr(service, "_restic", boom)

    result = service.run_backup(2, trigger="scheduled")

    assert result["success"] is False
    assert len(job["history"]) == 1
    assert job["history"][0]["success"] is False
    assert job["last_backup_at"] is None


def test_history_is_capped_at_limit(tmp_path, monkeypatch):
    from backend.shares.services.share_backup_service import HISTORY_LIMIT

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_ok)
    # Evita que el "sin cambios" detenga corridas repetidas.
    monkeypatch.setattr(service, "_tree_signature", lambda root: None)

    for _ in range(HISTORY_LIMIT + 5):
        service.run_backup(1, trigger="scheduled")

    assert len(job["history"]) == HISTORY_LIMIT


def test_job_history_returns_most_recent_first(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_tree_signature", lambda root: None)

    monkeypatch.setattr(service, "_restic", _fake_restic_fail)
    service.run_backup(1, trigger="scheduled")

    monkeypatch.setattr(service, "_restic", _fake_restic_ok)
    service.run_backup(1, trigger="manual")

    history = service.job_history(1)
    assert len(history) == 2
    assert history[0]["success"] is True
    assert history[0]["trigger"] == "manual"
    assert history[1]["success"] is False
