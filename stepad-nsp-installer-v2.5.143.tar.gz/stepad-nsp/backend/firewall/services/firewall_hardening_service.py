import subprocess

from datetime import datetime, timedelta

from sqlalchemy import func

from backend.core.database.session import SessionLocal

from backend.firewall.models.firewall_settings import FirewallSettings

from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


NFT = "/usr/sbin/nft"

REVIEW_INTERVAL_DAYS = 183


class FirewallHardeningService:

    def _run(self, args):

        result = subprocess.run(
            [NFT] + args,
            capture_output=True,
            text=True
        )

        return {
            "success": result.returncode == 0,
            "stderr": result.stderr.strip(),
        }


    def _current_wan_names(self) -> list[str]:

        try:

            from backend.network.interfaces.registry.models.managed_interface import (
                ManagedInterface
            )
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                rows = (
                    db.query(ManagedInterface)
                    .filter(
                        func.lower(ManagedInterface.role) == "wan"
                    )
                    .all()
                )

                return [
                    row.last_seen_name.strip()
                    for row in rows
                    if row.last_seen_name and row.last_seen_name.strip()
                ]

            finally:

                db.close()

        except Exception:

            return []

    def _ensure_wan_set(self):

        # La tabla stepad puede no tener aun el set @stepad_wan_ifaces
        # (lo crea el provider de DNS security). Sin el set, las reglas
        # "iifname != @stepad_wan_ifaces accept" fallan y el deny-all
        # bloquea tambien la LAN. Crearlo + poblarlo aqui es lo robusto.
        self._run([
            "add", "set", "inet", "stepad", "stepad_wan_ifaces",
            "{", "type", "ifname", ";", "}"
        ])

        self._run([
            "flush", "set", "inet", "stepad", "stepad_wan_ifaces"
        ])

        wans = self._current_wan_names()

        if wans:

            elements = [name for name in wans for name in (name,)]
            args = [
                "add", "element", "inet", "stepad", "stepad_wan_ifaces",
                "{", ", ".join(elements), "}"
            ]
            self._run(args)

    def _is_applied(self):

        result = subprocess.run(
            [NFT, "list", "chain", "inet", "stepad", "harden-forward"],
            capture_output=True,
            text=True
        )

        return result.returncode == 0

    def get_settings(self):

        db = SessionLocal()

        try:

            row = db.get(FirewallSettings, 1)

            # Deny-all por defecto en instalaciones nuevas (producto de
            # seguridad): si no hay fila de settings, se asume activo.
            hardening = bool(row.hardening_enabled) if row else True

            last_review = row.last_review if row else None

            last_access_review = row.last_access_review if row else None

            overdue = True

            if last_review:

                overdue = (
                    datetime.utcnow() - last_review
                    > timedelta(days=REVIEW_INTERVAL_DAYS)
                )

            access_overdue = True

            if last_access_review:

                access_overdue = (
                    datetime.utcnow() - last_access_review
                    > timedelta(days=REVIEW_INTERVAL_DAYS)
                )

            return {
                "hardening_enabled": hardening,
                "last_review": to_iso_utc(last_review),
                "review_overdue": overdue,
                "review_interval_days": REVIEW_INTERVAL_DAYS,
                "applied": self._is_applied(),
                "access_review": {
                    "last_review": to_iso_utc(last_access_review),
                    "overdue": access_overdue,
                },
                "admin_access_window": {
                    "start_hour": (
                        row.admin_access_start_hour if row else None
                    ),
                    "end_hour": (
                        row.admin_access_end_hour if row else None
                    ),
                },
                "wan_edge": self._wan_edge_status(db),
            }

        finally:

            db.close()

    def _wan_edge_status(self, db) -> dict:

        try:

            from backend.firewall.services.wan_edge_service import (
                WanEdgeService,
            )

            return WanEdgeService().status(db)

        except Exception as error:

            return {"error": str(error)}

    def set_enabled(self, enabled: bool):

        if enabled:

            result = self._apply()

        else:

            result = self._remove()

        if not result["success"]:

            return {
                "success": False,
                "message": result["stderr"],
            }

        db = SessionLocal()

        try:

            row = db.get(FirewallSettings, 1)

            if row is None:

                row = FirewallSettings(id=1)

                db.add(row)

            row.hardening_enabled = enabled

            db.commit()

        finally:

            db.close()

        return {
            "success": True,
            "hardening_enabled": enabled,
            "message": (
                "Hardening aplicado (deny-all con lista blanca)"
                if enabled
                else "Hardening desactivado (política por defecto)"
            ),
        }

    def mark_review(self):

        db = SessionLocal()

        try:

            row = db.get(FirewallSettings, 1)

            if row is None:

                row = FirewallSettings(id=1)

                db.add(row)

            row.last_review = datetime.utcnow()

            db.commit()

        finally:

            db.close()

        return {
            "success": True,
            "last_review": to_iso_utc(datetime.utcnow()),
        }

    def mark_access_review(self):

        db = SessionLocal()

        try:

            row = db.get(FirewallSettings, 1)

            if row is None:

                row = FirewallSettings(id=1)

                db.add(row)

            row.last_access_review = datetime.utcnow()

            db.commit()

        finally:

            db.close()

        return {
            "success": True,
            "last_access_review": to_iso_utc(datetime.utcnow()),
        }

    def save_admin_access_window(
        self,
        start_hour: int | None,
        end_hour: int | None
    ):

        db = SessionLocal()

        try:

            row = db.get(FirewallSettings, 1)

            if row is None:

                row = FirewallSettings(id=1)

                db.add(row)

            row.admin_access_start_hour = start_hour

            row.admin_access_end_hour = end_hour

            db.commit()

        finally:

            db.close()

        return {
            "success": True,
            "admin_access_window": {
                "start_hour": start_hour,
                "end_hour": end_hour,
            },
        }

    def admin_access_allowed(self) -> bool:

        db = SessionLocal()

        try:

            row = db.get(FirewallSettings, 1)

            if row is None:

                return True

            start = row.admin_access_start_hour

            end = row.admin_access_end_hour

            if start is None or end is None:

                return True

            hour = datetime.now().hour

            if start <= end:

                return start <= hour <= end

            return hour >= start or hour <= end

        finally:

            db.close()

    def check_access_review_alert(self, db):

        data = self.get_settings()

        if not data["access_review"]["overdue"]:

            return {"created": False}

        from backend.alerts.models.alert import Alert

        from backend.alerts.repositories.alert_repository import (
            AlertRepository
        )

        pending = (
            db.query(Alert)
            .filter(
                Alert.alert_type == "access_review_overdue",
                Alert.read.is_(False)
            )
            .count()
        )

        if pending > 0:

            return {"created": False}

        AlertRepository().create(
            db,
            Alert(
                alert_type="access_review_overdue",
                severity="warning",
                title="Revisión de accesos pendiente",
                message=(
                    "La revisión periódica de accesos administrativos "
                    "lleva más de 6 meses pendiente."
                )
            )
        )

        return {"created": True}

    def _apply(self):

        from backend.shared.runtime.resource_locks import resource_locks

        with resource_locks.nft:
            return self._apply_unlocked()

    def _apply_unlocked(self):

        results = []

        self._ensure_wan_set()

        # Idempotente: se eliminan las cadenas existentes y se recrean
        # limpias. Antes se acumulaban reglas duplicadas en cada
        # aplicacion (y en estados raros se perdia la regla de la web
        # 8443 dejando el NSP sin acceso a la interfaz web).
        for chain in ("harden-forward", "harden-input"):
            self._run([
                "delete", "chain", "inet", "stepad", chain
            ])

        results.append(self._run([
            "add", "chain", "inet", "stepad", "harden-forward", "{",
            "type", "filter", "hook", "forward", "priority", "1", ";",
            "policy", "drop", ";",
            "}"
        ]))

        results.append(self._run([
            "add", "rule", "inet", "stepad", "harden-forward",
            "ct", "state", "established,related", "accept"
        ]))

        results.append(self._run([
            "add", "rule", "inet", "stepad", "harden-forward",
            "iifname", "!=", "@stepad_wan_ifaces", "accept"
        ]))

        results.append(self._run([
            "add", "chain", "inet", "stepad", "harden-input", "{",
            "type", "filter", "hook", "input", "priority", "1", ";",
            "policy", "drop", ";",
            "}"
        ]))

        results.append(self._run([
            "add", "rule", "inet", "stepad", "harden-input",
            "ct", "state", "established,related", "accept"
        ]))

        results.append(self._run([
            "add", "rule", "inet", "stepad", "harden-input",
            "iifname", "!=", "@stepad_wan_ifaces", "accept"
        ]))

        # Tailscale / WireGuard: autenticados; sin rate-limit agresivo.
        results.append(self._run([
            "add", "rule", "inet", "stepad", "harden-input",
            "udp", "dport", "41641", "accept"
        ]))

        results.append(self._run([
            "add", "rule", "inet", "stepad", "harden-input",
            "udp", "dport", "51820", "accept"
        ]))

        # RustDesk self-hosted (opcional): solo si el admin activó
        # exposición WAN. Clave de servidor + rate suave anti-flood.
        try:
            from backend.rustdesk.services.rustdesk_service import (
                RUSTDESK_TCP_PORTS,
                RUSTDESK_UDP_PORTS,
                RustdeskService,
            )

            if RustdeskService().wan_ports_exposed():
                for port in RUSTDESK_TCP_PORTS:
                    results.append(self._run([
                        "add", "rule", "inet", "stepad", "harden-input",
                        "tcp", "dport", str(port),
                        "ct", "state", "new",
                        "limit", "rate", "40/second",
                        "burst", "20", "packets",
                        "counter", "accept",
                    ]))
                    results.append(self._run([
                        "add", "rule", "inet", "stepad", "harden-input",
                        "tcp", "dport", str(port),
                        "ct", "state", "established,related",
                        "accept",
                    ]))
                for port in RUSTDESK_UDP_PORTS:
                    results.append(self._run([
                        "add", "rule", "inet", "stepad", "harden-input",
                        "udp", "dport", str(port),
                        "limit", "rate", "80/second",
                        "burst", "40", "packets",
                        "counter", "accept",
                    ]))
                logger.info(
                    "Hardening: puertos RustDesk abiertos en WAN "
                    "(tcp %s, udp %s).",
                    RUSTDESK_TCP_PORTS,
                    RUSTDESK_UDP_PORTS,
                )
        except Exception as error:
            logger.warning(
                "Hardening: no se evaluó RustDesk WAN: %s",
                error,
            )

        # SSH/8443 + allowlist de port-forwards: WanEdgeService
        # (rate-limit admin + DMZ controlado bajo Suricata).
        try:

            from backend.firewall.services.wan_edge_service import (
                WanEdgeService,
            )

            WanEdgeService().enrich_hardening()

        except Exception as error:

            logger.error(
                "WAN edge no aplicado (hardening base sí): %s",
                error,
            )

            try:
                from backend.core.database.session import SessionLocal
                from backend.alerts.services.alert_service import AlertService

                db = SessionLocal()
                try:
                    AlertService().create(
                        db,
                        alert_type="HARDENING_DEGRADED",
                        severity="critical",
                        title="Hardening aplicado en modo degradado",
                        message=(
                            "El servicio WAN edge fallo al aplicar "
                            "rate-limit en SSH/8443. Se activo acceso "
                            "admin sin rate-limit como fallback. "
                            "Error: %s" % error
                        ),
                    )
                    db.commit()
                finally:
                    db.close()
            except Exception as alert_err:
                logger.error(
                    "No pude crear alerta de hardening degradado: %s",
                    alert_err,
                )

            # Fallback: acceso admin sin rate-limit (mejor que quedar
            # sin SSH/panel tras un fallo del borde).
            private = (
                "10.0.0.0/8", ",", "172.16.0.0/12", ",", "192.168.0.0/16"
            )
            results.append(self._run([
                "add", "rule", "inet", "stepad", "harden-input",
                "tcp", "dport", "22", "ip", "saddr",
                "{", *private, "}",
                "accept"
            ]))
            results.append(self._run([
                "add", "rule", "inet", "stepad", "harden-input",
                "tcp", "dport", "8443", "ip", "saddr",
                "{", *private, "}",
                "accept"
            ]))

        failed = [r["stderr"] for r in results if not r["success"]]

        if failed:

            logger.error(
                "Fallo al aplicar hardening: %s",
                failed
            )

            return {"success": False, "stderr": "; ".join(failed)}

        logger.info(
            "Hardening deny-all + WAN edge aplicados (forward + input)."
        )

        return {"success": True}

    def _remove(self):

        results = []

        for chain in ("harden-forward", "harden-input"):

            results.append(self._run([
                "delete", "chain", "inet", "stepad", chain
            ]))

        failed = [r["stderr"] for r in results if not r["success"]]

        if failed:

            logger.warning(
                "Al quitar hardening (probablemente no estaba): %s",
                failed
            )

        return {"success": True}
