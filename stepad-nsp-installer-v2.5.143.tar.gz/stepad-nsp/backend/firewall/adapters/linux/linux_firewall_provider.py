import shutil
import subprocess

from backend.firewall.models.firewall_status import FirewallStatus
from backend.firewall.providers.firewall_provider import (
    FirewallProvider
)
from backend.shared.logging.logger import logger


class LinuxFirewallProvider(FirewallProvider):

    CHAIN = "inet stepad forward"

    INPUT_CHAIN = "input"

    def run_command(
        self,
        command
    ):

        result = subprocess.run(
            command,
            capture_output=True,
            text=True
        )

        return {

            "success": result.returncode == 0,

            "stdout": result.stdout.strip(),

            "stderr": result.stderr.strip()

        }

    def initialize(self):

        self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "table",
                "inet",
                "stepad"
            ]
        )

        result = self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "chain",
                "inet",
                "stepad",
                "forward",
                "{",
                "type", "filter", "hook", "forward", "priority", "0", ";",
                "policy", "accept", ";",
                "}"
            ]
        )

        # Si ya existe la cadena, nft devuelve error.
        # Eso no debe detener STEPAD.
        if not result["success"]:

            result = {
                "success": True,
                "message": "Firewall chain already initialized"
            }

        # NFQUEUE para Suricata (respeta modo fail-closed en ajustes IPS).
        try:

            from backend.firewall.services.nfqueue_service import (
                NfqueueService,
            )

            NfqueueService().sync_from_settings()

        except Exception as error:

            logger.warning(
                f"NFQUEUE setup failed: {error}"
            )

        # Re-aplica al arrancar los bloqueos persistidos de IPs
        # atacantes (manuales + automaticos si la opcion esta activa).
        try:

            from backend.ips.services.attack_response_service import (
                attack_response_service,
            )

            attack_response_service.sync()

        except Exception as error:

            logger.warning(
                f"Attack block sync failed on boot: {error}"
            )

        return result

    def _ensure_input_chain(self):

        self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "table",
                "inet",
                "stepad"
            ]
        )

        self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "chain",
                "inet",
                "stepad",
                self.INPUT_CHAIN,
                "{",
                "type", "filter", "hook", "input", "priority", "-10", ";",
                "policy", "accept", ";",
                "}"
            ]
        )

    def _mac_rule_exists(self, chain: str, mac: str) -> bool:

        result = subprocess.run(
            [
                "/usr/sbin/nft",
                "list",
                "chain",
                "inet",
                "stepad",
                chain
            ],
            capture_output=True,
            text=True
        )

        return any(
            mac.lower() in line.lower()
            for line in result.stdout.splitlines()
        )

    def _add_mac_drop(self, chain: str, mac: str):

        return self.run_command(
            [
                "/usr/sbin/nft",
                "add",
                "rule",
                "inet",
                "stepad",
                chain,
                "ether",
                "saddr",
                mac,
                "drop"
            ]
        )

    def _delete_mac_drop(self, chain: str, mac: str):

        result = subprocess.run(
            [
                "/usr/sbin/nft",
                "-a",
                "list",
                "chain",
                "inet",
                "stepad",
                chain
            ],
            capture_output=True,
            text=True
        )

        for line in result.stdout.splitlines():

            if mac.lower() not in line.lower() or "handle" not in line:

                continue

            handle = line.split("handle")[1].strip()

            return self.run_command(
                [
                    "/usr/sbin/nft",
                    "delete",
                    "rule",
                    "inet",
                    "stepad",
                    chain,
                    "handle",
                    handle
                ]
            )

        return {
            "success": False,
            "message": "Rule not found"
        }

    def _clean_queue_rules(self):
        result = self.run_command(
            [
                "/usr/sbin/nft",
                "-a",
                "list",
                "chain",
                "inet",
                "stepad",
                "forward"
            ]
        )
        if not result["success"]:
            return
        for line in result["stdout"].splitlines():
            if "queue" not in line or "handle" not in line:
                continue
            handle = line.split("handle")[1].strip().split()[0]
            self.run_command(
                [
                    "/usr/sbin/nft",
                    "delete",
                    "rule",
                    "inet",
                    "stepad",
                    "forward",
                    "handle",
                    handle
                ]
            )

    def get_status(self) -> FirewallStatus:

        from backend.core.lifecycle.component_status import (
            ComponentStatus
        )


        backend = "NONE"


        if shutil.which("nft"):

            backend = "NFTABLES"

        elif shutil.which("iptables"):

            backend = "IPTABLES"



        status = (

            ComponentStatus.RUNNING

            if backend != "NONE"

            else ComponentStatus.FAILED

        )


        return FirewallStatus(

            name="firewall",

            backend=backend,

            status=status,

            total_rules=0

        )

    def block_mac(
        self,
        mac: str
    ):

        self._ensure_input_chain()

        results = {}

        for chain in ("forward", self.INPUT_CHAIN):

            if self._mac_rule_exists(chain, mac):

                results[chain] = {
                    "success": True,
                    "message": "Rule already exists"
                }

                continue

            results[chain] = self._add_mac_drop(chain, mac)

        success = all(
            result.get("success")
            for result in results.values()
        )

        return {
            "success": success,
            "results": results
        }

    def unblock_mac(
        self,
        mac: str
    ):

        results = {}

        for chain in ("forward", self.INPUT_CHAIN):

            results[chain] = self._delete_mac_drop(chain, mac)

        removed = any(
            result.get("success")
            for result in results.values()
        )

        return {
            "success": removed,
            "results": results
        }