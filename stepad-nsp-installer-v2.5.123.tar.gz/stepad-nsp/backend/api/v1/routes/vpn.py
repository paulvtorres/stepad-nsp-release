from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.vpn.services.vpn_service import VpnService
from backend.vpn.services.tailscale_service import TailscaleService
from backend.api.schemas.tailscale_request import ConnectTailscaleRequest

from backend.api.schemas.vpn_peer_request import (
    CreateVpnPeerRequest,
    UpdateVpnPeerRequest
)


router = APIRouter(
    prefix="/vpn",
    tags=["VPN"]
)

service = VpnService()

tailscale = TailscaleService()


@router.get("/status")
def get_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_status(db)


@router.get("/peers")
def list_peers(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.list_peers(db)


@router.get("/sessions")
def get_sessions(
    current_user: dict = Depends(get_current_user)
):

    return service.provider.sessions()


@router.post("/peers")
def create_peer(
    request: CreateVpnPeerRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.create_peer(
        db,
        request,
        created_by=current_user["user_id"]
    )


@router.patch("/peers/{peer_id}")
def update_peer(
    peer_id: int,
    request: UpdateVpnPeerRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.update_peer(
        db,
        peer_id,
        request,
        changed_by=current_user["user_id"]
    )


@router.delete("/peers/{peer_id}")
def delete_peer(
    peer_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete_peer(
        db,
        peer_id,
        changed_by=current_user["user_id"]
    )


@router.get("/tailscale")
def tailscale_status(
    current_user: dict = Depends(get_current_user)
):

    return tailscale.get_status()


@router.post("/tailscale/connect")
def tailscale_connect(
    request: ConnectTailscaleRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return tailscale.connect(request.auth_key)


@router.post("/tailscale/disconnect")
def tailscale_disconnect(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return tailscale.disconnect()
