import subprocess

from pathlib import Path

from backend.shared.logging.logger import logger


class TailscaleService:

    TAILSCALE = Path("/usr/bin/tailscale")

    def _run(self, *args: str, timeout: int = 30) -> dict:

        if not self.TAILSCALE.exists():

            return {
                "success": False,
                "output": "",
                "error": "tailscale no instalado"
            }

        try:

            result = subprocess.run(
                [str(self.TAILSCALE), *args],
                capture_output=True,
                text=True,
                timeout=timeout
            )

            return {
                "success": result.returncode == 0,
                "output": result.stdout.strip(),
                "error": result.stderr.strip()
            }

        except subprocess.TimeoutExpired:

            return {
                "success": False,
                "output": "",
                "error": "comando tailscale tardó demasiado"
            }

    def get_status(self) -> dict:

        installed = self.TAILSCALE.exists()

        if not installed:

            return {
                "installed": False,
                "state": "not_installed",
                "ip": "",
                "hostname": None,
                "web_url": None,
                "ssh": None
            }

        state = "need_login"
        ip = ""
        hostname = None

        ip_run = self._run("ip", "-4")

        if ip_run["success"] and ip_run["output"]:

            ip = ip_run["output"].splitlines()[0].strip()
            state = "connected"

        st = self._run("status")

        lines = st["output"].splitlines()

        if lines:

            parts = lines[0].split()

            if len(parts) >= 2:

                hostname = parts[1]

        logger.info("Tailscale status: state=%s ip=%s hostname=%s", state, ip, hostname)

        return {
            "installed": installed,
            "state": state,
            "ip": ip,
            "hostname": hostname,
            "web_url": f"https://{ip}:8443" if ip else None,
            "ssh": f"ssh paulan@{ip}" if ip else None
        }

    def connect(self, auth_key: str) -> dict:

        res = self._run(
            "up",
            "--authkey=" + auth_key,
            "--hostname=stepad-nsp",
            "--accept-routes",
            timeout=120
        )

        status = self.get_status()

        return {
            **status,
            "success": res["success"],
            "output": res["output"],
            "error": res["error"]
        }

    def disconnect(self) -> dict:

        res = self._run("logout", timeout=30)

        return {
            "success": res["success"],
            "output": res["output"],
            "error": res["error"]
        }