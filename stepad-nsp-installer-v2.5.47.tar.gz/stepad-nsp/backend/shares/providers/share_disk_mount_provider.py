"""
Mount / protect the dedicated STEPAD network-share disk.

The share disk is always mounted at SHARE_DISK_MOUNT via a systemd
.mount unit keyed by filesystem UUID. While assigned (disk_locked),
it is not meant to be unmounted by hand — only released from the NSP UI.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from backend.core.config.paths import SHARE_DISK_MOUNT, SHARE_DISK_MOUNT_UNIT
from backend.shared.logging.logger import logger


class ShareDiskMountProvider:

    UNIT_PATH = Path(f"/etc/systemd/system/{SHARE_DISK_MOUNT_UNIT}")

    def _run(self, command: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
        return subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    def blkid_field(self, device: str, field: str) -> str | None:
        result = self._run(["blkid", "-s", field, "-o", "value", device])
        if result.returncode != 0:
            return None
        value = (result.stdout or "").strip()
        return value or None

    def is_mounted_at(self, mountpoint: Path | str) -> bool:
        result = self._run(["findmnt", "-n", str(mountpoint)])
        return result.returncode == 0 and bool(result.stdout.strip())

    def current_source(self, mountpoint: Path | str) -> str | None:
        result = self._run(["findmnt", "-n", "-o", "SOURCE", str(mountpoint)])
        if result.returncode != 0:
            return None
        return (result.stdout or "").strip() or None

    def write_mount_unit(self, *, uuid: str, fstype: str) -> None:
        SHARE_DISK_MOUNT.mkdir(parents=True, exist_ok=True)

        # Keep the volume busy-friendly for Samba and remount on boot.
        content = "\n".join([
            "[Unit]",
            "Description=STEPAD network share disk (do not unmount manually)",
            "Documentation=https://stepad.local/shares",
            "Before=smbd.service nmbd.service",
            "Conflicts=umount.target",
            "",
            "[Mount]",
            f"What=/dev/disk/by-uuid/{uuid}",
            f"Where={SHARE_DISK_MOUNT}",
            f"Type={fstype}",
            "Options=defaults,nofail,x-systemd.device-timeout=10s",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ])

        self.UNIT_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.UNIT_PATH.write_text(content, encoding="utf-8")

        self._run(["systemctl", "daemon-reload"])

    def activate(self) -> dict:
        enable = self._run(["systemctl", "enable", SHARE_DISK_MOUNT_UNIT])
        start = self._run(["systemctl", "start", SHARE_DISK_MOUNT_UNIT])
        active = self._run(["systemctl", "is-active", SHARE_DISK_MOUNT_UNIT])

        ok = active.stdout.strip() == "active" or self.is_mounted_at(SHARE_DISK_MOUNT)

        if not ok:
            detail = (start.stderr or enable.stderr or active.stderr or "").strip()
            logger.error("Failed to activate share disk mount: %s", detail)
            return {"success": False, "message": detail or "No se pudo montar el disco."}

        return {
            "success": True,
            "mountpoint": str(SHARE_DISK_MOUNT),
            "message": "Disco montado y protegido.",
        }

    def deactivate(self) -> dict:
        self._run(["systemctl", "stop", SHARE_DISK_MOUNT_UNIT])
        self._run(["systemctl", "disable", SHARE_DISK_MOUNT_UNIT])

        if self.UNIT_PATH.exists():
            try:
                self.UNIT_PATH.unlink()
            except Exception as error:
                logger.warning("Could not remove mount unit: %s", error)

        self._run(["systemctl", "daemon-reload"])

        # Best-effort manual umount if still mounted.
        if self.is_mounted_at(SHARE_DISK_MOUNT):
            umount = self._run(["umount", str(SHARE_DISK_MOUNT)])
            if umount.returncode != 0:
                return {
                    "success": False,
                    "message": (
                        "Disco liberado en configuración, pero sigue montado "
                        f"(ocupado): {(umount.stderr or '').strip()}"
                    ),
                }

        return {"success": True, "message": "Disco liberado."}

    def format_ext4(
        self,
        device: str,
        *,
        label: str = "STEPAD-SHARE",
    ) -> dict:
        """
        Destructive: create ext4 on an existing partition.
        Windows clients access via Samba; ext4 is the NSP-side FS.
        """

        if not device.startswith("/dev/"):
            return {"success": False, "message": "Dispositivo inválido."}

        # Refuse if mounted anywhere.
        findmnt = self._run(["findmnt", "-n", "-S", device])
        if findmnt.returncode == 0 and findmnt.stdout.strip():
            return {
                "success": False,
                "message": (
                    f"{device} está montado. Desmóntalo o libéralo "
                    "antes de formatear."
                ),
            }

        mkfs = self._run(
            [
                "mkfs.ext4",
                "-F",
                "-L", label[:16],
                device,
            ],
            timeout=600,
        )

        if mkfs.returncode != 0:
            return {
                "success": False,
                "message": (mkfs.stderr or mkfs.stdout or "mkfs.ext4 falló").strip(),
            }

        # Refresh kernel partition table / udev.
        self._run(["udevadm", "settle"], timeout=30)
        uuid = self.blkid_field(device, "UUID")
        fstype = self.blkid_field(device, "TYPE") or "ext4"

        return {
            "success": True,
            "device": device,
            "uuid": uuid,
            "fstype": fstype,
            "message": f"Formateado {device} como ext4 (listo para Windows vía Samba).",
        }

    def prepare_whole_disk(
        self,
        disk: str,
        *,
        label: str = "STEPAD-SHARE",
    ) -> dict:
        """
        Wipe disk, create a single GPT partition spanning the device,
        then format ext4. Only for empty secondary disks.
        """

        if not disk.startswith("/dev/"):
            return {"success": False, "message": "Disco inválido."}

        # Ensure nothing on this disk is mounted.
        lsblk = self._run(["lsblk", "-lnpo", "NAME,MOUNTPOINT", disk])
        for line in (lsblk.stdout or "").splitlines():
            parts = line.split(None, 1)
            if len(parts) == 2 and parts[1].strip():
                return {
                    "success": False,
                    "message": (
                        f"Hay particiones montadas en {disk} "
                        f"({parts[0]} → {parts[1]}). Libéralas primero."
                    ),
                }

        # Clear signatures and create one partition.
        self._run(["wipefs", "-a", disk], timeout=60)
        parted = self._run(
            [
                "parted", "-s", disk,
                "mklabel", "gpt",
                "mkpart", "primary", "ext4", "1MiB", "100%",
            ],
            timeout=120,
        )
        if parted.returncode != 0:
            return {
                "success": False,
                "message": (parted.stderr or parted.stdout or "parted falló").strip(),
            }

        self._run(["partprobe", disk], timeout=30)
        self._run(["udevadm", "settle"], timeout=30)

        # Resolve first partition path (sdb1 / nvme0n1p1).
        part = None
        for candidate in (f"{disk}1", f"{disk}p1"):
            if Path(candidate).exists():
                part = candidate
                break

        if not part:
            # Wait briefly for device node.
            import time
            for _ in range(10):
                time.sleep(0.3)
                for candidate in (f"{disk}1", f"{disk}p1"):
                    if Path(candidate).exists():
                        part = candidate
                        break
                if part:
                    break

        if not part:
            return {
                "success": False,
                "message": "Se creó la partición pero no aparece el dispositivo.",
            }

        return self.format_ext4(part, label=label)

    def ensure_boot(self, uuid: str | None, fstype: str | None = None) -> None:
        if not uuid:
            return
        fstype = fstype or self.blkid_field(f"/dev/disk/by-uuid/{uuid}", "TYPE") or "auto"
        try:
            self.write_mount_unit(uuid=uuid, fstype=fstype)
            self.activate()
        except Exception as error:
            logger.error("Share disk boot mount failed: %s", error)

