"""
Network disk shares: one share root (disk/folder) + named folders whose
access is granted by device groups (same groups used for web filter /
bandwidth). Samba enforces access by client IP (hosts allow).
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.core.database.session import SessionLocal
from backend.groups.models.device_group import DeviceGroup, GroupDevice
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.interfaces.services.interface_service import (
    InterfaceService,
)
from backend.shares.models.network_share_folder import (
    GroupFolderAccess,
    NetworkShareFolder,
)
from backend.shares.models.network_share_settings import NetworkShareSettings
from backend.shares.providers.samba_share_provider import SambaShareProvider
from backend.shares.providers.share_disk_mount_provider import (
    ShareDiskMountProvider,
)
from backend.core.config.paths import SHARE_DISK_MOUNT
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


_FOLDER_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")

# System mountpoints that must never be used as the share root.
_FORBIDDEN_TARGETS = {
    "/",
    "/boot",
    "/boot/efi",
    "/etc",
    "/usr",
    "/var",
    "/home",
    "/root",
    "/tmp",
    "/opt",
}


class NetworkShareService:

    def __init__(self):
        self.provider = SambaShareProvider()
        self.disk_mount = ShareDiskMountProvider()
        self.interface_service = InterfaceService()

    def _settings(self, db: Session) -> NetworkShareSettings:
        row = db.get(NetworkShareSettings, 1)
        if row is None:
            row = NetworkShareSettings(
                id=1,
                enabled=False,
                share_root=None,
                device_path=None,
                device_uuid=None,
                disk_locked=False,
                workgroup="WORKGROUP",
            )
            db.add(row)
            db.commit()
            db.refresh(row)
        return row

    def _lan_ip(self) -> str | None:
        lan = self.interface_service.get_primary_lan()
        if not lan:
            return None
        ip = getattr(lan, "ip", None) or getattr(lan, "ipv4_address", None)
        return ip.strip() if isinstance(ip, str) and ip.strip() else None

    def _run(self, command: list[str], timeout: int = 5) -> str:
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            if result.returncode != 0:
                return ""
            return (result.stdout or "").strip()
        except Exception:
            return ""

    def _parent_disk_name(self, device: str | None) -> str | None:
        """
        /dev/sda2 -> sda, /dev/nvme0n1p3 -> nvme0n1, /dev/sdb -> sdb.
        """

        if not device:
            return None

        device = device.strip()
        if not device.startswith("/dev/"):
            return None

        pkname = self._run(["lsblk", "-no", "PKNAME", device])
        if pkname:
            return pkname.splitlines()[0].strip() or None

        name = self._run(["lsblk", "-no", "NAME", device])
        if name:
            return name.splitlines()[0].strip() or None

        return Path(device).name or None

    def _os_disk_name(self) -> str | None:
        """Block device that holds the OS root filesystem (/)."""

        source = self._run(["findmnt", "-n", "-o", "SOURCE", "/"])
        if not source:
            return None

        # LVM/mapper: still resolve via lsblk PKNAME when possible.
        parent = self._parent_disk_name(source.splitlines()[0].strip())
        if parent:
            return parent

        return Path(source.splitlines()[0].strip()).name or None

    def _transport_of(self, disk_name: str | None) -> str | None:
        if not disk_name:
            return None
        tran = self._run(["lsblk", "-no", "TRAN", f"/dev/{disk_name}"])
        if not tran:
            return None
        return tran.splitlines()[0].strip().lower() or None

    def _model_of(self, disk_name: str | None) -> str | None:
        if not disk_name:
            return None
        model = self._run(["lsblk", "-no", "MODEL", f"/dev/{disk_name}"])
        if not model:
            return None
        return model.splitlines()[0].strip() or None

    def _path_backing_disk(self, path: str) -> str | None:
        """Parent disk name for whatever device currently backs `path`."""

        source = self._run(["findmnt", "-n", "-o", "SOURCE", "-T", path])
        if not source:
            return None
        return self._parent_disk_name(source.splitlines()[0].strip())

    def _is_os_disk_path(self, path: str) -> bool:
        os_disk = self._os_disk_name()
        if not os_disk:
            # Fail closed: if we cannot identify the OS disk, reject
            # anything under the root filesystem mount.
            target = self._run(["findmnt", "-n", "-o", "TARGET", "-T", path])
            return (target.splitlines()[0].strip() if target else "/") == "/"

        backing = self._path_backing_disk(path)
        return backing == os_disk

    def _validate_share_root(self, root: str) -> Path:
        """
        Share root must be an absolute path on a secondary disk
        (extra SATA/NVMe/USB), never the OS disk.
        """

        root = (root or "").strip()
        if not root:
            raise HTTPException(
                400,
                "Indica el punto de montaje del disco compartido "
                "(USB o disco adicional, no el del sistema).",
            )

        if ".." in root or not root.startswith("/"):
            raise HTTPException(400, "La ruta debe ser absoluta.")

        path = Path(root)
        if path.exists() and not path.is_dir():
            raise HTTPException(400, "La ruta debe ser un directorio.")

        resolved = str(path.resolve() if path.exists() else path)

        if resolved.rstrip("/") in _FORBIDDEN_TARGETS or resolved == "/":
            raise HTTPException(
                400,
                "No se puede usar una ruta del sistema operativo como disco compartido.",
            )

        # Creating the directory only makes sense on an already-mounted
        # secondary volume. Do not mkdir on the OS disk.
        if not path.exists():
            parent = path.parent
            if not parent.exists():
                raise HTTPException(
                    400,
                    "Monta primero el disco adicional (USB/SATA) y elige "
                    "su punto de montaje. No uses el disco del sistema.",
                )
            if self._is_os_disk_path(str(parent)):
                raise HTTPException(
                    400,
                    "Esa ruta está en el disco del sistema operativo. "
                    "Conecta un disco USB o un disco adicional a la placa "
                    "y selecciona su montaje.",
                )
            path.mkdir(parents=True, exist_ok=True)

        if self._is_os_disk_path(str(path)):
            raise HTTPException(
                400,
                "El disco compartido no puede ser el mismo donde está el SO. "
                "Usa un disco USB o un disco adicional conectado a la placa.",
            )

        return path

    def list_units(self) -> list[dict]:
        """
        Secondary disk units (partitions with a filesystem) that can
        become the dedicated network-share disk. Excludes the OS disk.
        """

        os_disk = self._os_disk_name()
        units: list[dict] = []

        try:
            result = subprocess.run(
                [
                    "lsblk", "-nbpo",
                    "NAME,TYPE,SIZE,MOUNTPOINT,FSTYPE,UUID,PKNAME,TRAN,MODEL,LABEL",
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except Exception:
            return units

        if result.returncode != 0:
            return units

        # Prefer JSON for robust parsing.
        try:
            import json

            js = subprocess.run(
                ["lsblk", "-J", "-o",
                 "NAME,PATH,TYPE,SIZE,MOUNTPOINT,FSTYPE,UUID,PKNAME,TRAN,MODEL,LABEL"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if js.returncode == 0 and js.stdout:
                tree = json.loads(js.stdout)
                return self._units_from_lsblk_tree(tree.get("blockdevices") or [], os_disk)
        except Exception:
            pass

        return units

    def _units_from_lsblk_tree(
        self,
        devices: list[dict],
        os_disk: str | None,
        parent_disk: str | None = None,
        parent_tran: str | None = None,
        parent_model: str | None = None,
    ) -> list[dict]:
        units: list[dict] = []

        for device in devices:
            name = device.get("name") or ""
            typ = (device.get("type") or "").lower()
            path = device.get("path") or (f"/dev/{name}" if name else None)
            children = device.get("children") or []

            if typ == "disk":
                disk_name = name
                if os_disk and disk_name == os_disk:
                    continue
                tran = (device.get("tran") or parent_tran or "").lower() or None
                model = device.get("model") or parent_model
                child_units = self._units_from_lsblk_tree(
                    children,
                    os_disk,
                    parent_disk=disk_name,
                    parent_tran=tran,
                    parent_model=model,
                )
                units.extend(child_units)

                # Empty secondary disk (no partitions): offer full format.
                if path and not children:
                    bus = "USB" if (tran or "") == "usb" else (tran or "disk").upper()
                    title = f"{bus} · {path}"
                    if model:
                        title = f"{bus} · {model} · {path}"
                    units.append({
                        "device": path,
                        "disk": disk_name,
                        "uuid": None,
                        "fstype": None,
                        "size": device.get("size"),
                        "mountpoint": None,
                        "transport": tran or "internal",
                        "model": model,
                        "label": None,
                        "title": title + " (disco completo)",
                        "assigned": False,
                        "locked": False,
                        "selectable": False,
                        "formattable": True,
                        "whole_disk": True,
                        "hint": "Formatear creará una partición ext4 para compartir por Samba.",
                    })
                continue

            if typ != "part":
                units.extend(
                    self._units_from_lsblk_tree(
                        children,
                        os_disk,
                        parent_disk=parent_disk,
                        parent_tran=parent_tran,
                        parent_model=parent_model,
                    )
                )
                continue

            disk_name = parent_disk or device.get("pkname")
            if os_disk and disk_name == os_disk:
                continue

            if not path:
                continue

            fstype = device.get("fstype")
            uuid = device.get("uuid")
            tran = (parent_tran or device.get("tran") or "").lower() or "internal"
            model = parent_model or device.get("model")
            mountpoint = device.get("mountpoint") or None
            size = device.get("size")
            label = device.get("label")

            bus = "USB" if tran == "usb" else (tran or "disk").upper()
            title = f"{bus} · {path}"
            if model:
                title = f"{bus} · {model} · {path}"
            if label:
                title += f" ({label})"

            has_fs = bool(fstype and uuid)
            units.append({
                "device": path,
                "disk": disk_name,
                "uuid": uuid,
                "fstype": fstype,
                "size": size,
                "mountpoint": mountpoint,
                "transport": tran,
                "model": model,
                "label": label,
                "title": title if has_fs else f"{title} (sin formato)",
                "assigned": False,
                "locked": False,
                "selectable": has_fs,
                "formattable": not bool(mountpoint),
                "whole_disk": False,
                "hint": (
                    None if has_fs
                    else "Formatea en ext4 desde el NSP para usarlo como disco compartido."
                ),
            })

        return units

    def format_disk(
        self,
        db: Session,
        device: str,
        *,
        confirm: str,
        assign: bool = True,
        whole_disk: bool = False,
    ) -> dict:
        """
        Format a secondary unit as ext4 (Windows accesses via Samba).
        Requires confirm == 'FORMATEAR'. Optionally assigns as share disk.
        """

        if (confirm or "").strip().upper() != "FORMATEAR":
            raise HTTPException(
                400,
                "Para confirmar el borrado escribe FORMATEAR.",
            )

        device = (device or "").strip()
        if not device.startswith("/dev/"):
            raise HTTPException(400, "Indica una unidad /dev/...")

        os_disk = self._os_disk_name()
        parent = self._parent_disk_name(device) or Path(device).name

        # Whole disk path: parent is itself.
        disk_name = Path(device).name if whole_disk else parent
        if os_disk and (
            disk_name == os_disk
            or Path(device).name == os_disk
        ):
            raise HTTPException(
                400,
                "No se puede formatear el disco del sistema operativo.",
            )

        row = self._settings(db)
        if row.disk_locked and row.device_path:
            # Formatting the locked share disk requires release first.
            if (
                row.device_path == device
                or (row.device_uuid and device.endswith(Path(row.device_path).name))
            ):
                raise HTTPException(
                    400,
                    "Libera el disco compartido antes de formatearlo de nuevo.",
                )

        # Must appear in our secondary unit list (or be a listed whole disk).
        units = {u["device"]: u for u in self.list_units()}
        unit = units.get(device)
        if not unit or not unit.get("formattable"):
            raise HTTPException(
                400,
                "Esa unidad no se puede formatear (¿es del SO o está montada?).",
            )

        if unit.get("whole_disk") or whole_disk:
            result = self.disk_mount.prepare_whole_disk(device)
        else:
            result = self.disk_mount.format_ext4(device)

        if not result.get("success"):
            raise HTTPException(500, result.get("message") or "Formateo falló.")

        target = result.get("device") or device

        if assign:
            # Fresh UUID after format — assign_disk will remount/lock.
            if row.disk_locked and row.device_uuid:
                raise HTTPException(
                    400,
                    "Ya hay un disco compartido. Libéralo antes de asignar el nuevo.",
                )
            return self.assign_disk(db, target)

        status = self.get_status(db)
        status["message"] = result.get("message")
        status["formatted_device"] = target
        return status

    def list_candidate_roots(self) -> list[dict]:
        """Backward-compatible alias: mounted secondary volumes only."""

        return [
            {
                "path": unit["mountpoint"],
                "label": unit["title"],
                "kind": "mount",
                "device": unit["device"],
                "disk": unit["disk"],
                "transport": unit["transport"],
                "model": unit["model"],
                "fstype": unit["fstype"],
                "mounted": True,
                "exists": True,
                "usable": True,
            }
            for unit in self.list_units()
            if unit.get("mountpoint") and unit.get("selectable")
        ]

    def assign_disk(self, db: Session, device: str) -> dict:
        """
        Select a secondary partition as the dedicated share disk:
        mount it at SHARE_DISK_MOUNT, persist via systemd, lock it.
        """

        device = (device or "").strip()
        if not device.startswith("/dev/"):
            raise HTTPException(400, "Indica una unidad /dev/...")

        units = {u["device"]: u for u in self.list_units()}
        unit = units.get(device)
        if not unit:
            raise HTTPException(
                400,
                "Esa unidad no es válida (¿es el disco del SO o no tiene sistema de archivos?).",
            )

        uuid = unit["uuid"]
        fstype = unit["fstype"]
        mountpoint = unit.get("mountpoint")

        if mountpoint and Path(mountpoint).resolve() != SHARE_DISK_MOUNT.resolve():
            if mountpoint.rstrip("/") in _FORBIDDEN_TARGETS:
                raise HTTPException(400, "No se puede usar una ruta del sistema.")
            # Already mounted elsewhere: refuse to steal silently.
            raise HTTPException(
                400,
                f"La unidad está montada en {mountpoint}. "
                f"Desmóntala primero o elige otra; el NSP la montará en "
                f"{SHARE_DISK_MOUNT} y la dejará protegida.",
            )

        row = self._settings(db)

        # Replacing a locked disk requires an explicit release first.
        if (
            row.disk_locked
            and row.device_uuid
            and row.device_uuid != uuid
        ):
            raise HTTPException(
                400,
                "Ya hay un disco compartido protegido. "
                "Libéralo antes de asignar otra unidad.",
            )

        self.disk_mount.write_mount_unit(uuid=uuid, fstype=fstype)
        result = self.disk_mount.activate()
        if not result.get("success"):
            raise HTTPException(500, result.get("message") or "No se pudo montar el disco.")

        row.device_path = device
        row.device_uuid = uuid
        row.share_root = str(SHARE_DISK_MOUNT)
        row.disk_locked = True
        row.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(row)

        self.apply(db)
        status = self.get_status(db)
        status["message"] = (
            "Disco asignado como compartido. Queda montado de forma "
            "persistente y no debe desmontarse a mano."
        )
        return status

    def release_disk(self, db: Session) -> dict:
        """
        Explicit admin action to unlock/unmount the share disk.
        Stops Samba shares first so the volume is not busy.
        """

        row = self._settings(db)

        if not row.device_uuid and not row.disk_locked:
            raise HTTPException(400, "No hay disco compartido asignado.")

        # Stop serving files so umount can succeed.
        was_enabled = bool(row.enabled)
        row.enabled = False
        db.commit()
        try:
            self.provider.apply(enabled=False)
        except Exception as error:
            logger.warning("Could not stop Samba before release: %s", error)

        result = self.disk_mount.deactivate()

        row.device_path = None
        row.device_uuid = None
        row.share_root = None
        row.disk_locked = False
        row.enabled = False
        row.updated_at = datetime.utcnow()
        db.commit()

        status = self.get_status(db)
        status["message"] = result.get("message") or "Disco liberado."
        status["release_ok"] = bool(result.get("success"))
        status["was_enabled"] = was_enabled
        return status

    def get_status(self, db: Session) -> dict:
        row = self._settings(db)
        runtime = self.provider.status()
        folders = self.list_folders(db)
        lan_ip = self._lan_ip()
        os_disk = self._os_disk_name()
        root_ok = False
        root_error = None

        if row.share_root:
            try:
                self._validate_share_root(row.share_root)
                root_ok = True
            except HTTPException as error:
                root_error = error.detail

        units = self.list_units()
        for unit in units:
            if row.device_uuid and unit.get("uuid") == row.device_uuid:
                unit["assigned"] = True
                unit["locked"] = bool(row.disk_locked)
            elif row.device_path and unit.get("device") == row.device_path:
                unit["assigned"] = True
                unit["locked"] = bool(row.disk_locked)

        mounted = self.disk_mount.is_mounted_at(SHARE_DISK_MOUNT)

        return {
            "enabled": bool(row.enabled),
            "share_root": row.share_root,
            "share_root_ok": root_ok,
            "share_root_error": root_error,
            "device_path": row.device_path,
            "device_uuid": row.device_uuid,
            "disk_locked": bool(row.disk_locked),
            "mountpoint": str(SHARE_DISK_MOUNT),
            "mounted": mounted,
            "os_disk": f"/dev/{os_disk}" if os_disk else None,
            "workgroup": row.workgroup,
            "server_name": row.server_name,
            "updated_at": to_iso_utc(row.updated_at) if row.updated_at else None,
            "lan_ip": lan_ip,
            "unc_base": f"\\\\{lan_ip}" if lan_ip else None,
            "samba": runtime,
            "folders": folders,
            "units": units,
            "candidates": self.list_candidate_roots(),
            "ready": bool(
                row.enabled
                and root_ok
                and row.disk_locked
                and mounted
                and runtime.get("installed")
                and runtime.get("smbd_active")
            ),
        }

    def update_settings(
        self,
        db: Session,
        *,
        enabled: bool | None = None,
        share_root: str | None = None,
        workgroup: str | None = None,
        server_name: str | None = None,
    ) -> dict:
        row = self._settings(db)

        if share_root is not None:
            path = self._validate_share_root(share_root)
            row.share_root = str(path)

        if workgroup is not None:
            row.workgroup = (workgroup.strip() or "WORKGROUP")[:64]

        if server_name is not None:
            value = server_name.strip()
            row.server_name = value[:64] if value else None

        if enabled is not None:
            if enabled:
                root = share_root if share_root is not None else row.share_root
                if not row.disk_locked or not row.device_uuid:
                    raise HTTPException(
                        400,
                        "Primero asigna una unidad como disco compartido "
                        "(USB o disco adicional).",
                    )
                if not root:
                    raise HTTPException(
                        400,
                        "Antes de activar, elige un disco USB o adicional "
                        "(no el disco del sistema).",
                    )
                self._validate_share_root(root)
            row.enabled = bool(enabled)

        row.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(row)

        self.apply(db)

        return self.get_status(db)

    def _require_share_root(self, db: Session) -> Path:
        row = self._settings(db)
        if not row.share_root:
            raise HTTPException(
                400,
                "Configura primero el disco compartido (USB o disco adicional).",
            )
        return self._validate_share_root(row.share_root)

    def list_folders(self, db: Session) -> list[dict]:
        folders = (
            db.query(NetworkShareFolder)
            .order_by(NetworkShareFolder.name)
            .all()
        )
        return [self._folder_dict(db, folder) for folder in folders]

    def _folder_dict(self, db: Session, folder: NetworkShareFolder) -> dict:
        row = self._settings(db)
        root = Path(row.share_root) if row.share_root else None
        path = str(root / folder.folder_name) if root else None

        accesses = (
            db.query(GroupFolderAccess, DeviceGroup)
            .join(DeviceGroup, DeviceGroup.id == GroupFolderAccess.group_id)
            .filter(GroupFolderAccess.folder_id == folder.id)
            .all()
        )

        groups = [
            {
                "group_id": group.id,
                "group_name": group.name,
                "access_mode": access.access_mode,
            }
            for access, group in accesses
        ]

        lan_ip = self._lan_ip()

        return {
            "id": folder.id,
            "name": folder.name,
            "folder_name": folder.folder_name,
            "description": folder.description,
            "enabled": folder.enabled,
            "path": path,
            "unc_path": f"\\\\{lan_ip}\\{folder.name}" if lan_ip else None,
            "groups": groups,
            "created_at": to_iso_utc(folder.created_at) if folder.created_at else None,
        }

    def create_folder(
        self,
        db: Session,
        *,
        name: str,
        folder_name: str | None = None,
        description: str | None = None,
    ) -> dict:
        self._require_share_root(db)

        name = (name or "").strip()
        if not name:
            raise HTTPException(400, "El nombre de la carpeta es obligatorio.")

        slug = (folder_name or name).strip().replace(" ", "_")
        if not _FOLDER_NAME_RE.match(slug):
            raise HTTPException(
                400,
                "Nombre de carpeta inválido (usa letras, números, . _ -).",
            )

        if db.query(NetworkShareFolder).filter(
            (NetworkShareFolder.name == name)
            | (NetworkShareFolder.folder_name == slug)
        ).first():
            raise HTTPException(400, "Ya existe una carpeta con ese nombre.")

        folder = NetworkShareFolder(
            name=name,
            folder_name=slug,
            description=(description or "").strip() or None,
            enabled=True,
        )
        db.add(folder)
        db.commit()
        db.refresh(folder)

        self._ensure_folder_dir(db, folder)
        self.apply(db)

        return self._folder_dict(db, folder)

    def delete_folder(self, db: Session, folder_id: int) -> dict:
        folder = db.get(NetworkShareFolder, folder_id)
        if not folder:
            raise HTTPException(404, "Carpeta no encontrada.")

        db.query(GroupFolderAccess).filter(
            GroupFolderAccess.folder_id == folder_id
        ).delete()
        db.delete(folder)
        db.commit()

        self.apply(db)
        return {"success": True}

    def set_folder_groups(
        self,
        db: Session,
        folder_id: int,
        grants: list[dict],
    ) -> dict:
        """
        grants: [{group_id, access_mode: read|write}, ...]
        Replaces all access rows for the folder.
        """

        folder = db.get(NetworkShareFolder, folder_id)
        if not folder:
            raise HTTPException(404, "Carpeta no encontrada.")

        db.query(GroupFolderAccess).filter(
            GroupFolderAccess.folder_id == folder_id
        ).delete()

        for grant in grants or []:
            group_id = int(grant["group_id"])
            mode = (grant.get("access_mode") or "read").strip().lower()
            if mode not in ("read", "write"):
                raise HTTPException(400, "access_mode debe ser read o write.")
            if not db.get(DeviceGroup, group_id):
                raise HTTPException(400, f"Grupo {group_id} no existe.")
            db.add(GroupFolderAccess(
                group_id=group_id,
                folder_id=folder_id,
                access_mode=mode,
            ))

        db.commit()
        self.apply(db)
        return self._folder_dict(db, folder)

    def list_group_folders(self, db: Session, group_id: int) -> list[dict]:
        rows = (
            db.query(GroupFolderAccess, NetworkShareFolder)
            .join(
                NetworkShareFolder,
                NetworkShareFolder.id == GroupFolderAccess.folder_id,
            )
            .filter(GroupFolderAccess.group_id == group_id)
            .all()
        )
        return [
            {
                "folder_id": folder.id,
                "name": folder.name,
                "folder_name": folder.folder_name,
                "access_mode": access.access_mode,
                "enabled": folder.enabled,
            }
            for access, folder in rows
        ]

    def set_group_folders(
        self,
        db: Session,
        group_id: int,
        grants: list[dict],
    ) -> list[dict]:
        """
        grants: [{folder_id, access_mode}, ...] for one group.
        """

        if not db.get(DeviceGroup, group_id):
            raise HTTPException(404, "Grupo no encontrado.")

        db.query(GroupFolderAccess).filter(
            GroupFolderAccess.group_id == group_id
        ).delete()

        for grant in grants or []:
            folder_id = int(grant["folder_id"])
            mode = (grant.get("access_mode") or "read").strip().lower()
            if mode not in ("read", "write"):
                raise HTTPException(400, "access_mode debe ser read o write.")
            if not db.get(NetworkShareFolder, folder_id):
                raise HTTPException(400, f"Carpeta {folder_id} no existe.")
            db.add(GroupFolderAccess(
                group_id=group_id,
                folder_id=folder_id,
                access_mode=mode,
            ))

        db.commit()
        self.apply(db)
        return self.list_group_folders(db, group_id)

    def _ensure_folder_dir(
        self,
        db: Session,
        folder: NetworkShareFolder,
    ) -> Path:
        root = self._require_share_root(db)
        path = root / folder.folder_name
        path.mkdir(parents=True, exist_ok=True)
        try:
            shutil.chown(path, user="nobody", group="nogroup")
            os.chmod(path, 0o775)
        except Exception as error:
            logger.warning("Could not chown share folder %s: %s", path, error)
        return path

    def _ips_for_groups(self, db: Session, group_ids: list[int]) -> list[str]:
        if not group_ids:
            return []

        rows = (
            db.query(NetworkDevice.ip_address)
            .join(GroupDevice, GroupDevice.device_id == NetworkDevice.id)
            .filter(GroupDevice.group_id.in_(group_ids))
            .filter(NetworkDevice.ip_address.isnot(None))
            .all()
        )

        ips = sorted({
            (ip or "").strip()
            for (ip,) in rows
            if ip and ip.strip() and ip.strip() != "0.0.0.0"
        })
        return ips

    def build_samba_shares(self, db: Session) -> list[dict]:
        row = self._settings(db)
        if not row.share_root:
            return []

        try:
            self._validate_share_root(row.share_root)
        except HTTPException:
            logger.warning(
                "Share root %s is on the OS disk or invalid; skipping Samba shares.",
                row.share_root,
            )
            return []

        shares = []

        folders = (
            db.query(NetworkShareFolder)
            .filter(NetworkShareFolder.enabled.is_(True))
            .all()
        )

        for folder in folders:
            path = self._ensure_folder_dir(db, folder)
            accesses = (
                db.query(GroupFolderAccess)
                .filter(GroupFolderAccess.folder_id == folder.id)
                .all()
            )
            if not accesses:
                continue

            group_ids = [a.group_id for a in accesses]
            ips = self._ips_for_groups(db, group_ids)
            if not ips:
                # Share exists but no online devices yet — deny all except localhost.
                ips = []

            write = any(a.access_mode == "write" for a in accesses)

            shares.append({
                "name": folder.name,
                "path": str(path),
                "comment": folder.description or folder.name,
                "read_only": not write,
                "hosts_allow": ips,
            })

        return shares

    def apply(self, db: Session | None = None) -> dict:
        owns = db is None
        if owns:
            db = SessionLocal()
        try:
            row = self._settings(db)
            shares = self.build_samba_shares(db) if row.enabled else []

            if row.enabled and row.share_root:
                try:
                    self._validate_share_root(row.share_root)
                except HTTPException as error:
                    logger.warning(
                        "Cannot apply network shares: %s",
                        error.detail,
                    )
                    shares = []
                    return self.provider.apply(enabled=False)

            self.provider.write_config(
                workgroup=row.workgroup or "WORKGROUP",
                server_name=row.server_name,
                shares=shares,
            )
            return self.provider.apply(enabled=bool(row.enabled) and bool(shares or row.share_root))
        finally:
            if owns:
                db.close()

    def sync_access(self) -> None:
        """Called when group membership changes so hosts allow stays current."""

        try:
            self.apply()
        except Exception as error:
            logger.exception("Network share sync failed: %s", error)

    def ensure_boot(self) -> None:
        try:
            db = SessionLocal()
            try:
                row = self._settings(db)
                if row.device_uuid and row.disk_locked:
                    fstype = self.disk_mount.blkid_field(
                        f"/dev/disk/by-uuid/{row.device_uuid}",
                        "TYPE",
                    )
                    self.disk_mount.ensure_boot(row.device_uuid, fstype)
                    if not row.share_root:
                        row.share_root = str(SHARE_DISK_MOUNT)
                        db.commit()
            finally:
                db.close()
            self.apply()
        except Exception as error:
            logger.error("Network share boot error: %s", error)
