from pathlib import Path
from backend.core.config.settings import (
    Settings
)

STEPAD_DIR = Settings.STEPAD_DIR

DNS_DIR = STEPAD_DIR / "dns"

DNSMASQ_CONFIG = DNS_DIR / "dnsmasq.conf"

DOMAINS_CONFIG = DNS_DIR / "blocked_domains.conf"

RESERVATIONS_CONFIG = DNS_DIR / "reservations.conf"

DNSMASQ_PID_FILE = DNS_DIR / "dnsmasq.pid"

DNSMASQ_LOG_FILE = DNS_DIR / "dnsmasq.log"

POWERDNS_DIR = STEPAD_DIR / "powerdns"

RPZ_ZONE_FILE = POWERDNS_DIR / "blocked_domains.rpz"

RPZ_LUA_CONFIG = POWERDNS_DIR / "rpz.lua"

ZONES_DIR = STEPAD_DIR / "zones"

ZONES_DHCP_CONFIG = DNS_DIR / "zones.conf"

DNSMASQ_LEASES_FILE = Path("/var/lib/misc/dnsmasq.leases")

MAINTENANCE_DIR = STEPAD_DIR / "maintenance"

LAN_OVERRIDE_STATE_FILE = MAINTENANCE_DIR / "lan_override.json"

FIREWALL_DIR = STEPAD_DIR / "firewall"

ENCRYPTED_DNS_STATE_FILE = FIREWALL_DIR / "encrypted_dns_state.json"

STEPAD_PID_FILE = STEPAD_DIR / "stepad.pid"

SAMBA_DIR = STEPAD_DIR / "samba"

SAMBA_CONFIG = SAMBA_DIR / "smb.conf"

SAMBA_SHARES_ROOT_DEFAULT = Path("/srv/stepad-shares")

# Fixed mountpoint for the dedicated secondary share disk (USB/SATA).
SHARE_DISK_MOUNT = Path("/mnt/stepad-share-disk")

SHARE_DISK_MOUNT_UNIT = "mnt-stepad-share-disk.mount"
