import { useEffect, useMemo, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getShareStatus,
    updateShareConfig,
    assignShareDisk,
    releaseShareDisk,
    formatShareDisk,
    createShareFolder,
    deleteShareFolder,
    setShareFolderGroups,
    getGroups,
} from "../../services/api";

import "./shares.css";


function StepPill({ n, label, active, done }) {
    return (
        <div className={`sh-step ${active ? "active" : ""} ${done ? "done" : ""}`}>
            <span className="sh-step-n">{done ? "✓" : n}</span>
            <span className="sh-step-label">{label}</span>
        </div>
    );
}


function StatusDot({ ok, warn }) {
    const cls = ok ? "ok" : warn ? "warn" : "off";
    return <span className={`sh-dot ${cls}`} aria-hidden />;
}


function Shares() {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);
    const [groups, setGroups] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);
    const [workgroup, setWorkgroup] = useState("WORKGROUP");
    const [folderForm, setFolderForm] = useState({ name: "", description: "" });
    const [expandedFolder, setExpandedFolder] = useState(null);

    function load() {
        Promise.all([getShareStatus(), getGroups()])
            .then(([s, g]) => {
                setStatus(s);
                setWorkgroup(s.workgroup || "WORKGROUP");
                setGroups(g || []);
            })
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(load, 20000);
        return () => clearInterval(timer);
    }, []);

    const folders = status?.folders || [];
    const units = status?.units || [];
    const diskReady = Boolean(status?.disk_locked && status?.mounted);
    const sharingOn = Boolean(status?.enabled);
    const hasFolders = folders.length > 0;

    const currentStep = useMemo(() => {
        if (!diskReady) return 1;
        if (!sharingOn) return 2;
        return 3;
    }, [diskReady, sharingOn]);

    async function saveConfig(patch) {
        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await updateShareConfig(patch);
            setStatus(next);
            setWorkgroup(next.workgroup || "WORKGROUP");
            if (patch.enabled) {
                setNotice(
                    patch.enabled
                        ? "Compartido en red activado."
                        : "Compartido en red desactivado."
                );
            }
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleAssignDisk(device) {
        if (!device) return;
        if (!confirm(
            `¿Usar ${device} como disco compartido?\n\n`
            + "Quedará montado de forma permanente. "
            + "Solo se puede liberar desde esta pantalla."
        )) return;

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await assignShareDisk(device);
            setStatus(next);
            setNotice(next?.message || "Disco asignado correctamente.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleReleaseDisk() {
        if (!confirm(
            "¿Liberar el disco compartido?\n\n"
            + "Se detendrá el servicio y se desmontará la unidad. "
            + "Las carpetas dejarán de estar disponibles en la red."
        )) return;

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await releaseShareDisk();
            setStatus(next);
            setNotice(next?.message || "Disco liberado.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleFormatDisk(unit) {
        const device = unit?.device;
        if (!device) return;
        const whole = Boolean(unit.whole_disk);

        if (!confirm(
            `Se borrarán TODOS los datos de ${device}.\n\n`
            + (whole
                ? "Se creará una partición y se formateará (ext4).\n"
                : "Se formateará la partición (ext4).\n")
            + "Windows accederá por red (Samba), no necesita NTFS.\n\n"
            + "¿Continuar?"
        )) return;

        const typed = window.prompt(
            "Escribe FORMATEAR para confirmar (borra todo el contenido):"
        );
        if ((typed || "").trim().toUpperCase() !== "FORMATEAR") {
            setError("Formateo cancelado.");
            return;
        }
        if (status?.disk_locked) {
            setError("Libera el disco actual antes de formatear otra unidad.");
            return;
        }

        setError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await formatShareDisk({
                device,
                confirm: "FORMATEAR",
                assign: true,
                whole_disk: whole,
            });
            setStatus(next);
            setNotice(next?.message || "Disco formateado y listo para compartir.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleCreateFolder() {
        if (!folderForm.name.trim()) {
            setError("Indica el nombre de la carpeta.");
            return;
        }
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await createShareFolder({
                name: folderForm.name.trim(),
                description: folderForm.description.trim() || null,
            });
            setFolderForm({ name: "", description: "" });
            setNotice("Carpeta creada.");
            load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDeleteFolder(folder) {
        if (!confirm(`¿Eliminar la carpeta «${folder.name}» de la red?`)) return;
        setBusy(true);
        setError(null);
        try {
            await deleteShareFolder(folder.id);
            setNotice("Carpeta eliminada.");
            load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function toggleGroupOnFolder(folder, group, accessMode) {
        const current = folder.groups || [];
        const exists = current.find((g) => g.group_id === group.id);
        let next;
        if (exists && exists.access_mode === accessMode) {
            next = current.filter((g) => g.group_id !== group.id);
        } else if (exists) {
            next = current.map((g) =>
                g.group_id === group.id ? { ...g, access_mode: accessMode } : g
            );
        } else {
            next = [...current, { group_id: group.id, access_mode: accessMode }];
        }

        setBusy(true);
        setError(null);
        try {
            await setShareFolderGroups(folder.id, {
                groups: next.map((g) => ({
                    group_id: g.group_id,
                    access_mode: g.access_mode,
                })),
            });
            load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function copyUnc(text) {
        if (!text) return;
        navigator.clipboard?.writeText(text).then(() => {
            setNotice(`Copiado: ${text}`);
        }).catch(() => {});
    }

    if (loading && !status) {
        return (
            <div className="sh-page">
                <div className="sh-loading">Cargando disco de red…</div>
            </div>
        );
    }

    const sambaLabel = !status?.samba?.installed
        ? "Sin Samba"
        : status.samba.smbd_active
            ? "En servicio"
            : "Detenido";

    return (
        <div className="sh-page">

            <header className="sh-hero">
                <div className="sh-hero-text">
                    <p className="sh-eyebrow">Almacenamiento en red</p>
                    <h1>Disco de red</h1>
                    <p className="sh-lede">
                        Comparte un disco USB o adicional (nunca el del sistema)
                        con carpetas y permisos por grupo. En Windows:
                        <code className="sh-inline-code"> \\{status?.lan_ip || "IP-NSP"}\Carpeta</code>
                    </p>
                </div>

                {isAdmin && (
                    <div className="sh-hero-actions">
                        <button
                            type="button"
                            className={`sh-toggle-btn ${sharingOn ? "on" : ""}`}
                            disabled={busy || !diskReady}
                            title={!diskReady ? "Primero asigna un disco" : ""}
                            onClick={() => saveConfig({ enabled: !sharingOn })}
                        >
                            <StatusDot ok={sharingOn} warn={!diskReady} />
                            {sharingOn ? "Compartido activo" : "Activar compartido"}
                        </button>
                    </div>
                )}
            </header>

            <nav className="sh-steps" aria-label="Pasos">
                <StepPill n={1} label="Elegir disco" active={currentStep === 1} done={diskReady} />
                <span className="sh-steps-line" />
                <StepPill n={2} label="Activar red" active={currentStep === 2} done={sharingOn} />
                <span className="sh-steps-line" />
                <StepPill n={3} label="Carpetas y grupos" active={currentStep === 3} done={hasFolders && sharingOn} />
            </nav>

            {error && (
                <div className="sh-alert danger" role="alert">
                    <strong>No se pudo completar</strong>
                    <span>{error}</span>
                    <button type="button" className="sh-alert-close" onClick={() => setError(null)}>Cerrar</button>
                </div>
            )}
            {notice && !error && (
                <div className="sh-alert ok" role="status">
                    <span>{notice}</span>
                    <button type="button" className="sh-alert-close" onClick={() => setNotice(null)}>Cerrar</button>
                </div>
            )}

            <section className="sh-panel sh-overview">
                <div className="sh-stat">
                    <span className="sh-stat-label">Servicio</span>
                    <span className="sh-stat-value">
                        <StatusDot ok={status?.samba?.smbd_active} warn={!status?.samba?.installed} />
                        {sambaLabel}
                    </span>
                </div>
                <div className="sh-stat">
                    <span className="sh-stat-label">Acceso Windows</span>
                    <span className="sh-stat-value mono">
                        {status?.unc_base || "—"}
                        {status?.unc_base && (
                            <button type="button" className="sh-linkish" onClick={() => copyUnc(status.unc_base)}>
                                Copiar
                            </button>
                        )}
                    </span>
                </div>
                <div className="sh-stat">
                    <span className="sh-stat-label">Disco</span>
                    <span className="sh-stat-value">
                        <StatusDot ok={diskReady} />
                        {diskReady ? "Asignado y protegido" : "Sin asignar"}
                    </span>
                </div>
                <div className="sh-stat">
                    <span className="sh-stat-label">Carpetas</span>
                    <span className="sh-stat-value">{folders.length}</span>
                </div>
            </section>

            {!status?.samba?.installed && (
                <div className="sh-alert warn">
                    <strong>Falta Samba en el servidor</strong>
                    <span>Instala el paquete <code>samba</code> para publicar las carpetas en la red.</span>
                </div>
            )}

            {/* STEP 1 — DISK */}
            <section className={`sh-panel ${currentStep === 1 ? "focus" : ""}`}>
                <div className="sh-panel-head">
                    <div>
                        <h2>1. Disco compartido</h2>
                        <p>
                            Selecciona una unidad USB o un disco adicional.
                            El del sistema ({status?.os_disk || "OS"}) no aparece a propósito.
                        </p>
                    </div>
                </div>

                {diskReady && (
                    <div className="sh-active-disk">
                        <div className="sh-active-disk-icon" aria-hidden>HDD</div>
                        <div className="sh-active-disk-body">
                            <strong>En uso como disco compartido</strong>
                            <p>
                                {status.device_path}
                                {" · "}
                                {status.mountpoint}
                                {status.mounted ? " · montado" : " · desmontado"}
                            </p>
                            <span className="sh-pill protect">Protegido — no desmontar a mano</span>
                        </div>
                        {isAdmin && (
                            <button
                                type="button"
                                className="sh-btn ghost danger"
                                disabled={busy}
                                onClick={handleReleaseDisk}
                            >
                                Liberar disco
                            </button>
                        )}
                    </div>
                )}

                <div className="sh-unit-grid">
                    {units.length === 0 ? (
                        <div className="sh-empty">
                            <strong>No hay unidades adicionales</strong>
                            <p>
                                Conecta un disco USB o un HDD/SSD a la placa.
                                Si está vacío, podrás formatearlo aquí.
                            </p>
                        </div>
                    ) : (
                        units.map((unit) => (
                            <article
                                key={unit.device}
                                className={
                                    "sh-unit"
                                    + (unit.assigned ? " is-assigned" : "")
                                    + (unit.locked ? " is-locked" : "")
                                }
                            >
                                <div className="sh-unit-top">
                                    <div className="sh-unit-icon" aria-hidden>
                                        {(unit.transport || "").toLowerCase() === "usb" ? "USB" : "DISK"}
                                    </div>
                                    <div className="sh-unit-title">
                                        <strong>{unit.model || unit.device}</strong>
                                        <span>{unit.title}</span>
                                    </div>
                                    {unit.assigned && <span className="sh-pill ok">Activo</span>}
                                </div>

                                <dl className="sh-unit-meta">
                                    <div>
                                        <dt>Formato</dt>
                                        <dd>{unit.fstype || "Sin formato"}</dd>
                                    </div>
                                    <div>
                                        <dt>Tamaño</dt>
                                        <dd>{unit.size || "—"}</dd>
                                    </div>
                                    <div>
                                        <dt>Estado</dt>
                                        <dd>{unit.mountpoint ? `Montado en ${unit.mountpoint}` : "Sin montar"}</dd>
                                    </div>
                                </dl>

                                {unit.hint && <p className="sh-unit-hint">{unit.hint}</p>}

                                {isAdmin && !unit.assigned && (
                                    <div className="sh-unit-actions">
                                        {unit.formattable && (
                                            <button
                                                type="button"
                                                className="sh-btn danger"
                                                disabled={busy || status?.disk_locked}
                                                onClick={() => handleFormatDisk(unit)}
                                            >
                                                {unit.whole_disk || !unit.fstype
                                                    ? "Formatear y usar"
                                                    : "Reformatear"}
                                            </button>
                                        )}
                                        {unit.selectable && (
                                            <button
                                                type="button"
                                                className="sh-btn primary"
                                                disabled={busy || status?.disk_locked}
                                                onClick={() => handleAssignDisk(unit.device)}
                                            >
                                                Usar este disco
                                            </button>
                                        )}
                                    </div>
                                )}
                            </article>
                        ))
                    )}
                </div>
            </section>

            {/* STEP 2 — SHARE TOGGLE + WORKGROUP */}
            <section className={`sh-panel ${!diskReady ? "dim" : ""} ${currentStep === 2 ? "focus" : ""}`}>
                <div className="sh-panel-head">
                    <div>
                        <h2>2. Publicar en la red</h2>
                        <p>
                            Cuando el disco esté listo, activa el compartido para que
                            los PCs Windows lo vean.
                        </p>
                    </div>
                </div>

                {!diskReady ? (
                    <div className="sh-empty soft">
                        Completa el paso 1 para continuar.
                    </div>
                ) : (
                    <div className="sh-publish-row">
                        <div>
                            <strong>{sharingOn ? "Visible en la red local" : "Aún no publicado"}</strong>
                            <p className="sh-muted">
                                Ruta base: <code>{status?.unc_base || "—"}</code>
                            </p>
                        </div>
                        {isAdmin && (
                            <div className="sh-inline-form">
                                <label>
                                    Grupo de trabajo
                                    <input
                                        type="text"
                                        value={workgroup}
                                        onChange={(e) => setWorkgroup(e.target.value)}
                                    />
                                </label>
                                <button
                                    type="button"
                                    className="sh-btn ghost"
                                    disabled={busy}
                                    onClick={() => saveConfig({ workgroup })}
                                >
                                    Guardar
                                </button>
                            </div>
                        )}
                    </div>
                )}
            </section>

            {/* STEP 3 — FOLDERS */}
            <section className={`sh-panel ${!diskReady ? "dim" : ""} ${currentStep === 3 ? "focus" : ""}`}>
                <div className="sh-panel-head">
                    <div>
                        <h2>3. Carpetas y permisos</h2>
                        <p>
                            Cada carpeta aparece como un recurso de red.
                            Los <strong>grupos</strong> definen quién lee o escribe
                            (igual que en bloqueos web).
                        </p>
                    </div>
                </div>

                {!diskReady ? (
                    <div className="sh-empty soft">Asigna un disco para crear carpetas.</div>
                ) : (
                    <>
                        {isAdmin && (
                            <div className="sh-create-folder">
                                <label>
                                    Nombre en la red
                                    <input
                                        type="text"
                                        value={folderForm.name}
                                        onChange={(e) =>
                                            setFolderForm((f) => ({ ...f, name: e.target.value }))
                                        }
                                        placeholder="Ej. Contabilidad"
                                    />
                                </label>
                                <label>
                                    Descripción
                                    <input
                                        type="text"
                                        value={folderForm.description}
                                        onChange={(e) =>
                                            setFolderForm((f) => ({ ...f, description: e.target.value }))
                                        }
                                        placeholder="Opcional"
                                    />
                                </label>
                                <button
                                    type="button"
                                    className="sh-btn primary"
                                    disabled={busy}
                                    onClick={handleCreateFolder}
                                >
                                    Crear carpeta
                                </button>
                            </div>
                        )}

                        {folders.length === 0 ? (
                            <div className="sh-empty soft">
                                Todavía no hay carpetas. Crea la primera para empezar a compartir.
                            </div>
                        ) : (
                            <div className="sh-folder-list">
                                {folders.map((folder) => {
                                    const open = expandedFolder === folder.id;
                                    const grantCount = (folder.groups || []).length;
                                    return (
                                        <article key={folder.id} className={`sh-folder ${open ? "open" : ""}`}>
                                            <button
                                                type="button"
                                                className="sh-folder-summary"
                                                onClick={() =>
                                                    setExpandedFolder(open ? null : folder.id)
                                                }
                                            >
                                                <div>
                                                    <strong>{folder.name}</strong>
                                                    <span className="sh-muted">
                                                        {folder.unc_path || folder.path}
                                                        {folder.description ? ` · ${folder.description}` : ""}
                                                    </span>
                                                </div>
                                                <div className="sh-folder-summary-right">
                                                    <span className="sh-pill quiet">
                                                        {grantCount} grupo{grantCount === 1 ? "" : "s"}
                                                    </span>
                                                    <span className="sh-chevron">{open ? "▾" : "▸"}</span>
                                                </div>
                                            </button>

                                            {open && (
                                                <div className="sh-folder-body">
                                                    <div className="sh-folder-toolbar">
                                                        {folder.unc_path && (
                                                            <button
                                                                type="button"
                                                                className="sh-btn ghost"
                                                                onClick={() => copyUnc(folder.unc_path)}
                                                            >
                                                                Copiar ruta Windows
                                                            </button>
                                                        )}
                                                        {isAdmin && (
                                                            <button
                                                                type="button"
                                                                className="sh-btn ghost danger"
                                                                disabled={busy}
                                                                onClick={() => handleDeleteFolder(folder)}
                                                            >
                                                                Eliminar carpeta
                                                            </button>
                                                        )}
                                                    </div>

                                                    <p className="sh-grant-intro">Quién puede acceder</p>
                                                    <div className="sh-grant-grid">
                                                        {groups.map((group) => {
                                                            const grant = (folder.groups || [])
                                                                .find((g) => g.group_id === group.id);
                                                            return (
                                                                <div
                                                                    key={group.id}
                                                                    className={`sh-grant ${grant ? "on" : ""}`}
                                                                >
                                                                    <span className="sh-grant-name">
                                                                        {group.name}
                                                                        {group.is_default ? " · Invitados" : ""}
                                                                    </span>
                                                                    {isAdmin ? (
                                                                        <div className="sh-seg">
                                                                            <button
                                                                                type="button"
                                                                                className={grant?.access_mode === "read" ? "on" : ""}
                                                                                disabled={busy}
                                                                                onClick={() =>
                                                                                    toggleGroupOnFolder(folder, group, "read")
                                                                                }
                                                                            >
                                                                                Lectura
                                                                            </button>
                                                                            <button
                                                                                type="button"
                                                                                className={grant?.access_mode === "write" ? "on" : ""}
                                                                                disabled={busy}
                                                                                onClick={() =>
                                                                                    toggleGroupOnFolder(folder, group, "write")
                                                                                }
                                                                            >
                                                                                Escritura
                                                                            </button>
                                                                        </div>
                                                                    ) : (
                                                                        <span className="sh-muted">
                                                                            {grant
                                                                                ? (grant.access_mode === "write" ? "Escritura" : "Lectura")
                                                                                : "Sin acceso"}
                                                                        </span>
                                                                    )}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                </div>
                                            )}
                                        </article>
                                    );
                                })}
                            </div>
                        )}
                    </>
                )}
            </section>

            {busy && <div className="sh-busy-bar" aria-live="polite">Aplicando cambios…</div>}
        </div>
    );
}


export default Shares;
