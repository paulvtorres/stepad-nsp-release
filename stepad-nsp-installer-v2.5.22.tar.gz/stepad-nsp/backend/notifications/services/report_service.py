import io
import socket
import html as html_lib

from datetime import datetime, timezone


def _to_local(value):
    """Los logs se guardan en UTC (naive); convierten a hora local del
    servidor para que el Excel no muestre el dia equivocado (UTC+5
    hacia adelante -> a las 21h local ya es "mañana" en UTC)."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone().replace(tzinfo=None)

from openpyxl import Workbook
from openpyxl.styles import (
    Alignment,
    Border,
    Font,
    PatternFill,
    Side,
)
from openpyxl.utils import get_column_letter

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository
)


def _format_duration(minutes: int) -> str:

    minutes = minutes or 0

    if minutes <= 0:

        return "—"

    hours = minutes // 60

    remainder = minutes % 60

    if hours:

        return f"{hours} h {remainder} min"

    return f"{remainder} min"


def _escape(value) -> str:

    return html_lib.escape(str(value or ""))


class ReportService:

    def __init__(self):

        self.query_repo = DnsQueryLogRepository()

        self.org_repo = OrganizationSettingsRepository()

    def _organization(
        self,
        db
    ) -> dict:

        settings = self.org_repo.get(db)

        return {
            "company_name": settings.company_name,
            "ruc": settings.ruc,
            "address": settings.address,
            "phone": settings.phone,
            "email": settings.email,
            "city": settings.city,
            "country": settings.country,
        }

    @staticmethod
    def _hostname() -> str:

        try:

            return socket.gethostname()

        except Exception:

            return "stepad-nsp"

    def summary_rows(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ):

        return self.query_repo.find_summary(
            db,
            start=start,
            end=end,
            device_id=device_id,
            domain_contains=domain
        )

    def blocked_recent(
        self,
        db,
        start
    ):

        return self.query_repo.find_blocked_recent(
            db,
            start=start
        )

    def _per_device(
        self,
        rows
    ):

        devices = {}

        for row in rows:

            entry = devices.setdefault(row.device_id, {
                "device_name": row.device_hostname or row.hostname or row.client_ip or row.ip_address or "Desconocido",
                "device_ip": row.client_ip or row.ip_address,
                "visits": 0,
                "active_minutes": 0,
                "blocked": 0,
                "domains": {},
            })

            entry["visits"] += row.visit_count or 0

            entry["active_minutes"] += row.active_minutes or 0

            entry["blocked"] += row.blocked_count or 0

            entry["domains"][row.domain] = (
                entry["domains"].get(row.domain, 0)
                + (row.active_minutes or 0)
            )

        return sorted(
            devices.values(),
            key=lambda d: d["active_minutes"],
            reverse=True
        )

    def build_html_report(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ) -> str:

        rows = self.summary_rows(db, start, end, device_id, domain)

        devices = self._per_device(rows)

        blocked = self.blocked_recent(db, start)

        period = (
            f"{start.strftime('%d/%m/%Y %H:%M')} a "
            f"{end.strftime('%d/%m/%Y %H:%M')}"
        )

        org = self._organization(db)

        company = org["company_name"] or "STEPAD NSP"

        parts = []

        parts.append(
            f"<h2>{_escape(company)} — Resumen de navegación</h2>"
            f"<p>Período: <b>{_escape(period)}</b></p>"
        )

        parts.append("<h3>Resumen por equipo</h3>")
        parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
        parts.append("<tr style='background:#f3f4f6'><th>Equipo</th><th>IP</th><th>Consultas</th><th>Tiempo activo</th></tr>")

        for device in devices:

            parts.append(
                "<tr>"
                f"<td>{_escape(device['device_name'])}</td>"
                f"<td>{_escape(device['device_ip'])}</td>"
                f"<td>{device['visits']}</td>"
                f"<td>{_format_duration(device['active_minutes'])}</td>"
                "</tr>"
            )

        parts.append("</table>")

        parts.append("<h3>Páginas navegadas</h3>")
        parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
        parts.append("<tr style='background:#f3f4f6'><th>Equipo</th><th>Página</th><th>Frecuencia</th><th>Desde</th><th>Hasta</th><th>Horas</th></tr>")

        for row in rows:

            parts.append(
                "<tr>"
                f"<td>{_escape(row.device_hostname or row.hostname or row.client_ip or row.ip_address or 'Desconocido')}</td>"
                f"<td>{_escape(row.domain)}</td>"
                f"<td>{row.visit_count}</td>"
                f"<td>{row.first_seen.strftime('%d/%m/%Y %H:%M') if row.first_seen else '—'}</td>"
                f"<td>{row.last_seen.strftime('%d/%m/%Y %H:%M') if row.last_seen else '—'}</td>"
                f"<td>{_format_duration(row.active_minutes)}</td>"
                "</tr>"
            )

        parts.append("</table>")

        total_blocked = sum((b.get("blocked_count") or 0) for b in blocked)

        parts.append("<h3>Notificaciones importantes</h3>")
        parts.append(f"<p>Consultas bloqueadas en el período: <b>{total_blocked}</b></p>")

        if blocked:

            parts.append("<table border='1' cellspacing='0' cellpadding='6' style='border-collapse:collapse;width:100%'>")
            parts.append("<tr style='background:#fef2f2'><th>Equipo</th><th>Dominio</th><th>Fecha</th></tr>")

            for item in blocked:

                parts.append(
                    "<tr>"
                    f"<td>{_escape(item['device_name'])}</td>"
                    f"<td>{_escape(item['domain'])}</td>"
                    f"<td>{item['queried_at'].strftime('%d/%m/%Y %H:%M')}</td>"
                    "</tr>"
                )

            parts.append("</table>")

        parts.append(
            "<p style='color:#6b7280;font-size:12px'>"
            "Tiempo activo estimado a partir de la actividad DNS "
            "(minutos con consultas). Reporte generado por STEPAD NSP.</p>"
        )

        return "".join(parts)

    @staticmethod
    def _excel_border() -> Border:

        thin = Side(style="thin", color="D1D5DB")

        return Border(left=thin, right=thin, top=thin, bottom=thin)

    def _write_excel_title_block(
        self,
        sheet,
        *,
        report_title: str,
        org: dict,
        start,
        end,
        device_label: str | None = None,
        domain_filter: str | None = None,
        col_span: int = 8,
    ) -> int:
        """Encabezado corporativo. Devuelve la fila siguiente libre."""

        title_font = Font(bold=True, size=16, color="1E3A8A")
        subtitle_font = Font(bold=True, size=12, color="374151")
        meta_font = Font(size=10, color="4B5563")
        left = Alignment(horizontal="left", vertical="center", wrap_text=True)

        company = org.get("company_name") or "Empresa"

        sheet.merge_cells(
            start_row=1, start_column=1, end_row=1, end_column=col_span
        )
        sheet["A1"] = company
        sheet["A1"].font = title_font
        sheet["A1"].alignment = left
        sheet.row_dimensions[1].height = 28

        sheet.merge_cells(
            start_row=2, start_column=1, end_row=2, end_column=col_span
        )
        sheet["A2"] = report_title
        sheet["A2"].font = subtitle_font
        sheet["A2"].alignment = left

        period_start = start.strftime("%d/%m/%Y %H:%M") if start else "—"
        period_end = end.strftime("%d/%m/%Y %H:%M") if end else "—"

        meta_lines = []

        if org.get("ruc"):
            meta_lines.append(f"RUC: {org['ruc']}")

        if org.get("address"):
            meta_lines.append(f"Dirección: {org['address']}")

        location = ", ".join(
            part
            for part in (org.get("city"), org.get("country"))
            if part
        )

        if location:
            meta_lines.append(f"Ubicación: {location}")

        contact = []
        if org.get("phone"):
            contact.append(f"Tel. {org['phone']}")
        if org.get("email"):
            contact.append(org["email"])
        if contact:
            meta_lines.append(" · ".join(contact))

        meta_lines.append(f"Período analizado: {period_start}  →  {period_end}")
        meta_lines.append(
            "Generado: "
            + datetime.now().strftime("%d/%m/%Y %H:%M")
            + f"  ·  Equipo NSP: {self._hostname()}"
        )

        filters = []
        if device_label:
            filters.append(f"Equipo: {device_label}")
        if domain_filter:
            filters.append(f"Dominio contiene: {domain_filter}")
        if filters:
            meta_lines.append("Filtros: " + "  ·  ".join(filters))

        row_idx = 3
        for line in meta_lines:
            sheet.merge_cells(
                start_row=row_idx,
                start_column=1,
                end_row=row_idx,
                end_column=col_span,
            )
            cell = sheet.cell(row=row_idx, column=1, value=line)
            cell.font = meta_font
            cell.alignment = left
            row_idx += 1

        return row_idx + 1

    @staticmethod
    def _write_excel_section_title(
        sheet,
        row: int,
        title: str,
        col_span: int = 8,
    ) -> int:

        sheet.merge_cells(
            start_row=row,
            start_column=1,
            end_row=row,
            end_column=col_span,
        )
        cell = sheet.cell(row=row, column=1, value=title)
        cell.font = Font(bold=True, size=11, color="1F2937")
        cell.fill = PatternFill("solid", fgColor="E5E7EB")
        cell.alignment = Alignment(horizontal="left", vertical="center")
        cell.border = ReportService._excel_border()
        sheet.row_dimensions[row].height = 22
        return row + 1

    @staticmethod
    def _write_excel_table_header(
        sheet,
        row: int,
        headers: list[str],
    ) -> int:

        header_font = Font(bold=True, color="FFFFFF", size=10)
        header_fill = PatternFill("solid", fgColor="1E3A8A")
        center = Alignment(horizontal="center", vertical="center", wrap_text=True)
        border = ReportService._excel_border()

        for col, heading in enumerate(headers, start=1):
            cell = sheet.cell(row=row, column=col, value=heading)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = center
            cell.border = border

        sheet.row_dimensions[row].height = 24
        return row + 1

    @staticmethod
    def _write_excel_data_row(
        sheet,
        row: int,
        values: list,
        *,
        banded: bool = False,
        left_cols: set[int] | None = None,
        date_cols: set[int] | None = None,
        int_cols: set[int] | None = None,
    ) -> int:

        left_cols = left_cols or set()
        date_cols = date_cols or set()
        int_cols = int_cols or set()
        border = ReportService._excel_border()
        band_fill = PatternFill("solid", fgColor="F9FAFB")
        center = Alignment(horizontal="center", vertical="center")
        left = Alignment(horizontal="left", vertical="center", wrap_text=True)

        for col, value in enumerate(values, start=1):
            cell = sheet.cell(row=row, column=col, value=value)
            cell.border = border
            if col in left_cols:
                cell.alignment = left
            else:
                cell.alignment = center
            if col in date_cols and value is not None:
                cell.number_format = "DD/MM/YYYY HH:MM"
            if col in int_cols and isinstance(value, (int, float)):
                cell.number_format = "#,##0"
            if banded:
                cell.fill = band_fill

        return row + 1

    @staticmethod
    def _set_column_widths(sheet, widths: list[int]) -> None:

        for index, width in enumerate(widths, start=1):
            sheet.column_dimensions[get_column_letter(index)].width = width

    @staticmethod
    def _write_excel_footer(
        sheet,
        row: int,
        text: str,
        col_span: int = 8,
    ) -> None:

        sheet.merge_cells(
            start_row=row,
            start_column=1,
            end_row=row,
            end_column=col_span,
        )
        cell = sheet.cell(row=row, column=1, value=text)
        cell.font = Font(size=9, italic=True, color="6B7280")
        cell.alignment = Alignment(
            horizontal="left", vertical="top", wrap_text=True
        )
        sheet.row_dimensions[row].height = 36

    def build_excel(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None,
        device_label: str | None = None,
    ) -> io.BytesIO:

        rows = self.summary_rows(db, start, end, device_id, domain)

        devices = self._per_device(rows)

        blocked_events = []

        if start is not None:

            blocked_events = self.query_repo.find_blocked_recent(
                db,
                start=start,
                limit=500,
            )

        org = self._organization(db)

        total_visits = sum(row.visit_count or 0 for row in rows)
        total_blocked = sum(row.blocked_count or 0 for row in rows)
        unique_domains = len({row.domain for row in rows if row.domain})
        unique_devices = len(devices)

        sorted_rows = sorted(
            rows,
            key=lambda row: (row.active_minutes or 0, row.visit_count or 0),
            reverse=True,
        )

        workbook = Workbook()

        # --- Hoja 1: Resumen ejecutivo ---
        summary = workbook.active
        summary.title = "Resumen ejecutivo"

        next_row = self._write_excel_title_block(
            summary,
            report_title="Reporte de Historial DNS — Resumen ejecutivo",
            org=org,
            start=start,
            end=end,
            device_label=device_label,
            domain_filter=domain,
            col_span=6,
        )

        next_row = self._write_excel_section_title(
            summary, next_row, "Indicadores del período", col_span=6
        )

        kpi_headers = ["Indicador", "Valor"]
        next_row = self._write_excel_table_header(summary, next_row, kpi_headers)

        kpis = [
            ("Equipos con actividad", unique_devices),
            ("Consultas DNS registradas", total_visits),
            ("Intentos de acceso bloqueados", total_blocked),
            ("Dominios distintos visitados", unique_domains),
            ("Registros detallados (equipo × dominio)", len(rows)),
        ]

        for index, (label, value) in enumerate(kpis):
            next_row = self._write_excel_data_row(
                summary,
                next_row,
                [label, value],
                banded=index % 2 == 1,
                left_cols={1},
                int_cols={2},
            )

        next_row += 1
        next_row = self._write_excel_section_title(
            summary, next_row, "Actividad por equipo", col_span=6
        )

        device_headers = [
            "Equipo",
            "Dirección IP",
            "Consultas DNS",
            "Tiempo activo estimado",
            "Dominios visitados",
            "Intentos bloqueados",
        ]
        next_row = self._write_excel_table_header(
            summary, next_row, device_headers
        )

        device_data_start = next_row
        for index, device in enumerate(devices):
            next_row = self._write_excel_data_row(
                summary,
                next_row,
                [
                    device["device_name"],
                    device["device_ip"] or "—",
                    device["visits"],
                    _format_duration(device["active_minutes"]),
                    len(device["domains"]),
                    device["blocked"],
                ],
                banded=index % 2 == 1,
                left_cols={1, 2},
                int_cols={3, 5, 6},
            )

        self._write_excel_footer(
            summary,
            next_row + 1,
            "Nota: el tiempo activo se estima a partir de minutos con "
            "consultas DNS (no es tiempo de pantalla). Los bloqueos "
            "reflejan intentos denegados por políticas del NSP.",
            col_span=6,
        )

        summary.auto_filter.ref = f"A{device_data_start - 1}:F{next_row - 1}"
        summary.freeze_panes = f"A{device_data_start}"
        self._set_column_widths(summary, [28, 16, 16, 22, 18, 18])
        summary.sheet_view.showGridLines = False

        # --- Hoja 2: Detalle de navegación ---
        detail = workbook.create_sheet("Detalle de navegación")

        detail_row = self._write_excel_title_block(
            detail,
            report_title="Detalle de navegación por equipo y dominio",
            org=org,
            start=start,
            end=end,
            device_label=device_label,
            domain_filter=domain,
            col_span=8,
        )

        detail_headers = [
            "Equipo",
            "Dirección IP",
            "Dominio visitado",
            "Consultas DNS",
            "Tiempo activo estimado",
            "Primera consulta",
            "Última consulta",
            "Intentos bloqueados",
        ]
        detail_header_row = detail_row
        detail_row = self._write_excel_table_header(
            detail, detail_row, detail_headers
        )

        detail_data_start = detail_row
        for index, row in enumerate(sorted_rows):
            row_ip = row.client_ip or row.ip_address
            detail_row = self._write_excel_data_row(
                detail,
                detail_row,
                [
                    (
                        row.device_hostname
                        or row.hostname
                        or row_ip
                        or "Desconocido"
                    ),
                    row_ip or "—",
                    row.domain,
                    row.visit_count or 0,
                    _format_duration(row.active_minutes),
                    _to_local(row.first_seen),
                    _to_local(row.last_seen),
                    row.blocked_count or 0,
                ],
                banded=index % 2 == 1,
                left_cols={1, 2, 3},
                date_cols={6, 7},
                int_cols={4, 8},
            )

        self._write_excel_footer(
            detail,
            detail_row + 1,
            "Cada fila agrupa la actividad de un equipo hacia un dominio "
            "en el período seleccionado. Las fechas están en hora local "
            "del servidor NSP.",
            col_span=8,
        )

        detail.auto_filter.ref = (
            f"A{detail_header_row}:H{detail_row - 1}"
        )
        detail.freeze_panes = f"A{detail_data_start}"
        self._set_column_widths(detail, [26, 15, 36, 14, 20, 18, 18, 16])
        detail.sheet_view.showGridLines = False

        # --- Hoja 3: Intentos bloqueados ---
        blocked_sheet = workbook.create_sheet("Intentos bloqueados")

        blocked_row = self._write_excel_title_block(
            blocked_sheet,
            report_title="Sitios y dominios con acceso denegado",
            org=org,
            start=start,
            end=end,
            device_label=device_label,
            domain_filter=domain,
            col_span=4,
        )

        blocked_summary = [
            row for row in sorted_rows if (row.blocked_count or 0) > 0
        ]

        blocked_row = self._write_excel_section_title(
            blocked_sheet,
            blocked_row,
            "Resumen por equipo y dominio (intentos bloqueados)",
            col_span=4,
        )

        blocked_headers = [
            "Equipo",
            "Dominio",
            "Intentos bloqueados",
            "Último intento",
        ]
        blocked_header_row = blocked_row
        blocked_row = self._write_excel_table_header(
            blocked_sheet, blocked_row, blocked_headers
        )

        blocked_data_start = blocked_row
        if blocked_summary:
            for index, row in enumerate(blocked_summary):
                blocked_row = self._write_excel_data_row(
                    blocked_sheet,
                    blocked_row,
                    [
                        (
                            row.device_hostname
                            or row.hostname
                            or row.client_ip
                            or row.ip_address
                            or "Desconocido"
                        ),
                        row.domain,
                        row.blocked_count or 0,
                        _to_local(row.last_seen),
                    ],
                    banded=index % 2 == 1,
                    left_cols={1, 2},
                    date_cols={4},
                    int_cols={3},
                )
        else:
            blocked_sheet.merge_cells(
                start_row=blocked_row,
                start_column=1,
                end_row=blocked_row,
                end_column=4,
            )
            cell = blocked_sheet.cell(
                row=blocked_row,
                column=1,
                value="No se registraron intentos bloqueados en este período.",
            )
            cell.alignment = Alignment(horizontal="left", vertical="center")
            blocked_row += 1

        if blocked_events:
            blocked_row += 1
            blocked_row = self._write_excel_section_title(
                blocked_sheet,
                blocked_row,
                "Últimos eventos bloqueados (detalle cronológico)",
                col_span=4,
            )
            event_headers = ["Equipo", "Dominio", "Fecha y hora"]
            blocked_row = self._write_excel_table_header(
                blocked_sheet, blocked_row, event_headers
            )
            for index, item in enumerate(blocked_events[:200]):
                blocked_row = self._write_excel_data_row(
                    blocked_sheet,
                    blocked_row,
                    [
                        item.get("device_name") or "Desconocido",
                        item.get("domain"),
                        _to_local(item.get("queried_at")),
                    ],
                    banded=index % 2 == 1,
                    left_cols={1, 2},
                    date_cols={3},
                )

        self._write_excel_footer(
            blocked_sheet,
            blocked_row + 1,
            "Los bloqueos corresponden a políticas configuradas "
            "(contenido no laboral, reglas de grupo, malware, etc.).",
            col_span=4,
        )

        blocked_sheet.auto_filter.ref = (
            f"A{blocked_header_row}:D{blocked_data_start - 1}"
            if blocked_summary
            else f"A{blocked_header_row}:D{blocked_header_row}"
        )
        blocked_sheet.freeze_panes = f"A{blocked_data_start}"
        self._set_column_widths(blocked_sheet, [28, 40, 18, 20])
        blocked_sheet.sheet_view.showGridLines = False

        buffer = io.BytesIO()
        workbook.save(buffer)
        buffer.seek(0)
        return buffer
