import base64
import json
import os
import subprocess
import threading
import time

from pathlib import Path
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.backups.models.cloud_storage_settings import (
    CloudStorageSettings
)
from backend.backups.repositories.backup_settings_repository import (
    BackupSettingsRepository
)
from backend.audit.models.audit_log import AuditLog
from backend.alerts.models.alert import Alert
from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger

STEPAD_DIR = Path("/etc/stepad")
RCLONE_DIR = STEPAD_DIR / "rclone"
RCLONE_CONF = RCLONE_DIR / "rclone.conf"
UPLOAD_DIR = STEPAD_DIR / "log_uploads"
REMOTE_NAME = "stepad-logs"

RCLONE_BIN = "/usr/bin/rclone"


class CloudStorageService:

    def __init__(self):

        self._scheduler_thread = None
        self._stop = False
        self._settings_repo = BackupSettingsRepository()


    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self._get_or_create(db)

        return {
            "enabled": settings.enabled,
            "provider": settings.provider,
            "endpoint": settings.endpoint or "",
            "bucket": settings.bucket or "",
            "remote_path": settings.remote_path or "",
            "host": settings.host or "",
            "user": settings.user or "",
            "has_access_key": bool(settings.access_key),
            "has_secret_key": bool(settings.secret_key),
            "has_password": bool(settings.password),
            "upload_hour": settings.upload_hour,
            "upload_minute": settings.upload_minute,
            "upload_days": settings.upload_days,
            "last_upload_at": (
                settings.last_upload_at.isoformat()
                if settings.last_upload_at else None
            ),
            "last_upload_result": settings.last_upload_result or "",
        }


    def save_settings(
        self,
        db: Session,
        request
    ) -> dict:

        settings = self._get_or_create(db)

        if request.enabled is not None:
            settings.enabled = request.enabled
        if request.provider is not None:
            settings.provider = request.provider
        if request.endpoint is not None:
            settings.endpoint = request.endpoint.strip() or None
        if request.bucket is not None:
            settings.bucket = request.bucket.strip() or None
        if request.remote_path is not None:
            settings.remote_path = request.remote_path.strip() or None
        if request.host is not None:
            settings.host = request.host.strip() or None
        if request.user is not None:
            settings.user = request.user.strip() or None

        # credentials: only overwrite when the operator sends a new value.
        if request.access_key:
            settings.access_key = self._encrypt_secret(
                request.access_key.strip()
            )
        if request.secret_key:
            settings.secret_key = self._encrypt_secret(
                request.secret_key.strip()
            )
        if request.password:
            settings.password = self._encrypt_secret(
                request.password.strip()
            )

        if request.upload_hour is not None:
            settings.upload_hour = request.upload_hour
        if request.upload_minute is not None:
            settings.upload_minute = request.upload_minute
        if request.upload_days is not None:
            settings.upload_days = max(1, request.upload_days)

        db.add(settings)
        db.commit()
        db.refresh(settings)

        if settings.enabled:
            self._write_rclone_config(settings)

        return self.get_settings(db)


    def test_connection(
        self,
        db: Session
    ) -> dict:

        settings = self._get_or_create(db)

        if not self._write_rclone_config(settings):
            return {
                "success": False,
                "message": "Configura primero las credenciales."
            }

        result = subprocess.run(
            [RCLONE_BIN, "lsd", f"{REMOTE_NAME}:"],
            capture_output=True,
            text=True,
            timeout=25
        )

        if result.returncode == 0:
            return {
                "success": True,
                "message": "Conexión correcta."
            }

        return {
            "success": False,
            "message": (
                result.stderr.strip()
                or result.stdout.strip()
                or "No se pudo conectar."
            )
        }


    # ------------------------------------------------------------------
    # Upload
    # ------------------------------------------------------------------

    def upload_logs(
        self,
        db: Session,
        force: bool = False
    ) -> dict:

        settings = self._get_or_create(db)

        if not settings.enabled:
            return {
                "success": False,
                "message": "Respaldo en la nube desactivado."
            }

        archive = self._build_log_archive(
            db,
            settings.upload_days or 1
        )

        if archive is None:
            return {
                "success": False,
                "message": "No hay logs que subir."
            }

        target = self._remote_target(settings)

        result = subprocess.run(
            [
                RCLONE_BIN, "copy", str(archive), target,
                "--config", str(RCLONE_CONF),
                "--log-level", "ERROR"
            ],
            capture_output=True,
            text=True,
            timeout=120
        )

        settings.last_upload_at = datetime.utcnow()

        if result.returncode == 0:
            settings.last_upload_result = (
                f"OK {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}"
            )
            db.add(settings)
            db.commit()
            self._cleanup_archive(archive)
            return {
                "success": True,
                "message": (
                    f"Logs subidos a la nube: {archive.name}"
                )
            }

        settings.last_upload_result = (
            f"ERROR {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}"
        )
        db.add(settings)
        db.commit()

        detail = (
            result.stderr.strip()
            or result.stdout.strip()
            or "error desconocido"
        )

        self._notify_failure(detail, db)

        return {
            "success": False,
            "message": f"No se pudieron subir los logs: {detail}"
        }


    def _build_log_archive(
        self,
        db: Session,
        days: int
    ) -> Path | None:

        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

        end = datetime.utcnow().replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        start = end - timedelta(days=days)

        staging = UPLOAD_DIR / "staging"
        staging.mkdir(parents=True, exist_ok=True)

        for path in staging.iterdir():
            if path.is_file():
                path.unlink()

        written = 0

        audit = self._export_rows(
            db, AuditLog, start, end, "created_at"
        )
        if audit:
            (staging / "audit_logs.json").write_text(
                json.dumps(audit, ensure_ascii=False, indent=1),
                encoding="utf-8"
            )
            written += 1

        alerts = self._export_rows(
            db, Alert, start, end, "created_at"
        )
        if alerts:
            (staging / "alerts.json").write_text(
                json.dumps(alerts, ensure_ascii=False, indent=1),
                encoding="utf-8"
            )
            written += 1

        eve = Path("/var/log/suricata/eve.json")
        if eve.exists():
            try:
                (staging / "eve.json").write_bytes(eve.read_bytes())
                written += 1
            except Exception:
                pass

        app_log = Path.cwd() / "logs" / "stepad.log"
        if app_log.exists():
            try:
                (staging / "stepad.log").write_bytes(app_log.read_bytes())
                written += 1
            except Exception:
                pass

        if written == 0:
            return None

        name = f"logs-{end.strftime('%Y-%m-%d')}.tar.gz"
        archive = UPLOAD_DIR / name

        result = subprocess.run(
            [
                "tar", "czf", str(archive),
                "-C", str(staging), "."
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return None

        return self._encrypt(archive)


    def _export_rows(
        self,
        db: Session,
        model,
        start: datetime,
        end: datetime,
        time_column: str
    ) -> list[dict]:

        rows = (
            db.query(model)
            .filter(
                getattr(model, time_column) >= start,
                getattr(model, time_column) < end
            )
            .all()
        )

        return [
            {
                col.name: (
                    getattr(row, col.name).isoformat()
                    if isinstance(getattr(row, col.name), datetime)
                    else getattr(row, col.name)
                )
                for col in model.__table__.columns
            }
            for row in rows
        ]


    def _remote_target(
        self,
        settings
    ) -> str:

        provider = settings.provider
        remote_path = (settings.remote_path or "").strip("/")

        if provider == "s3":
            bucket = (settings.bucket or "").strip("/")
            if remote_path:
                return f"{REMOTE_NAME}:{bucket}/{remote_path}"
            return f"{REMOTE_NAME}:{bucket}"

        if provider == "sftp":
            return f"{REMOTE_NAME}:{remote_path or '.'}"

        return f"{REMOTE_NAME}:{remote_path or ''}"


    def _write_rclone_config(
        self,
        settings
    ) -> bool:

        provider = settings.provider

        if provider == "s3":
            if not (settings.endpoint and settings.bucket):
                return False
            if not (settings.access_key and settings.secret_key):
                return False
            body = (
                f"[{REMOTE_NAME}]\n"
                "type = s3\n"
                "provider = Other\n"
                f"endpoint = {settings.endpoint}\n"
                f"access_key_id = {self._decrypt_secret(settings.access_key)}\n"
                f"secret_access_key = {self._decrypt_secret(settings.secret_key)}\n"
                "region = us-east-1\n"
                "acl = private\n"
            )
        elif provider == "sftp":
            if not (settings.host and settings.user):
                return False
            if not settings.password:
                return False
            body = (
                f"[{REMOTE_NAME}]\n"
                "type = sftp\n"
                f"host = {settings.host}\n"
                f"user = {settings.user}\n"
                f"pass = {self._decrypt_secret(settings.password)}\n"
                "shell_type = unix\n"
            )
        elif provider == "webdav":
            if not (settings.host and settings.user):
                return False
            if not settings.password:
                return False
            body = (
                f"[{REMOTE_NAME}]\n"
                "type = webdav\n"
                f"url = {settings.host}\n"
                f"user = {settings.user}\n"
                f"pass = {self._decrypt_secret(settings.password)}\n"
                "vendor = other\n"
            )
        else:
            return False

        RCLONE_DIR.mkdir(parents=True, exist_ok=True)

        RCLONE_CONF.write_text(body, encoding="utf-8")
        RCLONE_CONF.chmod(0o600)

        return True


    # ------------------------------------------------------------------
    # Encryption helpers (reuse STEPAD_BACKUP_KEY)
    # ------------------------------------------------------------------

    def _get_key(self) -> str:

        key = os.getenv("STEPAD_BACKUP_KEY", "")

        if key:
            return key

        env_file = STEPAD_DIR / "stepad.env"
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                if line.startswith("STEPAD_BACKUP_KEY="):
                    return line.split("=", 1)[1].strip()

        return ""


    def _encrypt_secret(self, value: str) -> str:

        key = self._get_key()

        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-pbkdf2",
                "-salt", "-A", "-base64",
                "-pass", f"pass:{key}"
            ],
            input=value.encode(),
            capture_output=True
        )

        if result.returncode != 0:
            raise RuntimeError("No se pudo cifrar la credencial")

        return result.stdout.decode().strip()


    def _decrypt_secret(self, value: str) -> str:

        key = self._get_key()

        result = subprocess.run(
            [
                "openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2",
                "-A", "-base64",
                "-pass", f"pass:{key}"
            ],
            input=value.encode(),
            capture_output=True
        )

        if result.returncode != 0:
            return ""

        return result.stdout.decode()


    def _encrypt(self, source: Path) -> Path:

        key = self._get_key()

        encrypted = source.with_suffix(source.suffix + ".enc")

        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-pbkdf2",
                "-salt", "-pass", f"pass:{key}",
                "-in", str(source),
                "-out", str(encrypted)
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return source

        source.unlink(missing_ok=True)

        return encrypted


    def _cleanup_archive(self, archive: Path):

        try:
            archive.unlink(missing_ok=True)
        except Exception:
            pass


    def _notify_failure(self, detail: str, db: Session):

        try:

            from backend.notifications.services.email_service import (
                EmailService
            )
            from backend.notifications.services.email_settings_service import (
                build_delivery_context,
            )

            delivery = build_delivery_context(db)

            if not delivery:
                return

            EmailService().send_html(
                delivery,
                "STEPAD NSP - fallo al subir logs a la nube",
                "<p>El respaldo de logs a la nube falló:</p>"
                f"<pre>{detail}</pre>"
            )

        except Exception as error:

            logger.error(
                f"No se pudo notificar el fallo del respaldo en la nube: "
                f"{error}"
            )


    # ------------------------------------------------------------------
    # Scheduler
    # ------------------------------------------------------------------

    def is_due(
        self,
        db: Session
    ) -> bool:

        settings = self._get_or_create(db)

        if not settings.enabled:
            return False

        now = datetime.utcnow()

        if settings.last_upload_at is not None:
            last = settings.last_upload_at.replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            today = now.replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            if last >= today:
                return False

        return (
            now.hour == settings.upload_hour
            and now.minute == settings.upload_minute
        )


    def _scheduler_loop(self):

        logger.info("Cloud storage scheduler started.")

        while not self._stop:

            db = SessionLocal()

            try:

                if self.is_due(db):

                    result = self.upload_logs(db)

                    logger.info(
                        f"Subida de logs en la nube: {result}"
                    )

            except Exception as error:

                logger.exception(
                    f"Cloud storage scheduler error: {error}"
                )

            finally:

                db.close()

            for _ in range(60):
                if self._stop:
                    break
                time.sleep(1)


    def start_scheduler(self):

        if self._scheduler_thread is not None:
            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="cloud-storage-scheduler"
        )

        self._scheduler_thread.start()


    def stop(self):

        self._stop = True


    def _get_or_create(
        self,
        db: Session
    ) -> CloudStorageSettings:

        settings = (
            db.query(CloudStorageSettings)
            .order_by(CloudStorageSettings.id)
            .first()
        )

        if settings is None:

            settings = CloudStorageSettings()
            db.add(settings)
            db.commit()
            db.refresh(settings)

        return settings
