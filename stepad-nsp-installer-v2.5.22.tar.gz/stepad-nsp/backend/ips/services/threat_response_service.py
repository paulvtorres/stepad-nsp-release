import ipaddress

import subprocess

from backend.core.database.session import SessionLocal

from backend.alerts.services.alert_service import AlertService

from backend.audit.services.audit_service import AuditService

from backend.ips.models.threat_response_setting import ThreatResponseSetting

from backend.ips.models.malware_event import MalwareEvent

from backend.ips.repositories.malware_event_repository import (
    MalwareEventRepository
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.firewall.adapters.linux.linux_firewall_provider import (
    LinuxFirewallProvider
)

from backend.notifications.services.email_service import EmailService

from backend.notifications.services.email_settings_service import (
    build_delivery_context,
)

from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository
)

from backend.shared.logging.logger import logger


# Categorias de Suricata que indican malware/controlador (C2).
# Categorias de Suricata que indican malware/controlador (C2) de ALTA
# confianza. Se excluyen etiquetas amplias como "potentially bad
# traffic": incluyen firmas INFO (ej. versiones viejas de Java) que no
# son malware y provocaban falsos positivos (aislar equipos y bloquear
# IPs de CDN legitimos).
MALWARE_CATEGORIES = (
    "trojan",
    "malware",
    "botnet",
    "ransomware",
    "spyware",
    "keylogger",
    "command and control",
    "cnc",
    "attempted information leak",
    "a network trojan was detected",
)

# Marcas de firma (reglas ET) de malware/C2 de alta confianza.
SIGNATURE_MARKERS = (
    "et trojan",
    "et malware",
    "et cnc",
    "et c2",
    "et botnet",
    "et ransomware",
    "et banking",
    "malware",
    "trojan",
    "botnet",
    "ransomware",
    "banking trojan",
    "packed executable",
    "cobalt strike",
    "command and control",
    "cmd and control",
    "qakbot",
    "emotet",
    "trickbot",
    "njrat",
)


class ThreatResponseService:


    def __init__(self):

        self.repo = MalwareEventRepository()

        self.device_repo = DeviceRepository()

        self.alert_service = AlertService()

        self.audit_service = AuditService()

        self.provider = LinuxFirewallProvider()

        self.email_service = EmailService()

        self.notification_repo = NotificationSettingsRepository()

        self._last_resync = 0.0

        self._last_state = {}


    # ------------------------------------------------------------------
    # Clasificacion
    # ------------------------------------------------------------------

    def is_malware_event(
        self,
        category: str,
        signature: str
    ):

        haystack = f"{category} {signature}".lower()

        return any(
            marker in haystack
            for marker in (
                MALWARE_CATEGORIES + SIGNATURE_MARKERS
            )
        )


    def _severity(
        self,
        suricata_severity
    ):

        mapping = {
            1: "critical",
            2: "warning",
        }

        return mapping.get(suricata_severity, "info")


    def _is_actionable(self, severity: str):

        return severity in ("critical", "warning")


    def _is_external(self, ip: str):

        try:

            return ipaddress.ip_address(ip).is_global

        except ValueError:

            return False


    # ------------------------------------------------------------------
    # Ajustes
    # ------------------------------------------------------------------

    def get_settings(
        self,
        db
    ):

        row = db.query(ThreatResponseSetting).first()

        if row is None:

            row = ThreatResponseSetting()

            db.add(row)

            db.commit()

            db.refresh(row)

        return {
            "quarantine_enabled": row.quarantine_enabled,
            "c2_block_enabled": row.c2_block_enabled,
            "ips_fail_closed": row.ips_fail_closed,
            "updated_at": row.updated_at,
        }


    def update_settings(
        self,
        db,
        quarantine_enabled,
        c2_block_enabled,
        ips_fail_closed=None,
    ):

        row = db.query(ThreatResponseSetting).first()

        if row is None:

            row = ThreatResponseSetting()

            db.add(row)

        if quarantine_enabled is not None:

            row.quarantine_enabled = quarantine_enabled

        if c2_block_enabled is not None:

            row.c2_block_enabled = c2_block_enabled

        if ips_fail_closed is not None:

            row.ips_fail_closed = ips_fail_closed

        db.commit()

        db.refresh(row)

        if ips_fail_closed is not None:

            try:

                from backend.firewall.services.nfqueue_service import (
                    NfqueueService,
                )

                NfqueueService().sync(fail_closed=row.ips_fail_closed)

            except Exception as error:

                logger.warning(
                    "No pude aplicar modo NFQUEUE: %s",
                    error,
                )

        return {
            "quarantine_enabled": row.quarantine_enabled,
            "c2_block_enabled": row.c2_block_enabled,
            "ips_fail_closed": row.ips_fail_closed,
            "updated_at": row.updated_at,
        }


    # ------------------------------------------------------------------
    # Respuesta ante el evento
    # ------------------------------------------------------------------

    def handle_event(
        self,
        db,
        event: dict
    ):

        alert = event.get("alert", {})

        signature = alert.get("signature", "")

        category = alert.get("category", "")

        severity = self._severity(alert.get("severity"))

        if not self.is_malware_event(category, signature):

            return None

        src_ip = event.get("src_ip", "")

        dst_ip = event.get("dest_ip", "")

        dst_port = event.get("dest_port", "")

        settings = self.get_settings(db)

        device = self.device_repo.find_by_ip(db, src_ip)

        quarantined = False

        c2_blocked = False

        if (
            settings["quarantine_enabled"]
            and device is not None
            and not device.blocked
            and self._is_actionable(severity)
        ):

            quarantined = self._quarantine_device(
                db,
                device,
                src_ip,
                signature
            )

        if (
            settings["c2_block_enabled"]
            and dst_ip
            and self._is_external(dst_ip)
            and self._is_actionable(severity)
        ):

            c2_blocked = self._block_c2_ip(
                db,
                dst_ip,
                signature
            )

        event_row = MalwareEvent(
            src_ip=src_ip,
            src_mac=device.mac_address if device else None,
            device_id=device.id if device else None,
            device_name=(
                device.display_name or device.hostname
                if device else None
            ),
            dst_ip=dst_ip,
            dst_port=str(dst_port) if dst_port else None,
            signature=signature[:255],
            category=category[:128] or None,
            severity=severity,
            quarantined=quarantined,
            c2_blocked=c2_blocked,
        )

        self.repo.save(db, event_row)

        return event_row


    def _quarantine_device(
        self,
        db,
        device,
        src_ip: str,
        signature: str
    ):

        try:

            result = self.provider.block_mac(device.mac_address)

            if not result.get("success"):

                logger.warning(
                    "Cuarentena fallo: %s (%s): %s",
                    device.mac_address,
                    src_ip,
                    result.get("stderr")
                )

                return False

            device.blocked = True

            self.device_repo.update(db, device)

            name = device.display_name or device.hostname or src_ip

            title = f"CUARENTENA: {name} aislado por malware"

            message = (
                f"El dispositivo {name} ({src_ip}) fue aislado "
                f"automaticamente tras detectarse: {signature}. "
                f"Verifique el equipo antes de desbloquearlo."
            )

            self.alert_service.create(
                db,
                alert_type="quarantine",
                severity="critical",
                title=title,
                message=message
            )

            try:

                self.audit_service.create_log(
                    db,
                    None,
                    "QUARANTINE",
                    "device",
                    message
                )

            except Exception as error:

                logger.warning("Auditoria de cuarentena fallo: %s", error)

            self._notify_critical(title, message)

            return True

        except Exception as error:

            db.rollback()

            logger.exception(
                "Error en cuarentena de %s: %s",
                src_ip,
                error
            )

            return False


    def _block_c2_ip(
        self,
        db,
        ip: str,
        signature: str
    ):

        try:

            self._ensure_chain()

            self._add_c2_rule(ip)

            title = f"BLOQUEO C2: {ip} en lista de bloqueo"

            message = (
                f"IP {ip} bloqueada automaticamente por actividad "
                f"de malware/controlador: {signature}."
            )

            self.alert_service.create(
                db,
                alert_type="c2_block",
                severity="warning",
                title=title,
                message=message
            )

            try:

                self.audit_service.create_log(
                    db,
                    None,
                    "C2_BLOCK",
                    "network",
                    message
                )

            except Exception as error:

                logger.warning("Auditoria de bloqueo C2 fallo: %s", error)

            self._notify_critical(title, message)

            return True

        except Exception as error:

            db.rollback()

            logger.exception(
                "Error al bloquear C2 %s: %s",
                ip,
                error
            )

            return False


    def _notify_critical(
        self,
        title: str,
        message: str
    ):

        try:

            db = SessionLocal()

            try:

                settings = self.notification_repo.get(db)

                if settings.enabled:

                    delivery = build_delivery_context(db)

                    if delivery:

                        self.email_service.send_html(
                            delivery,
                            title,
                            f"<h3>{title}</h3><pre>{message}</pre>"
                        )

            finally:

                db.close()

        except Exception as error:

            logger.error(
                "Fallo la notificacion critica: %s",
                error
            )


    # ------------------------------------------------------------------
    # Cortafuegos: cadena de bloqueo C2
    # ------------------------------------------------------------------

    def _run(self, args):

        result = subprocess.run(
            ["/usr/sbin/nft", *args],
            capture_output=True,
            text=True
        )

        return {
            "success": result.returncode == 0,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip()
        }


    def _ensure_chain(self):

        self._run(["add", "table", "inet", "stepad"])

        self._run([
            "add", "set", "inet", "stepad", "stepad_wan_ifaces",
            "{", "type", "ifname", ";", "}"
        ])

        self._run([
            "add", "chain", "inet", "stepad", "c2-block"
        ])

        result = self._run([
            "list", "chain", "inet", "stepad", "forward"
        ])

        if "jump c2-block" not in result["stdout"]:

            self._run([
                "add", "rule", "inet", "stepad", "forward",
                "jump", "c2-block"
            ])


    def _flush(self):

        self._run([
            "flush", "chain", "inet", "stepad", "c2-block"
        ])


    def _populate_wan_set(self, wan_interfaces: list[str]):

        self._run([
            "flush", "set", "inet", "stepad", "stepad_wan_ifaces"
        ])

        if not wan_interfaces:

            return

        elements = ", ".join(wan_interfaces)

        self._run([
            "add", "element", "inet", "stepad", "stepad_wan_ifaces",
            "{", elements, "}"
        ])


    def _add_c2_rule(self, ip):

        result = self._run([
            "list", "chain", "inet", "stepad", "c2-block"
        ])

        if f"{ip} drop" in result["stdout"]:

            return

        if ":" in ip:

            self._run([
                "add", "rule", "inet", "stepad", "c2-block",
                "iifname", "!=", "@stepad_wan_ifaces",
                "ip6", "daddr", ip, "drop"
            ])

        else:

            self._run([
                "add", "rule", "inet", "stepad", "c2-block",
                "iifname", "!=", "@stepad_wan_ifaces",
                "ip", "daddr", ip, "drop"
            ])


    def sync_c2_rules(
        self,
        db=None
    ):

        try:

            own_db = db is None

            if own_db:

                db = SessionLocal()

            try:

                self._ensure_chain()

                from backend.network.interfaces.services.interface_service import (
                    InterfaceService,
                )

                wan_names = [
                    interface.name
                    for interface in InterfaceService().get_wan_interfaces()
                ]

                self._populate_wan_set(wan_names)

                self._flush()

                ips = self.repo.find_blocked_c2_ips(db)

                for ip in ips:

                    self._add_c2_rule(ip)

                return {"synced": len(ips)}

            finally:

                if own_db:

                    db.close()

        except Exception as error:

            logger.exception("Sync de bloqueo C2 fallo: %s", error)

            return {"synced": 0, "error": str(error)}


    def resync_if_stale(self, stale_after=300.0):

        import time

        now = time.time()

        if now - self._last_resync < stale_after:

            return

        self._last_resync = now

        self.sync_c2_rules()


    # ------------------------------------------------------------------
    # Consulta de eventos
    # ------------------------------------------------------------------

    def list_malware_events(
        self,
        db,
        limit: int = 10
    ):

        rows = self.repo.find_recent(db, limit)

        from datetime import timezone

        return [
            {
                "id": row.id,
                "src_ip": row.src_ip,
                "src_mac": row.src_mac,
                "device_id": row.device_id,
                "device_name": row.device_name,
                "dst_ip": row.dst_ip,
                "dst_port": row.dst_port,
                "signature": row.signature,
                "category": row.category,
                "severity": row.severity,
                "quarantined": row.quarantined,
                "c2_blocked": row.c2_blocked,
                "created_at": row.created_at.replace(
                    tzinfo=timezone.utc
                ).isoformat(),
            }
            for row in rows
        ]


threat_response_service = ThreatResponseService()
