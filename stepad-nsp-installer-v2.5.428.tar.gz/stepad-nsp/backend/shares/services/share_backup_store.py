"""Almacen de la configuracion de respaldos por boveda (`.respaldo.json`).

Solo E/S de archivo: normaliza el esquema y escribe de forma atomica con
permisos 0600. La logica de cache/mirror y del scheduler vive en el
servicio. Extraido del monolito sin cambiar comportamiento.
"""

import json
import os

from pathlib import Path

from backend.shared.logging.logger import logger


CONFIG_FILENAME = ".respaldo.json"

CONFIG_SCHEMA = 1


def config_path(vault: Path) -> Path:

    return vault / CONFIG_FILENAME


def empty_config() -> dict:

    return {"schema": CONFIG_SCHEMA, "next_job_id": 1, "jobs": []}


def read_config(vault: Path) -> dict | None:

    """Config real de la boveda, o None si no es legible/valida."""

    try:

        payload = json.loads(config_path(vault).read_text("utf-8"))

    except FileNotFoundError:

        return None

    except Exception as error:

        logger.warning("Config de respaldos ilegible en %s: %s", vault, error)

        return None

    if isinstance(payload, dict) and isinstance(payload.get("jobs"), list):

        return payload

    return None


def write_config(vault: Path, config: dict) -> dict:

    vault.mkdir(parents=True, exist_ok=True)

    config.setdefault("schema", CONFIG_SCHEMA)

    config.setdefault("jobs", [])

    config.setdefault(
        "next_job_id",
        max(
            (int(job.get("id") or 0) for job in config.get("jobs", [])),
            default=0,
        ) + 1,
    )

    path = config_path(vault)

    temp = path.with_suffix(".tmp")

    temp.write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    os.replace(temp, path)

    try:

        os.chmod(path, 0o600)

    except Exception as error:

        logger.debug("share_backup_store.write_config: %s", error)

    return config
