import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import {
    getAlerts,
    getDevices,
    getProtectionSummary,
    getSystemMonitoring,
    getSystemVersion,
    getWanMonitorStatus,
} from "../../services/api";

import "./how-it-works.css";


function formatNumber(value, fallback = "—") {

    if (value === null || value === undefined) return fallback;

    return new Intl.NumberFormat("es-EC").format(value);

}


function formatUptime(seconds) {

    if (!seconds) return "—";

    const days = Math.floor(seconds / 86400);

    const hours = Math.floor((seconds % 86400) / 3600);

    if (days > 0) return `${days} días y ${hours} horas`;

    return `${hours} horas`;

}


function StatusDot({ ok, muted = false }) {

    return (
        <i className={`hiw-dot ${ok ? "ok" : muted ? "muted" : "warn"}`} />
    );

}


export default function HowItWorks() {

    const [wan, setWan] = useState(null);

    const [devices, setDevices] = useState([]);

    const [protection, setProtection] = useState(null);

    const [alerts, setAlerts] = useState(null);

    const [hardware, setHardware] = useState(null);

    const [version, setVersion] = useState(null);

    const [loading, setLoading] = useState(true);

    const [lastUpdated, setLastUpdated] = useState(null);

    const [error, setError] = useState("");


    async function load() {

        const results = await Promise.allSettled([
            getWanMonitorStatus(),
            getDevices(),
            getProtectionSummary(1),
            getAlerts(5),
            getSystemMonitoring(),
            getSystemVersion(),
        ]);

        const [
            wanResult,
            devicesResult,
            protectionResult,
            alertsResult,
            hardwareResult,
            versionResult,
        ] = results;

        if (wanResult.status === "fulfilled") setWan(wanResult.value);
        if (devicesResult.status === "fulfilled") setDevices(devicesResult.value || []);
        if (protectionResult.status === "fulfilled") setProtection(protectionResult.value);
        if (alertsResult.status === "fulfilled") setAlerts(alertsResult.value);
        if (hardwareResult.status === "fulfilled") setHardware(hardwareResult.value);
        if (versionResult.status === "fulfilled") setVersion(versionResult.value);

        if (results.every((result) => result.status === "rejected")) {
            setError("No se pudo consultar el estado del NSP en este momento.");
        } else {
            setError("");
        }

        setLastUpdated(new Date());
        setLoading(false);

    }


    useEffect(() => {

        load();

        const timer = setInterval(load, 20000);

        return () => clearInterval(timer);

    }, []);


    const wanEntry = Object.values(wan?.interfaces || {})[0] || {};

    const internetOk = Boolean(wanEntry.link_up && wanEntry.ping_ok);

    const onlineDevices = devices.filter(
        (device) => (device.presence_status || device.status) === "ONLINE",
    ).length;

    const totalDevices = devices.length;

    const dnsTotal = protection?.dns?.total ?? 0;

    const dnsBlocked = protection?.dns?.blocked ?? 0;

    const unreadAlerts = alerts?.unread ?? 0;


    return (

        <div className="hiw-page">

            <header className="hiw-hero">

                <div className="hiw-hero-glow" aria-hidden="true" />

                <div>

                    <span className="hiw-eyebrow">VISTA PARA AUDITORÍA</span>

                    <h1>Cómo funciona esta red</h1>

                </div>

                <div className="hiw-hero-status">
                    <span className="hiw-live">
                        <span className="hiw-live-dot" />
                        EN VIVO
                    </span>
                    <small>
                        {lastUpdated
                            ? `Actualizado ${lastUpdated.toLocaleTimeString("es-EC")}`
                            : "Consultando el NSP…"}
                    </small>
                </div>

            </header>

            {error && <div className="hiw-error">{error}</div>}

            <section className="hiw-simple-status" aria-label="Estado general">

                <div>
                    <StatusDot ok={internetOk} />
                    <span>Internet</span>
                    <strong>{internetOk ? "Funcionando" : "Revisar"}</strong>
                </div>

                <div>
                    <StatusDot ok={onlineDevices > 0} />
                    <span>Equipos conectados</span>
                    <strong>{loading ? "Consultando…" : `${onlineDevices} de ${totalDevices}`}</strong>
                </div>

                <div>
                    <StatusDot ok />
                    <span>Protección</span>
                    <strong>Activa</strong>
                </div>

                <div>
                    <StatusDot ok={dnsBlocked >= 0} />
                    <span>Filtrado web</span>
                    <strong>{formatNumber(dnsBlocked)} bloqueos en 1 h</strong>
                </div>

                <div>
                    <StatusDot ok={unreadAlerts === 0} />
                    <span>Avisos pendientes</span>
                    <strong>{unreadAlerts === 0 ? "Ninguno" : `${unreadAlerts} para revisar`}</strong>
                </div>

                <div>
                    <StatusDot ok={Boolean(hardware?.uptime_seconds)} />
                    <span>Servidor NSP</span>
                    <strong>{version?.version || "En línea"} · {formatUptime(hardware?.uptime_seconds)}</strong>
                </div>

            </section>

            <section className="hiw-panel hiw-map-panel">

                <div className="hiw-panel-head">

                    <div>
                        <h2>Recorrido de la red</h2>
                    </div>

                    <span className="hiw-panel-label">Vista general</span>

                </div>

                <div className="hiw-map" role="img" aria-label="Internet entra al NSP, que protege y conecta a los equipos internos">

                    <div className={`hiw-map-node internet ${internetOk ? "ok" : "warn"}`}>
                        <span className="hiw-map-icon globe" aria-hidden="true" />
                        <strong>Internet</strong>
                        <small>{internetOk ? "Conexión disponible" : "Sin respuesta"}</small>
                    </div>

                    <div className="hiw-map-path" aria-hidden="true">
                        <span className="hiw-packet p1" />
                        <span className="hiw-packet p2" />
                        <span className="hiw-packet p3" />
                    </div>

                    <div className="hiw-map-node nsp">
                        <span className="hiw-map-icon shield" aria-hidden="true" />
                        <strong>NSP</strong>
                        <small>Activo</small>
                        <span className="hiw-map-badge">Protección activa</span>
                    </div>

                    <div className="hiw-map-path reverse" aria-hidden="true">
                        <span className="hiw-packet p1" />
                        <span className="hiw-packet p2" />
                        <span className="hiw-packet p3" />
                    </div>

                    <div className="hiw-map-node lan">
                        <span className="hiw-map-icon monitor" aria-hidden="true" />
                        <strong>Red interna</strong>
                        <small>{onlineDevices} equipos conectados</small>
                        <div className="hiw-mini-devices" aria-hidden="true">
                            <i />
                            <i />
                            <i />
                            <i />
                        </div>
                    </div>

                </div>

                <div className="hiw-map-legend">

                    <span><i className="ok" /> Permitido</span>
                    <span><i className="warn" /> Bloqueado o por revisar</span>
                    <span><i className="info" /> Registrado</span>

                </div>

            </section>

            <section className="hiw-panel">

                <div className="hiw-panel-head">

                    <div>
                        <h2>Conexión de un equipo</h2>
                    </div>

                </div>

                <div className="hiw-steps">

                    <div className="hiw-step">
                        <span className="hiw-step-number">1</span>
                        <div>
                            <strong>Se conecta</strong>
                        </div>
                    </div>

                    <div className="hiw-step">
                        <span className="hiw-step-number">2</span>
                        <div>
                            <strong>Recibe dirección</strong>
                        </div>
                    </div>

                    <div className="hiw-step">
                        <span className="hiw-step-number">3</span>
                        <div>
                            <strong>Es identificado</strong>
                        </div>
                    </div>

                    <div className="hiw-step">
                        <span className="hiw-step-number">4</span>
                        <div>
                            <strong>Navega con reglas</strong>
                        </div>
                    </div>

                </div>

            </section>

            <section className="hiw-panel">

                <div className="hiw-panel-head">

                    <div>
                        <h2>Protección en tres capas</h2>
                    </div>

                </div>

                <div className="hiw-layers">

                    <div className="hiw-layer content">
                        <span className="hiw-layer-visual web" aria-hidden="true" />
                        <span className="hiw-layer-number">1</span>
                        <h3>Filtra sitios web</h3>
                        <strong>{formatNumber(dnsBlocked)} bloqueos en la última hora</strong>
                    </div>

                    <div className="hiw-layer ips">
                        <span className="hiw-layer-visual radar" aria-hidden="true" />
                        <span className="hiw-layer-number">2</span>
                        <h3>Detecta ataques</h3>
                        <strong>{unreadAlerts === 0 ? "Sin avisos pendientes" : `${unreadAlerts} avisos pendientes`}</strong>
                    </div>

                    <div className="hiw-layer firewall">
                        <span className="hiw-layer-visual wall" aria-hidden="true" />
                        <span className="hiw-layer-number">3</span>
                        <h3>Cierra la entrada</h3>
                        <strong>Entrada externa cerrada</strong>
                    </div>

                </div>

            </section>

            <section className="hiw-panel">

                <div className="hiw-panel-head">

                    <div>
                        <h2>Accesos de revisión</h2>
                    </div>

                </div>

                <div className="hiw-links">

                    <Link to="/" className="hiw-link-card">
                        <strong>Estado general</strong>
                    </Link>

                    <Link to="/performance" className="hiw-link-card">
                        <strong>Rendimiento de red</strong>
                    </Link>

                    <Link to="/protection" className="hiw-link-card">
                        <strong>Protección y bloqueos</strong>
                    </Link>

                    <Link to="/alerts" className="hiw-link-card">
                        <strong>Alertas</strong>
                    </Link>

                </div>

            </section>

            <footer className="hiw-footer">

                <span>Datos en vivo del NSP · {version?.version || "—"}</span>

                <span>
                    {lastUpdated ? lastUpdated.toLocaleString("es-EC") : "—"}
                </span>

            </footer>

        </div>

    );

}
