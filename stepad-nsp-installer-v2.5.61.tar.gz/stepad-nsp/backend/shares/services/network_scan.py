"""
Escaneo de shares SMB en la LAN local.
Detecta equipos con shares accesibles y lista sus carpetas.
"""
import subprocess
import socket
import threading
from pathlib import Path
from backend.shared.logging.logger import logger


class NetworkShareScanner:

    def __init__(self):
        self._timeout = 2  # segundos por host

    def scan_lan(self, subnet: str = "192.168.100.0/24") -> list[dict]:
        """Escanea la subred buscando hosts con SMB (puerto 445)."""
        hosts = self._discover_hosts(subnet)
        results = []
        for host in hosts:
            shares = self._list_shares(host)
            if shares:
                results.append({
                    "ip": host,
                    "hostname": self._resolve_hostname(host),
                    "shares": shares,
                })
        return results

    def _discover_hosts(self, subnet: str) -> list[str]:
        """Descubre hosts activos con ping rápido."""
        # Extraer base del subnet (ej: 192.168.100)
        parts = subnet.split(".")
        base = ".".join(parts[:3])
        hosts = []
        threads = []

        def ping_host(ip):
            try:
                result = subprocess.run(
                    ["ping", "-c", "1", "-W", "1", ip],
                    capture_output=True, timeout=2
                )
                if result.returncode == 0:
                    hosts.append(ip)
            except Exception:
                pass

        for i in range(1, 255):
            ip = f"{base}.{i}"
            t = threading.Thread(target=ping_host, args=(ip,))
            threads.append(t)
            t.start()
            if len(threads) >= 50:
                for t in threads:
                    t.join(timeout=2)
                threads = []

        for t in threads:
            t.join(timeout=2)

        return sorted(hosts)

    def _list_shares(self, host: str) -> list[dict]:
        """Lista shares SMB de un host. Si requiere credenciales, indica que necesita autenticación."""
        try:
            result = subprocess.run(
                ["smbclient", "-L", host, "-N", "--timeout=3"],
                capture_output=True, text=True, timeout=5
            )
            shares = []
            needs_auth = False
            for line in result.stdout.splitlines():
                line = line.strip()
                if not line or line.startswith("Sharename") or line.startswith("---") or line.startswith("SMB"):
                    continue
                if "ACCESS_DENIED" in line or "session setup failed" in line:
                    needs_auth = True
                    continue
                parts = line.split()
                if len(parts) >= 2 and parts[1] in ("Disk", "Print"):
                    shares.append({
                        "name": parts[0],
                        "type": parts[1],
                        "comment": " ".join(parts[2:]) if len(parts) > 2 else "",
                    })
            if needs_auth and not shares:
                return [{"name": "(requiere credenciales)", "type": "Auth", "comment": "Ingrese usuario y contraseña para ver los shares"}]
            return shares
        except Exception as error:
            logger.warning("No se pudo listar shares en %s: %s", host, error)
            return []

    def test_connection(self, host: str, share: str, user: str = "", password: str = "") -> dict:
        """Prueba conexión a un share SMB.

        Cuando el frontend todavía no seleccionó un share (asistente de
        conexión), ``share`` llega vacío y aquí se validan las credenciales
        contra el host listando sus shares. Si ``share`` incluye subcarpeta
        (ej: ``TQB/TQB - Documentos``), se navega con ``cd`` dentro de
        ``smbclient`` porque la URL de conexión no acepta rutas anidadas.
        """
        try:
            share_name, subfolder = self._split_share_path(share)
            if share_name:
                cmd = ["smbclient", f"//{host}/{share_name}", "-c", "ls"]
                if subfolder:
                    escaped = subfolder.replace("\\", "\\\\").replace('"', '\\"')
                    cmd[-1] = f'cd "{escaped}"; ls'
            else:
                cmd = ["smbclient", "-L", host]
            if user:
                cmd.extend(["-U", f"{user}%{password}"])
            else:
                cmd.append("-N")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                return {"success": True, "message": "Conexión exitosa"}
            else:
                stderr = (result.stderr or "").lower()
                stdout = (result.stdout or "").lower()
                if "logon_failure" in stderr or "logon_failure" in stdout or "access_denied" in stderr or "nt_status_account" in stderr:
                    return {"success": False, "message": "Credenciales incorrectas. Verifique usuario y contraseña."}
                return {"success": False, "message": result.stderr.strip()[:200]}
        except Exception as error:
            return {"success": False, "message": str(error)[:200]}

    @staticmethod
    def _split_share_path(share: str) -> tuple[str, str]:
        """Divide ``share/ruta`` en (nombre_del_share, subcarpeta)."""
        parts = share.strip("/").split("/", 1)
        share_name = parts[0]
        subfolder = parts[1] if len(parts) > 1 else ""
        return share_name, subfolder

    def list_shares_with_auth(self, host: str, user: str, password: str) -> list[dict]:
        """Lista shares SMB de un host usando credenciales."""
        try:
            cmd = ["smbclient", "-L", host, "-U", f"{user}%{password}", "--timeout=3"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            # Detectar errores de autenticación
            stderr = (result.stderr or "").lower()
            stdout = (result.stdout or "").lower()
            if "logon_failure" in stderr or "logon_failure" in stdout or "access_denied" in stderr:
                return [{"name": "__AUTH_ERROR__", "type": "Error", "comment": "Credenciales incorrectas. Verifique usuario y contraseña."}]
            shares = []
            for line in result.stdout.splitlines():
                line = line.strip()
                if not line or line.startswith("Sharename") or line.startswith("---") or line.startswith("SMB"):
                    continue
                parts = line.split()
                if len(parts) >= 2 and parts[1] in ("Disk", "Print"):
                    shares.append({
                        "name": parts[0],
                        "type": parts[1],
                        "comment": " ".join(parts[2:]) if len(parts) > 2 else "",
                    })
            return shares
        except Exception as error:
            logger.warning("No se pudo listar shares en %s: %s", host, error)
            return []

    def _resolve_hostname(self, ip: str) -> str:
        """Resuelve nombre del host."""
        try:
            return socket.gethostbyaddr(ip)[0]
        except Exception:
            return ip

    def browse_share(self, host: str, share: str, path: str, user: str, password: str) -> list[dict]:
        """Lista el contenido de una carpeta dentro de un share SMB."""
        try:
            remote_path = f"{share}/{path}".rstrip("/") if path else share
            cmd = ["smbclient", f"//{host}/{share}", "-U", f"{user}%{password}", "--timeout=3"]
            if path:
                clean_path = path.strip("/")
                escaped = clean_path.replace("\\", "\\\\").replace('"', '\\"')
                cmd.extend(["-c", f'cd "{escaped}"; ls'])
            else:
                cmd.extend(["-c", "ls"])
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            items = []
            for line in result.stdout.splitlines():
                line = line.strip()
                if not line or line.startswith("blocks") or line.startswith(" NT_STATUS"):
                    continue
                # Parsear: "  carpeta/                          D        0  Mon Jan  1 00:00:00 2024"
                parts = line.split()
                if len(parts) < 2:
                    continue
                name = parts[0].rstrip("/")
                item_type = "dir" if "D" in parts[1] or line.count("  D  ") > 0 else "file"
                size = 0
                try:
                    size = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
                except:
                    pass
                items.append({
                    "name": name,
                    "type": item_type,
                    "size": size,
                })
            return items
        except Exception as error:
            logger.warning("No se pudo navegar en %s/%s: %s", host, share, error)
            return []
