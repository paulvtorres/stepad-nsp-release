"""Verificacion de puertos abiertos en el NSP.

Compara los puertos escuchando contra la lista de puertos permitidos.
Si encuentra puertos no esperados, genera alerta.

Nota: el DNS local (pdns) y WireGuard escuchan en UDP y/o en una IP
concreta (no en 0.0.0.0). Antes solo se miraba TCP en 0.0.0.0, asi que
ambos se reportaban como "caidos" en cada arranque (falsos positivos).
"""

import subprocess

from backend.shared.logging.logger import logger


# Puertos que el NSP DEBE escuchar en TCP y en todas las interfaces
EXPECTED_TCP = {
    22: "SSH (admin)",
    8443: "HTTPS (panel web)",
}

# Puertos que el NSP DEBE tener escuchando (UDP o TCP, en cualquier IP)
EXPECTED_ANY = {
    53: "DNS (local)",
    51820: "WireGuard VPN",
}

# Puertos que NUNCA deben estar abiertos en 0.0.0.0 (TCP)
FORBIDDEN_TCP = {
    80: "HTTP (debe usar HTTPS 8443)",
    3306: "MySQL (base de datos no expuesta)",
    5432: "PostgreSQL (debe ser solo localhost)",
    445: "Samba/SMB (no exponer)",
    139: "NetBIOS (no exponer)",
    3389: "RDP (no exponer)",
    11211: "Memcached (no exponer)",
    6379: "Redis (no exponer)",
    27017: "MongoDB (no exponer)",
}


def _listening_ports(flag):
    """Devuelve (puertos en todas las interfaces, puertos en cualquier IP).

    `flag` es la familia de sockets: "-tln" (TCP) o "-uln" (UDP).
    """

    try:

        result = subprocess.run(
            ["ss", flag],
            capture_output=True, text=True, timeout=5,
        )

    except Exception as exc:

        logger.warning("ports_check: no pude ejecutar ss %s: %s", flag, exc)

        return {}, {}

    if result.returncode != 0:

        logger.warning(
            "ports_check: ss %s devolvio %s", flag, result.returncode,
        )

        return {}, {}

    wildcard = {}
    anywhere = {}

    for line in result.stdout.splitlines()[1:]:

        parts = line.split()

        if len(parts) < 4:

            continue

        local = parts[3]

        if ":" not in local:

            continue

        try:

            port = int(local.rsplit(":", 1)[-1])

        except ValueError:

            continue

        anywhere.setdefault(port, line.strip())

        if local.startswith("0.0.0.0:") or local.startswith("[::]:"):

            wildcard[port] = line.strip()

    return wildcard, anywhere


def check_ports():
    """Verifica puertos abiertos y retorna problemas encontrados."""

    issues = []

    tcp_wildcard, tcp_any = _listening_ports("-tln")
    udp_wildcard, udp_any = _listening_ports("-uln")

    for port, desc in FORBIDDEN_TCP.items():
        if port in tcp_wildcard:
            issues.append({
                "check": "ports",
                "severity": "critical",
                "title": "Puerto prohibido abierto: %d (%s)" % (port, desc),
                "message": (
                    "El puerto %d (%s) esta escuchando en todas las "
                    "interfaces. Esto es un riesgo de seguridad."
                    "\n\nLinea: %s"
                    % (port, desc, tcp_wildcard.get(port, ""))
                ),
                "repair": (
                    "1) Identifique que servicio lo abre: "
                    "ss -tlnp | grep ':%d'\n"
                    "2) Detenga ese servicio: "
                    "sudo systemctl stop <servicio>\n"
                    "3) Si es intencional, restrinja a localhost: "
                    "bind 127.0.0.1 en su config" % port
                ),
            })

    for port, desc in EXPECTED_TCP.items():
        if port not in tcp_wildcard:
            issues.append({
                "check": "ports",
                "severity": "warning",
                "title": "Puerto esperado no escucha: %d (%s)" % (port, desc),
                "message": (
                    "El puerto %d (%s) no esta escuchando. "
                    "Esto puede indicar un servicio caido." % (port, desc)
                ),
                "repair": (
                    "Verifique el servicio asociado y reinicie si es necesario."
                ),
            })

    listening_any = set(tcp_any) | set(udp_any)

    for port, desc in EXPECTED_ANY.items():
        if port not in listening_any:
            issues.append({
                "check": "ports",
                "severity": "warning",
                "title": "Puerto esperado no escucha: %d (%s)" % (port, desc),
                "message": (
                    "El puerto %d (%s) no esta escuchando. "
                    "Esto puede indicar un servicio caido." % (port, desc)
                ),
                "repair": (
                    "Verifique el servicio asociado y reinicie si es necesario."
                ),
            })

    return issues
