"""Unified status of automatic maintenance tasks."""

import json
import os
import subprocess

from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.backups.repositories.backup_settings_repository import (
    BackupSettingsRepository,
)
from backend.dhcp.services.dhcp_reservation_cleanup_service import (
    DhcpReservationCleanupService,
)
from backend.retention.services.retention_service import RetentionService
from backend.shared.logging.logger import logger


MONTHS = {
    30: "1 mes",
    60: "2 meses",
    90: "3 meses",
    120: "4 meses",
    150: "5 meses",
    180: "6 meses",
    270: "9 meses",
    365: "12 meses",
    0: "ilimitado",
}

STATES = ("ok", "never", "overdue", "disabled")

TIMERS = (
    ("feed_malware", "Feed de malware", "stepad-malware-feed.timer"),
    ("suricata_rules", "Reglas de Suricata", "stepad-suricata-update.timer"),
)


def next_daily(now: datetime, hour: int, minute: int) -> datetime:

    target = now.replace(
        hour=int(hour or 0),
        minute=int(minute or 0),
        second=0,
        microsecond=0,
    )

    return target if target > now else target + timedelta(days=1)


def task_state(
    enabled: bool,
    last_run: datetime | None,
    next_run: datetime | None,
    now: datetime,
    grace_minutes: int = 120,
) -> str:

    if not enabled:

        return "disabled"

    if last_run is None:

        return "never"

    if next_run and now > next_run + timedelta(minutes=grace_minutes):

        return "overdue"

    return "ok"


def _iso(value: datetime | None) -> str | None:

    return value.isoformat(timespec="seconds") if value else None


def _systemd_timers() -> dict:

    """Last/next run of systemd timers (best effort)."""

    result = {}

    try:

        proc = subprocess.run(
            ["systemctl", "list-timers", "--all", "--output=json"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        if proc.returncode != 0:

            return result

        for row in json.loads(proc.stdout or "[]"):

            unit = row.get("unit") or ""

            next_us = row.get("next")

            last_us = row.get("last")

            if not unit or not isinstance(next_us, int):

                continue

            result[unit] = {
                "next": datetime.fromtimestamp(next_us / 1_000_000),
                "last": (
                    datetime.fromtimestamp(last_us / 1_000_000)
                    if isinstance(last_us, int) and last_us > 0
                    else None
                ),
            }

    except Exception as error:

        logger.debug("scheduled_tasks_service._systemd_timers: %s", error)

    return result


class ScheduledTasksService:

    def status(self, db: Session) -> dict:

        now = datetime.now()

        tasks = []

        # 1) Data retention per type (hourly).
        for item in RetentionService().list_settings(db):

            last = item.get("last_run_at")

            tasks.append({
                "key": f"retention.{item['key']}",
                "group": "Retención de datos",
                "label": item["label"],
                "enabled": bool(item.get("enabled", True)),
                "schedule": (
                    "cada hora · "
                    + MONTHS.get(item["retention_days"], f"{item['retention_days']} días")
                ),
                "last_run": _iso(last),
                "next_run": _iso(last + timedelta(hours=1)) if last else None,
                "result": f"{int(item.get('last_deleted') or 0)} eliminado(s)",
                "state": task_state(
                    bool(item.get("enabled", True)), last, None, now
                ),
            })

        # 2) DHCP reservation cleanup for offline devices.
        try:

            dhcp = DhcpReservationCleanupService().get_settings()

            hh, mm = (dhcp.get("run_time") or "03:00").split(":")

            last = self._parse_dt(dhcp.get("last_run_at"))

            tasks.append({
                "key": "dhcp.reservations",
                "group": "DHCP",
                "label": "Reservas de equipos offline",
                "enabled": bool(dhcp.get("enabled")),
                "schedule": f"diario {dhcp.get('run_time')} · {dhcp.get('days')} días",
                "last_run": dhcp.get("last_run_at"),
                "next_run": _iso(next_daily(now, int(hh), int(mm))),
                "result": f"{int(dhcp.get('last_deleted') or 0)} liberada(s)",
                "state": task_state(
                    bool(dhcp.get("enabled")), last,
                    next_daily(now, int(hh), int(mm)), now,
                    grace_minutes=180,
                ),
            })

        except Exception as error:

            logger.debug("scheduled_tasks_service dhcp: %s", error)

        # 3) Automatic backup.
        try:

            from backend.backups.services.backup_service import backup_overdue

            settings = BackupSettingsRepository().get(db)

            next_run = next_daily(now, settings.send_hour, settings.send_minute)

            enabled = bool(settings.enabled)

            state = (
                "overdue"
                if enabled and backup_overdue(
                    settings.last_backup_at, now,
                    settings.send_hour, settings.send_minute,
                )
                else task_state(
                    enabled, settings.last_backup_at, next_run, now,
                    grace_minutes=180,
                )
            )

            tasks.append({
                "key": "backup.database",
                "group": "Respaldos",
                "label": "Base de datos y configuración",
                "enabled": enabled,
                "schedule": (
                    f"diario {int(settings.send_hour):02d}:"
                    f"{int(settings.send_minute):02d} · "
                    f"{settings.retention_count} copias"
                ),
                "last_run": _iso(settings.last_backup_at),
                "next_run": _iso(next_run),
                "result": "OK" if settings.last_backup_at else "sin corridas",
                "state": state,
            })

        except Exception as error:

            logger.debug("scheduled_tasks_service backup: %s", error)

        # 3b) Monthly backup restore verification.
        try:

            from backend.backups.services.restore_verification_service import (
                RestoreVerificationService,
            )

            state = RestoreVerificationService().status()

            last = self._parse_dt(state.get("last_run_at"))

            next_run = last + timedelta(days=30) if last else None

            ok = bool(state.get("success"))

            state_value = task_state(
                True, last, next_run, now, grace_minutes=5 * 86400
            )

            if last is not None and not ok:

                state_value = "overdue"

            tasks.append({
                "key": "backup.restore_check",
                "group": "Respaldos",
                "label": "Verificación de respaldo",
                "enabled": True,
                "schedule": "mensual",
                "last_run": _iso(last),
                "next_run": _iso(next_run),
                "result": state.get("message") or "",
                "state": state_value,
            })

        except Exception as error:

            logger.debug("scheduled_tasks_service restore check: %s", error)

        # 4) System timers (feed/suricata).
        timers = _systemd_timers()

        for key, label, unit in TIMERS:

            info = timers.get(unit)

            if not info:

                continue

            last = info["last"]

            next_run = info["next"]

            tasks.append({
                "key": key,
                "group": "Sistema",
                "label": label,
                "enabled": True,
                "schedule": "diario (systemd)",
                "last_run": _iso(last),
                "next_run": _iso(next_run),
                "result": "",
                "state": task_state(True, last, next_run, now, grace_minutes=720),
            })

        return {
            "generated_at": _iso(now),
            "tasks": tasks,
            "resources": self._resources(),
        }

    def _parse_dt(self, value):

        if not value:

            return None

        try:

            return datetime.fromisoformat(str(value).replace("Z", ""))

        except Exception:

            return None

    def journal_used_mb(self) -> int | None:

        """Actual journal size (sum of files, not filesystem usage)."""

        folder = "/var/log/journal"

        if not os.path.isdir(folder):

            return None

        total = 0

        for root, _dirs, files in os.walk(folder):

            for name in files:

                try:

                    total += os.path.getsize(os.path.join(root, name))

                except OSError:

                    continue

        return round(total / (1024 ** 2))

    def _resources(self) -> dict:

        try:

            import shutil

            usage = shutil.disk_usage("/")

            return {
                "disk_percent": round(usage.used * 100 / usage.total, 1),
                "disk_free_gb": round(usage.free / (1024 ** 3), 1),
                "journal_used_mb": self.journal_used_mb(),
                "journal_limit_mb": 500,
            }

        except Exception as error:

            logger.debug("scheduled_tasks_service._resources: %s", error)

            return {}
