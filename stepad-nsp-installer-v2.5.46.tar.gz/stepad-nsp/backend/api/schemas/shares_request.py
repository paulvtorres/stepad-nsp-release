from pydantic import BaseModel, Field


class UpdateShareSettingsRequest(BaseModel):

    enabled: bool | None = None

    share_root: str | None = None

    workgroup: str | None = None

    server_name: str | None = None


class CreateShareFolderRequest(BaseModel):

    name: str

    folder_name: str | None = None

    description: str | None = None


class FolderGroupGrant(BaseModel):

    group_id: int

    access_mode: str = Field(default="read")


class SetFolderGroupsRequest(BaseModel):

    groups: list[FolderGroupGrant] = Field(default_factory=list)


class GroupFolderGrant(BaseModel):

    folder_id: int

    access_mode: str = Field(default="read")


class SetGroupFoldersRequest(BaseModel):

    folders: list[GroupFolderGrant] = Field(default_factory=list)
