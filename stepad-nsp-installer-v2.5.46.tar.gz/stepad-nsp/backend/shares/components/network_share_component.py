from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.shares.services.network_share_service import NetworkShareService
from backend.shared.logging.logger import logger


class NetworkShareComponent(BaseComponent):

    name = "network_shares"

    criticality = ComponentCriticality.OPTIONAL

    def __init__(self):
        self.service = NetworkShareService()

    def start(self):
        logger.info("NetworkShareComponent started.")
        try:
            self.service.ensure_boot()
        except Exception as error:
            logger.error("Network share boot error: %s", error)

    def stop(self):
        logger.info("NetworkShareComponent stopped.")
