from sqlalchemy import Boolean, DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NetworkShareFolder(Base):

    __tablename__ = "network_share_folders"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)

    # Directory name under share_root (sanitized, unique).
    folder_name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        unique=True,
    )

    description: Mapped[str | None] = mapped_column(String(255), nullable=True)

    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )


class GroupFolderAccess(Base):

    __tablename__ = "group_folder_access"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    group_id: Mapped[int] = mapped_column(
        ForeignKey("device_groups.id", ondelete="CASCADE"),
        nullable=False,
    )

    folder_id: Mapped[int] = mapped_column(
        ForeignKey("network_share_folders.id", ondelete="CASCADE"),
        nullable=False,
    )

    # "read" | "write"
    access_mode: Mapped[str] = mapped_column(String(10), default="read")

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )
