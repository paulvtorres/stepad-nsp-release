from sqlalchemy import Boolean, DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NetworkShareSettings(Base):

    __tablename__ = "network_share_settings"

    id: Mapped[int] = mapped_column(primary_key=True)

    enabled: Mapped[bool] = mapped_column(Boolean, default=False)

    # Absolute path where shared folders live (mounted disk or directory).
    share_root: Mapped[str | None] = mapped_column(String(512), nullable=True)

    workgroup: Mapped[str] = mapped_column(String(64), default="WORKGROUP")

    server_name: Mapped[str | None] = mapped_column(String(64), nullable=True)

    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )
