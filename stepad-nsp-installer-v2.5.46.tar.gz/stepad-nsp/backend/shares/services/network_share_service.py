"""
Network disk shares: one share root (disk/folder) + named folders whose
access is granted by device groups (same groups used for web filter /
bandwidth). Samba enforces access by client IP (hosts allow).
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.core.config.paths import SAMBA_SHARES_ROOT_DEFAULT
from backend.core.database.session import SessionLocal
from backend.groups.models.device_group import DeviceGroup, GroupDevice
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.interfaces.services.interface_service import (
    InterfaceService,
)
from backend.shares.models.network_share_folder import (
    GroupFolderAccess,
    NetworkShareFolder,
)
from backend.shares.models.network_share_settings import NetworkShareSettings
from backend.shares.providers.samba_share_provider import SambaShareProvider
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


_FOLDER_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


class NetworkShareService:

    def __init__(self):
        self.provider = SambaShareProvider()
        self.interface_service = InterfaceService()

    def _settings(self, db: Session) -> NetworkShareSettings:
        row = db.get(NetworkShareSettings, 1)
        if row is None:
            row = NetworkShareSettings(
                id=1,
                enabled=False,
                share_root=str(SAMBA_SHARES_ROOT_DEFAULT),
                workgroup="WORKGROUP",
            )
            db.add(row)
            db.commit()
            db.refresh(row)
        return row

    def _lan_ip(self) -> str | None:
        lan = self.interface_service.get_primary_lan()
        if not lan:
            return None
        ip = getattr(lan, "ip", None) or getattr(lan, "ipv4_address", None)
        return ip.strip() if isinstance(ip, str) and ip.strip() else None

    def list_candidate_roots(self) -> list[dict]:
        """Mountpoints and block devices useful as share roots."""

        candidates: list[dict] = []
        seen = set()

        default = str(SAMBA_SHARES_ROOT_DEFAULT)
        candidates.append({
            "path": default,
            "label": "Carpeta STEPAD (recomendado)",
            "kind": "default",
            "exists": Path(default).exists(),
        })
        seen.add(default)

        try:
            result = subprocess.run(
                ["findmnt", "-bno", "TARGET,SOURCE,FSTYPE,SIZE"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    parts = line.split()
                    if len(parts) < 3:
                        continue
                    target, source, fstype = parts[0], parts[1], parts[2]
                    if target in ("/", "/boot", "/boot/efi", "/etc", "/usr"):
                        continue
                    if fstype in ("tmpfs", "devtmpfs", "proc", "sysfs", "cgroup2"):
                        continue
                    if target in seen:
                        continue
                    seen.add(target)
                    size = parts[3] if len(parts) > 3 else None
                    candidates.append({
                        "path": target,
                        "label": f"{target} ({source})",
                        "kind": "mount",
                        "fstype": fstype,
                        "size_bytes": int(size) if size and size.isdigit() else None,
                        "exists": True,
                    })
        except Exception:
            pass

        return candidates

    def get_status(self, db: Session) -> dict:
        row = self._settings(db)
        runtime = self.provider.status()
        folders = self.list_folders(db)
        lan_ip = self._lan_ip()

        return {
            "enabled": bool(row.enabled),
            "share_root": row.share_root,
            "workgroup": row.workgroup,
            "server_name": row.server_name,
            "updated_at": to_iso_utc(row.updated_at) if row.updated_at else None,
            "lan_ip": lan_ip,
            "unc_base": f"\\\\{lan_ip}" if lan_ip else None,
            "samba": runtime,
            "folders": folders,
            "candidates": self.list_candidate_roots(),
            "ready": bool(
                row.enabled
                and row.share_root
                and runtime.get("installed")
                and runtime.get("smbd_active")
            ),
        }

    def update_settings(
        self,
        db: Session,
        *,
        enabled: bool | None = None,
        share_root: str | None = None,
        workgroup: str | None = None,
        server_name: str | None = None,
    ) -> dict:
        row = self._settings(db)

        if share_root is not None:
            root = share_root.strip()
            if not root:
                raise HTTPException(400, "Indica la ruta del disco/carpeta compartida.")
            if ".." in root or not root.startswith("/"):
                raise HTTPException(400, "La ruta debe ser absoluta.")
            Path(root).mkdir(parents=True, exist_ok=True)
            row.share_root = root

        if workgroup is not None:
            row.workgroup = (workgroup.strip() or "WORKGROUP")[:64]

        if server_name is not None:
            value = server_name.strip()
            row.server_name = value[:64] if value else None

        if enabled is not None:
            row.enabled = bool(enabled)

        row.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(row)

        self.apply(db)

        return self.get_status(db)

    def list_folders(self, db: Session) -> list[dict]:
        folders = (
            db.query(NetworkShareFolder)
            .order_by(NetworkShareFolder.name)
            .all()
        )
        return [self._folder_dict(db, folder) for folder in folders]

    def _folder_dict(self, db: Session, folder: NetworkShareFolder) -> dict:
        row = self._settings(db)
        root = Path(row.share_root or SAMBA_SHARES_ROOT_DEFAULT)
        path = root / folder.folder_name

        accesses = (
            db.query(GroupFolderAccess, DeviceGroup)
            .join(DeviceGroup, DeviceGroup.id == GroupFolderAccess.group_id)
            .filter(GroupFolderAccess.folder_id == folder.id)
            .all()
        )

        groups = [
            {
                "group_id": group.id,
                "group_name": group.name,
                "access_mode": access.access_mode,
            }
            for access, group in accesses
        ]

        lan_ip = self._lan_ip()

        return {
            "id": folder.id,
            "name": folder.name,
            "folder_name": folder.folder_name,
            "description": folder.description,
            "enabled": folder.enabled,
            "path": str(path),
            "unc_path": f"\\\\{lan_ip}\\{folder.name}" if lan_ip else None,
            "groups": groups,
            "created_at": to_iso_utc(folder.created_at) if folder.created_at else None,
        }

    def create_folder(
        self,
        db: Session,
        *,
        name: str,
        folder_name: str | None = None,
        description: str | None = None,
    ) -> dict:
        name = (name or "").strip()
        if not name:
            raise HTTPException(400, "El nombre de la carpeta es obligatorio.")

        slug = (folder_name or name).strip().replace(" ", "_")
        if not _FOLDER_NAME_RE.match(slug):
            raise HTTPException(
                400,
                "Nombre de carpeta inválido (usa letras, números, . _ -).",
            )

        if db.query(NetworkShareFolder).filter(
            (NetworkShareFolder.name == name)
            | (NetworkShareFolder.folder_name == slug)
        ).first():
            raise HTTPException(400, "Ya existe una carpeta con ese nombre.")

        folder = NetworkShareFolder(
            name=name,
            folder_name=slug,
            description=(description or "").strip() or None,
            enabled=True,
        )
        db.add(folder)
        db.commit()
        db.refresh(folder)

        self._ensure_folder_dir(db, folder)
        self.apply(db)

        return self._folder_dict(db, folder)

    def delete_folder(self, db: Session, folder_id: int) -> dict:
        folder = db.get(NetworkShareFolder, folder_id)
        if not folder:
            raise HTTPException(404, "Carpeta no encontrada.")

        db.query(GroupFolderAccess).filter(
            GroupFolderAccess.folder_id == folder_id
        ).delete()
        db.delete(folder)
        db.commit()

        self.apply(db)
        return {"success": True}

    def set_folder_groups(
        self,
        db: Session,
        folder_id: int,
        grants: list[dict],
    ) -> dict:
        """
        grants: [{group_id, access_mode: read|write}, ...]
        Replaces all access rows for the folder.
        """

        folder = db.get(NetworkShareFolder, folder_id)
        if not folder:
            raise HTTPException(404, "Carpeta no encontrada.")

        db.query(GroupFolderAccess).filter(
            GroupFolderAccess.folder_id == folder_id
        ).delete()

        for grant in grants or []:
            group_id = int(grant["group_id"])
            mode = (grant.get("access_mode") or "read").strip().lower()
            if mode not in ("read", "write"):
                raise HTTPException(400, "access_mode debe ser read o write.")
            if not db.get(DeviceGroup, group_id):
                raise HTTPException(400, f"Grupo {group_id} no existe.")
            db.add(GroupFolderAccess(
                group_id=group_id,
                folder_id=folder_id,
                access_mode=mode,
            ))

        db.commit()
        self.apply(db)
        return self._folder_dict(db, folder)

    def list_group_folders(self, db: Session, group_id: int) -> list[dict]:
        rows = (
            db.query(GroupFolderAccess, NetworkShareFolder)
            .join(
                NetworkShareFolder,
                NetworkShareFolder.id == GroupFolderAccess.folder_id,
            )
            .filter(GroupFolderAccess.group_id == group_id)
            .all()
        )
        return [
            {
                "folder_id": folder.id,
                "name": folder.name,
                "folder_name": folder.folder_name,
                "access_mode": access.access_mode,
                "enabled": folder.enabled,
            }
            for access, folder in rows
        ]

    def set_group_folders(
        self,
        db: Session,
        group_id: int,
        grants: list[dict],
    ) -> list[dict]:
        """
        grants: [{folder_id, access_mode}, ...] for one group.
        """

        if not db.get(DeviceGroup, group_id):
            raise HTTPException(404, "Grupo no encontrado.")

        db.query(GroupFolderAccess).filter(
            GroupFolderAccess.group_id == group_id
        ).delete()

        for grant in grants or []:
            folder_id = int(grant["folder_id"])
            mode = (grant.get("access_mode") or "read").strip().lower()
            if mode not in ("read", "write"):
                raise HTTPException(400, "access_mode debe ser read o write.")
            if not db.get(NetworkShareFolder, folder_id):
                raise HTTPException(400, f"Carpeta {folder_id} no existe.")
            db.add(GroupFolderAccess(
                group_id=group_id,
                folder_id=folder_id,
                access_mode=mode,
            ))

        db.commit()
        self.apply(db)
        return self.list_group_folders(db, group_id)

    def _ensure_folder_dir(
        self,
        db: Session,
        folder: NetworkShareFolder,
    ) -> Path:
        row = self._settings(db)
        root = Path(row.share_root or SAMBA_SHARES_ROOT_DEFAULT)
        root.mkdir(parents=True, exist_ok=True)
        path = root / folder.folder_name
        path.mkdir(parents=True, exist_ok=True)
        try:
            shutil.chown(path, user="nobody", group="nogroup")
            os.chmod(path, 0o775)
        except Exception as error:
            logger.warning("Could not chown share folder %s: %s", path, error)
        return path

    def _ips_for_groups(self, db: Session, group_ids: list[int]) -> list[str]:
        if not group_ids:
            return []

        rows = (
            db.query(NetworkDevice.ip_address)
            .join(GroupDevice, GroupDevice.device_id == NetworkDevice.id)
            .filter(GroupDevice.group_id.in_(group_ids))
            .filter(NetworkDevice.ip_address.isnot(None))
            .all()
        )

        ips = sorted({
            (ip or "").strip()
            for (ip,) in rows
            if ip and ip.strip() and ip.strip() != "0.0.0.0"
        })
        return ips

    def build_samba_shares(self, db: Session) -> list[dict]:
        row = self._settings(db)
        root = Path(row.share_root or SAMBA_SHARES_ROOT_DEFAULT)
        shares = []

        folders = (
            db.query(NetworkShareFolder)
            .filter(NetworkShareFolder.enabled.is_(True))
            .all()
        )

        for folder in folders:
            path = self._ensure_folder_dir(db, folder)
            accesses = (
                db.query(GroupFolderAccess)
                .filter(GroupFolderAccess.folder_id == folder.id)
                .all()
            )
            if not accesses:
                continue

            group_ids = [a.group_id for a in accesses]
            ips = self._ips_for_groups(db, group_ids)
            if not ips:
                # Share exists but no online devices yet — deny all except localhost.
                ips = []

            write = any(a.access_mode == "write" for a in accesses)

            shares.append({
                "name": folder.name,
                "path": str(path),
                "comment": folder.description or folder.name,
                "read_only": not write,
                "hosts_allow": ips,
            })

        return shares

    def apply(self, db: Session | None = None) -> dict:
        owns = db is None
        if owns:
            db = SessionLocal()
        try:
            row = self._settings(db)
            shares = self.build_samba_shares(db) if row.enabled else []

            if row.enabled and row.share_root:
                Path(row.share_root).mkdir(parents=True, exist_ok=True)

            self.provider.write_config(
                workgroup=row.workgroup or "WORKGROUP",
                server_name=row.server_name,
                shares=shares,
            )
            return self.provider.apply(enabled=bool(row.enabled))
        finally:
            if owns:
                db.close()

    def sync_access(self) -> None:
        """Called when group membership changes so hosts allow stays current."""

        try:
            self.apply()
        except Exception as error:
            logger.exception("Network share sync failed: %s", error)

    def ensure_boot(self) -> None:
        try:
            self.apply()
        except Exception as error:
            logger.error("Network share boot error: %s", error)
