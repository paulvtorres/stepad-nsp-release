from backend.shares import models as shares_models  # noqa: F401
