import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getShareStatus,
    updateShareConfig,
    createShareFolder,
    deleteShareFolder,
    setShareFolderGroups,
    getGroups,
} from "../../services/api";

import "./shares.css";


function Shares() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [groups, setGroups] = useState([]);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);

    const [shareRoot, setShareRoot] = useState("");

    const [workgroup, setWorkgroup] = useState("WORKGROUP");

    const [folderForm, setFolderForm] = useState({
        name: "",
        description: "",
    });


    function load() {

        Promise.all([getShareStatus(), getGroups()])
            .then(([s, g]) => {
                setStatus(s);
                setShareRoot(s.share_root || "");
                setWorkgroup(s.workgroup || "WORKGROUP");
                setGroups(g || []);
            })
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));

    }


    useEffect(() => {

        load();

        const timer = setInterval(load, 20000);

        return () => clearInterval(timer);

    }, []);


    async function saveConfig(patch) {

        setError(null);

        setBusy(true);

        try {

            const next = await updateShareConfig(patch);

            setStatus(next);

            setShareRoot(next.share_root || "");

            setWorkgroup(next.workgroup || "WORKGROUP");

        } catch (err) {

            setError(err.message || String(err));

        } finally {

            setBusy(false);

        }

    }


    async function handleCreateFolder() {

        if (!folderForm.name.trim()) {

            setError("Indica el nombre de la carpeta.");

            return;

        }

        setBusy(true);

        setError(null);

        try {

            await createShareFolder({
                name: folderForm.name.trim(),
                description: folderForm.description.trim() || null,
            });

            setFolderForm({ name: "", description: "" });

            load();

        } catch (err) {

            setError(err.message || String(err));

        } finally {

            setBusy(false);

        }

    }


    async function handleDeleteFolder(folder) {

        if (!confirm(`¿Eliminar la carpeta compartida «${folder.name}»?`)) {

            return;

        }

        setBusy(true);

        try {

            await deleteShareFolder(folder.id);

            load();

        } catch (err) {

            setError(err.message || String(err));

        } finally {

            setBusy(false);

        }

    }


    async function toggleGroupOnFolder(folder, group, accessMode) {

        const current = folder.groups || [];

        const exists = current.find((g) => g.group_id === group.id);

        let next;

        if (exists && exists.access_mode === accessMode) {

            next = current.filter((g) => g.group_id !== group.id);

        } else if (exists) {

            next = current.map((g) =>
                g.group_id === group.id
                    ? { ...g, access_mode: accessMode }
                    : g
            );

        } else {

            next = [
                ...current,
                { group_id: group.id, access_mode: accessMode },
            ];

        }

        setBusy(true);

        setError(null);

        try {

            await setShareFolderGroups(folder.id, {
                groups: next.map((g) => ({
                    group_id: g.group_id,
                    access_mode: g.access_mode,
                })),
            });

            load();

        } catch (err) {

            setError(err.message || String(err));

        } finally {

            setBusy(false);

        }

    }


    if (loading && !status) {

        return <div className="shares-page">Cargando disco de red…</div>;

    }


    const folders = status?.folders || [];

    const candidates = status?.candidates || [];


    return (

        <div className="shares-page">

            <header className="shares-header">

                <div>

                    <h2>Disco de red</h2>

                    <p>
                        Comparte un disco o carpeta del NSP en la LAN.
                        Cada carpeta se asigna a <strong>grupos</strong> de
                        equipos: el mismo modelo que bloqueos y ancho de banda.
                        Los PCs del grupo abren la ruta tipo{" "}
                        <code>\\IP-NSP\Carpeta</code>.
                    </p>

                </div>

                {
                    isAdmin && (
                        <label className="shares-enable">
                            <input
                                type="checkbox"
                                checked={Boolean(status?.enabled)}
                                disabled={busy}
                                onChange={(e) =>
                                    saveConfig({ enabled: e.target.checked })
                                }
                            />
                            Activar Samba (compartir en red)
                        </label>
                    )
                }

            </header>

            {error && <div className="shares-error">{error}</div>}

            <section className="shares-card">

                <h3>Estado</h3>

                <div className="shares-status-grid">

                    <div>
                        <span className="shares-label">Samba</span>
                        <strong>
                            {
                                status?.samba?.installed
                                    ? (status.samba.smbd_active ? "Activo" : "Instalado, detenido")
                                    : "No instalado (smbd)"
                            }
                        </strong>
                    </div>

                    <div>
                        <span className="shares-label">IP LAN</span>
                        <strong>{status?.lan_ip || "—"}</strong>
                    </div>

                    <div>
                        <span className="shares-label">Ruta base UNC</span>
                        <strong>{status?.unc_base || "—"}</strong>
                    </div>

                    <div>
                        <span className="shares-label">Listo</span>
                        <strong>{status?.ready ? "Sí" : "No"}</strong>
                    </div>

                </div>

                {
                    !status?.samba?.installed && (
                        <p className="shares-hint warn">
                            Instala el paquete <code>samba</code> en el NSP
                            para servir las carpetas. El módulo queda
                            configurado y aplicará al reiniciar Samba.
                        </p>
                    )
                }

            </section>

            <section className="shares-card">

                <h3>Unidad / carpeta raíz</h3>

                <p className="shares-hint">
                    Elige dónde viven los archivos compartidos: un disco
                    montado (USB/HDD) o la carpeta por defecto del NSP.
                    Luego creas carpetas lógicas con permisos por grupo.
                </p>

                {
                    isAdmin ? (
                        <div className="shares-form-row">

                            <label>
                                Ruta del disco o carpeta
                                <input
                                    type="text"
                                    value={shareRoot}
                                    onChange={(e) => setShareRoot(e.target.value)}
                                    placeholder="/srv/stepad-shares"
                                />
                            </label>

                            <label>
                                Grupo de trabajo (Windows)
                                <input
                                    type="text"
                                    value={workgroup}
                                    onChange={(e) => setWorkgroup(e.target.value)}
                                />
                            </label>

                            <button
                                type="button"
                                className="shares-primary"
                                disabled={busy}
                                onClick={() =>
                                    saveConfig({
                                        share_root: shareRoot,
                                        workgroup,
                                    })
                                }
                            >
                                Guardar raíz
                            </button>

                        </div>
                    ) : (
                        <p><code>{status?.share_root || "—"}</code></p>
                    )
                }

                {
                    candidates.length > 0 && isAdmin && (
                        <div className="shares-candidates">
                            <span className="shares-label">Sugerencias</span>
                            <div className="shares-candidate-list">
                                {
                                    candidates.map((c) => (
                                        <button
                                            key={c.path}
                                            type="button"
                                            className="shares-chip"
                                            disabled={busy}
                                            onClick={() => setShareRoot(c.path)}
                                            title={c.path}
                                        >
                                            {c.label}
                                        </button>
                                    ))
                                }
                            </div>
                        </div>
                    )
                }

            </section>

            <section className="shares-card">

                <h3>Carpetas compartidas</h3>

                {
                    isAdmin && (
                        <div className="shares-form-row">

                            <label>
                                Nombre (aparece en la red)
                                <input
                                    type="text"
                                    value={folderForm.name}
                                    onChange={(e) =>
                                        setFolderForm((f) => ({
                                            ...f,
                                            name: e.target.value,
                                        }))
                                    }
                                    placeholder="ej. Contabilidad"
                                />
                            </label>

                            <label>
                                Descripción
                                <input
                                    type="text"
                                    value={folderForm.description}
                                    onChange={(e) =>
                                        setFolderForm((f) => ({
                                            ...f,
                                            description: e.target.value,
                                        }))
                                    }
                                />
                            </label>

                            <button
                                type="button"
                                className="shares-primary"
                                disabled={busy}
                                onClick={handleCreateFolder}
                            >
                                Crear carpeta
                            </button>

                        </div>
                    )
                }

                {
                    folders.length === 0 ? (
                        <p className="shares-hint">
                            Aún no hay carpetas. Crea una y asígnale grupos
                            (Lectura o Lectura/escritura).
                        </p>
                    ) : (
                        folders.map((folder) => (
                            <div key={folder.id} className="shares-folder">

                                <div className="shares-folder-head">

                                    <div>

                                        <strong>{folder.name}</strong>

                                        <div className="shares-folder-meta">
                                            {folder.unc_path || folder.path}
                                            {folder.description
                                                ? ` · ${folder.description}`
                                                : ""}
                                        </div>

                                    </div>

                                    {
                                        isAdmin && (
                                            <button
                                                type="button"
                                                className="shares-danger"
                                                disabled={busy}
                                                onClick={() =>
                                                    handleDeleteFolder(folder)
                                                }
                                            >
                                                Eliminar
                                            </button>
                                        )
                                    }

                                </div>

                                <div className="shares-group-grants">

                                    <span className="shares-label">
                                        Grupos con acceso
                                    </span>

                                    <div className="shares-grant-list">

                                        {
                                            groups.map((group) => {

                                                const grant = (folder.groups || [])
                                                    .find((g) => g.group_id === group.id);

                                                return (
                                                    <div
                                                        key={group.id}
                                                        className={`shares-grant ${grant ? "on" : ""}`}
                                                    >
                                                        <span className="shares-grant-name">
                                                            {group.name}
                                                            {group.is_default ? " (Invitados)" : ""}
                                                        </span>
                                                        {
                                                            isAdmin ? (
                                                                <span className="shares-grant-actions">
                                                                    <button
                                                                        type="button"
                                                                        className={
                                                                            grant?.access_mode === "read"
                                                                                ? "active"
                                                                                : ""
                                                                        }
                                                                        disabled={busy}
                                                                        onClick={() =>
                                                                            toggleGroupOnFolder(
                                                                                folder,
                                                                                group,
                                                                                "read"
                                                                            )
                                                                        }
                                                                    >
                                                                        Lectura
                                                                    </button>
                                                                    <button
                                                                        type="button"
                                                                        className={
                                                                            grant?.access_mode === "write"
                                                                                ? "active"
                                                                                : ""
                                                                        }
                                                                        disabled={busy}
                                                                        onClick={() =>
                                                                            toggleGroupOnFolder(
                                                                                folder,
                                                                                group,
                                                                                "write"
                                                                            )
                                                                        }
                                                                    >
                                                                        Escritura
                                                                    </button>
                                                                </span>
                                                            ) : (
                                                                <span>
                                                                    {grant
                                                                        ? (grant.access_mode === "write"
                                                                            ? "Escritura"
                                                                            : "Lectura")
                                                                        : "Sin acceso"}
                                                                </span>
                                                            )
                                                        }
                                                    </div>
                                                );

                                            })
                                        }

                                    </div>

                                </div>

                            </div>
                        ))
                    )
                }

            </section>

        </div>

    );

}


export default Shares;
