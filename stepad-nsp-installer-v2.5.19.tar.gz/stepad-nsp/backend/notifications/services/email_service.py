import smtplib
import ssl

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

from pathlib import Path


class EmailService:

    def _parse_emails(self, raw: str) -> list[str]:

        return [
            email.strip()
            for email in (raw or "").split(",")
            if email.strip()
        ]

    def _deliver(
        self,
        settings,
        message
    ):

        try:

            port = settings.smtp_port or 587

            to_list = self._parse_emails(
                getattr(settings, "to_emails", "")
            )

            bcc_list = self._parse_emails(
                getattr(settings, "bcc_emails", "")
            )

            envelope = list(dict.fromkeys(to_list + bcc_list))

            if not envelope:

                return {
                    "success": False,
                    "message": "No recipient emails configured",
                }

            if port == 465:

                context = ssl.create_default_context()

                server = smtplib.SMTP_SSL(
                    settings.smtp_host,
                    port,
                    context=context,
                    timeout=30
                )

            else:

                server = smtplib.SMTP(
                    settings.smtp_host,
                    port,
                    timeout=30
                )

                server.ehlo()

                server.starttls()

                server.ehlo()

            if settings.smtp_user:

                server.login(
                    settings.smtp_user,
                    settings.smtp_password or ""
                )

            server.sendmail(
                settings.from_email,
                envelope,
                message.as_string()
            )

            server.quit()

            return {
                "success": True,
                "message": "Email sent"
            }

        except Exception as error:

            return {
                "success": False,
                "message": f"SMTP error: {error}"
            }

    def _recipients(self, settings):

        return self._parse_emails(getattr(settings, "to_emails", ""))

    def _bcc_recipients(self, settings):

        return self._parse_emails(getattr(settings, "bcc_emails", ""))

    def _apply_headers(self, message, settings):

        to_list = self._recipients(settings)

        bcc_list = self._bcc_recipients(settings)

        message["To"] = ", ".join(to_list)

        if bcc_list:

            message["Bcc"] = ", ".join(bcc_list)

        return to_list, bcc_list

    def send_html(
        self,
        settings,
        subject: str,
        html_body: str
    ):
        """
        Sends an HTML email through the configured SMTP server.
        Returns {success, message}. Handles both plain and
        SSL/TLS-starttls ports.
        """

        if not settings.smtp_host or not settings.from_email:

            return {
                "success": False,
                "message": "SMTP host or from address not configured"
            }

        message = MIMEMultipart("alternative")

        message["Subject"] = subject

        message["From"] = settings.from_email

        to_list, _ = self._apply_headers(message, settings)

        if not to_list:

            return {
                "success": False,
                "message": "No recipient emails configured"
            }

        message.attach(MIMEText(html_body, "html", "utf-8"))

        return self._deliver(settings, message)

    def send_html_with_attachment(
        self,
        settings,
        subject: str,
        html_body: str,
        attachment_bytes: bytes,
        attachment_filename: str,
    ):

        if not settings.smtp_host or not settings.from_email:

            return {
                "success": False,
                "message": "Falta servidor SMTP o correo remitente",
            }

        message = MIMEMultipart("mixed")

        message["Subject"] = subject

        message["From"] = settings.from_email

        to_list, _ = self._apply_headers(message, settings)

        if not to_list:

            return {
                "success": False,
                "message": "No hay destinatarios configurados",
            }

        alternative = MIMEMultipart("alternative")

        alternative.attach(MIMEText(html_body, "html", "utf-8"))

        message.attach(alternative)

        part = MIMEApplication(
            attachment_bytes,
            _subtype=(
                "vnd.openxmlformats-officedocument."
                "spreadsheetml.sheet"
            ),
        )

        part.add_header(
            "Content-Disposition",
            "attachment",
            filename=attachment_filename,
        )

        message.attach(part)

        return self._deliver(settings, message)

    def send_attachment(
        self,
        settings,
        subject: str,
        body: str,
        attachment_path: str | Path
    ):

        if not settings.smtp_host or not settings.from_email:

            return {
                "success": False,
                "message": "SMTP host or from address not configured"
            }

        path = Path(attachment_path)

        if not path.exists():

            return {
                "success": False,
                "message": f"Attachment not found: {path.name}"
            }

        message = MIMEMultipart()

        message["Subject"] = subject

        message["From"] = settings.from_email

        to_list, _ = self._apply_headers(message, settings)

        if not to_list:

            return {
                "success": False,
                "message": "No recipient emails configured"
            }

        message.attach(MIMEText(body, "plain", "utf-8"))

        with open(path, "rb") as file:

            part = MIMEApplication(
                file.read(),
                _subtype="octet-stream"
            )

        part.add_header(
            "Content-Disposition",
            "attachment",
            filename=path.name
        )

        message.attach(part)

        return self._deliver(settings, message)
