from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NotificationSettings(Base):

    __tablename__ = "notification_settings"


    id: Mapped[int] = mapped_column(
        primary_key=True
    )


    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    smtp_host: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )


    smtp_port: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=587
    )


    smtp_user: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    smtp_password: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    from_email: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )


    to_emails: Mapped[str] = mapped_column(
        String(1000),
        nullable=False,
        default=""
    )


    bcc_emails: Mapped[str] = mapped_column(
        String(1000),
        nullable=False,
        default=""
    )


    report_subject: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )


    alert_subject: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        default=""
    )


    # daily | weekly | monthly
    frequency: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="daily"
    )


    send_hour: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=8
    )


    send_minute: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0
    )


    last_sent_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True
    )


    # Alertas prioritarias de seguridad DNS (malware/phishing del feed).
    # Van aparte de "enabled" (reportes programados) para que un admin
    # pueda mantener estas alertas activas aunque desactive el reporte.
    security_dns_alert_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True
    )


    # Si esta vacio, se usa "to_emails". Permite avisar al equipo de
    # seguridad/TI sin mezclarlo con los destinatarios del reporte
    # general de navegacion.
    security_dns_alert_emails: Mapped[str] = mapped_column(
        String(1000),
        nullable=False,
        default=""
    )


    # CC (copia visible entre destinatarios) y CCO (copia oculta) para
    # esta alerta puntual -- p.ej. CC a un gerente de TI y CCO para un
    # buzon de auditoria/archivo, sin que ninguno vea al otro.
    security_dns_alert_cc_emails: Mapped[str] = mapped_column(
        String(1000),
        nullable=False,
        default=""
    )


    security_dns_alert_bcc_emails: Mapped[str] = mapped_column(
        String(1000),
        nullable=False,
        default=""
    )


    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
