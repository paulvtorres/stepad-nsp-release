import os
import signal
import subprocess
import time

import psutil

from backend.core.config.paths import (
    DNSMASQ_CONFIG,
    DNSMASQ_PID_FILE
)

from backend.shared.logging.logger import logger


DNSMASQ_BIN = "/usr/sbin/dnsmasq"

STOP_TIMEOUT_SECONDS = 5

START_CHECK_DELAY_SECONDS = 0.3


class DnsmasqProcessManager:
    """
    dnsmasq manages the DHCP lifecycle.
    DNS responsibilities can be handled by dnsmasq or delegated to
    another DNS engine depending on the configured settings.

    All operations that affect the dnsmasq process must go through
    this manager. (DNSMASQ_CONFIG, which conf-file-includes both
    blocked_domains.conf and reservations.conf). Every module that
    needs to apply changes to that process (domain rules, DHCP
    reservations, DHCP pool config) MUST go through this manager
    instead of independently signalling/spawning dnsmasq.

    Why a full restart and not SIGHUP:
    dnsmasq's SIGHUP handler only re-reads /etc/hosts, /etc/ethers,
    --dhcp-hostsfile, --dhcp-optsfile and --addn-hosts. It explicitly
    does NOT re-read the main configuration file, and address=/domain/
    directives (how we block domains) are only parsed at startup via
    conf-file=. So adding/removing a blocked domain requires killing
    and respawning the process — there is no lighter-weight option
    with this engine.
    """

    def _find_pid(self):

        if DNSMASQ_PID_FILE.exists():

            try:

                pid = int(
                    DNSMASQ_PID_FILE.read_text().strip()
                )

                if psutil.pid_exists(pid):

                    process = psutil.Process(pid)

                    if process.name() == "dnsmasq":

                        return pid

            except (ValueError, psutil.NoSuchProcess):

                pass

        # Fallback: scan by cmdline, matching OUR config file
        # specifically. Never match on process name alone -- this
        # host may be running an unrelated dnsmasq (NetworkManager,
        # libvirt, etc.) and killing that would be a serious bug.
        for process in psutil.process_iter(["pid", "name", "cmdline"]):

            if process.info["name"] != "dnsmasq":
                continue

            cmdline = " ".join(process.info.get("cmdline") or [])

            if str(DNSMASQ_CONFIG) in cmdline:

                return process.info["pid"]

        return None


    def status(self):

        pid = self._find_pid()

        return {
            "service": "dhcp",
            "running": pid is not None,
            "pid": pid
        }


    def stop(self):

        pid = self._find_pid()

        if not pid:

            return {
                "success": True,
                "message": "dnsmasq not running"
            }

        try:

            os.kill(pid, signal.SIGTERM)

            psutil.Process(pid).wait(
                timeout=STOP_TIMEOUT_SECONDS
            )

        except psutil.NoSuchProcess:

            pass

        except psutil.TimeoutExpired:

            logger.warning(
                f"dnsmasq (pid {pid}) did not stop gracefully, sending SIGKILL"
            )

            os.kill(pid, signal.SIGKILL)

        if DNSMASQ_PID_FILE.exists():

            DNSMASQ_PID_FILE.unlink()

        return {
            "success": True,
            "message": f"dnsmasq (pid {pid}) stopped"
        }


    def start(self):

        if not os.path.exists(DNSMASQ_BIN):

            return {
                "success": False,
                "error": "dnsmasq not installed"
            }

        existing = self._find_pid()

        if existing:

            return {
                "success": True,
                "pid": existing,
                "message": "dnsmasq already running"
            }

        DNSMASQ_CONFIG.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        process = subprocess.Popen(
            [
                DNSMASQ_BIN,
                "--no-daemon",
                "--conf-file=" + str(DNSMASQ_CONFIG)
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        time.sleep(START_CHECK_DELAY_SECONDS)

        if process.poll() is not None:

            _, stderr = process.communicate()

            logger.error(
                f"dnsmasq failed to start: {stderr.strip()}"
            )

            return {
                "success": False,
                "error": f"dnsmasq failed to start: {stderr.strip()}"
            }

        return {
            "success": True,
            "pid": process.pid,
            "message": "dnsmasq started"
        }


    def restart(self):

        from backend.shared.runtime.resource_locks import resource_locks

        with resource_locks.dnsmasq:
            self.stop()
            return self.start()


dnsmasq_process_manager = DnsmasqProcessManager()
