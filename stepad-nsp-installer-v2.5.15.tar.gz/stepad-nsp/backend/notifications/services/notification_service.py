import threading
import time

from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.notifications.models.notification_settings import (
    NotificationSettings
)
from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.report_service import ReportService

from backend.core.database.session import SessionLocal

from backend.shared.logging.logger import logger


FREQUENCY_LABELS = {
    "daily": "Diaria",
    "weekly": "Semanal",
    "monthly": "Mensual",
}

REPORT_PERIOD_LABELS = {
    "daily": "últimas 24 horas",
    "weekly": "últimos 7 días",
    "monthly": "últimos 30 días",
}


class NotificationService:

    def __init__(self):

        self.repository = NotificationSettingsRepository()

        self.email_service = EmailService()

        self.report_service = ReportService()

        self._scheduler_thread = None

        self._stop = False

    def _period(
        self,
        frequency: str
    ) -> tuple[datetime, datetime]:

        end = datetime.utcnow()

        days = {
            "daily": 1,
            "weekly": 7,
            "monthly": 30,
        }.get(frequency, 1)

        start = end - timedelta(days=days)

        return start, end

    def _smtp_ready(
        self,
        settings: NotificationSettings,
    ) -> tuple[bool, list[str]]:

        issues = []

        if not (settings.smtp_host or "").strip():

            issues.append("Servidor SMTP")

        if not (settings.from_email or "").strip():

            issues.append("Correo remitente")

        if not self.email_service._recipients(settings):

            issues.append("Destinatarios")

        if (settings.smtp_user or "").strip() and not settings.smtp_password:

            issues.append("Contraseña SMTP")

        return len(issues) == 0, issues

    def _next_send_hint(
        self,
        settings: NotificationSettings,
        now: datetime | None = None,
    ) -> str:

        now = now or datetime.now()

        if not settings.enabled:

            return "Las notificaciones están desactivadas."

        ready, issues = self._smtp_ready(settings)

        if not ready:

            return f"Complete: {', '.join(issues)}."

        if self.is_due(settings, now):

            return "Envío programado pendiente (próximos minutos)."

        target = now.replace(
            hour=settings.send_hour,
            minute=settings.send_minute,
            second=0,
            microsecond=0,
        )

        freq = settings.frequency or "daily"
        last = settings.last_sent_at

        if last is not None and last.tzinfo is None:

            last = last.replace(tzinfo=None)

        if freq == "daily":

            if now < target:

                return f"Hoy a las {settings.send_hour:02d}:{settings.send_minute:02d}"

            return (
                f"Mañana a las {settings.send_hour:02d}:"
                f"{settings.send_minute:02d}"
            )

        if freq == "weekly":

            if last is None:

                if now < target:

                    return (
                        f"Hoy a las {settings.send_hour:02d}:"
                        f"{settings.send_minute:02d} (primer envío)"
                    )

                return "Próximo envío en 7 días desde el primero."

            days_left = max(
                0,
                7 - (now.date() - last.date()).days,
            )

            if days_left == 0 and now >= target:

                return "Hoy (ciclo semanal)"

            return f"En {days_left or 7} día(s), a las {settings.send_hour:02d}:{settings.send_minute:02d}"

        if freq == "monthly":

            if last is None:

                if now < target:

                    return (
                        f"Hoy a las {settings.send_hour:02d}:"
                        f"{settings.send_minute:02d} (primer envío)"
                    )

                return "Próximo mes (primer envío)."

            if last.month == now.month and last.year == now.year:

                return (
                    f"Próximo mes, a las {settings.send_hour:02d}:"
                    f"{settings.send_minute:02d}"
                )

            if now < target:

                return f"Hoy a las {settings.send_hour:02d}:{settings.send_minute:02d}"

            return (
                f"Próximo mes, a las {settings.send_hour:02d}:"
                f"{settings.send_minute:02d}"
            )

        return f"A las {settings.send_hour:02d}:{settings.send_minute:02d}"

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        ready, issues = self._smtp_ready(settings)

        frequency = settings.frequency or "daily"

        return {
            "id": settings.id,
            "enabled": settings.enabled,
            "smtp_host": settings.smtp_host,
            "smtp_port": settings.smtp_port,
            "smtp_user": settings.smtp_user,
            "has_smtp_password": bool(settings.smtp_password),
            "from_email": settings.from_email,
            "to_emails": settings.to_emails,
            "frequency": frequency,
            "frequency_label": FREQUENCY_LABELS.get(frequency, frequency),
            "report_period": REPORT_PERIOD_LABELS.get(frequency, ""),
            "send_hour": settings.send_hour,
            "send_minute": settings.send_minute,
            "schedule_label": (
                f"{FREQUENCY_LABELS.get(frequency, frequency)} a las "
                f"{settings.send_hour:02d}:{settings.send_minute:02d}"
            ),
            "last_sent_at": (
                settings.last_sent_at.isoformat()
                if settings.last_sent_at else None
            ),
            "config_ready": ready,
            "config_issues": issues,
            "next_send_hint": self._next_send_hint(settings),
            "scheduler_running": (
                self._scheduler_thread is not None
                and self._scheduler_thread.is_alive()
            ),
        }

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.repository.get(db)

        if data.enabled is not None:
            settings.enabled = data.enabled

        if data.smtp_host is not None:
            settings.smtp_host = data.smtp_host

        if data.smtp_port is not None:
            settings.smtp_port = data.smtp_port

        if data.smtp_user is not None:
            settings.smtp_user = data.smtp_user

        # Only overwrite the password when a new one is provided.
        if data.smtp_password:
            settings.smtp_password = data.smtp_password

        if data.from_email is not None:
            settings.from_email = data.from_email

        if data.to_emails is not None:
            settings.to_emails = data.to_emails

        if data.frequency is not None:
            settings.frequency = data.frequency

        if data.send_hour is not None:
            settings.send_hour = data.send_hour

        if data.send_minute is not None:
            settings.send_minute = data.send_minute

        self.repository.save(db, settings)

        return self.get_settings(db)

    def send_report(
        self,
        db: Session,
        settings: NotificationSettings = None
    ) -> dict:

        settings = settings or self.repository.get(db)

        start, end = self._period(settings.frequency)

        html_body = self.report_service.build_html_report(
            db,
            start,
            end
        )

        excel_buffer = self.report_service.build_excel(
            db,
            start,
            end,
        )

        attachment_name = (
            f"historial-dns_{start.strftime('%Y%m%d')}-"
            f"{end.strftime('%Y%m%d')}.xlsx"
        )

        period_label = REPORT_PERIOD_LABELS.get(
            settings.frequency or "daily",
            "período seleccionado",
        )

        subject = (
            f"Reporte de navegación STEPAD NSP "
            f"({start.strftime('%d/%m/%Y')} - {end.strftime('%d/%m/%Y')})"
        )

        result = self.email_service.send_html_with_attachment(
            settings,
            subject,
            html_body,
            excel_buffer.getvalue(),
            attachment_name,
        )

        if result["success"]:

            settings.last_sent_at = datetime.now()

            self.repository.save(db, settings)

            result["message"] = (
                f"Reporte enviado ({period_label}) con Excel adjunto."
            )

        return result

    def send_test(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        html_body = (
            "<h2>Prueba de notificación</h2>"
            "<p>Este es un correo de prueba de STEPAD NSP. "
            "Si lo estás viendo, la configuración de correo es correcta.</p>"
        )

        return self.email_service.send_html(
            settings,
            "STEPAD NSP - Prueba de notificación",
            html_body
        )

    def is_due(
        self,
        settings: NotificationSettings,
        now: datetime
    ) -> bool:

        if not settings.enabled:

            return False

        if (
            now.hour < settings.send_hour
            or (
                now.hour == settings.send_hour
                and now.minute < settings.send_minute
            )
        ):

            return False

        last = settings.last_sent_at

        if last is None:

            return True

        if settings.frequency == "daily":

            return last.date() < now.date()

        if settings.frequency == "weekly":

            return (now.date() - last.date()).days >= 7

        if settings.frequency == "monthly":

            return (
                last.year != now.year
                or last.month != now.month
            )

        return False

    def _scheduler_loop(
        self
    ):

        logger.info("Notification scheduler started.")

        while not self._stop:

            try:

                db = SessionLocal()

                try:

                    settings = self.repository.get(db)

                    if self.is_due(settings, datetime.now()):

                        result = self.send_report(db, settings)

                        logger.info(
                            f"Notification report: {result}"
                        )

                    try:

                        from backend.siem.services.compliance_service import (
                            ComplianceService
                        )

                        ComplianceService().check_logs_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Logs review check failed: {error}"
                        )

                    try:

                        from backend.firewall.services.firewall_hardening_service import (
                            FirewallHardeningService
                        )

                        FirewallHardeningService().check_access_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Access review check failed: {error}"
                        )

                finally:

                    db.close()

            except Exception as error:

                logger.exception(
                    f"Notification scheduler error: {error}"
                )

            time.sleep(30)

    def start_scheduler(
        self
    ):

        if self._scheduler_thread is not None:

            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="notification-scheduler"
        )

        self._scheduler_thread.start()
