import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getNotificationSettings,
    saveNotificationSettings,
    testNotification,
    sendNotificationNow,
} from "../../../services/api";

import "../settings.css";


function formatDateTime(value) {

    if (!value) return "Nunca";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return "—";

    return date.toLocaleString();

}


function NotificationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        enabled: false,
        smtp_host: "",
        smtp_port: 587,
        smtp_user: "",
        smtp_password: "",
        from_email: "",
        to_emails: "",
        frequency: "daily",
        send_hour: 8,
        send_minute: 0,
    });

    const [status, setStatus] = useState({
        config_ready: false,
        config_issues: [],
        next_send_hint: "",
        schedule_label: "",
        report_period: "",
        frequency_label: "",
        last_sent_at: null,
        has_smtp_password: false,
        scheduler_running: false,
    });

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    function applySettings(data) {

        setForm({
            enabled: data.enabled,
            smtp_host: data.smtp_host || "",
            smtp_port: data.smtp_port || 587,
            smtp_user: data.smtp_user || "",
            smtp_password: "",
            from_email: data.from_email || "",
            to_emails: data.to_emails || "",
            frequency: data.frequency || "daily",
            send_hour: data.send_hour ?? 8,
            send_minute: data.send_minute ?? 0,
        });

        setStatus({
            config_ready: Boolean(data.config_ready),
            config_issues: data.config_issues || [],
            next_send_hint: data.next_send_hint || "",
            schedule_label: data.schedule_label || "",
            report_period: data.report_period || "",
            frequency_label: data.frequency_label || "",
            last_sent_at: data.last_sent_at || null,
            has_smtp_password: Boolean(data.has_smtp_password),
            scheduler_running: Boolean(data.scheduler_running),
        });

    }


    async function reloadSettings() {

        const data = await getNotificationSettings();

        applySettings(data);

        return data;

    }


    useEffect(() => {

        let cancelled = false;

        getNotificationSettings()

            .then((data) => {
                if (!cancelled) applySettings(data);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveNotificationSettings({
                enabled: form.enabled,
                smtp_host: form.smtp_host,
                smtp_port: Number(form.smtp_port),
                smtp_user: form.smtp_user,
                smtp_password: form.smtp_password || null,
                from_email: form.from_email,
                to_emails: form.to_emails,
                frequency: form.frequency,
                send_hour: Number(form.send_hour),
                send_minute: Number(form.send_minute),
            });

            applySettings(saved);

            setNotice("Configuración guardada correctamente.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleTest() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await testNotification();

            if (result.success === false) {

                setError(result.message || "No se pudo enviar la prueba.");

                return;

            }

            setNotice(result.message || "Correo de prueba enviado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSendNow() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await sendNotificationNow();

            if (result.success === false) {

                setError(result.message || "No se pudo enviar el reporte.");

                return;

            }

            await reloadSettings();

            setNotice(result.message || "Reporte enviado con Excel adjunto.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const recipientCount = form.to_emails
        .split(",")
        .map((email) => email.trim())
        .filter(Boolean).length;

    return (

        <div className="notify-panel">

            <div className="notify-header">

                <div>

                    <h3>Reportes automáticos por correo</h3>

                    <p className="notify-lead">

                        Envía al dueño o al área de TI un resumen de
                        navegación (Historial DNS) con Excel adjunto,
                        según la frecuencia que elija. El servicio revisa
                        cada minuto si corresponde enviar.

                    </p>

                </div>

                <label className={`notify-master-toggle ${form.enabled ? "on" : ""}`}>
                    <input
                        type="checkbox"
                        checked={form.enabled}
                        disabled={!isAdmin}
                        onChange={(e) =>
                            setForm({ ...form, enabled: e.target.checked })
                        }
                    />
                    <span>{form.enabled ? "Activo" : "Inactivo"}</span>
                </label>

            </div>


            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}


            <div className="notify-status-grid">

                <div className={`notify-status-card ${form.enabled ? "ok" : "muted"}`}>
                    <span className="notify-status-label">Estado</span>
                    <strong>{form.enabled ? "Programado" : "Desactivado"}</strong>
                    <span className="notify-status-meta">
                        {status.scheduler_running
                            ? "Servicio en ejecución"
                            : "Servicio no detectado"}
                    </span>
                </div>

                <div className="notify-status-card">
                    <span className="notify-status-label">Último envío</span>
                    <strong>{formatDateTime(status.last_sent_at)}</strong>
                    <span className="notify-status-meta">
                        {status.schedule_label || "Sin programación"}
                    </span>
                </div>

                <div className={`notify-status-card ${status.config_ready ? "ok" : "warn"}`}>
                    <span className="notify-status-label">Configuración SMTP</span>
                    <strong>{status.config_ready ? "Completa" : "Incompleta"}</strong>
                    <span className="notify-status-meta">
                        {status.config_ready
                            ? `${recipientCount} destinatario(s)`
                            : (status.config_issues || []).join(", ") || "Revise los campos"}
                    </span>
                </div>

                <div className="notify-status-card">
                    <span className="notify-status-label">Próximo envío</span>
                    <strong>{status.next_send_hint || "—"}</strong>
                    <span className="notify-status-meta">
                        Hora local del servidor NSP
                    </span>
                </div>

            </div>


            <div className="notify-report-preview">

                <h4>Contenido del reporte</h4>

                <ul>
                    <li>Resumen ejecutivo por equipo (consultas DNS y bloqueos)</li>
                    <li>Detalle de dominios visitados en el período</li>
                    <li>Intentos de acceso bloqueados</li>
                    <li>
                        Período del envío automático:{" "}
                        <strong>{status.report_period || "según frecuencia"}</strong>
                    </li>
                    <li>Archivo adjunto: <strong>historial-dns_*.xlsx</strong></li>
                </ul>

            </div>


            <div className="notify-section">

                <h4>Servidor de correo (SMTP)</h4>

                <div className="notify-form-grid">

                    <label>
                        Servidor SMTP
                        <input
                            type="text"
                            value={form.smtp_host}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, smtp_host: e.target.value })
                            }
                            placeholder="smtp.gmail.com"
                        />
                    </label>

                    <label>
                        Puerto
                        <input
                            type="number"
                            value={form.smtp_port}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, smtp_port: e.target.value })
                            }
                            placeholder="587"
                        />
                    </label>

                    <label>
                        Usuario SMTP
                        <input
                            type="text"
                            value={form.smtp_user}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, smtp_user: e.target.value })
                            }
                            placeholder="notificaciones@empresa.com"
                        />
                    </label>

                    <label>
                        Contraseña SMTP
                        <input
                            type="password"
                            value={form.smtp_password}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, smtp_password: e.target.value })
                            }
                            placeholder={
                                status.has_smtp_password
                                    ? "•••••••• (dejar vacío = no cambiar)"
                                    : "Contraseña del buzón"
                            }
                        />
                    </label>

                    <label>
                        Remitente (From)
                        <input
                            type="email"
                            value={form.from_email}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, from_email: e.target.value })
                            }
                            placeholder="nsp@empresa.com"
                        />
                    </label>

                    <label className="notify-wide">
                        Destinatarios
                        <input
                            type="text"
                            value={form.to_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, to_emails: e.target.value })
                            }
                            placeholder="dueno@empresa.com, ti@empresa.com"
                        />
                        <span className="notify-field-hint">
                            Separe varios correos con coma.
                        </span>
                    </label>

                </div>

            </div>


            <div className="notify-section">

                <h4>Programación del envío</h4>

                <div className="notify-form-grid notify-schedule-grid">

                    <label>
                        Frecuencia
                        <select
                            value={form.frequency}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, frequency: e.target.value })
                            }
                        >
                            <option value="daily">Diaria — últimas 24 h</option>
                            <option value="weekly">Semanal — últimos 7 días</option>
                            <option value="monthly">Mensual — últimos 30 días</option>
                        </select>
                    </label>

                    <label>
                        Hora de envío
                        <input
                            type="time"
                            disabled={!isAdmin}
                            value={`${String(form.send_hour).padStart(2, "0")}:${String(form.send_minute).padStart(2, "0")}`}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setForm({
                                    ...form,
                                    send_hour: Number(h),
                                    send_minute: Number(m),
                                });
                            }}
                        />
                        <span className="notify-field-hint">
                            Hora del servidor donde corre el NSP.
                        </span>
                    </label>

                </div>

            </div>


            <div className="notify-actions">

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={busy || !isAdmin}
                >
                    {busy ? "Guardando..." : "Guardar configuración"}
                </button>

                <button
                    className="secondary-button"
                    onClick={handleTest}
                    disabled={busy || !isAdmin}
                >
                    Enviar correo de prueba
                </button>

                <button
                    className="secondary-button"
                    onClick={handleSendNow}
                    disabled={busy || !isAdmin}
                >
                    Enviar reporte ahora
                </button>

            </div>

            {!isAdmin && (
                <p className="notify-readonly">Solo administradores pueden modificar esta sección.</p>
            )}

        </div>

    );

}


export default NotificationSection;
