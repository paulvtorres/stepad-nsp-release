"""Reconciliador DHCP: el ÚNICO escritor del estado de dnsmasq.

Tres fuentes de verdad, una sola salida:

    config.yaml   -> segmento (pool, gateway, lease, exclusiones)
    base de datos -> reservas por equipo y rangos de zona/grupo
    leases        -> observado (lo que dnsmasq tiene prestado)

`apply()` recalcula el estado deseado con la capa `domain/`, escribe
`dnsmasq.conf` y `reservations.conf` de forma ATÓMICA, valida con
`dnsmasq --test` y solo reinicia el proceso si el contenido cambió.

Reglas de la capa:

- Nadie fuera de aquí escribe esos dos archivos ni reinicia dnsmasq.
- Es idempotente: llamarlo N veces seguidas no reinicia nada si no hay
  cambios (un reinicio de dnsmasq corta DHCP/DNS unos segundos).
- Si la validación falla, restaura el contenido anterior y NO reinicia.
- Si el pool queda casi agotado, lo reporta (el panel lo muestra) para
  que el operador amplíe el segmento antes de que los equipos fallen.
"""

from __future__ import annotations

import hashlib
import threading

from datetime import datetime, timedelta, timezone
from backend.shared.datetime_utils import utcnow
from pathlib import Path

from backend.dhcp.domain.pool import build_pool_spec, pool_stats
from backend.dhcp.domain.conflicts import find_conflicts
from backend.dhcp.domain.reclaim import select_reclaimable
from backend.dhcp.domain.leases import parse_leases, read_leases
from backend.dhcp.domain.neighbors import arp_mac_by_ip
from backend.shared.logging.logger import logger


# Cuántas direcciones libres se consideran "pocas" para avisar.
POOL_LOW_ABSOLUTE = 5

POOL_LOW_RATIO = 0.05


def _digest(*texts: str) -> str:

    sha = hashlib.sha256()

    for text in texts:

        sha.update(text.encode("utf-8", "replace"))

    return sha.hexdigest()


def read_arp_table() -> dict[str, str]:
    """{ip: mac} de la tabla ARP (único punto de IO de vecinos)."""

    try:

        with open("/proc/net/arp", encoding="utf-8", errors="replace") as file:

            return arp_mac_by_ip(file.read())

    except OSError:

        return {}


class DhcpReconciler:

    def __init__(
        self,
        config_builder,
        reservations_builder,
        provider,
        reservation_provider,
        process_manager,
        config_path: Path,
        reservations_path: Path,
        alert_notifier=None,
        email_notifier=None,
        threshold_provider=None,
        config_service=None,
        leases_path: Path = Path("/var/lib/misc/dnsmasq.leases"),
    ):

        self._config_builder = config_builder

        self._reservations_builder = reservations_builder

        self._provider = provider

        self._reservation_provider = reservation_provider

        self._process = process_manager

        self._config_path = Path(config_path)

        self._reservations_path = Path(reservations_path)

        self._last_good_config_path = Path(str(config_path) + ".last-good")

        self._last_good_reservations_path = Path(str(reservations_path) + ".last-good")

        self._start_failures = 0

        self._alert_notifier = alert_notifier or self._default_alert

        self._email_notifier = email_notifier

        # Umbral configurado (panel). Inyectable para tests.
        self._threshold_provider = threshold_provider or self._configured_threshold

        self._config_service = config_service

        self._leases_path = Path(leases_path)

        # Racha de conflictos por IP: se remedia solo lo persistente
        # (un ARP viejo de un cambio de IP no debe sacar una IP del pool).
        self._conflict_first_seen: dict[str, datetime] = {}

        self._conflict_streaks: dict[str, int] = {}

        self._lock = threading.Lock()

        self._last_digest: str | None = None

        self._last_config_digest: str | None = None

        self._last_reservations_digest: str | None = None

        self._state = {
            "last_apply_at": None,
            "last_ok": None,
            "last_error": None,
            "applies": 0,
            "restarts": 0,
            "skipped": 0,
            "pool_low": False,
            "pool_exhausted": False,
            "conflicts": 0,
            "conflicts_signature": "",
            "reclaimed_total": 0,
            "reclaimed_last": 0,
        }

    # ------------------------------------------------------------------
    # Alertas de capacidad
    # ------------------------------------------------------------------

    def _default_alert(self, alert_type, severity, title, message) -> None:

        try:

            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                AlertService().create(
                    db,
                    alert_type=alert_type,
                    severity=severity,
                    title=title[:120],
                    message=message[:500],
                )

                db.commit()

            finally:

                db.close()

        except Exception as error:

            logger.warning("DHCP: no se pudo crear la alerta %s: %s", alert_type, error)

    def _notify_by_email(self, kind: str, pool: dict, was_low: bool, low: bool) -> None:

        if self._email_notifier is None:

            return

        try:

            self._email_notifier(
                kind,
                int(pool.get("free") or 0),
                int(pool.get("threshold") or 0),
            )

        except Exception as error:

            logger.warning("DHCP: no se pudo enviar el aviso por correo: %s", error)

    def _check_conflicts(self, config, reservations) -> list[dict]:

        """Conflictos de IP (lease vs ARP / estaticas dentro del pool).

        Se avisa UNA vez por conjunto de conflictos: si cambian, se avisa
        de nuevo (el titulo incluye las IPs para no quedar pegado al viejo).
        """

        arp = read_arp_table()

        if not arp:

            return []

        reserved = [item.get("ip") for item in reservations if item.get("ip")]

        conflicts = find_conflicts(
            read_leases(self._leases_path),
            arp,
            reserved,
            config.pool_start,
            config.pool_end,
        )

        signature = ",".join(
            f"{item.kind}:{item.ip}" for item in conflicts
        )

        self._state["conflicts"] = len(conflicts)

        if conflicts and signature != self._state.get("conflicts_signature"):

            real = [item for item in conflicts if item.kind == "lease_mismatch"]

            if real:

                detalles = "; ".join(
                    f"{item.ip}: lease {item.lease_mac} pero responde {item.arp_mac}"
                    for item in real[:4]
                )

                self._alert_notifier(
                    "DHCP_IP_CONFLICT",
                    "critical",
                    "DHCP: IP duplicada en la red (%d)" % len(real),
                    (
                        f"{detalles}. Un equipo usa una IP estatica dentro "
                        "del pool DHCP: reservala en Dispositivos o cambiala "
                        "fuera del pool (" + f"{config.pool_start}-{config.pool_end}" + ")."
                    ),
                )

            logger.warning(
                "DHCP: %d conflicto(s) de IP detectados (%s)",
                len(conflicts),
                signature,
            )

        self._state["conflicts_signature"] = signature

        self._remediate_conflicts(conflicts)

        return [item.to_dict() for item in conflicts]

    def _get_config_service(self):

        if self._config_service is None:

            from backend.shared.config.config_service import ConfigService

            self._config_service = ConfigService()

        return self._config_service

    def _remediate_conflicts(self, conflicts) -> None:

        """Excluye temporalmente IPs en conflicto persistente.

        Persistente = visto durante al menos 10 minutos, no dos applies
        seguidos. La exclusión automática caduca (7 días por defecto) y
        nunca se mezcla con las exclusiones manuales del operador.
        """

        now = datetime.now(timezone.utc)

        real = {

            item.ip: item

            for item in conflicts

            if item.kind in ("lease_mismatch", "static_in_pool")

        }

        for ip in list(self._conflict_first_seen):

            if ip not in real:

                self._conflict_first_seen.pop(ip, None)

        for ip in real:

            self._conflict_first_seen.setdefault(ip, now)

        persistent = sorted(

            ip

            for ip, first_seen in self._conflict_first_seen.items()

            if (now - first_seen).total_seconds() >= 600

        )

        self._state["auto_excluded"] = persistent

        try:

            service = self._get_config_service()

            config = dict(service.get_dhcp_config() or {})

            manual = list(config.get("excluded_ips") or [])

            days = max(1, min(365, int(config.get("auto_exclusion_days") or 7)))

            keep = []

            changed = False

            existing = {}

            for item in config.get("auto_excluded_ips") or []:

                if not isinstance(item, dict):

                    changed = True

                    continue

                try:

                    until = datetime.fromisoformat(str(item.get("until") or "").replace("Z", "+00:00"))

                except ValueError:

                    changed = True

                    continue

                if until > now:

                    keep.append(item)

                    existing[str(item.get("ip") or "")] = item

                else:

                    changed = True

            added = []

            for ip in persistent:

                if ip in manual:

                    continue

                if ip in existing:

                    existing[ip]["until"] = (now + timedelta(days=days)).isoformat()

                else:

                    item = {

                        "ip": ip,

                        "until": (now + timedelta(days=days)).isoformat(),

                        "reason": "Conflicto DHCP persistente",

                    }

                    keep.append(item)

                    existing[ip] = item

                    added.append(ip)

            if added or changed or (
                config.get("auto_excluded_ips") is not None
                and config.get("auto_excluded_ips") != keep
            ):

                config["auto_excluded_ips"] = keep

                service.update_section("dhcp", config)

                if added:

                    logger.warning(
                        "DHCP: IPs en conflicto excluidas temporalmente: %s", added
                    )

        except Exception as error:

            logger.warning(
                "DHCP: no se pudieron actualizar exclusiones automáticas: %s", error
            )

    def _notify_pool(self, pool: dict) -> None:

        """Alerta al AGOTARSE el pool y aviso cuando se recupera.

        Solo en las transiciones: una condicion que persiste no genera
        ruido (la alerta existente se mantiene viva).
        """

        if not pool:

            return

        was_low = bool(self._state.get("pool_low"))

        low = bool(pool.get("low"))

        if low and not was_low:

            self._notify_by_email("low", pool, was_low, low)

            self._alert_notifier(
                "DHCP_POOL_LOW",
                "warning",
                "DHCP: pool de IPs casi agotado",
                (
                    f"Quedan {pool.get('free')} direcciones libres "
                    f"(umbral {pool.get('threshold')}). Los equipos nuevos "
                    "pueden quedarse sin IP. STEPAD liberará leases de "
                    "equipos offline no ocupados; las reservas no se tocan. "
                    "Si no alcanza, ampliá el pool o reducí el lease_time."
                ),
            )

        elif was_low and not low:

            self._notify_by_email("recovered", pool, was_low, low)

            self._alert_notifier(
                "DHCP_POOL_RECOVERED",
                "info",
                "DHCP: el pool de IPs tiene espacio nuevamente",
                (
                    f"Direcciones libres: {pool.get('free')} "
                    f"(umbral {pool.get('threshold')})."
                ),
            )

        self._state["pool_low"] = low

        free = int(pool.get("free") or 0)

        exhausted = free <= 0

        was_exhausted = bool(self._state.get("pool_exhausted"))

        if exhausted and not was_exhausted:

            self._alert_notifier(
                "DHCP_POOL_EXHAUSTED",
                "critical",
                "DHCP: no quedan IPs libres",
                (
                    "El pool no tiene direcciones libres. STEPAD libera "
                    "leases y reservas de equipos offline que no estén en "
                    "uso. Si el problema continúa, ampliá el pool o reducí "
                    "reservas permanentes."
                ),
            )

        elif was_exhausted and not exhausted:

            self._alert_notifier(
                "DHCP_POOL_RECOVERED",
                "info",
                "DHCP: el pool de IPs tiene espacio nuevamente",
                f"Direcciones libres: {free}.",
            )

        self._state["pool_exhausted"] = exhausted

    # ------------------------------------------------------------------
    # Estado
    # ------------------------------------------------------------------

    def status(self) -> dict:

        return dict(self._state)

    def _record(self, **values) -> None:

        self._state.update(values)

        self._state["last_apply_at"] = utcnow().isoformat()

    # ------------------------------------------------------------------
    # Escritura atómica
    # ------------------------------------------------------------------

    def _write_atomic(self, path: Path, content: str) -> None:

        path.parent.mkdir(parents=True, exist_ok=True)

        tmp = path.with_suffix(path.suffix + ".tmp")

        tmp.write_text(content, encoding="utf-8")

        tmp.replace(path)

    def _restore(self, path: Path, previous: str | None) -> None:

        if previous is None:

            return

        try:

            self._write_atomic(path, previous)

        except OSError as error:

            logger.error("DHCP: no se pudo restaurar %s: %s", path, error)

    # ------------------------------------------------------------------
    # Reconciliación
    # ------------------------------------------------------------------

    def apply(self, force: bool = False) -> dict:

        with self._lock:

            return self._apply_locked(force=force)

    def _apply_locked(self, force: bool) -> dict:

        # Candado compartido con el resto del appliance: evita que otro
        # servicio (p. ej. LAN temporal) reinicie dnsmasq en medio de la
        # reescritura de la configuracion.
        from backend.shared.runtime.resource_locks import resource_locks

        with resource_locks.dnsmasq:

            return self._apply_serialized(force=force)

    def _apply_serialized(self, force: bool) -> dict:

        self._state["applies"] += 1

        previous_config = self._read(self._config_path)

        previous_reservations = self._read(self._reservations_path)

        try:

            config = self._config_builder()

        except Exception as error:

            logger.error(
                "DHCP: no se pudo calcular la configuración; se conserva la actual: %s",
                error,
            )

            service_result = self._ensure_current_service()

            self._record(
                last_ok=bool(service_result.get("success")),
                last_error=str(error),
            )

            return {
                "success": bool(service_result.get("success")),
                "fallback": "config_builder",
                "error": str(error),
                "service": service_result,
            }

        if config is None:

            self._record(last_ok=False, last_error="LAN no asignada")

            return {"success": False, "message": "LAN not detected"}

        reservations_error = None

        try:

            reservations = self._reservations_builder()

        except Exception as error:

            # Si la BD falla, NO se debe dejar dnsmasq caído. Se conserva
            # reservations.conf actual y se sigue con config/validación.
            logger.error(
                "DHCP: no se pudieron calcular reservas; se reutiliza el archivo actual: %s",
                error,
            )

            reservations = None

            reservations_error = str(error)

        try:

            config_result = self._provider.write_config(config)

            if reservations is None:

                reservations_result = {
                    "success": False,
                    "reused": True,
                    "error": reservations_error,
                }

            else:

                reservations_result = self._reservation_provider.write_reservations(
                    reservations
                )

        except Exception as error:

            logger.error("DHCP: fallo al escribir la configuración: %s", error)

            self._restore(self._config_path, previous_config)

            self._restore(self._reservations_path, previous_reservations)

            self._record(last_ok=False, last_error=str(error))

            return {"success": False, "error": str(error)}

        new_config = self._read(self._config_path) or ""

        new_reservations = self._read(self._reservations_path) or ""

        digest = _digest(new_config, new_reservations)

        config_digest = _digest(new_config)

        reservations_digest = _digest(new_reservations)

        config_changed = config_digest != self._last_config_digest

        reservations_changed = reservations_digest != self._last_reservations_digest

        running = bool(self._process.status().get("running"))

        conflicts = self._check_conflicts(config, reservations or [])

        static_ips = [
            item["ip"]
            for item in conflicts
            if item.get("kind") == "static_in_pool"
        ]

        pool = self._pool_status(config, reservations, static_ips)

        self._notify_pool(pool)

        # Auto-reclamacion: SOLO cuando el pool cruzo el umbral.
        reclaimed = self._reclaim_if_needed(pool)

        if reclaimed:

            pool = self._pool_status(config, reservations, static_ips)

            self._notify_pool(pool)

            # Los leases cambiaron: reiniciar para recargarlos.
            running = bool(self._process.status().get("running"))

            force = True

        if (
            not force
            and running
            and digest == self._last_digest
        ):

            self._state["skipped"] += 1

            self._record(last_ok=True, last_error=None)

            return {
                "success": True,
                "changed": False,
                "skipped": True,
                "reservations": reservations_result,
                "config": config_result,
                "service": self._process.status(),
                "pool": pool,
            }

        try:

            validation = self._provider.validate()

        except Exception as error:

            validation = {"success": False, "error": f"validación falló: {error}"}

        if not validation.get("success", True):

            logger.error(
                "DHCP: configuración inválida, se restaura la anterior: %s",
                validation.get("message") or validation,
            )

            self._restore(self._config_path, previous_config)

            self._restore(self._reservations_path, previous_reservations)

            self._record(
                last_ok=False,
                last_error=(
                    validation.get("error")
                    or validation.get("output")
                    or "validación falló"
                ),
            )

            return {
                "success": False,
                "changed": False,
                "error": "invalid config",
                "validation": validation,
            }

        changed = digest != self._last_digest

        # Solo la configuración (pool/interfaz/zonas) exige reinicio.
        # Las reservas van por dhcp-hostsfile y se recargan con SIGHUP.
        if not running:

            service_result = self._process.start()

        elif force or config_changed or self._last_config_digest is None:

            service_result = self._process.restart()

        elif reservations_changed:

            reloader = getattr(self._process, "reload", None)

            service_result = (
                reloader()
                if reloader is not None
                else {"success": False, "error": "reload no disponible"}
            )

            if not service_result.get("success"):

                service_result = self._process.restart()

        else:

            service_result = {"success": True, "pid": None, "message": "sin cambios"}

        if service_result.get("success"):

            self._start_failures = 0

            self._save_last_good()

        else:

            self._start_failures += 1

            if self._start_failures >= 2 and self._restore_last_good():

                logger.warning(
                    "DHCP: arranque falló %s veces; restaurando última configuración buena",
                    self._start_failures,
                )

                service_result = self._process.restart()

                if service_result.get("success"):

                    self._start_failures = 0

        if changed:

            self._state["restarts"] += 1

        self._last_digest = digest

        self._last_config_digest = config_digest

        self._last_reservations_digest = reservations_digest

        self._record(last_ok=bool(service_result.get("success")), last_error=None)

        logger.info(
            "DHCP reconciliado: %d reservas, %d libres, reinicio=%s",
            len(reservations or []),
            pool.get("free", -1),
            changed,
        )

        return {
            "success": bool(service_result.get("success")),
            "changed": True,
            "reservations": reservations_result,
            "config": config_result,
            "service": service_result,
            "pool": pool,
        }

    def _read(self, path: Path) -> str | None:

        try:

            return path.read_text(encoding="utf-8")

        except OSError:

            return None

    def _ensure_current_service(self) -> dict:
        """Arranca con los archivos actuales si la BD falla al construir."""

        status = self._process.status()

        if status.get("running"):

            return {"success": True, "running": True, "pid": status.get("pid"), "fallback": True}

        return self._process.start()

    def _save_last_good(self) -> None:
        config = self._read(self._config_path)

        reservations = self._read(self._reservations_path)

        if config is None or reservations is None:

            return

        try:

            self._write_atomic(self._last_good_config_path, config)

            self._write_atomic(self._last_good_reservations_path, reservations)

        except OSError as error:

            logger.warning("DHCP: no se pudo guardar última configuración buena: %s", error)

    def _restore_last_good(self) -> bool:
        config = self._read(self._last_good_config_path)

        reservations = self._read(self._last_good_reservations_path)

        if config is None or reservations is None:

            return False

        try:

            self._write_atomic(self._config_path, config)

            self._write_atomic(self._reservations_path, reservations)

            return True

        except OSError as error:

            logger.error("DHCP: no se pudo restaurar última configuración buena: %s", error)

            return False

    def _reclaim_if_needed(self, pool: dict | None = None) -> int:

        """Libera leases de equipos inactivos cuando el pool esta bajo."""

        if not pool or not pool.get("low"):

            return 0

        try:

            config = self._get_config_service().get_dhcp_config() or {}

            if not config.get("pool_reclaim_enabled", True):

                return 0

            # La reclamación solo corre cuando el pool cruzó el umbral.
            # En ese momento no se puede esperar 7 días: se liberan leases
            # de equipos que no están en ARP y no se vieron en la red en
            # los últimos `pool_emergency_reclaim_minutes` minutos.
            minutes = max(
                1,
                int(
                    config.get("pool_emergency_reclaim_minutes")
                    or 60
                ),
            )

            cutoff = utcnow() - timedelta(minutes=minutes)

        except Exception as error:

            logger.debug("DhcpReconciler: sin config de reclamacion: %s", error)

            return 0

        live_ips = set(read_arp_table())

        try:

            from backend.core.database.session import SessionLocal
            from backend.network.devices.models.network_device import (
                NetworkDevice,
            )

            db = SessionLocal()

            try:

                meta = {
                    (mac or "").lower(): {
                        "last_seen": last_seen,
                        "permanent": permanent or "",
                        "is_permanent": is_permanent,
                        "device_type": device_type,
                    }
                    for mac, last_seen, permanent, is_permanent, device_type in db.query(
                        NetworkDevice.mac_address,
                        NetworkDevice.last_seen,
                        NetworkDevice.permanent_ip,
                        NetworkDevice.is_permanent,
                        NetworkDevice.device_type,
                    ).all()
                }

                from backend.network.devices.services.device_classifier import (
                    DeviceClassifier,
                )

                for mac, value in meta.items():

                    value["protected"] = bool(
                        value.get("is_permanent")
                        or DeviceClassifier.is_infrastructure(
                            value.get("device_type")
                        )
                    )

            finally:

                db.close()

        except Exception as error:

            logger.warning("DhcpReconciler: sin datos de equipos: %s", error)

            return 0

        try:

            text = self._leases_path.read_text(encoding="utf-8", errors="replace")

        except OSError:

            return 0

        reclaimable = set(
            select_reclaimable(parse_leases(text), live_ips, meta, cutoff)
        )

        if not reclaimable:

            return 0

        keep = [
            line
            for line in text.splitlines()
            if not (len(line.split()) >= 3 and line.split()[2] in reclaimable)
        ]

        # dnsmasq mantiene los leases en memoria; editar el archivo con el
        # proceso vivo permite que los reescriba y se pierda la reclamación.
        was_running = bool(self._process.status().get("running"))

        if was_running:

            stopper = getattr(self._process, "stop", None)

            if stopper is not None:

                stopped = stopper()

                if not stopped.get("success", True):

                    logger.warning(
                        "DHCP: no se pudo detener dnsmasq para reclamar leases: %s",
                        stopped,
                    )

                    return 0

        self._write_atomic(self._leases_path, "\n".join(keep) + "\n")

        if was_running:

            started = self._process.start()

            if not started.get("success"):

                logger.error(
                    "DHCP: dnsmasq no arrancó después de reclamar leases: %s",
                    started,
                )

        self._state["reclaimed_last"] = len(reclaimable)

        self._state["reclaimed_total"] += len(reclaimable)

        logger.warning(
            "DHCP: pool bajo, liberadas %d IPs sin ARP "
            "(sin ver hace %d minutos)",
            len(reclaimable),
            minutes,
        )

        self._alert_notifier(
            "DHCP_POOL_RECLAIMED",
            "info",
            "DHCP: IPs liberadas por falta de espacio",
            (
                f"Se liberaron {len(reclaimable)} direcciones de equipos "
                f"sin ARP y sin actividad en los ultimos {minutes} minutos. "
                "Se conservan reservas y equipos presentes en la red."
            ),
        )

        return len(reclaimable)

    def _configured_threshold(self) -> int:

        try:

            from backend.shared.config.config_service import ConfigService

            return int(
                (ConfigService().get_dhcp_config() or {}).get(
                    "pool_low_threshold"
                )
                or 0
            )

        except Exception as error:
            logger.debug("reconciler._configured_threshold: %s", error)

            return 0

    def _pool_status(self, config, reservations, static_ips=()) -> dict:

        """Libres del pool + aviso si queda poco (para el panel)."""

        try:

            dhcp = {
                "pool_start": config.pool_start,
                "pool_end": config.pool_end,
                "netmask": config.netmask,
                "lease_time": config.lease_time,
                "excluded_ips": list(config.excluded_ips or []),
                "group_ip_start": config.group_ip_start,
                "group_ip_end": config.group_ip_end,
            }

            reserved = [
                item.get("ip")
                for item in reservations
                if item.get("ip")
            ]

            spec = build_pool_spec(dhcp, reserved)

            leases = read_leases(self._leases_path)

            stats = pool_stats(spec, leases, online_macs=set(), static_ips=static_ips)

            free = stats["free"]

            try:

                configured = int(self._threshold_provider() or 0)

            except Exception as error:
                logger.debug("reconciler._pool_status: %s", error)

                configured = 0

            threshold = (
                configured
                if configured > 0
                else max(
                    POOL_LOW_ABSOLUTE,
                    int(len(spec.dynamic) * POOL_LOW_RATIO),
                )
            )

            low = free < threshold

            if low:

                logger.warning(
                    "DHCP: quedan %d direcciones libres de %d dinámicas "
                    "(umbral %d). Ampliá el pool o liberá reservas.",
                    free,
                    len(spec.dynamic),
                    threshold,
                )

            return {
                "free": free,
                "threshold": threshold,
                "low": low,
                "static": stats.get("static", 0),
            }

        except Exception as error:

            logger.debug("DhcpReconciler: no pude calcular el pool: %s", error)

            return {}


_reconciler: DhcpReconciler | None = None


def get_dhcp_reconciler() -> DhcpReconciler:
    """Instancia única (el proceso es uno solo)."""

    global _reconciler

    if _reconciler is not None:

        return _reconciler

    from backend.core.config.paths import (
        DNSMASQ_CONFIG,
        RESERVATIONS_CONFIG,
    )
    from backend.core.dnsmasq.process_manager import dnsmasq_process_manager
    from backend.dhcp.providers.dnsmasq_reservation_provider import (
        DnsmasqReservationProvider,
    )
    from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider
    from backend.dhcp.services.dhcp_reservation_service import (
        DhcpReservationService,
    )
    from backend.dhcp.services.dhcp_pool_email_service import (
        DhcpPoolEmailService,
    )
    from backend.dhcp.services.dhcp_service import DhcpService

    dhcp_service = DhcpService()

    pool_email = DhcpPoolEmailService()

    _reconciler = DhcpReconciler(
        config_builder=dhcp_service.get_default_config,
        reservations_builder=DhcpReservationService().collect,
        provider=LinuxDhcpProvider(),
        reservation_provider=DnsmasqReservationProvider(),
        process_manager=dnsmasq_process_manager,
        config_path=DNSMASQ_CONFIG,
        reservations_path=RESERVATIONS_CONFIG,
        email_notifier=pool_email.notify,
    )

    return _reconciler
