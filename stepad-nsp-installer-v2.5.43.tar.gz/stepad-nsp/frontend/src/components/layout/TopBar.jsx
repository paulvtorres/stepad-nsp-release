import { useEffect, useRef, useState } from "react";

import { Link, useNavigate } from "react-router-dom";

import { useAuth } from "../../auth/useAuth";

import { getPendingInterfaceActions, getSystemVersion, getAlertsUnreadCount, getQuarantineCount } from "../../services/api";

import { formatClock } from "../../utils/datetime";


function userInitials(username) {

    const raw = (username || "?").trim();

    const parts = raw.split(/[\s._-]+/).filter(Boolean);

    if (parts.length >= 2) {

        return (parts[0][0] + parts[1][0]).toUpperCase();

    }

    return raw.slice(0, 2).toUpperCase();

}


function TopBar() {

    const navigate = useNavigate();

    const { user, logout } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [pendingInterfaces, setPendingInterfaces] = useState([]);

    const [version, setVersion] = useState(null);

    const [now, setNow] = useState(new Date());

    const [criticalAlerts, setCriticalAlerts] = useState(0);

    const [quarantinedCount, setQuarantinedCount] = useState(0);

    const [menuOpen, setMenuOpen] = useState(false);

    const menuRef = useRef(null);

    useEffect(() => {

        getSystemVersion()

            .then(setVersion)

            .catch(() => {});

    }, []);

    useEffect(() => {

        const t = setInterval(() => setNow(new Date()), 1000);

        return () => clearInterval(t);

    }, []);

    useEffect(() => {

        async function checkPending() {

            try {

                const pending = await getPendingInterfaceActions();

                setPendingInterfaces(pending || []);

            } catch (error) {

                console.error(error);

            }

        }

        checkPending();

        const interval = setInterval(checkPending, 30000);

        return () => clearInterval(interval);

    }, []);

    useEffect(() => {

        async function checkAlerts() {

            try {

                const data = await getAlertsUnreadCount();

                setCriticalAlerts(data?.critical || 0);

            } catch (error) {

                console.error(error);

            }

        }

        async function checkQuarantine() {

            try {

                const data = await getQuarantineCount();

                setQuarantinedCount(data?.count || 0);

            } catch (error) {

                console.error(error);

            }

        }

        checkAlerts();

        checkQuarantine();

        const interval = setInterval(() => {
            checkAlerts();
            checkQuarantine();
        }, 15000);

        return () => clearInterval(interval);

    }, []);

    useEffect(() => {

        function onPointerDown(event) {

            if (menuRef.current && !menuRef.current.contains(event.target)) {

                setMenuOpen(false);

            }

        }

        function onKeyDown(event) {

            if (event.key === "Escape") {

                setMenuOpen(false);

            }

        }

        document.addEventListener("mousedown", onPointerDown);

        document.addEventListener("keydown", onKeyDown);

        return () => {

            document.removeEventListener("mousedown", onPointerDown);

            document.removeEventListener("keydown", onKeyDown);

        };

    }, []);

    function goTo(path) {

        setMenuOpen(false);

        navigate(path);

    }


    return (

        <header className="topbar">

            <div className="topbar-left">

                <span className="topbar-live" title="Servicio activo">
                    <span className="topbar-live-dot" />
                    En línea
                </span>

                {
                    pendingInterfaces.length > 0 && (
                        <Link
                            to="/network/interfaces"
                            className="interface-alert-badge"
                            title="Hay tarjetas de red que necesitan tu atención"
                        >
                            {pendingInterfaces.length} interfaz
                            {pendingInterfaces.length === 1 ? "" : "s"}
                        </Link>
                    )
                }

            </div>

            <div className="topbar-right">

                <div
                    className="topbar-meta"
                    title={version?.version ? `Versión ${version.version}` : "Hora de Ecuador"}
                >
                    <time className="topbar-clock">{formatClock(now)}</time>
                    {
                        version?.version && (
                            <span className="topbar-version">{version.version}</span>
                        )
                    }
                </div>

                <button
                    type="button"
                    className={`alert-bell ${quarantinedCount > 0 ? "danger" : ""}`}
                    onClick={() => navigate("/quarantine")}
                    title={
                        quarantinedCount > 0
                            ? `${quarantinedCount} equipo(s) aislado(s)`
                            : "Equipos aislados"
                    }
                >
                    <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    >
                        <rect x="3" y="11" width="18" height="11" rx="2" />
                        <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                    </svg>
                    {
                        quarantinedCount > 0 && (
                            <span className="alert-bell-badge">
                                {quarantinedCount > 99 ? "99+" : quarantinedCount}
                            </span>
                        )
                    }
                </button>

                <button
                    type="button"
                    className={`alert-bell ${criticalAlerts > 0 ? "danger" : ""}`}
                    onClick={() => navigate("/alerts")}
                    title={
                        criticalAlerts > 0
                            ? `${criticalAlerts} alerta(s) crítica(s) sin atender`
                            : "Ver alertas"
                    }
                >
                    <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    >
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                        <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                    </svg>
                    {
                        criticalAlerts > 0 && (
                            <span className="alert-bell-badge">
                                {criticalAlerts > 99 ? "99+" : criticalAlerts}
                            </span>
                        )
                    }
                </button>

                {
                    user && (
                        <div className="topbar-user" ref={menuRef}>

                            <button
                                type="button"
                                className={`topbar-user-btn ${menuOpen ? "open" : ""}`}
                                onClick={() => setMenuOpen((open) => !open)}
                                aria-haspopup="menu"
                                aria-expanded={menuOpen}
                                title="Cuenta y sistema"
                            >
                                <span className="topbar-avatar">
                                    {userInitials(user.username)}
                                </span>
                                <span className="topbar-user-text">
                                    <span className="user-name">{user.username}</span>
                                    <span className="user-role-badge">
                                        {user.role === "ADMIN" ? "Admin" : "Operador"}
                                    </span>
                                </span>
                                <svg
                                    className="topbar-user-chevron"
                                    width="14"
                                    height="14"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2.4"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                >
                                    <polyline points="6 9 12 15 18 9" />
                                </svg>
                            </button>

                            {
                                menuOpen && (
                                    <div className="topbar-menu" role="menu">

                                        <div className="topbar-menu-head">
                                            <span className="topbar-menu-name">{user.username}</span>
                                            <span className="topbar-menu-role">
                                                {user.role === "ADMIN" ? "Administrador" : "Operador"}
                                            </span>
                                        </div>

                                        {
                                            isAdmin && (
                                                <button
                                                    type="button"
                                                    role="menuitem"
                                                    className="topbar-menu-item"
                                                    onClick={() => goTo("/system-control")}
                                                >
                                                    Reinicio y apagado
                                                </button>
                                            )
                                        }

                                        <div className="topbar-menu-sep" />

                                        <button
                                            type="button"
                                            role="menuitem"
                                            className="topbar-menu-item danger"
                                            onClick={logout}
                                        >
                                            Cerrar sesión
                                        </button>

                                    </div>
                                )
                            }

                        </div>
                    )
                }

            </div>

        </header>

    );

}


export default TopBar;
