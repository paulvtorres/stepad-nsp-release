import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getUsers,
    createUser,
    changeUserRole,
    changeUserStatus
} from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./users.css";


const ROLE_LABELS = {
    ADMIN: "Administrador",
    OPERATOR: "Operador"
};


const PASSWORD_POLICY = [
    { label: "Mínimo 8 caracteres", test: (v) => v.length >= 8 },
    { label: "Una letra mayúscula", test: (v) => /[A-Z]/.test(v) },
    { label: "Una letra minúscula", test: (v) => /[a-z]/.test(v) },
    { label: "Un número", test: (v) => /\d/.test(v) },
    { label: "Un carácter especial", test: (v) => /[^A-Za-z0-9]/.test(v) }
];


function Users() {

    const { user: currentUser } = useAuth();

    const [users, setUsers] = useState([]);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [showCreate, setShowCreate] = useState(false);

    const [createForm, setCreateForm] = useState({
        username: "",
        password: "",
        confirm: "",
        role: "OPERATOR"
    });

    const [createError, setCreateError] = useState(null);

    const [busy, setBusy] = useState(false);

    const [disableTarget, setDisableTarget] = useState(null);


    useEffect(() => {

        loadUsers();

    }, []);


    async function loadUsers() {

        setLoading(true);

        setError(null);

        try {

            const data = await getUsers();

            setUsers(data);

        } catch (err) {

            setError(err.message);

        } finally {

            setLoading(false);

        }

    }


    function isSelf(userId) {

        return currentUser && currentUser.id === userId;

    }


    function isAdmin() {

        return currentUser && currentUser.role === "ADMIN";

    }


    async function handleCreateUser() {

        const username = createForm.username.trim();

        const password = createForm.password;

        const confirm = createForm.confirm;

        setCreateError(null);

        if (!username) {

            setCreateError("Escribe un nombre de usuario.");

            return;

        }

        if (users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {

            setCreateError("Ya existe un usuario con ese nombre.");

            return;

        }

        if (password !== confirm) {

            setCreateError("Las contraseñas no coinciden.");

            return;

        }

        const failedRules = PASSWORD_POLICY.filter(
            (rule) => !rule.test(password)
        );

        if (failedRules.length) {

            setCreateError(
                "La contraseña debe cumplir: "
                + failedRules.map((rule) => rule.label).join(", ")
            );

            return;

        }

        setBusy(true);

        try {

            await createUser({
                username,
                password,
                role: createForm.role
            });

            setShowCreate(false);

            setCreateForm({
                username: "",
                password: "",
                confirm: "",
                role: "OPERATOR"
            });

            await loadUsers();

            setNotice(`Usuario "${username}" creado.`);

        } catch (err) {

            setCreateError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRoleChange(user, role) {

        try {

            await changeUserRole(user.id, role);

            await loadUsers();

            setNotice(`Rol de "${user.username}" actualizado a ${ROLE_LABELS[role] || role}.`);

        } catch (err) {

            setError(err.message);

        }

    }


    async function handleStatusChange(user, enabled) {

        setBusy(true);

        try {

            await changeUserStatus(user.id, enabled);

            setDisableTarget(null);

            await loadUsers();

            setNotice(
                enabled
                    ? `Usuario "${user.username}" reactivado.`
                    : `Usuario "${user.username}" desactivado.`
            );

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    if (!isAdmin()) {

        return (

            <div className="users-container">

                <h2>Usuarios</h2>

                <div className="users-no-permission">
                    Necesitas permisos de administrador para gestionar usuarios.
                </div>

            </div>

        );

    }


    const activeCount = users.filter((u) => u.enabled).length;


    return (

        <div className="users-container">

            <div className="users-header">

                <div>

                    <h2>Usuarios</h2>

                    <p>Cuentas con acceso al panel de administración.</p>

                </div>

                <button
                    className="primary-button"
                    onClick={() => setShowCreate(true)}
                >
                    + Nuevo usuario
                </button>

            </div>

            {
                error && (
                    <div className="users-error">
                        {error}
                    </div>
                )
            }

            {
                notice && (
                    <div className="users-notice">
                        {notice}
                    </div>
                )
            }

            <div className="users-summary">

                <div className="summary-item">
                    <span className="summary-label">Total de cuentas</span>
                    <span className="summary-value">{users.length}</span>
                </div>

                <div className="summary-divider" />

                <div className="summary-item">
                    <span className="summary-label">Activas</span>
                    <span className="summary-value active">{activeCount}</span>
                </div>

                <div className="summary-divider" />

                <div className="summary-item">
                    <span className="summary-label">Inactivas</span>
                    <span className="summary-value inactive">{users.length - activeCount}</span>
                </div>

            </div>

            <div className="table-card">

                <table className="users-table">

                    <thead>
                        <tr>
                            <th>Usuario</th>
                            <th>Rol</th>
                            <th>Estado</th>
                            <th>Último acceso</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>

                    <tbody>

                        {
                            loading && (
                                <tr>
                                    <td colSpan={5} className="users-empty">
                                        Cargando usuarios...
                                    </td>
                                </tr>
                            )
                        }

                        {
                            !loading && users.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="users-empty">
                                        No hay usuarios todavía.
                                    </td>
                                </tr>
                            )
                        }

                        {
                            users.map((u) => {

                                const self = isSelf(u.id);

                                return (

                                    <tr key={u.id} className={!u.enabled ? "row-disabled" : ""}>

                                        <td>
                                            <div className="user-name">
                                                {u.username}
                                                {self && <span className="self-tag">Tú</span>}
                                            </div>
                                        </td>

                                        <td>
                                            <div className="role-cell">
                                                <span className={`role-badge ${u.role.toLowerCase()}`}>
                                                    {ROLE_LABELS[u.role] || u.role}
                                                </span>

                                                <select
                                                    className="role-select"
                                                    value={u.role}
                                                    disabled={self}
                                                    onChange={(e) => handleRoleChange(u, e.target.value)}
                                                >
                                                    <option value="ADMIN">Administrador</option>
                                                    <option value="OPERATOR">Operador</option>
                                                </select>
                                            </div>
                                        </td>

                                        <td>
                                            <span className={`status-badge ${u.enabled ? "online" : "offline"}`}>
                                                <span className="status-dot" />
                                                {u.enabled ? "Activo" : "Inactivo"}
                                            </span>
                                        </td>

                                        <td className="last-login-cell">
                                            {u.last_login_at
                                                ? formatDateTime(u.last_login_at)
                                                : "Nunca"}
                                        </td>

                                        <td>
                                            {
                                                self ? (
                                                    <span className="self-note">
                                                        No puedes cambiar tu propia cuenta
                                                    </span>
                                                ) : (
                                                    <button
                                                        className={`status-toggle ${u.enabled ? "disable" : "enable"}`}
                                                        onClick={() => u.enabled ? setDisableTarget(u) : handleStatusChange(u, true)}
                                                        disabled={busy}
                                                    >
                                                        {u.enabled ? "Desactivar" : "Activar"}
                                                    </button>
                                                )
                                            }
                                        </td>

                                    </tr>

                                );

                            })
                        }

                    </tbody>

                </table>

            </div>

            {
                showCreate && (

                    <div className="confirm-overlay">

                        <div className="confirm-dialog user-create-dialog">

                            <h4>Nuevo usuario</h4>

                            <div className="user-form">

                                <label>
                                    Nombre de usuario
                                    <input
                                        type="text"
                                        value={createForm.username}
                                        onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                                        placeholder="ej. carlos"
                                        autoFocus
                                    />
                                </label>

                                <label>
                                    Contraseña
                                    <input
                                        type="password"
                                        value={createForm.password}
                                        onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })}
                                        placeholder="••••••••"
                                    />
                                </label>

                                {
                                    createForm.password && (
                                        <ul className="password-rules">
                                            {
                                                PASSWORD_POLICY.map((rule) => {
                                                    const ok = rule.test(createForm.password);
                                                    return (
                                                        <li
                                                            key={rule.label}
                                                            className={ok ? "rule-ok" : "rule-missing"}
                                                        >
                                                            {ok ? "✓" : "✗"} {rule.label}
                                                        </li>
                                                    );
                                                })
                                            }
                                        </ul>
                                    )
                                }

                                <label>
                                    Repetir contraseña
                                    <input
                                        type="password"
                                        value={createForm.confirm}
                                        onChange={(e) => setCreateForm({ ...createForm, confirm: e.target.value })}
                                        placeholder="••••••••"
                                    />
                                </label>

                                <label>
                                    Rol
                                    <select
                                        value={createForm.role}
                                        onChange={(e) => setCreateForm({ ...createForm, role: e.target.value })}
                                    >
                                        <option value="OPERATOR">Operador</option>
                                        <option value="ADMIN">Administrador</option>
                                    </select>
                                </label>

                            </div>

                            {
                                createError && (
                                    <div className="users-error">
                                        {createError}
                                    </div>
                                )
                            }

                            <div className="confirm-actions">

                                <button
                                    className="secondary-button"
                                    onClick={() => setShowCreate(false)}
                                    disabled={busy}
                                >
                                    Cancelar
                                </button>

                                <button
                                    className="primary-button"
                                    onClick={handleCreateUser}
                                    disabled={busy}
                                >
                                    {busy ? "Creando..." : "Crear usuario"}
                                </button>

                            </div>

                        </div>

                    </div>

                )
            }

            {
                disableTarget && (

                    <div className="confirm-overlay">

                        <div className="confirm-dialog">

                            <h4>Desactivar usuario</h4>

                            <p>
                                {disableTarget.username} perderá el acceso al panel de inmediato.
                                Puedes reactivarlo más tarde sin perder su configuración.
                            </p>

                            <div className="confirm-actions">

                                <button
                                    className="secondary-button"
                                    onClick={() => setDisableTarget(null)}
                                    disabled={busy}
                                >
                                    Cancelar
                                </button>

                                <button
                                    className="danger-button"
                                    onClick={() => handleStatusChange(disableTarget, false)}
                                    disabled={busy}
                                >
                                    {busy ? "Desactivando..." : "Sí, desactivar"}
                                </button>

                            </div>

                        </div>

                    </div>

                )
            }

        </div>

    );

}


export default Users;
