import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import { useAuth } from "../../auth/useAuth";

import {
    getQuarantinedDevices,
    releaseQuarantine,
    getQuarantineEmailSettings,
    saveQuarantineEmailSettings,
} from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./quarantine.css";


function Quarantine() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [devices, setDevices] = useState([]);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [releasingId, setReleasingId] = useState(null);

    const [emailForm, setEmailForm] = useState({
        quarantine_email_enabled: true,
        quarantine_emails: "",
        quarantine_cc_emails: "",
        quarantine_bcc_emails: "",
    });

    const [emailStatus, setEmailStatus] = useState({
        email_config_ready: false,
        email_account: "",
        config_ready: false,
        config_issues: [],
    });

    const [savingEmail, setSavingEmail] = useState(false);


    async function reloadDevices() {

        const data = await getQuarantinedDevices();

        setDevices(data.devices || []);

        return data;

    }


    async function reloadEmail() {

        const data = await getQuarantineEmailSettings();

        setEmailForm({
            quarantine_email_enabled: data.quarantine_email_enabled ?? true,
            quarantine_emails: data.quarantine_emails || "",
            quarantine_cc_emails: data.quarantine_cc_emails || "",
            quarantine_bcc_emails: data.quarantine_bcc_emails || "",
        });

        setEmailStatus({
            email_config_ready: Boolean(data.email_config_ready),
            email_account: data.email_account || "",
            config_ready: Boolean(data.config_ready),
            config_issues: data.config_issues || [],
        });

        return data;

    }


    useEffect(() => {

        let cancelled = false;

        Promise.all([getQuarantinedDevices(), getQuarantineEmailSettings()])

            .then(([list, email]) => {

                if (cancelled) return;

                setDevices(list.devices || []);

                setEmailForm({
                    quarantine_email_enabled: email.quarantine_email_enabled ?? true,
                    quarantine_emails: email.quarantine_emails || "",
                    quarantine_cc_emails: email.quarantine_cc_emails || "",
                    quarantine_bcc_emails: email.quarantine_bcc_emails || "",
                });

                setEmailStatus({
                    email_config_ready: Boolean(email.email_config_ready),
                    email_account: email.email_account || "",
                    config_ready: Boolean(email.config_ready),
                    config_issues: email.config_issues || [],
                });

            })

            .catch((err) => {

                if (!cancelled) setError(err.message);

            })

            .finally(() => {

                if (!cancelled) setLoading(false);

            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleRelease(device) {

        if (!isAdmin) return;

        const label = device.name || device.hostname || device.ip_address;

        if (!window.confirm(
            `¿Desaislar a ${label}?\n\n`
            + "Solo hágalo si el equipo ya fue revisado "
            + "(antivirus / malware)."
        )) {

            return;

        }

        setError(null);

        setNotice(null);

        setReleasingId(device.id);

        try {

            const result = await releaseQuarantine(device.id);

            if (result.success === false) {

                setError(result.message || "No se pudo desaislar.");

                return;

            }

            await reloadDevices();

            setNotice(result.message || "Equipo desaislado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setReleasingId(null);

        }

    }


    async function handleSaveEmail() {

        if (!isAdmin) return;

        setError(null);

        setNotice(null);

        setSavingEmail(true);

        try {

            const saved = await saveQuarantineEmailSettings(emailForm);

            setEmailForm({
                quarantine_email_enabled: saved.quarantine_email_enabled ?? true,
                quarantine_emails: saved.quarantine_emails || "",
                quarantine_cc_emails: saved.quarantine_cc_emails || "",
                quarantine_bcc_emails: saved.quarantine_bcc_emails || "",
            });

            setEmailStatus({
                email_config_ready: Boolean(saved.email_config_ready),
                email_account: saved.email_account || "",
                config_ready: Boolean(saved.config_ready),
                config_issues: saved.config_issues || [],
            });

            setNotice("Correo de aislamiento guardado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setSavingEmail(false);

        }

    }


    return (

        <div className="quarantine-page">

            <div className="quarantine-header">

                <div>

                    <h2>Equipos aislados</h2>

                    <p>
                        Equipos cortados de la red por cuarentena automática
                        del IPS. Aquí se ven aparte de las alertas generales
                        para no perderlos.
                    </p>

                </div>

                <div className={`quarantine-count-badge ${devices.length ? "danger" : "ok"}`}>
                    <strong>{devices.length}</strong>
                    <span>
                        {devices.length === 1 ? "aislado" : "aislados"}
                    </span>
                </div>

            </div>


            {error && (
                <div className="quarantine-error">{error}</div>
            )}

            {notice && (
                <div className="quarantine-ok">{notice}</div>
            )}


            <section className="quarantine-card">

                <h3>Aislados ahora</h3>

                {
                    loading ? (
                        <p className="quarantine-muted">Cargando…</p>
                    ) : devices.length === 0 ? (
                        <p className="quarantine-empty">
                            Ningún equipo aislado en este momento.
                        </p>
                    ) : (
                        <ul className="quarantine-list">
                            {
                                devices.map((device) => (
                                    <li key={device.id} className="quarantine-item">
                                        <div className="quarantine-item-main">
                                            <strong>{device.name}</strong>
                                            <div className="quarantine-item-meta">
                                                <span>{device.ip_address || "sin IP"}</span>
                                                <span>{device.mac_address || "sin MAC"}</span>
                                                <span>
                                                    {device.quarantined_at
                                                        ? formatDateTime(device.quarantined_at)
                                                        : "—"}
                                                </span>
                                            </div>
                                            {
                                                device.signature && (
                                                    <div className="quarantine-item-reason">
                                                        {device.signature}
                                                        {device.dst_ip ? ` → ${device.dst_ip}` : ""}
                                                    </div>
                                                )
                                            }
                                        </div>
                                        <div className="quarantine-item-actions">
                                            {
                                                device.id && (
                                                    <Link
                                                        className="quarantine-link"
                                                        to={`/network/devices/${device.id}`}
                                                    >
                                                        Ver equipo
                                                    </Link>
                                                )
                                            }
                                            <button
                                                type="button"
                                                className="quarantine-release"
                                                disabled={!isAdmin || releasingId === device.id}
                                                onClick={() => handleRelease(device)}
                                            >
                                                {releasingId === device.id
                                                    ? "Desaislando…"
                                                    : "Desaislar"}
                                            </button>
                                        </div>
                                    </li>
                                ))
                            }
                        </ul>
                    )
                }

            </section>


            <section className="quarantine-card">

                <h3>Correo al aislar un equipo</h3>

                <p className="quarantine-lead">
                    Aviso inmediato cuando el IPS aísla una máquina.
                    Independiente del reporte de navegación y de las
                    alertas generales. Configure la cuenta SMTP en{" "}
                    <Link to="/settings">Ajustes → Correo</Link>.
                </p>

                {
                    !emailStatus.email_config_ready && (
                        <div className="quarantine-warn">
                            Configure primero <strong>Ajustes → Correo</strong>.
                        </div>
                    )
                }

                <div className="quarantine-email-grid">

                    <label className={`quarantine-toggle ${emailForm.quarantine_email_enabled ? "on" : ""}`}>
                        <input
                            type="checkbox"
                            checked={emailForm.quarantine_email_enabled}
                            disabled={!isAdmin || savingEmail}
                            onChange={(e) =>
                                setEmailForm({
                                    ...emailForm,
                                    quarantine_email_enabled: e.target.checked,
                                })
                            }
                        />
                        <span>
                            {emailForm.quarantine_email_enabled ? "Activo" : "Inactivo"}
                        </span>
                    </label>

                    <label className="quarantine-wide">
                        Para
                        <input
                            type="text"
                            value={emailForm.quarantine_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setEmailForm({
                                    ...emailForm,
                                    quarantine_emails: e.target.value,
                                })
                            }
                            placeholder="ti@empresa.com, noc@empresa.com"
                        />
                    </label>

                    <label>
                        CC
                        <input
                            type="text"
                            value={emailForm.quarantine_cc_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setEmailForm({
                                    ...emailForm,
                                    quarantine_cc_emails: e.target.value,
                                })
                            }
                            placeholder="gerencia@empresa.com"
                        />
                    </label>

                    <label>
                        CCO
                        <input
                            type="text"
                            value={emailForm.quarantine_bcc_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setEmailForm({
                                    ...emailForm,
                                    quarantine_bcc_emails: e.target.value,
                                })
                            }
                            placeholder="auditoria@empresa.com"
                        />
                    </label>

                </div>

                <div className="quarantine-actions">

                    <button
                        type="button"
                        className="quarantine-save"
                        disabled={!isAdmin || savingEmail}
                        onClick={handleSaveEmail}
                    >
                        {savingEmail ? "Guardando…" : "Guardar correo de aislamiento"}
                    </button>

                    {
                        emailStatus.config_issues?.length > 0 && (
                            <span className="quarantine-muted">
                                Pendiente: {emailStatus.config_issues.join(", ")}
                            </span>
                        )
                    }

                </div>

                {!isAdmin && (
                    <p className="quarantine-muted">
                        Solo administradores pueden desaislar o cambiar el correo.
                    </p>
                )}

            </section>

        </div>

    );

}


export default Quarantine;
