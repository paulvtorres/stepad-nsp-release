import { useEffect, useState } from "react";

import { getWanProbes } from "../../../services/api";

import { formatDateTime } from "../../../utils/datetime";


function WanProbeLog() {

    const [data, setData] = useState(null);

    const [error, setError] = useState(null);

    const [hours, setHours] = useState(24);


    async function load(h = hours) {

        try {

            const result = await getWanProbes(h, 100);

            setData(result);

            setError(null);

        } catch (err) {

            setError(err.message);

        }

    }


    useEffect(() => {

        load(hours);

        const timer = setInterval(() => load(hours), 30000);

        return () => clearInterval(timer);

    }, [hours]);


    const events = data?.events || [];


    return (

        <div className="domain-rules">

            <h3>Intentos desde Internet (WAN)</h3>

            <p className="security-description" style={{ marginTop: 0 }}>
                Muestra de conexiones nuevas bloqueadas o vistas en el borde
                WAN (deny-all). El registro está limitado a ~5 eventos/segundo
                para no saturar disco ni CPU si hay un barrido o flood: el
                ataque sigue bloqueado; solo se guarda una muestra.
            </p>

            {
                error && (
                    <div className="maintenance-error" style={{ marginBottom: 12 }}>
                        {error}
                    </div>
                )
            }

            {
                data?.warning && (
                    <p className="hardening-meta" style={{ marginBottom: 12 }}>
                        {data.warning}
                    </p>
                )
            }

            <div className="hardening-row" style={{ marginBottom: 12 }}>

                <div className="hardening-info">

                    <strong>
                        Últimas {data?.hours ?? hours}h — {data?.count ?? 0} orígenes,
                        {" "}{data?.total_hits ?? 0} hits agregados
                    </strong>

                    <div className="hardening-meta">
                        Límite de log: {data?.log_rate_limit || "5/second"} ·
                        retención {data?.retention_days ?? 30} días
                    </div>

                </div>

                <label className="hardening-meta">
                    Ventana{" "}
                    <select
                        value={hours}
                        onChange={(e) => setHours(Number(e.target.value))}
                    >
                        <option value={6}>6 h</option>
                        <option value={24}>24 h</option>
                        <option value={72}>3 días</option>
                        <option value={168}>7 días</option>
                    </select>
                </label>

            </div>

            {
                events.length === 0 ? (
                    <p className="hardening-meta">
                        Sin intentos registrados en esta ventana (o deny-all
                        aún no aplicado / sin tráfico WAN nuevo).
                    </p>
                ) : (
                    <div className="table-card">
                        <table className="devices-table">
                            <thead>
                                <tr>
                                    <th>Origen</th>
                                    <th>Puerto</th>
                                    <th>Proto</th>
                                    <th>Objetivo</th>
                                    <th>Hits</th>
                                    <th>Último</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    events.map((ev) => (
                                        <tr key={ev.id}>
                                            <td>{ev.src_ip}</td>
                                            <td>{ev.dst_port ?? "—"}</td>
                                            <td>{ev.protocol}</td>
                                            <td>{ev.target}</td>
                                            <td>{ev.hit_count}</td>
                                            <td>{formatDateTime(ev.last_seen)}</td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>
                    </div>
                )
            }

        </div>

    );

}


export default WanProbeLog;
