import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getEncryptedDnsStatus,
    enableEncryptedDnsBlocking,
    disableEncryptedDnsBlocking,
    enableServiceBlockBlocking,
    disableServiceBlockBlocking,
    refreshEncryptedDnsBlocklist,
    getSecurityRules
} from "../../../services/api";

import { formatDateTime } from "../../../utils/datetime";

import "../security.css";


function EncryptedDnsSecurity() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [loading, setLoading] = useState(true);

    const [working, setWorking] = useState(false);

    const [serviceWorking, setServiceWorking] = useState(false);

    const [persistDns, setPersistDns] = useState(false);

    const [activeDomainRules, setActiveDomainRules] = useState(0);



    useEffect(() => {

        loadStatus();

        loadDomainRules();

    }, []);




    async function loadStatus() {

        try {

            const response = await getEncryptedDnsStatus();

            setStatus(response);

            setPersistDns(Boolean(response?.enabled_persist));

        }
        catch (error) {

            console.error(
                "Error loading encrypted DNS status",
                error
            );

        }
        finally {

            setLoading(false);

        }

    }




    async function loadDomainRules() {

        try {

            const rules = await getSecurityRules();

            setActiveDomainRules(

                (rules || []).filter(rule => rule.enabled).length

            );

        }
        catch (error) {

            console.error(error);

        }

    }




    async function toggle() {

        setWorking(true);

        try {

            const response = status?.enabled
                ? await disableEncryptedDnsBlocking()
                : await enableEncryptedDnsBlocking(persistDns);

            setStatus(response);

        }
        catch (error) {

            console.error(
                "Error toggling encrypted DNS blocking",
                error
            );

        }
        finally {

            setWorking(false);

        }

    }




    async function handleServiceChange(checked) {

        setServiceWorking(true);

        try {

            const response = checked
                ? await enableServiceBlockBlocking(true)
                : await disableServiceBlockBlocking();

            setStatus(response);

        }
        catch (error) {

            console.error(
                "Error toggling service block",
                error
            );

        }
        finally {

            setServiceWorking(false);

        }

    }




    async function refreshBlocklist() {

        setWorking(true);

        try {

            await refreshEncryptedDnsBlocklist();

            await loadStatus();

        }
        catch (error) {

            console.error(
                "Error refreshing DoH blocklist",
                error
            );

        }
        finally {

            setWorking(false);

        }

    }




    if (loading) {

        return (

            <div className="encrypted-dns">

                <p className="loading-message">
                    Cargando estado de protección...
                </p>

            </div>

        );

    }


    const bypassOpen = activeDomainRules > 0 && !status?.enabled;


    return (

        <div className="encrypted-dns">

            <div className="encrypted-dns-header">

                <h3>
                    Bloqueo DoT/DoH
                </h3>


                <div>

                    {
                        isAdmin && (
                            <button
                                className={
                                    `encrypted-dns-toggle ${status?.enabled ? "on" : "off"}`
                                }
                                onClick={toggle}
                                disabled={working}
                            >

                                {
                                    status?.enabled
                                        ? "Desactivar bloqueo"
                                        : "Activar bloqueo"
                                }

                            </button>
                        )
                    }


                    {
                        isAdmin && (
                            <button
                                className="encrypted-dns-refresh"
                                onClick={refreshBlocklist}
                                disabled={working}
                            >

                                Actualizar lista

                            </button>
                        )
                    }


                    {
                        isAdmin && (
                            <label
                                className="checkbox-label"
                                style={{ marginLeft: 8, display: "inline-flex", alignItems: "center" }}
                            >
                                <input
                                    type="checkbox"
                                    checked={persistDns}
                                    onChange={(e) => setPersistDns(e.target.checked)}
                                />
                                Siempre activo tras reinicio
                            </label>
                        )
                    }

                </div>

            </div>


            <p className="security-description" style={{ marginTop: 0 }}>

                Bloquea DNS-over-TLS (puerto 853) y DNS-over-HTTPS hacia
                resolutores públicos conocidos, y redirige cualquier DNS
                en texto plano hacia el resolver de STEPAD — así los
                dispositivos no pueden evadir el bloqueo de dominios
                configurando un DNS cifrado externo.

            </p>


            {
                status && (

                    <p className="encrypted-dns-meta">

                        {status.blocklist_ips} IPs en la lista de resolutores &middot;
                        {" "}WAN: {status.wan_interface || "no detectada"} &middot;{" "}
                        Última actualización: {
                            status.last_refreshed
                                ? formatDateTime(status.last_refreshed)
                                : "nunca"
                        }

                    </p>

                )
            }


            {
                status?.message && (

                    <p className="encrypted-dns-warning">

                        {status.message}

                    </p>

                )
            }


            {
                !status?.wan_interface && (

                    <p className="encrypted-dns-warning">

                        No se detectó una interfaz WAN — configura las
                        interfaces de red antes de activar el bloqueo.

                    </p>

                )
            }


            {
                bypassOpen && (

                    <div className="layer-warning">

                        <strong>Atención:</strong> tienes {activeDomainRules}{" "}
                        dominios bloqueados, pero el bloqueo DoT/DoH está
                        apagado. Cualquier dispositivo puede evadir el
                        bloqueo de dominios usando un DNS cifrado externo.
                        Actívalo para cerrar esta vía.

                    </div>

                )
            }


            <div className="service-block">

                <div className="service-block-header">

                    <h4>Bloqueo por IP de servicios</h4>


                    <span className={`protection-badge ${status?.service_block_enabled ? "ok" : "off"}`}>

                        {status?.service_block_enabled ? "ACTIVO" : "INACTIVO"}

                    </span>

                </div>


                <p className="service-block-description">

                    Bloquea Facebook, Instagram y WhatsApp para toda la red
                    impidiendo las conexiones hacia sus redes directamente
                    por IP — funciona aunque un dispositivo tenga las
                    direcciones guardadas en caché y no consulte el DNS.

                </p>


                <p className="encrypted-dns-meta">

                    {
                        status
                            ? `${status.service_ipv4_ranges} rangos IPv4 · ${status.service_ipv6_ranges} rangos IPv6 (Meta/Facebook)`
                            : "Rangos no disponibles"
                    }

                </p>


                {
                    isAdmin && (
                        <label
                            className="checkbox-label"
                            style={{ display: "inline-flex", alignItems: "center", marginTop: 8, cursor: "pointer" }}
                        >
                            <input
                                type="checkbox"
                                checked={Boolean(status?.service_block_enabled)}
                                disabled={serviceWorking}
                                onChange={(e) => handleServiceChange(e.target.checked)}
                            />
                            Activo — si marcas el visto queda bloqueado siempre (aunque reinicies); si lo quitas, se desactiva y no vuelve a activarse solo.
                        </label>
                    )
                }

            </div>


        </div>

    );


}


export default EncryptedDnsSecurity;
