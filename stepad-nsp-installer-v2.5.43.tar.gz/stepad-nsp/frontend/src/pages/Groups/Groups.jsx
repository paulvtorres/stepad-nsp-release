import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getGroups,
    createGroup,
    updateGroup,
    deleteGroup,
    getGroupDevices,
    addGroupDevice,
    removeGroupDevice,
    getGroupRules,
    addGroupRule,
    deleteGroupRule,
    getGroupCategories,
    setGroupCategories,
    getContentCategories,
    getDevices
} from "../../services/api";

import "./groups.css";


function Groups() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [groups, setGroups] = useState(null);

    const [devices, setDevices] = useState([]);

    const [expanded, setExpanded] = useState(null);

    const [detail, setDetail] = useState(null);

    const [rules, setRules] = useState([]);

    const [allCategories, setAllCategories] = useState([]);

    const [groupCats, setGroupCats] = useState([]);

    const [showCreate, setShowCreate] = useState(false);

    const [form, setForm] = useState({ name: "", description: "" });

    const [ruleForm, setRuleForm] = useState({ action: "BLOCK", domain: "" });

    const [ruleBusy, setRuleBusy] = useState(false);

    const [addDeviceId, setAddDeviceId] = useState("");

    const [selGroupDevice, setSelGroupDevice] = useState(null);

    const [selFreeDevice, setSelFreeDevice] = useState(null);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [showRules, setShowRules] = useState(false);

    const [busy, setBusy] = useState(false);


    function load() {

        getGroups()

            .then(setGroups)

            .catch((err) => setError(err.message));

    }

    function refreshGroups() {

        getGroups()

            .then(setGroups)

            .catch(() => {});

    }


    function bumpGroupCounters(groupId, deltaDevices = 0, deltaRules = 0) {

        setGroups((prev) =>
            (prev || []).map((g) =>
                g.id === groupId
                    ? {
                          ...g,
                          devices: Math.max(0, (g.devices || 0) + deltaDevices),
                          rules: Math.max(0, (g.rules || 0) + deltaRules),
                      }
                    : g
            )
        );

    }


    useEffect(() => {

        load();

        getDevices()

            .then(setDevices)

            .catch(() => {});

        getContentCategories()

            .then((cats) => setAllCategories(cats || []))

            .catch(() => {});

    }, []);


    async function openGroup(group) {

        // Toggle: si ya está expandido, se contrae.
        if (expanded === group.id) {

            setExpanded(null);

            return;

        }

        setExpanded(group.id);

        setBusy(false);

        setDetail(null);

        setRules([]);

        setAddDeviceId("");

        try {

            const [devData, ruleData, catData] = await Promise.all([
                getGroupDevices(group.id),
                getGroupRules(group.id),
                getGroupCategories(group.id)
            ]);

            setDetail(devData || []);

            setRules(ruleData || []);

            setGroupCats((catData || []).map((c) => c.key));

        } catch (err) {

            setError(err.message);

        }

    }


    async function toggleGroupCategory(key) {

        const next = groupCats.includes(key)
            ? groupCats.filter((k) => k !== key)
            : [...groupCats, key];

        setGroupCats(next);

        setBusy(true);

        try {

            await setGroupCategories(expanded, next);

            const data = await getGroups();

            setGroups(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleCreate() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await createGroup({
                name: form.name,
                description: form.description || null
            });

            setForm({ name: "", description: "" });

            setShowCreate(false);

            load();

            setNotice("Grupo creado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSetDefault(group) {

        setBusy(true);

        try {

            await updateGroup(group.id, { is_default: true });

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleBandwidth(group, value) {

        const mbps = value.trim();

        const kbps = mbps === "" ? null : (Number(mbps) * 1000);

        if (kbps !== null && (!Number.isFinite(kbps) || kbps <= 0)) {

            setError("Ingresa un valor válido en Mbps");

            load();

            return;

        }

        setBusy(true);

        try {

            await updateGroup(group.id, { bandwidth_limit_kbps: kbps });

            load();

        } catch (err) {

            setError(err.message);

            load();

        } finally {

            setBusy(false);

        }

    }


    async function handleDelete(group) {

        const ok = window.confirm(`¿Eliminar el grupo "${group.name}"?`);

        if (!ok) return;

        setBusy(true);

        try {

            await deleteGroup(group.id);

            if (expanded === group.id) setExpanded(null);

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleAddDevice(groupId, deviceId) {

        const did = deviceId ?? Number(addDeviceId);

        if (!did) return;

        const grp = groups && groups.find((g) => g.id === groupId);

        // Actualizacion optimista: el equipo pasa al grupo al instante.
        setDevices((prev) =>
            prev.map((d) =>
                d.id === did ? { ...d, groups: [{ id: groupId, name: grp?.name || "Grupo" }] } : d
            )
        );

        setDetail((prev) => {
            const dev = (devices || []).find((d) => d.id === did);
            if (!dev) return prev;
            const exists = (prev || []).some((x) => x.id === did);
            if (exists) return prev;
            return [dev, ...(prev || [])];
        });

        setAddDeviceId("");

        setSelFreeDevice(null);

        setSelGroupDevice(null);

        // Actualizacion optimista de contadores del encabezado.
        bumpGroupCounters(groupId, +1);

        setBusy(true);

        try {

            await addGroupDevice(groupId, Number(did));

            const devData = await getGroupDevices(groupId);

            setDetail(devData || []);

            getDevices()

                .then(setDevices)

                .catch(() => {});

            refreshGroups();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRemoveDevice(groupId, deviceId) {

        const defGrp = groups && groups.find((g) => g.is_default);

        // Actualizacion optimista: el equipo sale del grupo al instante
        // y pasa al grupo por defecto.
        setDetail((prev) => (prev || []).filter((d) => d.id !== deviceId));

        if (defGrp) {

            setDevices((prev) =>
                prev.map((d) =>
                    d.id === deviceId
                        ? { ...d, groups: [{ id: defGrp.id, name: defGrp.name || "Grupo" }] }
                        : d
                )
            );

        }

        setSelFreeDevice(null);

        setSelGroupDevice(null);

        // Actualizacion optimista de contadores del encabezado: el
        // equipo sale de este grupo y pasa al grupo por defecto.
        bumpGroupCounters(groupId, -1);

        if (defGrp) {

            bumpGroupCounters(defGrp.id, +1);

        }

        setBusy(true);

        try {

            await removeGroupDevice(groupId, deviceId);

            const devData = await getGroupDevices(groupId);

            setDetail(devData || []);

            getDevices()

                .then(setDevices)

                .catch(() => {});

            refreshGroups();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleAddRule(groupId) {

        if (!ruleForm.domain.trim()) return;

        const action = ruleForm.action;

        const domain = ruleForm.domain.trim();

        // Optimista: la regla aparece al instante (luego se refresca
        // con la respuesta real del backend).
        setRules((prev) => [
            { id: Date.now(), group_id: groupId, action, domain },
            ...(prev || []),
        ]);

        // Actualizacion optimista del contador de reglas.
        bumpGroupCounters(groupId, 0, +1);

        setRuleForm({ action: "BLOCK", domain: "" });

        setRuleBusy(true);

        try {

            await addGroupRule(
                groupId,
                action,
                domain
            );

            const ruleData = await getGroupRules(groupId);

            setRules(ruleData || []);

            refreshGroups();

        } catch (err) {

            setError(err.message);

        } finally {

            setRuleBusy(false);

        }

    }


    async function handleRemoveRule(ruleId) {

        // Optimista: quita la regla al instante.
        setRules((prev) => (prev || []).filter((r) => r.id !== ruleId));

        // Actualizacion optimista del contador de reglas.
        if (expanded) {

            bumpGroupCounters(expanded, 0, -1);

        }

        setBusy(true);

        try {

            await deleteGroupRule(ruleId);

            if (expanded) {

                const ruleData = await getGroupRules(expanded);

                setRules(ruleData || []);

            }

            refreshGroups();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const inGroup = (deviceId) =>
        detail && detail.some((d) => d.id === deviceId);


    return (

        <div className="groups-container">

            <div className="logs-header">

                <h2>Grupos (departamentos)</h2>

                <p>

                    Equipos nuevos van a <strong>Invitados</strong> (solo
                    bloqueos generales: porno, apuestas, juegos). Cree
                    grupos como Contabilidad y asigne equipos desde
                    Invitados para aplicar reglas extra (ej. bloquear YouTube).
                    Para cambiar de grupo: quite el equipo con «&gt;&gt;»
                    hacia Invitados y asignelo en el grupo destino con «&lt;&lt;».

                </p>

            </div>

            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}

            {
                isAdmin && (
                    <button
                        className="primary-button"
                        onClick={() => setShowCreate(!showCreate)}
                        disabled={groups === null}
                    >
                        {showCreate ? "Cancelar" : "+ Nuevo grupo"}
                    </button>
                )
            }

            {
                showCreate && isAdmin && (
                    <div className="group-create">

                        <input
                            type="text"
                            placeholder="Nombre (ej. Contabilidad)"
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                        />

                        <input
                            type="text"
                            placeholder="Descripción (opcional)"
                            value={form.description}
                            onChange={(e) => setForm({ ...form, description: e.target.value })}
                        />

                        <button
                            className="primary-button"
                            onClick={handleCreate}
                            disabled={busy || !form.name}
                        >
                            Crear
                        </button>

                    </div>
                )
            }

            {
                groups === null ? (
                    <p className="vpn-empty">Cargando grupos...</p>
                ) : (
            <div className="group-list">

                {
                    groups.map((group) => (
                        <div key={group.id} className={`group-card ${expanded === group.id ? "open" : ""}`}>

                            <div className="group-head" onClick={() => openGroup(group)}>

                                <div className="group-info">

                                    <span className="group-name">
                                        {group.name}
                                        {group.is_default && (
                                            <span className="group-default-tag">por defecto</span>
                                        )}
                                    </span>

                                    <span className="group-meta">
                                        {group.description || "Sin descripción"}
                                        {group.dns_alias_ip ? (
                                            <> · DNS {group.dns_alias_ip}</>
                                        ) : null}
                                    </span>

                                    <span className="group-badges">
                                        <span className="group-badge devices" title="Equipos en este grupo">
                                            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <rect x="2" y="3" width="20" height="14" rx="2" />
                                                <line x1="8" y1="21" x2="16" y2="21" />
                                                <line x1="12" y1="17" x2="12" y2="21" />
                                            </svg>
                                            {group.devices} {group.devices === 1 ? "equipo" : "equipos"}
                                        </span>
                                        <span className="group-badge rules" title="Reglas de bloqueo/permiso">
                                            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <circle cx="12" cy="12" r="10" />
                                                <line x1="4.9" y1="4.9" x2="19.1" y2="19.1" />
                                            </svg>
                                            {group.rules} {group.rules === 1 ? "regla" : "reglas"}
                                        </span>
                                    </span>

                                    {
                                        isAdmin && (
                                            <label
                                                className="group-bandwidth"
                                                onClick={(e) => e.stopPropagation()}
                                            >
                                                Ancho de banda:
                                                <input
                                                    type="number"
                                                    min="1"
                                                    defaultValue={
                                                        group.bandwidth_limit_kbps
                                                            ? (group.bandwidth_limit_kbps / 1000)
                                                            : ""
                                                    }
                                                    placeholder="Mbps"
                                                    onBlur={(e) =>
                                                        handleBandwidth(group, e.target.value)
                                                    }
                                                    onKeyDown={(e) => {
                                                        if (e.key === "Enter") {
                                                            handleBandwidth(group, e.target.value);
                                                        }
                                                    }}
                                                />
                                                Mbps
                                            </label>
                                        )
                                    }

                                </div>

                                <div className="group-actions">

                                    {
                                        isAdmin && !group.is_default && (
                                            <button
                                                className="secondary-button small"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleSetDefault(group);
                                                }}
                                            >
                                                Hacer default
                                            </button>
                                        )
                                    }

                                    {
                                        isAdmin && !group.is_default && (
                                            <button
                                                className="danger-button small"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleDelete(group);
                                                }}
                                                disabled={busy}
                                            >
                                                Eliminar
                                            </button>
                                        )
                                    }

                                    <button
                                        type="button"
                                        className="group-toggle-btn"
                                        title={expanded === group.id ? "Ocultar detalles" : "Ver detalles"}
                                        aria-label={expanded === group.id ? "Ocultar detalles" : "Ver detalles"}
                                        aria-expanded={expanded === group.id}
                                    >
                                        <svg
                                            className="group-toggle-icon"
                                            viewBox="0 0 24 24"
                                            width="16"
                                            height="16"
                                            fill="none"
                                            stroke="currentColor"
                                            strokeWidth="2.5"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        >
                                            <polyline points="6 9 12 15 18 9" />
                                        </svg>
                                    </button>

                                </div>

                            </div>

                            {
                                expanded === group.id && (
                                    <div className="group-detail">

                                        <div className="group-device-panels">

                                            <div className="group-device-panel">

                                                <h5>Equipos del grupo</h5>

                                                <div className="group-devices">

                                                    {
                                                        !detail || detail.length === 0 ? (
                                                            <p className="vpn-empty">Sin equipos asignados.</p>
                                                        ) : (
                                                            detail.map((device) => (
                                                                <div
                                                                    key={device.id}
                                                                    className={`group-device-row ${selGroupDevice && selGroupDevice.id === device.id ? "selected" : ""}`}
                                                                    onClick={() => setSelGroupDevice(device)}
                                                                    title="Seleccionar para quitar (>>)"
                                                                >
                                                                    <span className="group-device-name">
                                                                        {device.hostname || device.ip_address || device.mac_address}
                                                                    </span>
                                                                </div>
                                                            ))
                                                        )
                                                    }

                                                </div>

                                            </div>

                                            {
                                                isAdmin && !group.is_default && (
                                                    <div className="group-device-move">

                                                        <button
                                                            className={`move-btn ${selGroupDevice ? "active" : ""}`}
                                                            onClick={() => {
                                                                if (!selGroupDevice) return;
                                                                const d = selGroupDevice;
                                                                setSelGroupDevice(null);
                                                                handleRemoveDevice(group.id, d.id);
                                                            }}
                                                            disabled={!selGroupDevice}
                                                            title="Enviar a Invitados (grupo por defecto)"
                                                        >
                                                            {">>"}
                                                        </button>

                                                        <button
                                                            className={`move-btn ${selFreeDevice ? "active" : ""}`}
                                                            onClick={() => {
                                                                if (!selFreeDevice) return;
                                                                const d = selFreeDevice;
                                                                setSelFreeDevice(null);
                                                                handleAddDevice(group.id, d.id);
                                                            }}
                                                            disabled={!selFreeDevice}
                                                            title="Traer desde Invitados"
                                                        >
                                                            {"<<"}
                                                        </button>

                                                        {
                                                            !selGroupDevice && !selFreeDevice && (
                                                                <span className="group-move-hint">
                                                                    Selecciona un equipo
                                                                </span>
                                                            )
                                                        }

                                                    </div>
                                                )
                                            }

                                            {
                                                isAdmin && group.is_default && (
                                                    <div className="group-device-move group-device-move-hint-only">
                                                        <span className="group-move-hint">
                                                            Para mover a otro departamento,
                                                            abra ese grupo y use «&lt;&lt;».
                                                        </span>
                                                    </div>
                                                )
                                            }

                                            <div className="group-device-panel">

                                                <h5>
                                                    {
                                                        group.is_default
                                                            ? "Mover a otro departamento"
                                                            : (() => {
                                                                const def = groups && groups.find((g) => g.is_default);
                                                                return def
                                                                    ? `En "${def.name}" (disponibles)`
                                                                    : "Sin grupo";
                                                            })()
                                                    }
                                                </h5>

                                                <div className="group-devices">

                                                    {
                                                        group.is_default ? (
                                                            <p className="vpn-empty group-default-move-help">
                                                                Los equipos en Invitados solo tienen
                                                                bloqueos generales. Abra el grupo
                                                                destino (ej. Contabilidad) y
                                                                seleccione el equipo con «&lt;&lt;».
                                                            </p>
                                                        ) : (() => {
                                                            const def = groups && groups.find((g) => g.is_default);
                                                            const pool = devices.filter((d) => {
                                                                if (!d.groups || d.groups.length === 0) return true;
                                                                return def && d.groups[0].id === def.id;
                                                            });
                                                            if (pool.length === 0) {
                                                                return <p className="vpn-empty">No hay equipos en Invitados.</p>;
                                                            }
                                                            return pool.map((device) => (
                                                                <div
                                                                    key={device.id}
                                                                    className={`group-device-row ${selFreeDevice && selFreeDevice.id === device.id ? "selected" : ""}`}
                                                                    onClick={() => setSelFreeDevice(device)}
                                                                    title="Seleccionar para asignar (<<)"
                                                                >
                                                                    <span className="group-device-name">
                                                                        {device.hostname || device.ip_address || device.mac_address}
                                                                    </span>
                                                                </div>
                                                            ));
                                                        })()
                                                    }

                                                </div>

                                            </div>

                                        </div>

                                        {
                                            !group.is_default && (
                                                <>
                                        <div className="group-rules-header">

                                            <h4>Reglas de bloqueo del grupo</h4>

                                            {
                                                rules.length > 0 && (
                                                    <button
                                                        className="secondary-button small"
                                                        onClick={() => setShowRules((v) => !v)}
                                                        title={
                                                            showRules
                                                                ? "Ocultar la lista de dominios"
                                                                : "Ver todos los dominios bloqueados"
                                                        }
                                                    >
                                                        {showRules
                                                            ? "Ocultar dominios"
                                                            : `Ver dominios bloqueados (${rules.length})`}
                                                    </button>
                                                )
                                            }

                                        </div>

                                        {
                                            showRules && (
                                                <div className="group-rules">

                                                    {
                                                        rules.length === 0 ? (
                                                            <p className="vpn-empty">Sin reglas.</p>
                                                        ) : (
                                                            rules.map((rule) => (
                                                                <span key={rule.id} className={`group-rule-chip ${rule.action === "ALLOW" ? "allow" : "block"}`}>
                                                                    {rule.action === "ALLOW" ? "Permitir" : "Bloquear"} {rule.domain}
                                                                    {
                                                                        isAdmin && (
                                                                            <button
                                                                                className="category-remove"
                                                                                onClick={() => handleRemoveRule(rule.id)}
                                                                                title="Eliminar regla"
                                                                            >
                                                                                ✕
                                                                            </button>
                                                                        )
                                                                    }
                                                                </span>
                                                            ))
                                                        )
                                                    }

                                                </div>
                                            )
                                        }

                                        {
                                            isAdmin && (
                                                <div className="group-add-row">

                                                    <select
                                                        value={ruleForm.action}
                                                        onChange={(e) => setRuleForm({ ...ruleForm, action: e.target.value })}
                                                    >
                                                        <option value="ALLOW">Permitir</option>
                                                        <option value="BLOCK">Bloquear</option>
                                                    </select>

                                                    <input
                                                        type="text"
                                                        placeholder="dominio.com"
                                                        value={ruleForm.domain}
                                                        onChange={(e) => setRuleForm({ ...ruleForm, domain: e.target.value })}
                                                    />

                                                    <button
                                                        className="primary-button small"
                                                        onClick={() => handleAddRule(group.id)}
                                                        disabled={ruleBusy || !ruleForm.domain.trim()}
                                                    >
                                                        Añadir regla
                                                    </button>

                                                </div>
                                            )
                                        }

                                                </>
                                            )
                                        }

                                        {
                                            !group.is_default && (
                                                <>
                                        <h4>Perfil de navegación</h4>

                                        <p className="group-profile-hint">
                                            Restricciones adicionales para este grupo
                                            (redes sociales, streaming, YouTube…).
                                            Porno, apuestas y juegos ya están bloqueados
                                            de raíz en toda la red.
                                        </p>

                                        <div className="group-categories">

                                            {
                                                allCategories
                                                    .filter((cat) => !cat.is_root)
                                                    .map((cat) => (
                                                    <label key={cat.key} className="group-cat-chip">
                                                        <input
                                                            type="checkbox"
                                                            checked={groupCats.includes(cat.key)}
                                                            disabled={busy}
                                                            onChange={() => toggleGroupCategory(cat.key)}
                                                        />
                                                        {cat.name}
                                                        <span className="group-cat-meta">
                                                            {cat.domains} dominios
                                                        </span>
                                                    </label>
                                                ))
                                            }

                                        </div>
                                                </>
                                            )
                                        }

                                        {
                                            group.is_default && (
                                                <p className="group-profile-hint">
                                                    Invitados no tiene bloqueos extra: solo
                                                    aplican los generales de red (porno,
                                                    apuestas, juegos). Cree otro grupo para
                                                    restricciones como YouTube o redes sociales.
                                                </p>
                                            )
                                        }

                                    </div>
                                )
                            }

                        </div>
                    ))
                }

            </div>
                )
            }

        </div>

    );

}


export default Groups;
