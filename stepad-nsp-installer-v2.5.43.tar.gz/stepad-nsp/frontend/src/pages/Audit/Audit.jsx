import { useEffect, useState } from "react";

import { getAuditLogs, exportComplianceReport } from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./audit.css";


function toDateInputValue(date) {

    const y = date.getFullYear();

    const m = String(date.getMonth() + 1).padStart(2, "0");

    const d = String(date.getDate()).padStart(2, "0");

    return `${y}-${m}-${d}`;

}


function defaultStart() {

    const d = new Date();

    d.setDate(d.getDate() - 7);

    return toDateInputValue(d);

}


function Audit() {

    const [rows, setRows] = useState([]);

    const [loading, setLoading] = useState(true);

    const [startDate, setStartDate] = useState(defaultStart());

    const [endDate, setEndDate] = useState(toDateInputValue(new Date()));

    const [actionFilter, setActionFilter] = useState("");

    const [exporting, setExporting] = useState(false);


    async function handleExportCompliance() {

        setExporting(true);

        try {

            const blob = await exportComplianceReport(
                startDate ? `${startDate}T00:00:00` : undefined,
                endDate ? `${endDate}T23:59:59` : undefined
            );

            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");

            link.href = url;

            link.download = `reporte-cumplimiento-${startDate || "inicio"}-${endDate || "hoy"}.xlsx`;

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        } catch (error) {

            console.error(error);

            alert("No se pudo exportar el reporte de cumplimiento.");

        } finally {

            setExporting(false);

        }

    }


    async function load() {

        setLoading(true);

        try {

            const data = await getAuditLogs({
                start: startDate ? `${startDate}T00:00:00` : undefined,
                end: endDate ? `${endDate}T23:59:59` : undefined,
                action: actionFilter || undefined,
                limit: 500
            });

            setRows(data || []);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        let cancelled = false;

        getAuditLogs({
            start: startDate ? `${startDate}T00:00:00` : undefined,
            end: endDate ? `${endDate}T23:59:59` : undefined,
            action: actionFilter || undefined,
            limit: 500
        })

            .then((data) => {
                if (!cancelled) setRows(data || []);
            })

            .catch((error) => {
                if (!cancelled) console.error(error);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    return (

        <div className="logs-container">

            <div className="logs-header">

                <h2>Auditoría</h2>

                <p>

                    Registro de acciones administrativas (quién hizo qué
                    y cuándo) para control y cumplimiento.

                </p>

            </div>

            <div className="logs-filters">

                <label>
                    Desde
                    <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                    />
                </label>

                <label>
                    Hasta
                    <input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                    />
                </label>

                <label>
                    Acción (contiene)
                    <input
                        type="text"
                        placeholder="ej. LOGIN, VPN, RULE..."
                        value={actionFilter}
                        onChange={(e) => setActionFilter(e.target.value)}
                    />
                </label>

                <button
                    className="primary-button"
                    onClick={load}
                    disabled={loading}
                >
                    {loading ? "Cargando..." : "Filtrar"}
                </button>

                <button
                    className="export-button"
                    onClick={handleExportCompliance}
                    disabled={exporting}
                >
                    {exporting ? "Exportando..." : "Reporte de cumplimiento (Excel)"}
                </button>

            </div>

            <div className="table-card">

                <table className="logs-table">

                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Usuario</th>
                            <th>Acción</th>
                            <th>Recurso</th>
                            <th>Descripción</th>
                        </tr>
                    </thead>

                    <tbody>

                        {
                            rows.length === 0 && !loading && (
                                <tr>
                                    <td colSpan={5} className="empty-row">
                                        Sin registros en el rango seleccionado.
                                    </td>
                                </tr>
                            )
                        }

                        {
                            rows.map((row) => (
                                <tr key={row.id}>

                                    <td>{formatDateTime(row.created_at, "—")}</td>

                                    <td>{row.username || row.user_id || "sistema"}</td>

                                    <td>
                                        <span className="audit-action">{row.action}</span>
                                    </td>

                                    <td>{row.resource}</td>

                                    <td>{row.description}</td>

                                </tr>
                            ))
                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}


export default Audit;
