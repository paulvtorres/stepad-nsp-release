import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getRustdeskStatus,
    updateRustdeskConfig,
} from "../../services/api";

import "./rustdesk.css";


function Rustdesk() {
    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [busy, setBusy] = useState(false);
    const [publicHost, setPublicHost] = useState("");
    const [copied, setCopied] = useState(null);

    function load() {
        getRustdeskStatus()
            .then((s) => {
                setStatus(s);
                setPublicHost(s.public_host || "");
            })
            .catch((err) => setError(err.message))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const interval = setInterval(load, 15000);
        return () => clearInterval(interval);
    }, []);

    async function save(patch) {
        setError(null);
        setBusy(true);
        try {
            const next = await updateRustdeskConfig(patch);
            setStatus(next);
            setPublicHost(next.public_host || "");
        } catch (err) {
            setError(err.message);
        } finally {
            setBusy(false);
        }
    }

    async function copyText(label, text) {
        if (!text) return;
        try {
            await navigator.clipboard.writeText(text);
            setCopied(label);
            setTimeout(() => setCopied(null), 2000);
        } catch {
            setError("No se pudo copiar al portapapeles");
        }
    }

    if (loading && !status) {
        return <div className="rd-panel">Cargando RustDesk…</div>;
    }

    return (
        <div className="rd-panel">
            <h2>Acceso remoto (RustDesk)</h2>
            <p className="rd-hint">
                Servidor self-hosted tipo AnyDesk/TeamViewer. Los usuarios
                instalan el cliente RustDesk en su PC de oficina y en el
                equipo remoto, apuntan al servidor del NSP y se conectan
                con el ID de la máquina.
            </p>

            {error && <div className="rd-error">{error}</div>}

            {status && (
                <>
                    <div className="rd-status-grid">
                        <div className="rd-status-card">
                            <div className="rd-status-label">Estado</div>
                            <div className="rd-status-value">
                                {status.ready
                                    ? "Listo"
                                    : status.enabled
                                      ? "Activando…"
                                      : "Detenido"}
                            </div>
                        </div>
                        <div className="rd-status-card">
                            <div className="rd-status-label">hbbs / hbbr</div>
                            <div className="rd-status-value">
                                {status.hbbs_active ? "OK" : "—"} /{" "}
                                {status.hbbr_active ? "OK" : "—"}
                            </div>
                        </div>
                        <div className="rd-status-card">
                            <div className="rd-status-label">Versión</div>
                            <div className="rd-status-value">
                                {status.installed_version ||
                                    (status.installed ? "instalado" : "—")}
                            </div>
                        </div>
                        <div className="rd-status-card">
                            <div className="rd-status-label">WAN</div>
                            <div className="rd-status-value">
                                {status.expose_wan
                                    ? "Puertos abiertos"
                                    : "Solo LAN"}
                            </div>
                        </div>
                    </div>

                    {isAdmin && (
                        <div className="rd-actions">
                            <label className="rd-toggle">
                                <input
                                    type="checkbox"
                                    checked={!!status.enabled}
                                    disabled={busy}
                                    onChange={(e) =>
                                        save({ enabled: e.target.checked })
                                    }
                                />
                                Activar servidor RustDesk en el NSP
                            </label>

                            <label className="rd-toggle">
                                <input
                                    type="checkbox"
                                    checked={!!status.expose_wan}
                                    disabled={busy || !status.enabled}
                                    onChange={(e) =>
                                        save({
                                            expose_wan: e.target.checked,
                                        })
                                    }
                                />
                                Exponer a Internet (trabajo remoto desde fuera)
                            </label>

                            <p className="rd-hint">
                                Con deny-all activo, sin esta opción solo
                                funcionan clientes dentro de la LAN. Para
                                teletrabajo marque la exposición WAN (puertos
                                TCP 21115–21117 y UDP 21116). Si el NSP no es
                                el router de borde, reenvíe esos puertos desde
                                el router del ISP hacia el NSP.
                            </p>

                            <div className="rd-form">
                                <label>
                                    Host público (opcional)
                                    <input
                                        type="text"
                                        placeholder={
                                            status.detected_wan_ip ||
                                            "IP WAN o DNS, ej. remoto.empresa.com"
                                        }
                                        value={publicHost}
                                        disabled={busy}
                                        onChange={(e) =>
                                            setPublicHost(e.target.value)
                                        }
                                    />
                                </label>
                                <button
                                    type="button"
                                    disabled={busy}
                                    onClick={() =>
                                        save({
                                            public_host: publicHost.trim(),
                                        })
                                    }
                                >
                                    Guardar host
                                </button>
                            </div>
                        </div>
                    )}

                    {status.enabled && (
                        <div className="rd-client">
                            <h3>Configuración para los clientes</h3>
                            <p className="rd-hint">
                                En RustDesk → Ajustes → Red → ID/Relay server:
                            </p>

                            <div className="rd-copy-row">
                                <span className="rd-label">ID / Relay</span>
                                <code className="rd-code">
                                    {status.client_host || "—"}
                                </code>
                                <button
                                    type="button"
                                    disabled={!status.client_host}
                                    onClick={() =>
                                        copyText(
                                            "host",
                                            status.client_host
                                        )
                                    }
                                >
                                    {copied === "host" ? "Copiado" : "Copiar"}
                                </button>
                            </div>

                            <div className="rd-copy-row">
                                <span className="rd-label">Key</span>
                                <code className="rd-code">
                                    {status.public_key || "Generando…"}
                                </code>
                                <button
                                    type="button"
                                    disabled={!status.public_key}
                                    onClick={() =>
                                        copyText("key", status.public_key)
                                    }
                                >
                                    {copied === "key" ? "Copiado" : "Copiar"}
                                </button>
                            </div>

                            <ol className="rd-steps">
                                <li>
                                    Descargue el cliente oficial:{" "}
                                    <a
                                        href={
                                            status.client_downloads?.windows ||
                                            "https://rustdesk.com/"
                                        }
                                        target="_blank"
                                        rel="noreferrer"
                                    >
                                        rustdesk.com
                                    </a>
                                </li>
                                <li>
                                    Instálelo en el PC de la oficina y en el
                                    equipo desde el que se conectará.
                                </li>
                                <li>
                                    Configure ID server, Relay server y Key
                                    como arriba (misma config en ambos).
                                </li>
                                <li>
                                    En el PC de oficina anote el ID y defina
                                    una contraseña de acceso permanente.
                                </li>
                                <li>
                                    Desde fuera, abra RustDesk, introduzca el
                                    ID y conéctese.
                                </li>
                            </ol>
                        </div>
                    )}
                </>
            )}
        </div>
    );
}

export default Rustdesk;
