import { useState } from "react";

import ModulesSection from "./components/ModulesSection";
import OrganizationSection from "./components/OrganizationSection";
import EmailSection from "./components/EmailSection";
import NavigationReportSection from "./components/NavigationReportSection";
import AlertNotificationSection from "./components/AlertNotificationSection";
import SecuritySection from "./components/SecuritySection";
import BackupSection from "./components/BackupSection";
import IntegrationSection from "./components/IntegrationSection";
import PortForwardSection from "./components/PortForwardSection";
import RevisionSection from "./components/RevisionSection";
import MaintenanceSection from "./components/MaintenanceSection";
import UpdateSection from "./components/UpdateSection";
import DomainGroupsSection from "./components/DomainGroupsSection";

import "./settings.css";


function Settings() {

    const [tab, setTab] = useState("empresa");

    const TABS = [
        { key: "servicios", label: "Servicios" },
        { key: "empresa", label: "Empresa" },
        { key: "correo", label: "Correo" },
        { key: "seguridad", label: "Seguridad" },
        { key: "navegacion", label: "Navegación" },
        { key: "alertas", label: "Alertas" },
        { key: "copias", label: "Copias y respaldos" },
        { key: "revision", label: "Revisión" },
        { key: "integracion", label: "Integraciones" },
        { key: "dmz", label: "Reenvíos (DMZ)" },
        { key: "mantenimiento", label: "Mantenimiento" },
        { key: "dominios", label: "Dominios" },
        { key: "actualizaciones", label: "Actualizaciones" },
    ];


    return (

        <div className="settings-container">

            <h2>Ajustes y mantenimiento</h2>

            <div className="settings-tabs">

                {
                    TABS.map((item) => (
                        <button
                            key={item.key}
                            className={`settings-tab ${tab === item.key ? "active" : ""}`}
                            onClick={() => setTab(item.key)}
                        >
                            {item.label}
                        </button>
                    ))
                }

            </div>

            {tab === "servicios" && <ModulesSection />}

            {tab === "empresa" && <OrganizationSection />}

            {tab === "correo" && <EmailSection />}

            {tab === "seguridad" && <SecuritySection />}

            {tab === "navegacion" && <NavigationReportSection />}

            {tab === "alertas" && <AlertNotificationSection />}

            {tab === "copias" && <BackupSection />}

            {tab === "revision" && <RevisionSection />}

            {tab === "integracion" && <IntegrationSection />}

            {tab === "dmz" && <PortForwardSection />}

            {tab === "mantenimiento" && <MaintenanceSection />}

            {tab === "dominios" && <DomainGroupsSection />}

            {tab === "actualizaciones" && <UpdateSection />}

        </div>

    );

}


export default Settings;
