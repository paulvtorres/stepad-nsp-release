import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getPortForwards,
    createPortForward,
    deletePortForward,
} from "../../../services/api";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function PortForwardSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [forwards, setForwards] = useState([]);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);

    const [busy, setBusy] = useState(false);

    const [form, setForm] = useState({
        name: "",
        protocol: "tcp",
        external_port: "",
        internal_ip: "",
        internal_port: "",
        wan_interface: "",
    });


    async function load() {

        try {

            const data = await getPortForwards();

            setForwards(data || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        let cancelled = false;

        getPortForwards()

            .then((data) => {
                if (!cancelled) setForwards(data || []);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleCreate() {

        setError(null);

        setBusy(true);

        try {

            await createPortForward({
                name: form.name,
                protocol: form.protocol,
                external_port: Number(form.external_port),
                internal_ip: form.internal_ip,
                internal_port: Number(form.internal_port),
                wan_interface: form.wan_interface.trim() || null,
                enabled: true,
            });

            setForm({
                name: "",
                protocol: "tcp",
                external_port: "",
                internal_ip: "",
                internal_port: "",
                wan_interface: "",
            });

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDelete(id) {

        setError(null);

        setBusy(true);

        try {

            await deletePortForward(id);

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const activeCount = forwards.filter((f) => f.enabled).length;

    const badge = loading
        ? "Cargando…"
        : `${activeCount} activo${activeCount !== 1 ? "s" : ""}`;

    const badgeVariant = loading
        ? ""
        : activeCount > 0
            ? "complete"
            : "empty";


    return (

        <SettingsPanel
            title="Reenvío de puertos (DMZ)"
            lead="Publica un servicio de Internet hacia un equipo interno. Con deny-all activo el reenvío se permite de forma controlada (allowlist + límite de conexiones) y el tráfico sigue pasando por Suricata. No publiques bases de datos ni RDP/SMB a Internet."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Reglas"
                    value={loading ? "—" : String(forwards.length)}
                    meta="Reenvíos configurados"
                />

                <SettingsStatusCard
                    label="Activas"
                    value={loading ? "—" : String(activeCount)}
                    meta="Publicadas en el firewall"
                    variant={activeCount > 0 ? "ok" : "muted"}
                />

            </SettingsStatusGrid>

            <SettingsBlock title="Reenvíos configurados" first>

                {
                    loading && (
                        <p className="org-section-hint">Cargando reenvíos…</p>
                    )
                }

                {
                    !loading && forwards.length === 0 && (
                        <p className="org-section-hint">No hay reenvíos de puertos configurados.</p>
                    )
                }

                <ul className="org-list">

                    {
                        forwards.map((f) => (
                            <li key={f.id} className="org-list-item">

                                <div className="org-list-item-main">
                                    <strong>{f.name}</strong>
                                    {" — "}
                                    {f.protocol === "both" ? "TCP+UDP" : f.protocol.toUpperCase()}
                                    {" "}
                                    {f.wan_interface ? `[${f.wan_interface}]` : "[todas las WAN]"}
                                    {" "}
                                    {f.external_port} → {f.internal_ip}:{f.internal_port}
                                    {" "}
                                    <span className={`org-rule-state ${f.enabled ? "enabled" : "disabled"}`}>
                                        {f.enabled ? "ACTIVO" : "INACTIVO"}
                                    </span>
                                </div>

                                {
                                    isAdmin && (
                                        <button
                                            className="danger-button small"
                                            onClick={() => handleDelete(f.id)}
                                            disabled={busy}
                                        >
                                            Eliminar
                                        </button>
                                    )
                                }

                            </li>
                        ))
                    }

                </ul>

            </SettingsBlock>

            {
                isAdmin && (
                    <SettingsBlock
                        title="Nuevo reenvío"
                        hint="Define el puerto externo y el destino interno en la DMZ."
                    >

                        <div className="org-form-grid">

                            <label className="org-wide">
                                Nombre
                                <input
                                    type="text"
                                    placeholder="ej. servidor web DMZ"
                                    value={form.name}
                                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                                />
                            </label>

                            <label>
                                Protocolo
                                <select
                                    value={form.protocol}
                                    onChange={(e) => setForm({ ...form, protocol: e.target.value })}
                                >
                                    <option value="tcp">TCP</option>
                                    <option value="udp">UDP</option>
                                    <option value="both">TCP + UDP</option>
                                </select>
                            </label>

                            <label>
                                Puerto externo (WAN)
                                <input
                                    type="number"
                                    value={form.external_port}
                                    onChange={(e) => setForm({ ...form, external_port: e.target.value })}
                                    placeholder="ej. 443"
                                />
                            </label>

                            <label>
                                IP interna del host
                                <input
                                    type="text"
                                    value={form.internal_ip}
                                    onChange={(e) => setForm({ ...form, internal_ip: e.target.value })}
                                    placeholder="ej. 192.168.60.10"
                                />
                            </label>

                            <label>
                                Puerto interno
                                <input
                                    type="number"
                                    value={form.internal_port}
                                    onChange={(e) => setForm({ ...form, internal_port: e.target.value })}
                                    placeholder="ej. 443"
                                />
                            </label>

                            <label className="org-wide">
                                Interfaz WAN (vacío = todas)
                                <input
                                    type="text"
                                    value={form.wan_interface}
                                    onChange={(e) => setForm({ ...form, wan_interface: e.target.value })}
                                    placeholder="ej. enp37s0 (opcional)"
                                />
                            </label>

                        </div>

                        <SettingsActions>

                            <button
                                className="primary-button"
                                onClick={handleCreate}
                                disabled={
                                    busy
                                    || !form.name
                                    || !form.external_port
                                    || !form.internal_ip
                                    || !form.internal_port
                                }
                            >
                                Añadir reenvío
                            </button>

                        </SettingsActions>

                    </SettingsBlock>
                )
            }

        </SettingsPanel>

    );

}


export default PortForwardSection;
