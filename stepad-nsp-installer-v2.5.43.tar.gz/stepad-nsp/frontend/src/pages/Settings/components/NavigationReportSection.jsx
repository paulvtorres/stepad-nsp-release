import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getNavigationReportSettings,
    saveNavigationReportSettings,
    sendNotificationNow,
} from "../../../services/api";

import { formatDateTime } from "../../../utils/datetime";

import "../settings.css";


function NavigationReportSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        enabled: false,
        to_emails: "",
        bcc_emails: "",
        report_subject: "",
        frequency: "daily",
        send_hour: 8,
        send_minute: 0,
    });

    const [subjectDefaults, setSubjectDefaults] = useState({
        report: "",
        reportVars: [],
    });

    const [status, setStatus] = useState({
        config_ready: false,
        config_issues: [],
        email_config_ready: false,
        email_provider_label: "",
        email_account: "",
        next_send_hint: "",
        schedule_label: "",
        report_period: "",
        last_sent_at: null,
        scheduler_running: false,
    });

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [saving, setSaving] = useState(false);

    const [sending, setSending] = useState(false);

    const busy = saving || sending;


    function applySettings(data) {

        setForm({
            enabled: data.enabled,
            to_emails: data.to_emails || "",
            bcc_emails: data.bcc_emails || "",
            report_subject: data.report_subject || "",
            frequency: data.frequency || "daily",
            send_hour: data.send_hour ?? 8,
            send_minute: data.send_minute ?? 0,
        });

        setSubjectDefaults({
            report: data.report_subject_default || "",
            reportVars: data.report_subject_variables || [],
        });

        setStatus({
            config_ready: Boolean(data.config_ready),
            config_issues: data.config_issues || [],
            email_config_ready: Boolean(data.email_config_ready),
            email_provider_label: data.email_provider_label || "",
            email_account: data.email_account || "",
            next_send_hint: data.next_send_hint || "",
            schedule_label: data.schedule_label || "",
            report_period: data.report_period || "",
            last_sent_at: data.last_sent_at || null,
            scheduler_running: Boolean(data.scheduler_running),
        });

    }


    useEffect(() => {

        let cancelled = false;

        getNavigationReportSettings()

            .then((data) => {
                if (!cancelled) applySettings(data);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    function payloadFrom(nextForm = form) {

        return {
            enabled: nextForm.enabled,
            to_emails: nextForm.to_emails,
            bcc_emails: nextForm.bcc_emails,
            report_subject: nextForm.report_subject,
            frequency: nextForm.frequency,
            send_hour: Number(nextForm.send_hour),
            send_minute: Number(nextForm.send_minute),
        };

    }


    async function handleSave(nextForm) {

        const data = (
            nextForm
            && typeof nextForm === "object"
            && "to_emails" in nextForm
        ) ? nextForm : form;

        const emails = (data.to_emails || "")
            .split(",")
            .map((email) => email.trim())
            .filter(Boolean);

        if (data.enabled && emails.length === 0) {

            setError("Indique al menos un destinatario en Para antes de activar.");

            return;

        }

        setError(null);

        setNotice(null);

        setSaving(true);

        try {

            const saved = await saveNavigationReportSettings(payloadFrom(data));

            applySettings(saved);

            setNotice("Programación del reporte de navegación guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setSaving(false);

        }

    }


    async function handleSendNow() {

        setError(null);

        setNotice(null);

        setSending(true);

        try {

            const result = await sendNotificationNow();

            if (result.success === false) {

                setError(result.message || "No se pudo enviar el reporte.");

                return;

            }

            const data = await getNavigationReportSettings();

            applySettings(data);

            setNotice(result.message || "Reporte enviado con Excel adjunto.");

        } catch (err) {

            setError(err.message);

        } finally {

            setSending(false);

        }

    }


    const recipientCount = form.to_emails
        .split(",")
        .map((email) => email.trim())
        .filter(Boolean).length;

    const bccCount = form.bcc_emails
        .split(",")
        .map((email) => email.trim())
        .filter(Boolean).length;


    return (

        <div className="notify-panel">

            <div className="notify-header">

                <div>

                    <h3>Reporte de navegación por correo</h3>

                    <p className="notify-lead">

                        Programa el envío del resumen de navegación (Historial DNS)
                        con Excel adjunto. Es independiente de las alertas críticas
                        (pestaña <strong>Alertas</strong>). La cuenta SMTP se
                        configura en <strong>Correo</strong>.

                    </p>

                </div>

                <label className={`notify-master-toggle ${form.enabled ? "on" : ""}`}>
                    <input
                        type="checkbox"
                        checked={form.enabled}
                        disabled={!isAdmin || busy}
                        onChange={(e) => {
                            const emails = (form.to_emails || "")
                                .split(",")
                                .map((email) => email.trim())
                                .filter(Boolean);
                            if (e.target.checked && emails.length === 0) {
                                setError("Indique al menos un destinatario en Para antes de activar.");
                                return;
                            }
                            const next = {
                                ...form,
                                enabled: e.target.checked,
                            };
                            setForm(next);
                            handleSave(next);
                        }}
                    />
                    <span>{form.enabled ? "Activo" : "Inactivo"}</span>
                </label>

            </div>


            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}


            {
                !status.email_config_ready && (
                    <div className="org-warning-banner">
                        Configure la cuenta de correo en{" "}
                        <strong>Ajustes → Correo</strong> antes de activar
                        los reportes automáticos.
                    </div>
                )
            }

            {
                status.email_config_ready && !form.enabled && (
                    <div className="org-warning-banner">
                        El envío programado está <strong>apagado</strong>.
                        Escriba el correo en <strong>Para</strong>, active
                        el interruptor y pulse <strong>Guardar
                        programación</strong>.
                    </div>
                )
            }


            <div className="notify-status-grid">

                <div className={`notify-status-card ${form.enabled ? "ok" : "muted"}`}>
                    <span className="notify-status-label">Estado</span>
                    <strong>{form.enabled ? "Programado" : "Desactivado"}</strong>
                    <span className="notify-status-meta">
                        {status.scheduler_running
                            ? "Servicio en ejecución"
                            : "Servicio no detectado"}
                    </span>
                </div>

                <div className="notify-status-card">
                    <span className="notify-status-label">Último envío</span>
                    <strong>{formatDateTime(status.last_sent_at, "Nunca")}</strong>
                    <span className="notify-status-meta">
                        {status.schedule_label || "Sin programación"}
                    </span>
                </div>

                <div className={`notify-status-card ${status.config_ready ? "ok" : "warn"}`}>
                    <span className="notify-status-label">Listo para enviar</span>
                    <strong>{status.config_ready ? "Sí" : "No"}</strong>
                    <span className="notify-status-meta">
                        {status.config_ready
                            ? `${recipientCount} para${bccCount ? `, ${bccCount} CCO` : ""}`
                            : (status.config_issues || []).join(", ") || "Revise correo y destinatarios"}
                    </span>
                </div>

                <div className={`notify-status-card ${status.email_config_ready ? "ok" : "warn"}`}>
                    <span className="notify-status-label">Cuenta de correo</span>
                    <strong>{status.email_config_ready ? "Configurada" : "Pendiente"}</strong>
                    <span className="notify-status-meta">
                        {status.email_account
                            ? `${status.email_provider_label}: ${status.email_account}`
                            : "Ajustes → Correo"}
                    </span>
                </div>

                <div className="notify-status-card">
                    <span className="notify-status-label">Próximo envío</span>
                    <strong>{status.next_send_hint || "—"}</strong>
                    <span className="notify-status-meta">
                        Hora de Ecuador
                    </span>
                </div>

            </div>


            <div className="notify-report-preview">

                <h4>Contenido del reporte</h4>

                <ul>
                    <li>Navegación por equipo (de mayor a menor actividad)</li>
                    <li>Dominios visitados por cada equipo en el correo</li>
                    <li>Accesos bloqueados relevantes del período</li>
                    <li>
                        Período del envío automático:{" "}
                        <strong>{status.report_period || "según frecuencia"}</strong>
                    </li>
                    <li>
                        Excel adjunto con detalle completo:{" "}
                        <strong>historial-dns_*.xlsx</strong>
                    </li>
                </ul>

            </div>


            <div className="notify-section">

                <h4>Destinatarios y programación</h4>

                <div className="notify-form-grid">

                    <label className="notify-wide">
                        Para
                        <input
                            type="text"
                            value={form.to_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, to_emails: e.target.value })
                            }
                            placeholder="dueno@empresa.com, gerencia@empresa.com"
                        />
                        <span className="notify-field-hint">
                            Destinatarios del reporte de navegación. Separe varios correos con coma.
                        </span>
                    </label>

                    <label className="notify-wide">
                        Copia oculta (CCO)
                        <input
                            type="text"
                            value={form.bcc_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, bcc_emails: e.target.value })
                            }
                            placeholder="auditoria@empresa.com"
                        />
                    </label>

                    <label className="notify-wide">
                        Asunto del reporte
                        <input
                            type="text"
                            value={form.report_subject}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, report_subject: e.target.value })
                            }
                            placeholder={subjectDefaults.report}
                        />
                        <span className="notify-field-hint">
                            Variables: {(subjectDefaults.reportVars || [])
                                .map((v) => `{${v}}`)
                                .join(", ")}
                        </span>
                    </label>

                    <label>
                        Frecuencia
                        <select
                            value={form.frequency}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, frequency: e.target.value })
                            }
                        >
                            <option value="daily">Diaria — últimas 24 h</option>
                            <option value="weekly">Semanal — últimos 7 días</option>
                            <option value="monthly">Mensual — últimos 30 días</option>
                        </select>
                    </label>

                    <label>
                        Hora de envío
                        <input
                            type="time"
                            disabled={!isAdmin}
                            value={`${String(form.send_hour).padStart(2, "0")}:${String(form.send_minute).padStart(2, "0")}`}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setForm({
                                    ...form,
                                    send_hour: Number(h),
                                    send_minute: Number(m),
                                });
                            }}
                        />
                        <span className="notify-field-hint">
                            Hora de Ecuador. Ventana de 2 horas a partir de esta hora.
                        </span>
                    </label>

                </div>

            </div>


            <div className="notify-actions">

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={busy || !isAdmin}
                >
                    {saving ? "Guardando..." : "Guardar programación"}
                </button>

                <button
                    className="secondary-button"
                    onClick={handleSendNow}
                    disabled={busy || !isAdmin}
                >
                    {sending ? "Enviando..." : "Enviar reporte ahora"}
                </button>

            </div>

            {!isAdmin && (
                <p className="notify-readonly">Solo administradores pueden modificar esta sección.</p>
            )}

        </div>

    );

}


export default NavigationReportSection;
