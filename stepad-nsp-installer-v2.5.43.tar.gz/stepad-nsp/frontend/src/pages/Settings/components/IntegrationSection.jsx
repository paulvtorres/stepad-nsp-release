import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getSyslogSettings,
    saveSyslogSettings,
    testSyslog,
    getComplianceRetention,
    saveComplianceRetention,
    getLogsReview,
    saveLogsReview,
    markLogsReview,
} from "../../../services/api";

import { formatDateTime } from "../../../utils/datetime";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


function IntegrationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [syslog, setSyslog] = useState({
        enabled: false,
        server: "",
        port: 514,
        protocol: "udp",
    });

    const [retention, setRetention] = useState(90);

    const [reviewerEmail, setReviewerEmail] = useState("");

    const [reviewFreq, setReviewFreq] = useState(7);

    const [reviewLast, setReviewLast] = useState(null);

    const [reviewOverdue, setReviewOverdue] = useState(false);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);

    const [loading, setLoading] = useState(true);


    useEffect(() => {

        let cancelled = false;

        Promise.all([
            getSyslogSettings(),
            getComplianceRetention(),
            getLogsReview().catch(() => null),
        ])

            .then(([syslogData, retentionData, reviewData]) => {

                if (cancelled) return;

                setSyslog({
                    enabled: syslogData.enabled,
                    server: syslogData.server || "",
                    port: syslogData.port,
                    protocol: syslogData.protocol || "udp",
                });

                setRetention(retentionData.log_retention_days);

                if (reviewData) {
                    setReviewerEmail(reviewData.reviewer_email || "");
                    setReviewFreq(reviewData.frequency_days || 7);
                    setReviewLast(reviewData.last_review);
                    setReviewOverdue(reviewData.overdue);
                }

            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleSaveSyslog() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveSyslogSettings({
                enabled: syslog.enabled,
                server: syslog.server,
                port: Number(syslog.port),
                protocol: syslog.protocol,
            });

            setSyslog((previous) => ({
                ...previous,
                enabled: saved.enabled,
            }));

            setNotice("Configuración SIEM guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleTestSyslog() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await testSyslog();

            setNotice(result.message || "Mensaje de prueba enviado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveRetention() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await saveComplianceRetention({
                log_retention_days: Number(retention),
            });

            setNotice("Retención de logs guardada (aplica al reiniciar el DNS).");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveReviewer() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveLogsReview({
                reviewer_email: reviewerEmail,
                frequency_days: Number(reviewFreq),
            });

            setReviewLast(saved.last_review);

            setReviewOverdue(saved.overdue);

            setNotice("Responsable de revisión guardado.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleMarkReview() {

        setBusy(true);

        try {

            const saved = await markLogsReview();

            setReviewLast(saved.last_review);

            setReviewOverdue(saved.overdue);

            setNotice("Revisión de logs marcada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const badge = loading
        ? "Cargando…"
        : syslog.enabled
            ? "SIEM activo"
            : "Sin SIEM";

    const badgeVariant = loading
        ? ""
        : syslog.enabled
            ? "complete"
            : "partial";


    return (

        <SettingsPanel
            title="Integraciones y cumplimiento"
            lead="Conecta el NSP con tu SIEM, define la retención de registros y designa quién revisa los logs periódicamente."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
            notice={notice}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Syslog"
                    value={syslog.enabled ? "Enviando" : "Desactivado"}
                    meta={syslog.server ? `${syslog.server}:${syslog.port}` : "Sin servidor configurado"}
                    variant={syslog.enabled ? "ok" : "muted"}
                />

                <SettingsStatusCard
                    label="Retención"
                    value={`${retention} días`}
                    meta="Historial DNS y auditoría"
                />

                <SettingsStatusCard
                    label="Revisión de logs"
                    value={reviewOverdue ? "Pendiente" : reviewLast ? "Al día" : "Sin registrar"}
                    meta={reviewLast
                        ? `Última: ${formatDateTime(reviewLast)}`
                        : reviewerEmail || "Sin responsable"}
                    variant={reviewOverdue ? "warn" : reviewLast ? "ok" : "muted"}
                />

            </SettingsStatusGrid>

            <SettingsBlock
                title="Integración SIEM (Syslog)"
                hint="Reenvía eventos de seguridad a tu SOC (Splunk, Elastic, Graylog…) por syslog."
                first
            >

                <label className="org-checkbox-row">
                    <input
                        type="checkbox"
                        checked={syslog.enabled}
                        disabled={!isAdmin}
                        onChange={(e) => setSyslog({ ...syslog, enabled: e.target.checked })}
                    />
                    Reenvío a SIEM habilitado
                </label>

                <div className="org-form-grid">

                    <label>
                        Servidor syslog
                        <input
                            type="text"
                            value={syslog.server}
                            disabled={!isAdmin}
                            onChange={(e) => setSyslog({ ...syslog, server: e.target.value })}
                            placeholder="ej. 10.0.0.10"
                        />
                    </label>

                    <label>
                        Puerto
                        <input
                            type="number"
                            value={syslog.port}
                            disabled={!isAdmin}
                            onChange={(e) => setSyslog({ ...syslog, port: e.target.value })}
                            placeholder="514"
                        />
                    </label>

                    <label>
                        Protocolo
                        <select
                            value={syslog.protocol}
                            disabled={!isAdmin}
                            onChange={(e) => setSyslog({ ...syslog, protocol: e.target.value })}
                        >
                            <option value="udp">UDP</option>
                            <option value="tcp">TCP</option>
                        </select>
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleSaveSyslog}
                        disabled={busy || !isAdmin}
                    >
                        {busy ? "Guardando…" : "Guardar SIEM"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleTestSyslog}
                        disabled={busy || !isAdmin}
                    >
                        Enviar prueba
                    </button>

                </SettingsActions>

            </SettingsBlock>

            <SettingsBlock
                title="Retención de registros"
                hint="Días que se conservan los registros de navegación antes de purgarse."
            >

                <div className="org-form-grid">

                    <label>
                        Días de retención
                        <input
                            type="number"
                            value={retention}
                            disabled={!isAdmin}
                            onChange={(e) => setRetention(e.target.value)}
                            min={7}
                            max={730}
                        />
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleSaveRetention}
                        disabled={busy || !isAdmin}
                    >
                        Guardar retención
                    </button>

                </SettingsActions>

            </SettingsBlock>

            <SettingsBlock
                title="Responsable de revisión de logs"
                hint="Persona designada para revisar periódicamente los registros de auditoría."
            >

                {
                    reviewOverdue && (
                        <div className="org-warning-banner">
                            Revisión de logs pendiente (más de {reviewFreq} días).
                        </div>
                    )
                }

                <div className="org-form-grid">

                    <label>
                        Correo del responsable
                        <input
                            type="email"
                            value={reviewerEmail}
                            disabled={!isAdmin}
                            onChange={(e) => setReviewerEmail(e.target.value)}
                            placeholder="admin@empresa.com"
                        />
                    </label>

                    <label>
                        Recordatorio cada (días)
                        <input
                            type="number"
                            min={1}
                            max={365}
                            value={reviewFreq}
                            disabled={!isAdmin}
                            onChange={(e) => setReviewFreq(e.target.value)}
                        />
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleSaveReviewer}
                        disabled={busy || !isAdmin}
                    >
                        Guardar responsable
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleMarkReview}
                        disabled={busy || !isAdmin}
                    >
                        Marcar revisión hecha
                    </button>

                </SettingsActions>

            </SettingsBlock>

        </SettingsPanel>

    );

}


export default IntegrationSection;
