import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getBackupSettings,
    saveBackupSettings,
    getBackups,
    createBackup,
    downloadBackup,
    deleteBackup,
    uploadBackup,
    restoreBackup,
    getCloudSettings,
    saveCloudSettings,
    testCloudConnection,
    uploadCloudLogs,
} from "../../../services/api";

import { formatDateTime } from "../../../utils/datetime";

import {
    SettingsPanel,
    SettingsStatusGrid,
    SettingsStatusCard,
    SettingsBlock,
    SettingsActions,
} from "./SettingsPanel";

import "../settings.css";


const DEFAULT_CLOUD = {
    enabled: false,
    provider: "s3",
    endpoint: "",
    bucket: "",
    remote_path: "",
    host: "",
    user: "",
    access_key: "",
    secret_key: "",
    password: "",
    upload_hour: 3,
    upload_minute: 30,
    upload_days: 1,
};


function BackupSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        enabled: false,
        send_hour: 3,
        send_minute: 0,
        retention_count: 7,
        email_backup: false,
        to_emails: "",
        bcc_emails: "",
        email_subject: "",
    });

    const [backupSubjectDefault, setBackupSubjectDefault] = useState("");
    const [backupSubjectVars, setBackupSubjectVars] = useState([]);

    const [cloudForm, setCloudForm] = useState(DEFAULT_CLOUD);

    const [backups, setBackups] = useState([]);

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [cloudMsg, setCloudMsg] = useState(null);

    const [busy, setBusy] = useState(false);

    const [cloudBusy, setCloudBusy] = useState(false);

    const [loading, setLoading] = useState(true);


    useEffect(() => {

        let cancelled = false;

        Promise.all([
            getBackupSettings(),
            getBackups(),
            getCloudSettings().catch(() => null),
        ])

            .then(([settings, backupList, cloud]) => {

                if (cancelled) return;

                setForm({
                    enabled: settings.enabled,
                    send_hour: settings.send_hour,
                    send_minute: settings.send_minute,
                    retention_count: settings.retention_count,
                    email_backup: settings.email_backup,
                    to_emails: settings.to_emails || "",
                    bcc_emails: settings.bcc_emails || "",
                    email_subject: settings.email_subject || "",
                });

                setBackupSubjectDefault(settings.email_subject_default || "");
                setBackupSubjectVars(settings.email_subject_variables || []);

                setBackups(backupList || []);

                if (cloud) {
                    setCloudForm({
                        enabled: cloud.enabled,
                        provider: cloud.provider || "s3",
                        endpoint: cloud.endpoint || "",
                        bucket: cloud.bucket || "",
                        remote_path: cloud.remote_path || "",
                        host: cloud.host || "",
                        user: cloud.user || "",
                        access_key: "",
                        secret_key: "",
                        password: "",
                        upload_hour: cloud.upload_hour ?? 3,
                        upload_minute: cloud.upload_minute ?? 30,
                        upload_days: cloud.upload_days ?? 1,
                    });
                }

            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            })

            .finally(() => {
                if (!cancelled) setLoading(false);
            });

        return () => { cancelled = true; };

    }, []);


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            await saveBackupSettings({
                enabled: form.enabled,
                send_hour: Number(form.send_hour),
                send_minute: Number(form.send_minute),
                retention_count: Number(form.retention_count),
                email_backup: form.email_backup,
                to_emails: form.to_emails,
                bcc_emails: form.bcc_emails,
                email_subject: form.email_subject,
            });

            setNotice("Configuración de copias guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleCreate() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await createBackup();

            if (result.success) {

                setNotice(`Copia creada: ${result.filename}`);

                setBackups(await getBackups() || []);

            } else {

                setError(result.message || "No se pudo crear la copia.");

            }

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDownload(filename) {

        try {

            const blob = await downloadBackup(filename);

            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");

            link.href = url;

            link.download = filename;

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        } catch (err) {

            setError(err.message);

        }

    }


    async function handleUpload(event) {

        const file = event.target.files && event.target.files[0];

        if (!file) return;

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await uploadBackup(file);

            setNotice(result.message || "Respaldo subido.");

            setBackups(await getBackups() || []);

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

            event.target.value = "";

        }

    }


    async function handleRestore(filename) {

        const ok = window.confirm(
            `¿Restaurar el respaldo "${filename}"?\n\n` +
            "Se reemplazará la configuración y la base de datos actuales " +
            "por las del respaldo y el servicio se reiniciará."
        );

        if (!ok) return;

        setBusy(true);

        try {

            const result = await restoreBackup(filename);

            setNotice(result.message || "Restaurando…");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDelete(filename) {

        setError(null);

        setBusy(true);

        try {

            await deleteBackup(filename);

            setBackups(await getBackups() || []);

            setNotice("Copia eliminada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleCloudSave() {

        setError(null);

        setCloudMsg(null);

        setCloudBusy(true);

        try {

            const payload = {
                enabled: cloudForm.enabled,
                provider: cloudForm.provider,
                endpoint: cloudForm.endpoint,
                bucket: cloudForm.bucket,
                remote_path: cloudForm.remote_path,
                host: cloudForm.host,
                user: cloudForm.user,
                upload_hour: Number(cloudForm.upload_hour),
                upload_minute: Number(cloudForm.upload_minute),
                upload_days: Number(cloudForm.upload_days),
            };

            if (cloudForm.access_key) payload.access_key = cloudForm.access_key;

            if (cloudForm.secret_key) payload.secret_key = cloudForm.secret_key;

            if (cloudForm.password) payload.password = cloudForm.password;

            await saveCloudSettings(payload);

            setCloudMsg("Configuración de nube guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setCloudBusy(false);

        }

    }


    async function handleCloudTest() {

        setError(null);

        setCloudMsg(null);

        setCloudBusy(true);

        try {

            const result = await testCloudConnection();

            setCloudMsg(result.message || "Conexión correcta.");

        } catch (err) {

            setError(err.message);

        } finally {

            setCloudBusy(false);

        }

    }


    async function handleCloudUpload() {

        setError(null);

        setCloudMsg(null);

        setCloudBusy(true);

        try {

            const result = await uploadCloudLogs();

            setCloudMsg(result.message || "Subida iniciada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setCloudBusy(false);

        }

    }


    const scheduleLabel = `${String(form.send_hour).padStart(2, "0")}:${String(form.send_minute).padStart(2, "0")}`;

    const badge = loading
        ? "Cargando…"
        : form.enabled
            ? "Automático activo"
            : "Manual";

    const badgeVariant = loading
        ? ""
        : form.enabled
            ? "complete"
            : "partial";


    return (

        <SettingsPanel
            title="Copias y respaldos"
            lead="Genera copias de la configuración y base de datos para recuperación ante desastres. Opcionalmente envíalas por correo o súbelas a almacenamiento en la nube."
            badge={badge}
            badgeVariant={badgeVariant}
            error={error}
            notice={notice || cloudMsg}
        >

            <SettingsStatusGrid>

                <SettingsStatusCard
                    label="Copias locales"
                    value={loading ? "—" : String(backups.length)}
                    meta={`Retención: ${form.retention_count} archivos`}
                />

                <SettingsStatusCard
                    label="Programación"
                    value={form.enabled ? scheduleLabel : "Desactivada"}
                    meta={form.email_backup ? "Incluye envío por email" : "Solo almacenamiento local"}
                    variant={form.enabled ? "ok" : "muted"}
                />

                <SettingsStatusCard
                    label="Nube"
                    value={cloudForm.enabled ? "Activa" : "Inactiva"}
                    meta={cloudForm.provider === "s3" ? "S3-compatible" : cloudForm.provider.toUpperCase()}
                    variant={cloudForm.enabled ? "ok" : "muted"}
                />

            </SettingsStatusGrid>

            <SettingsBlock
                title="Copias automáticas"
                hint="Programa la generación diaria de respaldos cifrados en el equipo."
                first
            >

                <label className="org-checkbox-row">
                    <input
                        type="checkbox"
                        checked={form.enabled}
                        disabled={!isAdmin}
                        onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                    />
                    Copias automáticas habilitadas
                </label>

                <label className="org-checkbox-row">
                    <input
                        type="checkbox"
                        checked={form.email_backup}
                        disabled={!isAdmin}
                        onChange={(e) => setForm({ ...form, email_backup: e.target.checked })}
                    />
                    Enviar respaldo cifrado por email (fuera del sitio)
                </label>

                {form.email_backup && (
                    <div className="org-form-grid">
                        <label className="org-wide">
                            Para
                            <input
                                type="text"
                                value={form.to_emails}
                                disabled={!isAdmin}
                                onChange={(e) =>
                                    setForm({ ...form, to_emails: e.target.value })
                                }
                                placeholder="ti@empresa.com, respaldos@empresa.com"
                            />
                            <span className="notify-field-hint">
                                Si se deja vacío, se usan los destinatarios de Navegación.
                            </span>
                        </label>

                        <label className="org-wide">
                            Copia oculta (CCO)
                            <input
                                type="text"
                                value={form.bcc_emails}
                                disabled={!isAdmin}
                                onChange={(e) =>
                                    setForm({ ...form, bcc_emails: e.target.value })
                                }
                                placeholder="auditoria@empresa.com"
                            />
                            <span className="notify-field-hint">
                                Opcional. Los destinatarios en CCO no verán a los demás.
                            </span>
                        </label>

                        <label className="org-wide">
                            Asunto del correo
                            <input
                                type="text"
                                value={form.email_subject}
                                disabled={!isAdmin}
                                onChange={(e) =>
                                    setForm({ ...form, email_subject: e.target.value })
                                }
                                placeholder={backupSubjectDefault}
                            />
                            <span className="notify-field-hint">
                                Deje vacío para la plantilla predeterminada.
                                Variables: {(backupSubjectVars || [])
                                    .map((v) => `{${v}}`)
                                    .join(", ")}
                            </span>
                        </label>
                    </div>
                )}

                <div className="org-form-grid">

                    <label>
                        Hora de la copia
                        <input
                            type="time"
                            value={scheduleLabel}
                            disabled={!isAdmin}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setForm({ ...form, send_hour: Number(h), send_minute: Number(m) });
                            }}
                        />
                    </label>

                    <label>
                        Conservar (nº de copias)
                        <input
                            type="number"
                            value={form.retention_count}
                            disabled={!isAdmin}
                            onChange={(e) => setForm({ ...form, retention_count: e.target.value })}
                            min={1}
                            max={60}
                        />
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleSave}
                        disabled={busy || !isAdmin}
                    >
                        {busy ? "Guardando…" : "Guardar configuración"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleCreate}
                        disabled={busy || !isAdmin}
                    >
                        Generar copia ahora
                    </button>

                </SettingsActions>

            </SettingsBlock>

            <SettingsBlock
                title="Respaldo de logs en la nube"
                hint="Sube diariamente logs (auditoría, alertas, Suricata) cifrados al almacenamiento del cliente vía rclone."
            >

                <label className="org-checkbox-row">
                    <input
                        type="checkbox"
                        checked={cloudForm.enabled}
                        disabled={!isAdmin}
                        onChange={(e) => setCloudForm({ ...cloudForm, enabled: e.target.checked })}
                    />
                    Subida automática habilitada
                </label>

                <div className="org-form-grid">

                    <label className="org-wide">
                        Proveedor
                        <select
                            value={cloudForm.provider}
                            disabled={!isAdmin}
                            onChange={(e) => setCloudForm({ ...cloudForm, provider: e.target.value })}
                        >
                            <option value="s3">S3-compatible (B2, Wasabi, R2, MinIO…)</option>
                            <option value="sftp">SFTP</option>
                            <option value="webdav">WebDAV</option>
                        </select>
                    </label>

                    {cloudForm.provider === "s3" ? (
                        <>
                            <label className="org-wide">
                                Endpoint (URL del servicio S3)
                                <input
                                    type="text"
                                    value={cloudForm.endpoint}
                                    disabled={!isAdmin}
                                    placeholder="https://s3.us-west-004.backblazeb2.com"
                                    onChange={(e) => setCloudForm({ ...cloudForm, endpoint: e.target.value })}
                                />
                            </label>
                            <label>
                                Bucket
                                <input
                                    type="text"
                                    value={cloudForm.bucket}
                                    disabled={!isAdmin}
                                    placeholder="nombre-del-bucket"
                                    onChange={(e) => setCloudForm({ ...cloudForm, bucket: e.target.value })}
                                />
                            </label>
                            <label>
                                Access Key ID
                                <input
                                    type="text"
                                    value={cloudForm.access_key}
                                    disabled={!isAdmin}
                                    placeholder="dejar vacío para conservar la actual"
                                    onChange={(e) => setCloudForm({ ...cloudForm, access_key: e.target.value })}
                                />
                            </label>
                            <label>
                                Secret Access Key
                                <input
                                    type="password"
                                    value={cloudForm.secret_key}
                                    disabled={!isAdmin}
                                    placeholder="dejar vacío para conservar la actual"
                                    onChange={(e) => setCloudForm({ ...cloudForm, secret_key: e.target.value })}
                                />
                            </label>
                        </>
                    ) : (
                        <>
                            <label className="org-wide">
                                {cloudForm.provider === "sftp" ? "Servidor SFTP (host)" : "URL WebDAV"}
                                <input
                                    type="text"
                                    value={cloudForm.host}
                                    disabled={!isAdmin}
                                    placeholder="servidor.ejemplo.com"
                                    onChange={(e) => setCloudForm({ ...cloudForm, host: e.target.value })}
                                />
                            </label>
                            <label>
                                Usuario
                                <input
                                    type="text"
                                    value={cloudForm.user}
                                    disabled={!isAdmin}
                                    onChange={(e) => setCloudForm({ ...cloudForm, user: e.target.value })}
                                />
                            </label>
                            <label>
                                Contraseña
                                <input
                                    type="password"
                                    value={cloudForm.password}
                                    disabled={!isAdmin}
                                    placeholder="dejar vacío para conservar la actual"
                                    onChange={(e) => setCloudForm({ ...cloudForm, password: e.target.value })}
                                />
                            </label>
                        </>
                    )}

                    <label className="org-wide">
                        Carpeta remota (opcional)
                        <input
                            type="text"
                            value={cloudForm.remote_path}
                            disabled={!isAdmin}
                            placeholder="logs"
                            onChange={(e) => setCloudForm({ ...cloudForm, remote_path: e.target.value })}
                        />
                    </label>

                    <label>
                        Hora de subida
                        <input
                            type="time"
                            disabled={!isAdmin}
                            value={`${String(cloudForm.upload_hour).padStart(2, "0")}:${String(cloudForm.upload_minute).padStart(2, "0")}`}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setCloudForm({ ...cloudForm, upload_hour: Number(h), upload_minute: Number(m) });
                            }}
                        />
                    </label>

                    <label>
                        Días a subir por vez
                        <input
                            type="number"
                            value={cloudForm.upload_days}
                            disabled={!isAdmin}
                            min={1}
                            max={7}
                            onChange={(e) => setCloudForm({ ...cloudForm, upload_days: e.target.value })}
                        />
                    </label>

                </div>

                <SettingsActions>

                    <button
                        className="primary-button"
                        onClick={handleCloudSave}
                        disabled={cloudBusy || !isAdmin}
                    >
                        {cloudBusy ? "Guardando…" : "Guardar nube"}
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleCloudTest}
                        disabled={cloudBusy || !isAdmin}
                    >
                        Probar conexión
                    </button>

                    <button
                        className="secondary-button"
                        onClick={handleCloudUpload}
                        disabled={cloudBusy || !isAdmin}
                    >
                        Subir logs ahora
                    </button>

                </SettingsActions>

            </SettingsBlock>

            <SettingsBlock
                title="Restaurar desde archivo"
                hint="Sube un respaldo cifrado (.enc) para migrar la configuración a otro equipo."
            >

                {
                    isAdmin && (
                        <input
                            type="file"
                            accept=".enc"
                            onChange={handleUpload}
                            disabled={busy}
                        />
                    )
                }

            </SettingsBlock>

            <SettingsBlock
                title="Copias disponibles"
                hint="Descarga, restaura o elimina respaldos almacenados en este equipo."
            >

                <div className="org-table-wrap">

                    <table className="org-table">

                        <thead>
                            <tr>
                                <th>Archivo</th>
                                <th>Tamaño</th>
                                <th>Fecha</th>
                                {isAdmin && <th>Acciones</th>}
                            </tr>
                        </thead>

                        <tbody>

                            {
                                backups.length === 0 && (
                                    <tr>
                                        <td colSpan={isAdmin ? 4 : 3} className="org-table-empty">
                                            Aún no hay copias de seguridad.
                                        </td>
                                    </tr>
                                )
                            }

                            {
                                backups.map((backup) => (
                                    <tr key={backup.name}>

                                        <td className="org-code">{backup.name}</td>

                                        <td>{(backup.size / 1024 / 1024).toFixed(2)} MB</td>

                                        <td>{formatDateTime(backup.modified)}</td>

                                        {
                                            isAdmin && (
                                                <td>
                                                    <button
                                                        className="secondary-button small"
                                                        onClick={() => handleDownload(backup.name)}
                                                    >
                                                        Descargar
                                                    </button>
                                                    {" "}
                                                    <button
                                                        className="primary-button small"
                                                        onClick={() => handleRestore(backup.name)}
                                                        disabled={busy}
                                                    >
                                                        Restaurar
                                                    </button>
                                                    {" "}
                                                    <button
                                                        className="danger-button small"
                                                        onClick={() => handleDelete(backup.name)}
                                                        disabled={busy}
                                                    >
                                                        Eliminar
                                                    </button>
                                                </td>
                                            )
                                        }

                                    </tr>
                                ))
                            }

                        </tbody>

                    </table>

                </div>

            </SettingsBlock>

        </SettingsPanel>

    );

}


export default BackupSection;
