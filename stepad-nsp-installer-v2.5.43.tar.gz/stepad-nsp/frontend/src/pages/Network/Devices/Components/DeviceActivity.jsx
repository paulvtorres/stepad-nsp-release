import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import { getNavigationSummary } from "../../../../services/api";

import { formatDateTime } from "../../../../utils/datetime";


function toDateInputValue(date) {

    const y = date.getFullYear();

    const m = String(date.getMonth() + 1).padStart(2, "0");

    const d = String(date.getDate()).padStart(2, "0");

    return `${y}-${m}-${d}`;

}


function DeviceActivity({ device }) {

    const [rows, setRows] = useState([]);

    const [loading, setLoading] = useState(true);


    useEffect(() => {

        async function loadActivity() {

            if (!device)

                return;


            setLoading(true);


            try {

                const start = new Date();

                start.setDate(start.getDate() - 7);


                const data = await getNavigationSummary({

                    start: `${toDateInputValue(start)}T00:00:00`,

                    end: `${toDateInputValue(new Date())}T23:59:59`,

                    deviceId: String(device.id)

                });


                setRows(data || []);

            } catch (error) {

                console.error(error);

                setRows([]);

            } finally {

                setLoading(false);

            }

        }


        loadActivity();


    }, [device]);


    if (!device) {

        return <p>Selecciona un dispositivo...</p>;

    }


    const totalVisits = rows.reduce((sum, r) => sum + r.visit_count, 0);

    const totalBlocked = rows.reduce((sum, r) => sum + r.blocked_count, 0);


    return (

        <div className="card">

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>

                <h3>Actividad (últimos 7 días)</h3>


                <Link to="/logs" style={{ color: "var(--primary)", fontSize: 13 }}>

                    Ver el registro completo →

                </Link>

            </div>


            <p style={{ color: "var(--muted)", fontSize: 13, marginTop: -8 }}>

                Dominios consultados por este equipo. Las filas marcadas
                como bloqueadas no pudieron cargarse por la política de seguridad.

            </p>


            <p style={{ fontSize: 13 }}>

                <strong>{totalVisits}</strong> consultas ·{" "}

                <strong style={{ color: "var(--danger)" }}>{totalBlocked}</strong> bloqueadas

            </p>


            {
                loading && <p>Cargando actividad...</p>
            }


            {
                !loading && rows.length === 0 && (

                    <p style={{ color: "var(--muted)", fontSize: 13 }}>

                        Sin actividad registrada para este equipo en los últimos 7 días.

                    </p>

                )
            }


            {
                rows.length > 0 && (

                    <table>

                        <thead>

                            <tr>

                                <th>Dominio</th>

                                <th>Visitas</th>

                                <th>Bloqueadas</th>

                                <th>Última vez</th>

                            </tr>

                        </thead>


                        <tbody>

                            {
                                rows.map((row, index) => (

                                    <tr key={`${row.device_id}-${row.domain}-${index}`}>

                                        <td>
                                            {row.domain}
                                        </td>

                                        <td>
                                            {row.visit_count}
                                        </td>

                                        <td>
                                            {row.blocked_count > 0

                                                ? <span style={{ color: "var(--danger)" }}>{row.blocked_count}</span>

                                                : 0}
                                        </td>

                                        <td>
                                            {formatDateTime(row.last_seen, "-")}
                                        </td>

                                    </tr>

                                ))
                            }

                        </tbody>

                    </table>

                )
            }

        </div>

    );


}


export default DeviceActivity;
