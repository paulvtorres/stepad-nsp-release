// Hora de la empresa (Ecuador = UTC-5 todo el año, sin horario de verano).
// Se formatea restando 5 h al instante UTC para no depender de que el
// navegador tenga la base IANA "America/Guayaquil" (si falta, toLocaleString
// cae a UTC y las alertas salen 5 h adelantadas: 13:30 en vez de 08:30).

export const DISPLAY_TIMEZONE = "America/Guayaquil";

const ECUADOR_OFFSET_MS = 5 * 60 * 60 * 1000;

const WEEKDAYS_SHORT = ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"];

const MONTHS_SHORT = [
    "ene", "feb", "mar", "abr", "may", "jun",
    "jul", "ago", "sep", "oct", "nov", "dic"
];


function pad2(n) {

    return String(n).padStart(2, "0");

}


function normalizeIso(raw) {

    let value = raw.trim().replace(/ /g, "T");

    // Algunos navegadores fallan con microsegundos de 6 dígitos.
    value = value.replace(/(\.\d{3})\d+/, "$1");

    if (/[zZ]|[+-]\d{2}:?\d{2}$/.test(value)) {

        return value;

    }

    return value + "Z";

}


export function parseUtcDate(value) {

    if (value instanceof Date) {

        return Number.isNaN(value.getTime()) ? null : value;

    }

    if (value === null || value === undefined || value === "") {

        return null;

    }

    if (typeof value === "number") {

        const ms = value < 1e12 ? value * 1000 : value;

        const date = new Date(ms);

        return Number.isNaN(date.getTime()) ? null : date;

    }

    const date = new Date(normalizeIso(String(value)));

    if (Number.isNaN(date.getTime())) {

        return null;

    }

    return date;

}


/** Componentes de calendario en hora de Ecuador (UTC-5). */
function ecuadorParts(date) {

    const shifted = new Date(date.getTime() - ECUADOR_OFFSET_MS);

    return {
        year: shifted.getUTCFullYear(),
        month: shifted.getUTCMonth() + 1,
        day: shifted.getUTCDate(),
        weekday: shifted.getUTCDay(),
        hour: shifted.getUTCHours(),
        minute: shifted.getUTCMinutes(),
        second: shifted.getUTCSeconds()
    };

}


export function formatClock(date = new Date()) {

    const p = ecuadorParts(date);

    return (
        `${WEEKDAYS_SHORT[p.weekday]}, ${pad2(p.day)} ${MONTHS_SHORT[p.month - 1]}, `
        + `${pad2(p.hour)}:${pad2(p.minute)}:${pad2(p.second)}`
    );

}


export function formatDateTime(value, empty = "") {

    const date = parseUtcDate(value);

    if (!date) {

        return empty;

    }

    const p = ecuadorParts(date);

    return (
        `${p.day}/${p.month}/${p.year}, `
        + `${pad2(p.hour)}:${pad2(p.minute)}:${pad2(p.second)}`
    );

}


export function formatDate(value, empty = "") {

    const date = parseUtcDate(value);

    if (!date) {

        return empty;

    }

    const p = ecuadorParts(date);

    return `${p.day}/${p.month}/${p.year}`;

}
