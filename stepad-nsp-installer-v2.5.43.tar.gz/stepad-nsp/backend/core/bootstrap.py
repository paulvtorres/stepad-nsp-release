import os
import sys

from backend.shared.config.config_loader import config
from backend.shared.constants.app_constants import HEADER_WIDTH
from backend.shared.logging.logger import logger
from backend.shared.runtime import runtime

from backend.core.lifecycle.component_status import ComponentStatus
from backend.core.lifecycle.component_lifecycle_manager import ComponentLifecycleManager

from backend.core.components.core_component import CoreComponent

from backend.network.components.network_component import NetworkComponent

from backend.dhcp.components.dhcp_component import DhcpComponent

from backend.dns.components.dns_component import DnsComponent

from backend.nat.components.nat_component import NatComponent

from backend.api.components.api_component import ApiComponent

from backend.firewall.components.firewall_component import FirewallComponent

from backend.bandwidth.components.bandwidth_component import (
    BandwidthComponent
)

from backend.ips.components.ips_component import IpsComponent

from backend.rules.components.rules_component import RulesComponent

from backend.rules.components.schedule_enforcement_component import (
    ScheduleEnforcementComponent
)

from backend.network.zones.components.zone_component import ZoneComponent

from backend.network.interfaces.registry.components.interface_registry_component import (
    InterfaceRegistryComponent
)

from backend.vpn.components.vpn_component import VpnComponent
from backend.rustdesk.components.rustdesk_component import RustdeskComponent

from backend.notifications.components.notification_component import (
    NotificationComponent
)

from backend.backups.components.backup_component import BackupComponent

from backend.monitoring.components.monitoring_component import (
    MonitoringComponent
)

from backend.content.components.content_component import ContentComponent

class Bootstrap:


    def __init__(self):

        if os.geteuid() != 0:

            logger.error(
                "STEPAD NSP must be started with administrative privileges."
            )

            sys.exit(1)


        self.lifecycle = ComponentLifecycleManager()



    def start(self):

        logger.info("=" * HEADER_WIDTH)
        logger.info(config["app"]["name"])
        logger.info(config["app"]["description"])
        logger.info("=" * HEADER_WIDTH)
        logger.info("")


        self.lifecycle.register(
            CoreComponent()
        )


        self.lifecycle.register(
            InterfaceRegistryComponent()
        )


        self.lifecycle.register(
            NetworkComponent()
        )


        self.lifecycle.register(
            DhcpComponent()
        )    

        self.lifecycle.register(
            DnsComponent()
        )

        self.lifecycle.register(
            ZoneComponent()
        )

        self.lifecycle.register(FirewallComponent())

        self.lifecycle.register(BandwidthComponent())

        self.lifecycle.register(IpsComponent())

        self.lifecycle.register(RulesComponent())

        self.lifecycle.register(
            ScheduleEnforcementComponent()
        )

        self.lifecycle.register(
            NatComponent()
        )

        self.lifecycle.register(
            VpnComponent()
        )

        self.lifecycle.register(
            RustdeskComponent()
        )

        self.lifecycle.register(
            NotificationComponent()
        )

        self.lifecycle.register(
            BackupComponent()
        )

        self.lifecycle.register(
            MonitoringComponent()
        )

        self.lifecycle.register(
            ContentComponent()
        )

        self.lifecycle.register(
            ApiComponent()
        )
        

        self.lifecycle.start_all()



        runtime.set(
            "system",
            ComponentStatus.RUNNING.value
        )


        logger.info(
            f"Runtime state: {runtime.all()}"
        )

        logger.info("")

        logger.info(
            f"{config['app']['name']} is running."
        )



    def stop(self):

        self.lifecycle.stop_all()