import os
import signal
import subprocess
import time

import psutil

from backend.core.config.paths import (
    DNSMASQ_CONFIG,
    DNSMASQ_LOG_FILE,
    DNSMASQ_PID_FILE,
)

from backend.shared.process.subprocess_log import open_rotated_log

from backend.shared.logging.logger import logger


DNSMASQ_BIN = "/usr/sbin/dnsmasq"

STOP_TIMEOUT_SECONDS = 5

START_CHECK_DELAY_SECONDS = 0.3

# Tope del log propio de dnsmasq (rotación al reiniciar el proceso).
DNSMASQ_LOG_MAX_BYTES = 5 * 1024 * 1024

DNSMASQ_LOG_BACKUP_COUNT = 3


class DnsmasqProcessManager:
    """
    dnsmasq manages the DHCP lifecycle.
    DNS responsibilities can be handled by dnsmasq or delegated to
    another DNS engine depending on the configured settings.

    All operations that affect the dnsmasq process must go through
    this manager. (DNSMASQ_CONFIG, which conf-file-includes both
    blocked_domains.conf and reservations.conf). Every module that
    needs to apply changes to that process (domain rules, DHCP
    reservations, DHCP pool config) MUST go through this manager
    instead of independently signalling/spawning dnsmasq.

    Why a full restart and not SIGHUP:
    dnsmasq's SIGHUP handler only re-reads /etc/hosts, /etc/ethers,
    --dhcp-hostsfile, --dhcp-optsfile and --addn-hosts. It explicitly
    does NOT re-read the main configuration file, and address=/domain/
    directives (how we block domains) are only parsed at startup via
    conf-file=. So adding/removing a blocked domain requires killing
    and respawning the process — there is no lighter-weight option
    with this engine.

    La salida del proceso va a DNSMASQ_LOG_FILE (append), nunca a
    PIPE: un tubo sin lector bloquea dnsmasq y deja de repartir IP.
    El archivo se rota al arrancar si supera DNSMASQ_LOG_MAX_BYTES.
    """

    def __init__(self):

        self._log_file = None

    def _find_pid(self):

        if DNSMASQ_PID_FILE.exists():

            try:

                pid = int(
                    DNSMASQ_PID_FILE.read_text().strip()
                )

                if psutil.pid_exists(pid):

                    process = psutil.Process(pid)

                    if process.name() == "dnsmasq":

                        return pid

            except (ValueError, psutil.NoSuchProcess):

                pass

        # Fallback: scan by cmdline, matching OUR config file
        # specifically. Never match on process name alone -- this
        # host may be running an unrelated dnsmasq (NetworkManager,
        # libvirt, etc.) and killing that would be a serious bug.
        for process in psutil.process_iter(["pid", "name", "cmdline"]):

            if process.info["name"] != "dnsmasq":
                continue

            cmdline = " ".join(process.info.get("cmdline") or [])

            if str(DNSMASQ_CONFIG) in cmdline:

                return process.info["pid"]

        return None


    def status(self):

        pid = self._find_pid()

        return {
            "service": "dhcp",
            "running": pid is not None,
            "pid": pid
        }

    def _close_log_file(self) -> None:

        if self._log_file is None:

            return

        try:

            self._log_file.close()

        except Exception:

            pass

        finally:

            self._log_file = None

    def _open_log_file(self):

        self._close_log_file()

        self._log_file = open_rotated_log(
            DNSMASQ_LOG_FILE,
            DNSMASQ_LOG_MAX_BYTES,
            DNSMASQ_LOG_BACKUP_COUNT,
        )

        return self._log_file

    def stop(self):

        pid = self._find_pid()

        if not pid:

            self._close_log_file()

            return {
                "success": True,
                "message": "dnsmasq not running"
            }

        try:

            os.kill(pid, signal.SIGTERM)

            psutil.Process(pid).wait(
                timeout=STOP_TIMEOUT_SECONDS
            )

        except psutil.NoSuchProcess:

            pass

        except psutil.TimeoutExpired:

            logger.warning(
                f"dnsmasq (pid {pid}) did not stop gracefully, sending SIGKILL"
            )

            os.kill(pid, signal.SIGKILL)

        if DNSMASQ_PID_FILE.exists():

            DNSMASQ_PID_FILE.unlink()

        self._close_log_file()

        return {
            "success": True,
            "message": f"dnsmasq (pid {pid}) stopped"
        }


    def start(self):

        if not os.path.exists(DNSMASQ_BIN):

            return {
                "success": False,
                "error": "dnsmasq not installed"
            }

        existing = self._find_pid()

        if existing:

            return {
                "success": True,
                "pid": existing,
                "message": "dnsmasq already running"
            }

        DNSMASQ_CONFIG.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        log_stream = self._open_log_file()

        process = subprocess.Popen(
            [
                DNSMASQ_BIN,
                "--no-daemon",
                "--conf-file=" + str(DNSMASQ_CONFIG)
            ],
            stdout=log_stream,
            stderr=subprocess.STDOUT,
        )

        time.sleep(START_CHECK_DELAY_SECONDS)

        if process.poll() is not None:

            logger.error(
                "dnsmasq failed to start (exit %s)",
                process.returncode,
            )

            self._close_log_file()

            return {
                "success": False,
                "error": (
                    f"dnsmasq failed to start (exit {process.returncode})"
                ),
            }

        return {
            "success": True,
            "pid": process.pid,
            "message": "dnsmasq started"
        }


    def restart(self):

        from backend.shared.runtime.resource_locks import resource_locks

        with resource_locks.dnsmasq:
            self.stop()
            return self.start()


dnsmasq_process_manager = DnsmasqProcessManager()
