from backend.dhcp.services.dhcp_health_service import udp67_recv_queue_bytes


def test_udp67_recv_queue_parses_stuck_dnsmasq():

    ss = (
        "State  Recv-Q Send-Q Local Address:Port Peer Address:Port Process\n"
        'UNCONN 213760 0 0.0.0.0%enp3s0:67 0.0.0.0:* '
        'users:(("dnsmasq",pid=115301,fd=4))\n'
        'UNCONN 0 0 192.168.1.1:53 0.0.0.0:* '
        'users:(("pdns_recursor",pid=1,fd=4))\n'
    )

    assert udp67_recv_queue_bytes(ss) == 213760


def test_udp67_recv_queue_zero_when_healthy():

    ss = (
        'UNCONN 0 0 0.0.0.0%enp3s0:67 0.0.0.0:* '
        'users:(("dnsmasq",pid=297624,fd=4))\n'
    )

    assert udp67_recv_queue_bytes(ss) == 0


def test_udp67_ignores_other_listeners():

    ss = (
        'UNCONN 99999 0 0.0.0.0:67 0.0.0.0:* '
        'users:(("otherdhcp",pid=1,fd=4))\n'
    )

    assert udp67_recv_queue_bytes(ss) == 0
