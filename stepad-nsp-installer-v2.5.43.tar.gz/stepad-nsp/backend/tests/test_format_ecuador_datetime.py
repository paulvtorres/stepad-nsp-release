from datetime import datetime

from backend.shared.utils.datetimes import format_ecuador_datetime


def test_format_ecuador_datetime_from_utc_naive():

    value = datetime(2026, 9, 1, 18, 58, 19)

    assert format_ecuador_datetime(value) == "01/09/2026, 13:58:19"
