from unittest.mock import MagicMock, patch

from backend.notifications.services.critical_alert_email_service import (
    CriticalAlertEmailService,
)


def test_critical_alert_uses_alert_recipients_not_navigation():

    settings = MagicMock()
    settings.alert_email_enabled = True
    settings.alert_emails = "noc@empresa.com"
    settings.alert_cc_emails = ""
    settings.alert_bcc_emails = ""
    settings.alert_subject = ""

    db = MagicMock()

    with patch(
        "backend.notifications.services.critical_alert_email_service."
        "NotificationSettingsRepository"
    ) as repo_cls, patch(
        "backend.notifications.services.critical_alert_email_service."
        "build_delivery_context"
    ) as build_ctx, patch(
        "backend.notifications.services.critical_alert_email_service."
        "build_alert_subject",
        return_value="Alerta test",
    ), patch(
        "backend.notifications.services.critical_alert_email_service."
        "EmailService"
    ) as email_cls:

        repo_cls.return_value.get.return_value = settings
        build_ctx.return_value = MagicMock()
        email_cls.return_value.send_html.return_value = {"success": True}

        sent = CriticalAlertEmailService().send(
            db,
            "DHCP caído",
            "dnsmasq no responde",
        )

    assert sent is True
    build_ctx.assert_called_once_with(
        db,
        to_emails="noc@empresa.com",
        cc_emails="",
        bcc_emails="",
    )


def test_critical_alert_skipped_when_disabled():

    settings = MagicMock()
    settings.alert_email_enabled = False

    db = MagicMock()

    with patch(
        "backend.notifications.services.critical_alert_email_service."
        "NotificationSettingsRepository"
    ) as repo_cls, patch(
        "backend.notifications.services.critical_alert_email_service."
        "build_delivery_context"
    ) as build_ctx:

        repo_cls.return_value.get.return_value = settings

        sent = CriticalAlertEmailService().send(
            db,
            "FALLO de internet (WAN)",
            "WAN caída",
        )

    assert sent is False
    build_ctx.assert_not_called()
