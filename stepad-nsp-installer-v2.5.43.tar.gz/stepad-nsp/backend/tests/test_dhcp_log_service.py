from pathlib import Path

import os

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from backend.dhcp.services.dhcp_log_service import DhcpLogService


def test_dhcp_log_tail_filters_and_limits(tmp_path, monkeypatch):

    log_file = tmp_path / "dnsmasq.log"

    log_file.write_text(
        "line old\n"
        "DHCPACK 192.168.1.79 VENTAS\n"
        "DHCPDISCOVER f4:30:b9 ninguna dirección disponible\n"
        "line newest\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_log_service.DNSMASQ_LOG_FILE",
        log_file,
    )

    service = DhcpLogService()

    data = service.tail(lines=2, search="dhcp")

    assert data["count"] == 2
    assert "VENTAS" in data["lines"][0]
    assert "ninguna dirección" in data["lines"][1]
