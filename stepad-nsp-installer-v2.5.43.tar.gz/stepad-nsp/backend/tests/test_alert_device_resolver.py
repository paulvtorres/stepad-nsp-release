from unittest.mock import patch

from backend.alerts.services.alert_device_resolver import (
    client_ip_from_ips_message,
)


@patch(
    "backend.alerts.services.alert_device_resolver.ConfigService"
)
def test_client_ip_prefers_lan_address_after_arrow(mock_config):

    mock_config.return_value.get_dhcp_config.return_value = {
        "network": "192.168.1.0",
        "netmask": "255.255.255.0",
    }

    message = (
        "ET P2P BitTorrent | Privacy | "
        "66.225.197.106 -> 192.168.1.106:58692"
    )

    assert client_ip_from_ips_message(message) == "192.168.1.106"


@patch(
    "backend.alerts.services.alert_device_resolver.ConfigService"
)
def test_client_ip_when_lan_is_source(mock_config):

    mock_config.return_value.get_dhcp_config.return_value = {
        "network": "192.168.1.0",
        "netmask": "255.255.255.0",
    }

    message = "Malware | cat | 192.168.1.36 -> 67.213.116.181:443"

    assert client_ip_from_ips_message(message) == "192.168.1.36"
