from unittest.mock import MagicMock, patch

from backend.notifications.services.quarantine_email_service import (
    QuarantineEmailService,
)


def test_quarantine_email_uses_own_recipients():

    settings = MagicMock()
    settings.quarantine_email_enabled = True
    settings.quarantine_emails = "ti@empresa.com"
    settings.quarantine_cc_emails = ""
    settings.quarantine_bcc_emails = ""
    settings.alert_subject = ""

    db = MagicMock()

    with patch(
        "backend.notifications.services.quarantine_email_service."
        "NotificationSettingsRepository"
    ) as repo_cls, patch(
        "backend.notifications.services.quarantine_email_service."
        "build_delivery_context"
    ) as build_ctx, patch(
        "backend.notifications.services.quarantine_email_service."
        "build_alert_subject",
        return_value="Cuarentena",
    ), patch(
        "backend.notifications.services.quarantine_email_service."
        "EmailService"
    ) as email_cls:

        repo_cls.return_value.get.return_value = settings
        build_ctx.return_value = MagicMock()
        email_cls.return_value.send_html.return_value = {"success": True}

        sent = QuarantineEmailService().send(
            db,
            "CUARENTENA: RRHH",
            "aislado",
            device_name="RRHH",
            ip="192.168.1.36",
            mac="34:97:f6:8e:f8:1b",
            signature="ET HUNTING",
        )

    assert sent is True
    build_ctx.assert_called_once_with(
        db,
        to_emails="ti@empresa.com",
        cc_emails="",
        bcc_emails="",
    )
