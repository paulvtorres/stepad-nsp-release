from pathlib import Path

from backend.shared.logging.log_rotation import rotate_log_file


def test_rotate_log_file_when_over_limit(tmp_path: Path):

    log_file = tmp_path / "stepad.log"

    log_file.write_bytes(b"x" * 100)

    rotate_log_file(log_file, max_bytes=50, backup_count=3)

    assert not log_file.exists()
    assert (tmp_path / "stepad.log.1").exists()
    assert (tmp_path / "stepad.log.1").read_bytes() == b"x" * 100


def test_rotate_log_file_skips_when_under_limit(tmp_path: Path):

    log_file = tmp_path / "stepad.log"

    log_file.write_bytes(b"ok")

    rotate_log_file(log_file, max_bytes=50, backup_count=3)

    assert log_file.read_bytes() == b"ok"
    assert not (tmp_path / "stepad.log.1").exists()
