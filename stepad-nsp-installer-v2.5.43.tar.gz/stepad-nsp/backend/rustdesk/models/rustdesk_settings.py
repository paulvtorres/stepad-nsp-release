from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class RustdeskSettings(Base):

    __tablename__ = "rustdesk_settings"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
    )

    # Servidor hbbs/hbbr activo en el NSP.
    enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
    )

    # Abrir puertos RustDesk en WAN (trabajo remoto desde Internet).
    # Si está en false, solo LAN (ya permitida por hardening).
    expose_wan: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
    )

    # Host público/DNS que deben usar los clientes (opcional).
    # Vacío = IP WAN detectada del NSP.
    public_host: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    installed_version: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )
