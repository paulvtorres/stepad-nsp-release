"""
Proveedor OS para RustDesk Server OSS (hbbs + hbbr).

Binarios y datos bajo /etc/stepad/rustdesk (ReadWritePaths del NSP).
Unidades systemd: stepad-rustdesk-hbbs / stepad-rustdesk-hbbr.
"""

from __future__ import annotations

import platform
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from backend.shared.logging.logger import logger


# Versión OSS fijada (reproducible en instalaciones).
RUSTDESK_SERVER_VERSION = "1.1.14"

# Puertos mínimos (señalización + relay). Sin web client (21118/21119).
TCP_PORTS = (21115, 21116, 21117)
UDP_PORTS = (21116,)

HBBS_UNIT = "stepad-rustdesk-hbbs.service"
HBBR_UNIT = "stepad-rustdesk-hbbr.service"


class RustdeskProvider:

    CONFIG_DIR = Path("/etc/stepad/rustdesk")
    BIN_DIR = CONFIG_DIR / "bin"
    DATA_DIR = CONFIG_DIR / "data"
    HBBS_BIN = BIN_DIR / "hbbs"
    HBBR_BIN = BIN_DIR / "hbbr"
    PUB_KEY = DATA_DIR / "id_ed25519.pub"
    PRIV_KEY = DATA_DIR / "id_ed25519"

    def run_command(self, command: list[str], cwd: str | None = None) -> dict:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            cwd=cwd,
        )
        return {
            "success": result.returncode == 0,
            "output": (result.stdout or "").strip(),
            "error": (result.stderr or "").strip(),
        }

    def _arch_asset(self) -> str:
        machine = platform.machine().lower()
        if machine in ("x86_64", "amd64"):
            return "amd64"
        if machine in ("aarch64", "arm64"):
            return "arm64"
        if machine in ("armv7l", "armhf"):
            return "armv7"
        raise RuntimeError(f"Arquitectura no soportada para RustDesk: {machine}")

    def is_installed(self) -> bool:
        return self.HBBS_BIN.is_file() and self.HBBR_BIN.is_file()

    def public_key(self) -> str | None:
        if not self.PUB_KEY.is_file():
            return None
        return self.PUB_KEY.read_text(encoding="utf-8").strip() or None

    def unit_active(self, unit: str) -> bool:
        result = self.run_command(["systemctl", "is-active", unit])
        return result["output"] == "active"

    def status(self) -> dict:
        return {
            "installed": self.is_installed(),
            "version": RUSTDESK_SERVER_VERSION if self.is_installed() else None,
            "hbbs_active": self.unit_active(HBBS_UNIT),
            "hbbr_active": self.unit_active(HBBR_UNIT),
            "public_key": self.public_key(),
            "tcp_ports": list(TCP_PORTS),
            "udp_ports": list(UDP_PORTS),
            "data_dir": str(self.DATA_DIR),
        }

    def ensure_dirs(self) -> None:
        self.BIN_DIR.mkdir(parents=True, exist_ok=True)
        self.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.CONFIG_DIR.chmod(0o755)
        self.DATA_DIR.chmod(0o700)

    def install(self) -> dict:
        """Descarga hbbs/hbbr desde GitHub releases e instala unidades."""

        self.ensure_dirs()

        arch = self._arch_asset()
        url = (
            "https://github.com/rustdesk/rustdesk-server/releases/download/"
            f"{RUSTDESK_SERVER_VERSION}/rustdesk-server-linux-{arch}.zip"
        )

        logger.info("RustDesk: descargando %s", url)

        try:
            with tempfile.TemporaryDirectory(prefix="stepad-rustdesk-") as tmp:
                tmp_path = Path(tmp)
                zip_path = tmp_path / "rustdesk-server.zip"

                with urllib.request.urlopen(url, timeout=120) as response:
                    zip_path.write_bytes(response.read())

                extract_dir = tmp_path / "extract"
                extract_dir.mkdir()

                with zipfile.ZipFile(zip_path, "r") as zf:
                    zf.extractall(extract_dir)

                hbbs = self._find_binary(extract_dir, "hbbs")
                hbbr = self._find_binary(extract_dir, "hbbr")

                if not hbbs or not hbbr:
                    return {
                        "success": False,
                        "error": "El paquete no contiene hbbs/hbbr",
                    }

                shutil.copy2(hbbs, self.HBBS_BIN)
                shutil.copy2(hbbr, self.HBBR_BIN)
                self.HBBS_BIN.chmod(0o755)
                self.HBBR_BIN.chmod(0o755)

        except Exception as error:
            logger.error("RustDesk install falló: %s", error)
            return {"success": False, "error": str(error)}

        units = self.write_units(relay_host="127.0.0.1")
        if not units.get("success"):
            return units

        reload = self.run_command(["systemctl", "daemon-reload"])
        if not reload["success"]:
            return {
                "success": False,
                "error": reload["error"] or "daemon-reload falló",
            }

        logger.info(
            "RustDesk server %s instalado en %s",
            RUSTDESK_SERVER_VERSION,
            self.BIN_DIR,
        )

        return {
            "success": True,
            "version": RUSTDESK_SERVER_VERSION,
        }

    def _find_binary(self, root: Path, name: str) -> Path | None:
        matches = [p for p in root.rglob(name) if p.is_file()]
        return matches[0] if matches else None

    def write_units(self, relay_host: str) -> dict:
        """
        Escribe unidades systemd. relay_host es el host que hbbs anuncia
        a los clientes para el relay (IP/DNS público o LAN), sin puerto.
        """

        host = (relay_host or "127.0.0.1").strip()
        # Evitar inyección en unit file.
        if any(ch in host for ch in (" ", "\n", "\r", ";", "|", "&", "`")):
            return {"success": False, "error": "Host de relay inválido"}

        hbbr_unit = f"""[Unit]
Description=STEPAD RustDesk Relay (hbbr)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={self.DATA_DIR}
ExecStart={self.HBBR_BIN}
Restart=always
RestartSec=3
LimitNOFILE=100000

[Install]
WantedBy=multi-user.target
"""

        hbbs_unit = f"""[Unit]
Description=STEPAD RustDesk ID/Rendezvous (hbbs)
After=network-online.target {HBBR_UNIT}
Wants=network-online.target
Requires={HBBR_UNIT}

[Service]
Type=simple
WorkingDirectory={self.DATA_DIR}
ExecStart={self.HBBS_BIN} -r {host}:21117
Restart=always
RestartSec=3
LimitNOFILE=100000

[Install]
WantedBy=multi-user.target
"""

        try:
            Path(f"/etc/systemd/system/{HBBR_UNIT}").write_text(
                hbbr_unit, encoding="utf-8"
            )
            Path(f"/etc/systemd/system/{HBBS_UNIT}").write_text(
                hbbs_unit, encoding="utf-8"
            )
        except OSError as error:
            return {
                "success": False,
                "error": (
                    f"No se pudieron escribir unidades systemd: {error}. "
                    "Añada /etc/systemd/system a ReadWritePaths de "
                    "stepad-nsp.service"
                ),
            }

        return {"success": True}

    def start(self) -> dict:
        if not self.is_installed():
            return {"success": False, "error": "RustDesk no instalado"}

        self.ensure_dirs()

        for unit in (HBBR_UNIT, HBBS_UNIT):
            enable = self.run_command(["systemctl", "enable", unit])
            if not enable["success"]:
                return {
                    "success": False,
                    "error": enable["error"] or f"No se pudo habilitar {unit}",
                }

        # restart aplica cambios de ExecStart (-r host) si ya corría.
        for unit in (HBBR_UNIT, HBBS_UNIT):
            restarted = self.run_command(["systemctl", "restart", unit])
            if not restarted["success"]:
                return {
                    "success": False,
                    "error": restarted["error"] or f"No se pudo iniciar {unit}",
                }

        return {"success": True, "public_key": self.public_key()}

    def stop(self) -> dict:
        for unit in (HBBS_UNIT, HBBR_UNIT):
            self.run_command(["systemctl", "disable", "--now", unit])
        return {"success": True}

    def restart(self) -> dict:
        stopped = self.stop()
        if not stopped.get("success"):
            return stopped
        return self.start()
