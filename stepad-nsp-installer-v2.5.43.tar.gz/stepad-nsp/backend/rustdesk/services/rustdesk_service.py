"""
Servicio de dominio: RustDesk self-hosted en el NSP.
"""

from __future__ import annotations

from datetime import datetime

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.audit.services.audit_service import AuditService
from backend.core.database.session import SessionLocal
from backend.network.interfaces.services.interface_service import (
    InterfaceService,
)
from backend.rustdesk.models.rustdesk_settings import RustdeskSettings
from backend.rustdesk.services.rustdesk_provider import (
    TCP_PORTS,
    UDP_PORTS,
    RustdeskProvider,
)
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


CLIENT_DOWNLOAD = {
    "windows": "https://github.com/rustdesk/rustdesk/releases/latest",
    "macos": "https://github.com/rustdesk/rustdesk/releases/latest",
    "linux": "https://github.com/rustdesk/rustdesk/releases/latest",
    "android": "https://rustdesk.com/",
}


class RustdeskService:

    def __init__(self):
        self.provider = RustdeskProvider()
        self.interface_service = InterfaceService()
        self.audit_service = AuditService()

    def _row(self, db: Session) -> RustdeskSettings:
        row = db.get(RustdeskSettings, 1)
        if row is None:
            row = RustdeskSettings(
                id=1,
                enabled=False,
                expose_wan=False,
            )
            db.add(row)
            db.commit()
            db.refresh(row)
        return row

    def _detected_wan_ip(self) -> str | None:
        wan = self.interface_service.get_primary_wan()
        if not wan:
            return None
        ip = getattr(wan, "ip", None) or getattr(wan, "ipv4_address", None)
        return ip.strip() if isinstance(ip, str) and ip.strip() else None

    def _detected_lan_ip(self) -> str | None:
        lan = self.interface_service.get_primary_lan()
        if not lan:
            return None
        ip = getattr(lan, "ip", None) or getattr(lan, "ipv4_address", None)
        return ip.strip() if isinstance(ip, str) and ip.strip() else None

    def resolve_public_host(self, row: RustdeskSettings) -> str | None:
        if row.public_host and row.public_host.strip():
            return row.public_host.strip()
        return self._detected_wan_ip()

    def resolve_client_host(self, row: RustdeskSettings) -> str | None:
        """
        Host que deben poner los clientes en ID/Relay server.
        Con expose_wan: público; sin él: LAN del NSP.
        """
        if row.expose_wan:
            return self.resolve_public_host(row)
        return self._detected_lan_ip() or self.resolve_public_host(row)

    def get_status(self, db: Session) -> dict:
        row = self._row(db)
        runtime = self.provider.status()
        client_host = self.resolve_client_host(row) if row.enabled else None

        return {
            "enabled": bool(row.enabled),
            "expose_wan": bool(row.expose_wan),
            "public_host": row.public_host,
            "installed_version": row.installed_version,
            "updated_at": to_iso_utc(row.updated_at) if row.updated_at else None,
            "installed": runtime["installed"],
            "hbbs_active": runtime["hbbs_active"],
            "hbbr_active": runtime["hbbr_active"],
            "public_key": runtime["public_key"],
            "tcp_ports": runtime["tcp_ports"],
            "udp_ports": runtime["udp_ports"],
            "detected_wan_ip": self._detected_wan_ip(),
            "detected_lan_ip": self._detected_lan_ip(),
            "client_host": client_host,
            "client_id_server": client_host,
            "client_relay_server": client_host,
            "client_downloads": CLIENT_DOWNLOAD,
            "ready": bool(
                row.enabled
                and runtime["hbbs_active"]
                and runtime["hbbr_active"]
                and runtime["public_key"]
            ),
        }

    def wan_ports_exposed(self, db: Session | None = None) -> bool:
        """True si el hardening debe abrir RustDesk en WAN."""

        owns = db is None
        if owns:
            db = SessionLocal()
        try:
            row = db.get(RustdeskSettings, 1)
            return bool(row and row.enabled and row.expose_wan)
        finally:
            if owns:
                db.close()

    def apply_config(
        self,
        db: Session,
        *,
        enabled: bool | None = None,
        expose_wan: bool | None = None,
        public_host: str | None = ...,
        changed_by: int | None = None,
    ) -> dict:
        row = self._row(db)

        if enabled is not None:
            row.enabled = bool(enabled)

        if expose_wan is not None:
            row.expose_wan = bool(expose_wan)

        if public_host is not ...:
            cleaned = (public_host or "").strip() or None
            row.public_host = cleaned

        if row.enabled:
            result = self._ensure_running(row)
            if not result.get("success"):
                raise HTTPException(
                    status_code=500,
                    detail=result.get("error") or "No se pudo activar RustDesk",
                )
            row.installed_version = result.get("version") or row.installed_version
        else:
            self.provider.stop()

        row.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(row)

        self._refresh_hardening()

        self.audit_service.create_log(
            db=db,
            user_id=changed_by,
            action="RUSTDESK_UPDATED",
            resource="RUSTDESK",
            description=(
                f"RustDesk enabled={row.enabled} "
                f"expose_wan={row.expose_wan} "
                f"host={row.public_host or '-'}"
            ),
        )

        return self.get_status(db)

    def _ensure_running(self, row: RustdeskSettings) -> dict:
        if not self.provider.is_installed():
            installed = self.provider.install()
            if not installed.get("success"):
                return installed

        relay_host = self.resolve_public_host(row) or "127.0.0.1"
        # Clientes remotos necesitan el host público/LAN en -r, no 127.0.0.1.
        client_relay = self.resolve_client_host(row) or relay_host

        written = self.provider.write_units(relay_host=client_relay)
        if not written.get("success"):
            return written

        reload = self.provider.run_command(["systemctl", "daemon-reload"])
        if not reload["success"]:
            return {
                "success": False,
                "error": reload["error"] or "daemon-reload falló",
            }

        started = self.provider.start()
        if not started.get("success"):
            return started

        # Esperar clave tras primer arranque.
        if not self.provider.public_key():
            import time

            for _ in range(10):
                time.sleep(0.5)
                if self.provider.public_key():
                    break

        return {
            "success": True,
            "version": self.provider.status().get("version"),
            "public_key": self.provider.public_key(),
        }

    def ensure_boot(self) -> None:
        """Llamado al arrancar el componente: mantiene servicio si está enabled."""

        db = SessionLocal()
        try:
            row = db.get(RustdeskSettings, 1)
            if not row or not row.enabled:
                return

            result = self._ensure_running(row)
            if not result.get("success"):
                logger.error("RustDesk boot: %s", result.get("error"))
            else:
                logger.info("RustDesk activo (hbbs/hbbr).")

            if row.expose_wan:
                self._refresh_hardening()

        finally:
            db.close()

    def _refresh_hardening(self) -> None:
        try:
            from backend.firewall.services.firewall_hardening_service import (
                FirewallHardeningService,
            )

            hardening = FirewallHardeningService()
            settings = hardening.get_settings()
            if settings.get("hardening_enabled"):
                # Reaplica deny-all + allowlist (incluye puertos RustDesk).
                hardening.set_enabled(True)
        except Exception as error:
            logger.warning("RustDesk: no se pudo refrescar hardening: %s", error)


# Expose port constants for firewall.
RUSTDESK_TCP_PORTS = TCP_PORTS
RUSTDESK_UDP_PORTS = UDP_PORTS
