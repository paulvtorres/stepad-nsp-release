from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.rustdesk.services.rustdesk_service import RustdeskService
from backend.shared.logging.logger import logger


class RustdeskComponent(BaseComponent):

    name = "rustdesk"

    criticality = ComponentCriticality.OPTIONAL

    def __init__(self):
        self.service = RustdeskService()

    def start(self):
        logger.info("RustdeskComponent started.")
        try:
            self.service.ensure_boot()
        except Exception as error:
            logger.error("RustDesk boot error: %s", error)

    def stop(self):
        logger.info("RustdeskComponent stopped.")
