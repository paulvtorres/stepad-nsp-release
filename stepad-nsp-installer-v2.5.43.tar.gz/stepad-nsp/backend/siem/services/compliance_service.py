import io

from datetime import datetime, timezone, timedelta

from sqlalchemy.orm import Session

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter


def _to_local(value):
    """Los timestamps se guardan en UTC (naive). Se convierten a la hora
    local del sistema antes de escribirlos en Excel, para que el reporte
    muestre la hora correcta del cliente."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone().replace(tzinfo=None)

from backend.siem.repositories.siem_repositories import (
    ComplianceSettingsRepository
)
from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository
)
from backend.users.models.user import User
from backend.audit.repositories.audit_repository import AuditRepository
from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)
from backend.alerts.models.alert import Alert
from backend.alerts.repositories.alert_repository import AlertRepository
from backend.shared.runtime import runtime
from backend.shared.utils.datetimes import to_iso_utc
from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)
from backend.nat.repositories.port_forward_repository import (
    PortForwardRepository
)
from backend.vpn.repositories.vpn_peer_repository import VpnPeerRepository


class ComplianceService:

    def __init__(self):

        self.compliance_repo = ComplianceSettingsRepository()

        self.org_repo = OrganizationSettingsRepository()

        self.audit_repo = AuditRepository()

        self.query_repo = DnsQueryLogRepository()

        self.alert_repo = AlertRepository()

        self.zone_repo = NetworkZoneRepository()

        self.port_forward_repo = PortForwardRepository()

        self.vpn_repo = VpnPeerRepository()

    def get_retention(
        self,
        db: Session
    ) -> dict:

        settings = self.compliance_repo.get(db)

        return {
            "log_retention_days": settings.log_retention_days
        }

    def save_retention(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.compliance_repo.get(db)

        if data.log_retention_days is not None:

            settings.log_retention_days = data.log_retention_days

        self.compliance_repo.save(db, settings)

        return self.get_retention(db)

    def retention_days(
        self,
        db: Session
    ) -> int:

        return self.compliance_repo.get(db).log_retention_days

    def get_logs_review(
        self,
        db: Session
    ) -> dict:

        settings = self.compliance_repo.get(db)

        last = settings.last_logs_review

        frequency = settings.logs_review_frequency_days or 7

        overdue = True

        if last:

            overdue = (
                datetime.utcnow() - last > timedelta(days=frequency)
            )

        return {
            "reviewer_email": settings.logs_reviewer_email,
            "frequency_days": frequency,
            "last_review": to_iso_utc(last),
            "overdue": overdue,
        }

    def save_logs_review(
        self,
        db: Session,
        email: str | None,
        frequency_days: int | None
    ) -> dict:

        settings = self.compliance_repo.get(db)

        if email is not None:

            settings.logs_reviewer_email = (
                email.strip() or None
            )

        if frequency_days is not None and frequency_days > 0:

            settings.logs_review_frequency_days = frequency_days

        self.compliance_repo.save(db, settings)

        return self.get_logs_review(db)

    def mark_logs_review(
        self,
        db: Session
    ) -> dict:

        settings = self.compliance_repo.get(db)

        settings.last_logs_review = datetime.utcnow()

        self.compliance_repo.save(db, settings)

        return self.get_logs_review(db)

    def check_logs_review_alert(
        self,
        db: Session
    ) -> dict:

        data = self.get_logs_review(db)

        if not data["overdue"]:

            return {"created": False}

        pending = (
            db.query(Alert)
            .filter(
                Alert.alert_type == "logs_review_overdue",
                Alert.read.is_(False)
            )
            .count()
        )

        if pending > 0:

            return {"created": False}

        self.alert_repo.create(
            db,
            Alert(
                alert_type="logs_review_overdue",
                severity="warning",
                title="Revisión de logs pendiente",
                message=(
                    "El responsable de revisión de logs debe revisar "
                    "los registros (cumplimiento de la política de "
                    "monitoreo)."
                )
            )
        )

        return {"created": True}

    def build_excel(
        self,
        db: Session,
        start: datetime | None = None,
        end: datetime | None = None
    ) -> io.BytesIO:

        org = self.org_repo.get(db)

        users = db.query(User).all()

        audit = self.audit_repo.find_filtered(
            db,
            start=start,
            end=end,
            limit=300
        )

        blocked_rows = [
            row for row in self.query_repo.find_summary(
                db, start=start, end=end
            )
            if (row.blocked_count or 0) > 0
        ]

        alerts = self.alert_repo.list(db, limit=500)

        zones = self.zone_repo.find_all(db)

        forwards = self.port_forward_repo.find_all(db)

        peers = self.vpn_repo.find_all(db)

        components = runtime.all()

        running = sum(
            1 for s in components.values()
            if s.get("status") == "running"
        )

        severity_counts = {"critical": 0, "warning": 0, "info": 0}

        for alert in alerts:

            severity_counts[alert.severity] = (
                severity_counts.get(alert.severity, 0) + 1
            )

        total_blocked = sum(r.blocked_count or 0 for r in blocked_rows)

        workbook = Workbook()

        header_font = Font(bold=True, color="FFFFFF")

        header_fill = PatternFill("solid", fgColor="1E3A8A")

        title_font = Font(bold=True, size=14)

        def style(sheet, widths):

            for cell in sheet[1]:

                cell.font = header_font

                cell.fill = header_fill

            sheet.auto_filter.ref = sheet.dimensions

            sheet.freeze_panes = "A2"

            for index, width in enumerate(widths, start=1):

                sheet.column_dimensions[
                    get_column_letter(index)
                ].width = width

        # --- Resumen ---
        resumen = workbook.active

        resumen.title = "Resumen"

        rows_data = [
            ("EMPRESA", org.company_name),
            ("RUC", org.ruc or "—"),
            ("PERÍODO", (
                f"{start.strftime('%d/%m/%Y') if start else '—'} → "
                f"{end.strftime('%d/%m/%Y') if end else '—'}"
            )),
            ("GENERADO", datetime.now().strftime("%d/%m/%Y %H:%M")),
            ("ESTADO DEL SISTEMA", (
                "healthy" if running == len(components) else "degraded"
            )),
            ("COMPONENTES", f"{running}/{len(components)} activos"),
            ("USUARIOS", len(users)),
            ("CONSULTAS BLOQUEADAS", total_blocked),
            ("ALERTAS CRÍTICAS", severity_counts.get("critical", 0)),
            ("ALERTAS DE ADVERTENCIA", severity_counts.get("warning", 0)),
            ("ZONAS (VLAN/subred)", len(zones)),
            ("REENVÍOS DE PUERTO (DMZ)", len(forwards)),
            ("PEERS VPN", len(peers)),
        ]

        for label, value in rows_data:

            resumen.append([label, value])

        for row in resumen.iter_rows(min_row=1, max_row=1):

            for cell in row:

                cell.font = title_font

        for cell in resumen["A"]:

            cell.font = Font(bold=True)

        resumen.column_dimensions["A"].width = 32

        resumen.column_dimensions["B"].width = 50

        # --- Usuarios ---
        usr = workbook.create_sheet("Usuarios")

        usr.append(
            ["Usuario", "Rol", "Activo", "Último acceso",
             "Cambio de contraseña"]
        )

        for u in users:

            usr.append([
                u.username,
                u.role,
                "Sí" if u.enabled else "No",
                _to_local(u.last_login_at),
                _to_local(u.password_changed_at)
            ])

        style(usr, [22, 14, 10, 22, 22])

        # --- Auditoría ---
        au = workbook.create_sheet("Auditoría")

        au.append(["Fecha", "Usuario", "Acción", "Recurso", "Descripción"])

        for row in audit:

            username = None

            if row.user_id:

                user = db.get(User, row.user_id)

                username = user.username if user else None

            au.append([
                _to_local(row.created_at),
                username or row.user_id or "sistema",
                row.action,
                row.resource,
                row.description
            ])

        style(au, [20, 18, 26, 16, 50])

        # --- Consultas bloqueadas ---
        bl = workbook.create_sheet("Consultas bloqueadas")

        bl.append(["Equipo", "Página (dominio)", "Veces bloqueada"])

        for row in sorted(
            blocked_rows,
            key=lambda r: r.blocked_count or 0,
            reverse=True
        ):

            bl.append([
                row.hostname or row.ip_address or "Desconocido",
                row.domain,
                row.blocked_count
            ])

        style(bl, [24, 40, 18])

        # --- Configuración ---
        cfg = workbook.create_sheet("Configuración")

        cfg.append(["Sección", "Ítem", "Detalle"])

        for zone in zones:

            cfg.append([
                "Zona",
                zone.name,
                f"{zone.network_cidr} · gw {zone.gateway_ip} · "
                f"VLAN {zone.vlan_id or 'IP alias'}"
            ])

        for forward in forwards:

            cfg.append([
                "Reenvío (DMZ)",
                forward.name,
                f"{forward.protocol} {forward.external_port} → "
                f"{forward.internal_ip}:{forward.internal_port}"
            ])

        for peer in peers:

            cfg.append([
                "VPN peer",
                peer.name,
                f"{peer.allowed_ip} · "
                f"caduca {peer.expires_at or 'nunca'}"
            ])

        style(cfg, [18, 26, 60])

        buffer = io.BytesIO()

        workbook.save(buffer)

        buffer.seek(0)

        return buffer
