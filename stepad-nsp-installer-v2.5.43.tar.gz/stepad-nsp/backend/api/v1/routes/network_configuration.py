from fastapi import APIRouter, Depends, HTTPException

from pydantic import BaseModel

from backend.network.configuration.services.interface_configuration_service import InterfaceConfigurationService
from backend.network.configuration.services.network_topology_check_service import NetworkTopologyCheckService
from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

router = APIRouter(

    prefix="/network",

    tags=["Network Configuration"]

)


service = InterfaceConfigurationService()

topology_service = NetworkTopologyCheckService()


class LanSegmentRequest(BaseModel):

    network: str

    pool_start: str | None = None

    pool_end: str | None = None

    excluded_ips: list[str] = []

    # Subrango exclusivo para alias DNS de grupos (una IP por grupo).
    group_ip_start: str | None = None

    group_ip_end: str | None = None

    group_ip_count: int | None = None


@router.get("/topology-check")
def topology_check(
    current_user: dict = Depends(get_current_user)
):

    return topology_service.check()


@router.post("/lan/set")
def set_lan(
    request: LanSegmentRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    try:

        return topology_service.set_lan_segment(
            request.network,
            request.pool_start,
            request.pool_end,
            request.excluded_ips,
            group_ip_start=request.group_ip_start,
            group_ip_end=request.group_ip_end,
            group_ip_count=request.group_ip_count,
        )

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))



@router.post("/lan/config-test")
async def configure_lan_test(

    current_user: dict = Depends(require_role(UserRoles.ADMIN))

):

    return service.configure_lan_default()