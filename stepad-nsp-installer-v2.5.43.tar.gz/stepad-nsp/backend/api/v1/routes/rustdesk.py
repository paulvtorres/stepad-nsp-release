from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.api.schemas.rustdesk_request import UpdateRustdeskRequest
from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.core.database.dependency import get_db
from backend.rustdesk.services.rustdesk_service import RustdeskService
from backend.shared.constants.user_roles import UserRoles


router = APIRouter(
    prefix="/rustdesk",
    tags=["RustDesk"],
)

service = RustdeskService()


@router.get("/status")
def get_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return service.get_status(db)


@router.put("/config")
def update_config(
    request: UpdateRustdeskRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.apply_config(
        db,
        enabled=request.enabled,
        expose_wan=request.expose_wan,
        public_host=(
            request.public_host
            if "public_host" in request.model_fields_set
            else ...
        ),
        changed_by=current_user["user_id"],
    )
