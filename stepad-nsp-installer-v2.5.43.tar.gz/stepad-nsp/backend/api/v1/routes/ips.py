import subprocess

from pathlib import Path

from fastapi import APIRouter, Depends

from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.ips.services.suricata_alert_ingest import EVE_LOG

from backend.ips.services.threat_response_service import (
    threat_response_service
)


class ThreatResponseRequest(BaseModel):

    quarantine_enabled: bool | None = None

    c2_block_enabled: bool | None = None

    ips_fail_closed: bool | None = None


router = APIRouter(
    prefix="/ips",
    tags=["IPS"]
)


RULES_FILE = Path("/var/lib/suricata/rules/suricata.rules")


def _suricata_running():

    try:

        result = subprocess.run(
            ["pgrep", "-f", "suricata -D"],
            capture_output=True,
            text=True,
            timeout=5
        )

        return bool(result.stdout.strip())

    except Exception:

        return False


def _rules_count():

    try:

        if not RULES_FILE.exists():

            return 0

        count = 0

        for line in RULES_FILE.read_text(
            encoding="utf-8",
            errors="ignore"
        ).splitlines():

            stripped = line.strip()

            if not stripped or stripped.startswith("#"):

                continue

            count += 1

        return count

    except Exception:

        return 0


@router.get("/status")
def ips_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    from backend.alerts.models.alert import Alert

    from datetime import datetime, timedelta

    since = datetime.utcnow() - timedelta(hours=24)

    alerts_24h = (
        db.query(Alert)
        .filter(
            Alert.alert_type == "suricata",
            Alert.created_at >= since
        )
        .count()
    )

    return {
        "enabled": True,
        "suricata_running": _suricata_running(),
        "rules_loaded": _rules_count(),
        "alerts_last_24h": alerts_24h,
        "eve_log": str(EVE_LOG),
        "eve_log_size": EVE_LOG.stat().st_size if EVE_LOG.exists() else 0,
    }


@router.get("/threat-response")
def get_threat_response(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return threat_response_service.get_settings(db)


@router.put("/threat-response")
def update_threat_response(
    request: ThreatResponseRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return threat_response_service.update_settings(
        db,
        request.quarantine_enabled,
        request.c2_block_enabled,
        request.ips_fail_closed,
    )


@router.post("/threat-intel/refresh")
def refresh_threat_intel(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    from backend.ips.services.threat_intel_service import (
        threat_intel_service,
    )

    return threat_intel_service.sync()


@router.get("/malware-events")
def malware_events(
    limit: int = 10,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    events = threat_response_service.list_malware_events(
        db,
        limit=max(1, min(limit, 50))
    )

    return {"events": events}


@router.get("/quarantine")
def list_quarantine(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return threat_response_service.list_quarantined(db)


@router.get("/quarantine/count")
def quarantine_count(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    data = threat_response_service.list_quarantined(db)

    return {"count": data["count"]}


@router.post("/quarantine/{device_id}/release")
def release_quarantine(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return threat_response_service.release_quarantine(
        db,
        device_id,
        actor=current_user.get("username"),
    )
