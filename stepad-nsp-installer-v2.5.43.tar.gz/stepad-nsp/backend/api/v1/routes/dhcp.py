from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from backend.dhcp.services.dhcp_service import DhcpService
from backend.dhcp.services.dhcp_lease_service import DhcpLeaseService
from backend.dhcp.services.dhcp_log_service import DhcpLogService
from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles


router = APIRouter(
    prefix="/dhcp",
    tags=["DHCP"]
)


service = DhcpService()

lease_service = DhcpLeaseService()

log_service = DhcpLogService()


class ExclusionsRequest(BaseModel):

    ips: list[str] = []


@router.get("/config")
async def config(
    current_user: dict = Depends(get_current_user)
):

    return service.get_default_config()



@router.get("/exclusions")
async def exclusions(
    current_user: dict = Depends(get_current_user)
):

    return service.get_exclusions()



@router.post("/exclusions")
async def set_exclusions(
    request: ExclusionsRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    try:

        return service.set_exclusions(request.ips)

    except ValueError as error:

        raise HTTPException(status_code=400, detail=str(error))



@router.get("/leases")
async def leases(
    current_user: dict = Depends(get_current_user)
):

    return lease_service.list_leases()



@router.get("/diagnosis")
async def diagnosis(
    current_user: dict = Depends(get_current_user)
):

    return service.diagnose()



@router.get("/status")
async def status(
    current_user: dict = Depends(get_current_user)
):

    return service.get_status()


@router.get("/logs")
async def dhcp_logs(
    lines: int = Query(200, ge=1, le=1000),
    search: str | None = Query(None, max_length=120),
    current_user: dict = Depends(get_current_user)
):

    return log_service.tail(lines=lines, search=search)