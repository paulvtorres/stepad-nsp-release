from pydantic import BaseModel, Field


class UpdateRustdeskRequest(BaseModel):

    enabled: bool | None = None

    expose_wan: bool | None = Field(
        default=None,
        description=(
            "Si true, abre puertos RustDesk en WAN para trabajo remoto."
        ),
    )

    public_host: str | None = Field(
        default=None,
        description=(
            "IP o DNS público para clientes. Vacío = detectar WAN."
        ),
    )
