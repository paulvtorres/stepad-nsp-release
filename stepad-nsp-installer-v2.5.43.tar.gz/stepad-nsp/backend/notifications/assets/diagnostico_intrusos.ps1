<#
    STEPAD NSP - Diagnostico de posible intrusion / acceso remoto no autorizado
    ----------------------------------------------------------------------------

    Este script es SOLO DE DIAGNOSTICO: no borra, no detiene ni desinstala
    nada. Revisa el equipo Windows buscando senales de que alguien mas
    pudo haber entrado (remotamente o en persona) y muestra todo para que
    tu decidas que hacer.

    COMO USARLO:
      1. Guarda este archivo con extension .ps1 (si tu correo/descarga lo
         entrego como .txt, quita el ".txt" del nombre).
      2. Clic derecho sobre el archivo > "Ejecutar con PowerShell", o
         abre PowerShell como Administrador y ejecuta:
           Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
           .\diagnostico_intrusos.ps1
      3. Ejecutalo como Administrador -- varias secciones (usuarios,
         eventos de seguridad, RDP) necesitan ese permiso para mostrar
         informacion completa.
#>

param(
    [int]$DiasHistorial = 7
)

$ErrorActionPreference = "SilentlyContinue"

function Section($titulo) {
    Write-Host ""
    Write-Host "== $titulo ==" -ForegroundColor Cyan
}

Write-Host "=== STEPAD NSP: diagnostico de posible intrusion / acceso remoto ===" -ForegroundColor Cyan
Write-Host "Equipo: $env:COMPUTERNAME    Fecha: $(Get-Date)" -ForegroundColor White

$esAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltinRole]::Administrator
)

if (-not $esAdmin) {
    Write-Host ""
    Write-Host "AVISO: no se esta ejecutando como Administrador. Varias secciones" -ForegroundColor Yellow
    Write-Host "(usuarios, eventos de seguridad, RDP) pueden salir incompletas." -ForegroundColor Yellow
}


# ---------------------------------------------------------------------------
Section "Software de acceso remoto instalado"
# ---------------------------------------------------------------------------
# No toda herramienta de acceso remoto es maliciosa (soporte de TI la usa a
# diario) -- pero es la forma mas comun en que un intruso entra sin usar
# malware "clasico". Si no reconoces alguno de estos como instalado por tu
# equipo de TI, es una senal fuerte de intrusion.

$NombresAccesoRemoto = @(
    "anydesk", "teamviewer", "rustdesk", "ultravnc", "tightvnc", "realvnc",
    "vncserver", "logmein", "splashtop", "screenconnect", "connectwise",
    "supremo", "dwservice", "netsupport", "ammyy", "radmin", "chromeremotedesktop",
    "gotomypc", "showmypc"
)

$rutasRegistro = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
)

$instalados = Get-ItemProperty $rutasRegistro | Where-Object {
    $nombre = $_.DisplayName
    $nombre -and ($NombresAccesoRemoto | Where-Object { $nombre -like "*$_*" })
}

if ($instalados) {
    $instalados | Select-Object DisplayName, DisplayVersion, InstallDate | Format-Table -AutoSize
    Write-Host "Se encontro software de acceso remoto instalado. Verifica con tu equipo" -ForegroundColor Yellow
    Write-Host "de TI si lo instalaron ellos a proposito." -ForegroundColor Yellow
} else {
    Write-Host "No se encontro software de acceso remoto conocido instalado." -ForegroundColor Green
}

Write-Host ""
Write-Host "-- Procesos de acceso remoto EN EJECUCION ahora mismo --" -ForegroundColor White

$procesosRemotos = Get-Process | Where-Object {
    $nombre = $_.ProcessName.ToLower()
    $NombresAccesoRemoto | Where-Object { $nombre -like "*$_*" }
}

if ($procesosRemotos) {
    $procesosRemotos | Select-Object Name, Id, Path | Format-Table -AutoSize
    Write-Host "Hay software de acceso remoto CORRIENDO en este momento." -ForegroundColor Red
} else {
    Write-Host "No hay procesos de acceso remoto conocidos corriendo ahora." -ForegroundColor Green
}


# ---------------------------------------------------------------------------
Section "Escritorio remoto (RDP) de Windows"
# ---------------------------------------------------------------------------

$rdp = Get-ItemProperty "HKLM:\System\CurrentControlSet\Control\Terminal Server" -Name fDenyTSConnections
if ($rdp.fDenyTSConnections -eq 0) {
    Write-Host "RDP esta HABILITADO en este equipo." -ForegroundColor Yellow
} else {
    Write-Host "RDP esta deshabilitado." -ForegroundColor Green
}

Write-Host ""
Write-Host "-- Inicios de sesion remotos/de red en los ultimos $DiasHistorial dias (Visor de eventos) --" -ForegroundColor White
Write-Host "   (LogonType 10 = Escritorio Remoto, 3 = Red)" -ForegroundColor DarkGray

$desde = (Get-Date).AddDays(-$DiasHistorial)

$logonsRemotos = Get-WinEvent -FilterHashtable @{
    LogName   = "Security"
    Id        = 4624
    StartTime = $desde
} -ErrorAction SilentlyContinue | ForEach-Object {
    $xml = [xml]$_.ToXml()
    $datos = $xml.Event.EventData.Data
    $logonType = ($datos | Where-Object { $_.Name -eq "LogonType" }).'#text'
    if ($logonType -eq "10" -or $logonType -eq "3") {
        [PSCustomObject]@{
            Fecha      = $_.TimeCreated
            Usuario    = ($datos | Where-Object { $_.Name -eq "TargetUserName" }).'#text'
            TipoSesion = $logonType
            IPOrigen   = ($datos | Where-Object { $_.Name -eq "IpAddress" }).'#text'
        }
    }
}

if ($logonsRemotos) {
    $logonsRemotos | Sort-Object Fecha -Descending | Select-Object -First 30 | Format-Table -AutoSize
    Write-Host "Revisa si reconoces cada USUARIO e IP de origen. Una IP externa" -ForegroundColor Yellow
    Write-Host "(no de tu red local) o fuera de horario laboral es sospechosa." -ForegroundColor Yellow
} else {
    Write-Host "No se registraron inicios de sesion remotos/de red en el periodo (o falta permiso de Administrador para leerlos)." -ForegroundColor Green
}

Write-Host ""
Write-Host "-- Intentos de inicio de sesion FALLIDOS recientes (posible fuerza bruta) --" -ForegroundColor White

$fallidos = Get-WinEvent -FilterHashtable @{
    LogName   = "Security"
    Id        = 4625
    StartTime = $desde
} -ErrorAction SilentlyContinue

if ($fallidos) {
    Write-Host "Total de intentos fallidos en $DiasHistorial dias: $($fallidos.Count)" -ForegroundColor $(if ($fallidos.Count -gt 20) { "Red" } else { "Yellow" })
    $fallidos | ForEach-Object {
        $xml = [xml]$_.ToXml()
        $datos = $xml.Event.EventData.Data
        [PSCustomObject]@{
            Fecha    = $_.TimeCreated
            Usuario  = ($datos | Where-Object { $_.Name -eq "TargetUserName" }).'#text'
            IPOrigen = ($datos | Where-Object { $_.Name -eq "IpAddress" }).'#text'
        }
    } | Group-Object Usuario, IPOrigen | Sort-Object Count -Descending | Select-Object -First 15 |
        Format-Table Count, Name -AutoSize
} else {
    Write-Host "No se registraron intentos fallidos en el periodo." -ForegroundColor Green
}


# ---------------------------------------------------------------------------
Section "Cuentas de usuario y administradores"
# ---------------------------------------------------------------------------

Write-Host "-- Miembros del grupo Administradores --" -ForegroundColor White
Get-LocalGroupMember -Group "Administradores" -ErrorAction SilentlyContinue |
    Select-Object Name, PrincipalSource | Format-Table -AutoSize

Write-Host "Revisa que TODAS estas cuentas sean las que tu equipo de TI reconoce." -ForegroundColor Yellow
Write-Host "Una cuenta admin que no reconoces es una senal MUY fuerte de intrusion." -ForegroundColor Yellow

Write-Host ""
Write-Host "-- Cuentas de usuario creadas en los ultimos $DiasHistorial dias --" -ForegroundColor White

$cuentasNuevas = Get-WinEvent -FilterHashtable @{
    LogName   = "Security"
    Id        = 4720
    StartTime = $desde
} -ErrorAction SilentlyContinue | ForEach-Object {
    $xml = [xml]$_.ToXml()
    $datos = $xml.Event.EventData.Data
    [PSCustomObject]@{
        Fecha         = $_.TimeCreated
        CuentaCreada  = ($datos | Where-Object { $_.Name -eq "TargetUserName" }).'#text'
    }
}

if ($cuentasNuevas) {
    $cuentasNuevas | Format-Table -AutoSize
    Write-Host "Se crearon cuentas nuevas en este periodo. Verifica si fue autorizado." -ForegroundColor Red
} else {
    Write-Host "No se crearon cuentas de usuario en el periodo (o falta permiso de Administrador)." -ForegroundColor Green
}


# ---------------------------------------------------------------------------
Section "Conexiones de red activas"
# ---------------------------------------------------------------------------
Write-Host "-- Conexiones ESTABLECIDAS con procesos, marcando IPs publicas --" -ForegroundColor White

$rangosPrivados = @("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
                     "172.2", "172.30.", "172.31.", "127.", "169.254.")

Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | ForEach-Object {

    $esPrivada = $false
    foreach ($rango in $rangosPrivados) {
        if ($_.RemoteAddress.StartsWith($rango)) { $esPrivada = $true; break }
    }

    $proceso = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue

    [PSCustomObject]@{
        Proceso      = $proceso.ProcessName
        PID          = $_.OwningProcess
        IPRemota     = $_.RemoteAddress
        PuertoRemoto = $_.RemotePort
        Publica      = -not $esPrivada
    }

} | Sort-Object Publica -Descending | Format-Table -AutoSize

Write-Host "Revisa especialmente las filas con 'Publica = True' hacia procesos que" -ForegroundColor Yellow
Write-Host "no reconozcas (nombre raro, ruta en Temp/AppData)." -ForegroundColor Yellow


# ---------------------------------------------------------------------------
Section "Windows Defender"
# ---------------------------------------------------------------------------

$defender = Get-MpComputerStatus -ErrorAction SilentlyContinue

if ($defender) {
    [PSCustomObject]@{
        ProteccionTiempoReal = $defender.RealTimeProtectionEnabled
        AntivirusActualizado = $defender.AntivirusSignatureLastUpdated
        UltimoAnalisisCompleto = $defender.FullScanEndTime
    } | Format-Table -AutoSize

    if (-not $defender.RealTimeProtectionEnabled) {
        Write-Host "La proteccion en tiempo real esta DESACTIVADA. Un intruso a veces" -ForegroundColor Red
        Write-Host "la desactiva para instalar herramientas sin ser detectado." -ForegroundColor Red
    }
} else {
    Write-Host "No se pudo consultar el estado de Windows Defender (¿usas otro antivirus?)." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "-- Exclusiones configuradas en Defender (un intruso puede excluir su malware) --" -ForegroundColor White

$exclusiones = Get-MpPreference -ErrorAction SilentlyContinue

if ($exclusiones -and ($exclusiones.ExclusionPath -or $exclusiones.ExclusionProcess)) {
    Write-Host "Carpetas excluidas:" -ForegroundColor White
    $exclusiones.ExclusionPath | ForEach-Object { Write-Host "  $_" }
    Write-Host "Procesos excluidos:" -ForegroundColor White
    $exclusiones.ExclusionProcess | ForEach-Object { Write-Host "  $_" }
    Write-Host "Revisa que cada exclusion tenga una razon legitima conocida." -ForegroundColor Yellow
} else {
    Write-Host "No hay exclusiones configuradas." -ForegroundColor Green
}


# ---------------------------------------------------------------------------
Section "Recomendaciones"
# ---------------------------------------------------------------------------
Write-Host "1. Si viste software de acceso remoto, RDP, cuentas o IPs que NO reconoces:"
Write-Host "     - Desconecta el equipo de la red (cable/WiFi) de inmediato."
Write-Host "     - Cambia las contrasenas usadas desde este equipo, desde OTRO equipo limpio."
Write-Host "     - Avisa a tu administrador de STEPAD NSP para aislar el equipo desde el panel."
Write-Host "2. Ejecuta un analisis completo con Windows Defender:"
Write-Host "     Start-MpScan -ScanType FullScan"
Write-Host "3. Si el RDP esta habilitado y no lo necesitas, deshabilitalo:"
Write-Host "     Set-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 1"
Write-Host "4. Considera instalar Malwarebytes (version gratuita) para un segundo analisis:"
Write-Host "     https://www.malwarebytes.com/mwb-download"
