from pydantic import BaseModel


class NavigationReportSettingsRequest(BaseModel):

    enabled: bool | None = None

    to_emails: str | None = None

    bcc_emails: str | None = None

    report_subject: str | None = None

    frequency: str | None = None

    send_hour: int | None = None

    send_minute: int | None = None


class AlertNotificationSettingsRequest(BaseModel):

    alert_subject: str | None = None

    alert_email_enabled: bool | None = None

    alert_emails: str | None = None

    alert_cc_emails: str | None = None

    alert_bcc_emails: str | None = None

    security_dns_alert_enabled: bool | None = None

    security_dns_alert_emails: str | None = None

    security_dns_alert_cc_emails: str | None = None

    security_dns_alert_bcc_emails: str | None = None


class QuarantineNotificationSettingsRequest(BaseModel):

    quarantine_email_enabled: bool | None = None

    quarantine_emails: str | None = None

    quarantine_cc_emails: str | None = None

    quarantine_bcc_emails: str | None = None


class NotificationSettingsRequest(
    NavigationReportSettingsRequest,
    AlertNotificationSettingsRequest,
    QuarantineNotificationSettingsRequest,
):
    """Compatibilidad: actualiza reporte y/o alertas en una sola petición."""

    pass
