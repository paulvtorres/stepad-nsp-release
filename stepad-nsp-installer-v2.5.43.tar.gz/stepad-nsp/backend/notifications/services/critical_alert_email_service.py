"""
Correo inmediato para alertas críticas del NSP.

Independiente del reporte programado de navegación (Historial DNS).
Solo debe usarse cuando severity == critical en el panel de Alertas.
"""

from sqlalchemy.orm import Session

from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository,
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.email_settings_service import (
    build_delivery_context,
)
from backend.notifications.services.email_subject_service import (
    build_alert_subject,
)

from backend.shared.logging.logger import logger


class CriticalAlertEmailService:

    def __init__(self):

        self.repository = NotificationSettingsRepository()

        self.email_service = EmailService()

    def send(
        self,
        db: Session,
        title: str,
        message: str,
        *,
        html_body: str | None = None,
    ) -> bool:

        settings = self.repository.get(db)

        if not settings.alert_email_enabled:

            return False

        recipients = (settings.alert_emails or "").strip()

        if not recipients:

            return False

        delivery = build_delivery_context(
            db,
            to_emails=recipients,
            cc_emails=settings.alert_cc_emails or "",
            bcc_emails=settings.alert_bcc_emails or "",
        )

        if delivery is None:

            return False

        subject = build_alert_subject(
            db,
            settings.alert_subject,
            title=title,
        )

        body = html_body or f"<h3>{title}</h3><p>{message}</p>"

        result = self.email_service.send_html(
            delivery,
            subject,
            body,
        )

        if not result.get("success"):

            logger.warning(
                "Alerta crítica: no se envió correo (%s): %s",
                title,
                result.get("message"),
            )

            return False

        return True
