"""
Correo inmediato cuando un equipo queda aislado (cuarentena IPS).

Independiente del reporte de navegación y de las alertas críticas
generales: destinatarios propios para que no se pierda en el ruido.
"""

from sqlalchemy.orm import Session

from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository,
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.email_settings_service import (
    build_delivery_context,
)
from backend.notifications.services.email_subject_service import (
    build_alert_subject,
)

from backend.shared.logging.logger import logger


class QuarantineEmailService:

    def __init__(self):

        self.repository = NotificationSettingsRepository()

        self.email_service = EmailService()

    def send(
        self,
        db: Session,
        title: str,
        message: str,
        *,
        device_name: str = "",
        ip: str = "",
        mac: str = "",
        signature: str = "",
    ) -> bool:

        settings = self.repository.get(db)

        if not settings.quarantine_email_enabled:

            return False

        recipients = (settings.quarantine_emails or "").strip()

        if not recipients:

            return False

        delivery = build_delivery_context(
            db,
            to_emails=recipients,
            cc_emails=settings.quarantine_cc_emails or "",
            bcc_emails=settings.quarantine_bcc_emails or "",
        )

        if delivery is None:

            return False

        subject = build_alert_subject(
            db,
            settings.alert_subject,
            title=title,
        )

        html_body = f"""
        <h2 style="color:#b91c1c;">Equipo aislado de la red</h2>
        <p><strong>{title}</strong></p>
        <p>{message}</p>
        <table style="border-collapse:collapse;margin:12px 0;">
          <tr><td style="padding:4px 12px 4px 0;color:#555;">Equipo</td>
              <td><strong>{device_name or "—"}</strong></td></tr>
          <tr><td style="padding:4px 12px 4px 0;color:#555;">IP</td>
              <td>{ip or "—"}</td></tr>
          <tr><td style="padding:4px 12px 4px 0;color:#555;">MAC</td>
              <td>{mac or "—"}</td></tr>
          <tr><td style="padding:4px 12px 4px 0;color:#555;">Detección</td>
              <td>{signature or "—"}</td></tr>
        </table>
        <p>Revise el equipo en persona o de forma remota y, cuando sea
        seguro, desaislelo en <em>Seguridad → Equipos aislados</em>.</p>
        """

        result = self.email_service.send_html(
            delivery,
            subject,
            html_body,
        )

        if not result.get("success"):

            logger.warning(
                "Cuarentena: no se envió correo (%s): %s",
                title,
                result.get("message"),
            )

            return False

        return True
