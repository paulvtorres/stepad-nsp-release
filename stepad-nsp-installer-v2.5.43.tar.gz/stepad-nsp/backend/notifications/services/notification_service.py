import threading
import time

from datetime import datetime, timedelta, timezone

from fastapi import HTTPException

from sqlalchemy.orm import Session

from backend.notifications.models.notification_settings import (
    NotificationSettings
)
from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.email_settings_service import (
    EmailSettingsService,
    build_delivery_context,
)
from backend.shared.utils.datetimes import now_ecuador, to_ecuador, to_iso_utc

from backend.notifications.services.report_service import (
    EMAIL_REPORT_BODY,
    ReportService,
)
from backend.notifications.services.email_subject_service import (
    ALERT_VARIABLES,
    DEFAULT_ALERT_SUBJECT,
    DEFAULT_REPORT_SUBJECT,
    REPORT_VARIABLES,
    build_alert_subject,
    build_report_subject,
)

from backend.core.database.session import SessionLocal

from backend.shared.logging.logger import logger


FREQUENCY_LABELS = {
    "daily": "Diaria",
    "weekly": "Semanal",
    "monthly": "Mensual",
}

REPORT_PERIOD_LABELS = {
    "daily": "últimas 24 horas",
    "weekly": "últimos 7 días",
    "monthly": "últimos 30 días",
}


class NotificationService:

    def __init__(self):

        self.repository = NotificationSettingsRepository()

        self.email_service = EmailService()

        self.email_settings_service = EmailSettingsService()

        self.report_service = ReportService()

        self._scheduler_thread = None

        self._stop = False

    def _period(
        self,
        frequency: str
    ) -> tuple[datetime, datetime]:

        end = datetime.utcnow()

        days = {
            "daily": 1,
            "weekly": 7,
            "monthly": 30,
        }.get(frequency, 1)

        start = end - timedelta(days=days)

        return start, end

    def _report_ready(
        self,
        db: Session,
        settings: NotificationSettings,
    ) -> tuple[bool, list[str]]:

        email = self.email_settings_service.repository.get(db)

        issues = self.email_settings_service._ready_issues(email)

        if not self.email_service._recipients(settings):

            issues.append("Destinatarios del reporte")

        return len(issues) == 0, issues

    def _alert_ready(
        self,
        db: Session,
        settings: NotificationSettings,
    ) -> tuple[bool, list[str]]:

        email = self.email_settings_service.repository.get(db)

        issues = list(self.email_settings_service._ready_issues(email))

        if settings.alert_email_enabled:

            alert_to = [
                email.strip()
                for email in (settings.alert_emails or "").split(",")
                if email.strip()
            ]

            if not alert_to:

                issues.append("Destinatarios de alertas críticas")

        if settings.security_dns_alert_enabled:

            dns_to = [
                email.strip()
                for email in (settings.security_dns_alert_emails or "").split(",")
                if email.strip()
            ]

            if not dns_to:

                issues.append("Destinatarios de alertas DNS")

        return len(issues) == 0, issues

    def _smtp_ready(
        self,
        db: Session,
        settings: NotificationSettings,
    ) -> tuple[bool, list[str]]:

        return self._report_ready(db, settings)

    def _email_status(
        self,
        db: Session,
    ) -> dict:

        email_status = self.email_settings_service.get_settings(db)

        return {
            "email_config_ready": email_status["config_ready"],
            "email_provider": email_status["provider"],
            "email_provider_label": email_status["provider_label"],
            "email_account": email_status["account_email"],
        }

    def _next_send_hint(
        self,
        db: Session,
        settings: NotificationSettings,
        now: datetime | None = None,
    ) -> str:

        now = now or now_ecuador()

        if not settings.enabled:

            return "Los reportes de navegación están desactivados."

        ready, issues = self._smtp_ready(db, settings)

        if not ready:

            return f"Complete: {', '.join(issues)}."

        if self.is_due(settings, now):

            return "Envío programado pendiente (próximos minutos)."

        target = now.replace(
            hour=settings.send_hour,
            minute=settings.send_minute,
            second=0,
            microsecond=0,
        )

        freq = settings.frequency or "daily"
        last = settings.last_sent_at

        if last is not None and last.tzinfo is None:

            last = last.replace(tzinfo=None)

        if freq == "daily":

            if now < target:

                return f"Hoy a las {settings.send_hour:02d}:{settings.send_minute:02d}"

            return (
                f"Mañana a las {settings.send_hour:02d}:"
                f"{settings.send_minute:02d}"
            )

        if freq == "weekly":

            if last is None:

                if now < target:

                    return (
                        f"Hoy a las {settings.send_hour:02d}:"
                        f"{settings.send_minute:02d} (primer envío)"
                    )

                return "Próximo envío en 7 días desde el primero."

            days_left = max(
                0,
                7 - (now.date() - last.date()).days,
            )

            if days_left == 0 and now >= target:

                return "Hoy (ciclo semanal)"

            return f"En {days_left or 7} día(s), a las {settings.send_hour:02d}:{settings.send_minute:02d}"

        if freq == "monthly":

            if last is None:

                if now < target:

                    return (
                        f"Hoy a las {settings.send_hour:02d}:"
                        f"{settings.send_minute:02d} (primer envío)"
                    )

                return "Próximo mes (primer envío)."

            if last.month == now.month and last.year == now.year:

                return (
                    f"Próximo mes, a las {settings.send_hour:02d}:"
                    f"{settings.send_minute:02d}"
                )

            if now < target:

                return f"Hoy a las {settings.send_hour:02d}:{settings.send_minute:02d}"

            return (
                f"Próximo mes, a las {settings.send_hour:02d}:"
                f"{settings.send_minute:02d}"
            )

        return f"A las {settings.send_hour:02d}:{settings.send_minute:02d}"

    def get_report_settings(
        self,
        db: Session,
    ) -> dict:

        settings = self.repository.get(db)

        ready, issues = self._report_ready(db, settings)

        frequency = settings.frequency or "daily"

        return {
            "id": settings.id,
            "enabled": settings.enabled,
            "to_emails": settings.to_emails,
            "bcc_emails": settings.bcc_emails,
            "report_subject": settings.report_subject or "",
            "report_subject_default": DEFAULT_REPORT_SUBJECT,
            "report_subject_variables": list(REPORT_VARIABLES),
            "frequency": frequency,
            "frequency_label": FREQUENCY_LABELS.get(frequency, frequency),
            "report_period": REPORT_PERIOD_LABELS.get(frequency, ""),
            "send_hour": settings.send_hour,
            "send_minute": settings.send_minute,
            "schedule_label": (
                f"{FREQUENCY_LABELS.get(frequency, frequency)} a las "
                f"{settings.send_hour:02d}:{settings.send_minute:02d}"
            ),
            "last_sent_at": to_iso_utc(settings.last_sent_at),
            "config_ready": ready,
            "config_issues": issues,
            "next_send_hint": self._next_send_hint(db, settings),
            "scheduler_running": (
                self._scheduler_thread is not None
                and self._scheduler_thread.is_alive()
            ),
            **self._email_status(db),
        }

    def get_alert_settings(
        self,
        db: Session,
    ) -> dict:

        settings = self.repository.get(db)

        ready, issues = self._alert_ready(db, settings)

        return {
            "id": settings.id,
            "alert_subject": settings.alert_subject or "",
            "alert_subject_default": DEFAULT_ALERT_SUBJECT,
            "alert_subject_variables": list(ALERT_VARIABLES),
            "alert_email_enabled": settings.alert_email_enabled,
            "alert_emails": settings.alert_emails or "",
            "alert_cc_emails": settings.alert_cc_emails or "",
            "alert_bcc_emails": settings.alert_bcc_emails or "",
            "security_dns_alert_enabled": settings.security_dns_alert_enabled,
            "security_dns_alert_emails": settings.security_dns_alert_emails or "",
            "security_dns_alert_cc_emails": (
                settings.security_dns_alert_cc_emails or ""
            ),
            "security_dns_alert_bcc_emails": (
                settings.security_dns_alert_bcc_emails or ""
            ),
            "config_ready": ready,
            "config_issues": issues,
            **self._email_status(db),
        }

    def get_quarantine_settings(
        self,
        db: Session,
    ) -> dict:

        settings = self.repository.get(db)

        email_status = self._email_status(db)

        issues = list(
            self.email_settings_service._ready_issues(
                self.email_settings_service.repository.get(db)
            )
        )

        if settings.quarantine_email_enabled:

            recipients = [
                email.strip()
                for email in (settings.quarantine_emails or "").split(",")
                if email.strip()
            ]

            if not recipients:

                issues.append("Destinatarios de aislamiento")

        return {
            "id": settings.id,
            "quarantine_email_enabled": settings.quarantine_email_enabled,
            "quarantine_emails": settings.quarantine_emails or "",
            "quarantine_cc_emails": settings.quarantine_cc_emails or "",
            "quarantine_bcc_emails": settings.quarantine_bcc_emails or "",
            "config_ready": len(issues) == 0,
            "config_issues": issues,
            **email_status,
        }

    def get_settings(
        self,
        db: Session
    ) -> dict:

        report = self.get_report_settings(db)
        alerts = self.get_alert_settings(db)

        return {
            **report,
            **alerts,
            **self.get_quarantine_settings(db),
            "report_config_ready": report["config_ready"],
            "report_config_issues": report["config_issues"],
            "alert_config_ready": alerts["config_ready"],
            "alert_config_issues": alerts["config_issues"],
            "config_ready": report["config_ready"],
            "config_issues": report["config_issues"],
        }

    def save_report_settings(
        self,
        db: Session,
        data,
    ) -> dict:

        settings = self.repository.get(db)

        if data.enabled is not None:
            settings.enabled = data.enabled

        if data.to_emails is not None:
            settings.to_emails = data.to_emails

        if data.bcc_emails is not None:
            settings.bcc_emails = data.bcc_emails

        if data.report_subject is not None:
            settings.report_subject = (data.report_subject or "").strip()

        if data.frequency is not None:
            settings.frequency = data.frequency

        if data.send_hour is not None:
            settings.send_hour = data.send_hour

        if data.send_minute is not None:
            settings.send_minute = data.send_minute

        if settings.enabled:

            recipients = [
                email.strip()
                for email in (settings.to_emails or "").split(",")
                if email.strip()
            ]

            if not recipients:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Indique al menos un destinatario en Para "
                        "para activar el envío programado."
                    ),
                )

        self.repository.save(db, settings)

        return self.get_report_settings(db)

    def save_alert_settings(
        self,
        db: Session,
        data,
    ) -> dict:

        settings = self.repository.get(db)

        if data.alert_subject is not None:
            settings.alert_subject = (data.alert_subject or "").strip()

        if data.alert_email_enabled is not None:
            settings.alert_email_enabled = data.alert_email_enabled

        if data.alert_emails is not None:
            settings.alert_emails = data.alert_emails or ""

        if data.alert_cc_emails is not None:
            settings.alert_cc_emails = data.alert_cc_emails or ""

        if data.alert_bcc_emails is not None:
            settings.alert_bcc_emails = data.alert_bcc_emails or ""

        if data.security_dns_alert_enabled is not None:
            settings.security_dns_alert_enabled = (
                data.security_dns_alert_enabled
            )

        if data.security_dns_alert_emails is not None:
            settings.security_dns_alert_emails = (
                data.security_dns_alert_emails or ""
            )

        if data.security_dns_alert_cc_emails is not None:
            settings.security_dns_alert_cc_emails = (
                data.security_dns_alert_cc_emails or ""
            )

        if data.security_dns_alert_bcc_emails is not None:
            settings.security_dns_alert_bcc_emails = (
                data.security_dns_alert_bcc_emails or ""
            )

        if settings.alert_email_enabled:

            recipients = [
                email.strip()
                for email in (settings.alert_emails or "").split(",")
                if email.strip()
            ]

            if not recipients:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Indique al menos un destinatario en Para "
                        "para activar las alertas críticas por correo."
                    ),
                )

        if settings.security_dns_alert_enabled:

            dns_recipients = [
                email.strip()
                for email in (settings.security_dns_alert_emails or "").split(",")
                if email.strip()
            ]

            if not dns_recipients:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Indique al menos un destinatario en Para "
                        "para activar las alertas DNS por correo."
                    ),
                )

        self.repository.save(db, settings)

        return self.get_alert_settings(db)

    def save_quarantine_settings(
        self,
        db: Session,
        data,
    ) -> dict:

        settings = self.repository.get(db)

        if data.quarantine_email_enabled is not None:
            settings.quarantine_email_enabled = data.quarantine_email_enabled

        if data.quarantine_emails is not None:
            settings.quarantine_emails = data.quarantine_emails or ""

        if data.quarantine_cc_emails is not None:
            settings.quarantine_cc_emails = data.quarantine_cc_emails or ""

        if data.quarantine_bcc_emails is not None:
            settings.quarantine_bcc_emails = data.quarantine_bcc_emails or ""

        if settings.quarantine_email_enabled:

            recipients = [
                email.strip()
                for email in (settings.quarantine_emails or "").split(",")
                if email.strip()
            ]

            if not recipients:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Indique al menos un destinatario en Para "
                        "para activar el correo de equipos aislados."
                    ),
                )

        self.repository.save(db, settings)

        return self.get_quarantine_settings(db)

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        if hasattr(data, "model_dump"):
            payload = data.model_dump(exclude_unset=True)
        else:
            payload = dict(data)

        report_keys = {
            "enabled",
            "to_emails",
            "bcc_emails",
            "report_subject",
            "frequency",
            "send_hour",
            "send_minute",
        }
        alert_keys = {
            "alert_subject",
            "alert_email_enabled",
            "alert_emails",
            "alert_cc_emails",
            "alert_bcc_emails",
            "security_dns_alert_enabled",
            "security_dns_alert_emails",
            "security_dns_alert_cc_emails",
            "security_dns_alert_bcc_emails",
        }
        quarantine_keys = {
            "quarantine_email_enabled",
            "quarantine_emails",
            "quarantine_cc_emails",
            "quarantine_bcc_emails",
        }

        from backend.notifications.schemas.notification_settings import (
            AlertNotificationSettingsRequest,
            NavigationReportSettingsRequest,
            QuarantineNotificationSettingsRequest,
        )

        report_payload = {
            key: payload[key]
            for key in report_keys
            if key in payload
        }
        alert_payload = {
            key: payload[key]
            for key in alert_keys
            if key in payload
        }
        quarantine_payload = {
            key: payload[key]
            for key in quarantine_keys
            if key in payload
        }

        if report_payload:
            self.save_report_settings(
                db,
                NavigationReportSettingsRequest(**report_payload),
            )

        if alert_payload:
            self.save_alert_settings(
                db,
                AlertNotificationSettingsRequest(**alert_payload),
            )

        if quarantine_payload:
            self.save_quarantine_settings(
                db,
                QuarantineNotificationSettingsRequest(**quarantine_payload),
            )

        if not report_payload and not alert_payload and not quarantine_payload:
            self.repository.get(db)

        return self.get_settings(db)

    def send_report(
        self,
        db: Session,
        settings: NotificationSettings = None
    ) -> dict:

        settings = settings or self.repository.get(db)

        delivery = build_delivery_context(
            db,
            to_emails=settings.to_emails,
            bcc_emails=settings.bcc_emails,
        )

        if delivery is None:

            return {
                "success": False,
                "message": "Configure la cuenta de correo en Ajustes → Correo.",
            }

        start, end = self._period(settings.frequency)

        html_body = EMAIL_REPORT_BODY

        excel_buffer = self.report_service.build_excel(
            db,
            start,
            end,
        )

        attachment_name = (
            f"historial-dns_{start.strftime('%Y%m%d')}-"
            f"{end.strftime('%Y%m%d')}.xlsx"
        )

        period_label = REPORT_PERIOD_LABELS.get(
            settings.frequency or "daily",
            "período seleccionado",
        )

        subject = build_report_subject(
            db,
            settings.report_subject,
            frequency=settings.frequency or "daily",
            start=start,
            end=end,
        )

        result = self.email_service.send_html_with_attachment(
            delivery,
            subject,
            html_body,
            excel_buffer.getvalue(),
            attachment_name,
        )

        if result["success"]:

            settings.last_sent_at = datetime.now(timezone.utc).replace(
                tzinfo=None
            )

            self.repository.save(db, settings)

            result["message"] = (
                f"Reporte enviado ({period_label}) con Excel adjunto."
            )

        return result

    def send_test(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        delivery = build_delivery_context(
            db,
            to_emails=settings.to_emails,
            bcc_emails=settings.bcc_emails,
        )

        if delivery is None:

            return {
                "success": False,
                "message": "Configure la cuenta de correo en Ajustes → Correo.",
            }

        html_body = (
            "<h2>Prueba de notificación</h2>"
            "<p>Este es un correo de prueba de STEPAD NSP. "
            "Si lo estás viendo, la configuración de correo es correcta.</p>"
        )

        subject = build_report_subject(
            db,
            settings.report_subject,
            frequency=settings.frequency or "daily",
            start=datetime.now() - timedelta(days=1),
            end=datetime.now(),
        )

        return self.email_service.send_html(
            delivery,
            subject,
            html_body
        )

    def is_due(
        self,
        settings: NotificationSettings,
        now: datetime | None = None
    ) -> bool:

        if not settings.enabled:

            return False

        now = now_ecuador() if now is None else now

        if now.tzinfo is not None:

            now = to_ecuador(now)

        target = now.replace(
            hour=settings.send_hour,
            minute=settings.send_minute,
            second=0,
            microsecond=0,
        )

        # Ventana de 2 h a partir de la hora programada (hora de
        # Ecuador). Si se activa a media tarde, espera al próximo
        # día a las 08:00; no dispara en el acto.
        if now < target or now >= target + timedelta(hours=2):

            return False

        last = settings.last_sent_at

        if last is None:

            return True

        last = to_ecuador(last)

        if settings.frequency == "daily":

            return last.date() < now.date()

        if settings.frequency == "weekly":

            return (now.date() - last.date()).days >= 7

        if settings.frequency == "monthly":

            return (
                last.year != now.year
                or last.month != now.month
            )

        return False

    def _scheduler_loop(
        self
    ):

        logger.info("Notification scheduler started.")

        while not self._stop:

            try:

                db = SessionLocal()

                try:

                    settings = self.repository.get(db)

                    if self.is_due(settings):

                        result = self.send_report(db, settings)

                        if result.get("success"):

                            logger.info(
                                f"Notification report: {result}"
                            )

                        else:

                            logger.warning(
                                f"Notification report FAILED: {result}"
                            )

                    try:

                        from backend.siem.services.compliance_service import (
                            ComplianceService
                        )

                        ComplianceService().check_logs_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Logs review check failed: {error}"
                        )

                    try:

                        from backend.firewall.services.firewall_hardening_service import (
                            FirewallHardeningService
                        )

                        FirewallHardeningService().check_access_review_alert(db)

                    except Exception as error:

                        logger.warning(
                            f"Access review check failed: {error}"
                        )

                finally:

                    db.close()

            except Exception as error:

                logger.exception(
                    f"Notification scheduler error: {error}"
                )

            time.sleep(30)

    def start_scheduler(
        self
    ):

        if self._scheduler_thread is not None:

            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="notification-scheduler"
        )

        self._scheduler_thread.start()
