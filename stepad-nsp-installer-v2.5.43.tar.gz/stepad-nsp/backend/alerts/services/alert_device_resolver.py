import ipaddress
import re

from backend.shared.config.config_service import ConfigService


def _lan_network():

    try:

        dhcp = ConfigService().get_dhcp_config()

        return ipaddress.ip_network(
            f"{dhcp['network']}/{dhcp.get('netmask', '255.255.255.0')}",
            strict=False,
        )

    except Exception:

        return ipaddress.ip_network("192.168.1.0/24", strict=False)


def client_ip_from_ips_message(message: str | None) -> str | None:
    """
    Resuelve la IP del equipo LAN en alertas Suricata.

    El mensaje suele ser: "firma | cat | IP_A -> IP_B:puerto".
    La IP LAN puede ser origen o destino según la dirección del flujo.
    """

    if not message:

        return None

    ips = re.findall(r"\d{1,3}(?:\.\d{1,3}){3}", message)

    if not ips:

        return None

    network = _lan_network()

    for ip in ips:

        try:

            if ipaddress.ip_address(ip) in network:

                return ip

        except ValueError:

            continue

    if len(ips) >= 2 and "->" in message:

        candidate = ips[1].split(":")[0]

        try:

            ipaddress.ip_address(candidate)

            return candidate

        except ValueError:

            pass

    return ips[0]
