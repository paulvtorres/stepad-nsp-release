"""Deteccion de dominios bloqueados que indican una amenaza activa
(malware/phishing del feed), a diferencia de un bloqueo comun por
filtro de contenido (adultos, apuestas, redes sociales, etc).

Se usa para decidir cuando un bloqueo del DNS merece una alerta
PRIORITARIA (con correo inmediato) en vez de simplemente sumar al
conteo de "accesos bloqueados" del reporte.
"""

from sqlalchemy.orm import Session

from backend.content.models.content_category import (
    ContentCategory,
    CategoryDomain,
)


def _normalize(domain: str | None) -> str:

    return (domain or "").strip().lower().rstrip(".")


def _domain_and_parent_suffixes(domain: str) -> set[str]:

    labels = domain.split(".")

    # Genera "sub.evil.com" -> {"sub.evil.com", "evil.com"}, deteniendose
    # en dos etiquetas (no tiene sentido comparar solo el TLD).
    return {
        ".".join(labels[i:])
        for i in range(len(labels) - 1)
    }


def is_malware_feed_domain(db: Session, domain: str | None) -> bool:

    normalized = _normalize(domain)

    if not normalized or "." not in normalized:

        return False

    candidates = _domain_and_parent_suffixes(normalized)

    match = (
        db.query(CategoryDomain.id)
        .join(
            ContentCategory,
            ContentCategory.id == CategoryDomain.category_id
        )
        .filter(
            ContentCategory.key == "malware",
            CategoryDomain.domain.in_(candidates)
        )
        .first()
    )

    return match is not None


def classify_blocked_domain(
    db: Session,
    domain: str | None
) -> dict | None:
    """Clasifica un dominio bloqueado como amenaza prioritaria, o None
    si es un bloqueo comun (filtro de contenido) que no lo amerita."""

    if is_malware_feed_domain(db, domain):

        return {
            "kind": "malware",
            "label": "Posible malware o phishing",
        }

    return None
