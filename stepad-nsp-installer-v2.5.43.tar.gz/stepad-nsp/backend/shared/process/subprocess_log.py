from pathlib import Path

from backend.shared.logging.log_rotation import rotate_log_file


def open_rotated_log(
    path: Path,
    max_bytes: int,
    backup_count: int,
):
    """
    Abre un log en append, rotando primero si supera max_bytes.
    Usar como stdout/stderr de subprocess (nunca PIPE).
    """

    path.parent.mkdir(parents=True, exist_ok=True)

    rotate_log_file(path, max_bytes, backup_count)

    return open(path, "a", buffering=1, encoding="utf-8")
