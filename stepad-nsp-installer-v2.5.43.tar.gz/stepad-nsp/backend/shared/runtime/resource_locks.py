"""Serialización de mutaciones a recursos compartidos del appliance.

dnsmasq, nftables (tabla stepad / dnsnat) y Suricata son tocados por
varios servicios. Sin un candado común, reinicios y reescrituras de
reglas se pisan entre sí (DHCP a medias, Suricata restart mientras
ingest lee eve.json, handles nft inválidos).

Uso:
    with resource_locks.dnsmasq:
        dnsmasq_process_manager.restart()
"""

from __future__ import annotations

import threading
from contextlib import contextmanager
from typing import Iterator


class _NamedLock:
    def __init__(self, name: str):
        self.name = name
        self._lock = threading.RLock()

    def acquire(self, blocking: bool = True, timeout: float = -1) -> bool:
        return self._lock.acquire(blocking, timeout)

    def release(self) -> None:
        self._lock.release()

    def __enter__(self):
        self._lock.acquire()
        return self

    def __exit__(self, exc_type, exc, tb):
        self._lock.release()
        return False


class ResourceLocks:
    """Candados de proceso para dueños de recursos compartidos."""

    def __init__(self):
        self.dnsmasq = _NamedLock("dnsmasq")
        self.nft = _NamedLock("nft")
        self.suricata = _NamedLock("suricata")

    @contextmanager
    def appliance(self) -> Iterator[None]:
        """Toma nft + dnsmasq + suricata (orden fijo anti-deadlock)."""
        with self.nft:
            with self.dnsmasq:
                with self.suricata:
                    yield


resource_locks = ResourceLocks()
