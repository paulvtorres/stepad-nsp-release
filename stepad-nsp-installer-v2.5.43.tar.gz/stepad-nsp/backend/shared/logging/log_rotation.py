from pathlib import Path


def rotate_log_file(
    path: Path,
    max_bytes: int,
    backup_count: int,
) -> None:
    """
    Rota path -> path.1 -> path.2 ... cuando supera max_bytes.
    """

    if backup_count < 1 or not path.exists():

        return

    if path.stat().st_size <= max_bytes:

        return

    oldest = path.with_name(f"{path.name}.{backup_count}")

    if oldest.exists():

        oldest.unlink()

    for index in range(backup_count - 1, 0, -1):

        src = path.with_name(f"{path.name}.{index}")

        dst = path.with_name(f"{path.name}.{index + 1}")

        if src.exists():

            src.rename(dst)

    path.rename(path.with_name(f"{path.name}.1"))
