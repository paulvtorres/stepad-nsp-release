import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from backend.shared.config.config_loader import config

def create_logger():
    """
    Factory responsible for building the STEPAD NSP logger.
    """

    logger = logging.getLogger(f"{config['app']['name']}")

    # Evitar duplicar handlers si ya fue creado
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)

    # Crear carpeta de logs si no existe
    log_path = Path(config["log"]["directory"])
    log_path.mkdir(exist_ok=True)

    file_path = log_path / config["log"]["file"]

    max_bytes = int(config["log"].get("max_bytes", 10 * 1024 * 1024))
    backup_count = int(config["log"].get("backup_count", 5))

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(message)s"
    )

    # Console Handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    # File Handler con rotación automática
    file_handler = RotatingFileHandler(
        file_path,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    # Attach handlers
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger