from datetime import datetime, timezone
from zoneinfo import ZoneInfo


DISPLAY_TIMEZONE = ZoneInfo("America/Guayaquil")


def now_ecuador():
    """Hora actual de Ecuador (naive), para programar envíos a las 08:00."""
    return datetime.now(DISPLAY_TIMEZONE).replace(tzinfo=None)


def to_ecuador(value):
    """UTC naive/aware -> hora de Ecuador naive."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(DISPLAY_TIMEZONE).replace(tzinfo=None)


def local_to_utc(value):
    """
    Convierte un datetime "naive" (hora local del servidor, como lo
    envia el frontend en los filtros de fecha, ej. "2026-08-15T23:59:59")
    a UTC naive para consultar los logs (que se guardan en UTC).

    Sin esta conversion, el backend interpretaba esas fechas como UTC y
    (siendo el servidor UTC-5) cortaba la actividad a partir de las 19h
    local. Aplicar esta conversion en TODOS los filtros de fecha evita
    el problema de una vez.
    """
    if value is None:
        return None
    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    local_tz = datetime.now().astimezone().tzinfo
    return (
        value.replace(tzinfo=local_tz)
        .astimezone(timezone.utc)
        .replace(tzinfo=None)
    )


def utc_to_local(value):
    """
    UTC naive (como se guardan los logs) -> hora local del servidor
    (naive), para mostrar en reportes/Excel.
    """
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone().replace(tzinfo=None)


def format_ecuador_datetime(value, empty=None):
    """Hora de Ecuador para mostrar en la UI (naive UTC in -> string local)."""

    local = to_ecuador(value)

    if local is None:

        return empty

    return local.strftime("%d/%m/%Y, %H:%M:%S")


def to_iso_utc(value):
    """
    Serializa un datetime "naive" en UTC (como se guardan created_at/
    last_seen/etc, via datetime.utcnow()) a un string ISO-8601 CON
    marcador de zona ("...Z"), para enviarlo al frontend.

    Sin el "Z", `dt.isoformat()` produce un string sin zona horaria
    (ej. "2026-08-22T20:22:30"), y el navegador (new Date(...)) lo
    interpreta como HORA LOCAL en vez de UTC -- el valor mostrado
    queda adelantado/atrasado por el offset del huso horario del
    servidor (ej. 5 horas en UTC-5). Con el "Z", el navegador convierte
    correctamente a la hora local de quien lo esta viendo.
    """
    if value is None:
        return None
    if value.tzinfo is not None:
        value = value.astimezone(timezone.utc).replace(tzinfo=None)
    # Tres dígitos de ms: algunos navegadores fallan con microsegundos.
    return value.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
