"""WAN probe / scan attempt aggregates

Revision ID: 0014
Revises: 0013
Create Date: 2026-08-26 12:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0014"
down_revision = "0013"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "wan_probe_events",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("src_ip", sa.String(length=45), nullable=False),
        sa.Column("dst_port", sa.Integer(), nullable=True),
        sa.Column(
            "protocol",
            sa.String(length=16),
            nullable=False,
            server_default="tcp",
        ),
        sa.Column(
            "chain",
            sa.String(length=16),
            nullable=False,
            server_default="input",
        ),
        sa.Column(
            "hit_count",
            sa.Integer(),
            nullable=False,
            server_default="1",
        ),
        sa.Column("first_seen", sa.DateTime(), nullable=False),
        sa.Column("last_seen", sa.DateTime(), nullable=False),
        sa.UniqueConstraint(
            "src_ip",
            "dst_port",
            "protocol",
            "chain",
            name="uq_wan_probe_agg",
        ),
    )
    op.create_index(
        "ix_wan_probe_events_src_ip",
        "wan_probe_events",
        ["src_ip"],
    )
    op.create_index(
        "ix_wan_probe_events_last_seen",
        "wan_probe_events",
        ["last_seen"],
    )


def downgrade() -> None:
    op.drop_index("ix_wan_probe_events_last_seen", table_name="wan_probe_events")
    op.drop_index("ix_wan_probe_events_src_ip", table_name="wan_probe_events")
    op.drop_table("wan_probe_events")
