"""Persist DNS alias IP per device group

Revision ID: 0013
Revises: 0012
Create Date: 2026-08-24 13:20:00.000000

Las IPs de alias DNS de grupos dejan de calcularse por orden de id
(reasignación al borrar) y pasan a guardarse en device_groups.dns_alias_ip.
Backfill: grupos existentes reciben la primera IP libre del subrango
configurado, en orden de id, una sola vez.
"""
from alembic import op
import sqlalchemy as sa


revision = "0013"
down_revision = "0012"
branch_labels = None
depends_on = None


def _backfill_alias_ips() -> None:
    """Asigna IPs estables a grupos que aún no tienen dns_alias_ip."""
    bind = op.get_bind()
    rows = bind.execute(
        sa.text(
            "SELECT id FROM device_groups "
            "WHERE dns_alias_ip IS NULL ORDER BY id ASC"
        )
    ).fetchall()
    if not rows:
        return

    try:
        from backend.groups.constants.group_dns_ip_reserve import (
            group_ip_list,
            next_free_group_ip,
        )
    except Exception:
        # Fallback si el import falla en entorno mínimo de migración.
        group_ip_list = lambda: [  # noqa: E731
            f"192.168.1.{i}" for i in range(10, 20)
        ]
        next_free_group_ip = None  # type: ignore

    used = {
        r[0]
        for r in bind.execute(
            sa.text(
                "SELECT dns_alias_ip FROM device_groups "
                "WHERE dns_alias_ip IS NOT NULL"
            )
        ).fetchall()
        if r[0]
    }

    for (group_id,) in rows:
        if next_free_group_ip is not None:
            ip = next_free_group_ip(used)
        else:
            ip = next((x for x in group_ip_list() if x not in used), None)
        if ip is None:
            break
        bind.execute(
            sa.text(
                "UPDATE device_groups SET dns_alias_ip = :ip "
                "WHERE id = :gid"
            ),
            {"ip": ip, "gid": group_id},
        )
        used.add(ip)


def upgrade() -> None:
    op.add_column(
        "device_groups",
        sa.Column("dns_alias_ip", sa.String(length=45), nullable=True),
    )
    op.create_index(
        "ix_device_groups_dns_alias_ip",
        "device_groups",
        ["dns_alias_ip"],
        unique=True,
    )
    _backfill_alias_ips()


def downgrade() -> None:
    op.drop_index("ix_device_groups_dns_alias_ip", table_name="device_groups")
    op.drop_column("device_groups", "dns_alias_ip")
