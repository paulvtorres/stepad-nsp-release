"""RustDesk settings

Revision ID: 0015
Revises: 0014
Create Date: 2026-08-26 22:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0015"
down_revision = "0014"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "rustdesk_settings",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
        sa.Column(
            "expose_wan",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
        sa.Column("public_host", sa.String(length=255), nullable=True),
        sa.Column("installed_version", sa.String(length=32), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )


def downgrade() -> None:
    op.drop_table("rustdesk_settings")
