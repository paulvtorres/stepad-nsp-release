"""Correo dedicado al aislar un equipo (cuarentena IPS)

Revision ID: 0017
Revises: 0016
Create Date: 2026-08-31 13:10:00.000000

El aislamiento no debe depender solo del buzón de alertas generales:
tiene destinatarios propios para que TI se entere aunque haya mucho ruido.
"""
from alembic import op
import sqlalchemy as sa


revision = "0017"
down_revision = "0016"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "notification_settings",
        sa.Column(
            "quarantine_email_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "quarantine_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "quarantine_cc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "quarantine_bcc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )

    # Arranque: si ya hay destinatarios de alertas críticas, copiarlos
    # para no perder avisos de aislamiento tras actualizar.
    op.execute(
        """
        UPDATE notification_settings
        SET quarantine_emails = alert_emails
        WHERE COALESCE(alert_emails, '') != ''
          AND COALESCE(quarantine_emails, '') = ''
        """
    )


def downgrade() -> None:
    op.drop_column("notification_settings", "quarantine_bcc_emails")
    op.drop_column("notification_settings", "quarantine_cc_emails")
    op.drop_column("notification_settings", "quarantine_emails")
    op.drop_column("notification_settings", "quarantine_email_enabled")
