"""Destinatarios propios para alertas críticas por correo

Revision ID: 0016
Revises: 0015
Create Date: 2026-08-28 15:40:00.000000

Las alertas del panel (IPS, DHCP, WAN, etc.) no deben usar los mismos
destinatarios ni el interruptor del reporte de navegación.
"""
from alembic import op
import sqlalchemy as sa


revision = "0016"
down_revision = "0015"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "notification_settings",
        sa.Column(
            "alert_email_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "alert_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "alert_cc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )
    op.add_column(
        "notification_settings",
        sa.Column(
            "alert_bcc_emails",
            sa.String(length=1000),
            nullable=False,
            server_default="",
        ),
    )

    # Antes las alertas críticas reutilizaban los destinatarios del
    # reporte de navegación; copiamos para no perder avisos ya activos.
    op.execute(
        """
        UPDATE notification_settings
        SET alert_emails = to_emails
        WHERE COALESCE(to_emails, '') != ''
          AND COALESCE(alert_emails, '') = ''
        """
    )


def downgrade() -> None:
    op.drop_column("notification_settings", "alert_bcc_emails")
    op.drop_column("notification_settings", "alert_cc_emails")
    op.drop_column("notification_settings", "alert_emails")
    op.drop_column("notification_settings", "alert_email_enabled")
