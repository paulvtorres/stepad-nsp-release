"""
Comprobaciones profundas de salud para navegación/DHCP/DNS.

Usado por el banner del panel y el monitor periódico.
"""

from __future__ import annotations

import socket
import struct
import subprocess
import time
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.core.config.settings import Settings
from backend.dhcp.services.dhcp_health_service import DhcpHealthService
from backend.dns.logging.dns_query_log_listener import (
    LISTEN_HOST,
    LISTEN_PORT,
    dns_query_log_listener,
)
from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.shared.config.config_service import ConfigService
from backend.shared.enums.dns_engine import DnsEngine


# Sin consultas DNS protobuf en este tiempo → listener probablemente roto.
LISTENER_STALE_MINUTES = 30

# Umbral de disco libre mínimo (MB) para alertar.
DISK_FREE_WARN_MB = 512


def _encode_dns_name(name: str) -> bytes:
    parts = name.strip(".").split(".")
    out = b""
    for part in parts:
        label = part.encode("ascii", errors="ignore")[:63]
        out += bytes([len(label)]) + label
    return out + b"\x00"


def probe_dns_a(
    resolver: str,
    qname: str = "google.com",
    timeout: float = 2.0,
) -> bool:
    """Resuelve un A vía UDP contra resolver. False si falla."""

    if not resolver:

        return False

    try:

        query_id = 0xABCD

        header = struct.pack(
            "!HHHHHH",
            query_id,
            0x0100,
            1,
            0,
            0,
            0,
        )

        payload = header + _encode_dns_name(qname) + struct.pack("!HH", 1, 1)

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        sock.settimeout(timeout)

        sock.sendto(payload, (resolver, 53))

        data, _ = sock.recvfrom(512)

        sock.close()

        if len(data) < 12:

            return False

        flags = struct.unpack("!H", data[2:4])[0]

        rcode = flags & 0xF

        ancount = struct.unpack("!H", data[6:8])[0]

        return rcode == 0 and ancount > 0

    except Exception:

        return False


def _listener_port_open() -> bool:

    try:

        with socket.create_connection(
            (LISTEN_HOST, LISTEN_PORT),
            timeout=2,
        ):
            return True

    except Exception:

        return False


def _recent_dns_log(db: Session, minutes: int) -> int:

    since = datetime.utcnow() - timedelta(minutes=minutes)

    return (
        db.query(DnsQueryLog.id)
        .filter(DnsQueryLog.queried_at >= since)
        .count()
    )


def _pdns_active() -> bool:

    try:

        result = subprocess.run(
            ["systemctl", "is-active", "pdns-recursor"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        return result.stdout.strip() == "active"

    except Exception:

        return False


def _suricata_active() -> bool:

    try:

        result = subprocess.run(
            ["systemctl", "is-active", "suricata"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        return result.stdout.strip() == "active"

    except Exception:

        return False


def _disk_free_mb(path: str = "/") -> int:

    try:

        import shutil

        usage = shutil.disk_usage(path)

        return int(usage.free / (1024 * 1024))

    except Exception:

        return 0


def _ips_enabled(db: Session) -> bool:

    try:

        from backend.system.services.module_service import ModuleService

        modules = ModuleService().get_modules(db)

        ips = next(
            (module for module in modules if module["key"] == "ips"),
            None,
        )

        return bool(ips and ips.get("enabled"))

    except Exception:

        return False


class NavigationHealthService:

    def __init__(self):

        self.dhcp_health = DhcpHealthService()

    def inspect(self, db: Session) -> dict:
        """
        Devuelve checks con ok/detail para el panel y monitor.
        """

        dhcp = self.dhcp_health.inspect()

        dhcp_ok = bool(dhcp.get("healthy"))

        if not dhcp.get("running"):

            dhcp_detail = "DHCP inactivo — los equipos no reciben IP"

        elif dhcp.get("stuck"):

            dhcp_detail = (
                f"DHCP colgado (cola UDP 67 = {dhcp.get('recv_q', '?')} bytes)"
            )

        else:

            dhcp_detail = "DHCP respondiendo con normalidad"

        dhcp_cfg = ConfigService().get_dhcp_config() or {}

        dns_server = (
            dhcp_cfg.get("dns_server")
            or dhcp_cfg.get("gateway")
            or "127.0.0.1"
        )

        dns_resolves = probe_dns_a(dns_server)

        pdns_ok = _pdns_active()

        if Settings.DNS_ENGINE != DnsEngine.DNSMASQ:

            dns_ok = pdns_ok and dns_resolves

            if not pdns_ok:

                dns_detail = "pdns-recursor no está activo"

            elif not dns_resolves:

                dns_detail = (
                    f"El resolver ({dns_server}) no responde consultas DNS"
                )

            else:

                dns_detail = f"DNS responde en {dns_server}"

        else:

            dns_ok = dns_resolves

            dns_detail = (
                f"DNS responde en {dns_server}"
                if dns_ok
                else f"DNS no responde en {dns_server}"
            )

        listener_port = _listener_port_open()

        listener_started = dns_query_log_listener.is_started()

        last_msg = dns_query_log_listener.last_message_at()

        listener_age_min = None

        if last_msg is not None:

            listener_age_min = int(
                (time.time() - last_msg) / 60
            )

        recent_logs = _recent_dns_log(db, LISTENER_STALE_MINUTES)

        if not listener_started:

            listener_ok = listener_port

            listener_detail = (
                "Listener de navegación no arrancó en este proceso"
                if not listener_port
                else "Puerto 4242 abierto (listener parcial)"
            )

        elif not listener_port:

            listener_ok = False

            listener_detail = (
                "El listener de logs DNS (127.0.0.1:4242) no responde"
            )

        elif pdns_ok and recent_logs == 0 and (
            listener_age_min is None
            or listener_age_min >= LISTENER_STALE_MINUTES
        ):

            listener_ok = False

            listener_detail = (
                "Sin tráfico DNS registrado en "
                f"{LISTENER_STALE_MINUTES} min — "
                "pdns puede estar desconectado del listener"
            )

        else:

            listener_ok = True

            if listener_age_min is not None and listener_age_min < 5:

                listener_detail = (
                    "Registro de navegación activo "
                    f"(último evento hace {listener_age_min} min)"
                )

            elif recent_logs > 0:

                listener_detail = (
                    f"Registro de navegación activo "
                    f"({recent_logs} consultas en "
                    f"{LISTENER_STALE_MINUTES} min)"
                )

            else:

                listener_detail = "Listener DNS escuchando en 127.0.0.1:4242"

        internet_ok = False

        try:

            with socket.create_connection(("1.1.1.1", 443), timeout=3):

                internet_ok = True

        except Exception:

            internet_ok = False

        forwarding_ok = False

        try:

            result = subprocess.run(
                ["sysctl", "-n", "net.ipv4.ip_forward"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            forwarding_ok = result.stdout.strip() == "1"

        except Exception:

            forwarding_ok = False

        ips_enabled = _ips_enabled(db)

        suricata_ok = True

        suricata_detail = "IPS desactivado en módulos"

        if ips_enabled:

            suricata_ok = _suricata_active()

            suricata_detail = (
                "Suricata activo"
                if suricata_ok
                else "IPS activo pero Suricata no está corriendo"
            )

        free_mb = _disk_free_mb()

        disk_ok = free_mb >= DISK_FREE_WARN_MB

        disk_detail = (
            f"Disco libre: {free_mb} MB"
            if disk_ok
            else f"Poco espacio en disco ({free_mb} MB libres)"
        )

        zones_ok = True

        zones_detail = "Sin zonas de red adicionales"

        try:

            from backend.network.zones.repositories.network_zone_repository import (
                NetworkZoneRepository,
            )
            from backend.dns.providers.zone_pdns_provider import (
                ZonePdnsProvider,
            )

            zones = NetworkZoneRepository().find_all(db)

            if zones:

                down = []

                for zone in zones:

                    if not ZonePdnsProvider(zone).get_status().get("running"):

                        down.append(zone.name or str(zone.id))

                if down:

                    zones_ok = False

                    zones_detail = (
                        "Resolver DNS caído en zonas: "
                        + ", ".join(down)
                    )

                else:

                    zones_detail = f"DNS activo en {len(zones)} zona(s)"

        except Exception:

            pass

        try:

            from backend.network.configuration.services.network_topology_check_service import (
                NetworkTopologyCheckService,
            )

            conflicts = NetworkTopologyCheckService().get_conflicts()

        except Exception:

            conflicts = {"ok": True, "detail": "Sin conflictos de red"}

        checks = {
            "internet": {
                "ok": internet_ok,
                "detail": (
                    "El NSP tiene salida a internet"
                    if internet_ok
                    else "El NSP no alcanza internet"
                ),
            },
            "dhcp": {
                "ok": dhcp_ok,
                "detail": dhcp_detail,
            },
            "dns": {
                "ok": dns_ok,
                "detail": dns_detail,
            },
            "log_listener": {
                "ok": listener_ok,
                "detail": listener_detail,
            },
            "forwarding": {
                "ok": forwarding_ok,
                "detail": (
                    "Reenvío (NAT) activo"
                    if forwarding_ok
                    else "Reenvío desactivado"
                ),
            },
            "suricata": {
                "ok": suricata_ok,
                "detail": suricata_detail,
            },
            "disk": {
                "ok": disk_ok,
                "detail": disk_detail,
            },
            "zones_dns": {
                "ok": zones_ok,
                "detail": zones_detail,
            },
            "conflicto": {
                "ok": conflicts.get("ok", True),
                "detail": conflicts.get("detail", "Sin conflictos de red"),
            },
        }

        ok = all(check["ok"] for check in checks.values())

        return {
            "ok": ok,
            "checks": checks,
            "dhcp_snapshot": dhcp,
        }
