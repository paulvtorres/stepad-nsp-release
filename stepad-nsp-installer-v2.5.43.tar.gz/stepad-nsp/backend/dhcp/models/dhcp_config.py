from dataclasses import dataclass, field


@dataclass
class DhcpConfig:

    interface: str

    network: str

    netmask: str

    gateway: str

    dns_server: str

    pool_start: str

    pool_end: str

    lease_time: str

    # IPs que el DHCP no debe entregar nunca (dispositivos con IP estatica).
    excluded_ips: list[str] = field(default_factory=list)

    # Subrango exclusivo para alias DNS de grupos (no se mezcla con equipos).
    group_ip_start: str | None = None

    group_ip_end: str | None = None

    group_ip_count: int | None = None