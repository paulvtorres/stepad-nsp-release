"""
Salud operativa del DHCP (dnsmasq).

Detecta proceso caído o colgado (cola UDP 67 llena / bloqueado en
pipe) y reintenta arrancar. Genera alerta crítica en el panel y, si
hay destinatarios de alertas configurados, un aviso inmediato.
"""

from __future__ import annotations

import re
import subprocess
import time

from sqlalchemy.orm import Session

from backend.alerts.services.alert_service import AlertService
from backend.core.dnsmasq.process_manager import (
    DNSMASQ_BIN,
    dnsmasq_process_manager,
)
from backend.shared.logging.logger import logger


# Cola Recv-Q en bytes. DHCP sano suele estar en 0; si el proceso
# deja de leer el socket (p. ej. bloqueado en logs) la cola crece.
STUCK_RECVQ_BYTES = 8192

# No repetir correo/alerta cada 30s del monitor.
ALERT_COOLDOWN_SECONDS = 1800


_SS_LINE = re.compile(
    r"^(?:UNCONN|UNCONN-P)\s+(\d+)\s+\d+\s+\S+:67\b"
)


def udp67_recv_queue_bytes(ss_output: str | None = None) -> int:
    """Recv-Q de UDP/67 de nuestro dnsmasq. 0 si no escucha."""

    if ss_output is None:

        result = subprocess.run(
            ["ss", "-ulnp"],
            capture_output=True,
            text=True,
        )

        ss_output = result.stdout or ""

    best = 0

    for line in ss_output.splitlines():

        if ":67" not in line:

            continue

        if DNSMASQ_BIN not in line and "dnsmasq" not in line:

            continue

        match = _SS_LINE.search(line.strip())

        if match:

            best = max(best, int(match.group(1)))

    return best


class DhcpHealthService:

    def __init__(self):

        self.alert_service = AlertService()

        self._last_alert_at: float = 0.0

    def inspect(self) -> dict:

        status = dnsmasq_process_manager.status()

        recv_q = 0

        if status.get("running"):

            try:

                recv_q = udp67_recv_queue_bytes()

            except Exception as error:

                logger.warning("DHCP health: no se leyó Recv-Q: %s", error)

        stuck = bool(status.get("running") and recv_q >= STUCK_RECVQ_BYTES)

        return {
            "running": bool(status.get("running")),
            "pid": status.get("pid"),
            "recv_q": recv_q,
            "stuck": stuck,
            "healthy": bool(status.get("running") and not stuck),
        }

    def ensure_healthy(self, db: Session) -> dict:

        snap = self.inspect()

        if snap["healthy"]:

            return snap

        if not snap["running"]:

            title = "DHCP caído: los equipos no reciben IP"
            message = (
                "El servicio DHCP (dnsmasq) no está en ejecución. "
                "STEPAD intenta reiniciarlo."
            )
            reason = "down"

        else:

            title = "DHCP colgado: no responde a pedidos de IP"
            message = (
                f"El servidor DHCP está escuchando pero no procesa "
                f"peticiones (cola UDP 67 = {snap['recv_q']} bytes). "
                "STEPAD intenta reiniciarlo."
            )
            reason = "stuck"

        logger.error("DHCP %s: %s", reason, message)

        restarted = dnsmasq_process_manager.restart()

        snap["restart"] = restarted
        snap["reason"] = reason

        self._raise_alert(db, title, message)

        return snap

    def _raise_alert(self, db: Session, title: str, message: str) -> None:

        now = time.time()

        if now - self._last_alert_at < ALERT_COOLDOWN_SECONDS:

            return

        self._last_alert_at = now

        try:

            self.alert_service.create(
                db,
                alert_type="DHCP_HEALTH",
                severity="critical",
                title=title,
                message=message,
            )

        except Exception as error:

            logger.error("DHCP health: no se creó alerta: %s", error)

        self._send_email(db, title, message)

    def _send_email(self, db: Session, title: str, message: str) -> None:

        try:

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            html_body = f"""
            <p><strong>{title}</strong></p>
            <p>{message}</p>
            <p>Revise <em>Alertas</em> en el panel del NSP y que los
            equipos vuelvan a obtener IP (renovar DHCP).</p>
            """

            CriticalAlertEmailService().send(
                db,
                title,
                message,
                html_body=html_body,
            )

        except Exception as error:

            logger.warning("DHCP health: no se envió correo: %s", error)
