from pathlib import Path

from backend.core.config.paths import DNSMASQ_LOG_FILE


class DhcpLogService:

    def _log_paths(self) -> list[Path]:

        paths = [DNSMASQ_LOG_FILE]

        for index in range(1, 4):

            rotated = DNSMASQ_LOG_FILE.with_name(
                f"{DNSMASQ_LOG_FILE.name}.{index}"
            )

            if rotated.exists():

                paths.append(rotated)

        return paths

    def tail(
        self,
        lines: int = 200,
        search: str | None = None,
    ) -> dict:

        limit = max(1, min(lines, 1000))

        needle = (search or "").strip().lower()

        collected: list[str] = []

        for path in self._log_paths():

            if not path.exists():

                continue

            try:

                content = path.read_text(
                    encoding="utf-8",
                    errors="replace",
                ).splitlines()

            except OSError:

                continue

            for line in reversed(content):

                if needle and needle not in line.lower():

                    continue

                collected.append(line)

                if len(collected) >= limit:

                    break

            if len(collected) >= limit:

                break

        collected.reverse()

        return {
            "lines": collected,
            "count": len(collected),
            "log_file": str(DNSMASQ_LOG_FILE),
            "search": search or "",
        }
