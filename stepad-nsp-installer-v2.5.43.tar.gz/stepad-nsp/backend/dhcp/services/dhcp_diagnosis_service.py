import subprocess

from backend.core.config.paths import (

    DNSMASQ_CONFIG

)

from backend.dhcp.models.dhcp_diagnosis import (

    DhcpDiagnosis,

    DhcpCheck

)

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.shared.config.config_service import (
    ConfigService
)

from backend.dhcp.services.dhcp_process_service import (

    DhcpProcessService

)

from backend.core.dnsmasq.process_manager import (

    DNSMASQ_BIN

)


class DhcpDiagnosisService:

    def __init__(self):

        self.interface_service = InterfaceService()

        self.config_service = ConfigService()

        self.process_service = DhcpProcessService()


    def diagnose(self):

        checks = []

        healthy = True


        config = self.config_service.get_dhcp_config()

        lan = self.interface_service.get_primary_lan()


        checks.append(

            DhcpCheck(

                name="LAN Interface",

                status="OK" if lan else "FAILED",

                message=(

                    lan.name

                    if lan

                    else "No LAN interface configured"

                ),

                action=(

                    None

                    if lan

                    else "Configure a LAN interface"

                )

            )

        )


        if lan is None:

            healthy = False



        config_exists = DNSMASQ_CONFIG.exists()


        checks.append(

            DhcpCheck(

                name="Configuration File",

                status="OK" if config_exists else "FAILED",

                message=str(DNSMASQ_CONFIG),

                action=(

                    None

                    if config_exists

                    else "Generate DHCP configuration"

                )

            )

        )


        if not config_exists:

            healthy = False



        network_ok = bool(config.get("network"))


        checks.append(

            DhcpCheck(

                name="Network",

                status="OK" if network_ok else "FAILED",

                message=(

                    config.get("network")

                    or "Not configured"

                ),

                action=(

                    None

                    if network_ok

                    else "Configure DHCP network"

                )

            )

        )


        if not network_ok:

            healthy = False



        gateway_ok = bool(config.get("gateway"))


        checks.append(

            DhcpCheck(

                name="Gateway",

                status="OK" if gateway_ok else "FAILED",

                message=(

                    config.get("gateway")

                    or "Not configured"

                ),

                action=(

                    None

                    if gateway_ok

                    else "Configure gateway"

                )

            )

        )


        if not gateway_ok:

            healthy = False



        pool_ok = (

            bool(config.get("pool_start"))

            and

            bool(config.get("pool_end"))

        )


        checks.append(

            DhcpCheck(

                name="DHCP Pool",

                status="OK" if pool_ok else "FAILED",

                message=(

                    f'{config.get("pool_start")} - {config.get("pool_end")}'

                    if pool_ok

                    else "Pool not configured"

                ),

                action=(

                    None

                    if pool_ok

                    else "Configure DHCP address pool"

                )

            )

        )


        if not pool_ok:

            healthy = False



        status = self.process_service.status()

        running = status["running"]



        checks.append(

            DhcpCheck(

                name="Process",

                status="OK" if running else "FAILED",

                message=(
                    "DHCP service running"
                    if running
                    else "DHCP service stopped"
                ),

                action=(

                    None

                    if running

                    else "Start DHCP service"

                )

            )

        )


        if not running:

            healthy = False



        if config_exists:


            result = subprocess.run(

                [

                    DNSMASQ_BIN,

                    "--test",

                    f"--conf-file={DNSMASQ_CONFIG}"

                ],

                capture_output=True,

                text=True

            )


            syntax_ok = result.returncode == 0


            checks.append(

                DhcpCheck(

                    name="Configuration Test",

                    status="OK" if syntax_ok else "FAILED",

                    message=(

                        result.stdout.strip()

                        or result.stderr.strip()

                    ),

                    action=(

                        None

                        if syntax_ok

                        else "Review dnsmasq configuration"

                    )

                )

            )


            if not syntax_ok:

                healthy = False



        else:


            checks.append(

                DhcpCheck(

                    name="Configuration Test",

                    status="SKIPPED",

                    message="Configuration file not found",

                    action=None

                )

            )



        port_check = subprocess.run(

            [

                "ss",

                "-lunp"

            ],

            capture_output=True,

            text=True

        )


        port_lines = [

            line

            for line in port_check.stdout.splitlines()

            if ":67" in line

        ]


        external_dhcp = [

            line

            for line in port_lines

            if DNSMASQ_BIN not in line

        ]


        port_ok = (

            running

            or not external_dhcp

        )


        checks.append(

            DhcpCheck(

                name="UDP Port 67",

                status="OK" if port_ok else "FAILED",

                message=(

                    "DHCP service owns UDP port 67"

                    if running

                    else (

                        "UDP port 67 available"

                        if not port_lines

                        else "Another service is using UDP port 67"

                    )

                ),

                action=(

                    None

                    if port_ok

                    else "Stop the service using UDP port 67"

                )

            )

        )


        if not port_ok:

            healthy = False



        recv_q = 0

        if running:

            try:

                from backend.dhcp.services.dhcp_health_service import (
                    STUCK_RECVQ_BYTES,
                    udp67_recv_queue_bytes,
                )

                recv_q = udp67_recv_queue_bytes(port_check.stdout)

                queue_ok = recv_q < STUCK_RECVQ_BYTES

            except Exception:

                queue_ok = True

            checks.append(

                DhcpCheck(

                    name="DHCP socket queue",

                    status="OK" if queue_ok else "FAILED",

                    message=(
                        f"UDP 67 Recv-Q={recv_q}"
                        if queue_ok
                        else (
                            f"DHCP colgado (cola UDP 67 = {recv_q} bytes)"
                        )
                    ),

                    action=(
                        None
                        if queue_ok
                        else "Reiniciar el servicio DHCP / STEPAD NSP"
                    )

                )

            )

            if not queue_ok:

                healthy = False



        summary = "DHCP is running"


        for check in checks:

            if check.status == "FAILED":

                summary = check.message

                break



        return DhcpDiagnosis(

            healthy=healthy,

            summary=summary,

            checks=checks

        )