"""
Ingesta de intentos WAN desde el log del kernel (nft log).

Las reglas nft escriben como máximo ~5 líneas/s (rate-limit). Este
servicio agrega por (src, puerto, proto, cadena) para no inflar la DB
bajo un barrido.
"""

from __future__ import annotations

import re
import subprocess
import threading
import time
from datetime import datetime, timedelta

from sqlalchemy.dialects.postgresql import insert as pg_insert

from backend.core.database.session import SessionLocal
from backend.firewall.models.wan_probe_event import WanProbeEvent
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc


LOG_MARKERS = {
    "STEPAD-WAN-IN": "input",
    "STEPAD-WAN-FW": "forward",
}

# journalctl -k; solo líneas con nuestros prefijos.
_LINE_RE = re.compile(
    r"(?P<marker>STEPAD-WAN-(?:IN|FW)).*?"
    r"SRC=(?P<src>\S+).*?"
    r"(?:DST=(?P<dst>\S+).*?)?"
    r"PROTO=(?P<proto>\S+)"
    r"(?:.*?DPT=(?P<dpt>\d+))?",
    re.IGNORECASE,
)

# Retención: borrar agregados más viejos que N días.
RETENTION_DAYS = 30


class WanProbeIngestService:

    def __init__(self):

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self):

        if self._thread and self._thread.is_alive():

            return

        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="wan-probe-ingest",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "Ingesta de intentos WAN iniciada (nft log rate-limited)."
        )

    def stop(self):

        self._stop.set()

    def _loop(self):

        # Cursor: no reprocesar el boot entero en cada arranque.
        since = datetime.utcnow() - timedelta(seconds=30)

        while not self._stop.is_set():

            try:

                self._poll_since(since)
                since = datetime.utcnow() - timedelta(seconds=5)
                self._purge_old()

            except Exception as error:

                logger.warning("WAN probe ingest: %s", error)

            self._stop.wait(8)

    def _poll_since(self, since: datetime):

        since_arg = since.strftime("%Y-%m-%d %H:%M:%S")

        result = subprocess.run(
            [
                "journalctl",
                "-k",
                "--since", since_arg,
                "--no-pager",
                "-o", "short-iso",
            ],
            capture_output=True,
            text=True,
            timeout=20,
        )

        if result.returncode != 0:

            return

        batch: dict[tuple, int] = {}

        for line in result.stdout.splitlines():

            if "STEPAD-WAN-" not in line:

                continue

            parsed = self._parse(line)

            if not parsed:

                continue

            key = (
                parsed["src_ip"],
                parsed["dst_port"],
                parsed["protocol"],
                parsed["chain"],
            )
            batch[key] = batch.get(key, 0) + 1

        if not batch:

            return

        self._upsert_batch(batch)

    def _parse(self, line: str) -> dict | None:

        match = _LINE_RE.search(line)

        if not match:

            return None

        marker = match.group("marker").upper()
        chain = LOG_MARKERS.get(marker)

        if not chain:

            return None

        proto = (match.group("proto") or "tcp").lower()
        if proto.startswith("tcp"):
            proto = "tcp"
        elif proto.startswith("udp"):
            proto = "udp"
        elif proto.startswith("icmp"):
            proto = "icmp"

        dpt = match.group("dpt")
        dst_port = int(dpt) if dpt else None

        return {
            "src_ip": match.group("src"),
            "dst_port": dst_port,
            "protocol": proto,
            "chain": chain,
        }

    def _upsert_batch(self, batch: dict[tuple, int]):

        now = datetime.utcnow()
        db = SessionLocal()

        try:

            for (src, dport, proto, chain), hits in batch.items():

                stmt = pg_insert(WanProbeEvent).values(
                    src_ip=src,
                    dst_port=dport,
                    protocol=proto,
                    chain=chain,
                    hit_count=hits,
                    first_seen=now,
                    last_seen=now,
                )
                stmt = stmt.on_conflict_do_update(
                    constraint="uq_wan_probe_agg",
                    set_={
                        "hit_count": WanProbeEvent.hit_count + hits,
                        "last_seen": now,
                    },
                )
                db.execute(stmt)

            db.commit()

        except Exception:

            db.rollback()
            raise

        finally:

            db.close()

    def _purge_old(self):

        # Cada ~50 ciclos (~6 min) bastaría; aquí barato y raro.
        if int(time.time()) % 50 != 0:

            return

        cutoff = datetime.utcnow() - timedelta(days=RETENTION_DAYS)
        db = SessionLocal()

        try:

            (
                db.query(WanProbeEvent)
                .filter(WanProbeEvent.last_seen < cutoff)
                .delete(synchronize_session=False)
            )
            db.commit()

        except Exception:

            db.rollback()

        finally:

            db.close()

    def list_recent(
        self,
        *,
        limit: int = 100,
        hours: int = 24,
    ) -> dict:

        since = datetime.utcnow() - timedelta(hours=max(1, hours))
        db = SessionLocal()

        try:

            rows = (
                db.query(WanProbeEvent)
                .filter(WanProbeEvent.last_seen >= since)
                .order_by(WanProbeEvent.last_seen.desc())
                .limit(min(limit, 500))
                .all()
            )

            events = [
                {
                    "id": row.id,
                    "src_ip": row.src_ip,
                    "dst_port": row.dst_port,
                    "protocol": row.protocol,
                    "chain": row.chain,
                    "hit_count": row.hit_count,
                    "first_seen": to_iso_utc(row.first_seen),
                    "last_seen": to_iso_utc(row.last_seen),
                    "target": (
                        "NSP (este equipo)"
                        if row.chain == "input"
                        else "Red interna (forward)"
                    ),
                }
                for row in rows
            ]

            total_hits = sum(e["hit_count"] for e in events)

            return {
                "hours": hours,
                "count": len(events),
                "total_hits": total_hits,
                "events": events,
                "log_rate_limit": "5/second (nft)",
                "retention_days": RETENTION_DAYS,
                "warning": (
                    "El log está limitado a ~5 eventos/s para no saturar "
                    "disco/CPU bajo un barrido. Un flood grande se sigue "
                    "bloqueando; solo se registra una muestra."
                ),
            }

        finally:

            db.close()


wan_probe_ingest = WanProbeIngestService()
