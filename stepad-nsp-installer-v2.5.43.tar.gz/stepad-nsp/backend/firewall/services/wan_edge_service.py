"""
Protección perimetral WAN (borde profesional).

Se aplica junto al hardening deny-all. Objetivos:

1. Proteger el NSP: rate-limit de SSH/8443 incluso desde RFC1918
   (un equipo infectado en LAN no puede forzar credenciales sin freno).
2. Proteger la LAN del cliente: los port-forwards publicados pasan el
   deny-all de forma controlada (allowlist) y siguen pasando por
   Suricata NFQUEUE en forward; con límite de conexiones nuevas.
3. No abrir SSH/8443 a Internet público (sigue restringido a privadas).

Sin candados propios: el caller (hardening) ya entra bajo resource_locks.nft.
"""

from __future__ import annotations

import subprocess

from sqlalchemy.orm import Session

from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger


NFT = "/usr/sbin/nft"

# Límites defensivos (nuevas conexiones). Burst absorbe picos legítimos.
ADMIN_RATE = "20/minute"
ADMIN_BURST = "10"
# Por servicio publicado: tope de conexiones concurrentes nuevas
# hacia ese destino (anti-flood hacia el servidor interno).
PUBLISHED_CONN_MAX = 40
PUBLISHED_NEW_RATE = "30/second"
PUBLISHED_NEW_BURST = "20"

# Log de intentos WAN: rate bajo a propósito. Un barrido/DDoS sigue
# bloqueándose por policy drop; solo se registra una muestra para no
# saturar journald/disco/CPU.
WAN_PROBE_LOG_RATE = "5/second"
WAN_PROBE_LOG_BURST = "10"

PRIVATE_CIDRS = ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")


class WanEdgeService:

    def _run(self, args: list[str]) -> dict:

        result = subprocess.run(
            [NFT] + args,
            capture_output=True,
            text=True,
        )

        return {
            "success": result.returncode == 0,
            "stderr": result.stderr.strip(),
        }

    def enrich_hardening(
        self,
        db: Session | None = None,
    ) -> dict:
        """
        Añade reglas de borde a harden-input / harden-forward ya creados.
        Idempotente respecto al ciclo completo de hardening (cadenas
        recreadas desde cero antes de llamar aquí).
        """

        owns_db = db is None

        if owns_db:

            db = SessionLocal()

        try:

            input_ok = self._apply_admin_rate_limits()

            forward_ok = self._apply_published_service_allows(db)

            log_ok = self._apply_wan_probe_logging()

            logger.info(
                "WAN edge: rate-limit admin=%s, port-forwards allow=%s, "
                "probe-log=%s",
                input_ok.get("success"),
                forward_ok.get("success"),
                log_ok.get("success"),
            )

            return {
                "success": (
                    input_ok.get("success")
                    and forward_ok.get("success")
                    and log_ok.get("success")
                ),
                "admin_rate_limit": input_ok,
                "published_allows": forward_ok,
                "probe_logging": log_ok,
            }

        finally:

            if owns_db:

                db.close()

    def _apply_admin_rate_limits(self) -> dict:
        """
        Sustituye el accept abierto de 22/8443 por accept con rate-limit.
        Llamar DESPUÉS de las reglas base, ANTES de WireGuard/Tailscale
        (esas no se rate-limitan: ya van autenticadas).
        """

        results = []

        private = ", ".join(PRIVATE_CIDRS)

        # Una sola regla por puerto: accept bajo el límite; el exceso
        # cae en policy drop del harden-input (sin segundo medidor).
        for port in ("22", "8443"):

            results.append(self._run([
                "add", "rule", "inet", "stepad", "harden-input",
                "tcp", "dport", port,
                "ip", "saddr", "{", private, "}",
                "ct", "state", "new",
                "limit", "rate", ADMIN_RATE,
                "burst", ADMIN_BURST,
                "packets",
                "counter", "accept",
            ]))

            results.append(self._run([
                "add", "rule", "inet", "stepad", "harden-input",
                "tcp", "dport", port,
                "ip", "saddr", "{", private, "}",
                "ct", "state", "established,related",
                "accept",
            ]))

        failed = [r["stderr"] for r in results if not r["success"] and r["stderr"]]

        if failed:

            logger.warning("WAN edge admin rate-limit: %s", "; ".join(failed))

        return {
            "success": all(r["success"] for r in results),
            "stderr": "; ".join(failed),
        }

    def _apply_published_service_allows(self, db: Session) -> dict:
        """
        Allowlist en harden-forward para DNAT publicados.

        Tras DNAT, el paquete entra por WAN con daddr/dport internos.
        Sin estas reglas, deny-all los tira y el DMZ "no funciona".
        Con ellas, el tráfico sigue el forward normal → NFQUEUE Suricata.
        """

        try:

            from backend.nat.repositories.port_forward_repository import (
                PortForwardRepository,
            )

            forwards = PortForwardRepository().find_enabled(db)

        except Exception as error:

            logger.warning(
                "WAN edge: no se pudieron leer port-forwards: %s",
                error,
            )

            return {"success": True, "added": 0}

        added = 0
        results = []

        for forward in forwards:

            protocols = (
                ["tcp", "udp"]
                if (forward.protocol or "").lower() == "both"
                else [forward.protocol or "tcp"]
            )

            for protocol in protocols:

                # Anti-flood: demasiadas conexiones concurrentes → drop.
                results.append(self._run([
                    "add", "rule", "inet", "stepad", "harden-forward",
                    "iifname", "@stepad_wan_ifaces",
                    "ip", "daddr", str(forward.internal_ip),
                    protocol, "dport", str(forward.internal_port),
                    "ct", "state", "new",
                    "ct", "count", "over", str(PUBLISHED_CONN_MAX),
                    "counter", "drop",
                ]))

                # Rate de SYNs hacia el servicio publicado.
                results.append(self._run([
                    "add", "rule", "inet", "stepad", "harden-forward",
                    "iifname", "@stepad_wan_ifaces",
                    "ip", "daddr", str(forward.internal_ip),
                    protocol, "dport", str(forward.internal_port),
                    "ct", "state", "new",
                    "limit", "rate", "over", PUBLISHED_NEW_RATE,
                    "burst", PUBLISHED_NEW_BURST,
                    "packets",
                    "counter", "drop",
                ]))

                results.append(self._run([
                    "add", "rule", "inet", "stepad", "harden-forward",
                    "iifname", "@stepad_wan_ifaces",
                    "ip", "daddr", str(forward.internal_ip),
                    protocol, "dport", str(forward.internal_port),
                    "counter", "accept",
                ]))

                added += 1

        failed = [r["stderr"] for r in results if not r["success"] and r["stderr"]]

        if failed:

            # ct count puede no existir en nft viejo; no tumbar hardening.
            logger.warning(
                "WAN edge published allows (parcial): %s",
                "; ".join(failed[:3]),
            )

        return {
            "success": True,
            "added": added,
            "stderr": "; ".join(failed),
        }

    def _apply_wan_probe_logging(self) -> dict:
        """
        Al final de harden-input/forward: log rate-limited de NEW desde WAN.
        No hace drop (lo hace la policy); solo deja evidencia muestreada.
        """

        results = []

        for chain, prefix in (
            ("harden-input", "STEPAD-WAN-IN "),
            ("harden-forward", "STEPAD-WAN-FW "),
        ):

            results.append(self._run([
                "add", "rule", "inet", "stepad", chain,
                "iifname", "@stepad_wan_ifaces",
                "ct", "state", "new",
                "limit", "rate", WAN_PROBE_LOG_RATE,
                "burst", WAN_PROBE_LOG_BURST,
                "packets",
                "log", "prefix", prefix,
                "level", "warn",
                "flags", "ip", "options",
                "counter",
            ]))

        failed = [r["stderr"] for r in results if not r["success"] and r["stderr"]]

        if failed:

            logger.warning("WAN probe log rules: %s", "; ".join(failed))

        return {
            "success": all(r["success"] for r in results),
            "rate": WAN_PROBE_LOG_RATE,
            "stderr": "; ".join(failed),
        }

    def status(self, db: Session | None = None) -> dict:

        owns_db = db is None

        if owns_db:

            db = SessionLocal()

        try:

            from backend.nat.repositories.port_forward_repository import (
                PortForwardRepository,
            )

            forwards = PortForwardRepository().find_enabled(db)

            return {
                "enabled_with_hardening": True,
                "admin_rate_limit": f"{ADMIN_RATE} (burst {ADMIN_BURST})",
                "published_conn_max": PUBLISHED_CONN_MAX,
                "published_new_rate": PUBLISHED_NEW_RATE,
                "published_services": len(forwards),
                "probe_log_rate": WAN_PROBE_LOG_RATE,
                "notes": (
                    "SSH/8443 no se abren a Internet. Los port-forwards "
                    "pasan deny-all con límites y Suricata en forward. "
                    f"Intentos WAN se registran como muestra "
                    f"({WAN_PROBE_LOG_RATE}) para no saturar el disco."
                ),
            }

        finally:

            if owns_db:

                db.close()
