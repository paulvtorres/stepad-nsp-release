from datetime import datetime

from sqlalchemy import String, Integer, DateTime, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class WanProbeEvent(Base):

    __tablename__ = "wan_probe_events"

    __table_args__ = (
        UniqueConstraint(
            "src_ip",
            "dst_port",
            "protocol",
            "chain",
            name="uq_wan_probe_agg",
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    src_ip: Mapped[str] = mapped_column(String(45), nullable=False, index=True)

    dst_port: Mapped[int | None] = mapped_column(Integer, nullable=True)

    protocol: Mapped[str] = mapped_column(String(16), nullable=False, default="tcp")

    # input = golpe al NSP; forward = hacia LAN (tras deny / antes de drop)
    chain: Mapped[str] = mapped_column(String(16), nullable=False, default="input")

    hit_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    first_seen: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    last_seen: Mapped[datetime] = mapped_column(DateTime, nullable=False, index=True)
