from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.firewall.adapters.linux.linux_firewall_provider import (
    LinuxFirewallProvider
)

from backend.firewall.dns_security.services.encrypted_dns_service import (
    EncryptedDnsService
)

from backend.shared.logging.logger import logger



class FirewallComponent(BaseComponent):


    name = "firewall"

    criticality = ComponentCriticality.IMPORTANT



    def __init__(self):

        self.provider = LinuxFirewallProvider()

        self.encrypted_dns_service = EncryptedDnsService()



    def start(self):

        logger.info(
            "FirewallComponent started."
        )


        result = self.provider.initialize()


        logger.info(
            f"Firewall initialization: {result}"
        )


        try:

            from backend.firewall.services.firewall_hardening_service import (
                FirewallHardeningService
            )

            hardening = FirewallHardeningService()

            settings = hardening.get_settings()

            if settings.get("hardening_enabled"):

                hardening.set_enabled(True)

                logger.info(
                    "Hardening deny-all aplicado en el arranque."
                )

            else:

                hardening.set_enabled(False)

        except Exception as error:

            logger.error(
                f"Fallo al sincronizar hardening: {error}"
            )


        try:

            self.encrypted_dns_service.reapply_on_boot()

        except Exception as error:

            logger.error(
                f"Failed to reapply encrypted DNS blocking on boot: {error}"
            )


        # Detectar reinicios repentinos (sin apagado limpio): registra
        # en auditoria y alertas si la maquina se reinicio de golpe.
        try:

            from backend.system.services.reboot_tracker import (
                RebootTracker
            )

            RebootTracker.record_boot()

        except Exception as error:

            logger.error(
                f"Reboot tracker failed: {error}"
            )

        try:

            from backend.firewall.services.wan_probe_ingest_service import (
                wan_probe_ingest,
            )

            wan_probe_ingest.start()

        except Exception as error:

            logger.error(
                "WAN probe ingest no arrancó: %s",
                error,
            )



    def stop(self):

        try:

            from backend.firewall.services.wan_probe_ingest_service import (
                wan_probe_ingest,
            )

            wan_probe_ingest.stop()

        except Exception:

            pass

        logger.info(
            "FirewallComponent stopped."
        )
