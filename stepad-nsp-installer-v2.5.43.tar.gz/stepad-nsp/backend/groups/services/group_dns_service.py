import ipaddress
import subprocess
import time

from datetime import datetime
from pathlib import Path

from sqlalchemy.orm import Session

from backend.core.config.paths import DNS_DIR
from backend.core.dnsmasq.process_manager import dnsmasq_process_manager

from backend.groups.repositories.device_group_repository import (
    DeviceGroupRepository
)
from backend.groups.models.device_group import DeviceGroup

from backend.content.models.content_category import (
    ContentCategory,
    CategoryDomain,
    GroupCategory,
)
from backend.content.services.content_category_service import (
    ROOT_CATEGORY_KEYS,
)

from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository
)
from backend.groups.constants.group_dns_ip_reserve import (
    GROUP_DNS_ALIAS_FIRST_OFFSET,
    is_group_dns_alias_ip,
    merge_group_dns_exclusions,
    next_free_group_ip,
)
from backend.shared.logging.logger import logger
from backend.shared.runtime.resource_locks import resource_locks

# Compat cleanup: offset histórico (=10) respecto al primer host.
ALIAS_BASE_OFFSET = GROUP_DNS_ALIAS_FIRST_OFFSET + 1

from backend.shared.enums import RuleAction

from backend.network.devices.models.network_device import NetworkDevice


GROUPS_DNS_CONFIG = DNS_DIR / "groups_dns.conf"

GROUP_DIR = DNS_DIR / "group-dns"

PDNS_RECURSOR_BIN = "/usr/sbin/pdns_recursor"

REC_CONTROL_BIN = "/usr/bin/rec_control"

RPZ_TTL_SECONDS = 300

# Tabla nftables donde se redirige el DNS de cada equipo a su recursor
# de grupo (forzado por IP de origen, sin depender del DNS del cliente).
DNS_NAT_TABLE = "stepad-dnsnat"

# Dominios relacionados de ecosistemas conocidos: al bloquear la raiz,
# se bloquean tambien sus CDN y servicios auxiliares. Sin esto, bloquear
# "youtube.com" deja pasar el video, que se sirve desde googlevideo.com.
RELATED_DOMAINS = {
    "youtube.com": [
        "googlevideo.com",
        "redirector.googlevideo.com",
        "youtubei.googleapis.com",
        "ytimg.com",
        "s.ytimg.com",
        "yt3.ggpht.com",
        "youtu.be",
        "m.youtube.com",
        "www.youtube.com",
        "youtube-nocookie.com",
    ],
}


class GroupDnsService:

    def __init__(self):

        self.repository = DeviceGroupRepository()

        self.rule_repository = DeviceAccessRuleRepository()

    def _lan_prefixlen(self, lan_iface_name: str | None = None) -> int:
        """Prefijo de la LAN primaria (no asumir /24)."""
        try:
            from backend.network.services.lan_scope_service import (
                LanScopeService,
            )

            for cfg in LanScopeService().lan_configurations():
                if lan_iface_name and cfg.get("interface") != lan_iface_name:
                    continue
                cidr = cfg.get("network")
                if not cidr:
                    continue
                return int(ipaddress.ip_network(cidr, strict=False).prefixlen)
        except Exception:
            pass
        return 24

    def _alias_cidr(self, alias_ip: str, lan_name: str | None = None) -> str:
        return f"{alias_ip}/{self._lan_prefixlen(lan_name)}"

    # ------------------------------------------------------------------
    # Blocklist computation
    # ------------------------------------------------------------------

    def group_blocklist(
        self,
        db: Session,
        group: DeviceGroup
    ) -> list[str]:
        """
        Effective blocklist for a group:
          (global default blocks - group ALLOWs) | group BLOCKs | permanent blocks
        """

        now = datetime.utcnow()

        all_global = self.rule_repository.find_global_domains(db)

        permanent = {
            rule.value.strip().lower()
            for rule in all_global
            if rule.is_permanent
        }

        # Bloqueos de raiz: siempre en todo grupo, por encima de ALLOWs.
        root_category_ids = {
            row.id
            for row in (
                db.query(ContentCategory)
                .filter(ContentCategory.key.in_(ROOT_CATEGORY_KEYS))
                .all()
            )
        }

        if root_category_ids:

            root_domains = (
                db.query(CategoryDomain)
                .filter(CategoryDomain.category_id.in_(root_category_ids))
                .all()
            )

            permanent |= {
                row.domain.strip().lower()
                for row in root_domains
            }

        default = {
            rule.value.strip().lower()
            for rule in all_global
            if not rule.is_permanent
        }

        group_rules = (
            db.query(DeviceAccessRule)
            .filter(DeviceAccessRule.group_id == group.id)
            .all()
        )

        allows = {
            rule.value.strip().lower()
            for rule in group_rules
            if rule.action == RuleAction.ALLOW
        }

        blocks = {
            rule.value.strip().lower()
            for rule in group_rules
            if rule.action == RuleAction.BLOCK
        }

        # Categorias de contenido seleccionadas para este grupo
        # (perfil de navegacion por area). Sus dominios se suman al
        # blocklist del grupo.
        group_category_ids = {
            row.category_id
            for row in db.query(GroupCategory)
            .filter(GroupCategory.group_id == group.id)
            .all()
        }

        if group_category_ids:

            category_domains = (
                db.query(CategoryDomain)
                .filter(CategoryDomain.category_id.in_(group_category_ids))
                .all()
            )

            blocks |= {
                row.domain.strip().lower()
                for row in category_domains
            }

        effective = (default - allows) | blocks | permanent

        # Expandir dominios relacionados del ecosistema (CDN, subdominios).
        expanded = set(effective)

        for domain in effective:

            for related in RELATED_DOMAINS.get(
                domain.strip(".").lower(),
                (),
            ):

                expanded.add(related)

        return sorted(expanded)

    # ------------------------------------------------------------------
    # Alias IP allocation
    # ------------------------------------------------------------------

    def group_alias_ip(
        self,
        db: Session,
        group: DeviceGroup
    ) -> str | None:
        """
        IP LAN donde escucha el DNS del grupo.

        Fuente de verdad: ``DeviceGroup.dns_alias_ip`` (persistida al
        crear el grupo). No se reasigna al borrar otros grupos.
        """

        try:

            if group.dns_alias_ip:
                return group.dns_alias_ip

            # Backfill para grupos previos a la columna.
            used = {
                row[0]
                for row in (
                    db.query(DeviceGroup.dns_alias_ip)
                    .filter(DeviceGroup.dns_alias_ip.isnot(None))
                    .all()
                )
                if row[0]
            }
            free = next_free_group_ip(used)
            if free is None:
                logger.warning(
                    f"Grupo {group.id}: sin dns_alias_ip y sin IPs "
                    f"libres en el subrango de grupos."
                )
                return None

            group.dns_alias_ip = free
            db.commit()
            db.refresh(group)
            logger.info(
                f"Backfill dns_alias_ip={free} para grupo {group.id}"
            )
            return free

        except Exception as error:

            logger.warning(
                f"Could not allocate group DNS alias: {error}"
            )

            return None

    def _group_recursor_allow_from(self) -> list[str]:
        """
        LAN-only clients may query a group recursor. Never 0.0.0.0/0 —
        that would expose RPZ filtering as a public open resolver on the
        group alias IP.
        """

        from backend.network.configuration.services.network_configuration_service import (
            NetworkConfigurationService,
        )

        networks = sorted(
            {
                lan["network"]
                for lan in NetworkConfigurationService().get_lan_configurations()
                if lan.get("network")
            }
        )

        return ["127.0.0.1", *networks]

    # ------------------------------------------------------------------
    # Per-group recursor
    # ------------------------------------------------------------------

    def _ensure_recursor(
        self,
        group: DeviceGroup,
        alias_ip: str,
        blocklist: list[str]
    ):

        group_dir = GROUP_DIR / str(group.id)

        group_dir.mkdir(parents=True, exist_ok=True)

        rpz_file = group_dir / "blocked_domains.rpz"

        pid_file = group_dir / "pdns.pid"

        # Put the alias IP on the LAN interface (idempotent).
        try:

            from backend.network.interfaces.services.interface_service import (
                InterfaceService
            )

            lan = InterfaceService().get_primary_lan()

            if lan:

                subprocess.run(
                    [
                        "ip",
                        "addr",
                        "add",
                        self._alias_cidr(alias_ip, lan.name),
                        "dev",
                        lan.name,
                    ],
                    capture_output=True,
                    timeout=10
                )

        except Exception:

            pass

        # RPZ zone file.
        lines = ["$TTL 300\n@ IN SOA localhost. root.localhost. ( 1 300 300 300 300 )\n@ IN NS localhost.\n"]

        for domain in blocklist:

            lines.append(f"{domain} IN CNAME .\n")

        rpz_file.write_text("".join(lines))

        recursor_yml = group_dir / "recursor.yml"

        allow_from = self._group_recursor_allow_from()

        allow_from_yaml = "".join(
            f"  - {network}\n"
            for network in allow_from
        )

        # Formato YAML de PowerDNS 5.2 (incoming/recursor). El recursor
        # de grupo recusa de forma independiente: necesita hint_file.
        # El RPZ se define en YAML (no lua_config_file): pdns 5.2
        # rechaza lua_config_file si el YAML trae ajustes propios.
        recursor_yml.write_text(
            "incoming:\n"
            "  listen:\n"
            f"  - {alias_ip}\n"
            "  allow_from:\n"
            f"{allow_from_yaml}"
            "recursor:\n"
            # Socket de control PROPIO del grupo: sin esto pdns usa el
            # socket por defecto y choca con el recursor principal -> el
            # reload del RPZ iba al recursor equivocado y el bloqueo era
            # intermitente (a veces resolvia lo bloqueado).
            f"  socket_dir: {group_dir}\n"
            "  hint_file: /usr/share/dns/root.hints\n"
            "  security_poll_suffix: \"\"\n"
            "  rpzs:\n"
            f"  - name: {rpz_file}\n"
            "    defpol: NXDOMAIN\n"
            f"    policyName: stepad-group-{group.id}\n"
            "dnssec:\n"
            "  validation: \"off\"\n"
            # Enviar las respuestas al listener de registro del NSP
            # (127.0.0.1:4242), igual que el recursor principal: sin
            # esto, las consultas de los equipos del grupo no aparecian
            # en el log de navegacion.
            "logging:\n"
            "  protobuf_servers:\n"
            "  - servers:\n"
            "    - 127.0.0.1:4242\n"
            "    timeout: 2\n"
            "    reconnectWaitTime: 1\n"
            "    maxQueuedEntries: 100\n"
            "    asyncConnect: false\n"
            "    logQueries: false\n"
            "    logResponses: true\n"
            "    exportTypes:\n"
            "    - A\n"
            "    - AAAA\n"
        )


        # Detectar recursor ya corriendo para este grupo (por config-dir;
        # el pid_file no se escribe porque la config no define pid-file).
        pids = subprocess.run(
            ["pgrep", "-f", f"config-dir={group_dir}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        running_pids = [p.strip() for p in pids.stdout.split()]

        socket_path = str(group_dir / "pdns_recursor.controlsocket")

        if running_pids:

            # Si recursor.yml se modifico DESPUES del arranque del proceso
            # (p. ej. tras actualizar a una version que agrega socket_dir),
            # hay que REINICIAR el recursor: el reload de lua no relee
            # socket_dir y el bloqueo volveria a ser intermitente.
            restart = False
            try:
                elapsed = int(
                    subprocess.run(
                        ["ps", "-o", "etimes=", "-p", running_pids[0]],
                        capture_output=True,
                        text=True,
                        timeout=5,
                    ).stdout.strip()
                )
                if recursor_yml.stat().st_mtime > time.time() - elapsed:
                    restart = True
            except Exception:
                restart = False

            if restart:

                for pid in running_pids:

                    subprocess.run(["kill", pid], capture_output=True, timeout=5)

                time.sleep(1)

            else:

                # Ya corre con la config actual: SOLO se recarga el RPZ
                # (sin reiniciar, sin ventana de no-bloqueo) y se vacia
                # la cache de los dominios bloqueados (pdns sirve
                # respuestas positivas cacheadas de antes del bloqueo
                # hasta que expiren).
                subprocess.run(
                    [REC_CONTROL_BIN, "-s", socket_path, "reload-zones"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                try:
                    subprocess.run(
                        [REC_CONTROL_BIN, "-s", socket_path, "wipe-cache"]
                        + blocklist,
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                except Exception:
                    pass
                return alias_ip

        subprocess.run(
            [PDNS_RECURSOR_BIN, "--daemon=yes", "--config-dir=" + str(group_dir)],
            capture_output=True,
            timeout=10
        )

        return alias_ip

    def _write_dhcp_conf(
        self,
        db: Session,
        groups: list[tuple[DeviceGroup, str, list[str]]]
    ):
        """
        Writes groups_dns.conf for dnsmasq: tags each device to its
        group and hands the group's DNS alias to tagged clients. Only
        restarts dnsmasq if the file actually changed.
        """

        lines = ["# Auto-generated group DNS assignment -- do not edit by hand.\n"]

        # Un dispositivo pertenece a UN SOLO grupo DNS. Si esta en
        # varios, el grupo especifico (no por defecto) gana; el grupo
        # por defecto solo aplica si el dispositivo no esta en otro.
        mac_to_group = {}

        for group, alias_ip, blocklist in groups:

            is_default = bool(getattr(group, "is_default", False))

            device_ids = self.repository.device_ids(db, group.id)

            for device_id in device_ids:

                device = db.get(NetworkDevice, device_id)

                if not device or not device.mac_address:

                    continue

                mac = device.mac_address

                current = mac_to_group.get(mac)

                if current is None or (current["default"] and not is_default):

                    mac_to_group[mac] = {
                        "group_id": group.id,
                        "default": is_default,
                    }

        for mac, info in mac_to_group.items():

            lines.append(f"dhcp-host={mac},set:grp{info['group_id']}\n")

        for group, alias_ip, blocklist in groups:

            if any(
                info["group_id"] == group.id
                for info in mac_to_group.values()
            ):

                lines.append(f"dhcp-option=tag:grp{group.id},6,{alias_ip}\n")

        content = "".join(lines)

        GROUPS_DNS_CONFIG.parent.mkdir(parents=True, exist_ok=True)

        previous = (
            GROUPS_DNS_CONFIG.read_text(encoding="utf-8")
            if GROUPS_DNS_CONFIG.exists()
            else ""
        )

        if content != previous:

            GROUPS_DNS_CONFIG.write_text(content)

            dnsmasq_process_manager.restart()

        return True

    # ------------------------------------------------------------------
    # DNS forcing: redirige el DNS de cada equipo a su recursor de grupo
    # ------------------------------------------------------------------

    def _write_dns_forcing(
        self,
        db: Session,
        entries: list
    ) -> None:
        """
        Fuerza que todo equipo gestionado use el recursor de su grupo
        SIN importar el DNS que tenga configurado (lease DHCP viejo,
        DNS externo, etc.): reglas nftables (DNAT en prerouting) que
        reescriben cualquier consulta DNS (UDP/TCP 53) del equipo hacia
        la IP del recursor de su grupo. Asi el bloqueo aplica al equipo
        aunque el cliente nunca renueve su configuracion.

        El match es por MAC (ether saddr), NO por IP: un equipo con DHCP
        cambia de IP al renovar, y una regla por IP quedaria obsoleta
        hasta el siguiente sync. La MAC es estable.

        Se regenera completa en cada sync (la tabla se limpia y se
        vuelve a llenar con el mapeo actual equipo -> grupo).
        """

        with resource_locks.nft:
            self._write_dns_forcing_unlocked(db, entries)

    def _write_dns_forcing_unlocked(
        self,
        db: Session,
        entries: list
    ) -> None:

        mapping: dict[str, str] = {}

        for group, alias_ip, _blocklist in entries:

            for device_id in self.repository.device_ids(db, group.id):

                device = db.get(NetworkDevice, device_id)

                if device and device.mac_address:

                    mapping[device.mac_address.lower()] = alias_ip

        nft = "/usr/sbin/nft"

        def _run(args):
            try:
                return subprocess.run(
                    args,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
            except Exception:
                return None

        # Asegurar tabla + cadena (idempotente).
        if _run([nft, "list", "table", "ip", DNS_NAT_TABLE]).returncode != 0:

            _run([nft, "add", "table", "ip", DNS_NAT_TABLE])

        if (
            _run(
                [nft, "list", "chain", "ip", DNS_NAT_TABLE, "prerouting"]
            ).returncode != 0
        ):

            _run(
                [
                    nft, "add", "chain", "ip", DNS_NAT_TABLE, "prerouting",
                    "{ type nat hook prerouting priority dstnat; policy accept; }",
                ]
            )

        _run([nft, "flush", "table", "ip", DNS_NAT_TABLE])

        for mac, alias in mapping.items():

            _run(
                [
                    nft, "add", "rule", "ip", DNS_NAT_TABLE, "prerouting",
                    "ether", "saddr", mac, "udp", "dport", "53",
                    "counter", "dnat", "to", alias,
                ]
            )

            _run(
                [
                    nft, "add", "rule", "ip", DNS_NAT_TABLE, "prerouting",
                    "ether", "saddr", mac, "tcp", "dport", "53",
                    "counter", "dnat", "to", alias,
                ]
            )

        logger.info(
            f"DNS forcing: {len(mapping)} equipos redirigidos a su grupo."
        )

    # ------------------------------------------------------------------
    # Public sync entry points
    # ------------------------------------------------------------------

    def sync_group(
        self,
        db: Session,
        group_id: int
    ):

        try:

            group = self.repository.find_by_id(db, group_id)

            if group is None:

                return

            self._sync_incremental(db, focus_group_id=group.id)

        except Exception as error:

            logger.exception(f"Group DNS sync failed: {error}")

    def sync_device(
        self,
        db: Session,
        device_id: int
    ):

        try:

            focus = None
            group_ids = self.repository.group_ids_for_device(db, device_id)
            if group_ids:
                focus = group_ids[0]

            self._sync_incremental(db, focus_group_id=focus)

        except Exception as error:

            logger.exception(f"Device DNS sync failed: {error}")

    def sync_all(
        self,
        db: Session
    ):

        try:

            self._sync_all(db)

        except Exception as error:

            logger.exception(f"Group DNS sync_all failed: {error}")

    def sync_dhcp_exclusions(self, db: Session | None = None) -> None:
        """Alinea excluded_ips del pool con el subrango de alias de grupos."""

        try:
            from backend.shared.config.config_service import ConfigService
            from backend.groups.constants.group_dns_ip_reserve import (
                merge_group_dns_exclusions,
            )

            cfg_svc = ConfigService()
            dhcp_cfg = cfg_svc.get_dhcp_config()
            gateway = dhcp_cfg.get("gateway")
            if not gateway:
                return
            merged = merge_group_dns_exclusions(
                list(dhcp_cfg.get("excluded_ips") or []),
                gateway,
            )
            if merged != list(dhcp_cfg.get("excluded_ips") or []):
                dhcp_cfg["excluded_ips"] = merged
                cfg_svc.update_section("dhcp", dhcp_cfg)
                from backend.dhcp.services.dhcp_service import DhcpService
                DhcpService().apply_config()
        except Exception as error:
            logger.warning(
                f"No se pudo sincronizar exclusión DHCP de alias: {error}"
            )

    def _stop_group_recursor(self, group_id: int) -> None:
        group_dir = GROUP_DIR / str(group_id)
        try:
            pids = subprocess.run(
                ["pgrep", "-f", f"config-dir={group_dir}"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for pid in [p.strip() for p in pids.stdout.split() if p.strip()]:
                subprocess.run(["kill", pid], capture_output=True, timeout=5)
        except Exception as error:
            logger.warning(
                f"No pude detener recursor del grupo {group_id}: {error}"
            )

    def _alias_ip_from_recursor_yml(self, group_dir: Path) -> str | None:
        yml = group_dir / "recursor.yml"
        if not yml.exists():
            return None
        try:
            # Formato propio: bloque incoming.listen con "- <ip>"
            in_listen = False
            for line in yml.read_text(encoding="utf-8").splitlines():
                stripped = line.strip()
                if stripped == "listen:":
                    in_listen = True
                    continue
                if in_listen:
                    if stripped.startswith("- "):
                        return stripped[2:].strip()
                    if stripped and not stripped.startswith("#"):
                        break
        except Exception:
            return None
        return None

    def _cleanup_orphaned_group_dns(
        self,
        active_group_ids: set[int],
        active_alias_ips: set[str],
    ) -> None:
        """
        Al borrar grupos, sync ya no los recrea pero dejan alias IP,
        pdns_recursor y carpetas en /etc/stepad/dns/group-dns/. Sin esto
        quedan IPs fantasma (.10/.12/.13/.14) que chocan con DHCP.
        """
        if not GROUP_DIR.exists():
            return

        orphan_aliases: set[str] = set()

        for child in GROUP_DIR.iterdir():
            if not child.is_dir() or not child.name.isdigit():
                continue
            gid = int(child.name)
            if gid in active_group_ids:
                continue

            alias = self._alias_ip_from_recursor_yml(child)
            if alias:
                orphan_aliases.add(alias)

            self._stop_group_recursor(gid)

            try:
                for leftover in child.iterdir():
                    try:
                        leftover.unlink()
                    except IsADirectoryError:
                        pass
                    except Exception:
                        pass
                child.rmdir()
            except Exception as error:
                logger.warning(
                    f"No pude borrar dir DNS del grupo {gid}: {error}"
                )

            logger.info(f"Group DNS orphan limpiado: grupo {gid}.")

        # Quitar alias de la LAN que ya no pertenecen a ningun grupo activo.
        # Incluye: subrango actual de grupos, huérfanos de carpetas DNS, y
        # IPs secundarias coladas en el pool de equipos (esquema antiguo
        # por id, p.ej. .21) que nunca deben vivir en la interfaz LAN.
        try:
            from backend.network.interfaces.services.interface_service import (
                InterfaceService,
            )
            from backend.shared.config.config_service import ConfigService

            lan = InterfaceService().get_primary_lan()
            if not lan:
                return

            dhcp_cfg = ConfigService().get_dhcp_config() or {}
            gateway = dhcp_cfg.get("gateway")
            pool_start = dhcp_cfg.get("pool_start")
            pool_end = dhcp_cfg.get("pool_end")

            def _in_device_pool(ip: str) -> bool:
                if not pool_start or not pool_end:
                    return False
                try:
                    import ipaddress
                    a = int(ipaddress.IPv4Address(ip))
                    return (
                        int(ipaddress.IPv4Address(pool_start))
                        <= a
                        <= int(ipaddress.IPv4Address(pool_end))
                    )
                except ValueError:
                    return False

            result = subprocess.run(
                ["ip", "-4", "-o", "addr", "show", "dev", lan.name],
                capture_output=True,
                text=True,
                timeout=10,
            )
            for line in result.stdout.splitlines():
                parts = line.split()
                if "inet" not in parts:
                    continue
                inet = parts[parts.index("inet") + 1]
                ip = inet.split("/")[0]
                if ip in active_alias_ips:
                    continue
                if gateway and ip == gateway:
                    continue

                should_drop = ip in orphan_aliases
                if not should_drop and gateway:
                    try:
                        should_drop = is_group_dns_alias_ip(ip, gateway)
                    except Exception:
                        should_drop = False
                # Alias fantasma del esquema id-based dentro del pool de equipos.
                if not should_drop and _in_device_pool(ip):
                    should_drop = True

                if not should_drop:
                    continue

                subprocess.run(
                    [
                        "ip",
                        "addr",
                        "del",
                        self._alias_cidr(ip, lan.name),
                        "dev",
                        lan.name,
                    ],
                    capture_output=True,
                    timeout=10,
                )
                logger.info(f"Alias DNS de grupo eliminado de {lan.name}: {ip}")
        except Exception as error:
            logger.warning(f"Cleanup de alias DNS fallo: {error}")

    def _collect_active_entries(
        self,
        db: Session,
        *,
        ensure_group_ids: set[int] | None = None,
        ensure_all: bool = False,
    ) -> list:
        """Grupos con equipos + alias. Solo llama _ensure_recursor cuando
        ensure_all o el id está en ensure_group_ids."""

        entries = []

        for group in self.repository.find_all(db):

            device_ids = self.repository.device_ids(db, group.id)

            if not device_ids:

                continue

            alias_ip = self.group_alias_ip(db, group)

            if alias_ip is None:

                continue

            blocklist = self.group_blocklist(db, group)

            if ensure_all or (
                ensure_group_ids is not None
                and group.id in ensure_group_ids
            ):

                self._ensure_recursor(group, alias_ip, blocklist)

            entries.append((group, alias_ip, blocklist))

        return entries

    def _sync_incremental(
        self,
        db: Session,
        *,
        focus_group_id: int | None,
    ):
        """Actualiza DNAT/DHCP siempre; solo reinicia el recursor del
        grupo enfocado (o ninguno si solo movió un equipo)."""

        ensure_ids = (
            {focus_group_id} if focus_group_id is not None else set()
        )

        # Si el grupo enfocado pasó de 0 a N equipos, hay que crear
        # recursor. Si solo se movió un equipo, ensure_ids puede
        # incluir el grupo destino; el origen se limpia en orphan
        # cleanup si quedó vacío.
        entries = self._collect_active_entries(
            db,
            ensure_group_ids=ensure_ids,
            ensure_all=False,
        )

        self._write_dhcp_conf(db, entries)
        self._write_dns_forcing(db, entries)

        active_ids = {g.id for g in self.repository.find_all(db)}
        active_aliases = {
            g.dns_alias_ip
            for g in self.repository.find_all(db)
            if g.dns_alias_ip
        }
        active_aliases.update(ip for _, ip, _ in entries)

        self._cleanup_orphaned_group_dns(active_ids, active_aliases)
        self.sync_dhcp_exclusions(db)

        logger.info(
            "Group DNS incremental sync "
            f"(focus={focus_group_id}, active={len(entries)})."
        )

    def _sync_all(
        self,
        db: Session
    ):

        entries = self._collect_active_entries(db, ensure_all=True)

        self._write_dhcp_conf(db, entries)

        self._write_dns_forcing(db, entries)

        active_ids = {g.id for g in self.repository.find_all(db)}
        active_aliases = {
            g.dns_alias_ip
            for g in self.repository.find_all(db)
            if g.dns_alias_ip
        }
        active_aliases.update(ip for _, ip, _ in entries)

        self._cleanup_orphaned_group_dns(active_ids, active_aliases)
        self.sync_dhcp_exclusions(db)

        logger.info(
            f"Group DNS synced ({len(entries)} active groups)."
        )


group_dns_service = GroupDnsService()
