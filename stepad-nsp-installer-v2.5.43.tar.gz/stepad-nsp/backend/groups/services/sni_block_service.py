import os
import subprocess
import threading
import time

from pathlib import Path

from sqlalchemy.orm import Session

from backend.network.devices.models.network_device import NetworkDevice
from backend.groups.constants.ips_evasion import (
    MAX_SNI_DOMAINS_HARD_CAP,
    ggc_ips_for_blocklist,
    sni_domains_for_blocklist,
)
from backend.shared.logging.logger import logger

RULES_FILE = "/var/lib/suricata/rules/stepad-sni.rules"
SURICATA_YAML = "/etc/suricata/suricata.yaml"
SNI_YAML_ENTRY = "  - /var/lib/suricata/rules/stepad-sni.rules"
RULES_HEADER = (
    "# STEPAD NSP — reglas SNI de antievasión (auto-generado).\n"
    "# El blocklist DNS completo vive en RPZ por grupo; aquí solo DoH,\n"
    "# YouTube/redes y otros dominios que el DNS no corta bien.\n"
    "# NO editar a mano.\n"
)

NFT = "/usr/sbin/nft"
IP_COMMENT_PREFIX = "stepad-ipblock"

# Reintentos del reload rapido (por socket) antes de caer al restart
# lento: el socket de control puede tardar unos segundos en responder
# justo despues de que Suricata termino de arrancar (por ej. tras su
# propio restart reciente), y reintentar aqui evita un restart
# innecesario.
RELOAD_RETRY_ATTEMPTS = 3
RELOAD_RETRY_WAIT_SECONDS = 3

# Enfriamiento entre restarts completos de Suricata. Se persiste en un
# archivo (no en memoria) porque cada despliegue/actualizacion reinicia
# el proceso del backend -- sin esto, varios despliegues seguidos en
# pocos minutos encadenan restarts de Suricata que se pisan entre si
# (el siguiente arranca antes de que el anterior termine) y generan
# picos de CPU sostenidos (visto en produccion el 22/ago).
SURICATA_RESTART_COOLDOWN_SECONDS = 90
SURICATA_RESTART_MARKER = Path("/tmp/stepad-suricata-restart.marker")

REFRESH_INTERVAL_SECONDS = 6 * 3600
FIRST_REFRESH_SECONDS = 120
SNI_BASE_SID = 900000
LEASES_FILE = "/var/lib/misc/dnsmasq.leases"
# DNS/RPZ = blocklist completo. SNI = catálogo fijo antievasión (ips_evasion).
MAX_IPS_PER_SNI_RULE = 64


class SniBlockService:
    """
    Antievasión Suricata (IPS) por grupo.

    **DNS/RPZ** bloquea el blocklist completo (malware, categorías, reglas).
    **Este servicio** solo genera reglas SNI para el catálogo fijo de
    evasión (DoH, YouTube, redes) cuando el grupo tiene esa política activa.

    Una regla TLS + una QUIC por dominio del catálogo, con IPs agregadas
    por equipo del grupo. Sin combinatoria IP×dominio del feed malware.
    """

    def __init__(self):
        self._thread = None
        self._stop = threading.Event()

    # ------------------------------------------------------------------
    # Data helpers
    # ------------------------------------------------------------------

    def _group(self, db: Session, group_id: int):
        from backend.groups.models.device_group import DeviceGroup
        return (
            db.query(DeviceGroup)
            .filter(DeviceGroup.id == group_id)
            .first()
        )

    def _group_device_macs(self, db: Session, group_id: int) -> list[str]:
        from backend.groups.repositories.device_group_repository import (
            DeviceGroupRepository
        )
        device_ids = DeviceGroupRepository().device_ids(db, group_id)
        if not device_ids:
            return []
        rows = (
            db.query(NetworkDevice.mac_address)
            .filter(NetworkDevice.id.in_(device_ids))
            .all()
        )
        macs = []
        for (mac,) in rows:
            mac = mac.strip().lower()
            if mac:
                macs.append(mac)
        return macs

    def _group_blocklist(self, db: Session, group) -> list[str]:
        from backend.groups.services.group_dns_service import (
            group_dns_service
        )
        try:
            return group_dns_service.group_blocklist(db, group) or []
        except Exception as error:
            logger.exception(f"group_blocklist failed: {error}")
            return []

    def _lease_ips(self) -> dict[str, str]:
        result: dict[str, str] = {}
        try:
            with open(LEASES_FILE) as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 3:
                        result[parts[1].strip().lower()] = parts[2].strip()
        except Exception:
            pass
        return result

    def _device_ips(self, db: Session, macs: list[str]) -> list[str]:
        leases = self._lease_ips()
        ips = []
        for mac in macs:
            ip = leases.get(mac)
            if not ip:
                row = (
                    db.query(NetworkDevice.ip_address)
                    .filter(NetworkDevice.mac_address == mac)
                    .first()
                )
                ip = row[0] if row else None
            if ip:
                ips.append(ip)
        return ips

    def _sni_domains_for_group(
        self,
        blocklist: list[str],
    ) -> list[str]:
        """Catálogo IPS fijo ∩ política del grupo (no todo el blocklist)."""
        return sni_domains_for_blocklist(blocklist)

    def _parents(self, domains: list[str]) -> list[str]:
        """Deja solo los dominios que no son subdominios de otro de la
        lista (youtube.com cubre www.youtube.com -> se elimina el hijo)."""
        unique = sorted(set(domains))
        result = []
        for d in unique:
            if any(
                d.endswith("." + other)
                for other in unique
                if other != d
            ):
                continue
            result.append(d)
        return result

    def _escape(self, domain: str) -> str:
        return domain.replace(".", "\\.")

    # ------------------------------------------------------------------
    # Rule generation
    # ------------------------------------------------------------------

    def _build_rules(self, entries: list[tuple[str, str]]) -> list[str]:
        """Una regla TLS + una QUIC por dominio del catálogo, IPs agregadas."""
        by_domain: dict[str, list[str]] = {}
        for ip, domain in entries:
            ips = by_domain.setdefault(domain, [])
            if ip not in ips:
                ips.append(ip)

        domains = sorted(by_domain.keys())
        if len(domains) > MAX_SNI_DOMAINS_HARD_CAP:
            logger.warning(
                "SNI: %s dominios en catálogo; tope duro %s.",
                len(domains),
                MAX_SNI_DOMAINS_HARD_CAP,
            )
            domains = domains[:MAX_SNI_DOMAINS_HARD_CAP]

        lines = []
        sid = SNI_BASE_SID
        for domain in domains:
            ips = by_domain[domain][:MAX_IPS_PER_SNI_RULE]
            if not ips:
                continue
            escaped = self._escape(domain)
            src = ips[0] if len(ips) == 1 else f"[{','.join(ips)}]"
            # TLS (TCP) y QUIC (UDP/HTTP3): el video/audio de YouTube va
            # por QUIC; ambas reglas se generan para cubrir ambos.
            lines.append(
                f'drop tls {src} any -> any any '
                f'(tls.sni; pcre:"/(^|\\.){escaped}$/i"; '
                f'sid:{sid}; rev:1;)'
            )
            sid += 1
            lines.append(
                f'drop quic {src} any -> any any '
                f'(quic.sni; pcre:"/(^|\\.){escaped}$/i"; '
                f'sid:{sid}; rev:1;)'
            )
            sid += 1
        return lines

    def _write_file(self, lines: list[str]):
        content = RULES_HEADER + "\n".join(lines)
        if lines:
            content += "\n"
        tmp = RULES_FILE + ".tmp"
        try:
            os.makedirs(os.path.dirname(RULES_FILE), exist_ok=True)
            with open(tmp, "w") as f:
                f.write(content)
            os.replace(tmp, RULES_FILE)
        except Exception as error:
            logger.error(f"SNI rules write fallo: {error}")

    def _ensure_yaml(self):
        """
        Asegura que rule-files incluya la regla SNI de grupos, sin
        corromper el YAML. Trabaja por lineas (no con replace textual)
        para no romper la indentacion de la secuencia rule-files.
        """
        try:
            with open(SURICATA_YAML) as f:
                lines = f.readlines()

            def has_sni():
                return any(
                    "/var/lib/suricata/rules/stepad-sni.rules" in line
                    and line.lstrip().startswith("- ")
                    for line in lines
                )

            changed = False

            if not "".join(lines).lstrip().startswith("%YAML 1.1"):
                lines.insert(0, "%YAML 1.1\n---\n")
                changed = True

            if not has_sni():
                for i, line in enumerate(lines):
                    if line.strip() == "- suricata.rules":
                        lines.insert(i + 1, SNI_YAML_ENTRY + "\n")
                        changed = True
                        break

            if changed:
                with open(SURICATA_YAML, "w") as f:
                    f.writelines(lines)
        except Exception as error:
            logger.error(f"Suricata yaml update fallo: {error}")

    def _reload(self):
        # Si suricata no esta corriendo no hay nada que recargar (el
        # bloqueo DNS+IP sigue activo) y no se pierde tiempo aqui.
        try:
            status = subprocess.run(
                ["systemctl", "is-active", "suricata"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if status.stdout.strip() != "active":
                return
        except Exception:
            return

        # Reload rapido de reglas (suricatasc, sin reiniciar el proceso).
        # El restart de systemd tarda ~10s y bloquea las respuestas de la
        # API (reglas/equipos que parecen "no hacer nada"). Si el socket
        # no esta disponible todavia, se reintenta un par de veces antes
        # de caer al restart (evita restarts innecesarios).
        for attempt in range(RELOAD_RETRY_ATTEMPTS):
            try:
                result = subprocess.run(
                    ["suricatasc", "-c", "reload-rules"],
                    capture_output=True,
                    text=True,
                    timeout=8,
                )
                if result.returncode == 0:
                    return
            except Exception:
                pass

            if attempt < RELOAD_RETRY_ATTEMPTS - 1:
                time.sleep(RELOAD_RETRY_WAIT_SECONDS)

        # Evita restarts encadenados: si Suricata ya se reinicio hace
        # poco por este mismo mecanismo (posiblemente desde otro
        # proceso del backend, ej. durante una racha de despliegues),
        # se omite este restart y se deja para el proximo reload -- las
        # reglas ya quedaron escritas en el archivo, solo falta que
        # Suricata las recargue una vez que se estabilice.
        try:
            if SURICATA_RESTART_MARKER.exists():
                elapsed = time.time() - SURICATA_RESTART_MARKER.stat().st_mtime
                if elapsed < SURICATA_RESTART_COOLDOWN_SECONDS:
                    logger.warning(
                        "Suricata reload: se omite restart (uno reciente "
                        f"hace {elapsed:.0f}s); se reintentara en el "
                        "proximo ciclo."
                    )
                    return
        except Exception:
            pass

        try:
            SURICATA_RESTART_MARKER.touch()
        except Exception:
            pass

        try:
            from backend.shared.runtime.resource_locks import resource_locks

            with resource_locks.suricata:
                subprocess.run(
                    ["systemctl", "restart", "suricata"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
        except Exception as error:
            logger.error(f"Suricata reload fallo: {error}")

    # ------------------------------------------------------------------
    # Sync
    # ------------------------------------------------------------------

    def _compute(self, db: Session) -> list[tuple[str, str]]:
        from backend.groups.repositories.device_group_repository import (
            DeviceGroupRepository
        )
        entries: list[tuple[str, str]] = []
        for group in DeviceGroupRepository().find_all(db):
            blocklist = self._group_blocklist(db, group)
            domains = self._parents(
                self._sni_domains_for_group(blocklist)
            )
            if not domains:
                continue
            macs = self._group_device_macs(db, group.id)
            if not macs:
                continue
            ips = self._device_ips(db, macs)
            if not ips:
                continue
            for ip in ips:
                for d in domains:
                    entries.append((ip, d))
        return entries

    # ------------------------------------------------------------------
    # IP block (specific resolved IPs, per device)
    # ------------------------------------------------------------------

    def _ip_set_name(self, gid: int) -> str:
        return f"stepad_grp_ips_v4_{gid}"

    def _lan_interface(self) -> str | None:
        try:
            from backend.network.interfaces.services.interface_service import (
                InterfaceService
            )
            lan = InterfaceService().get_primary_lan()
            return lan.name if lan else None
        except Exception:
            return None

    def _run(self, cmd):
        try:
            return subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
        except Exception:
            return None

    def _blocked_ips(self, blocklist: list[str]) -> list[str]:
        return ggc_ips_for_blocklist(blocklist)

    def _ip_rule_exists(self, comment: str) -> bool:
        result = self._run([NFT, "list", "chain", "inet", "stepad", "forward"])
        return bool(result and result.returncode == 0 and comment in result.stdout)

    def _delete_ip_rule(self, comment: str):
        result = self._run([NFT, "-a", "list", "chain", "inet", "stepad", "forward"])
        if result is None or result.returncode != 0:
            return
        for line in result.stdout.splitlines():
            if comment in line and "handle" in line:
                handle = line.split("handle")[1].strip().split()[0]
                self._run(
                    [NFT, "delete", "rule", "inet", "stepad", "forward", "handle", handle]
                )
                return

    def _ensure_ip_set(self, name: str):
        self._run(
            [NFT, "add", "set", "inet", "stepad", name,
             "{", "type", "ipv4_addr", ";", "flags", "interval", ";", "}"]
        )

    def _flush_ip_set(self, name: str):
        self._run([NFT, "flush", "set", "inet", "stepad", name])

    def _add_ip_elements(self, name: str, elements: list[str]):
        for i in range(0, len(elements), 64):
            chunk = elements[i:i + 64]
            args = [NFT, "add", "element", "inet", "stepad", name, "{"]
            for j, el in enumerate(chunk):
                args.append(el + ("," if j < len(chunk) - 1 else ""))
            args.append("}")
            result = self._run(args)
            if result is None or result.returncode != 0:
                logger.error(
                    f"nft add element {name} fallo: "
                    f"{result.stderr.strip() if result else 'run failed'}"
                )

    def _apply_group_ip_block(
        self,
        db: Session,
        group,
        lan: str | None,
    ):
        macs = self._group_device_macs(db, group.id)
        blocklist = self._group_blocklist(db, group)
        if not macs or not blocklist:
            self._remove_group_ip_block(group.id)
            return

        ips = self._blocked_ips(blocklist)
        if not ips:
            self._remove_group_ip_block(group.id)
            return

        set_name = self._ip_set_name(group.id)

        # Quitar reglas que referencian el set antes de recrearlo (si el
        # set fue creado por una version anterior sin `flags interval`,
        # no se puede cambiar y hay que borrarlo y recrearlo con rangos).
        for mac in macs:
            self._delete_ip_rule(f"{IP_COMMENT_PREFIX}-{group.id}-{mac}")

        self._run([NFT, "delete", "set", "inet", "stepad", set_name])

        self._ensure_ip_set(set_name)
        self._add_ip_elements(set_name, ips)

        for mac in macs:
            comment = f"{IP_COMMENT_PREFIX}-{group.id}-{mac}"
            args = [NFT, "insert", "rule", "inet", "stepad", "forward"]
            if lan:
                args += ["iifname", lan]
            args += [
                "ether", "saddr", mac,
                "ip", "daddr", f"@{set_name}",
                "counter", "drop",
                "comment", f'"{comment}"',
            ]
            self._run(args)

        logger.info(
            f"Group {group.id} IP block: {len(macs)} equipos, "
            f"{len(ips)} IPs especificas."
        )

    def _remove_group_ip_block(self, gid: int):
        result = self._run([NFT, "-a", "list", "chain", "inet", "stepad", "forward"])
        comments = []
        if result and result.returncode == 0:
            for line in result.stdout.splitlines():
                if IP_COMMENT_PREFIX not in line:
                    continue
                marker = f"{IP_COMMENT_PREFIX}-{gid}-"
                if marker in line and "handle" in line:
                    handle = line.split("handle")[1].strip().split()[0]
                    self._run(
                        [NFT, "delete", "rule", "inet", "stepad", "forward", "handle", handle]
                    )
        self._run([NFT, "delete", "set", "inet", "stepad", self._ip_set_name(gid)])

    def _sync_ip_block(self, db: Session):
        from backend.groups.repositories.device_group_repository import (
            DeviceGroupRepository
        )
        lan = self._lan_interface()
        groups = DeviceGroupRepository().find_all(db)
        active_markers = []
        for group in groups:
            self._apply_group_ip_block(db, group, lan)
            active_markers.append(f"{IP_COMMENT_PREFIX}-{group.id}-")
        result = self._run([NFT, "-a", "list", "chain", "inet", "stepad", "forward"])
        if result and result.returncode == 0:
            for line in result.stdout.splitlines():
                if IP_COMMENT_PREFIX not in line or "handle" not in line:
                    continue
                if not any(m in line for m in active_markers):
                    handle = line.split("handle")[1].strip().split()[0]
                    self._run(
                        [NFT, "delete", "rule", "inet", "stepad", "forward", "handle", handle]
                    )

    def sync_all(self, db: Session):
        try:
            entries = self._compute(db)
            rules = self._build_rules(entries)
            self._write_file(rules)
            self._ensure_yaml()
            self._reload()
            self._sync_ip_block(db)
            logger.info(
                f"SNI antievasión: {len(rules)} reglas Suricata "
                f"({len(entries)} pares IP×dominio del catálogo)."
            )
        except Exception as error:
            logger.exception(f"SNI block sync_all failed: {error}")

    def sync_group(self, db: Session, group_id: int):
        self.sync_all(db)

    # ------------------------------------------------------------------
    # Periodic re-resolution
    # ------------------------------------------------------------------

    def start_refresh_timer(self):
        if self._thread and self._thread.is_alive():
            return

        self._stop.clear()

        def _refresh():
            try:
                from backend.core.database.session import SessionLocal
                db = SessionLocal()
                try:
                    self.sync_all(db)
                finally:
                    db.close()
            except Exception as error:
                logger.exception(f"SNI block refresh failed: {error}")

        def loop():
            if not self._stop.wait(FIRST_REFRESH_SECONDS):
                _refresh()
            while not self._stop.is_set():
                if self._stop.wait(REFRESH_INTERVAL_SECONDS):
                    break
                _refresh()

        self._thread = threading.Thread(
            target=loop,
            daemon=True,
            name="group-sni-block-refresh",
        )
        self._thread.start()
        logger.info("SNI block refresh timer iniciado.")

    def stop_refresh_timer(self):
        self._stop.set()


sni_block_service = SniBlockService()
