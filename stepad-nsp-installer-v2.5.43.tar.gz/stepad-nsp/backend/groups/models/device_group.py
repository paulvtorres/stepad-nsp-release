from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Table, Column
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class DeviceGroup(Base):

    __tablename__ = "device_groups"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        unique=True
    )


    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )


    # True = the group that new/unrecognized devices join
    # automatically. Only one should be default.
    is_default: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )


    # Download bandwidth cap in kbps for every device in this group.
    # NULL = unlimited (or overridden per-device).
    bandwidth_limit_kbps: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )


    # IP LAN exclusiva del alias DNS del grupo (subrango group_ip_*).
    # Persistida: no se reasigna al borrar otros grupos.
    dns_alias_ip: Mapped[str | None] = mapped_column(
        String(45),
        nullable=True,
        unique=True,
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )


class GroupDevice(Base):

    __tablename__ = "group_devices"


    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True
    )


    group_id: Mapped[int] = mapped_column(
        ForeignKey("device_groups.id", ondelete="CASCADE"),
        nullable=False
    )


    device_id: Mapped[int] = mapped_column(
        ForeignKey("network_devices.id", ondelete="CASCADE"),
        nullable=False
    )


    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
