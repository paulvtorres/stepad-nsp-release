# Constantes compartidas del módulo groups.
