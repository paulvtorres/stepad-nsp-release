"""Subrango de IPs LAN exclusivo para alias DNS de grupos.

Diseño
------
1. Se configura el segmento principal (ej. ``192.168.1.0/24``).
2. Dentro de ese segmento se define un **subrango solo para grupos**
   (``group_ip_start`` .. ``group_ip_end`` en ``config.yaml``).
3. El pool DHCP de **equipos** no incluye ese subrango.
4. Si no quedan IPs libres en el subrango, el NSP **no crea** más grupos.

Default (si no hay config explícita), con gateway ``.1``:

* ``192.168.1.10`` .. ``192.168.1.19`` → **10 IPs** para grupos
* Equipos desde ``.20`` (o el ``pool_start`` configurado, si es ≥)

Las IPs de grupos y de equipos **no se mezclan**.
"""

from __future__ import annotations

import ipaddress

# Default: 10 IPs para grupos (.10-.19 si gateway es .1).
DEFAULT_GROUP_IP_COUNT = 10

# Primera IP por defecto = gateway + este offset → .10 con gw .1
DEFAULT_GROUP_IP_FIRST_OFFSET = 9

# Mínimo razonable de IPs para el pool de equipos.
MIN_DEVICE_DHCP_POOL_SIZE = 20


def _gateway_from_config(dhcp_cfg: dict | None) -> str:
    dhcp_cfg = dhcp_cfg or {}
    return str(dhcp_cfg.get("gateway") or "192.168.1.1")


def group_ip_bounds(
    dhcp_cfg: dict | None = None,
) -> tuple[ipaddress.IPv4Address, ipaddress.IPv4Address]:
    """
    Subrango exclusivo de grupos: (start, end) inclusive.

    Prioridad:
    1. ``group_ip_start`` + ``group_ip_end`` en dhcp config
    2. ``group_ip_start`` + ``group_ip_count``
    3. Default: gateway+9 .. gateway+9+DEFAULT_GROUP_IP_COUNT-1
    """
    dhcp_cfg = dhcp_cfg or _load_dhcp_cfg()
    gw = ipaddress.IPv4Address(_gateway_from_config(dhcp_cfg))

    start_raw = dhcp_cfg.get("group_ip_start")
    end_raw = dhcp_cfg.get("group_ip_end")
    count_raw = dhcp_cfg.get("group_ip_count")

    if start_raw and end_raw:
        first = ipaddress.IPv4Address(str(start_raw))
        last = ipaddress.IPv4Address(str(end_raw))
    elif start_raw and count_raw:
        first = ipaddress.IPv4Address(str(start_raw))
        last = ipaddress.IPv4Address(int(first) + int(count_raw) - 1)
    else:
        count = int(count_raw) if count_raw else DEFAULT_GROUP_IP_COUNT
        if count < 1:
            count = DEFAULT_GROUP_IP_COUNT
        first = ipaddress.IPv4Address(
            int(gw) + DEFAULT_GROUP_IP_FIRST_OFFSET
        )
        last = ipaddress.IPv4Address(int(first) + count - 1)

    if int(last) < int(first):
        raise ValueError(
            f"Subrango de grupos inválido: {first}-{last}"
        )

    return first, last


def _load_dhcp_cfg() -> dict:
    try:
        from backend.shared.config.config_service import ConfigService
        return ConfigService().get_dhcp_config() or {}
    except Exception:
        return {}


def group_ip_list(dhcp_cfg: dict | None = None) -> list[str]:
    first, last = group_ip_bounds(dhcp_cfg)
    return [
        str(ipaddress.IPv4Address(a))
        for a in range(int(first), int(last) + 1)
    ]


def group_ip_capacity(dhcp_cfg: dict | None = None) -> int:
    return len(group_ip_list(dhcp_cfg))


def group_ip_exclusion_token(dhcp_cfg: dict | None = None) -> str:
    first, last = group_ip_bounds(dhcp_cfg)
    if first == last:
        return str(first)
    return f"{first}-{last}"


def rebase_group_ip_range(
    gateway: str,
    count: int | None = None,
    dhcp_cfg: dict | None = None,
) -> tuple[str, str]:
    """
    Recalcula el subrango de grupos relativo a un gateway nuevo.

    Conserva el tamaño (count) del subrango actual si no se pasa.
    """
    if count is None:
        try:
            first, last = group_ip_bounds(dhcp_cfg)
            count = int(last) - int(first) + 1
        except Exception:
            count = DEFAULT_GROUP_IP_COUNT
    if count < 1:
        count = DEFAULT_GROUP_IP_COUNT

    gw = ipaddress.IPv4Address(gateway)
    first = ipaddress.IPv4Address(int(gw) + DEFAULT_GROUP_IP_FIRST_OFFSET)
    last = ipaddress.IPv4Address(int(first) + count - 1)
    return str(first), str(last)


def default_device_pool_start(
    dhcp_cfg: dict | str | None = None,
) -> str:
    """Primera IP sugerida para equipos: justo después del subrango de grupos."""
    if isinstance(dhcp_cfg, str):
        dhcp_cfg = {"gateway": dhcp_cfg}
    _first, last = group_ip_bounds(dhcp_cfg)
    return str(ipaddress.IPv4Address(int(last) + 1))


def is_group_dns_alias_ip(ip: str, gateway: str | None = None) -> bool:
    """
    gateway se ignora si hay config; se mantiene el parámetro por
    compatibilidad con llamadas antiguas.
    """
    dhcp_cfg = _load_dhcp_cfg()
    if gateway and not dhcp_cfg.get("gateway"):
        dhcp_cfg = {**dhcp_cfg, "gateway": gateway}
    first, last = group_ip_bounds(dhcp_cfg)
    addr = int(ipaddress.IPv4Address(ip))
    return int(first) <= addr <= int(last)


def merge_group_dns_exclusions(
    excluded_ips: list[str] | None,
    gateway: str | None = None,
) -> list[str]:
    dhcp_cfg = _load_dhcp_cfg()
    if gateway:
        dhcp_cfg = {**dhcp_cfg, "gateway": gateway}
    token = group_ip_exclusion_token(dhcp_cfg)
    merged: list[str] = []
    seen: set[str] = set()
    for raw in list(excluded_ips or []) + [token]:
        item = str(raw).strip()
        if not item or item in seen:
            continue
        seen.add(item)
        merged.append(item)
    return merged


def next_free_group_ip(
    used_ips: set[str] | list[str] | None = None,
    dhcp_cfg: dict | None = None,
) -> str | None:
    """Primera IP libre del subrango de grupos (no reasigna las ocupadas)."""
    used = {str(ip).strip() for ip in (used_ips or []) if ip}
    for ip in group_ip_list(dhcp_cfg):
        if ip not in used:
            return ip
    return None


def free_group_ip_count(
    used_ips: set[str] | list[str] | None = None,
    dhcp_cfg: dict | None = None,
) -> int:
    used = {str(ip).strip() for ip in (used_ips or []) if ip}
    return sum(1 for ip in group_ip_list(dhcp_cfg) if ip not in used)


def validate_pool_against_group_reserve(
    pool_start: str,
    pool_end: str,
    gateway: str | None = None,
) -> None:
    dhcp_cfg = _load_dhcp_cfg()
    if gateway:
        dhcp_cfg = {**dhcp_cfg, "gateway": gateway}

    start = int(ipaddress.IPv4Address(pool_start))
    end = int(ipaddress.IPv4Address(pool_end))
    if end < start:
        raise ValueError(f"Pool invertido: {pool_start}-{pool_end}")

    first, last = group_ip_bounds(dhcp_cfg)
    r0, r1 = int(first), int(last)
    capacity = r1 - r0 + 1

    device_addrs = [
        a for a in range(start, end + 1)
        if not (r0 <= a <= r1)
    ]
    if len(device_addrs) < MIN_DEVICE_DHCP_POOL_SIZE:
        raise ValueError(
            f"El pool {pool_start}-{pool_end} deja solo "
            f"{len(device_addrs)} IP(s) para equipos fuera del subrango "
            f"de grupos ({first}-{last}, {capacity} IPs). "
            f"Se requieren al menos {MIN_DEVICE_DHCP_POOL_SIZE} para "
            f"equipos. Empieza el pool en "
            f"{default_device_pool_start(dhcp_cfg)} o superior, "
            f"o reduce el subrango de grupos en la configuración."
        )


# --- Compat con nombres anteriores ---

GROUP_DNS_ALIAS_COUNT = DEFAULT_GROUP_IP_COUNT
GROUP_DNS_ALIAS_FIRST_OFFSET = DEFAULT_GROUP_IP_FIRST_OFFSET
MIN_TOTAL_HOSTS_FOR_LAN = DEFAULT_GROUP_IP_COUNT + MIN_DEVICE_DHCP_POOL_SIZE


def group_dns_alias_bounds(gateway: str):
    return group_ip_bounds({"gateway": gateway})


def group_dns_alias_exclusion_token(gateway: str) -> str:
    return group_ip_exclusion_token({"gateway": gateway})


def group_dns_alias_ip_for_index(gateway: str, zero_based_index: int) -> str:
    ips = group_ip_list({"gateway": gateway})
    if zero_based_index < 0 or zero_based_index >= len(ips):
        raise ValueError(
            f"Solo hay {len(ips)} IPs reservadas para alias de grupos "
            f"(índice {zero_based_index} fuera de rango)."
        )
    return ips[zero_based_index]
