"""Catálogo IPS/SNI: solo antievasión (Suricata).

Arquitectura STEPAD NSP
-----------------------
* **DNS/RPZ (por grupo)** — bloqueo masivo de dominios (malware, categorías,
  reglas). Es el muro principal.
* **Suricata SNI + IP GGC** — solo lo que el DNS no corta bien: DoH, SNI TLS
  de YouTube/redes, caché de video del ISP.

Nunca se generan reglas Suricata desde el blocklist DNS completo (evita
combinatoria IP×dominio que colapsó NFQUEUE con ~309k reglas).
"""

from __future__ import annotations

import dataclasses

# Infraestructura Google compartida: no bloquear por SNI (Gmail, Drive…).
NEVER_BLOCK_SUFFIXES: tuple[str, ...] = (
    "google.com",
    "googleapis.com",
    "gstatic.com",
    "googleusercontent.com",
)

# Caché de video YouTube del ISP (GGC). Solo nft cuando el grupo bloquea YT.
GGC_BLOCKED_IPS: tuple[str, ...] = (
    "45.162.72.0/24",
    "45.162.73.0/24",
    "162.43.190.0/24",
    "172.172.255.216",
)

# Resolvers DoH/DoT conocidos — aplicar SNI si el grupo tiene filtrado DNS.
DOH_SNI_DOMAINS: tuple[str, ...] = (
    "dns.google",
    "dns.google.com",
    "cloudflare-dns.com",
    "one.one.one.one",
    "dns.quad9.net",
    "mozilla.cloudflare-dns.com",
    "dns.adguard.com",
    "doh.opendns.com",
    "dns.opendns.com",
    "doh.cleanbrowsing.org",
    "dns.nextdns.io",
)

YOUTUBE_MARKERS: tuple[str, ...] = (
    "youtube.com",
    "youtu.be",
    "googlevideo.com",
    "ytimg.com",
    "youtube-nocookie.com",
    "youtubei.googleapis.com",
    "ggpht.com",
    "yt3.ggpht.com",
)

YOUTUBE_SNI_DOMAINS: tuple[str, ...] = YOUTUBE_MARKERS

SOCIAL_MARKERS: tuple[str, ...] = (
    "whatsapp.com",
    "whatsapp.net",
    "facebook.com",
    "fbcdn.net",
    "instagram.com",
    "tiktok.com",
    "tiktokv.com",
    "musical.ly",
    "snapchat.com",
    "twimg.com",
    "twitter.com",
    "x.com",
)

SOCIAL_SNI_DOMAINS: tuple[str, ...] = SOCIAL_MARKERS


@dataclasses.dataclass(frozen=True)
class EvasionCategory:
    """Una familia de evasión: se activa si el blocklist del grupo la toca."""

    key: str
    markers: tuple[str, ...]
    sni_domains: tuple[str, ...]
    # Si True, SNI DoH aplica a cualquier grupo con filtrado DNS activo.
    always_when_filtered: bool = False
    ggc_ip_block: bool = False


EVASION_CATEGORIES: tuple[EvasionCategory, ...] = (
    EvasionCategory(
        key="doh",
        markers=(),
        sni_domains=DOH_SNI_DOMAINS,
        always_when_filtered=True,
    ),
    EvasionCategory(
        key="youtube",
        markers=YOUTUBE_MARKERS,
        sni_domains=YOUTUBE_SNI_DOMAINS,
        ggc_ip_block=True,
    ),
    EvasionCategory(
        key="social",
        markers=SOCIAL_MARKERS,
        sni_domains=SOCIAL_SNI_DOMAINS,
    ),
)

# Tope de seguridad (no debería alcanzarse con el catálogo fijo).
MAX_SNI_DOMAINS_HARD_CAP = 64


def _domain_matches_markers(domain: str, markers: tuple[str, ...]) -> bool:
    d = (domain or "").strip().lower().lstrip(".")
    if not d:
        return False
    for marker in markers:
        if d == marker or d.endswith("." + marker):
            return True
    return False


def blocklist_has_filtering(blocklist: list[str] | set[str]) -> bool:
    """True si el grupo tiene algún dominio bloqueado (DNS activo)."""
    return bool(blocklist)


def category_active(
    blocklist: list[str] | set[str],
    category: EvasionCategory,
) -> bool:
    blocked = list(blocklist)
    if category.always_when_filtered:
        return blocklist_has_filtering(blocked)
    if not category.markers:
        return False
    return any(
        _domain_matches_markers(d, category.markers)
        for d in blocked
    )


def sni_domains_for_blocklist(blocklist: list[str] | set[str]) -> list[str]:
    """
    Dominios que merecen reglas Suricata SNI para este grupo.

    Fuente: catálogo fijo de antievasión ∩ política del grupo (blocklist),
    NO el blocklist entero.
    """
    blocked = {str(d).strip().lower() for d in blocklist if d}
    if not blocked:
        return []

    domains: set[str] = set()
    for category in EVASION_CATEGORIES:
        if category_active(blocked, category):
            domains.update(category.sni_domains)

    # Filtrar infra Google genérica (por si un marker cae cerca).
    result = sorted(
        d for d in domains
        if not any(
            d == s or d.endswith("." + s)
            for s in NEVER_BLOCK_SUFFIXES
        )
    )

    if len(result) > MAX_SNI_DOMAINS_HARD_CAP:
        result = result[:MAX_SNI_DOMAINS_HARD_CAP]

    return result


def ggc_ips_for_blocklist(blocklist: list[str] | set[str]) -> list[str]:
    """Rangos GGC a bloquear por nft solo si el grupo bloquea YouTube."""
    blocked = list(blocklist)
    for category in EVASION_CATEGORIES:
        if category.ggc_ip_block and category_active(blocked, category):
            return list(GGC_BLOCKED_IPS)
    return []
