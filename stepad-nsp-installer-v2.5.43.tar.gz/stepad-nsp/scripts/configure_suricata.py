#!/usr/bin/env python3
"""
Configura /etc/suricata/suricata.yaml para STEPAD NSP:
  - HOME_NET leida del config.yaml de la app (segmento LAN actual)
  - Modo IPS (NFQUEUDAD 0, en linea)
  - Regla de bloqueo por grupo (stepad-sni.rules) en rule-files
  - Socket de control (suricatasc reload-rules)

Se ejecuta desde install.sh (como root), desde las actualizaciones y
cuando se cambia el segmento LAN. HOME_NET ya NO está quemada: se
calcula desde backend/shared/config/config.yaml (dhcp.network + netmask)
para que Suricata vigile siempre la red interna actual.
"""
import ipaddress
from pathlib import Path

import yaml

P = "/etc/suricata/suricata.yaml"
SNI_RULE = "/var/lib/suricata/rules/stepad-sni.rules"

# Red interna adicional siempre vigilada: VPN (WireGuard).
VPN_NET = "10.200.0.0/24"

APP_CONFIG = (
    Path(__file__).resolve().parent.parent
    / "backend" / "shared" / "config" / "config.yaml"
)


def _lan_cidr() -> str:
    with open(APP_CONFIG) as f:
        cfg = yaml.safe_load(f) or {}

    dhcp = cfg.get("dhcp") or {}

    network = dhcp.get("network")

    netmask = dhcp.get("netmask")

    if not network or not netmask:
        return "192.168.0.0/24"

    try:
        return str(
            ipaddress.ip_network(
                f"{network}/{netmask}",
                strict=False
            )
        )
    except ValueError:
        return "192.168.0.0/24"


def main() -> int:
    with open(P) as f:
        cfg = yaml.safe_load(f) or {}

    home_net = f"[{_lan_cidr()},{VPN_NET}]"

    cfg.setdefault("vars", {}).setdefault(
        "address-groups", {}
    )["HOME_NET"] = home_net

    cfg["nfq"] = [{"mode": "ips", "queue": 0, "repeat-mark": "yes"}]

    # Se corre en modo NFQUEUE inline (-q 0). El yaml por defecto trae
    # `af-packet: eth0` (interfaz inexistente en muchos equipos). Se usa
    # `interface: default` (generico: enlaza las disponibles) para que
    # Suricata arranque sin depender del nombre de la NIC.
    cfg["af-packet"] = [{"interface": "default"}]

    rule_files = cfg.get("rule-files") or []
    if SNI_RULE not in rule_files:
        rule_files.append(SNI_RULE)
    cfg["rule-files"] = rule_files

    cfg["unix-command"] = {
        "enabled": True,
        "filename": "/var/run/suricata-command.socket",
    }

    # Tuning de rendimiento (Suricata 7, IPS via NFQUEUE).
    # `detect.profile: high` optimiza el motor de deteccion a costa de
    # algo mas de memoria (el equipo NSP no va escaso). NO se apagan
    # parsers de app-layer: el ruleset de suricata-update contiene
    # firmas de telnet/rfb/bittorrent/etc. y desactivarlos rompe la
    # carga de reglas.
    cfg.setdefault("detect", {})["profile"] = "high"

    # IPS por NFQUEUE: `auto`/`drop` en midstream/stream_error corta
    # flujos válidos (p.ej. GGC). Preferir ignore + permitir midstream.
    cfg["exception-policy"] = "ignore"
    stream = cfg.setdefault("stream", {})
    if isinstance(stream, dict):
        stream["midstream"] = True
    else:
        cfg["stream"] = {"midstream": True}

    _configure_eve_log_rotation(cfg)

    with open(P, "w") as f:
        # Suricata exige el encabezado YAML 1.1 (safe_dump lo omite).
        f.write("%YAML 1.1\n---\n")
        yaml.safe_dump(cfg, f, default_flow_style=False, sort_keys=False)

    # PyYAML escribe las secuencias de nivel superior SIN indentar
    # (ej. "rule-files:\n- a\n- b"), lo que es valido para su propio
    # loader pero fragil frente a inserciones textuales posteriores.
    # Se indenta el bloque rule-files para dejarlo convencional.
    _indent_rule_files(P)

    print("suricata.yaml configurado (IPS + reglas SNI + socket).")
    return 0


def _configure_eve_log_rotation(cfg: dict) -> None:
    """Limita el tamaño de eve.json para no llenar disco ni romper offsets."""

    outputs = cfg.get("outputs")

    if not isinstance(outputs, list):

        outputs = []

    eve_cfg = None

    for item in outputs:

        if isinstance(item, dict) and "eve-log" in item:

            eve_cfg = item["eve-log"]

            break

    if eve_cfg is None:

        eve_cfg = {}

        outputs.append({"eve-log": eve_cfg})

    eve_cfg.update(
        {
            "enabled": True,
            "filetype": "regular",
            "filename": "eve.json",
            "rotate-size": "100mb",
            "rotate-num": 5,
        }
    )

    cfg["outputs"] = outputs


def _indent_rule_files(path: str) -> None:
    with open(path) as f:
        lines = f.readlines()

    out = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        out.append(line)
        if line.rstrip("\n").lstrip() == "rule-files:":
            i += 1
            while i < n and lines[i].lstrip().startswith("- "):
                out.append("  " + lines[i].lstrip())
                i += 1
            continue
        i += 1

    with open(path, "w") as f:
        f.writelines(out)


if __name__ == "__main__":
    raise SystemExit(main())
