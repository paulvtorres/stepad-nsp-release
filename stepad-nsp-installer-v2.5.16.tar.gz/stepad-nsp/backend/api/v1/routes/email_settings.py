from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.notifications.services.email_settings_service import (
    EmailSettingsService,
)
from backend.notifications.schemas.email_settings import (
    EmailSettingsRequest,
    EmailTestRequest,
)


router = APIRouter(
    prefix="/email",
    tags=["Email"],
)

service = EmailSettingsService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    return service.get_settings(db)


@router.get("/providers")
def list_providers(
    current_user: dict = Depends(get_current_user),
):

    return service.list_providers()


@router.put("/settings")
def save_settings(
    request: EmailSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.save_settings(db, request)


@router.post("/test")
def send_test(
    request: EmailTestRequest | None = None,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    to_email = request.to_email if request else None

    return service.send_test(db, to_email)
