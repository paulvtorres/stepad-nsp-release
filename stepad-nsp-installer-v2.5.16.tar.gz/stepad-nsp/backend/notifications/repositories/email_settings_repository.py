from sqlalchemy import inspect, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from backend.notifications.models.email_settings import EmailSettings
from backend.notifications.constants.email_providers import detect_provider

from backend.shared.logging.logger import logger


def _ensure_email_settings_table(db: Session) -> None:

    bind = db.get_bind()

    if "email_settings" in inspect(bind).get_table_names():

        return

    logger.warning(
        "Tabla email_settings ausente; creando e importando SMTP existente."
    )

    EmailSettings.__table__.create(bind, checkfirst=True)

    if "notification_settings" in inspect(bind).get_table_names():

        db.execute(
            text(
                """
                INSERT INTO email_settings (
                    id, provider, smtp_host, smtp_port,
                    smtp_user, smtp_password, from_email, updated_at
                )
                SELECT
                    1,
                    CASE
                        WHEN LOWER(COALESCE(smtp_host, '')) = 'smtp.gmail.com'
                            THEN 'gmail'
                        WHEN LOWER(COALESCE(smtp_host, '')) = 'smtp-mail.outlook.com'
                            THEN 'outlook'
                        WHEN LOWER(COALESCE(smtp_host, '')) = 'smtp.office365.com'
                            THEN 'office365'
                        WHEN LOWER(COALESCE(smtp_host, '')) = 'smtp.mail.yahoo.com'
                            THEN 'yahoo'
                        ELSE 'custom'
                    END,
                    COALESCE(smtp_host, ''),
                    COALESCE(smtp_port, 587),
                    smtp_user,
                    smtp_password,
                    COALESCE(from_email, ''),
                    updated_at
                FROM notification_settings
                WHERE id = 1
                """
            )
        )

    else:

        db.add(EmailSettings(id=1))

    db.commit()


class EmailSettingsRepository:

    def get(
        self,
        db: Session,
    ) -> EmailSettings:

        try:

            _ensure_email_settings_table(db)

            settings = db.get(EmailSettings, 1)

        except OperationalError as error:

            db.rollback()

            logger.exception(
                "Error accediendo email_settings: %s",
                error,
            )

            raise

        if settings is None:

            settings = EmailSettings(id=1)

            db.add(settings)

            db.commit()

            db.refresh(settings)

        elif not (settings.provider or "").strip():

            settings.provider = detect_provider(settings.smtp_host)

            db.commit()

            db.refresh(settings)

        return settings

    def save(
        self,
        db: Session,
        settings: EmailSettings,
    ):

        db.commit()

        db.refresh(settings)

        return settings
