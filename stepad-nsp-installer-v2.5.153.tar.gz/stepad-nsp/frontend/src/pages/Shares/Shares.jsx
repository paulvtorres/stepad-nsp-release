import { useCallback, useEffect, useMemo, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getShareStatus,
    shareVolume,
    unshareVolume,
    formatShareDisk,
    deleteSharePartition,
    createSharePartition,
    unlockShareIntegrity,
    createShareFolder,
    deleteShareFolder,
    setShareFolderGroups,
    setShareFolderShared,
    mountDisk,
} from "../../services/api";

import { getToken } from "../../auth/authStorage";

import FolderExplorer from "./SharesExplorer";
import FileExplorer from "../../components/FileExplorer/FileExplorer";
import { createDiskAdapter } from "../../components/FileExplorer/adapters";
import NetworkUnitsCard from "./NetworkUnitsCard";

import "./shares.css";


const API_URL = import.meta.env.VITE_API_URL || "/api/v1";

const VIEW_UNITS = "unidades";
const VIEW_FOLDERS = "carpetas";
const VIEW_DISK = "disco";


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function formatSize(bytes) {
    if (
        bytes == null ||
        !Number.isFinite(Number(bytes)) ||
        Number(bytes) < 0
    ) {
        return "—";
    }

    const value = Number(bytes);

    if (value === 0) {
        return "0 B";
    }

    const units = ["B", "KB", "MB", "GB", "TB"];

    const index = Math.min(
        Math.floor(Math.log(value) / Math.log(1024)),
        units.length - 1
    );

    const size = value / 1024 ** index;

    return `${size.toFixed(
        size >= 100 || index === 0 ? 0 : 1
    )} ${units[index]}`;
}


function freeGbOf(bytes) {
    if (bytes == null || !Number.isFinite(Number(bytes))) {
        return 0;
    }

    return Number(bytes) / 1024 ** 3;
}


function fmtGb(gb) {
    if (!Number.isFinite(Number(gb)) || Number(gb) <= 0) {
        return "0";
    }

    const value = Number(gb);

    return value >= 100
        ? String(Math.floor(value))
        : String(Math.round(value * 10) / 10);
}


async function fetchSilent(endpoint) {
    const token = getToken();

    const response = await fetch(`${API_URL}${endpoint}`, {
        headers: {
            "Content-Type": "application/json",
            ...(token
                ? { Authorization: `Bearer ${token}` }
                : {}),
        },
    });

    if (!response.ok) {
        throw new Error(`API Error ${response.status}`);
    }

    return response.json();
}


/* -------------------------------------------------------------------------- */
/* Component                                                                  */
/* -------------------------------------------------------------------------- */

function Shares() {
    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    /* ---------------------------------------------------------------------- */
    /* Main state                                                             */
    /* ---------------------------------------------------------------------- */

    const [status, setStatus] = useState(null);
    const [groups, setGroups] = useState([]);

    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);

    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);

    const [view, setView] = useState(VIEW_UNITS);

    /* ---------------------------------------------------------------------- */
    /* Selection                                                              */
    /* ---------------------------------------------------------------------- */

    const [selectedDevice, setSelectedDevice] = useState(null);

    /*
     * Estado independiente para el explorador de una partición
     * que todavía no es una unidad compartida.
     */
    const [mountedDisk, setMountedDisk] = useState(null);

    /* ---------------------------------------------------------------------- */
    /* Unit / folder state                                                    */
    /* ---------------------------------------------------------------------- */

    const [names, setNames] = useState({});
    const [newPart, setNewPart] = useState({});

    const [folderDraft, setFolderDraft] = useState("");

    const [openFolder, setOpenFolder] = useState(null);

    const [permOpen, setPermOpen] = useState(null);
    const [permDraft, setPermDraft] = useState({});

    const [confirmUp, setConfirmUp] = useState(null);


    /* ---------------------------------------------------------------------- */
    /* Derived data                                                           */
    /* ---------------------------------------------------------------------- */

    const volumes = useMemo(
        () => status?.volumes || [],
        [status]
    );

    const folders = useMemo(
        () => status?.folders || [],
        [status]
    );

    const disks = useMemo(
        () => status?.disks || [],
        [status]
    );

    const diskAdapter = useMemo(
        () => (
            mountedDisk
                ? createDiskAdapter(mountedDisk.mountpoint)
                : null
        ),
        [mountedDisk]
    );

    /*
     * Convertimos la estructura:
     *
     * disks[]
     *   partitions[]
     *
     * en una lista plana para trabajar fácilmente con la partición
     * seleccionada.
     */
    const allPartitions = useMemo(() => {
        const result = [];

        for (const disk of disks) {
            for (const partition of disk.partitions || []) {
                result.push({
                    ...partition,

                    disk: disk.device,
                    model: disk.model,
                    transport: disk.transport,
                    bus: disk.bus,
                });
            }
        }

        return result;
    }, [disks]);


    const selectedPart = useMemo(() => {
        if (!selectedDevice) {
            return null;
        }

        return (
            allPartitions.find(
                (partition) => partition.device === selectedDevice
            ) || null
        );
    }, [allPartitions, selectedDevice]);


    /*
     * Una partición física y una unidad compartida son conceptos
     * diferentes.
     *
     * selectedPart:
     *     /dev/sdb1
     *
     * selectedUnit:
     *     volume registrado en NSP
     */
    const selectedUnit = useMemo(() => {
        if (!selectedPart?.volume_id) {
            return null;
        }

        return (
            volumes.find(
                (volume) => volume.id === selectedPart.volume_id
            ) || null
        );
    }, [selectedPart, volumes]);


    const unitFolders = useMemo(() => {
        if (!selectedUnit) {
            return [];
        }

        return folders.filter(
            (folder) => folder.volume_id === selectedUnit.id
        );
    }, [folders, selectedUnit]);


    const sambaOk = Boolean(status?.samba?.installed);

    const integrity = status?.integrity || {};

    const integrityLocked = Boolean(integrity.locked);
    const integrityPaused = Boolean(integrity.paused);

    const diskHealth = status?.disk_health || null;

    const diskHealthProblems = useMemo(
        () =>
            (diskHealth?.disks || []).filter(
                (disk) =>
                    disk.level === "warning" ||
                    disk.level === "critical"
            ),
        [diskHealth]
    );


    /* ---------------------------------------------------------------------- */
    /* Error / notice                                                         */
    /* ---------------------------------------------------------------------- */

    const setUpError = useCallback((message) => {
        setError(message || null);
    }, []);


    useEffect(() => {
        if (!notice) {
            return undefined;
        }

        const timer = setTimeout(() => {
            setNotice(null);
        }, 5000);

        return () => clearTimeout(timer);
    }, [notice]);


    /* ---------------------------------------------------------------------- */
    /* Load status                                                            */
    /* ---------------------------------------------------------------------- */

    const load = useCallback(async () => {
        try {
            const [nextStatus, nextGroups] = await Promise.all([
                fetchSilent("/shares/status"),

                fetchSilent("/groups/")
                    .catch(() => []),
            ]);

            setStatus(nextStatus);
            setGroups(nextGroups || []);

            setError(null);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setLoading(false);
        }
    }, [setUpError]);


    useEffect(() => {
        load();

        const timer = setInterval(load, 5000);

        return () => {
            clearInterval(timer);
        };
    }, [load]);


    /* ---------------------------------------------------------------------- */
    /* Keep selection valid                                                  */
    /* ---------------------------------------------------------------------- */

    useEffect(() => {
        if (allPartitions.length === 0) {
            setSelectedDevice(null);
            return;
        }

        /*
         * Si la partición seleccionada todavía existe,
         * no cambiamos nada.
         */
        if (
            selectedDevice &&
            allPartitions.some(
                (partition) =>
                    partition.device === selectedDevice
            )
        ) {
            return;
        }

        /*
         * Preferimos una partición ya configurada como unidad.
         */
        const firstUnitPartition = allPartitions.find(
            (partition) => partition.volume_id
        );

        const nextDevice =
            firstUnitPartition?.device ||
            allPartitions[0]?.device ||
            null;

        setSelectedDevice(nextDevice);
    }, [allPartitions, selectedDevice]);


    /* ---------------------------------------------------------------------- */
    /* Selection reset                                                        */
    /* ---------------------------------------------------------------------- */

    const selectPartition = useCallback((device) => {
        setSelectedDevice(device);

        setOpenFolder(null);
        setPermOpen(null);

        setMountedDisk(null);

        setView(VIEW_UNITS);

        setError(null);
        setNotice(null);
    }, []);


    /* ---------------------------------------------------------------------- */
    /* Partition form                                                         */
    /* ---------------------------------------------------------------------- */

    function partForm(disk) {
        return (
            newPart[disk] || {
                sizeGb: "",
                role: "share",
            }
        );
    }


    function setPartForm(disk, patch) {
        setNewPart((previous) => ({
            ...previous,

            [disk]: {
                ...partForm(disk),
                ...patch,
            },
        }));
    }


    /* ---------------------------------------------------------------------- */
    /* Confirmation                                                           */
    /* ---------------------------------------------------------------------- */

    function askConfirm(id, label, run) {
        setConfirmUp({
            id,
            label,
            run,
        });
    }


    function runConfirmed() {
        const run = confirmUp?.run;

        if (!run) {
            return;
        }

        setConfirmUp(null);

        run();
    }


    function isConfirming(id) {
        return confirmUp?.id === id;
    }


    /* ---------------------------------------------------------------------- */
    /* Generic action                                                         */
    /* ---------------------------------------------------------------------- */

    async function doAction(fn, successMessage) {
        setUpError(null);
        setNotice(null);
        setBusy(true);

        try {
            const next = await fn();

            if (next) {
                setStatus(next);
            }

            if (successMessage) {
                setNotice(successMessage);
            }
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Mount / explore physical disk                                          */
    /* ---------------------------------------------------------------------- */

    async function viewDiskContents(part) {
        const device = part?.device;

        if (!device) {
            return;
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            let mountpoint;
            let readonly = false;

            if (selectedUnit && selectedUnit.mountpoint) {
                mountpoint = selectedUnit.mountpoint;
                readonly = false;
            } else {
                const result = await mountDisk(device);
                mountpoint = result?.mountpoint;
                readonly = Boolean(result?.readonly);

                if (!mountpoint) {
                    throw new Error(
                        result?.error ||
                        "El servidor no devolvio el punto de montaje."
                    );
                }
            }

            setMountedDisk({
                device,
                mountpoint,
                readonly,
            });

            /*
             * IMPORTANTE:
             *
             * No usamos VIEW_FOLDERS aquí.
             *
             * Esta partición todavía no necesariamente es una
             * unidad compartida / volume.
             */
            setView(VIEW_DISK);

            setNotice(
                `Disco montado en ${mountpoint}.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Share volume                                                           */
    /* ---------------------------------------------------------------------- */

    async function handleShare(part) {
        const device = part?.device;

        if (!device) {
            return;
        }

        const name = (
            names[device] ||
            ""
        ).trim();

        if (!name) {
            setUpError(
                "Escribe un nombre para la unidad."
            );
            return;
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            const next = await shareVolume({
                device,
                name,
            });

            setStatus(next);

            setSelectedDevice(device);
            setOpenFolder(null);

            setNotice(
                `«${name}» activada como unidad.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Unshare volume                                                         */
    /* ---------------------------------------------------------------------- */

    async function handleUnshare(part) {
        const volumeId = part?.volume_id;
        const device = part?.device;

        if (!volumeId || !device) {
            return;
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            const next = await unshareVolume(volumeId);

            setStatus(next);

            setOpenFolder(null);

            setView(VIEW_UNITS);

            setNotice(
                next?.message ||
                `Unidad ${device} desactivada.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Format                                                                 */
    /* ---------------------------------------------------------------------- */

    async function handleFormat(part) {
        const device = part?.device;

        if (!device) {
            return;
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            const next = await formatShareDisk({
                device,
                confirm: "FORMATEAR",
                assign: false,
                whole_disk: false,
            });

            setStatus(next);

            setNotice(
                next?.message ||
                `${device} formateado.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Delete partition                                                       */
    /* ---------------------------------------------------------------------- */

    async function handleDeletePartition(part) {
        const device = part?.device;

        if (!device) {
            return;
        }

        if (part.volume_id || part.sharing) {
            setUpError(
                "Desactiva la unidad antes de eliminar la partición."
            );
            return;
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            const next = await deleteSharePartition({
                device,
                confirm: "ELIMINAR",
            });

            setStatus(next);

            setSelectedDevice(null);

            setMountedDisk(null);

            setNotice(
                next?.message ||
                `Partición ${device} eliminada.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Create partition                                                       */
    /* ---------------------------------------------------------------------- */

    async function handleCreatePartition(
        disk,
        options = {}
    ) {
        const device = disk?.device;

        if (!device) {
            return;
        }

        const form = partForm(device);

        const useRemaining =
            Boolean(options.useRemaining);

        const role =
            options.role ||
            form.role ||
            "share";

        let sizeGb = null;

        if (!useRemaining) {
            const raw =
                options.sizeGb != null
                    ? options.sizeGb
                    : form.sizeGb;

            sizeGb = Number(raw);

            if (
                !Number.isFinite(sizeGb) ||
                sizeGb <= 0
            ) {
                setUpError(
                    "Indica el tamaño en GB."
                );
                return;
            }
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            const next = await createSharePartition({
                disk: device,

                size_gb: useRemaining
                    ? null
                    : sizeGb,

                use_remaining: useRemaining,

                role,
            });

            setStatus(next);

            if (next?.created_device) {
                setSelectedDevice(
                    next.created_device
                );
            }

            setNotice(
                next?.message ||
                "Partición creada."
            );

            const nextDisk =
                (next?.disks || []).find(
                    (item) =>
                        item.device === device
                );

            const remainGb =
                freeGbOf(nextDisk?.free);

            setPartForm(device, {
                sizeGb:
                    remainGb > 0
                        ? fmtGb(remainGb)
                        : "",
            });
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Folder                                                                 */
    /* ---------------------------------------------------------------------- */

    async function handleCreateFolder() {
        if (!selectedUnit?.id) {
            return;
        }

        const name =
            folderDraft.trim();

        if (!name) {
            setUpError(
                "Escribe un nombre para la carpeta."
            );
            return;
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            await createShareFolder({
                name,
                volume_id: selectedUnit.id,
            });

            setFolderDraft("");

            const next =
                await getShareStatus();

            setStatus(next);

            setNotice(
                `Carpeta «${name}» creada.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    async function handleDeleteFolder(folder) {
        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            await deleteShareFolder(folder.id);

            setPermOpen((current) =>
                current === folder.id
                    ? null
                    : current
            );

            if (
                openFolder?.id === folder.id
            ) {
                setOpenFolder(null);
            }

            const next =
                await getShareStatus();

            setStatus(next);

            setNotice(
                `Carpeta «${folder.name}» eliminada.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    async function handleUnshareFolder(folder) {
        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            const next =
                await setShareFolderShared(
                    folder.id,
                    false
                );

            setStatus((previous) => ({
                ...previous,

                folders:
                    (previous?.folders || []).map(
                        (item) =>
                            item.id === next.id
                                ? next
                                : item
                    ),
            }));

            setPermOpen((current) =>
                current === folder.id
                    ? null
                    : current
            );

            setNotice(
                `Carpeta «${folder.name}» vuelve a ser privada.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }



    async function handleShareFolder(folder) {
        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            const next =
                await setShareFolderShared(
                    folder.id,
                    true
                );

            setStatus((previous) => ({
                ...previous,

                folders:
                    (previous?.folders || []).map(
                        (item) =>
                            item.id === next.id
                                ? next
                                : item
                    ),
            }));

            setNotice(
                `Carpeta \u00AB${folder.name}\u00BB compartida en la red.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    async function handleShareDiskFolder(item, crumbs) {
        if (!selectedUnit?.id || !item) return;
        const folderName = item.name;
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            await createShareFolder({
                name: folderName,
                volume_id: selectedUnit.id,
                folder_name: folderName,
            });
            const next = await getShareStatus();
            setStatus(next);
            setNotice(`Carpeta «${folderName}» creada y compartida.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    /* ---------------------------------------------------------------------- */
    /* Permissions                                                            */
    /* ---------------------------------------------------------------------- */

    function openPerms(folder) {
        if (permOpen === folder.id) {
            setPermOpen(null);
            return;
        }

        setPermOpen(folder.id);

        setPermDraft((previous) => ({
            ...previous,

            [folder.id]:
                (folder.groups || []).map(
                    (group) => ({
                        group_id: group.group_id,
                        access_mode: group.access_mode,
                    })
                ),
        }));
    }


    function togglePermGroup(groupId) {
        setPermDraft((previous) => {
            const current = [
                ...(previous[permOpen] || []),
            ];

            const existing =
                current.find(
                    (group) =>
                        group.group_id === groupId
                );

            if (existing) {
                return {
                    ...previous,

                    [permOpen]:
                        current.filter(
                            (group) =>
                                group.group_id !== groupId
                        ),
                };
            }

            return {
                ...previous,

                [permOpen]: [
                    ...current,

                    {
                        group_id: groupId,
                        access_mode: "read",
                    },
                ],
            };
        });
    }


    function changePermMode(
        groupId,
        mode
    ) {
        setPermDraft((previous) => ({
            ...previous,

            [permOpen]:
                (previous[permOpen] || []).map(
                    (group) =>
                        group.group_id === groupId
                            ? {
                                ...group,
                                access_mode: mode,
                            }
                            : group
                ),
        }));
    }


    async function savePerms(folder) {
        const grants =
            permDraft[folder.id] || [];

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            await setShareFolderGroups(
                folder.id,
                {
                    groups: grants.map(
                        (grant) => ({
                            group_id:
                                grant.group_id,

                            access_mode:
                                grant.access_mode,
                        })
                    ),
                }
            );

            const refreshed =
                await getShareStatus();

            setStatus(refreshed);

            setPermOpen(null);

            setNotice(
                grants.length === 0
                    ? `«${folder.name}» está compartida sin restricciones.`
                    : `Permisos de «${folder.name}» actualizados.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    async function makePublic(folder) {
        setPermDraft((previous) => ({
            ...previous,
            [folder.id]: [],
        }));

        setBusy(true);
        setUpError(null);
        setNotice(null);

        try {
            await setShareFolderGroups(
                folder.id,
                {
                    groups: [],
                }
            );

            const refreshed =
                await getShareStatus();

            setStatus(refreshed);

            setPermOpen(null);

            setNotice(
                `«${folder.name}» está compartida sin restricciones.`
            );
        } catch (err) {
            setUpError(
                err.message ||
                String(err)
            );
        } finally {
            setBusy(false);
        }
    }


    /* ---------------------------------------------------------------------- */
    /* Labels                                                                 */
    /* ---------------------------------------------------------------------- */

    function folderAccessLabel(folder) {
        if (!folder.shared) {
            return {
                text: "Privada (solo web)",
                cls: "private",
            };
        }

        const grants =
            folder.groups || [];

        if (grants.length === 0) {
            return {
                text: "Compartida",
                cls: "public",
            };
        }

        const write =
            grants.some(
                (grant) =>
                    grant.access_mode === "write"
            );

        return {
            text:
                `Compartida · ${grants.length} grupo` +
                (grants.length === 1
                    ? ""
                    : "s"),

            cls:
                write
                    ? "private"
                    : "readonly",
        };
    }


    function partitionState(partition) {
        if (partition.volume_id) {
            return {
                text: "Activa",
                cls: "green",
            };
        }

        if (partition.fstype) {
            return {
                text: "Con formato",
                cls: "",
            };
        }

        return {
            text: "Sin formato",
            cls: "readonly",
        };
    }


    /* ---------------------------------------------------------------------- */
    /* Action button                                                          */
    /* ---------------------------------------------------------------------- */

    function renderActionButton(
        id,
        actionLabel,
        onAction,
        options = {}
    ) {
        const {
            danger = false,
            primary = false,
            disabled = false,
            title,
            confirmLabel,
        } = options;

        if (isConfirming(id)) {
            return (
                <span className="sh-confirm-inline">
                    <span>
                        {confirmUp.label}
                    </span>

                    <button
                        type="button"
                        className="sh-btn sh-btn-sm danger"
                        disabled={busy}
                        onClick={runConfirmed}
                    >
                        Confirmar
                    </button>

                    <button
                        type="button"
                        className="sh-btn sh-btn-sm"
                        disabled={busy}
                        onClick={() =>
                            setConfirmUp(null)
                        }
                    >
                        Cancelar
                    </button>
                </span>
            );
        }

        return (
            <button
                type="button"
                className={[
                    "sh-btn",
                    "sh-btn-sm",

                    danger
                        ? "danger"
                        : "",

                    primary
                        ? "primary"
                        : "",
                ]
                    .filter(Boolean)
                    .join(" ")}

                disabled={
                    disabled ||
                    busy
                }

                title={title}

                onClick={() => {
                    if (confirmLabel) {
                        askConfirm(
                            id,
                            confirmLabel,
                            onAction
                        );
                    } else {
                        onAction();
                    }
                }}
            >
                {actionLabel}
            </button>
        );
    }


    /* ---------------------------------------------------------------------- */
    /* Disk explorer                                                          */
    /* ---------------------------------------------------------------------- */

    function renderDiskExplorer() {
        if (!mountedDisk) {
            return (
                <div className="sh-main-placeholder">
                    <p className="sh-empty">
                        No hay ningún disco montado.
                    </p>
                </div>
            );
        }

        return (
            <div className="sh-unit-detail">
                <p className="sh-eyebrow">
                    Explorador de disco
                </p>

                <h3>
                    {mountedDisk.device}
                </h3>

                <p className="sh-part-hint">
                    Montado en{" "}
                    <code className="sh-inline-code">
                        {mountedDisk.mountpoint}
                    </code>
                </p>

                <FileExplorer
                    key={mountedDisk.mountpoint}
                    adapter={diskAdapter}
                    rootLabel={mountedDisk.device}
                    readOnly={mountedDisk.readonly}
                    exitLabel="← Volver a unidades"
                    onExit={() => {
                        setMountedDisk(null);
                        setView(VIEW_UNITS);
                    }}
                />
                    onShareFolder={selectedUnit ? handleShareDiskFolder : null}
            </div>
        );
    }


    /* ---------------------------------------------------------------------- */
    /* Loading                                                                */
    /* ---------------------------------------------------------------------- */

    if (loading && !status) {
        return (
            <div className="sh-page">
                <p className="sh-loading">
                    Cargando…
                </p>
            </div>
        );
    }


    /* ---------------------------------------------------------------------- */
    /* Render                                                                 */
    /* ---------------------------------------------------------------------- */

    return (
        <div className="sh-page">

            {/* ---------------------------------------------------------------- */}
            {/* Header                                                           */}
            {/* ---------------------------------------------------------------- */}

            <header className="sh-hero">
                <p className="sh-eyebrow">
                    Almacenamiento
                </p>

                <h1>
                    Unidades de disco
                </h1>

                <p className="sh-lede">
                    Administrá discos y particiones,
                    creá carpetas compartidas o privadas
                    y programá respaldos automáticos
                    protegidos.
                </p>
            </header>


            {/* ---------------------------------------------------------------- */}
            {/* Global messages                                                  */}
            {/* ---------------------------------------------------------------- */}

            {!sambaOk && (
                <div className="sh-banner warn">
                    Falta Samba. En el servidor:
                    {" "}
                    <code>
                        sudo apt-get install -y samba
                    </code>
                </div>
            )}


            {diskHealthProblems.length > 0 && (
                <div
                    className={`sh-banner ${
                        diskHealth?.worst === "critical"
                            ? "error"
                            : "warn"
                    }`}
                >
                    <strong>
                        Salud del disco:
                    </strong>

                    <ul className="sh-health-list">
                        {diskHealthProblems.map(
                            (disk) => (
                                <li
                                    key={disk.device}
                                >
                                    <code>
                                        {disk.device}
                                    </code>

                                    {disk.model
                                        ? ` (${disk.model})`
                                        : ""}

                                    {" — "}

                                    {disk.message}
                                </li>
                            )
                        )}
                    </ul>
                </div>
            )}


            {integrityLocked && (
                <div className="sh-banner error sh-integrity-banner">
                    <div>
                        <strong>
                            Escritura bloqueada por
                            protección antiransomware.
                        </strong>

                        <p>
                            {integrity.detail ||
                                "Se detectaron cambios masivos de archivos."}
                        </p>
                    </div>

                    {isAdmin && (
                        <button
                            type="button"
                            className="sh-btn danger"
                            disabled={
                                busy ||
                                integrityPaused
                            }
                            onClick={() => {
                                if (
                                    !confirm(
                                        "¿Reactivar escritura? Revisa antes que no haya ransomware activo."
                                    )
                                ) {
                                    return;
                                }

                                doAction(
                                    () =>
                                        unlockShareIntegrity(),
                                    "Escritura reactivada."
                                );
                            }}
                        >
                            Reactivar escritura
                        </button>
                    )}
                </div>
            )}


            {error && (
                <div className="sh-banner error">
                    {error}
                </div>
            )}


            {notice && (
                <div className="sh-banner ok sh-notice">
                    {notice}
                </div>
            )}


            {/* ---------------------------------------------------------------- */}
            {/* Tabs                                                             */}
            {/* ---------------------------------------------------------------- */}

            <nav
                className="sh-view-tabs"
                role="tablist"
                aria-label="Secciones de almacenamiento"
            >
                <button
                    type="button"
                    role="tab"
                    aria-selected={
                        view === VIEW_UNITS
                    }
                    className={
                        view === VIEW_UNITS
                            ? "active"
                            : ""
                    }
                    onClick={() =>
                        setView(VIEW_UNITS)
                    }
                >
                    Unidades
                </button>


            </nav>


            {/* ================================================================= */}
            {/* UNIDADES                                                          */}
            {/* ================================================================= */}

            {view === VIEW_UNITS && (
                <section className="sh-split sh-units-view">

                    {/* --------------------------------------------------------- */}
                    {/* Left                                                       */}
                    {/* --------------------------------------------------------- */}

                    <aside className="sh-pane sh-side">
                        <div className="sh-side-window">

                            <h2>
                                Discos y particiones
                            </h2>

                            {disks.length === 0 ? (
                                <p className="sh-empty">
                                    Conecta un disco USB o
                                    un disco adicional.
                                </p>
                            ) : (
                                <div className="sh-side-list">

                                    {disks.map(
                                        (disk) => (
                                            <div
                                                key={
                                                    disk.device
                                                }
                                                className="sh-side-disk"
                                            >

                                                <div className="sh-side-disk-head">

                                                    <span className="sh-badge">
                                                        {disk.bus ||
                                                            "DISCO"}
                                                    </span>

                                                    <strong>
                                                        {disk.device}
                                                    </strong>

                                                    {disk.model && (
                                                        <span className="sh-muted sh-side-model">
                                                            {disk.model}
                                                        </span>
                                                    )}

                                                    <span className="sh-muted">
                                                        {formatSize(
                                                            disk.size
                                                        )}

                                                        {disk.free >
                                                            0 &&
                                                            ` · libre ${formatSize(
                                                                disk.free
                                                            )}`}
                                                    </span>
                                                </div>


                                                {/* Partitions */}
                                                <ul className="sh-part-list">

                                                    {(disk.partitions ||
                                                        []).map(
                                                        (part) => {
                                                            const state =
                                                                partitionState(
                                                                    part
                                                                );

                                                            const active =
                                                                selectedDevice ===
                                                                part.device;

                                                            const nameValue =
                                                                names[
                                                                    part.device
                                                                ] ??
                                                                "";

                                                            return (
                                                                <li
                                                                    key={
                                                                        part.device
                                                                    }
                                                                    className={[
                                                                        "sh-part-row",

                                                                        part.volume_id
                                                                            ? "sharing"
                                                                            : "",

                                                                        active
                                                                            ? "selected"
                                                                            : "",
                                                                    ]
                                                                        .filter(
                                                                            Boolean
                                                                        )
                                                                        .join(
                                                                            " "
                                                                        )}

                                                                    onClick={() =>
                                                                        selectPartition(
                                                                            part.device
                                                                        )
                                                                    }
                                                                >

                                                                    <div className="sh-part-main">

                                                                        <div className="sh-part-title">

                                                                            <strong>
                                                                                {
                                                                                    part.device
                                                                                }
                                                                            </strong>

                                                                            <span className="sh-part-meta">
                                                                                {formatSize(
                                                                                    part.size
                                                                                )}
                                                                            </span>

                                                                            <span className="sh-part-meta">
                                                                                {part.fstype ||
                                                                                    "sin formato"}
                                                                            </span>

                                                                        </div>


                                                                        {!part.volume_id &&
                                                                            part.fstype && (
                                                                                <label
                                                                                    className="sh-name-field"
                                                                                    onClick={(
                                                                                        event
                                                                                    ) =>
                                                                                        event.stopPropagation()
                                                                                    }
                                                                                >
                                                                                    <input
                                                                                        type="text"
                                                                                        value={
                                                                                            nameValue
                                                                                        }
                                                                                        disabled={
                                                                                            !isAdmin ||
                                                                                            busy
                                                                                        }
                                                                                        placeholder="Nombre de la unidad"
                                                                                        maxLength={
                                                                                            64
                                                                                        }
                                                                                        onChange={(
                                                                                            event
                                                                                        ) =>
                                                                                            setNames(
                                                                                                (
                                                                                                    previous
                                                                                                ) => ({
                                                                                                    ...previous,
                                                                                                    [part.device]:
                                                                                                        event
                                                                                                            .target
                                                                                                            .value,
                                                                                                })
                                                                                            )
                                                                                        }
                                                                                    />
                                                                                </label>
                                                                            )}

                                                                    </div>


                                                                    <span
                                                                        className={`sh-badge ${state.cls}`}
                                                                    >
                                                                        {
                                                                            state.text
                                                                        }
                                                                    </span>


                                                                    {isAdmin && (
                                                                        <div
                                                                            className="sh-side-actions"
                                                                            onClick={(
                                                                                event
                                                                            ) =>
                                                                                event.stopPropagation()
                                                                            }
                                                                        >

                                                                            {part.volume_id ? (
                                                                                renderActionButton(
                                                                                    `unshare:${part.device}`,
                                                                                    "Desactivar",
                                                                                    () =>
                                                                                        handleUnshare(
                                                                                            part
                                                                                        ),
                                                                                    {
                                                                                        danger: true,
                                                                                        confirmLabel:
                                                                                            "¿Desactivar la unidad y sus carpetas?",
                                                                                    }
                                                                                )
                                                                            ) : !part.fstype ? (
                                                                                <>
                                                                                    {renderActionButton(
                                                                                        `fmt:${part.device}`,
                                                                                        "Formatear",
                                                                                        () =>
                                                                                            handleFormat(
                                                                                                part
                                                                                            ),
                                                                                        {
                                                                                            confirmLabel:
                                                                                                "¿Formatear? Se borrará todo el contenido.",
                                                                                        }
                                                                                    )}

                                                                                    {part.deletable &&
                                                                                        renderActionButton(
                                                                                            `del:${part.device}`,
                                                                                            "Eliminar",
                                                                                            () =>
                                                                                                handleDeletePartition(
                                                                                                    part
                                                                                                ),
                                                                                            {
                                                                                                danger: true,
                                                                                                confirmLabel:
                                                                                                    "¿Eliminar la partición?",
                                                                                            }
                                                                                        )}
                                                                                </>
                                                                            ) : (
                                                                                <>
                                                                                    {renderActionButton(
                                                                                        `share:${part.device}`,
                                                                                        "Activar",
                                                                                        () =>
                                                                                            handleShare(
                                                                                                part
                                                                                            ),
                                                                                        {
                                                                                            primary: true,
                                                                                            disabled:
                                                                                                !nameValue.trim(),
                                                                                        }
                                                                                    )}

                                                                                    {renderActionButton(
                                                                                        `del:${part.device}`,
                                                                                        "Eliminar",
                                                                                        () =>
                                                                                            handleDeletePartition(
                                                                                                part
                                                                                            ),
                                                                                        {
                                                                                            danger: true,
                                                                                            confirmLabel:
                                                                                                "¿Eliminar la partición?",
                                                                                        }
                                                                                    )}
                                                                                </>
                                                                            )}

                                                                        </div>
                                                                    )}

                                                                </li>
                                                            );
                                                        }
                                                    )}

                                                </ul>


                                                {/* Create partition */}
                                                {isAdmin &&
                                                    disk.can_create_partition && (
                                                        <div className="sh-create-part">

                                                            <form
                                                                className="sh-create-form"
                                                                onSubmit={(
                                                                    event
                                                                ) => {
                                                                    event.preventDefault();

                                                                    handleCreatePartition(
                                                                        disk
                                                                    );
                                                                }}
                                                            >

                                                                <input
                                                                    type="number"
                                                                    min="0.1"
                                                                    step="any"
                                                                    value={
                                                                        partForm(
                                                                            disk.device
                                                                        ).sizeGb
                                                                    }
                                                                    disabled={
                                                                        busy
                                                                    }
                                                                    placeholder={`TB libre ${fmtGb(
                                                                        freeGbOf(
                                                                            disk.free
                                                                        )
                                                                    )}`}
                                                                    title={`Tamaño en GB (máx ${fmtGb(
                                                                        freeGbOf(
                                                                            disk.free
                                                                        )
                                                                    )})`}
                                                                    onChange={(
                                                                        event
                                                                    ) =>
                                                                        setPartForm(
                                                                            disk.device,
                                                                            {
                                                                                sizeGb:
                                                                                    event
                                                                                        .target
                                                                                        .value,
                                                                            }
                                                                        )
                                                                    }
                                                                />

                                                                <button
                                                                    type="submit"
                                                                    className="sh-btn primary"
                                                                    disabled={
                                                                        busy
                                                                    }
                                                                >
                                                                    Nueva partición
                                                                </button>

                                                                {renderActionButton(
                                                                    `all:${disk.device}`,
                                                                    "Todo el libre",
                                                                    () =>
                                                                        handleCreatePartition(
                                                                            disk,
                                                                            {
                                                                                useRemaining:
                                                                                    true,
                                                                            }
                                                                        ),
                                                                    {
                                                                        disabled:
                                                                            busy,
                                                                    }
                                                                )}

                                                            </form>

                                                        </div>
                                                    )}

                                            </div>
                                        )
                                    )}

                                </div>
                            )}

                        </div>

                        <NetworkUnitsCard />

                    </aside>


                    {/* --------------------------------------------------------- */}
                    {/* Right                                                      */}
                    {/* --------------------------------------------------------- */}

                    <main className="sh-pane sh-main">

                        {selectedPart ? (
                            <div className="sh-unit-detail">

                                <h3>
                                    {selectedUnit?.name ||
                                        selectedPart.device}
                                </h3>

                                <p className="sh-part-hint">
                                    {formatSize(
                                        selectedPart.size
                                    )}

                                    {" · "}

                                    {selectedPart.fstype ||
                                        "sin formato"}

                                    {selectedUnit && (
                                        <>
                                            {" · "}
                                            <code className="sh-inline-code">
                                                {selectedUnit.mountpoint}
                                            </code>
                                        </>
                                    )}
                                </p>

                                <div className="sh-unit-detail-actions">

                                    {selectedPart.fstype && (
                                        <button
                                            type="button"
                                            className="sh-btn primary"
                                            disabled={busy}
                                            onClick={() =>
                                                selectedUnit
                                                    ? setView(VIEW_FOLDERS)
                                                    : viewDiskContents(selectedPart)
                                            }
                                        >
                                            {selectedUnit ? "Administrar carpetas →" : "Explorar contenido →"}
                                        </button>
                                    )}

                                    {!selectedUnit && (
                                        <button
                                            type="button"
                                            className="sh-btn"
                                            disabled={
                                                busy ||
                                                !(
                                                    names[
                                                        selectedPart
                                                            .device
                                                    ] ||
                                                    ""
                                                ).trim()
                                            }
                                            onClick={() =>
                                                handleShare(
                                                    selectedPart
                                                )
                                            }
                                        >
                                            Activar como unidad de red
                                        </button>
                                    )}

                                    {!selectedPart.fstype &&
                                        renderActionButton(
                                            `fmt:${selectedPart.device}`,
                                            "Formatear",
                                            () =>
                                                handleFormat(
                                                    selectedPart
                                                ),
                                            {
                                                confirmLabel:
                                                    "¿Formatear? Se borrará todo el contenido.",
                                            }
                                        )}

                                </div>

                            </div>
                        ) : (
                            <div className="sh-main-placeholder">
                                <p className="sh-empty">
                                    Seleccioná un disco o
                                    partición de la izquierda.
                                </p>
                            </div>
                        )}

                    </main>

                </section>
            )}


            {/* ================================================================= */}
            {/* DISK EXPLORER                                                     */}
            {/* ================================================================= */}

            {view === VIEW_DISK && (
                <section className="sh-pane sh-main sh-disk-full">
                    {renderDiskExplorer()}
                </section>
            )}


            {/* ================================================================= */}
            {/* FOLDERS                                                           */}
            {/* ================================================================= */}

            {view === VIEW_FOLDERS && (
                <section className="sh-split sh-split-3 sh-folders-view">

                    <aside className="sh-pane sh-side">

                        {selectedUnit ? (
                            <div className="sh-side-window">

                                <h2 style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                                    Carpetas
                                    <span className="sh-part-meta">
                                        {" · "}
                                        {
                                            selectedUnit.name
                                        }
                                    </span>
                                    <button
                                        type="button"
                                        className="sh-btn sh-btn-sm"
                                        style={{ marginLeft: "auto", fontSize: "0.75rem" }}
                                        onClick={() => viewDiskContents(selectedPart)}
                                    >
                                        Ver disco →
                                    </button>
                                </h2>


                                {isAdmin && (
                                    <form
                                        className="sh-folder-create"
                                        onSubmit={(
                                            event
                                        ) => {
                                            event.preventDefault();

                                            handleCreateFolder();
                                        }}
                                    >
                                        <input
                                            type="text"
                                            value={
                                                folderDraft
                                            }
                                            disabled={
                                                busy
                                            }
                                            placeholder="Nueva carpeta"
                                            maxLength={
                                                64
                                            }
                                            onChange={(
                                                event
                                            ) =>
                                                setFolderDraft(
                                                    event
                                                        .target
                                                        .value
                                                )
                                            }
                                        />

                                        <button
                                            type="submit"
                                            className="sh-btn primary"
                                            disabled={
                                                busy ||
                                                !folderDraft.trim()
                                            }
                                        >
                                            Crear
                                        </button>
                                    </form>
                                )}


                                {unitFolders.length === 0 ? (
                                    <p className="sh-empty">
                                        {isAdmin
                                            ? "Crea una carpeta para empezar. Las carpetas son privadas hasta que las compartís."
                                            : "No hay carpetas."}
                                    </p>
                                ) : (
                                    <ul className="sh-folder-list">

                                        {unitFolders.map(
                                            (folder) => {
                                                const access =
                                                    folderAccessLabel(
                                                        folder
                                                    );

                                                const draft =
                                                    permDraft[
                                                        folder.id
                                                    ];

                                                const isOpen =
                                                    permOpen ===
                                                    folder.id;

                                                const isSelected =
                                                    openFolder?.id ===
                                                    folder.id;

                                                return (
                                                    <li
                                                        key={
                                                            folder.id
                                                        }
                                                        className={[
                                                            "sh-folder-card",

                                                            isSelected
                                                                ? "selected"
                                                                : "",
                                                        ]
                                                            .filter(
                                                                Boolean
                                                            )
                                                            .join(
                                                                " "
                                                            )}
                                                    >

                                                        <div
                                                            className="sh-folder-row"
                                                            onClick={() => {
                                                                setOpenFolder(
                                                                    folder
                                                                );

                                                                setPermOpen(
                                                                    null
                                                                );
                                                            }}
                                                        >

                                                            <span className="sh-folder-icon">
                                                                {folder.shared
                                                                    ? "🌐"
                                                                    : "🔒"}
                                                            </span>

                                                            <div className="sh-folder-info">

                                                                <div className="sh-folder-title">

                                                                    <strong>
                                                                        {
                                                                            folder.name
                                                                        }
                                                                    </strong>

                                                                    {folder.unc_path && (
                                                                        <code
                                                                            className="sh-inline-code sh-folder-unc"
                                                                            title={
                                                                                folder.unc_path
                                                                            }
                                                                        >
                                                                            {
                                                                                folder.unc_path
                                                                            }
                                                                        </code>
                                                                    )}

                                                                </div>

                                                            </div>

                                                            <span
                                                                className={`sh-badge ${access.cls}`}
                                                            >
                                                                {
                                                                    access.text
                                                                }
                                                            </span>


                                                            {isAdmin && (
                                                                <span
                                                                    className="sh-folder-actions"
                                                                    onClick={(
                                                                        event
                                                                    ) =>
                                                                        event.stopPropagation()
                                                                    }
                                                                >

                                                                    <button
                                                                        type="button"
                                                                        className="sh-btn sh-btn-sm primary"
                                                                        disabled={
                                                                            busy
                                                                        }
                                                                        onClick={() => {
                                                                            setOpenFolder(
                                                                                folder
                                                                            );

                                                                            setPermOpen(
                                                                                null
                                                                            );
                                                                        }}
                                                                    >
                                                                        Abrir
                                                                    </button>


                                                                    {folder.shared ? (
                                                                        <>
                                                                            <button
                                                                                type="button"
                                                                                className="sh-btn sh-btn-sm"
                                                                                disabled={
                                                                                    busy
                                                                                }
                                                                                onClick={() =>
                                                                                    openPerms(
                                                                                        folder
                                                                                    )
                                                                                }
                                                                            >
                                                                                {isOpen
                                                                                    ? "Cerrar"
                                                                                    : "Permisos"}
                                                                            </button>

                                                                            {renderActionButton(
                                                                                `unshare-folder:${folder.id}`,
                                                                                "Dejar de compartir",
                                                                                () =>
                                                                                    handleUnshareFolder(
                                                                                        folder
                                                                                    ),
                                                                                {
                                                                                    danger: true,
                                                                                    confirmLabel:
                                                                                        "¿Hacer la carpeta privada de nuevo (solo web)?",
                                                                                }
                                                                            )}
                                                                        </>
                                                                    ) : isAdmin ? (
                                                                        <button
                                                                            type="button"
                                                                            className="sh-btn sh-btn-sm primary"
                                                                            disabled={busy}
                                                                            onClick={() =>
                                                                                handleShareFolder(
                                                                                    folder
                                                                                )
                                                                            }
                                                                        >
                                                                            Compartir
                                                                        </button>
                                                                    ) : null}


                                                                    {renderActionButton(
                                                                        `del-folder:${folder.id}`,
                                                                        "Eliminar",
                                                                        () =>
                                                                            handleDeleteFolder(
                                                                                folder
                                                                            ),
                                                                        {
                                                                            danger: true,
                                                                            confirmLabel:
                                                                                "¿Eliminar la carpeta?",
                                                                        }
                                                                    )}

                                                                </span>
                                                            )}

                                                        </div>


                                                        {/* Permissions */}
                                                        {isOpen &&
                                                            folder.shared &&
                                                            isAdmin && (
                                                                <div className="sh-perm-panel">

                                                                    <p className="sh-perm-note">
                                                                        Sin grupos marcados,
                                                                        cualquier equipo
                                                                        de la red accede.
                                                                    </p>


                                                                    {groups.length ===
                                                                    0 ? (
                                                                        <p className="sh-part-hint">
                                                                            No hay
                                                                            grupos de
                                                                            dispositivos.
                                                                        </p>
                                                                    ) : (
                                                                        <ul className="sh-perm-list">

                                                                            {groups.map(
                                                                                (
                                                                                    group
                                                                                ) => {
                                                                                    const grant =
                                                                                        (
                                                                                            draft ||
                                                                                            []
                                                                                        ).find(
                                                                                            (
                                                                                                item
                                                                                            ) =>
                                                                                                item.group_id ===
                                                                                                group.id
                                                                                        );

                                                                                    return (
                                                                                        <li
                                                                                            key={
                                                                                                group.id
                                                                                            }
                                                                                            className="sh-perm-row"
                                                                                        >

                                                                                            <label className="sh-perm-check">

                                                                                                <input
                                                                                                    type="checkbox"
                                                                                                    checked={Boolean(
                                                                                                        grant
                                                                                                    )}
                                                                                                    disabled={
                                                                                                        busy
                                                                                                    }
                                                                                                    onChange={() =>
                                                                                                        togglePermGroup(
                                                                                                            group.id
                                                                                                        )
                                                                                                    }
                                                                                                />

                                                                                                <span className="sh-perm-name">

                                                                                                    {
                                                                                                        group.name
                                                                                                    }

                                                                                                    {group.is_default && (
                                                                                                        <em>
                                                                                                            {" · "}
                                                                                                            por defecto
                                                                                                        </em>
                                                                                                    )}

                                                                                                    <small>
                                                                                                        {" "}
                                                                                                        (
                                                                                                        {
                                                                                                            group.devices
                                                                                                        }{" "}
                                                                                                        equipos

                                                                                                        {group.is_default
                                                                                                            ? ""
                                                                                                            : ` · ${group.rules} reglas`}
                                                                                                        )
                                                                                                    </small>

                                                                                                </span>

                                                                                            </label>


                                                                                            {grant && (
                                                                                                <span className="sh-mode">

                                                                                                    <button
                                                                                                        type="button"
                                                                                                        className={
                                                                                                            grant.access_mode ===
                                                                                                            "read"
                                                                                                                ? "active"
                                                                                                                : ""
                                                                                                        }
                                                                                                        disabled={
                                                                                                            busy
                                                                                                        }
                                                                                                        onClick={() =>
                                                                                                            changePermMode(
                                                                                                                group.id,
                                                                                                                "read"
                                                                                                            )
                                                                                                        }
                                                                                                    >
                                                                                                        Lectura
                                                                                                    </button>

                                                                                                    <button
                                                                                                        type="button"
                                                                                                        className={
                                                                                                            grant.access_mode ===
                                                                                                            "write"
                                                                                                                ? "active"
                                                                                                                : ""
                                                                                                        }
                                                                                                        disabled={
                                                                                                            busy
                                                                                                        }
                                                                                                        onClick={() =>
                                                                                                            changePermMode(
                                                                                                                group.id,
                                                                                                                "write"
                                                                                                            )
                                                                                                        }
                                                                                                    >
                                                                                                        Escritura
                                                                                                    </button>

                                                                                                </span>
                                                                                            )}

                                                                                        </li>
                                                                                    );
                                                                                }
                                                                            )}

                                                                        </ul>
                                                                    )}


                                                                    {(draft ||
                                                                        []).length ===
                                                                        0 && (
                                                                        <p className="sh-perm-lock-hint">
                                                                            Sin restricciones
                                                                            · todos los
                                                                            equipos
                                                                            tienen
                                                                            Lectura/Escritura.
                                                                        </p>
                                                                    )}


                                                                    <div className="sh-perm-actions">

                                                                        <button
                                                                            type="button"
                                                                            className="sh-btn"
                                                                            disabled={
                                                                                busy
                                                                            }
                                                                            onClick={() =>
                                                                                makePublic(
                                                                                    folder
                                                                                )
                                                                            }
                                                                        >
                                                                            Sin restricciones
                                                                        </button>

                                                                        <button
                                                                            type="button"
                                                                            className="sh-btn primary"
                                                                            disabled={
                                                                                busy
                                                                            }
                                                                            onClick={() =>
                                                                                savePerms(
                                                                                    folder
                                                                                )
                                                                            }
                                                                        >
                                                                            Guardar
                                                                        </button>

                                                                    </div>

                                                                </div>
                                                            )}

                                                    </li>
                                                );
                                            }
                                        )}

                                    </ul>
                                )}

                            </div>
                        ) : (
                            <div className="sh-main-placeholder">
                                <p className="sh-empty">
                                    Seleccioná una unidad
                                    activa en «Unidades»
                                    para ver sus carpetas.
                                </p>
                            </div>
                        )}

                    </aside>


                    <main className="sh-pane sh-main">

                        {openFolder ? (
                            <FolderExplorer
                                folder={openFolder}
                                onClose={() =>
                                    setOpenFolder(null)
                                }
                            />
                        ) : (
                            <div className="sh-main-placeholder">

                                <p className="sh-empty">
                                    {selectedUnit
                                        ? "Seleccioná una carpeta a la izquierda para ver sus archivos y carpetas."
                                        : "Seleccioná una unidad arriba para ver sus carpetas."}
                                </p>

                            </div>
                        )}

                    </main>

                </section>
            )}

        </div>
    );
}


export default Shares;