/**
 * Estructura del menú lateral. Cada grupo agrupa pantallas relacionadas;
 * adminOnly oculta la entrada a operadores.
 */
export const NAV_GROUPS = [
    {
        id: "overview",
        label: "Inicio",
        items: [
            { to: "/", label: "Panel", end: true },
            { to: "/alerts", label: "Alertas" },
        ],
    },
    {
        id: "network",
        label: "Red",
        items: [
            { to: "/network/interfaces", label: "Interfaces" },
            { to: "/network/dhcp", label: "DHCP" },
            { to: "/network/devices", label: "Dispositivos" },
            { to: "/network/zones", label: "Zonas" },
            { to: "/network/diagram", label: "Diagrama" },
            { to: "/monitoring", label: "Internet (WAN)" },
            { to: "/bandwidth", label: "Ancho de banda" },
            { to: "/load-balancing", label: "Balanceo de carga", adminOnly: true },
        ],
    },
    {
        id: "security",
        label: "Seguridad",
        items: [
            { to: "/security", label: "Firewall y dominios" },
            { to: "/protection", label: "Protección (IPS)" },
            { to: "/external-attacks", label: "Ataques externos" },
            { to: "/egress", label: "Egreso / Exfiltración" },
            { to: "/quarantine", label: "Equipos aislados" },
        ],
    },
    {
        id: "activity",
        label: "Navegación",
        items: [
            { to: "/live-navigation", label: "Navegación en vivo" },
            { to: "/top-pages", label: "Páginas más visitadas" },
            { to: "/logs", label: "Historial DNS" },
        ],
    },
    {
        id: "remote",
        label: "Acceso remoto",
        items: [
            { to: "/vpn", label: "VPN" },
            { to: "/rustdesk", label: "RustDesk" },
        ],
    },
    {
        id: "storage",
        label: "Almacenamiento",
        items: [
            { to: "/shares", label: "Unidades de disco" },
            { to: "/backups", label: "Respaldos de carpetas" },
            { to: "/system-backup", label: "Respaldo del sistema", adminOnly: true },
        ],
    },
    {
        id: "admin",
        label: "Administración",
        items: [
            { to: "/groups", label: "Departamentos" },
            { to: "/hardware", label: "Equipo (hardware)" },
            { to: "/audit", label: "Auditoría", adminOnly: true },
            { to: "/users", label: "Usuarios", adminOnly: true },
            { to: "/settings", label: "Ajustes" },
        ],
    },
];

export function visibleNavGroups(user) {
    const isAdmin = user?.role === "ADMIN";

    return NAV_GROUPS.map((group) => ({
        ...group,
        items: group.items.filter(
            (item) => !item.adminOnly || isAdmin
        ),
    })).filter((group) => group.items.length > 0);
}

export function groupForPath(path, groups = NAV_GROUPS) {
    if (path === "/") {
        return groups[0]?.label ?? "Inicio";
    }

    if (path.startsWith("/account/")) {
        return "Mi cuenta";
    }

    return groups.find((group) =>
        group.items.some(
            (item) => item.to !== "/" && path.startsWith(item.to)
        )
    )?.label ?? groups[0]?.label ?? "Inicio";
}
