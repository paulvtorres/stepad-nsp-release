#!/usr/bin/env bash
# STEPAD: restrict sshd to every address EXCEPT the WAN interface.
# Includes LAN, Tailscale and WireGuard. Regenerated at boot so IP changes
# never leave SSH exposed on the WAN.
set -euo pipefail

CONF_DIR="/etc/ssh/sshd_config.d"
CONF="${CONF_DIR}/stepad-listen.conf"
STEPAD_CFG="/etc/stepad/config.yaml"

mkdir -p "$CONF_DIR"

read_cfg() {
    awk -F': *' -v key="$1" '
        $0 ~ "^[[:space:]]*" key ":" { print $2; exit }
    ' "$STEPAD_CFG" 2>/dev/null | tr -d '"[:space:]\r'
}

wan_if=""
[ -r "$STEPAD_CFG" ] && wan_if="$(read_cfg wan_interface)"

if [ -z "$wan_if" ]; then
    echo "stepad-sshd-listen: no WAN interface in config; keeping current config" >&2
    exit 0
fi

addrs=("127.0.0.1")

# Every global IPv4 address except the WAN interface (LAN, Tailscale, WG).
while read -r addr; do
    [ -n "$addr" ] && addrs+=("$addr")
done < <(
    ip -o -4 addr show scope global 2>/dev/null \
        | awk -v wan="$wan_if" '$2 != wan {print $4}' \
        | cut -d/ -f1
)

# Tailscale may come up slightly later; wait briefly.
ts_ip=""
for _ in $(seq 1 10); do
    ts_ip="$(tailscale ip -4 2>/dev/null | head -1 || true)"
    [ -n "$ts_ip" ] && break
    sleep 1
done
[ -n "$ts_ip" ] && addrs+=("$ts_ip")

if [ "${#addrs[@]}" -le 1 ]; then
    echo "stepad-sshd-listen: no non-WAN address found; keeping current config" >&2
    exit 0
fi

unique=()
for a in "${addrs[@]}"; do
    case " ${unique[*]:-} " in
        *" $a "*) ;;
        *) unique+=("$a") ;;
    esac
done

tmp="$(mktemp)"
{
    echo "# Managed by STEPAD: SSH on every interface except the WAN."
    for a in "${unique[@]}"; do
        echo "ListenAddress $a"
    done
} > "$tmp"

install -m 0644 "$tmp" "$CONF"
rm -f "$tmp"

if ! sshd -t >/dev/null 2>&1; then
    echo "stepad-sshd-listen: invalid sshd config, restoring previous" >&2
    rm -f "$CONF"
    exit 1
fi

systemctl reload ssh 2>/dev/null || systemctl restart ssh 2>/dev/null || true
