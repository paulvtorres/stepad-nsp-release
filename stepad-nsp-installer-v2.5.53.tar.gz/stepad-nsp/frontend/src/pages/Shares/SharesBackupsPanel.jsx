import { useEffect, useState } from "react";

import {
    getShareBackups,
    createShareBackup,
    updateShareBackup,
    deleteShareBackup,
    runShareBackup,
    pruneShareBackup,
    getShareBackupSnapshots,
    getShareBackupSnapshotFiles,
    downloadShareBackup,
} from "../../services/api";

function formatSize(bytes) {
    if (bytes == null || !Number.isFinite(bytes) || bytes < 0) return "—";
    if (bytes === 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const idx = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const value = bytes / 1024 ** idx;
    return `${value.toFixed(value >= 100 || idx === 0 ? 0 : 1)} ${units[idx]}`;
}


export default function ShareBackupsPanel({ sources = [], anchorSource = null }) {
    const anchor = anchorSource || null;

    const [data, setData] = useState(null);   // { installed, store_*, jobs }
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);

    const [form, setForm] = useState({
        name: "",
        source_path: "",
        schedule_hour: "2",
        schedule_minute: "0",
        retention_count: "7",
        prune_free_pct: "15",
    });

    const [snapOpen, setSnapOpen] = useState(null);          // jobId
    const [snapshots, setSnapshots] = useState({});          // jobId -> list
    const [snapLoading, setSnapLoading] = useState(null);    // jobId
    const [browse, setBrowse] = useState(null);              // {jobId, snapshotId, prefix, listing}

    useEffect(() => {
        if (!notice) return undefined;
        const timer = setTimeout(() => setNotice(null), 6000);
        return () => clearTimeout(timer);
    }, [notice]);

    useEffect(() => {
        setForm((f) => ({ ...f, source_path: anchor || "" }));
    }, [anchor]);

    function load() {
        return fetchSilent("/shares/backups")
            .then(setData)
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(() => {
            fetchSilent("/shares/backups")
                .then(setData)
                .catch(() => {});
        }, 30000);
        return () => clearInterval(timer);
    }, []);

    async function handleCreate(event) {
        event.preventDefault();
        const source = (anchor || form.source_path).trim();
        if (!source) {
            setError("Indica la ruta a respaldar (ej. la raíz de una unidad compartida).");
            return;
        }
        const payload = {
            name: form.name.trim() || undefined,
            source_path: source,
            schedule_hour: Number(form.schedule_hour) || 2,
            schedule_minute: Number(form.schedule_minute) || 0,
            retention_count: Number(form.retention_count) || 7,
            prune_free_pct: Number(form.prune_free_pct) || 15,
        };
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await createShareBackup(payload);
            setForm({
                name: "",
                source_path: anchor || "",
                schedule_hour: "2",
                schedule_minute: "0",
                retention_count: "7",
                prune_free_pct: "15",
            });
            await load();
            setNotice("Job de respaldo creado. Usa «Ejecutar ahora» para la primera copia.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleRun(job) {
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await runShareBackup(job.id);
            await load();
            setNotice(`Respaldo «${job.name}» ejecutado.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handlePrune(job) {
        if (!window.confirm(
            `¿Compactar el repositorio de «${job.name}»?\n\n`
            + `Se borran las versiones más antiguas y solo las ${job.retention_count} más recientes quedan.`
        )) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const result = await pruneShareBackup(job.id);
            await load();
            setNotice(result?.message || "Repositorio compactado.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleToggle(job) {
        setBusy(true);
        setError(null);
        try {
            await updateShareBackup(job.id, { enabled: !job.enabled });
            await load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleRemove(job) {
        if (!window.confirm(
            `¿Eliminar el job «${job.name}»?\n\n`
            + "También se borra su repositorio de respaldos (no se puede deshacer)."
        )) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await deleteShareBackup(job.id);
            if (snapOpen === job.id) {
                setSnapOpen(null);
                setBrowse(null);
            }
            await load();
            setNotice(`Job «${job.name}» eliminado.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function openSnapshots(job) {
        const willOpen = snapOpen === job.id;
        setSnapOpen(willOpen ? null : job.id);
        if (willOpen) {
            setBrowse(null);
            return;
        }
        if (snapshots[job.id]) return;
        setSnapLoading(job.id);
        setError(null);
        try {
            const res = await getShareBackupSnapshots(job.id);
            setSnapshots((prev) => ({ ...prev, [job.id]: res?.snapshots || [] }));
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setSnapLoading(null);
        }
    }

    async function browseSnapshot(jobId, snapshotId, prefix) {
        setBrowse(null);
        setError(null);
        try {
            const listing = await getShareBackupSnapshotFiles(jobId, snapshotId, prefix || "");
            setBrowse({ jobId, snapshotId, prefix: prefix || "", listing });
        } catch (err) {
            setError(err.message || String(err));
        }
    }

    async function handleDownloadEntry(jobId, snapshotId, entry) {
        if (busy) return;
        setBusy(true);
        setError(null);
        try {
            const blob = await downloadShareBackup(jobId, snapshotId, entry.path);
            const isDir = entry.type === "dir";
            const name = (entry.path.split("/").pop() || "restauracion").trim() || "restauracion";
            const url = URL.createObjectURL(blob);
            const element = document.createElement("a");
            element.href = url;
            element.download = isDir ? `${name}.tar` : name;
            document.body.appendChild(element);
            element.click();
            element.remove();
            setTimeout(() => URL.revokeObjectURL(url), 4000);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    const jobs = (data?.jobs || []).filter(
        (job) => (anchor ? job.source_path === anchor : true)
    );

    return (
        <section className="sh-bk-panel">
            <div className="sh-bk-head">
                <div>
                    <p className="sh-eyebrow">Protección</p>
                    <h2>{anchor ? `Respaldo programado de «${anchor.split("/").pop() || "esta carpeta"}»` : "Resguardos versionados"}</h2>
                    <p className="sh-lede">
                        {anchor
                            ? "Backup cifrado y versionado de esta carpeta (restic). Programalo, ejecútalo ahora, o vuelve a una versión anterior."
                            : "Copias de seguridad históricas por unidad/carpeta con restic (cifradas, deduplicadas y fuera del alcance de Samba) para poder volver a una versión anterior si un ransomware cifra los archivos."}
                    </p>
                </div>
                {data?.installed && (
                    <div className="sh-bk-meta">
                        <span className="sh-badge">restic OK</span>
                        <span className="sh-muted">{data.store_root}</span>
                        <span className="sh-muted">
                            usado {data.store_used_human} · libre {(data.store_free_pct ?? 100)}%
                        </span>
                    </div>
                )}
            </div>

            {!loading && data?.installed === false && (
                <div className="sh-banner warn">
                    Falta restic en el servidor. Instala: <code>sudo apt-get install -y restic</code>
                </div>
            )}

            <div className="sh-bk-body">
                <div className="sh-bk-form">
                    <h3>{anchor ? "Programar respaldo de esta carpeta" : "Programar nuevo respaldo"}</h3>
                    <p className="sh-part-hint">
                        Un repositorio cifrado por carpeta/unidad. El archivo se puede respaldar desde
                        cualquier ruta local o unidad compartida de red.
                    </p>
                    <form className="sh-bk-form-grid" onSubmit={handleCreate}>
                        <input
                            type="text"
                            list="sh-bk-sources"
                            placeholder="Ruta a respaldar: /mnt/stepad-share/respaldos"
                            value={anchor || form.source_path}
                            disabled={busy || Boolean(anchor)}
                            maxLength={512}
                            onChange={(e) => setForm((f) => ({ ...f, source_path: e.target.value }))}
                        />
                        <datalist id="sh-bk-sources">
                            {(sources || []).map((s) => (
                                <option key={s} value={s}>
                                    {s}
                                </option>
                            ))}
                        </datalist>
                        {!anchor && (
                            <input
                                type="text"
                                placeholder="Nombre (opcional)"
                                value={form.name}
                                disabled={busy}
                                maxLength={64}
                                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                            />
                        )}
                        <div className="sh-bk-form-row">
                            <label>
                                Hora
                                <input
                                    type="number"
                                    min="0"
                                    max="23"
                                    value={form.schedule_hour}
                                    disabled={busy}
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, schedule_hour: e.target.value }))
                                    }
                                />
                            </label>
                            <label>
                                Minuto
                                <input
                                    type="number"
                                    min="0"
                                    max="59"
                                    value={form.schedule_minute}
                                    disabled={busy}
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, schedule_minute: e.target.value }))
                                    }
                                />
                            </label>
                            <label>
                                Conservar
                                <input
                                    type="number"
                                    min="1"
                                    max="365"
                                    value={form.retention_count}
                                    disabled={busy}
                                    title="Número de versiones recientes que se conservan al compactar"
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, retention_count: e.target.value }))
                                    }
                                />
                            </label>
                            <label>
                                Compactar bajo %
                                <input
                                    type="number"
                                    min="5"
                                    max="80"
                                    value={form.prune_free_pct}
                                    disabled={busy}
                                    title="Compacta cuando quede menos de este % de espacio libre"
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, prune_free_pct: e.target.value }))
                                    }
                                />
                            </label>
                        </div>
                        <button type="submit" className="sh-btn primary" disabled={busy}>
                            {anchor ? "Programar respaldo" : "Crear job"}
                        </button>
                    </form>
                </div>

                <div className="sh-bk-list">
                    {loading ? (
                        <p className="sh-loading">Cargando…</p>
                    ) : jobs.length === 0 ? (
                        <p className="sh-empty">
                            {anchor
                                ? "Esta carpeta aún no está respaldada. Programala a la izquierda."
                                : "Aún no hay jobs. Crea uno indicando la raíz de la unidad o carpeta a proteger."}
                        </p>
                    ) : (
                        jobs.map((job) => {
                            const isOpen = snapOpen === job.id;
                            const snaps = snapshots[job.id];
                            return (
                                <article key={job.id} className="sh-bk-job">
                                    <div className="sh-bk-job-head">
                                        <div className="sh-bk-job-title">
                                            <strong>{job.name}</strong>
                                            <code className="sh-inline-code">{job.source_path}</code>
                                            <span className={`sh-badge ${job.enabled ? "green" : "readonly"}`}>
                                                {job.enabled ? "programado" : "apagado"}
                                            </span>
                                            {job.enabled && (
                                                <span className="sh-muted">
                                                    todos los días {String(job.schedule_hour).padStart(2, "0")}:
                                                    {String(job.schedule_minute).padStart(2, "0")} · conserva
                                                    {` ${job.retention_count}`} versiones
                                                </span>
                                            )}
                                        </div>
                                        <div className="sh-bk-job-actions">
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm primary"
                                                disabled={busy}
                                                onClick={() => handleRun(job)}
                                            >
                                                Ejecutar ahora
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => openSnapshots(job)}
                                            >
                                                {isOpen ? "Cerrar versiones" : "Versiones"}
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => handlePrune(job)}
                                                title="Borrar versiones antiguas según retención"
                                            >
                                                Compactar
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => handleToggle(job)}
                                            >
                                                {job.enabled ? "Apagar" : "Activar"}
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm danger"
                                                disabled={busy}
                                                onClick={() => handleRemove(job)}
                                            >
                                                Eliminar
                                            </button>
                                        </div>
                                    </div>
                                    {job.last_result && (
                                        <p className="sh-bk-last">
                                            Último: {job.last_result}
                                            {job.last_bytes ? ` (${formatSize(job.last_bytes)})` : ""}
                                        </p>
                                    )}

                                    {isOpen && (
                                        <div className="sh-bk-snapshots">
                                            {snapLoading === job.id ? (
                                                <p className="sh-loading">Cargando versiones…</p>
                                            ) : !snaps ? null : snaps.length === 0 ? (
                                                <p className="sh-empty">
                                                    Sin versiones todavía. Pulsa «Ejecutar ahora».
                                                </p>
                                            ) : (
                                                <table className="sh-bk-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Fecha</th>
                                                            <th>Snapshot</th>
                                                            <th>Tamaño</th>
                                                            <th>Cambios</th>
                                                            <th />
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {snaps.map((snap) => (
                                                            <tr key={snap.id}>
                                                                <td>{snap.time}</td>
                                                                <td>
                                                                    <code className="sh-muted">
                                                                        {snap.short_id}
                                                                    </code>
                                                                </td>
                                                                <td>{snap.total_bytes_human || "—"}</td>
                                                                <td className="sh-muted">
                                                                    +{snap.files_new ?? "?"} ·
                                                                    ~{snap.files_changed ?? "?"}
                                                                </td>
                                                                <td>
                                                                    <button
                                                                        type="button"
                                                                        className="sh-btn sh-btn-sm"
                                                                        disabled={busy}
                                                                        onClick={() =>
                                                                            browseSnapshot(
                                                                                job.id,
                                                                                snap.id,
                                                                                ""
                                                                            )
                                                                        }
                                                                    >
                                                                        Explorar / descargar
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            )}

                                            {browse
                                                && browse.jobId === job.id
                                                && (
                                                <div className="sh-bk-browse">
                                                    <div className="sh-bk-crumbs">
                                                        <button
                                                            type="button"
                                                            className="sh-btn sh-btn-sm"
                                                            disabled={busy}
                                                            onClick={() =>
                                                                browseSnapshot(
                                                                    job.id,
                                                                    browse.snapshotId,
                                                                    ""
                                                                )
                                                            }
                                                        >
                                                            raíz
                                                        </button>
                                                        {browse.prefix.split("/").filter(Boolean)
                                                            .map((part, idx) => {
                                                                const up = browse.prefix
                                                                    .split("/")
                                                                    .filter(Boolean)
                                                                    .slice(0, idx + 1);
                                                                return (
                                                                    <span key={`${part}-${idx}`}>
                                                                        {" / "}
                                                                        <button
                                                                            type="button"
                                                                            className="sh-btn sh-btn-sm"
                                                                            disabled={busy}
                                                                            onClick={() =>
                                                                                browseSnapshot(
                                                                                    job.id,
                                                                                    browse.snapshotId,
                                                                                    up.join("/")
                                                                                )
                                                                            }
                                                                        >
                                                                            {part}
                                                                        </button>
                                                                    </span>
                                                                );
                                                            })}
                                                    </div>
                                                    {(browse.listing?.directories || []).map(
                                                        (dir) => (
                                                            <div key={dir} className="sh-bk-entry">
                                                                <button
                                                                    type="button"
                                                                    className="sh-bk-dir"
                                                                    disabled={busy}
                                                                    onClick={() =>
                                                                        browseSnapshot(
                                                                            job.id,
                                                                            browse.snapshotId,
                                                                            [browse.prefix, dir].filter(Boolean).join("/")
                                                                        )
                                                                    }
                                                                >
                                                                    📁 {dir}/
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    className="sh-btn sh-btn-sm"
                                                                    disabled={busy}
                                                                    onClick={() =>
                                                                        handleDownloadEntry(
                                                                            job.id,
                                                                            browse.snapshotId,
                                                                            {
                                                                                path: [browse.prefix, dir].filter(Boolean).join("/"),
                                                                                type: "dir",
                                                                            }
                                                                        )
                                                                    }
                                                                >
                                                                    Descargar carpeta (.tar)
                                                                </button>
                                                            </div>
                                                        )
                                                    )}
                                                    {(browse.listing?.files || []).map((file) => (
                                                        <div key={file.path} className="sh-bk-entry">
                                                            <span className="sh-bk-file">
                                                                📄 {file.name}
                                                                <span className="sh-muted">
                                                                    {" "}
                                                                    ({file.size_human})
                                                                </span>
                                                            </span>
                                                            <button
                                                                type="button"
                                                                className="sh-btn sh-btn-sm"
                                                                disabled={busy}
                                                                onClick={() =>
                                                                    handleDownloadEntry(
                                                                        job.id,
                                                                        browse.snapshotId,
                                                                        { path: file.path, type: "file" }
                                                                    )
                                                                }
                                                            >
                                                                Descargar
                                                            </button>
                                                        </div>
                                                    ))}
                                                    {browse.listing
                                                        && (browse.listing.directories || []).length === 0
                                                        && (browse.listing.files || []).length === 0
                                                        && (
                                                        <p className="sh-empty">Carpeta vacía.</p>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </article>
                            );
                        })
                    )}
                </div>
            </div>
        </section>
    );
}