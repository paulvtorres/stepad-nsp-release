import { useEffect, useRef, useState } from "react";

import {
    getWebFileUnits,
    getWebFileList,
    uploadWebFile,
    downloadWebFile,
    mkdirWebFile,
    deleteWebFile,
    moveWebFile,
} from "../../services/api";

function formatSize(bytes) {
    if (bytes == null || !Number.isFinite(bytes) || bytes < 0) return "—";
    if (bytes === 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const idx = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const value = bytes / 1024 ** idx;
    return `${value.toFixed(value >= 100 || idx === 0 ? 0 : 1)} ${units[idx]}`;
}

function resolveUnit(folderPath, units) {
    const path = String(folderPath || "").replace(/\/+$/, "");
    if (!path) return null;
    let best = null;
    let bestLen = -1;
    for (const unit of units || []) {
        const root = String(unit.path || unit.resolved || "").replace(/\/+$/, "");
        if (!root) continue;
        const prefix = path.startsWith(root + "/")
            ? path.slice(root.length + 1)
            : path === root
                ? ""
                : null;
        if (prefix === null) continue;
        if (root.length > bestLen) {
            bestLen = root.length;
            best = { unit, prefix };
        }
    }
    return best;
}


export default function FolderExplorer({ folder, onClose }) {
    const [unitMatch, setUnitMatch] = useState(null);   // {unit, prefix}
    const [crumbs, setCrumbs] = useState([]);           // relative path under the unit
    const [listing, setListing] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);
    const [newDir, setNewDir] = useState(false);
    const [dirDraft, setDirDraft] = useState("");
    const [delEntry, setDelEntry] = useState(null);
    const [renEntry, setRenEntry] = useState(null);     // {entry, draft}
    const [movEntry, setMovEntry] = useState(null);     // {entry, crumbs, dirs}
    const [dropping, setDropping] = useState(false);
    const fileInputRef = useRef(null);
    const dirInputRef = useRef(null);

    // Clamp crumbs so they always start at the folder root.
    const startParts = (unitMatch?.prefix || "").split("/").filter(Boolean);
    const safeCrumbs = crumbs.length >= startParts.length ? crumbs : startParts;
    const prefix = safeCrumbs.join("/");

    useEffect(() => {
        if (!notice) return undefined;
        const timer = setTimeout(() => setNotice(null), 6000);
        return () => clearTimeout(timer);
    }, [notice]);

    useEffect(() => {
        let cancelled = false;
        getWebFileUnits()
            .then((res) => {
                if (cancelled) return;
                const match = resolveUnit(folder.path, res?.units || []);
                setUnitMatch(match);
                if (match) setCrumbs((match.prefix || "").split("/").filter(Boolean));
            })
            .catch((err) => {
                if (!cancelled) setError(err.message || String(err));
            })
            .finally(() => {
                if (!cancelled) setLoading(false);
            });
        return () => { cancelled = true; };
    }, [folder.path]);

    function refresh() {
        if (!unitMatch) return null;
        return getWebFileList(unitMatch.unit.path, safeCrumbs.join("/"))
            .then(setListing)
            .catch((err) => {
                setError(err.message || String(err));
                setListing(null);
            });
    }

    useEffect(() => {
        if (!unitMatch) {
            setListing(null);
            return;
        }
        setLoading(true);
        refresh().finally(() => setLoading(false));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [unitMatch, safeCrumbs.join("/")]);

    function openDir(name) {
        setCrumbs([...safeCrumbs, name]);
    }

    function upDir() {
        setCrumbs(safeCrumbs.slice(0, Math.max(startParts.length, safeCrumbs.length - 1)));
    }

    function toRoot() {
        setCrumbs(startParts);
    }

    async function handleUpload(fileList) {
        if (!fileList || !fileList.length) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const res = await uploadWebFile(unitMatch.unit.path, prefix, Array.from(fileList));
            await refresh();
            setNotice(res.message || `Subido: ${(res.created || []).map((c) => c.name).join(", ")}`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
            if (fileInputRef.current) fileInputRef.current.value = "";
            if (dirInputRef.current) dirInputRef.current.value = "";
        }
    }

    async function handleNewFolder(event) {
        event.preventDefault();
        const name = dirDraft.trim();
        if (!name) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await mkdirWebFile(unitMatch.unit.path, prefix, name);
            setDirDraft("");
            setNewDir(false);
            await refresh();
            setNotice(`Carpeta «${name}» creada.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDownload(entry) {
        setBusy(true);
        setError(null);
        try {
            const path = [prefix, entry.name].filter(Boolean).join("/");
            const blob = await downloadWebFile(unitMatch.unit.path, path);
            const url = URL.createObjectURL(blob);
            const element = document.createElement("a");
            element.href = url;
            element.download = entry.name;
            document.body.appendChild(element);
            element.click();
            element.remove();
            setTimeout(() => URL.revokeObjectURL(url), 4000);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDelete(entry) {
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const path = [prefix, entry.name].filter(Boolean).join("/");
            await deleteWebFile(unitMatch.unit.path, path);
            setDelEntry(null);
            await refresh();
            setNotice(`«${entry.name}» eliminado.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function openRename(entry) {
        setRenEntry({ entry, draft: entry.name });
    }

    async function handleRename(event) {
        event?.preventDefault();
        const name = (renEntry?.draft || "").trim();
        if (!name || !renEntry) return;
        const fromPath = [prefix, renEntry.entry.name].filter(Boolean).join("/");
        const toDir = prefix.split("/").filter(Boolean);
        const toPath = [...toDir, name].join("/");
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await moveWebFile(unitMatch.unit.path, fromPath, toPath);
            setRenEntry(null);
            await refresh();
            setNotice(`«${renEntry.entry.name}» renombrado a «${name}».`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function openMove(entry) {
        setMovEntry({ entry, crumbs: startParts, dirs: null, loading: false });
        loadMoveDirs(startParts);
    }

    function loadMoveDirs(crumbList) {
        setMovEntry((prev) => ({
            ...prev,
            crumbs: crumbList,
            loading: true,
            dirs: null,
        }));
        getWebFileList(unitMatch.unit.path, crumbList.join("/"))
            .then((res) => setMovEntry((prev) => ({ ...prev, dirs: res.directories || [], loading: false })))
            .catch((err) => {
                setError(err.message || String(err));
                setMovEntry((prev) => ({ ...prev, loading: false }));
            });
    }

    async function handleMove() {
        if (!movEntry || !movEntry.entry) return;
        const destPath = [movEntry.crumbs.join("/"), movEntry.entry.name]
            .filter(Boolean)
            .join("/");
        const fromPath = [prefix, movEntry.entry.name].filter(Boolean).join("/");
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await moveWebFile(unitMatch.unit.path, fromPath, destPath);
            setMovEntry(null);
            await refresh();
            setNotice(`«${movEntry.entry.name}» movido a ${destPath || "la raíz de la carpeta"}.`);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    const access = !folder.shared
        ? { text: "Privada", cls: "private" }
        : (folder.groups || []).length === 0
            ? { text: "Compartida", cls: "public" }
            : { text: "Compartida", cls: "private" };

    function onDropGrant(event) {
        event.preventDefault();
        setDropping(false);
        const files = Array.from(event.dataTransfer?.files || []);
        if (files.length && !busy) handleUpload(files);
    }

    return (
        <section className="sh-card sh-explorer">
            <div className="sh-wf-toolbar">
                <button type="button" className="sh-btn" disabled={busy} onClick={onClose}>
                    ← Volver a carpetas
                </button>
                <strong>📁 {folder.name}</strong>
                <span className={`sh-badge ${access.cls}`}>{access.text}</span>
                {folder.unc_path && (
                    <code className="sh-inline-code">{folder.unc_path}</code>
                )}
            </div>

            {loading && !unitMatch ? (
                <p className="sh-loading">Localizando unidad…</p>
            ) : !unitMatch ? (
                <p className="sh-error">
                    {error || "No se encontró una unidad montada para esta carpeta."}
                </p>
            ) : (
                <div
                    className={["sh-wf-drop", dropping ? "active" : ""].filter(Boolean).join(" ")}
                    onDragEnter={(e) => { e.preventDefault(); setDropping(true); }}
                    onDragOver={(e) => { e.preventDefault(); if (!dropping) setDropping(true); }}
                    onDragLeave={(e) => {
                        if (!e.currentTarget.contains(e.relatedTarget)) setDropping(false);
                    }}
                    onDrop={onDropGrant}
                >
                    {dropping && (
                        <div className="sh-wf-drop-hint">
                            Suelta los archivos para subirlos aquí
                        </div>
                    )}

                    <div className="sh-wf-toolbar">
                        <input
                            ref={fileInputRef}
                            type="file"
                            multiple
                            hidden
                            onChange={(e) => handleUpload(e.target.files)}
                        />
                        <input
                            ref={dirInputRef}
                            type="file"
                            multiple
                            hidden
                            {...{ webkitdirectory: "", directory: "" }}
                            onChange={(e) => handleUpload(e.target.files)}
                        />
                        <button
                            type="button"
                            className="sh-btn primary"
                            disabled={busy}
                            onClick={() => fileInputRef.current && fileInputRef.current.click()}
                        >
                            Subir archivos
                        </button>
                        <button
                            type="button"
                            className="sh-btn"
                            disabled={busy}
                            onClick={() => dirInputRef.current && dirInputRef.current.click()}
                        >
                            Subir carpeta
                        </button>
                        <button
                            type="button"
                            className="sh-btn"
                            disabled={busy}
                            onClick={() => setNewDir((v) => !v)}
                        >
                            Nueva carpeta
                        </button>
                        <button
                            type="button"
                            className="sh-btn"
                            disabled={busy}
                            onClick={() => refresh().catch(() => {})}
                        >
                            Recargar
                        </button>
                        <span className="sh-wf-spacer" />
                        {notice && (
                            <span className="sh-wf-notice-inline">
                                {notice}
                            </span>
                        )}
                    </div>
                    {error && <p className="sh-error">{error}</p>}

                    {newDir && (
                        <form className="sh-wf-newdir" onSubmit={handleNewFolder}>
                            <input
                                type="text"
                                placeholder="Nombre de la carpeta"
                                value={dirDraft}
                                maxLength={120}
                                autoFocus
                                onChange={(e) => setDirDraft(e.target.value)}
                            />
                            <button type="submit" className="sh-btn primary" disabled={busy}>
                                Crear
                            </button>
                            <button
                                type="button"
                                className="sh-btn"
                                disabled={busy}
                                onClick={() => setNewDir(false)}
                            >
                                Cancelar
                            </button>
                        </form>
                    )}

                    <div className="sh-wf-crumbs">
                        <button type="button" className="sh-btn sh-btn-sm" disabled={busy} onClick={toRoot}>
                            inicio de la carpeta
                        </button>
                        {safeCrumbs.slice(startParts.length).map((part, idx) => {
                            const up = startParts.concat(safeCrumbs.slice(startParts.length, idx + 1));
                            return (
                                <span key={`${part}-${idx}`}>
                                    {" / "}
                                    <button
                                        type="button"
                                        className="sh-btn sh-btn-sm"
                                        disabled={busy}
                                        onClick={() => setCrumbs(up)}
                                    >
                                        {part}
                                    </button>
                                </span>
                            );
                        })}
                    </div>

                    {loading ? (
                        <p className="sh-loading">Cargando…</p>
                    ) : !listing ? null : (
                        <table className="sh-bk-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Tamaño</th>
                                    <th>Modificado</th>
                                    <th />
                                </tr>
                            </thead>
                            <tbody>
                                {safeCrumbs.length > startParts.length && (
                                    <tr>
                                        <td>
                                            <button type="button" className="sh-bk-dir" disabled={busy} onClick={upDir}>
                                                … (subir)
                                            </button>
                                        </td>
                                        <td className="sh-muted">—</td>
                                        <td className="sh-muted">—</td>
                                        <td />
                                    </tr>
                                )}
                                {(listing.directories || []).map((dir) => (
                                    <tr key={`d-${dir.name}`}>
                                        <td>
                                            <button type="button" className="sh-bk-dir" disabled={busy} onClick={() => openDir(dir.name)}>
                                                📁 {dir.name}/
                                            </button>
                                        </td>
                                        <td className="sh-muted">—</td>
                                        <td className="sh-muted">{dir.mtime || "—"}</td>
                                        <td className="sh-wf-actions">
                                            <button type="button" className="sh-btn sh-btn-sm" disabled={busy} onClick={() => openRename(dir)}>
                                                Renombrar
                                            </button>
                                            <button type="button" className="sh-btn sh-btn-sm" disabled={busy} onClick={() => openMove(dir)}>
                                                Mover
                                            </button>
                                            <button type="button" className="sh-btn sh-btn-sm danger" disabled={busy} onClick={() => setDelEntry(dir)}>
                                                Eliminar
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                {(listing.files || []).map((file) => (
                                    <tr key={`f-${file.name}`}>
                                        <td>📄 {file.name}</td>
                                        <td>{formatSize(file.size)}</td>
                                        <td className="sh-muted">{file.mtime || "—"}</td>
                                        <td className="sh-wf-actions">
                                            <button type="button" className="sh-btn sh-btn-sm" disabled={busy} onClick={() => handleDownload(file)}>
                                                Descargar
                                            </button>
                                            <button type="button" className="sh-btn sh-btn-sm" disabled={busy} onClick={() => openRename(file)}>
                                                Renombrar
                                            </button>
                                            <button type="button" className="sh-btn sh-btn-sm" disabled={busy} onClick={() => openMove(file)}>
                                                Mover
                                            </button>
                                            <button type="button" className="sh-btn sh-btn-sm danger" disabled={busy} onClick={() => setDelEntry(file)}>
                                                Eliminar
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                {(!listing.directories || listing.directories.length === 0)
                                    && (!listing.files || listing.files.length === 0)
                                    && (
                                    <tr>
                                        <td className="sh-empty" colSpan="4">
                                            Carpeta vacía · arrastrá archivos aquí o usá «Subir archivos».
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    )}
                </div>
            )}

            {renEntry && (
                <div className="sh-confirm-overlay" onClick={() => setRenEntry(null)}>
                    <form
                        className="sh-confirm"
                        onClick={(e) => e.stopPropagation()}
                        onSubmit={handleRename}
                    >
                        <h4>Renombrar «{renEntry.entry.name}»</h4>
                        <input
                            type="text"
                            value={renEntry.draft}
                            maxLength={120}
                            autoFocus
                            onChange={(e) => setRenEntry((prev) => ({ ...prev, draft: e.target.value }))}
                        />
                        <div className="sh-wf-actions">
                            <button type="button" className="sh-btn" disabled={busy} onClick={() => setRenEntry(null)}>
                                Cancelar
                            </button>
                            <button type="submit" className="sh-btn primary" disabled={busy || !renEntry.draft.trim()}>
                                Renombrar
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {movEntry && (
                <div className="sh-confirm-overlay">
                    <div className="sh-confirm sh-move-dialog">
                        <h4>Mover «{movEntry.entry.name}»</h4>
                        <p className="sh-part-hint">
                            Elige la carpeta de destino dentro de «{folder.name}».
                        </p>
                        <div className="sh-move-crumbs">
                            <button
                                type="button"
                                className="sh-btn sh-btn-sm"
                                disabled={busy}
                                onClick={() => loadMoveDirs(startParts)}
                            >
                                inicio de la carpeta
                            </button>
                            {movEntry.crumbs.slice(startParts.length).map((part, idx) => (
                                <span key={`${part}-${idx}`}>
                                    {" / "}
                                    <button
                                        type="button"
                                        className="sh-btn sh-btn-sm"
                                        disabled={busy}
                                        onClick={() =>
                                            loadMoveDirs(startParts.concat(movEntry.crumbs.slice(startParts.length, idx + 1)))
                                        }
                                    >
                                        {part}
                                    </button>
                                </span>
                            ))}
                        </div>
                        <div className="sh-move-dirs">
                            {movEntry.loading ? (
                                <p className="sh-loading">Cargando…</p>
                            ) : (
                                (movEntry.dirs || []).map((dir) => (
                                    <button
                                        key={dir.name}
                                        type="button"
                                        className="sh-btn sh-btn-sm"
                                        disabled={busy}
                                        onClick={() => loadMoveDirs([...movEntry.crumbs, dir.name])}
                                    >
                                        📁 {dir.name}/
                                    </button>
                                ))
                            )}
                        </div>
                        <div className="sh-wf-actions">
                            <button type="button" className="sh-btn" disabled={busy} onClick={() => setMovEntry(null)}>
                                Cancelar
                            </button>
                            <button type="button" className="sh-btn primary" disabled={busy} onClick={handleMove}>
                                Mover aquí
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {delEntry && (
                <div className="sh-confirm-overlay" onClick={() => setDelEntry(null)}>
                    <div className="sh-confirm" onClick={(e) => e.stopPropagation()}>
                        <h4>Eliminar</h4>
                        <p>
                            ¿Eliminar <strong>«{delEntry.name}»</strong>
                            {delEntry.type === "dir" ? " (carpeta con su contenido)" : ""}?
                        </p>
                        <div className="sh-wf-actions">
                            <button type="button" className="sh-btn" disabled={busy} onClick={() => setDelEntry(null)}>
                                Cancelar
                            </button>
                            <button type="button" className="sh-btn danger" disabled={busy} onClick={() => handleDelete(delEntry)}>
                                Sí, eliminar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </section>
    );
}