"""
Limpieza programada de reservas DHCP de equipos que llevan
mucho tiempo OFFLINE. Libera IPs del pool sin intervención manual.
"""

from __future__ import annotations

import re
import threading
import time
from datetime import datetime, timedelta

from backend.core.database.session import SessionLocal
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.services.device_classifier import (
    DeviceClassifier,
)
from backend.shared.config.config_service import ConfigService
from backend.shared.logging.logger import logger


DEFAULT_CLEANUP_DAYS = 14
MIN_CLEANUP_DAYS = 3
MAX_CLEANUP_DAYS = 180
DEFAULT_CLEANUP_HOUR = 3
DEFAULT_CLEANUP_MINUTE = 0

_TIME_RE = re.compile(r"^(\d{1,2}):(\d{2})$")


def parse_run_time(value: str | None) -> tuple[int, int]:
    """Acepta 'HH:MM' o 'H:MM'. Devuelve (hour, minute)."""

    if value is None or str(value).strip() == "":
        return DEFAULT_CLEANUP_HOUR, DEFAULT_CLEANUP_MINUTE

    match = _TIME_RE.match(str(value).strip())

    if not match:
        raise ValueError("La hora debe tener formato HH:MM (ej. 03:00).")

    hour = int(match.group(1))
    minute = int(match.group(2))

    if hour < 0 or hour > 23 or minute < 0 or minute > 59:
        raise ValueError("Hora inválida. Use 00:00 a 23:59.")

    return hour, minute


def format_run_time(hour: int, minute: int) -> str:

    return f"{int(hour):02d}:{int(minute):02d}"


class DhcpReservationCleanupService:

    def __init__(self):

        self.config_service = ConfigService()
        self._stop = False
        self._scheduler_thread = None
        self._lock = threading.Lock()

    def get_settings(self) -> dict:

        dhcp = self.config_service.get_dhcp_config() or {}

        days = int(
            dhcp.get(
                "reservation_cleanup_days",
                DEFAULT_CLEANUP_DAYS,
            )
            or DEFAULT_CLEANUP_DAYS
        )

        days = max(MIN_CLEANUP_DAYS, min(MAX_CLEANUP_DAYS, days))

        hour = int(
            dhcp.get(
                "reservation_cleanup_hour",
                DEFAULT_CLEANUP_HOUR,
            )
            if dhcp.get("reservation_cleanup_hour") is not None
            else DEFAULT_CLEANUP_HOUR
        )
        minute = int(
            dhcp.get(
                "reservation_cleanup_minute",
                DEFAULT_CLEANUP_MINUTE,
            )
            if dhcp.get("reservation_cleanup_minute") is not None
            else DEFAULT_CLEANUP_MINUTE
        )

        hour = max(0, min(23, hour))
        minute = max(0, min(59, minute))

        return {
            "enabled": bool(
                dhcp.get("reservation_cleanup_enabled", True)
            ),
            "days": days,
            "run_hour": hour,
            "run_minute": minute,
            "run_time": format_run_time(hour, minute),
            "protect_infrastructure": bool(
                dhcp.get(
                    "reservation_cleanup_protect_infrastructure",
                    True,
                )
            ),
            "last_run_at": dhcp.get("reservation_cleanup_last_run_at"),
            "last_deleted": int(
                dhcp.get("reservation_cleanup_last_deleted", 0) or 0
            ),
        }

    def update_settings(
        self,
        *,
        enabled: bool | None = None,
        days: int | None = None,
        run_time: str | None = None,
        run_hour: int | None = None,
        run_minute: int | None = None,
        protect_infrastructure: bool | None = None,
    ) -> dict:

        dhcp = dict(self.config_service.get_dhcp_config() or {})

        if enabled is not None:
            dhcp["reservation_cleanup_enabled"] = bool(enabled)

        if days is not None:
            days_i = int(days)
            if days_i < MIN_CLEANUP_DAYS or days_i > MAX_CLEANUP_DAYS:
                raise ValueError(
                    f"Los días deben estar entre "
                    f"{MIN_CLEANUP_DAYS} y {MAX_CLEANUP_DAYS}."
                )
            dhcp["reservation_cleanup_days"] = days_i

        if run_time is not None:
            hour, minute = parse_run_time(run_time)
            dhcp["reservation_cleanup_hour"] = hour
            dhcp["reservation_cleanup_minute"] = minute
        else:
            if run_hour is not None:
                hour = int(run_hour)
                if hour < 0 or hour > 23:
                    raise ValueError("La hora debe estar entre 0 y 23.")
                dhcp["reservation_cleanup_hour"] = hour

            if run_minute is not None:
                minute = int(run_minute)
                if minute < 0 or minute > 59:
                    raise ValueError("Los minutos deben estar entre 0 y 59.")
                dhcp["reservation_cleanup_minute"] = minute

        if protect_infrastructure is not None:
            dhcp[
                "reservation_cleanup_protect_infrastructure"
            ] = bool(protect_infrastructure)

        self.config_service.update_section("dhcp", dhcp)

        return self.get_settings()

    def _cutoff(self, days: int) -> datetime:

        return datetime.now() - timedelta(days=days)

    def _is_protected(self, device: NetworkDevice) -> bool:

        return DeviceClassifier.is_infrastructure(device.device_type)

    def _parse_last_run(self, value) -> datetime | None:

        if not value:
            return None

        if isinstance(value, datetime):
            return value

        text = str(value).strip().replace("Z", "")

        try:
            return datetime.fromisoformat(text)
        except ValueError:
            return None

    def is_due(
        self,
        settings: dict | None = None,
        now: datetime | None = None,
    ) -> bool:
        """
        True si la limpieza automática debe correr ahora.
        Usa hora local del servidor (en producción: Ecuador).
        Corre como máximo una vez por día calendario, a partir
        de la hora configurada.
        """

        settings = settings or self.get_settings()
        now = now or datetime.now()

        if not settings.get("enabled"):
            return False

        hour = int(settings.get("run_hour", DEFAULT_CLEANUP_HOUR))
        minute = int(settings.get("run_minute", DEFAULT_CLEANUP_MINUTE))

        if now.hour < hour or (
            now.hour == hour and now.minute < minute
        ):
            return False

        last = self._parse_last_run(settings.get("last_run_at"))

        if last is None:
            return True

        return last.date() < now.date()

    def list_candidates(
        self,
        days: int | None = None,
        protect_infrastructure: bool | None = None,
    ) -> list[dict]:

        settings = self.get_settings()
        days_i = days if days is not None else settings["days"]
        protect = (
            protect_infrastructure
            if protect_infrastructure is not None
            else settings["protect_infrastructure"]
        )

        cutoff = self._cutoff(days_i)

        db = SessionLocal()

        try:

            devices = (
                db.query(NetworkDevice)
                .filter(
                    NetworkDevice.status == "OFFLINE",
                    NetworkDevice.last_seen < cutoff,
                    NetworkDevice.ip_address.isnot(None),
                    NetworkDevice.mac_address.isnot(None),
                )
                .order_by(NetworkDevice.last_seen.asc())
                .all()
            )

            rows = []

            for device in devices:

                if protect and self._is_protected(device):
                    continue

                rows.append(
                    {
                        "id": device.id,
                        "hostname": device.hostname,
                        "mac_address": device.mac_address,
                        "ip_address": device.ip_address,
                        "device_type": device.device_type,
                        "last_seen": (
                            device.last_seen.isoformat()
                            if device.last_seen
                            else None
                        ),
                    }
                )

            return rows

        finally:

            db.close()

    def run_cleanup(
        self,
        *,
        dry_run: bool = False,
        days: int | None = None,
        protect_infrastructure: bool | None = None,
        user_id: int | None = None,
    ) -> dict:

        with self._lock:

            candidates = self.list_candidates(
                days=days,
                protect_infrastructure=protect_infrastructure,
            )

            if dry_run:
                return {
                    "success": True,
                    "dry_run": True,
                    "deleted": 0,
                    "candidates": candidates,
                    "count": len(candidates),
                }

            if not candidates:
                self._record_run(0)
                return {
                    "success": True,
                    "dry_run": False,
                    "deleted": 0,
                    "candidates": [],
                    "count": 0,
                    "message": "No hay reservas vencidas para eliminar.",
                }

            from backend.network.devices.services.device_service import (
                DeviceService,
            )
            from backend.dhcp.services.dhcp_service import DhcpService

            service = DeviceService()
            db = SessionLocal()
            deleted_ids = []
            errors = []

            reason = (
                "Limpieza automática DHCP: sin conexión "
                f"más de {days if days is not None else self.get_settings()['days']} días"
            )

            try:

                for row in candidates:

                    result = service.delete_device(
                        row["id"],
                        db,
                        user_id=user_id,
                        reason=reason,
                        sync_dhcp=False,
                    )

                    if result.get("deleted"):
                        deleted_ids.append(row["id"])
                    else:
                        errors.append(
                            {
                                "id": row["id"],
                                "reason": result.get("reason"),
                            }
                        )

                db.commit()

            except Exception:

                db.rollback()
                raise

            finally:

                db.close()

            dhcp_result = DhcpService().apply_config()

            self._record_run(len(deleted_ids))

            logger.info(
                "DHCP reservation cleanup deleted=%s errors=%s",
                len(deleted_ids),
                len(errors),
            )

            return {
                "success": True,
                "dry_run": False,
                "deleted": len(deleted_ids),
                "deleted_ids": deleted_ids,
                "errors": errors,
                "count": len(candidates),
                "dhcp": dhcp_result,
                "message": (
                    f"Se liberaron {len(deleted_ids)} reserva(s) DHCP."
                ),
            }

    def _record_run(self, deleted: int) -> None:

        dhcp = dict(self.config_service.get_dhcp_config() or {})
        # Hora local del servidor (Ecuador en producción).
        dhcp["reservation_cleanup_last_run_at"] = (
            datetime.now().isoformat(timespec="seconds")
        )
        dhcp["reservation_cleanup_last_deleted"] = int(deleted)
        self.config_service.update_section("dhcp", dhcp)

    def _scheduler_loop(self) -> None:

        logger.info("DHCP reservation cleanup scheduler started.")

        while not self._stop:

            try:

                settings = self.get_settings()

                if self.is_due(settings):

                    result = self.run_cleanup()

                    logger.info(
                        "Scheduled DHCP cleanup at %s: deleted=%s",
                        settings.get("run_time"),
                        result.get("deleted"),
                    )

            except Exception as error:

                logger.exception(
                    "DHCP reservation cleanup scheduler error: %s",
                    error,
                )

            # Revisar cada minuto si llegó la hora programada.
            for _ in range(60):

                if self._stop:
                    return

                time.sleep(1)

    def start_scheduler(self) -> None:

        if self._scheduler_thread is not None:
            return

        self._stop = False
        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="dhcp-reservation-cleanup",
        )
        self._scheduler_thread.start()

    def stop_scheduler(self) -> None:

        self._stop = True
