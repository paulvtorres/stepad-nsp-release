from fastapi import APIRouter, Depends
from fastapi.responses import Response

from sqlalchemy.orm import Session

from backend.api.schemas.shares_request import (
    CreateBackupJobRequest,
    UpdateBackupJobRequest,
)
from backend.core.database.dependency import get_db
from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles
from backend.shares.models.network_share_backup_job import NetworkShareBackupJob
from backend.shares.services.share_backup_service import ShareBackupService


router = APIRouter(
    prefix="/shares/backups",
    tags=["Network Disk Backups"],
)

service = ShareBackupService()


def _get_job(db: Session, job_id: int) -> NetworkShareBackupJob:
    job = db.get(NetworkShareBackupJob, job_id)
    if not job:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
    return job


@router.get("")
def list_backups(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.list_jobs(db)


@router.post("", status_code=201)
def create_backup(
    request: CreateBackupJobRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    job = service.create_job(db, request)
    return service._serialize(job)


@router.put("/{job_id}")
def update_backup(
    job_id: int,
    request: UpdateBackupJobRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    job = service.update_job(db, job_id, request)
    return service._serialize(job)


@router.delete("/{job_id}")
def delete_backup(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    service.delete_job(db, job_id)
    return {"success": True}


@router.post("/{job_id}/run")
def run_backup_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    job = _get_job(db, job_id)
    return service.run_backup(db, job)


@router.get("/{job_id}/snapshots")
def list_snapshots(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    job = _get_job(db, job_id)
    return {"snapshots": service.list_snapshots(db, job)}


@router.get("/{job_id}/snapshots/{snapshot_id}/files")
def list_snapshot_files(
    job_id: int,
    snapshot_id: str,
    prefix: str = "",
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    job = _get_job(db, job_id)
    return service.list_files(db, job, snapshot_id, prefix)


@router.get("/{job_id}/snapshots/{snapshot_id}/download")
def download_snapshot_path(
    job_id: int,
    snapshot_id: str,
    path: str = "/",
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    job = _get_job(db, job_id)
    content, is_dir, path = service.download(db, job, snapshot_id, path)
    name = (path.strip("/").split("/")[-1] or "restauracion").strip()
    if is_dir:
        filename = f"{name or 'carpeta'}.tar"
        media_type = "application/x-tar"
    else:
        filename = name
        media_type = "application/octet-stream"
    return Response(
        content=content,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


@router.post("/{job_id}/prune")
def prune_backups(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    job = _get_job(db, job_id)
    return service.prune(db, job)