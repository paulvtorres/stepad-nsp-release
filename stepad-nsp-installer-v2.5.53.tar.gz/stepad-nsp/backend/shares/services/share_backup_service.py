"""
Versioned backups of shared volumes using restic (anti-ransomware).

Each job snapshots one directory (a shared volume mountpoint or folder)
into a dedicated, encrypted and deduplicated restic repository stored in
/var/stepad-restic -- a root-only tree that Samba never exposes:
shares.conf only ever references volume mountpoints under /mnt/stepad-share,
so a SMB client (or ransomware moving through SMB) cannot reach, list or
delete the repositories.

Retention keeps the newest N snapshots; when free space on the backup
partition drops below a threshold, `forget --keep-last N --prune` trims
old versions while preserving recent ones.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc
from backend.shares.models.network_share_backup_job import NetworkShareBackupJob
from backend.shares.models.network_share_folder import NetworkShareFolder

STORAGE_ROOT = Path("/var/stepad-restic")

ENV_FILE = Path("/etc/stepad/stepad.env")

RESTIC_PASSWORD_KEY = "STEPAD_RESTIC_PASSWORD"

POLL_SECONDS = 60

RECONCILE_SECONDS = 300


def _human_bytes(value: int | None) -> str:
    try:
        value = int(value or 0)
    except (TypeError, ValueError):
        value = 0
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024 or unit == "TiB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{int(value)} B"


class ShareBackupService:

    def __init__(self):
        self._stop = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._running_jobs: set[int] = set()
        self._last_reconcile = 0.0

    # ------------------------------------------------------------------
    # restic commands
    # ------------------------------------------------------------------

    def _password(self) -> str:
        try:
            if ENV_FILE.exists():
                for line in ENV_FILE.read_text().splitlines():
                    if line.startswith(RESTIC_PASSWORD_KEY + "="):
                        value = line.split("=", 1)[1].strip().strip('"')
                        if value:
                            return value
        except Exception:
            pass
        import secrets

        key = secrets.token_hex(16)
        try:
            with open(ENV_FILE, "a") as file:
                file.write(f"\n{RESTIC_PASSWORD_KEY}={key}\n")
        except Exception as error:
            logger.warning("Could not persist restic password: %s", error)
        return key

    def _repo_path(self, job: NetworkShareBackupJob) -> Path:
        slug = re.sub(r"[^A-Za-z0-9_\-]+", "-", (job.name or "job")).strip("-") or "job"
        return STORAGE_ROOT / f"job-{job.id}-{slug[:40]}"

    def _env(self) -> dict:
        return {
            **os.environ,
            "RESTIC_PASSWORD": self._password(),
            "LC_ALL": "C",
            "LANG": "C",
        }

    def _restic(self, job: NetworkShareBackupJob, args: list[str], *, timeout: int = 3600) -> subprocess.CompletedProcess:
        command = ["restic", "-r", str(self._repo_path(job)), *args]
        result = subprocess.run(
            command,
            env=self._env(),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result

    def _ensure_repo(self, job: NetworkShareBackupJob, db: Session) -> None:
        repo = self._repo_path(job)
        STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(STORAGE_ROOT, 0o700)
        except Exception:
            pass
        if not repo.exists():
            repo.mkdir(parents=True, exist_ok=True)
            os.chmod(repo, 0o700)
        # A fresh restic repo is initialized lazily on first successful run.
        probe = self._restic(job, ["snapshots", "--json"], timeout=60)
        if probe.returncode != 0:
            init = self._restic(job, ["init"], timeout=120)
            if init.returncode != 0:
                raise HTTPException(
                    status_code=500,
                    detail=f"No se pudo inicializar el repositorio restic: {init.stderr.strip()[:300]}",
                )

    def installed(self) -> bool:
        return bool(shutil.which("restic"))

    # ------------------------------------------------------------------
    # job CRUD + status
    # ------------------------------------------------------------------

    def list_jobs(self, db: Session) -> dict:
        try:
            STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
            os.chmod(STORAGE_ROOT, 0o700)
        except Exception:
            pass
        jobs = db.query(NetworkShareBackupJob).order_by(NetworkShareBackupJob.id).all()

        disk = shutil.disk_usage(STORAGE_ROOT) if STORAGE_ROOT.exists() else None
        repo_bytes = 0
        if STORAGE_ROOT.exists():
            for child in STORAGE_ROOT.iterdir():
                if child.is_dir():
                    try:
                        repo_bytes += sum(
                            p.stat().st_size for p in child.rglob("*") if p.is_file()
                        )
                    except Exception:
                        pass

        return {
            "installed": self.installed(),
            "store_root": str(STORAGE_ROOT),
            "store_used_bytes": repo_bytes,
            "store_used_human": _human_bytes(repo_bytes),
            "store_free_bytes": disk.free if disk else 0,
            "store_free_pct": round(100 * (disk.free / disk.total), 1) if disk and disk.total else 100.0,
            "jobs": [self._serialize(job) for job in jobs],
        }

    def _serialize(self, job: NetworkShareBackupJob) -> dict:
        return {
            "id": job.id,
            "name": job.name,
            "source_path": job.source_path,
            "enabled": job.enabled,
            "schedule_mode": job.schedule_mode,
            "folder_id": job.folder_id,
            "schedule_hour": job.schedule_hour,
            "schedule_minute": job.schedule_minute,
            "interval_minutes": job.interval_minutes,
            "retention_count": job.retention_count,
            "prune_free_pct": job.prune_free_pct,
            "last_backup_at": to_iso_utc(job.last_backup_at),
            "last_result": job.last_result,
            "last_snapshot_id": job.last_snapshot_id,
            "last_bytes": job.last_bytes,
            "next_run": self._next_run(job),
        }

    def _next_run(self, job: NetworkShareBackupJob) -> str | None:
        if not job.enabled:
            return None
        if job.schedule_mode == "interval":
            minutes = max(1, int(job.interval_minutes or 60))
            return f"cada {minutes} min"
        if job.schedule_mode == "on_change":
            return "al modificar archivos"
        return f"{job.schedule_hour:02d}:{job.schedule_minute:02d}"

    def create_job(self, db: Session, data) -> NetworkShareBackupJob:
        source = (data.source_path or "").strip()
        if not source or not Path(source).is_dir():
            raise HTTPException(
                status_code=400,
                detail="La ruta de origen no existe o no es un directorio.",
            )
        job = NetworkShareBackupJob(
            name=(data.name or "").strip() or Path(source).name,
            source_path=source,
            enabled=True,
            schedule_mode=(
                data.schedule_mode
                if getattr(data, "schedule_mode", None) in ("interval", "on_change")
                else "daily"
            ),
            schedule_hour=int(data.schedule_hour) if data.schedule_hour is not None else 2,
            schedule_minute=int(data.schedule_minute) if data.schedule_minute is not None else 0,
            interval_minutes=(
                max(15, int(data.interval_minutes))
                if getattr(data, "schedule_mode", None) == "interval"
                and getattr(data, "interval_minutes", None)
                else None
            ),
            retention_count=max(1, int(data.retention_count or 7)),
            prune_free_pct=max(5, min(80, int(data.prune_free_pct or 15))),
        )
        existing = (
            db.query(NetworkShareBackupJob)
            .filter(NetworkShareBackupJob.name == job.name)
            .first()
        )
        if existing:
            raise HTTPException(status_code=400, detail="Ya existe un respaldo con ese nombre.")
        db.add(job)
        db.commit()
        db.refresh(job)
        return job

    def update_job(self, db: Session, job_id: int, data) -> NetworkShareBackupJob:
        job = db.get(NetworkShareBackupJob, job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if data.name is not None:
            job.name = (data.name or "").strip() or job.name
        if data.source_path is not None:
            source = (data.source_path or "").strip()
            if not source or not Path(source).is_dir():
                raise HTTPException(status_code=400, detail="La ruta de origen no es válida.")
            job.source_path = source
        if data.enabled is not None:
            job.enabled = data.enabled
        if getattr(data, "schedule_mode", None) is not None:
            if data.schedule_mode not in ("daily", "interval", "on_change"):
                raise HTTPException(status_code=400, detail="schedule_mode inválido.")
            job.schedule_mode = data.schedule_mode
        if data.schedule_hour is not None:
            job.schedule_hour = int(data.schedule_hour)
        if data.schedule_minute is not None:
            job.schedule_minute = int(data.schedule_minute)
        if getattr(data, "interval_minutes", None) is not None:
            job.interval_minutes = max(15, int(data.interval_minutes))
        if data.retention_count is not None:
            job.retention_count = max(1, int(data.retention_count))
        if data.prune_free_pct is not None:
            job.prune_free_pct = max(5, min(80, int(data.prune_free_pct)))
        job.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(job)
        return job

    def _delete_repo(self, job: NetworkShareBackupJob) -> None:
        repo = self._repo_path(job)
        if repo.exists():
            try:
                shutil.rmtree(repo)
            except Exception as error:
                logger.warning("Could not remove repo %s: %s", repo, error)

    def delete_job(self, db: Session, job_id: int) -> None:
        job = db.get(NetworkShareBackupJob, job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        name = job.name
        repo = self._repo_path(job)
        db.delete(job)
        db.commit()
        if repo.exists():
            try:
                shutil.rmtree(repo)
            except Exception as error:
                logger.warning("Could not remove repo %s: %s", repo, error)

    # ------------------------------------------------------------------
    # run / snapshots / files / download
    # ------------------------------------------------------------------

    def run_backup(self, db: Session, job: NetworkShareBackupJob) -> dict:
        with self._lock:
            if job.id in self._running_jobs:
                return {
                    "success": False,
                    "message": "El respaldo ya está en ejecución.",
                }
            self._running_jobs.add(job.id)
        try:
            return self._run_backup_locked(db, job)
        finally:
            with self._lock:
                self._running_jobs.discard(job.id)

    def _run_backup_locked(self, db: Session, job: NetworkShareBackupJob) -> dict:
        if not self.installed():
            raise HTTPException(
                status_code=400,
                detail="restic no está instalado. Instala el paquete: apt-get install -y restic",
            )
        source = Path(job.source_path)
        if not source.is_dir():
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            job.last_result = detail[:500]
            job.updated_at = datetime.utcnow()
            db.commit()
            return {"success": False, "message": detail}

        try:
            self._ensure_repo(job, db)
        except HTTPException:
            raise

        args = [
            "backup",
            str(source),
            "--host", "stepad",
            "--tag", f"job:{job.id}",
            "--exclude-caches",
            "--json",
        ]
        result = None
        try:
            result = self._restic(job, args, timeout=7200)
        except subprocess.TimeoutExpired:
            detail = "El respaldo tardó demasiado y se canceló."
            job.last_result = detail
            job.updated_at = datetime.utcnow()
            db.commit()
            return {"success": False, "message": detail}
        except Exception as error:
            detail = f"Error ejecutando restic: {error}"
            job.last_result = detail[:500]
            job.updated_at = datetime.utcnow()
            db.commit()
            return {"success": False, "message": detail}

        if result.returncode != 0:
            detail = f"restic falló: {result.stderr.strip()[:400]}"
            job.last_result = detail
            job.updated_at = datetime.utcnow()
            db.commit()
            return {"success": False, "message": detail}

        snapshot_id = None
        bytes_processed = 0
        for line in (result.stdout or "").splitlines():
            try:
                payload = json.loads(line)
            except Exception:
                continue
            if payload.get("message_type") == "summary":
                snapshot_id = payload.get("snapshot_id")
                bytes_processed = int(payload.get("total_bytes_processed") or 0)
            elif payload.get("message_type") == "snapshot":
                snapshot_id = payload.get("snapshot_id") or payload.get("id") or snapshot_id

        job.last_backup_at = datetime.utcnow()
        job.last_snapshot_id = (snapshot_id or "")[:64]
        job.last_bytes = bytes_processed
        job.last_result = (
            f"OK  snapshot {snapshot_id[:12] if snapshot_id else 'n/a'} "
            f"{_human_bytes(bytes_processed)}"
        )
        job.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(job)

        pruned = self._maybe_prune(db, job)

        return {
            "success": True,
            "snapshot_id": snapshot_id,
            "snapshot_short": snapshot_id[:12] if snapshot_id else None,
            "bytes_processed": bytes_processed,
            "bytes_human": _human_bytes(bytes_processed),
            "pruned": pruned,
        }

    def list_snapshots(self, db: Session, job: NetworkShareBackupJob) -> list[dict]:
        if not self.installed():
            return []
        try:
            self._ensure_repo(job, db)
        except HTTPException:
            return []
        result = self._restic(job, ["snapshots", "--json"], timeout=120)
        if result.returncode != 0:
            return []
        try:
            rows = json.loads(result.stdout or "[]")
        except Exception:
            rows = []
        snapshots = []
        for row in rows:
            summary = row.get("summary") or {}
            snapshots.append({
                "id": row.get("id", ""),
                "short_id": row.get("short_id", ""),
                "time_iso": to_iso_utc(self._parse_restic_time(row.get("time"))),
                "time": (row.get("time") or "")[:19].replace("T", " "),
                "hostname": row.get("hostname"),
                "tags": row.get("tags") or [],
                "paths": row.get("paths") or [],
                "files_new": summary.get("files_new"),
                "files_changed": summary.get("files_changed"),
                "files_unmodified": summary.get("files_unmodified"),
                "total_bytes_processed": summary.get("total_bytes_processed"),
                "total_bytes_human": _human_bytes(summary.get("total_bytes_processed")),
            })
        snapshots.sort(key=lambda s: s.get("time") or "", reverse=True)
        return snapshots

    def _parse_restic_time(self, value) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except Exception:
            try:
                return datetime.fromtimestamp(value)
            except Exception:
                return None

    def is_due(self, job: NetworkShareBackupJob, now: datetime) -> bool:
        if not job.enabled:
            return False
        if job.schedule_mode == "interval":
            # N backups a day -> run every 24h/N (interval_minutes).
            last = job.last_backup_at
            if last is None:
                return True
            interval = max(1, int(job.interval_minutes or 60))
            elapsed = (now - last).total_seconds()
            return elapsed >= interval * 60
        if job.schedule_mode == "on_change":
            # Handled by the change watcher, never by the clock.
            return False
        if now.hour < job.schedule_hour:
            return False
        if now.hour == job.schedule_hour and now.minute < job.schedule_minute:
            return False
        last = job.last_backup_at
        if last is None:
            return True
        return last.date() < now.date()

    def _tree_signature(self, root: Path) -> str | None:
        """Snapshot of (path, mtime, size) so on-change backups can detect edits."""
        try:
            entries = []
            for path in sorted(root.rglob("*")):
                if path.is_dir():
                    continue
                stat = path.stat()
                rel = path.relative_to(root).as_posix()
                entries.append(f"{rel}:{stat.st_mtime_ns}:{stat.st_size}")
            return hashlib.sha256(
                "\n".join(entries).encode("utf-8", "replace")
            ).hexdigest()
        except OSError:
            return None

    def _maybe_run_on_change(self, db: Session, job: NetworkShareBackupJob) -> None:
        """Backup the source only when files changed since the last successful run."""
        if job.schedule_mode != "on_change" or not job.enabled:
            return
        source = Path(job.source_path)
        if not source.is_dir():
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            if job.last_result != detail:
                job.last_result = detail
                job.updated_at = datetime.utcnow()
                db.commit()
            return

        signature = self._tree_signature(source)
        if signature is None:
            return
        if job.change_hash is None:
            # First baseline: we don't run an unsolicited backup, we just
            # record the current state. From the next change on, we back up.
            job.change_hash = signature
            job.updated_at = datetime.utcnow()
            db.commit()
            return
        if signature == job.change_hash:
            return
        try:
            result = self.run_backup(db, job)
            # Refresh the baseline right after a successful run so the same
            # tree is not backed up again on the next tick.
            fresh = self._tree_signature(source)
            if fresh is not None:
                job.change_hash = fresh
                job.updated_at = datetime.utcnow()
                db.commit()
            state = result.get("message", result)
            logger.info("On-change backup %s: %s", job.name, state)
        except HTTPException as error:
            logger.warning(
                "On-change backup %s failed: %s", job.name, error.detail
            )

    def _maybe_prune(self, db: Session, job: NetworkShareBackupJob) -> dict | None:
        if not STORAGE_ROOT.exists():
            return None
        usage = shutil.disk_usage(STORAGE_ROOT)
        if not usage.total:
            return None
        free_pct = 100 * usage.free / usage.total
        if free_pct >= float(job.prune_free_pct or 15):
            return None
        return self.prune(db, job)

    def prune(self, db: Session, job: NetworkShareBackupJob) -> dict:
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        retention = max(1, int(job.retention_count or 7))
        try:
            self._ensure_repo(job, db)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        forget = self._restic(job, ["forget", "--keep-last", str(retention), "--prune"], timeout=7200)
        if forget.returncode != 0:
            logger.error("restic forget/prune failed: %s", forget.stderr)
        usage = shutil.disk_usage(STORAGE_ROOT)
        free_pct = round(100 * usage.free / usage.total, 1) if usage.total else 100.0
        detail = (
            f"Se conservan las {retention} versiones más recientes y se "
            f"compactó el repositorio. Espacio libre: {free_pct}%."
            if forget.returncode == 0
            else f"La limpieza no terminó bien: {forget.stderr.strip()[:300]}"
        )
        job.last_result = detail[:500]
        job.updated_at = datetime.utcnow()
        db.commit()
        return {"success": forget.returncode == 0, "message": detail, "free_pct": free_pct}

    def list_files(self, db: Session, job: NetworkShareBackupJob, snapshot_id: str, prefix: str = "") -> dict:
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job, db)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"restic ls falló: {result.stderr.strip()[:300]}",
            )
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception:
            entries = []

        root = (job.source_path or "/").rstrip("/")
        root_key = root.lstrip("/")
        prefix = (prefix or "").strip("/")
        base = prefix.split("/") if prefix else []
        folders: set[str] = set()
        files: list[dict] = []
        for entry in entries:
            rel = (entry.get("path") or "").lstrip("/")
            if root != "/":
                if rel == root_key:
                    continue
                if not rel.startswith(root_key + "/"):
                    continue
                rel = rel[len(root_key) + 1:]
            if not rel:
                continue
            parts = rel.split("/")
            if len(parts) != len(base) + 1:
                continue
            if parts[:len(base)] != base:
                continue
            item = parts[len(base)]
            full = f"{prefix}/{item}" if prefix else item
            if entry.get("type") == "dir":
                folders.add(item)
            else:
                files.append({
                    "name": item,
                    "path": full,
                    "size": entry.get("size"),
                    "size_human": _human_bytes(entry.get("size")),
                    "type": "file",
                })
            if len(folders) + len(files) > 3000:
                break

        def sort_key(item):
            return (item.get("name") or "").lower()

        return {
            "snapshot": snapshot_id,
            "prefix": prefix,
            "directories": sorted(folders, key=str.lower),
            "files": sorted(files, key=sort_key),
        }

    def _entry_is_dir(self, job: NetworkShareBackupJob, snapshot_id: str, path: str) -> bool:
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            return False
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception:
            return False
        root = (job.source_path or "/").rstrip("/")
        wanted = "/".join([
            seg for seg in [root, path.strip("/")] if seg.strip("/")
        ])
        for entry in entries:
            if (entry.get("path") or "").rstrip("/") == wanted.rstrip("/"):
                return entry.get("type") == "dir"
        return False

    @staticmethod
    def _parse_ndjson(stdout: str) -> list[dict]:
        rows = []
        for line in (stdout or "").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        return rows

    def download(self, db: Session, job: NetworkShareBackupJob, snapshot_id: str, path: str):
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job, db)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        root = (job.source_path or "/").rstrip("/")
        rel = path.strip("/")
        abs_path = f"{root}/{rel}" if rel else root
        is_dir = self._entry_is_dir(job, snapshot_id, path)

        args = ["dump", snapshot_id, abs_path]
        if is_dir:
            args = ["dump", "--archive=tar", snapshot_id, abs_path]

        result = subprocess.run(
            ["restic", "-r", str(self._repo_path(job)), *args],
            env=self._env(),
            capture_output=True,
            timeout=3600,
        )
        if result.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"restic dump falló: {result.stderr.strip()[:300]}",
            )
        return result.stdout, is_dir, path

    # ------------------------------------------------------------------
    # reconciliation (keep the DB and the disk in sync)
    # ------------------------------------------------------------------

    def _reconcile(self, db: Session) -> None:
        """
        Self-healing pass that keeps the backup jobs DB state aligned with
        reality, so a folder deleted/recreated, a volume unmounted for a
        while or a failed deletion never leaves a permanently desynced job:
          1. every active folder policy must have its linked job;
          2. jobs linked to a deleted folder are dropped (row + repository);
             jobs whose source dir is missing are paused, and folder-linked
             jobs are re-enabled automatically when the source comes back;
          3. leftover repositories not referenced by any job are garbage
             collected.
        """
        # 1) Recreate missing folder jobs / disable ones whose unit is not
        #    mounted yet (reuses the same logic as the backup dialog).
        from backend.shares.services.network_share_service import NetworkShareService

        folder_sync = NetworkShareService()
        active = (
            db.query(NetworkShareFolder)
            .filter(NetworkShareFolder.backup_mode != "off")
            .all()
        )
        for folder in active:
            try:
                folder_sync._sync_folder_backup_job(db, folder)
            except HTTPException as error:
                logger.warning("Reconcile folder %s: %s", folder.id, error.detail)
            except Exception:
                logger.exception("Reconcile folder %s failed", folder.id)

        # 2) Drop orphan jobs; pause/re-enable by source availability.
        jobs = db.query(NetworkShareBackupJob).all()
        for job in jobs:
            if (
                job.folder_id is not None
                and db.get(NetworkShareFolder, job.folder_id) is None
            ):
                self.delete_job(db, job.id)
                continue
            self._reconcile_job_source(db, job)

        # 3) Remove repositories that no job references anymore.
        self._gc_orphan_repos(db)

    def _reconcile_job_source(self, db: Session, job: NetworkShareBackupJob) -> None:
        """
        Disable a job whose source directory is not available and re-enable
        folder-linked jobs automatically once it is back.
        """
        source = Path(job.source_path or "")
        now = datetime.utcnow()

        if source.is_dir():
            if not job.enabled and job.folder_id is not None:
                folder = db.get(NetworkShareFolder, job.folder_id)
                if folder is not None and folder.backup_mode != "off":
                    job.enabled = True
                    if job.schedule_mode == "on_change":
                        # Re-baseline after the gap so the next change runs.
                        job.change_hash = None
                    job.updated_at = now
                    db.commit()
            return

        if job.enabled:
            detail = (
                "La ruta de origen no existe. La carpeta o unidad no está "
                "montada. Respaldo en pausa."
            )
            if job.last_result != detail:
                job.last_result = detail[:500]
            job.enabled = False
            job.updated_at = now
            db.commit()

    def _gc_orphan_repos(self, db: Session) -> None:
        """Delete repositories that no longer belong to any backup job."""
        if not STORAGE_ROOT.exists():
            return
        expected = {
            self._repo_path(job)
            for job in db.query(NetworkShareBackupJob).all()
        }
        for child in STORAGE_ROOT.iterdir():
            if not child.is_dir() or child in expected:
                continue
            try:
                shutil.rmtree(child)
                logger.info("Se eliminó un repositorio huérfano: %s", child.name)
            except OSError as error:
                logger.warning(
                    "No se pudo eliminar el repositorio huérfano %s: %s",
                    child,
                    error,
                )

    # ------------------------------------------------------------------
    # scheduler
    # ------------------------------------------------------------------

    def start_scheduler(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop = False
            self._thread = threading.Thread(
                target=self._loop,
                name="share-backup-scheduler",
                daemon=True,
            )
            self._thread.start()
            logger.info("Share backup scheduler started.")

    def stop_scheduler(self) -> None:
        self._stop = True
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=5)
        self._thread = None
        logger.info("Share backup scheduler stopped.")

    def _loop(self) -> None:
        for _ in range(4):
            if self._stop:
                return
            time.sleep(1)
        while not self._stop:
            try:
                self._tick()
            except Exception as error:
                logger.exception("Share backup tick failed: %s", error)
            for _ in range(POLL_SECONDS):
                if self._stop:
                    return
                time.sleep(1)

    def _tick(self) -> None:
        db = SessionLocal()
        try:
            if time.monotonic() - self._last_reconcile >= RECONCILE_SECONDS:
                self._reconcile(db)
                self._last_reconcile = time.monotonic()
            jobs = db.query(NetworkShareBackupJob).all()
            for job in jobs:
                if not job.enabled:
                    continue
                if job.schedule_mode == "on_change":
                    self._maybe_run_on_change(db, job)
                    continue
                if not self.is_due(job, datetime.utcnow()):
                    continue
                try:
                    result = self.run_backup(db, job)
                    logger.info("Scheduled backup %s: %s", job.name, result.get("message", result))
                except HTTPException as error:
                    logger.warning("Scheduled backup %s failed: %s", job.name, error.detail)
        finally:
            db.close()