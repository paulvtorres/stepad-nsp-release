"""
Web file explorer for the protected share storage.

Authenticated admins can browse, upload, download, create folders and
delete files inside the share storage through the NSP web console. Every
path is validated to stay inside the share roots (SHARE_VOLUMES_ROOT and
the registered sharing volumes); system dirs and the restic repository
(/var/stepad-restic) are never reachable.
"""

from __future__ import annotations

import os
import re
import shutil
import time
from pathlib import Path

from fastapi import HTTPException, UploadFile
from sqlalchemy.orm import Session

from backend.core.config.paths import SHARE_VOLUMES_ROOT
from backend.shares.models.network_share_volume import NetworkShareVolume
from backend.shared.logging.logger import logger

_SAFE_SEGMENT = re.compile(r"^[^/\x00]+$")
_UPLOAD_CHUNK = 1024 * 1024
_HIDDEN_ROOTS = {".stepad-restic", ".stepad-backups"}


class WebFileService:

    def list_units(self, db: Session) -> list[dict]:
        units: list[dict] = []
        seen: set[str] = set()

        def add(path: str, label: str, kind: str) -> None:
            root = Path(path)
            try:
                resolved = root.resolve()
                is_dir = root.is_dir()
            except OSError:
                return
            if not is_dir:
                return
            marker = str(resolved)
            if marker in seen:
                return
            seen.add(marker)
            try:
                usage = shutil.disk_usage(resolved)
                free_b = usage.free
                total_b = usage.total
            except OSError:
                free_b = None
                total_b = None
            units.append({
                "path": str(root),
                "resolved": marker,
                "label": label,
                "kind": kind,
                "free_bytes": free_b,
                "total_bytes": total_b,
            })

        if SHARE_VOLUMES_ROOT.exists():
            add(str(SHARE_VOLUMES_ROOT), "Disco compartido", "root")

        volumes = (
            db.query(NetworkShareVolume)
            .filter(NetworkShareVolume.sharing.is_(True))
            .order_by(NetworkShareVolume.name)
            .all()
        )
        for volume in volumes:
            if volume.mountpoint:
                label = volume.name or Path(volume.mountpoint).name
                add(volume.mountpoint, label, "volume")

        if not units:
            raise HTTPException(400, "No hay unidades compartidas montadas.")
        return units

    def _allowed_roots(self, db: Session) -> list[Path]:
        roots: list[Path] = []
        seen: set[str] = set()

        if SHARE_VOLUMES_ROOT.exists():
            try:
                root = SHARE_VOLUMES_ROOT.resolve()
                roots.append(root)
                seen.add(str(root))
            except OSError:
                pass

        volumes = (
            db.query(NetworkShareVolume)
            .filter(NetworkShareVolume.sharing.is_(True))
            .all()
        )
        for volume in volumes:
            if not volume.mountpoint:
                continue
            try:
                exists = Path(volume.mountpoint).is_dir()
                resolved = Path(volume.mountpoint).resolve()
            except OSError:
                continue
            if not exists:
                continue
            marker = str(resolved)
            if marker in seen:
                continue
            roots.append(resolved)
            seen.add(marker)

        if not roots:
            raise HTTPException(400, "No hay unidades compartidas montadas.")
        return roots

    def _resolve_root(self, db: Session, unit: str) -> Path:
        if not unit or not unit.strip():
            raise HTTPException(400, "Indica la unidad.")
        requested = str(Path(unit)).rstrip("/") or "/"
        for root in self._allowed_roots(db):
            if str(root).rstrip("/") == requested:
                return root
        raise HTTPException(400, "Unidad no permitida o no montada.")

    @staticmethod
    def _rel_parts(rel: str) -> list[str]:
        rel = (rel or "").strip("/")
        if not rel:
            return []
        parts = rel.split("/")
        for part in parts:
            if part in ("", ".", "..") or not _SAFE_SEGMENT.match(part):
                raise HTTPException(400, "Ruta no permitida.")
            if part in _HIDDEN_ROOTS:
                raise HTTPException(400, "Ruta no permitida.")
        return parts

    def _path(self, db: Session, unit: str, rel: str, must_exist: bool = True) -> Path:
        root = self._resolve_root(db, unit)
        candidate = root
        for part in self._rel_parts(rel):
            candidate = candidate / part
        try:
            resolved = candidate.resolve()
        except OSError:
            resolved = candidate
        root_resolved = root.resolve()
        try:
            inside = (
                os.path.commonpath([str(root_resolved), str(resolved)])
                == str(root_resolved)
            )
        except ValueError:
            inside = False
        if not inside:
            raise HTTPException(400, "Ruta fuera de la unidad o inválida.")
        if must_exist and not resolved.exists():
            raise HTTPException(400, "No existe.")
        return resolved

    @staticmethod
    def _mtime(path: Path):
        try:
            return time.strftime(
                "%Y-%m-%d %H:%M", time.gmtime(path.stat().st_mtime)
            )
        except OSError:
            return None

    def list_dir(self, db: Session, unit: str, prefix: str = "") -> dict:
        root = self._resolve_root(db, unit)
        target = self._path(db, unit, prefix, must_exist=True)
        if not target.is_dir():
            raise HTTPException(400, "No es una carpeta.")
        directories: list[dict] = []
        files: list[dict] = []
        try:
            entries = sorted(target.iterdir(), key=lambda e: e.name.lower())
        except OSError as exc:
            raise HTTPException(500, f"No se pudo leer la carpeta: {exc}") from exc

        for entry in entries:
            if entry.name in _HIDDEN_ROOTS:
                continue
            try:
                if entry.is_dir():
                    directories.append({
                        "name": entry.name,
                        "type": "dir",
                        "size": None,
                        "mtime": self._mtime(entry),
                    })
                elif entry.is_file():
                    files.append({
                        "name": entry.name,
                        "type": "file",
                        "size": entry.stat().st_size,
                        "mtime": self._mtime(entry),
                    })
            except OSError:
                continue
        return {
            "unit": str(root),
            "prefix": (prefix or "").strip("/"),
            "directories": directories,
            "files": files,
        }

    async def upload(
        self,
        db: Session,
        unit: str,
        dirname: str,
        files: list[UploadFile],
    ) -> dict:
        target = self._path(db, unit, dirname, must_exist=True)
        if not target.is_dir():
            raise HTTPException(400, "El destino no es una carpeta.")
        if not files:
            raise HTTPException(400, "No se recibieron archivos.")

        # Each multipart part may carry a relative path (folder upload):
        # "imagenes/logo.png" -> subdirectories are created automatically.
        created: list[dict] = []
        skipped: list[str] = []
        failed: list[dict] = []

        for upload in files:
            raw_name = upload.filename or ""
            try:
                parts = self._rel_parts(raw_name)
            except HTTPException as exc:
                await upload.close()
                failed.append({"name": raw_name or "(sin nombre)", "error": exc.detail})
                continue
            if not parts:
                await upload.close()
                failed.append({"name": raw_name or "(sin nombre)", "error": "Nombre inválido"})
                continue

            parents = parts[:-1]
            name = parts[-1]
            dest = target
            try:
                for part in parents:
                    dest = dest / part
                    dest.mkdir(parents=True, exist_ok=True)
                final = dest / name
            except OSError as exc:
                await upload.close()
                failed.append({"name": raw_name, "error": f"No se pudo crear la carpeta: {exc}"})
                continue

            if final.exists():
                await upload.close()
                skipped.append(raw_name if len(parents) else name)
                continue

            try:
                with final.open("wb") as out:
                    while True:
                        chunk = await upload.read(_UPLOAD_CHUNK)
                        if not chunk:
                            break
                        out.write(chunk)
            except OSError as exc:
                await upload.close()
                failed.append({"name": raw_name, "error": f"No se pudo guardar: {exc}"})
                continue
            await upload.close()
            created.append({
                "name": raw_name if len(parents) else name,
                "size": final.stat().st_size,
                "mtime": self._mtime(final),
            })

        if not created:
            if skipped:
                return {
                    "created": [],
                    "skipped": skipped,
                    "failed": failed,
                    "message": "Archivos ya existentes; nada nuevo para subir.",
                }
            detail = failed[0]["error"] if failed else "Ningún archivo válido para subir."
            raise HTTPException(400, detail)

        return {
            "created": created,
            "skipped": skipped,
            "failed": failed,
            "message": f"{len(created)} archivo(s) subido(s)"
            + (f", {len(skipped)} ya existían" if skipped else ""),
        }

    def download(self, db: Session, unit: str, path: str) -> Path:
        target = self._path(db, unit, path, must_exist=True)
        if not target.is_file():
            raise HTTPException(400, "Solo se pueden descargar archivos individuales.")
        return target

    def mkdir(self, db: Session, unit: str, dirname: str, name: str) -> dict:
        name = (name or "").strip()
        if not name or name in (".", "..") or not _SAFE_SEGMENT.match(name):
            raise HTTPException(400, "Nombre de carpeta inválido.")
        parent = self._path(db, unit, dirname, must_exist=True)
        if not parent.is_dir():
            raise HTTPException(400, "El destino no es una carpeta.")
        dest = parent / name
        try:
            dest_resolved = dest.resolve()
        except OSError:
            dest_resolved = dest
        root_resolved = self._resolve_root(db, unit).resolve()
        try:
            inside = (
                os.path.commonpath([str(root_resolved), str(dest_resolved)])
                == str(root_resolved)
            )
        except ValueError:
            inside = False
        if not inside:
            raise HTTPException(400, "Ruta fuera de la unidad o inválida.")
        if dest.exists():
            raise HTTPException(409, "Ya existe.")
        try:
            dest.mkdir()
        except OSError as exc:
            raise HTTPException(500, f"No se pudo crear la carpeta: {exc}") from exc
        return {"name": dest.name}

    def move(self, db: Session, unit: str, source: str, dest: str) -> dict:
        root = self._resolve_root(db, unit)
        root_resolved = root.resolve()
        src = self._path(db, unit, source, must_exist=True)
        try:
            src_resolved = src.resolve()
        except OSError:
            src_resolved = src
        if src_resolved == root_resolved:
            raise HTTPException(400, "No se puede mover la unidad.")

        dst_candidate = root
        for part in self._rel_parts(dest):
            dst_candidate = dst_candidate / part
        try:
            dst_resolved = dst_candidate.resolve()
        except OSError:
            dst_resolved = dst_candidate
        try:
            inside = (
                os.path.commonpath([str(root_resolved), str(dst_resolved)])
                == str(root_resolved)
            )
        except ValueError:
            inside = False
        if not inside or dst_resolved == root_resolved:
            raise HTTPException(400, "Ruta de destino fuera de la unidad o inválida.")
        if dst_resolved == src_resolved:
            raise HTTPException(400, "El destino es el mismo elemento.")

        if src.is_dir():
            try:
                dst_resolved.relative_to(src_resolved)
            except ValueError:
                pass
            else:
                raise HTTPException(400, "No se puede mover una carpeta dentro de sí misma.")

        if not dst_candidate.parent.is_dir():
            raise HTTPException(400, "La carpeta de destino no existe.")
        if dst_candidate.exists():
            raise HTTPException(409, f"Ya existe «{dst_candidate.name}» en el destino.")

        try:
            os.rename(src, dst_candidate)
        except OSError as exc:
            raise HTTPException(500, f"No se pudo mover: {exc}") from exc
        return {
            "from": source,
            "to": dest,
            "path": os.path.relpath(str(dst_candidate), str(root_resolved)),
        }

    def remove(self, db: Session, unit: str, path: str) -> dict:
        target = self._path(db, unit, path, must_exist=True)
        root_resolved = self._resolve_root(db, unit).resolve()
        try:
            resolved = target.resolve()
        except OSError:
            resolved = target
        if resolved == root_resolved:
            raise HTTPException(400, "No se puede eliminar la unidad.")
        try:
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
        except OSError as exc:
            raise HTTPException(500, f"No se pudo eliminar: {exc}") from exc
        return {"deleted": target.name}