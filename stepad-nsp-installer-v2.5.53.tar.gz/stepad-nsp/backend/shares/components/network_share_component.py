from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.shares.services.network_share_service import NetworkShareService
from backend.shares.services.share_disk_health_service import (
    share_disk_health_service,
)
from backend.shares.services.share_integrity_watch_service import (
    ShareIntegrityWatchService,
)
from backend.shares.services.share_backup_service import ShareBackupService
from backend.shared.logging.logger import logger


class NetworkShareComponent(BaseComponent):

    name = "network_shares"

    criticality = ComponentCriticality.OPTIONAL

    def __init__(self):
        self.service = NetworkShareService()
        self.integrity_watch = ShareIntegrityWatchService()
        self.backup_scheduler = ShareBackupService()
        self.disk_health = share_disk_health_service

    def start(self):
        logger.info("NetworkShareComponent started.")
        try:
            self.service.ensure_boot()
        except Exception as error:
            logger.error("Network share boot error: %s", error)
        try:
            self.integrity_watch.start_scheduler()
        except Exception as error:
            logger.error("Share integrity watch start error: %s", error)
        try:
            self.backup_scheduler.start_scheduler()
        except Exception as error:
            logger.error("Share backup scheduler start error: %s", error)
        try:
            self.disk_health.start_scheduler()
        except Exception as error:
            logger.error("Share disk health watch start error: %s", error)

    def stop(self):
        try:
            self.integrity_watch.stop_scheduler()
        except Exception as error:
            logger.error("Share integrity watch stop error: %s", error)
        try:
            self.backup_scheduler.stop_scheduler()
        except Exception as error:
            logger.error("Share backup scheduler stop error: %s", error)
        try:
            self.disk_health.stop_scheduler()
        except Exception as error:
            logger.error("Share disk health watch stop error: %s", error)
        logger.info("NetworkShareComponent stopped.")
