"""
Cubre el refactor de "que el módulo de programación quede perfecto":

1. Backoff: un job que falla no se reintenta cada POLL_SECONDS sin
   límite -- espera según FAILURE_BACKOFF_MINUTES antes de volver a
   intentarlo, y el contador de fallos se resetea apenas tiene éxito.
2. Alerta: al llegar a FAILURE_ALERT_THRESHOLD fallos consecutivos se
   crea una alerta BACKUP_FAILING_ALERT (antes solo existía alerta para
   "la carpeta de origen desapareció").
3. Retención real: retention_count se aplica (forget --keep-last) tras
   CADA respaldo exitoso, no solo cuando el disco se queda sin espacio.
4. on_change ya no adelanta su baseline (change_hash) cuando el intento
   de respaldo falla.
"""

import os
import subprocess

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from datetime import datetime, timedelta

from backend.shares.services.share_backup_service import (
    FAILURE_ALERT_THRESHOLD,
    FAILURE_BACKOFF_MINUTES,
    Job,
    ShareBackupService,
    _default_job,
)


def _make_service(tmp_path, monkeypatch, *, schedule_mode="daily"):
    vault = tmp_path / "Respaldo"
    vault.mkdir()
    source = tmp_path / "Compartida"
    source.mkdir()

    record = dict(_default_job())
    record.update({
        "id": 1,
        "name": "job-1",
        "source_path": str(source),
        "schedule_mode": schedule_mode,
    })
    job = Job(record, vault=vault)

    service = ShareBackupService.__new__(ShareBackupService)
    service._stop = False
    service._thread = None
    service._lock = __import__("threading").Lock()
    service._running_jobs = set()
    service._running_since = {}
    service._active_protected_backups = 0
    service._last_reconcile = 0.0

    monkeypatch.setattr(service, "_find_job", lambda job_id: job)
    monkeypatch.setattr(service, "_save_job", lambda j: None)
    monkeypatch.setattr(service, "installed", lambda: True)
    monkeypatch.setattr(service, "_ensure_repo", lambda j: None)
    monkeypatch.setattr(service, "_maybe_prune", lambda j: None)
    monkeypatch.setattr(service, "_enforce_retention_count", lambda j: None)
    monkeypatch.setattr(service, "_is_network_source", lambda s: False)
    monkeypatch.setattr(service, "_raise_failure_alert", lambda j, m: None)

    return service, job


def _fake_restic_ok(*_a, **_k):
    return subprocess.CompletedProcess(
        args=[],
        returncode=0,
        stdout=(
            '{"message_type":"summary","snapshot_id":"abc123",'
            '"total_bytes_processed":100,"total_bytes_added":50}\n'
        ),
        stderr="",
    )


def _fake_restic_fail(*_a, **_k):
    return subprocess.CompletedProcess(
        args=[], returncode=1, stdout="", stderr="repository locked"
    )


# ---------------------------------------------------------------------
# 1. Backoff
# ---------------------------------------------------------------------

def test_is_due_blocks_immediate_retry_after_a_single_failure(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="interval")
    job["interval_minutes"] = 60
    job["consecutive_failures"] = 1
    job["last_attempt_at"] = datetime(2026, 9, 15, 10, 0).isoformat()
    job["last_backup_at"] = datetime(2026, 9, 15, 9, 0).isoformat()  # ya venció

    # Un minuto después del fallo: NO debe reintentar todavía (backoff
    # tras 1 fallo = FAILURE_BACKOFF_MINUTES[0] minutos).
    soon = datetime(2026, 9, 15, 10, 1)
    assert service.is_due(job, soon) is False

    # Pasado el backoff completo, sí debe reintentar.
    later = datetime(2026, 9, 15, 10) + timedelta(minutes=FAILURE_BACKOFF_MINUTES[0] + 1)
    assert service.is_due(job, later) is True


def test_is_due_retries_every_tick_without_any_prior_failure(tmp_path, monkeypatch):
    # Caso normal (sin fallos): el backoff no debe interferir en nada.
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="interval")
    job["interval_minutes"] = 60
    job["last_backup_at"] = datetime(2026, 9, 15, 8, 0).isoformat()

    now = datetime(2026, 9, 15, 9, 1)
    assert service.is_due(job, now) is True


def test_repeated_failures_are_throttled_across_many_ticks(tmp_path, monkeypatch):
    # Reproduce el escenario reportado: un job diario que sigue fallando
    # ya no se reintenta en CADA uno de 30 ticks de 60s -- antes esto
    # daba 30/30 "due"; con backoff debe dar muchos menos.
    #
    # _finish_run() sella last_attempt_at con now_ecuador() (reloj real),
    # así que para simular el paso del tiempo de forma determinística
    # hay que mover ESE reloj junto con el "now" simulado del loop.
    import backend.shares.services.share_backup_service as module

    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_hour"] = 8
    job["schedule_minute"] = 0
    job["last_backup_at"] = datetime(2026, 9, 14, 8, 0).isoformat()

    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    due_count = 0
    base = datetime(2026, 9, 15, 8, 0)
    for minute in range(30):
        now = base + timedelta(minutes=minute)
        monkeypatch.setattr(module, "now_ecuador", lambda now=now: now)
        if service.is_due(job, now):
            due_count += 1
            service.run_backup(1, trigger="scheduled")

    assert due_count < 30
    # Con backoff de 5 min tras el primer fallo, en 30 minutos como mucho
    # debería reintentar unas pocas veces, no cada minuto.
    assert due_count <= 8


def test_consecutive_failures_resets_after_a_success(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)
    service.run_backup(1, trigger="scheduled")
    service.run_backup(1, trigger="scheduled")
    assert job["consecutive_failures"] == 2

    monkeypatch.setattr(service, "_restic", _fake_restic_ok)
    service.run_backup(1, trigger="scheduled")

    assert job["consecutive_failures"] == 0


# ---------------------------------------------------------------------
# 2. Alerta por fallos repetidos
# ---------------------------------------------------------------------

def test_alert_fires_once_consecutive_failures_reach_threshold(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    alerts = []
    monkeypatch.setattr(
        service, "_raise_failure_alert",
        lambda j, m: alerts.append(j.get("consecutive_failures")),
    )

    for _ in range(FAILURE_ALERT_THRESHOLD + 2):
        service.run_backup(1, trigger="scheduled")

    # Se dispara UNA sola vez al cruzar el umbral, no en cada fallo
    # posterior (evita espamear alertas idénticas).
    assert alerts == [FAILURE_ALERT_THRESHOLD]
    assert job["failure_alert_active"] is True


def test_alert_can_fire_again_after_recovering_and_failing_again(
    tmp_path, monkeypatch
):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")

    alerts = []
    monkeypatch.setattr(
        service, "_raise_failure_alert",
        lambda j, m: alerts.append(True),
    )

    monkeypatch.setattr(service, "_restic", _fake_restic_fail)
    for _ in range(FAILURE_ALERT_THRESHOLD):
        service.run_backup(1, trigger="scheduled")
    assert len(alerts) == 1

    monkeypatch.setattr(service, "_restic", _fake_restic_ok)
    service.run_backup(1, trigger="scheduled")
    assert job["failure_alert_active"] is False

    # Forzamos que la próxima corrida no se salte por "sin cambios": lo
    # que se está probando acá es el ciclo de la alerta, no la detección
    # de cambios (ya cubierta en otro archivo de tests).
    job["tree_hash"] = None

    monkeypatch.setattr(service, "_restic", _fake_restic_fail)
    for _ in range(FAILURE_ALERT_THRESHOLD):
        service.run_backup(1, trigger="scheduled")
    assert len(alerts) == 2


def test_no_alert_before_reaching_the_threshold(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    alerts = []
    monkeypatch.setattr(
        service, "_raise_failure_alert", lambda j, m: alerts.append(True)
    )

    for _ in range(FAILURE_ALERT_THRESHOLD - 1):
        service.run_backup(1, trigger="scheduled")

    assert alerts == []


# ---------------------------------------------------------------------
# 3. Retención real (no solo reactiva a espacio en disco)
# ---------------------------------------------------------------------

def test_retention_is_enforced_after_every_successful_backup(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_ok)

    calls = []
    # Sobreescribimos el stub del fixture para contar llamadas reales.
    monkeypatch.setattr(
        service, "_enforce_retention_count", lambda j: calls.append(j.get("id"))
    )

    service.run_backup(1, trigger="scheduled")

    assert calls == [1]


def test_retention_is_not_enforced_when_backup_fails(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    monkeypatch.setattr(service, "_restic", _fake_restic_fail)

    calls = []
    monkeypatch.setattr(
        service, "_enforce_retention_count", lambda j: calls.append(j.get("id"))
    )

    service.run_backup(1, trigger="scheduled")

    assert calls == []


def test_enforce_retention_count_calls_restic_forget_keep_last(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["retention_count"] = 5

    captured = {}

    def fake_restic(j, args, timeout=None):
        captured["args"] = args
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    monkeypatch.setattr(service, "_restic", fake_restic)

    # _make_service() ya stubea _enforce_retention_count como no-op para
    # las pruebas de arriba (que no la ejercitan) -- acá la restauramos
    # para probar la implementación real.
    ShareBackupService._enforce_retention_count(service, job)

    assert captured["args"] == ["forget", "--keep-last", "5"]
    # A propósito SIN --prune: eso lo sigue haciendo _maybe_prune, que es
    # más caro y solo corre cuando el disco realmente se aprieta.
    assert "--prune" not in captured["args"]


# ---------------------------------------------------------------------
# 4. on_change: no adelantar el baseline si el respaldo falló
# ---------------------------------------------------------------------

def test_on_change_baseline_does_not_advance_when_backup_fails(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="on_change")
    job["change_hash"] = "old-hash"

    monkeypatch.setattr(service, "_tree_signature", lambda root: "new-hash")
    monkeypatch.setattr(
        service, "run_backup",
        lambda job_id, trigger="on_change": {"success": False, "message": "boom"},
    )

    service._maybe_run_on_change(job)

    # El baseline sigue siendo el viejo: la próxima corrida debe volver a
    # intentar respaldar este mismo cambio, no darlo por hecho.
    assert job["change_hash"] == "old-hash"


def test_on_change_baseline_advances_when_backup_succeeds(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="on_change")
    job["change_hash"] = "old-hash"

    monkeypatch.setattr(service, "_tree_signature", lambda root: "new-hash")
    monkeypatch.setattr(
        service, "run_backup",
        lambda job_id, trigger="on_change": {"success": True, "message": "OK"},
    )

    service._maybe_run_on_change(job)

    assert job["change_hash"] == "new-hash"



def test_new_daily_job_is_not_due_for_times_already_passed_today(tmp_path, monkeypatch):
    # Job recién creado con horarios que YA pasaron hoy (p. ej. 01:30 y 08:00
    # configurados a las 10:00): no debe dispararse de inmediato.
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00"
    job["last_backup_at"] = None
    assert service.is_due(job, datetime(2026, 9, 15, 10, 0)) is False


def test_new_daily_job_is_due_at_next_scheduled_time(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00"
    job["last_backup_at"] = None
    assert service.is_due(job, datetime(2026, 9, 15, 7, 59)) is False
    assert service.is_due(job, datetime(2026, 9, 15, 8, 0)) is True


def test_new_daily_job_with_no_future_time_today_waits_for_tomorrow(
    tmp_path, monkeypatch,
):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "01:30,08:00"
    job["last_backup_at"] = None
    # 08:01 ya pasó el último horario de hoy -> recién mañana (01:30).
    assert service.is_due(job, datetime(2026, 9, 15, 8, 1)) is False


def test_failed_first_attempt_waits_for_next_scheduled_time(tmp_path, monkeypatch):
    service, job = _make_service(tmp_path, monkeypatch, schedule_mode="daily")
    job["schedule_times"] = "08:00"
    job["history"] = [{"success": False}]
    job["last_backup_at"] = None
    # El intento de 08:00 falló: NO reintenta el mismo día fuera de horario;
    # espera la próxima hora programada (mañana 08:00).
    assert service.is_due(job, datetime(2026, 9, 15, 9, 0)) is False
    assert service.is_due(job, datetime(2026, 9, 16, 8, 0)) is True
