"""
Salud operativa del DHCP (dnsmasq).

Detecta proceso caído o colgado (cola UDP 67 llena / bloqueado en
pipe) y reintenta arrancar. Genera alerta crítica en el panel y, si
hay destinatarios de alertas configurados, un aviso inmediato.
"""

from __future__ import annotations

import re
import subprocess
import time

from sqlalchemy.orm import Session

from backend.alerts.services.alert_service import AlertService
from backend.core.dnsmasq.process_manager import (
    DNSMASQ_BIN,
    dnsmasq_process_manager,
)
from backend.shared.logging.logger import logger


# Cola Recv-Q en bytes. DHCP sano suele estar en 0; si el proceso
# deja de leer el socket (p. ej. bloqueado en logs) la cola crece.
STUCK_RECVQ_BYTES = 8192

# No repetir correo/alerta cada 30s del monitor.
ALERT_COOLDOWN_SECONDS = 1800

_SECONDARY_CACHE = {"checked_at": 0.0, "ip": "", "reachable": None}


_SS_LINE = re.compile(
    r"^(?:UNCONN|UNCONN-P)\s+(\d+)\s+\d+\s+\S+:67\b"
)


def udp67_recv_queue_bytes(ss_output: str | None = None) -> int:
    """Recv-Q de UDP/67 de nuestro dnsmasq. 0 si no escucha."""

    if ss_output is None:

        result = subprocess.run(
            ["ss", "-ulnp"],
            capture_output=True,
            text=True,
        )

        ss_output = result.stdout or ""

    best = 0

    for line in ss_output.splitlines():

        if ":67" not in line:

            continue

        if DNSMASQ_BIN not in line and "dnsmasq" not in line:

            continue

        match = _SS_LINE.search(line.strip())

        if match:

            best = max(best, int(match.group(1)))

    return best


class DhcpHealthService:

    def __init__(self):

        self.alert_service = AlertService()

        self._last_alert_at: float = 0.0
        self._down_since: float | None = None

    def _secondary_status(self) -> dict:

        try:

            from backend.shared.config.config_service import ConfigService

            config = ConfigService().get_dhcp_config() or {}

        except Exception:

            return {"enabled": False, "ip": "", "reachable": None}

        enabled = bool(config.get("secondary_dhcp_enabled"))
        ip = str(config.get("secondary_dhcp_ip") or "").strip()

        if not enabled or not ip:

            return {"enabled": enabled, "ip": ip, "reachable": None}

        now = time.monotonic()

        if (
            _SECONDARY_CACHE["ip"] == ip
            and now - _SECONDARY_CACHE["checked_at"] < 30
        ):

            return {
                "enabled": True,
                "ip": ip,
                "reachable": _SECONDARY_CACHE["reachable"],
            }

        reachable = False

        try:

            result = subprocess.run(
                ["ping", "-c", "1", "-W", "1", ip],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=2,
            )
            reachable = result.returncode == 0

        except (OSError, subprocess.SubprocessError):

            reachable = False

        _SECONDARY_CACHE.update(
            {"checked_at": now, "ip": ip, "reachable": reachable}
        )

        return {"enabled": True, "ip": ip, "reachable": reachable}

    def inspect(self) -> dict:

        status = dnsmasq_process_manager.status()

        recv_q = 0

        if status.get("running"):

            try:

                recv_q = udp67_recv_queue_bytes()

            except Exception as error:

                logger.warning("DHCP health: no se leyó Recv-Q: %s", error)

        stuck = bool(status.get("running") and recv_q >= STUCK_RECVQ_BYTES)

        pool_low = False
        pool_exhausted = False
        conflicts = 0

        try:

            from backend.dhcp.reconciler import get_dhcp_reconciler

            reconciler_status = get_dhcp_reconciler().status()
            pool_low = bool(reconciler_status.get("pool_low"))
            pool_exhausted = bool(reconciler_status.get("pool_exhausted"))
            conflicts = int(reconciler_status.get("conflicts") or 0)
            auto_excluded = set(
                reconciler_status.get("auto_excluded") or []
            )

        except Exception as error:
            logger.debug("dhcp_health_service.inspect: %s", error)

        healthy = bool(status.get("running") and not stuck)
        secondary = self._secondary_status()
        secondary_attention = bool(
            secondary["enabled"]
            and (not secondary["ip"] or secondary["reachable"] is False)
        )
        unmitigated_conflicts = max(0, conflicts - len(auto_excluded))

        if (
            not healthy
            or pool_exhausted
            or unmitigated_conflicts > 0
        ):
            attention_level = "critical"
        elif pool_low or conflicts > 0 or secondary_attention:
            attention_level = "warning"
        else:
            attention_level = "ok"

        return {
            "running": bool(status.get("running")),
            "pid": status.get("pid"),
            "recv_q": recv_q,
            "stuck": stuck,
            # `pool_low` NO afecta a `healthy`: el watchdog no debe
            # reiniciar dnsmasq porque falten direcciones (no lo arregla).
            "pool_low": pool_low,
            "pool_exhausted": pool_exhausted,
            "conflicts": conflicts,
            "conflicts_mitigated": len(auto_excluded),
            "conflicts_attention": unmitigated_conflicts,
            "attention_level": attention_level,
            # El icono del panel usa attention; el watchdog sigue usando
            # healthy para no reiniciar dnsmasq por falta de direcciones.
            "secondary_dhcp_enabled": secondary["enabled"],
            "secondary_dhcp_ip": secondary["ip"],
            "secondary_dhcp_reachable": secondary["reachable"],
            "attention": bool(
                not healthy
                or pool_low
                or pool_exhausted
                or unmitigated_conflicts > 0
                or secondary_attention
            ),
            "healthy": healthy,
        }

    def ensure_healthy(self, db: Session) -> dict:

        snap = self.inspect()

        if snap["healthy"]:

            self._down_since = None

            try:

                self.alert_service.resolve(db, "DHCP_HEALTH")

            except Exception as error:

                logger.debug("DHCP health: no se pudo resolver alerta: %s", error)

            return snap

        if self._down_since is None:

            self._down_since = time.monotonic()

        down_for = time.monotonic() - self._down_since

        if not snap["running"]:

            title = "DHCP caído: los equipos no reciben IP"
            message = (
                "El servicio DHCP (dnsmasq) no está en ejecución. "
                "STEPAD intenta reiniciarlo."
            )
            reason = "down"

        else:

            title = "DHCP colgado: no responde a pedidos de IP"
            message = (
                f"El servidor DHCP está escuchando pero no procesa "
                f"peticiones (cola UDP 67 = {snap['recv_q']} bytes). "
                "STEPAD intenta reiniciarlo."
            )
            reason = "stuck"

        logger.warning("DHCP %s: %s (reintentando)", reason, message)

        from backend.dhcp.services.dhcp_apply import apply_dhcp_change

        restarted = apply_dhcp_change(force=True)

        snap["restart"] = restarted
        snap["reason"] = reason

        # Solo se alerta si sigue fallando DESPUES del reintento: un
        # arranque o un reinicio del servicio deja a dnsmasq unos segundos
        # levantandose y antes generaba una alerta critica falsa.
        snap["after_restart"] = self.inspect()

        # Alerta si sigue caído después del reintento o si lleva más de
        # 45 s sin servicio: un reinicio normal tarda pocos segundos y no
        # debe generar falsos positivos.
        if (not snap["after_restart"]["healthy"]) or down_for >= 45:

            self._raise_alert(db, title, message)

        return snap

    def _raise_alert(self, db: Session, title: str, message: str) -> None:

        now = time.time()

        if now - self._last_alert_at < ALERT_COOLDOWN_SECONDS:

            return

        self._last_alert_at = now

        try:

            self.alert_service.create(
                db,
                alert_type="DHCP_HEALTH",
                severity="critical",
                title=title,
                message=message,
            )

        except Exception as error:

            logger.error("DHCP health: no se creó alerta: %s", error)

        # AlertService ya dispara el correo inmediato para alertas
        # críticas con los destinatarios configurados.

    def _send_email(self, db: Session, title: str, message: str) -> None:

        try:

            from backend.dhcp.services.dhcp_alert_service import (
                DhcpAlertService,
            )

            if not DhcpAlertService().service_email_allowed():

                logger.info(
                    "DHCP health: correo omitido "
                    "(desactivado en Red → DHCP)."
                )

                return

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            html_body = f"""
            <p><strong>{title}</strong></p>
            <p>{message}</p>
            <p>Revise <em>Alertas</em> y <em>Red → DHCP</em> en el panel
            del NSP y que los equipos vuelvan a obtener IP.</p>
            """

            CriticalAlertEmailService().send(
                db,
                title,
                message,
                html_body=html_body,
            )

        except Exception as error:

            logger.warning("DHCP health: no se envió correo: %s", error)
