"""Balanceo de carga y failover multi-WAN.

Soporta:
- ECMP (Equal-Cost Multi-Path) con nftables fibhash
- Failover automatico cuando una WAN cae
- Distribucion por conexion (conntrack sticky)
- Monitoreo de salud de cada WAN

Requisitos: 2+ interfaces con rol WAN configuradas.
"""

import subprocess
import threading
import time

from datetime import datetime
from pathlib import Path

from sqlalchemy.orm import Session

from backend.shared.logging.logger import logger


NFT_TABLE = "stepad"
LB_CHAIN = "load-balance"
HEALTH_CHECK_INTERVAL = 10


class LoadBalancingService:

    def __init__(self):
        self._health = {}  # interface -> {"online": bool, "last_check": float}
        self._lock = threading.Lock()
        self._monitor_thread = None
        self._running = False

    def get_wan_interfaces(self, db: Session) -> list:
        """Interfaces con rol WAN, con IP/gateway reales del sistema.

        La fuente es `InterfaceService` (registro por MAC + estado del
        kernel), no el modelo viejo de la tabla `managed_interfaces`
        (que no tiene name/ip/gateway y rompia la pantalla con 500).
        """
        try:
            from backend.network.interfaces.services.interface_service import (
                InterfaceService,
            )

            interfaces = InterfaceService().list_interfaces(deep=False)

        except Exception as error:

            logger.warning(
                "load_balancing_service.get_wan_interfaces: %s", error
            )

            return []

        result = []

        for iface in interfaces:

            if (getattr(iface, "role", None) or "") != "WAN":

                continue

            result.append({
                "id": iface.id,
                "name": iface.name,
                "ipv4": iface.ip,
                "gateway": (
                    getattr(iface, "gateway", None)
                    or self._gateway_for(iface.name)
                ),
                "online": self._health.get(iface.name, {}).get(
                    "online", bool(iface.link_detected)
                ),
            })

        return sorted(result, key=lambda item: item["name"])

    def configure(self, db: Session, config: dict) -> dict:
        """Configura el balanceo de carga."""
        enabled = config.get("enabled", False)
        mode = config.get("mode", "ecmp")  # ecmp, failover, round-robin
        interfaces = config.get("interfaces", [])

        if not enabled:
            self._remove_rules()
            self._stop_monitor()
            return {"success": True, "message": "Balanceo desactivado"}

        if len(interfaces) < 2:
            return {"success": False, "message": "Se necesitan al menos 2 interfaces WAN"}

        # Configurar ECMP routes
        result = self._configure_ecmp(interfaces, mode)

        if result["success"]:
            self._start_monitor(interfaces)

        return result

    def _configure_ecmp(self, interfaces: list, mode: str) -> dict:
        """Configura rutas ECMP con nftables."""
        try:
            # Crear tabla de routing si no existe
            self._run(["ip", "route", "replace", "default"])

            # Construir ruta ECMP
            if mode == "ecmp":
                nexthops = " ".join([
                    f"nexthop via {iface['gateway']} dev {iface['name']} weight 1"
                    for iface in interfaces
                ])
                cmd = ["ip", "route", "replace", "default"] + nexthops.split()
            elif mode == "failover":
                # Failover: primaria con backup
                primary = interfaces[0]
                backup = interfaces[1]
                cmd = [
                    "ip", "route", "replace", "default",
                    "via", primary["gateway"], "dev", primary["name"],
                    "metric", "100",
                ]
            else:
                return {"success": False, "message": f"Modo no soportado: {mode}"}

            result = self._run(cmd)
            if result.returncode != 0:
                return {"success": False, "error": result.stderr}

            # Configurar nftables para conntrack sticky
            self._apply_nft_rules(interfaces, mode)

            return {"success": True, "mode": mode, "interfaces": len(interfaces)}

        except Exception as exc:
            logger.debug("load_balancing_service._configure_ecmp: %s", exc)
            return {"success": False, "error": str(exc)}

    def _apply_nft_rules(self, interfaces: list, mode: str):
        """Aplica reglas nftables para distribucion de trafico."""
        try:
            # Limpiar cadena anterior
            self._run(["nft", "flush", "chain", "inet", NFT_TABLE, LB_CHAIN])

            if mode == "ecmp" and len(interfaces) >= 2:
                # Usar fibhash para distribuir por conexion
                self._run([
                    "nft", "add", "rule", "inet", NFT_TABLE, "forward",
                    "meta", "oifname", "{", ",".join(i["name"] for i in interfaces), "}",
                    "ct", "state", "new", "counter",
                    "fib", "saddr", "proto", "dscp", "hash",
                ])

        except Exception as exc:
            logger.warning("LoadBalancing: error aplicando nft: %s", exc)

    def _remove_rules(self):
        """Elimina reglas de balanceo."""
        try:
            self._run(["nft", "flush", "chain", "inet", NFT_TABLE, LB_CHAIN])
            # Restaurar ruta default por defecto
            self._run(["ip", "route", "flush", "all", "cached"])
        except Exception as error:
            logger.debug("load_balancing_service._remove_rules: %s", error)
    def _start_monitor(self, interfaces: list):
        """Inicia monitoreo de salud de WANs."""
        if self._monitor_thread and self._monitor_thread.is_alive():
            return

        self._running = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            args=(interfaces,),
            daemon=True,
            name="wan-health-monitor",
        )
        self._monitor_thread.start()

    def _stop_monitor(self):
        self._running = False

    def _monitor_loop(self, interfaces: list):
        """Monitorea salud de interfaces WAN."""
        while self._running:
            for iface in interfaces:
                online = self._check_interface(iface["name"])
                with self._lock:
                    self._health[iface["name"]] = {
                        "online": online,
                        "last_check": time.time(),
                    }
            time.sleep(HEALTH_CHECK_INTERVAL)

    def _gateway_for(self, name: str) -> str | None:

        try:

            out = self._run(
                ["ip", "route", "show", "default", "dev", name]
            ).stdout

            for line in out.splitlines():

                parts = line.split()

                if "via" in parts:

                    return parts[parts.index("via") + 1]

        except Exception as error:

            logger.debug("load_balancing_service._gateway_for: %s", error)

        return None

    def _check_interface(self, name: str) -> bool:
        """Verifica si una interfaz esta online."""
        try:
            result = self._run(["ip", "link", "show", name])
            return "state UP" in result.stdout
        except Exception as error:
            logger.debug("load_balancing_service._check_interface: %s", error)
            return False

    def get_status(self, db: Session) -> dict:
        """Estado actual del balanceo."""
        interfaces = self.get_wan_interfaces(db)
        online_count = sum(1 for i in interfaces if i["online"])

        return {
            "enabled": len(interfaces) >= 2,
            "mode": "ecmp",
            "interfaces": interfaces,
            "online_count": online_count,
            "total_count": len(interfaces),
            "healthy": online_count == len(interfaces),
        }

    def _run(self, cmd: list) -> subprocess.CompletedProcess:
        return subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
        )


load_balancing_service = LoadBalancingService()