from pathlib import Path

from backend.shares.services import share_backup_schedule as cache


def test_mirror_y_lectura(tmp_path):

    path = tmp_path / "schedule.json"

    cache.mirror(path, Path("/mnt/v"), [{"id": 1, "name": "A"}])

    assert cache.jobs_for(path, Path("/mnt/v")) == [{"id": 1, "name": "A"}]

    assert path.stat().st_mode & 0o777 == 0o600


def test_no_guarda_credenciales_smb(tmp_path):

    path = tmp_path / "schedule.json"

    cache.mirror(
        path,
        Path("/mnt/v"),
        [{"id": 1, "smb_user": "u", "smb_password": "p", "name": "A"}],
    )

    job = cache.jobs_for(path, Path("/mnt/v"))[0]

    assert "smb_password" not in job

    assert "smb_user" not in job


def test_acepta_formato_v1(tmp_path):

    path = tmp_path / "schedule.json"

    path.write_text(
        '{"vault": "/mnt/v", "jobs": [{"id": 2}]}',
        encoding="utf-8",
    )

    assert cache.jobs_for(path, Path("/mnt/v")) == [{"id": 2}]


def test_remove_entry(tmp_path):

    path = tmp_path / "schedule.json"

    cache.mirror(path, Path("/mnt/v"), [{"id": 1}])

    cache.remove_entry(path, Path("/mnt/v"))

    assert cache.jobs_for(path, Path("/mnt/v")) is None


def test_ensure_mirror_solo_escribe_si_cambia(tmp_path):

    path = tmp_path / "schedule.json"

    cache.ensure_mirror(path, Path("/mnt/v"), [{"id": 1}])

    mtime = path.stat().st_mtime_ns

    cache.ensure_mirror(path, Path("/mnt/v"), [{"id": 1}])

    assert path.stat().st_mtime_ns == mtime

    cache.ensure_mirror(path, Path("/mnt/v"), [{"id": 3}])

    assert cache.jobs_for(path, Path("/mnt/v")) == [{"id": 3}]
