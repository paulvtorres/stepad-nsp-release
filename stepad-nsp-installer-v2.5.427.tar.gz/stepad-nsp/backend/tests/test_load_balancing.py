from types import SimpleNamespace

import backend.network.interfaces.services.interface_service as iface_module

from backend.network.services.load_balancing_service import (
    LoadBalancingService,
)


def _fake_interfaces():

    return [
        SimpleNamespace(
            id=1, name="enp2s0", role="WAN", ip="192.168.100.11",
            gateway="192.168.100.1", link_detected=True,
        ),
        SimpleNamespace(
            id=2, name="enp3s0", role="LAN", ip="192.168.1.1",
            gateway=None, link_detected=True,
        ),
    ]


def test_wan_interfaces_uses_role_and_live_data(monkeypatch):

    class FakeService:

        def list_interfaces(self, deep=True):

            return _fake_interfaces()

    monkeypatch.setattr(iface_module, "InterfaceService", FakeService)

    items = LoadBalancingService().get_wan_interfaces(None)

    assert items == [{
        "id": 1,
        "name": "enp2s0",
        "ipv4": "192.168.100.11",
        "gateway": "192.168.100.1",
        "online": True,
    }]


def test_status_with_one_wan_is_disabled_and_healthy(monkeypatch):

    class FakeService:

        def list_interfaces(self, deep=True):

            return _fake_interfaces()

    monkeypatch.setattr(iface_module, "InterfaceService", FakeService)

    status = LoadBalancingService().get_status(None)

    assert status["enabled"] is False

    assert status["total_count"] == 1

    assert status["healthy"] is True


def test_no_wan_returns_empty(monkeypatch):

    class FakeService:

        def list_interfaces(self, deep=True):

            return []

    monkeypatch.setattr(iface_module, "InterfaceService", FakeService)

    assert LoadBalancingService().get_wan_interfaces(None) == []
