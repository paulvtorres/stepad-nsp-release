import ipaddress

from sqlalchemy.orm import Session

from backend.core.config.paths import ZONES_DHCP_CONFIG
from backend.core.dnsmasq.process_manager import dnsmasq_process_manager

from backend.network.zones.models.network_zone import NetworkZone
from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)
from backend.network.zones.providers.linux_vlan_provider import (
    LinuxVlanProvider
)

from backend.network.zones.services.zone_interface_resolver import (
    ZoneInterfaceResolver
)

from backend.dns.providers.zone_pdns_provider import ZonePdnsProvider

from backend.firewall.services.time_policy_service import TimePolicyService

from backend.firewall.services.zone_isolation_service import (
    ZoneIsolationService
)

from backend.shared.config.config_service import ConfigService

from backend.shared.logging.logger import logger


class NetworkZoneService:

    def __init__(self):

        self.repository = NetworkZoneRepository()

        self.vlan_provider = LinuxVlanProvider()

        self.resolver = ZoneInterfaceResolver()

        self.time_policy_service = TimePolicyService()

        self.isolation_service = ZoneIsolationService()


    def list_zones(
        self,
        db: Session
    ):

        return self.repository.find_all(db)


    def get_default_zone(
        self,
        db: Session
    ):

        return self.repository.find_default(db)


    def ensure_zone_for_lan(
        self,
        db: Session,
        *,
        mac_address: str,
        interface_name: str,
    ) -> dict:
        """
        After a NIC is assigned as LAN: if this is the first zone in
        the system, create the default zone from the primary DHCP
        segment in config. Additional LAN cards are NOT auto-created
        with a guessed CIDR (admin must choose the real segment) --
        the caller gets needs_zone_setup=True instead.
        """

        mac = (mac_address or "").strip().lower()

        iface = (interface_name or "").strip()

        if not mac or not iface:

            return {
                "created": False,
                "needs_zone_setup": True,
                "message": "Falta MAC o nombre de interfaz para la zona.",
            }

        existing = self.repository.find_by_interface_mac(db, mac)

        if existing:

            return {
                "created": False,
                "needs_zone_setup": False,
                "zone_id": existing.id,
                "zone_name": existing.name,
                "message": f"La zona «{existing.name}» ya usa esta tarjeta.",
            }

        all_zones = self.repository.find_all(db)

        if all_zones:

            return {
                "created": False,
                "needs_zone_setup": True,
                "interface_mac": mac,
                "physical_interface": iface,
                "message": (
                    "Tarjeta LAN lista. Crea una zona eligiendo esta "
                    "tarjeta (o una VLAN) y el segmento CIDR/DHCP."
                ),
            }

        # No zones yet. Only auto-create the default zone when this
        # is the first/only LAN -- otherwise a free 2nd NIC on a box
        # that never created zones would steal the primary DHCP CIDR.
        from backend.network.interfaces.registry.repositories.managed_interface_repository import (
            ManagedInterfaceRepository
        )

        other_lans = [
            entry
            for entry in ManagedInterfaceRepository().find_all(db)
            if (
                entry.role == "LAN"
                and (entry.mac_address or "").lower() != mac
            )
        ]

        if other_lans:

            return {
                "created": False,
                "needs_zone_setup": True,
                "interface_mac": mac,
                "physical_interface": iface,
                "message": (
                    "Hay otra LAN sin zona aún. Crea la zona de esta "
                    "tarjeta con su propio CIDR/DHCP (no se autoasigna "
                    "el segmento principal a una 2.ª tarjeta)."
                ),
            }

        dhcp = ConfigService().get_dhcp_config()

        network = dhcp.get("network") or "192.168.1.0"

        netmask = dhcp.get("netmask") or "255.255.255.0"

        gateway = dhcp.get("gateway") or "192.168.1.1"

        pool_start = dhcp.get("pool_start") or "192.168.1.20"

        pool_end = dhcp.get("pool_end") or "192.168.1.150"

        try:

            prefix = ipaddress.IPv4Network(
                f"{network}/{netmask}",
                strict=False,
            ).prefixlen

            network_cidr = f"{network}/{prefix}"

        except Exception:

            network_cidr = f"{network}/24"

        zone = NetworkZone(
            name="LAN principal",
            description=(
                "Zona creada automáticamente al asignar la primera "
                "tarjeta LAN. Puedes renombrarla o ajustar el segmento."
            ),
            vlan_id=None,
            physical_interface=iface,
            interface_mac=mac,
            network_cidr=network_cidr,
            gateway_ip=gateway,
            dhcp_pool_start=pool_start,
            dhcp_pool_end=pool_end,
            is_default=True,
        )

        saved = self.create_zone(db, zone)

        logger.info(
            f"Auto-created default zone id={saved.id} for LAN "
            f"{iface} ({mac}) cidr={network_cidr}"
        )

        return {
            "created": True,
            "needs_zone_setup": False,
            "zone_id": saved.id,
            "zone_name": saved.name,
            "interface_mac": mac,
            "physical_interface": iface,
            "message": (
                f"Se creó la zona por defecto «{saved.name}» "
                f"({network_cidr}) en esta tarjeta."
            ),
        }


    def create_zone(
        self,
        db: Session,
        zone: NetworkZone
    ):

        if zone.is_default:

            # Only one default zone -- unset any existing one rather
            # than silently allow two, which would make "where do new
            # devices land" ambiguous.
            current_default = self.repository.find_default(db)

            if current_default:

                current_default.is_default = False

                self.repository.update(db, current_default)

        if zone.interface_mac:

            zone.interface_mac = zone.interface_mac.strip().lower()

        saved = self.repository.save(db, zone)

        self.vlan_provider.ensure_zone_interface(saved)

        self._regenerate_zone_dhcp(db)

        pdns = ZonePdnsProvider(saved)

        pdns.bootstrap()

        pdns.start()

        self.time_policy_service.sync_zone(db, saved)

        self.isolation_service.sync(db)

        return saved


    def delete_zone(
        self,
        db: Session,
        zone: NetworkZone
    ):

        pdns = ZonePdnsProvider(zone)

        pdns.stop()

        self.vlan_provider.remove_zone_interface(zone)

        self.repository.delete(db, zone)

        self._regenerate_zone_dhcp(db)

        self.isolation_service.sync(db)


    def update_zone(
        self,
        db: Session,
        zone: NetworkZone,
        request
    ):

        if request.name is not None:

            zone.name = request.name

        if request.description is not None:

            zone.description = request.description

        if request.is_default is not None and request.is_default:

            current_default = self.repository.find_default(db)

            if current_default and current_default.id != zone.id:

                current_default.is_default = False

                self.repository.update(db, current_default)

            zone.is_default = True

        if request.enforce_time_cutoff is not None:

            zone.enforce_time_cutoff = request.enforce_time_cutoff

        if request.time_cutoff_schedule_id is not None:

            zone.time_cutoff_schedule_id = request.time_cutoff_schedule_id

        interface_updated = False

        if request.interface_mac is not None:

            zone.interface_mac = (
                request.interface_mac.strip().lower()
                if request.interface_mac
                else None
            )

            interface_updated = True

        updated = self.repository.update(db, zone)

        self.time_policy_service.sync_zone(db, updated)

        if interface_updated:

            self.vlan_provider.ensure_zone_interface(updated)

        self.isolation_service.sync(db)

        if request.is_default is not None:

            # is_default flipping changes which dhcp-range is left
            # untagged -- the whole zones.conf needs rewriting, not
            # just this one zone's lines.
            self._regenerate_zone_dhcp(db)

        return updated


    def _regenerate_zone_dhcp(
        self,
        db: Session
    ):
        """
        Rewrites ZONES_DHCP_CONFIG from every zone in the DB and
        restarts dnsmasq. One dnsmasq process serves DHCP for every
        zone -- there's no need for a DHCP daemon per zone the way
        there is for DNS (dnsmasq natively handles multiple
        interfaces/ranges in a single config; RPZ does not have an
        equivalent for multi-policy DNS, which is why DNS is split
        into one PowerDNS instance per zone instead).
        """

        zones = self.repository.find_all(db)

        lines = ["# Auto-generated by NetworkZoneService -- do not edit by hand.\n"]

        seen_interfaces = set()

        for zone in zones:

            base_interface = self.resolver.resolve(zone)

            interface_name = (

                f"{base_interface}.{zone.vlan_id}"

                if zone.vlan_id

                else base_interface

            )

            # Every distinct zone interface must be listed so a 2nd/
            # 3rd physical LAN (or VLAN) receives DHCP. Zones that
            # only IP-alias the primary LAN still share that name --
            # seen_interfaces keeps the line unique.
            if interface_name and interface_name not in seen_interfaces:

                lines.append(f"interface={interface_name}")

                seen_interfaces.add(interface_name)

            netmask = str(
                ipaddress.ip_network(zone.network_cidr, strict=False).netmask
            )

            # The default zone's range is intentionally open (no
            # "set:tag," requirement) -- it's the catch-all for any
            # device that hasn't been explicitly reserved into another
            # zone yet, including a phone connecting for the very
            # first time. Every other zone requires its tag so
            # dnsmasq's multinetting doesn't hand its addresses out to
            # devices that were never assigned there.
            tag_prefix = "" if zone.is_default else f"set:zone{zone.id},"

            lines.append(
                f"dhcp-range={tag_prefix}{zone.dhcp_pool_start},{zone.dhcp_pool_end},{netmask},12h"
            )

            if not zone.is_default:

                lines.append(f"dhcp-option=tag:zone{zone.id},3,{zone.gateway_ip}")

                lines.append(f"dhcp-option=tag:zone{zone.id},6,{zone.gateway_ip}")

            else:

                lines.append(f"dhcp-option=3,{zone.gateway_ip}")

                lines.append(f"dhcp-option=6,{zone.gateway_ip}")

            lines.append("")

        ZONES_DHCP_CONFIG.parent.mkdir(parents=True, exist_ok=True)

        ZONES_DHCP_CONFIG.write_text("\n".join(lines) + "\n")

        dnsmasq_process_manager.restart()
