import os
from types import SimpleNamespace

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from backend.dhcp.services.dhcp_pool_stats_service import (
    DhcpPoolStatsService,
    _range_size,
)


def test_range_size():

    assert _range_size("192.168.1.20", "192.168.1.200") == 181
    assert _range_size("192.168.1.10", "192.168.1.19") == 10


def test_pool_stats_counts(monkeypatch):

    store = {
        "dhcp": {
            "gateway": "192.168.1.1",
            "pool_start": "192.168.1.20",
            "pool_end": "192.168.1.29",
            "group_ip_start": "192.168.1.10",
            "group_ip_end": "192.168.1.19",
        }
    }

    devices = [
        SimpleNamespace(
            ip_address="192.168.1.21",
            mac_address="aa:bb:cc:dd:ee:01",
            status="ONLINE",
        ),
        SimpleNamespace(
            ip_address="192.168.1.22",
            mac_address="aa:bb:cc:dd:ee:02",
            status="OFFLINE",
        ),
        SimpleNamespace(
            ip_address="192.168.1.5",
            mac_address="aa:bb:cc:dd:ee:03",
            status="ONLINE",
        ),
    ]

    groups = [
        SimpleNamespace(dns_alias_ip="192.168.1.10"),
        SimpleNamespace(dns_alias_ip="192.168.1.11"),
    ]

    class FakeQuery:
        def __init__(self, rows):
            self.rows = rows

        def filter(self, *args, **kwargs):
            return self

        def all(self):
            return self.rows

    class FakeDb:
        def query(self, model):
            name = getattr(model, "__name__", str(model))
            if "DeviceGroup" in name or "device_group" in str(model):
                return FakeQuery(groups)
            return FakeQuery(devices)

        def close(self):
            return None

    service = DhcpPoolStatsService()
    service.config_service = SimpleNamespace(
        get_dhcp_config=lambda: store["dhcp"]
    )

    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_pool_stats_service.SessionLocal",
        lambda: FakeDb(),
    )

    stats = service.get_stats()

    assert stats["devices"]["total"] == 10
    assert stats["devices"]["online"] == 1
    assert stats["devices"]["offline"] == 1
    assert stats["devices"]["free"] == 8
    assert stats["groups"]["total"] == 10
    assert stats["groups"]["used"] == 2
    assert stats["groups"]["free"] == 8
    assert stats["overall"]["total"] == 20
    assert stats["overall"]["free"] == 16
