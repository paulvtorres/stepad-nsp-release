import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import TopBar from "./TopBar";
import IdleTimeout from "../IdleTimeout";
import OrgSetupBanner from "../OrgSetupBanner";
import { useAuth } from "../../auth/useAuth";
import { NetworkSegmentProvider } from "../../network/NetworkSegmentProvider";
import {
    groupForPath,
    visibleNavGroups,
} from "../../constants/navigation";

function MainLayout() {

    const { user } = useAuth();

    const location = useLocation();

    const [sidebarOpen, setSidebarOpen] = useState(false);

    const navGroups = visibleNavGroups(user);

    useEffect(() => {

        setSidebarOpen(false);

    }, [location.pathname]);

    const [openGroups, setOpenGroups] = useState(
        () => new Set([groupForPath(location.pathname, navGroups)])
    );

    useEffect(() => {

        setOpenGroups((prev) => {
            const next = new Set(prev);
            next.add(groupForPath(location.pathname, navGroups));
            return next;
        });

    }, [location.pathname, user?.role]);

    function toggleGroup(label) {

        setOpenGroups((prev) => {
            const next = new Set(prev);
            if (next.has(label)) {
                next.delete(label);
            } else {
                next.add(label);
            }
            return next;
        });
    }

    return (
        <NetworkSegmentProvider>
        <IdleTimeout>
            <div className="layout">

                <button
                    className={`hamburger ${sidebarOpen ? "open" : ""}`}
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                    aria-label="Abrir menú"
                    type="button"
                >
                    <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                    >
                        <line x1="3" y1="6" x2="21" y2="6" />
                        <line x1="3" y1="12" x2="21" y2="12" />
                        <line x1="3" y1="18" x2="21" y2="18" />
                    </svg>
                </button>

                {
                    sidebarOpen && (
                        <div
                            className="sidebar-backdrop"
                            onClick={() => setSidebarOpen(false)}
                        />
                    )
                }

                <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
                    <div className="sidebar-brand">
                        <h2>STEPAD NSP</h2>
                        <p className="sidebar-tagline">Network Security</p>
                    </div>

                    <nav className="sidebar-nav" aria-label="Menú principal">
                        {navGroups.map((group) => {
                            const isOpen = openGroups.has(group.label);
                            const isSingle = group.items.length === 1;

                            if (isSingle) {
                                const item = group.items[0];

                                return (
                                    <NavLink
                                        key={group.id}
                                        to={item.to}
                                        end={item.end}
                                        className="nav-single"
                                    >
                                        {item.label}
                                    </NavLink>
                                );
                            }

                            return (
                                <div key={group.id} className="nav-group">
                                    <button
                                        className="nav-group-title"
                                        onClick={() => toggleGroup(group.label)}
                                        type="button"
                                        aria-expanded={isOpen}
                                    >
                                        <span>{group.label}</span>
                                        <span className="nav-group-chevron">
                                            {isOpen ? "▾" : "▸"}
                                        </span>
                                    </button>

                                    {
                                        isOpen && (
                                            <div className="nav-group-items">
                                                {group.items.map((item) => (
                                                    <NavLink
                                                        key={item.to}
                                                        to={item.to}
                                                        end={item.end}
                                                    >
                                                        {item.label}
                                                    </NavLink>
                                                ))}
                                            </div>
                                        )
                                    }
                                </div>
                            );
                        })}
                    </nav>
                </aside>

                <div className="main-area">

                    <TopBar />

                    <main className="content">
                        <OrgSetupBanner />
                        <Outlet />
                    </main>

                </div>

            </div>
        </IdleTimeout>
        </NetworkSegmentProvider>
    );
}

export default MainLayout;
