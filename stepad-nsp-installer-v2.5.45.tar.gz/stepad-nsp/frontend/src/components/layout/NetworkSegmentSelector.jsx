import { useNetworkSegment } from "../../network/useNetworkSegment";

import "./NetworkSegmentSelector.css";


function shortMac(mac) {

    if (!mac) {

        return "";

    }

    const parts = mac.toLowerCase().split(":");

    if (parts.length < 2) {

        return mac;

    }

    return parts.slice(-3).join(":");

}


function NetworkSegmentSelector() {

    const {
        lanCards,
        zones,
        selectedLan,
        selectedZones,
        setSelectedMac,
        zoneBelongsToLan,
        loading,
    } = useNetworkSegment();


    if (loading && !lanCards.length) {

        return null;

    }


    if (lanCards.length === 0) {

        return (
            <div className="segment-selector empty" title="Asigna al menos una tarjeta como LAN">
                <span className="segment-selector-label">Red</span>
                <span className="segment-selector-value muted">Sin LAN</span>
            </div>
        );

    }


    if (lanCards.length === 1) {

        const card = lanCards[0];

        const name = card.display_name
            || card.current_name
            || card.last_seen_name
            || "LAN";

        const cidr = selectedZones[0]?.network_cidr;

        return (
            <div
                className="segment-selector single"
                title={`${name} · ${card.mac_address}${cidr ? ` · ${cidr}` : ""}`}
            >
                <span className="segment-selector-label">Red activa</span>
                <span className="segment-selector-value">
                    {name}
                    {cidr ? ` · ${cidr}` : ""}
                </span>
            </div>
        );

    }


    return (
        <label className="segment-selector multi">
            <span className="segment-selector-label">Red / tarjeta</span>
            <select
                className="segment-selector-select"
                value={(selectedLan?.mac_address || "").toLowerCase()}
                onChange={(event) => setSelectedMac(event.target.value)}
                aria-label="Seleccionar tarjeta LAN o segmento"
            >
                {
                    lanCards.map((card) => {

                        const mac = (card.mac_address || "").toLowerCase();

                        const name = card.display_name
                            || card.current_name
                            || card.last_seen_name
                            || "LAN";

                        const cardZones = zones.filter((zone) =>
                            zoneBelongsToLan(zone, card)
                        );

                        const cidrHint = cardZones
                            .map((zone) => zone.network_cidr)
                            .filter(Boolean)
                            .join(", ");

                        return (
                            <option key={mac || card.id} value={mac}>
                                {name}
                                {" · "}
                                {shortMac(mac)}
                                {card.ip_address ? ` · ${card.ip_address}` : ""}
                                {cidrHint ? ` · ${cidrHint}` : ""}
                            </option>
                        );

                    })
                }
            </select>
        </label>
    );

}


export default NetworkSegmentSelector;
