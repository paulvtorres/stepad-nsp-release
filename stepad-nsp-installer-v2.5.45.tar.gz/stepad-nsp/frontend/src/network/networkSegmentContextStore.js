import { createContext } from "react";

export const NetworkSegmentContext = createContext(null);

export const SEGMENT_STORAGE_KEY = "stepad.selectedLanMac";
