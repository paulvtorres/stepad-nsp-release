import {
    useCallback,
    useEffect,
    useMemo,
    useState,
} from "react";

import {
    getRegisteredInterfaces,
    getZones,
} from "../services/api";

import {
    NetworkSegmentContext,
    SEGMENT_STORAGE_KEY,
} from "./networkSegmentContextStore";


function readStoredMac() {

    try {

        return localStorage.getItem(SEGMENT_STORAGE_KEY) || "";

    } catch {

        return "";

    }

}


function zoneBelongsToLan(zone, lan) {

    if (!zone || !lan) {

        return false;

    }

    const zoneMac = (zone.interface_mac || "").trim().toLowerCase();

    const lanMac = (lan.mac_address || "").trim().toLowerCase();

    if (zoneMac && lanMac && zoneMac === lanMac) {

        return true;

    }

    const iface = (
        lan.current_name || lan.last_seen_name || ""
    ).trim().toLowerCase();

    const zoneIface = (zone.physical_interface || "").trim().toLowerCase();

    return Boolean(iface && zoneIface && iface === zoneIface);

}


export function NetworkSegmentProvider({ children }) {

    const [lanCards, setLanCards] = useState([]);

    const [zones, setZones] = useState([]);

    const [selectedMac, setSelectedMacState] = useState(readStoredMac);

    const [loading, setLoading] = useState(true);


    const refresh = useCallback(async () => {

        try {

            const [ifaces, zoneList] = await Promise.all([
                getRegisteredInterfaces(),
                getZones(),
            ]);

            const lans = (ifaces || [])
                .filter((item) => (item.role || "").toUpperCase() === "LAN")
                .sort((a, b) => (a.priority ?? 100) - (b.priority ?? 100));

            setLanCards(lans);

            setZones(zoneList || []);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }, []);


    useEffect(() => {

        refresh();

        const timer = setInterval(refresh, 30000);

        return () => clearInterval(timer);

    }, [refresh]);


    useEffect(() => {

        if (!lanCards.length) {

            return;

        }

        const stillValid = lanCards.some(
            (card) =>
                (card.mac_address || "").toLowerCase() ===
                (selectedMac || "").toLowerCase()
        );

        if (!stillValid) {

            const next = lanCards[0].mac_address || "";

            setSelectedMacState(next);

            try {

                localStorage.setItem(SEGMENT_STORAGE_KEY, next);

            } catch {
                /* ignore */
            }

        }

    }, [lanCards, selectedMac]);


    const setSelectedMac = useCallback((mac) => {

        const value = (mac || "").toLowerCase();

        setSelectedMacState(value);

        try {

            localStorage.setItem(SEGMENT_STORAGE_KEY, value);

        } catch {
            /* ignore */
        }

    }, []);


    const selectedLan = useMemo(() => {

        if (!selectedMac) {

            return lanCards[0] || null;

        }

        return (
            lanCards.find(
                (card) =>
                    (card.mac_address || "").toLowerCase() ===
                    selectedMac.toLowerCase()
            ) || lanCards[0] || null
        );

    }, [lanCards, selectedMac]);


    const selectedZones = useMemo(() => {

        if (!selectedLan) {

            return [];

        }

        return zones.filter((zone) => zoneBelongsToLan(zone, selectedLan));

    }, [zones, selectedLan]);


    const selectedZoneIds = useMemo(
        () => new Set(selectedZones.map((zone) => zone.id)),
        [selectedZones]
    );


    const hostsDefaultZone = useMemo(
        () => selectedZones.some((zone) => zone.is_default),
        [selectedZones]
    );


    const value = useMemo(
        () => ({
            loading,
            lanCards,
            zones,
            selectedMac: selectedLan?.mac_address || "",
            selectedLan,
            selectedZones,
            selectedZoneIds,
            hostsDefaultZone,
            setSelectedMac,
            refresh,
            zoneBelongsToLan,
        }),
        [
            loading,
            lanCards,
            zones,
            selectedLan,
            selectedZones,
            selectedZoneIds,
            hostsDefaultZone,
            setSelectedMac,
            refresh,
        ]
    );


    return (

        <NetworkSegmentContext.Provider value={value}>

            {children}

        </NetworkSegmentContext.Provider>

    );

}
