import { useContext } from "react";

import { NetworkSegmentContext } from "./networkSegmentContextStore";

export function useNetworkSegment() {

    const context = useContext(NetworkSegmentContext);

    if (!context) {

        throw new Error(
            "useNetworkSegment must be used within NetworkSegmentProvider"
        );

    }

    return context;

}
