import { useEffect, useState } from "react";

import { useSearchParams } from "react-router-dom";

import { useAuth } from "../../../auth/useAuth";

import { useNetworkSegment } from "../../../network/useNetworkSegment";

import {
    getZones,
    createZone,
    updateZone,
    deleteZone,
    getSchedules
} from "../../../services/api";

import Schedules from "./components/Schedules";

import "./zones.css";


const emptyForm = {
    name: "",
    description: "",
    link_mode: "nic",
    vlan_id: "",
    physical_interface: "",
    interface_mac: "",
    network_cidr: "",
    gateway_ip: "",
    dhcp_pool_start: "",
    dhcp_pool_end: "",
    is_default: false,
    enforce_time_cutoff: false,
    time_cutoff_schedule_id: ""
};


function Zones() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [searchParams, setSearchParams] = useSearchParams();

    const {
        lanCards,
        selectedLan,
        refresh: refreshSegments,
    } = useNetworkSegment();


    const [zones, setZones] = useState([]);

    const [schedules, setSchedules] = useState([]);

    const [form, setForm] = useState(emptyForm);

    const [showForm, setShowForm] = useState(false);

    const [showSchedules, setShowSchedules] = useState(false);


    useEffect(() => {

        loadZones();

        loadSchedules();

    }, []);


    useEffect(() => {

        const mac = (searchParams.get("mac") || "").toLowerCase();

        const iface = searchParams.get("iface") || "";

        if (!mac && !iface) {

            return;

        }

        const card = lanCards.find(
            (item) => (item.mac_address || "").toLowerCase() === mac
        );

        setForm((current) => ({
            ...current,
            link_mode: "nic",
            interface_mac: mac || current.interface_mac,
            physical_interface:
                iface
                || card?.current_name
                || card?.last_seen_name
                || current.physical_interface,
            name: current.name || (
                card
                    ? `LAN ${card.display_name || card.current_name || card.last_seen_name || ""}`.trim()
                    : current.name
            ),
            description: current.description || (
                "Segmento en tarjeta LAN dedicada. Ajusta CIDR y DHCP "
                + "al router/red que conectaste."
            ),
        }));

        setShowForm(true);

        setSearchParams({}, { replace: true });

    }, [lanCards, searchParams, setSearchParams]);


    async function loadZones() {

        try {

            const data = await getZones();

            setZones(data);

            await refreshSegments();

        } catch (error) {

            console.error(error);

        }

    }


    async function loadSchedules() {

        try {

            const data = await getSchedules();

            setSchedules(data);

        } catch (error) {

            console.error(error);

        }

    }


    function updateField(field, value) {

        setForm((current) => ({ ...current, [field]: value }));

    }


    function applyLanCard(mac) {

        const card = lanCards.find(
            (item) => (item.mac_address || "").toLowerCase() === (mac || "").toLowerCase()
        );

        if (!card) {

            updateField("interface_mac", mac);

            return;

        }

        setForm((current) => ({
            ...current,
            interface_mac: (card.mac_address || "").toLowerCase(),
            physical_interface:
                card.current_name || card.last_seen_name || current.physical_interface,
        }));

    }


    async function handleCreate() {

        if (!form.physical_interface.trim()) {

            alert("Elige una tarjeta LAN (o indica la interfaz física).");

            return;

        }

        if (form.link_mode === "vlan" && !form.vlan_id) {

            alert("Indica el VLAN ID (1–4094) o elige «Tarjeta completa».");

            return;

        }

        try {

            await createZone({
                name: form.name,
                description: form.description || null,
                vlan_id: form.link_mode === "vlan" && form.vlan_id
                    ? Number(form.vlan_id)
                    : null,
                physical_interface: form.physical_interface.trim(),
                interface_mac: form.interface_mac.trim() || null,
                network_cidr: form.network_cidr,
                gateway_ip: form.gateway_ip,
                dhcp_pool_start: form.dhcp_pool_start,
                dhcp_pool_end: form.dhcp_pool_end,
                is_default: form.is_default,
                enforce_time_cutoff: form.enforce_time_cutoff,
                time_cutoff_schedule_id: form.time_cutoff_schedule_id
                    ? Number(form.time_cutoff_schedule_id)
                    : null
            });

            setForm(emptyForm);

            setShowForm(false);

            await loadZones();

        } catch (error) {

            console.error(error);

            alert("No se pudo crear la zona -- revisa la consola.");

        }

    }


    async function handleToggleCutoff(zone) {

        try {

            await updateZone(zone.id, {
                enforce_time_cutoff: !zone.enforce_time_cutoff
            });

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleAssignSchedule(zone, scheduleId) {

        try {

            await updateZone(zone.id, {
                time_cutoff_schedule_id: scheduleId ? Number(scheduleId) : null
            });

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleSetDefault(zone) {

        try {

            await updateZone(zone.id, { is_default: true });

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleDelete(zone) {

        if (!confirm(`¿Eliminar la zona "${zone.name}"? Esto detiene su resolver y su interfaz.`)) {

            return;

        }

        try {

            await deleteZone(zone.id);

            await loadZones();

        } catch (error) {

            console.error(error);

        }

    }


    return (

        <div className="zones-container">

            <div className="zones-header">

                <div>

                    <h2>Zonas de red</h2>

                    <p>
                        Una zona es un segmento interno (CIDR + DHCP + políticas).
                        Puede ocupar una <strong>tarjeta LAN completa</strong> o
                        una <strong>VLAN</strong> sobre una tarjeta. Las pantallas
                        son las mismas: elige la red arriba para administrar cada una.
                        {selectedLan
                            ? ` Ahora estás en el contexto de ${selectedLan.display_name || selectedLan.current_name || selectedLan.last_seen_name || "LAN"}.`
                            : ""}
                    </p>

                </div>

                <div className="zones-header-actions">

                    {
                        isAdmin && (
                            <>
                                <button
                                    className="secondary-button"
                                    onClick={() => setShowSchedules(!showSchedules)}
                                >
                                    {showSchedules ? "Ocultar horarios" : "Gestionar horarios"}
                                </button>

                                <button
                                    className="primary-button"
                                    onClick={() => setShowForm(!showForm)}
                                >
                                    {showForm ? "Cancelar" : "+ Nueva zona"}
                                </button>
                            </>
                        )
                    }

                </div>

            </div>

            {
                showSchedules && <Schedules />
            }

            {
                showForm && (

                    <div className="zone-form">

                        <div className="zone-form-intro">
                            <strong>¿Cómo se conecta esta zona?</strong>
                            <p>
                                Elige libremente el segmento (CIDR, gateway y pool DHCP).
                                Si conectas una tarjeta libre a otro router, usa
                                «Tarjeta completa» con el CIDR de esa red. Si tienes
                                switch administrable, usa «VLAN».
                            </p>
                            <p className="zone-form-warn">
                                No actives DHCP del NSP y del router en el mismo
                                cable/L2 a la vez: deja uno solo repartiendo IPs.
                            </p>
                        </div>

                        <div className="zone-link-modes" role="radiogroup" aria-label="Tipo de enlace">

                            <label className={`zone-link-card ${form.link_mode === "nic" ? "active" : ""}`}>
                                <input
                                    type="radio"
                                    name="link_mode"
                                    checked={form.link_mode === "nic"}
                                    onChange={() => updateField("link_mode", "nic")}
                                />
                                <span className="zone-link-title">Tarjeta completa</span>
                                <span className="zone-link-desc">
                                    Otra NIC LAN física = otro segmento. Ideal para
                                    la tarjeta libre hacia un router con red distinta.
                                </span>
                            </label>

                            <label className={`zone-link-card ${form.link_mode === "vlan" ? "active" : ""}`}>
                                <input
                                    type="radio"
                                    name="link_mode"
                                    checked={form.link_mode === "vlan"}
                                    onChange={() => updateField("link_mode", "vlan")}
                                />
                                <span className="zone-link-title">VLAN (802.1Q)</span>
                                <span className="zone-link-desc">
                                    Varios segmentos en una misma tarjeta vía switch
                                    en modo trunk. Indica el VLAN ID.
                                </span>
                            </label>

                        </div>

                        <div className="zone-form-grid">

                            <label>
                                Nombre
                                <input
                                    type="text"
                                    placeholder="ej. Invitados / Contabilidad / Router 2"
                                    value={form.name}
                                    onChange={(e) => updateField("name", e.target.value)}
                                />
                            </label>

                            <label>
                                Descripción
                                <input
                                    type="text"
                                    placeholder="Para qué sirve este segmento"
                                    value={form.description}
                                    onChange={(e) => updateField("description", e.target.value)}
                                />
                            </label>

                            <label>
                                Tarjeta LAN
                                <select
                                    value={(form.interface_mac || "").toLowerCase()}
                                    onChange={(e) => applyLanCard(e.target.value)}
                                >
                                    <option value="">— Elige una tarjeta LAN —</option>
                                    {
                                        lanCards.map((card) => {
                                            const mac = (card.mac_address || "").toLowerCase();
                                            const label = card.display_name
                                                || card.current_name
                                                || card.last_seen_name
                                                || mac;
                                            return (
                                                <option key={mac || card.id} value={mac}>
                                                    {label}
                                                    {card.ip_address ? ` (${card.ip_address})` : ""}
                                                    {" · "}
                                                    {mac}
                                                </option>
                                            );
                                        })
                                    }
                                </select>
                                <small>
                                    La zona queda ligada a la MAC: si cambias la
                                    tarjeta de puerto, el segmento la sigue.
                                </small>
                            </label>

                            {
                                form.link_mode === "vlan" && (
                                    <label>
                                        VLAN ID
                                        <input
                                            type="number"
                                            min={1}
                                            max={4094}
                                            placeholder="ej. 20"
                                            value={form.vlan_id}
                                            onChange={(e) => updateField("vlan_id", e.target.value)}
                                        />
                                        <small>
                                            El puerto del switch debe ser trunk con este VLAN etiquetado.
                                        </small>
                                    </label>
                                )
                            }

                            <label>
                                Interfaz física (resuelta)
                                <input
                                    type="text"
                                    placeholder="ej. enp3s0"
                                    value={form.physical_interface}
                                    onChange={(e) => updateField("physical_interface", e.target.value)}
                                />
                                <small>
                                    Se rellena al elegir la tarjeta; puedes ajustarla si hace falta.
                                </small>
                            </label>

                            <label>
                                Red (CIDR)
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.50.0/24"
                                    value={form.network_cidr}
                                    onChange={(e) => updateField("network_cidr", e.target.value)}
                                />
                            </label>

                            <label>
                                IP del NSP en esta zona (gateway/DNS)
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.50.1"
                                    value={form.gateway_ip}
                                    onChange={(e) => updateField("gateway_ip", e.target.value)}
                                />
                            </label>

                            <label>
                                Pool DHCP desde
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.50.20"
                                    value={form.dhcp_pool_start}
                                    onChange={(e) => updateField("dhcp_pool_start", e.target.value)}
                                />
                            </label>

                            <label>
                                Pool DHCP hasta
                                <input
                                    type="text"
                                    placeholder="ej. 192.168.50.200"
                                    value={form.dhcp_pool_end}
                                    onChange={(e) => updateField("dhcp_pool_end", e.target.value)}
                                />
                            </label>

                            <label>
                                Horario de corte total (solo si activas el corte abajo)
                                <select
                                    value={form.time_cutoff_schedule_id}
                                    onChange={(e) => updateField("time_cutoff_schedule_id", e.target.value)}
                                >
                                    <option value="">-- Sin horario --</option>
                                    {
                                        schedules.map((schedule) => (
                                            <option key={schedule.id} value={schedule.id}>
                                                {schedule.name || `Horario #${schedule.id}`}
                                            </option>
                                        ))
                                    }
                                </select>
                            </label>

                        </div>

                        <div className="zone-form-checkboxes">

                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    checked={form.is_default}
                                    onChange={(e) => updateField("is_default", e.target.checked)}
                                />
                                Zona por defecto (dispositivos nuevos, celulares incluidos, caen aquí)
                            </label>

                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    checked={form.enforce_time_cutoff}
                                    onChange={(e) => updateField("enforce_time_cutoff", e.target.checked)}
                                />
                                Cortar todo internet fuera del horario (solo equipos de empresa)
                            </label>

                        </div>

                        <button
                            className="primary-button"
                            onClick={handleCreate}
                        >
                            Guardar zona
                        </button>

                    </div>

                )
            }

            <div className="table-card">

                <table className="zones-table">

                    <thead>

                        <tr>
                            <th>Nombre</th>
                            <th>Red</th>
                            <th>Enlace</th>
                            <th>Default</th>
                            <th>Corte por horario</th>
                            <th>Horario asignado</th>
                            <th>Acciones</th>
                        </tr>

                    </thead>

                    <tbody>

                        {
                            zones.map((zone) => (

                                <tr key={zone.id}>

                                    <td>{zone.name}</td>

                                    <td>{zone.network_cidr} ({zone.gateway_ip})</td>

                                    <td>
                                        {
                                            zone.vlan_id
                                                ? `VLAN ${zone.vlan_id}`
                                                : "Tarjeta completa"
                                        }
                                        {
                                            zone.interface_mac
                                                ? ` · ${zone.interface_mac}`
                                                : zone.physical_interface
                                                    ? ` · ${zone.physical_interface}`
                                                    : ""
                                        }
                                    </td>

                                    <td>
                                        {
                                            zone.is_default
                                                ? "✓"
                                                : (
                                                    isAdmin && (
                                                        <button
                                                            className="secondary-button small"
                                                            onClick={() => handleSetDefault(zone)}
                                                        >
                                                            Hacer default
                                                        </button>
                                                    )
                                                )
                                        }
                                    </td>

                                    <td>
                                        {
                                            isAdmin && (
                                                <label className="checkbox-label">
                                                    <input
                                                        type="checkbox"
                                                        checked={zone.enforce_time_cutoff}
                                                        onChange={() => handleToggleCutoff(zone)}
                                                    />
                                                </label>
                                            )
                                        }
                                        {
                                            !isAdmin && (zone.enforce_time_cutoff ? "✓" : "—")
                                        }
                                    </td>

                                    <td>
                                        {
                                            isAdmin ? (
                                                <select
                                                    value={zone.time_cutoff_schedule_id || ""}
                                                    onChange={(e) =>
                                                        handleAssignSchedule(zone, e.target.value)
                                                    }
                                                    disabled={!zone.enforce_time_cutoff}
                                                >
                                                    <option value="">-- Sin horario --</option>
                                                    {
                                                        schedules.map((schedule) => (
                                                            <option key={schedule.id} value={schedule.id}>
                                                                {schedule.name || `Horario #${schedule.id}`}
                                                            </option>
                                                        ))
                                                    }
                                                </select>
                                            ) : (
                                                zone.enforce_time_cutoff
                                                    ? (schedules.find((s) => s.id === zone.time_cutoff_schedule_id)?.name || "Asignado")
                                                    : "—"
                                            )
                                        }
                                    </td>

                                    <td>
                                        {
                                            isAdmin && (
                                                <button
                                                    className="danger-button"
                                                    onClick={() => handleDelete(zone)}
                                                >
                                                    Eliminar
                                                </button>
                                            )
                                        }
                                    </td>

                                </tr>

                            ))
                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}


export default Zones;
