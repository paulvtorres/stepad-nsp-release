import { useEffect, useState } from "react";

import {
    getDhcpCleanupSettings,
    saveDhcpCleanupSettings,
    runDhcpCleanup,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function DhcpCleanupPanel() {

    const [enabled, setEnabled] = useState(false);

    const [days, setDays] = useState(14);

    const [runTime, setRunTime] = useState("03:00");

    const [protectInfrastructure, setProtectInfrastructure] = useState(true);

    const [pending, setPending] = useState([]);

    const [pendingCount, setPendingCount] = useState(0);

    const [lastRunAt, setLastRunAt] = useState(null);

    const [lastDeleted, setLastDeleted] = useState(0);

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpCleanupSettings();

            setEnabled(Boolean(data.enabled));
            setDays(Number(data.days) || 14);
            setRunTime(data.run_time || "03:00");
            setProtectInfrastructure(
                data.protect_infrastructure !== false
            );
            setPending(data.pending || []);
            setPendingCount(data.pending_count || 0);
            setLastRunAt(data.last_run_at || null);
            setLastDeleted(data.last_deleted || 0);

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo leer la programación de limpieza."
            );

        }

    }


    useEffect(() => {

        load();

    }, []);


    async function handleSave() {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await saveDhcpCleanupSettings({
                enabled,
                days: Number(days),
                run_time: runTime,
                protect_infrastructure: protectInfrastructure,
            });

            setPending(data.pending || []);
            setPendingCount(data.pending_count || 0);
            setRunTime(data.run_time || runTime);
            setMessage(
                data.message
                || `Programación guardada (diaria a las ${data.run_time}).`
            );

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo guardar."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handlePreview() {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await runDhcpCleanup({
                dry_run: true,
                days: Number(days),
                protect_infrastructure: protectInfrastructure,
            });

            setPending(data.candidates || []);
            setPendingCount(data.count || 0);
            setMessage(
                data.count
                    ? `${data.count} equipo(s) se eliminarían ahora.`
                    : "No hay equipos que cumplan el criterio."
            );

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo previsualizar."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleRunNow() {

        if (!window.confirm(
            `¿Eliminar ahora las reservas de equipos sin conexión `
            + `más de ${days} días?\n\n`
            + "Se borran del listado de dispositivos y se liberan "
            + "sus IPs en DHCP. Los logs de navegación se conservan."
        )) {
            return;
        }

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await runDhcpCleanup({
                dry_run: false,
                days: Number(days),
                protect_infrastructure: protectInfrastructure,
            });

            setMessage(
                data.message
                || `Eliminados: ${data.deleted || 0}`
            );
            setLastDeleted(data.deleted || 0);
            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo ejecutar la limpieza."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel">

            <h3>Limpieza de reservas no usadas</h3>

            <p className="registry-hint">
                Cada equipo registrado reserva una IP en DHCP aunque esté
                apagado. Puedes programar la eliminación automática
                <strong> diaria a una hora fija</strong> de equipos
                {" "}<strong>sin conexión</strong> tras N días.
                Hora del servidor (Ecuador). Si un celular vuelve, se
                registra de nuevo.
            </p>

            <WriteGuard>

                <div className="registry-form-panel">

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={enabled}
                            onChange={(e) => setEnabled(e.target.checked)}
                        />
                        Activar limpieza automática diaria
                    </label>

                    <div className="registry-form-grid">

                        <label>
                            Días sin conexión
                            <input
                                type="number"
                                min={3}
                                max={180}
                                value={days}
                                onChange={(e) => setDays(e.target.value)}
                            />
                        </label>

                        <label>
                            Hora diaria (HH:MM)
                            <input
                                type="time"
                                value={runTime}
                                onChange={(e) => setRunTime(e.target.value)}
                            />
                        </label>

                    </div>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={protectInfrastructure}
                            onChange={(e) =>
                                setProtectInfrastructure(e.target.checked)
                            }
                        />
                        Proteger impresoras, routers y teléfonos IP
                    </label>

                    <div className="confirm-actions registry-form-actions">

                        <button
                            className="primary-button"
                            onClick={handleSave}
                            disabled={busy}
                        >
                            {busy ? "Guardando..." : "Guardar programación"}
                        </button>

                        <button
                            className="secondary-button"
                            onClick={handlePreview}
                            disabled={busy}
                        >
                            Ver candidatos
                        </button>

                        <button
                            className="secondary-button"
                            onClick={handleRunNow}
                            disabled={busy}
                        >
                            Ejecutar ahora
                        </button>

                    </div>

                </div>

            </WriteGuard>

            <div className="lan-stat-row">
                <span className="lan-stat">
                    <span>Programado</span>
                    <strong>
                        {enabled
                            ? `Diario a las ${runTime}`
                            : "Desactivado"}
                    </strong>
                </span>
                <span className="lan-stat">
                    <span>Pendientes ahora</span>
                    <strong>{pendingCount}</strong>
                </span>
                <span className="lan-stat">
                    <span>Última ejecución</span>
                    <strong>{lastRunAt || "—"}</strong>
                </span>
                <span className="lan-stat">
                    <span>Últimos borrados</span>
                    <strong>{lastDeleted}</strong>
                </span>
            </div>

            {pending.length > 0 && (
                <div className="dhcp-candidates">
                    <p className="registry-section-label">
                        Candidatos (máx. 50 mostrados)
                    </p>
                    <ul>
                        {pending.map((row) => (
                            <li key={row.id}>
                                <strong>
                                    {row.hostname || "(sin nombre)"}
                                </strong>
                                {" · "}
                                {row.ip_address}
                                {" · "}
                                {row.mac_address}
                                {" · "}
                                {row.device_type}
                                {" · visto "}
                                {row.last_seen || "—"}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpCleanupPanel;
