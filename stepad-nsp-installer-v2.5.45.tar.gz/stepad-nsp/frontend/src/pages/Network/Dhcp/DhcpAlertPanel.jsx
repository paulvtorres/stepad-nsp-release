import { useEffect, useState } from "react";

import {
    getDhcpAlertSettings,
    saveDhcpAlertSettings,
    runDhcpAlertCheck,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function DhcpAlertPanel() {

    const [serviceAlertEnabled, setServiceAlertEnabled] = useState(true);

    const [scheduledCheckEnabled, setScheduledCheckEnabled] = useState(false);

    const [runTime, setRunTime] = useState("08:00");

    const [poolLowAlertEnabled, setPoolLowAlertEnabled] = useState(false);

    const [poolLowThreshold, setPoolLowThreshold] = useState(10);

    const [healthy, setHealthy] = useState(true);

    const [problems, setProblems] = useState([]);

    const [lastRunAt, setLastRunAt] = useState(null);

    const [lastResult, setLastResult] = useState(null);

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpAlertSettings();

            setServiceAlertEnabled(
                data.service_alert_enabled !== false
            );
            setScheduledCheckEnabled(
                Boolean(data.scheduled_check_enabled)
            );
            setRunTime(data.run_time || "08:00");
            setPoolLowAlertEnabled(
                Boolean(data.pool_low_alert_enabled)
            );
            setPoolLowThreshold(
                Number(data.pool_low_threshold) || 10
            );
            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setLastRunAt(data.last_run_at || null);
            setLastResult(data.last_result || null);

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudieron leer las alertas DHCP."
            );

        }

    }


    useEffect(() => {

        load();

    }, []);


    async function handleSave() {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await saveDhcpAlertSettings({
                service_alert_enabled: serviceAlertEnabled,
                scheduled_check_enabled: scheduledCheckEnabled,
                run_time: runTime,
                pool_low_alert_enabled: poolLowAlertEnabled,
                pool_low_threshold: Number(poolLowThreshold),
            });

            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setMessage(
                data.message
                || "Programación de alertas guardada."
            );

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo guardar."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleCheck(forceEmail = false) {

        setBusy(true);
        setMessage("");
        setError("");

        try {

            const data = await runDhcpAlertCheck({
                force_email: forceEmail,
            });

            setHealthy(data.healthy !== false);
            setProblems(data.problems || []);
            setMessage(
                `${data.message || "Verificación lista."}`
                + (data.emailed ? " Correo enviado." : "")
            );
            await load();

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudo verificar."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel">

            <h3>Alertas por correo (DHCP)</h3>

            <p className="registry-hint">
                Avisos si DHCP se cae, no arranca, queda colgado, falla el
                diagnóstico o quedan pocas IPs libres. Usa los
                destinatarios de <strong>Ajustes → Alertas</strong>
                (correo SMTP debe estar configurado).
            </p>

            <WriteGuard>

                <div className="registry-form-panel">

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={serviceAlertEnabled}
                            onChange={(e) =>
                                setServiceAlertEnabled(e.target.checked)
                            }
                        />
                        Correo inmediato si DHCP cae o se cuelga
                    </label>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={scheduledCheckEnabled}
                            onChange={(e) =>
                                setScheduledCheckEnabled(e.target.checked)
                            }
                        />
                        Verificación diaria programada (solo envía si hay
                        problemas)
                    </label>

                    <div className="registry-form-grid">

                        <label>
                            Hora de verificación (HH:MM)
                            <input
                                type="time"
                                value={runTime}
                                onChange={(e) => setRunTime(e.target.value)}
                                disabled={!scheduledCheckEnabled}
                            />
                        </label>

                        <label>
                            Umbral IPs libres (pool equipos)
                            <input
                                type="number"
                                min={1}
                                max={500}
                                value={poolLowThreshold}
                                onChange={(e) =>
                                    setPoolLowThreshold(e.target.value)
                                }
                            />
                        </label>

                    </div>

                    <label className="dhcp-toggle-row">
                        <input
                            type="checkbox"
                            checked={poolLowAlertEnabled}
                            onChange={(e) =>
                                setPoolLowAlertEnabled(e.target.checked)
                            }
                        />
                        Avisar si las IPs libres del pool ≤ umbral
                    </label>

                    <div className="confirm-actions registry-form-actions">

                        <button
                            className="primary-button"
                            onClick={handleSave}
                            disabled={busy}
                        >
                            {busy ? "Guardando..." : "Guardar alertas"}
                        </button>

                        <button
                            className="secondary-button"
                            onClick={() => handleCheck(false)}
                            disabled={busy}
                        >
                            Verificar ahora
                        </button>

                        <button
                            className="secondary-button"
                            onClick={() => handleCheck(true)}
                            disabled={busy}
                        >
                            Verificar y forzar correo
                        </button>

                    </div>

                </div>

            </WriteGuard>

            <div className="lan-stat-row">
                <span className="lan-stat">
                    <span>Estado actual</span>
                    <strong className={healthy ? "ok-text" : "err-text"}>
                        {healthy ? "Saludable" : "Con problemas"}
                    </strong>
                </span>
                <span className="lan-stat">
                    <span>Última verificación</span>
                    <strong>{lastRunAt || "—"}</strong>
                </span>
                <span className="lan-stat">
                    <span>Resultado</span>
                    <strong>{lastResult || "—"}</strong>
                </span>
            </div>

            {problems.length > 0 && (
                <div className="dhcp-candidates">
                    <p className="registry-section-label">
                        Problemas detectados
                    </p>
                    <ul>
                        {problems.map((row, index) => (
                            <li key={`${row.code}-${index}`}>
                                <strong>{row.title}</strong>
                                {" — "}
                                {row.message}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpAlertPanel;
