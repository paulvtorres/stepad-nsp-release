import { Link } from "react-router-dom";

import { useNetworkSegment } from "../../../network/useNetworkSegment";

import DhcpStatusPanel from "./DhcpStatusPanel";
import DhcpPoolStatsPanel from "./DhcpPoolStatsPanel";
import LanSegmentPanel from "./LanSegmentPanel";
import DhcpAlertPanel from "./DhcpAlertPanel";
import DhcpCleanupPanel from "./DhcpCleanupPanel";
import DhcpLogPanel from "./DhcpLogPanel";

import "../Interfaces/interfaces.css";
import "./dhcp.css";


function Dhcp() {

    const {
        lanCards,
        selectedLan,
        selectedZones,
    } = useNetworkSegment();

    const lanLabel = selectedLan
        ? (selectedLan.display_name
            || selectedLan.current_name
            || selectedLan.last_seen_name
            || "LAN")
        : null;

    return (

        <div className="interfaces-page dhcp-page">

            <header className="interfaces-header">
                <h2>DHCP</h2>
                <p>
                    Estado del servicio, uso de IPs, segmento, alertas por
                    correo, limpieza de reservas y registro de actividad.
                    {lanCards.length > 1 && lanLabel
                        ? ` Contexto actual: ${lanLabel}.`
                        : ""}
                </p>
            </header>

            {
                lanCards.length > 1 && selectedZones.length > 0 && (
                    <div className="dhcp-segment-banner">
                        <strong>DHCP de la red seleccionada</strong>
                        <ul>
                            {
                                selectedZones.map((zone) => (
                                    <li key={zone.id}>
                                        {zone.name}: {zone.network_cidr}
                                        {" · pool "}
                                        {zone.dhcp_pool_start}–{zone.dhcp_pool_end}
                                        {" · gw "}
                                        {zone.gateway_ip}
                                        {zone.is_default ? " (default)" : ""}
                                    </li>
                                ))
                            }
                        </ul>
                        <p>
                            El panel de «Segmento LAN» abajo es el DHCP del
                            segmento principal del appliance. Para otra
                            tarjeta, ajusta la zona en{" "}
                            <Link to="/network/zones">Zonas</Link>.
                        </p>
                    </div>
                )
            }

            {
                lanCards.length > 1 && selectedZones.length === 0 && (
                    <div className="dhcp-segment-banner warn">
                        Esta tarjeta LAN aún no tiene zona. Crea una en{" "}
                        <Link
                            to={
                                `/network/zones?mac=${encodeURIComponent(selectedLan?.mac_address || "")}`
                                + `&iface=${encodeURIComponent(selectedLan?.current_name || selectedLan?.last_seen_name || "")}`
                            }
                        >
                            Zonas
                        </Link>
                        {" "}con el CIDR y el pool DHCP de ese segmento.
                    </div>
                )
            }

            <DhcpStatusPanel />

            <DhcpPoolStatsPanel />

            <LanSegmentPanel />

            <DhcpAlertPanel />

            <DhcpCleanupPanel />

            <DhcpLogPanel />

        </div>

    );
}

export default Dhcp;
