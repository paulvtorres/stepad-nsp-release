import { useEffect, useState } from "react";

import { getDhcpPoolStats } from "../../../services/api";


function StatCard({ label, value, hint, tone }) {

    return (

        <div className={`dhcp-stat-card ${tone || ""}`}>
            <span className="dhcp-stat-label">{label}</span>
            <strong className="dhcp-stat-value">{value}</strong>
            {hint && <span className="dhcp-stat-hint">{hint}</span>}
        </div>

    );

}


function DhcpPoolStatsPanel() {

    const [stats, setStats] = useState(null);

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpPoolStats();

            setStats(data);
            setError("");

        } catch (err) {

            setError(
                err?.response?.data?.detail
                || err.message
                || "No se pudieron leer las estadísticas DHCP."
            );

        }

    }


    useEffect(() => {

        load();

        const timer = setInterval(load, 20000);

        return () => clearInterval(timer);

    }, []);


    if (!stats && !error) {
        return (
            <div className="registry-panel">
                <h3>Uso de IPs</h3>
                <p className="registry-hint">Cargando...</p>
            </div>
        );
    }


    const devices = stats?.devices || {};
    const groups = stats?.groups || {};
    const overall = stats?.overall || {};


    return (

        <div className="registry-panel">

            <div className="registry-panel-head">
                <div>
                    <h3>Uso de IPs</h3>
                    <p className="registry-hint">
                        Totales según el segmento configurado: pool de
                        equipos ({stats?.pool_start}–{stats?.pool_end})
                        + reserva de grupos ({stats?.group_ip_start}–
                        {stats?.group_ip_end}). Libres = total − online −
                        offline (y grupos usados).
                    </p>
                </div>
                <button
                    type="button"
                    className="secondary-button"
                    onClick={load}
                >
                    Actualizar
                </button>
            </div>

            <div className="dhcp-stat-grid">
                <StatCard
                    label="Total IPs"
                    value={overall.total ?? "—"}
                    hint="Equipos + grupos"
                />
                <StatCard
                    label="En línea"
                    value={overall.online ?? "—"}
                    hint="Equipos ONLINE"
                    tone="ok"
                />
                <StatCard
                    label="Offline (reservadas)"
                    value={overall.offline ?? "—"}
                    hint="Siguen ocupando IP"
                    tone="warn"
                />
                <StatCard
                    label="Libres"
                    value={overall.free ?? "—"}
                    hint="Disponibles ahora"
                    tone="accent"
                />
            </div>

            <div className="lan-stat-row" style={{ marginTop: 14 }}>
                <span className="lan-stat">
                    <span>Pool equipos</span>
                    <strong>
                        {devices.total ?? 0}
                        {" · "}online {devices.online ?? 0}
                        {" · "}off {devices.offline ?? 0}
                        {" · "}libres {devices.free ?? 0}
                    </strong>
                </span>
                <span className="lan-stat">
                    <span>IPs de grupos</span>
                    <strong>
                        {groups.total ?? 0}
                        {" · "}usadas {groups.used ?? 0}
                        {" · "}libres {groups.free ?? 0}
                    </strong>
                </span>
            </div>

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}


export default DhcpPoolStatsPanel;
