import io
import socket
import html as html_lib

from datetime import datetime, timezone


def _to_local(value):
    """Los logs se guardan en UTC (naive); convierten a hora local del
    servidor para que el Excel no muestre el dia equivocado (UTC+5
    hacia adelante -> a las 21h local ya es "mañana" en UTC)."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone().replace(tzinfo=None)

from openpyxl import Workbook
from openpyxl.styles import (
    Alignment,
    Border,
    Font,
    PatternFill,
    Side,
)
from openpyxl.utils import get_column_letter

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.organization.repositories.organization_settings_repository import (
    OrganizationSettingsRepository
)


def _format_duration(minutes: int) -> str:

    minutes = int(minutes or 0)

    if minutes <= 0:

        return "—"

    hours = minutes // 60

    remainder = minutes % 60

    if hours:

        return f"{hours} h {remainder} min"

    return f"{remainder} min"


def _format_period(start, end) -> str:
    """Período en hora local del servidor, con etiqueta según duración."""

    if not start or not end:

        return "—"

    local_start = _to_local(start)

    local_end = _to_local(end)

    hours = (end - start).total_seconds() / 3600

    if 23 <= hours <= 25:

        prefix = "Últimas 24 horas · "

    elif 167 <= hours <= 169:

        prefix = "Últimos 7 días · "

    elif 719 <= hours <= 745:

        prefix = "Últimos 30 días · "

    else:

        prefix = ""

    return (
        f"{prefix}"
        f"{local_start.strftime('%d/%m/%Y %H:%M')} a "
        f"{local_end.strftime('%d/%m/%Y %H:%M')} (hora local)"
    )


def _format_timestamp(value) -> str:

    local = _to_local(value)

    if local is None:

        return "—"

    return local.strftime("%d/%m/%Y %H:%M")


# Cuerpo vacío: el reporte va solo en el Excel adjunto.
EMAIL_REPORT_BODY = "<html><body></body></html>"


class ReportService:

    def __init__(self):

        self.query_repo = DnsQueryLogRepository()

        self.org_repo = OrganizationSettingsRepository()

    def _organization(
        self,
        db
    ) -> dict:

        settings = self.org_repo.get(db)

        return {
            "company_name": settings.company_name,
            "ruc": settings.ruc,
            "address": settings.address,
            "phone": settings.phone,
            "email": settings.email,
            "city": settings.city,
            "country": settings.country,
        }

    @staticmethod
    def _hostname() -> str:

        try:

            return socket.gethostname()

        except Exception:

            return "stepad-nsp"

    def summary_rows(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ):

        return self.query_repo.find_summary(
            db,
            start=start,
            end=end,
            device_id=device_id,
            domain_contains=domain
        )

    def blocked_recent(
        self,
        db,
        start
    ):

        return self.query_repo.find_blocked_recent(
            db,
            start=start
        )

    @staticmethod
    def _row_device_key(row) -> str:

        if row.device_id is not None:

            return str(row.device_id)

        ip = row.client_ip or row.ip_address

        return ip or "unknown"

    def _per_device(
        self,
        db,
        start,
        end,
        rows,
    ):

        active_by_device = self.query_repo.find_device_active_minutes(
            db,
            start=start,
            end=end,
        )

        period_cap = None

        if start and end:

            period_cap = max(
                1,
                int((end - start).total_seconds() // 60),
            )

        devices = {}

        for row in rows:

            key = self._row_device_key(row)

            entry = devices.setdefault(key, {
                "device_name": row.device_hostname or row.hostname or row.client_ip or row.ip_address or "Desconocido",
                "device_ip": row.client_ip or row.ip_address,
                "visits": 0,
                "active_minutes": 0,
                "blocked": 0,
                "domains": {},
            })

            entry["visits"] += row.visit_count or 0

            entry["blocked"] += row.blocked_count or 0

            entry["domains"][row.domain] = (
                entry["domains"].get(row.domain, 0)
                + (row.visit_count or 0)
            )

        for key, entry in devices.items():

            minutes = active_by_device.get(key, 0)

            if period_cap is not None:

                minutes = min(minutes, period_cap)

            entry["active_minutes"] = minutes

        return sorted(
            devices.values(),
            key=lambda d: (d["visits"], d["active_minutes"]),
            reverse=True,
        )

    @staticmethod
    def _device_label(row) -> str:

        return (
            row.device_hostname
            or row.hostname
            or row.client_ip
            or row.ip_address
            or "Desconocido"
        )

    def _rows_sorted_by_domain_usage(
        self,
        rows,
        devices,
    ):
        """Detalle ordenado: dominios con más consultas DNS primero."""

        rank = {
            device["device_name"]: index
            for index, device in enumerate(devices)
        }

        return sorted(
            rows,
            key=lambda row: (
                -(row.visit_count or 0),
                rank.get(self._device_label(row), 9999),
                row.domain or "",
            ),
        )

    def build_html_report(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None
    ) -> str:

        return EMAIL_REPORT_BODY

    @staticmethod
    def _excel_border() -> Border:

        thin = Side(style="thin", color="D1D5DB")

        return Border(left=thin, right=thin, top=thin, bottom=thin)

    def _write_excel_title_block(
        self,
        sheet,
        *,
        report_title: str,
        org: dict,
        start,
        end,
        device_label: str | None = None,
        domain_filter: str | None = None,
        col_span: int = 8,
    ) -> int:
        """Encabezado corporativo. Devuelve la fila siguiente libre."""

        title_font = Font(bold=True, size=22, color="1E3A8A")
        subtitle_font = Font(bold=True, size=14, color="374151")
        meta_font = Font(size=12, color="4B5563")
        left = Alignment(horizontal="left", vertical="center", wrap_text=True)

        company = org.get("company_name") or "Empresa"

        sheet.merge_cells(
            start_row=1, start_column=1, end_row=1, end_column=col_span
        )
        sheet["A1"] = company
        sheet["A1"].font = title_font
        sheet["A1"].alignment = left
        sheet.row_dimensions[1].height = 38

        sheet.merge_cells(
            start_row=2, start_column=1, end_row=2, end_column=col_span
        )
        sheet["A2"] = report_title
        sheet["A2"].font = subtitle_font
        sheet["A2"].alignment = left
        sheet.row_dimensions[2].height = 26

        meta_lines = []

        if org.get("ruc"):
            meta_lines.append(f"RUC: {org['ruc']}")

        if org.get("address"):
            meta_lines.append(f"Dirección: {org['address']}")

        location = ", ".join(
            part
            for part in (org.get("city"), org.get("country"))
            if part
        )

        if location:
            meta_lines.append(f"Ubicación: {location}")

        contact = []
        if org.get("phone"):
            contact.append(f"Tel. {org['phone']}")
        if org.get("email"):
            contact.append(org["email"])
        if contact:
            meta_lines.append(" · ".join(contact))

        meta_lines.append(
            f"Período analizado: {_format_period(start, end)}"
        )
        meta_lines.append(
            "Generado: "
            + datetime.now().strftime("%d/%m/%Y %H:%M")
            + f"  ·  Equipo NSP: {self._hostname()}"
        )

        filters = []
        if device_label:
            filters.append(f"Equipo: {device_label}")
        if domain_filter:
            filters.append(f"Dominio contiene: {domain_filter}")
        if filters:
            meta_lines.append("Filtros: " + "  ·  ".join(filters))

        row_idx = 3
        for line in meta_lines:
            sheet.merge_cells(
                start_row=row_idx,
                start_column=1,
                end_row=row_idx,
                end_column=col_span,
            )
            cell = sheet.cell(row=row_idx, column=1, value=line)
            cell.font = meta_font
            cell.alignment = left
            sheet.row_dimensions[row_idx].height = 22
            row_idx += 1

        return row_idx + 1

    @staticmethod
    def _write_excel_section_title(
        sheet,
        row: int,
        title: str,
        col_span: int = 8,
    ) -> int:

        sheet.merge_cells(
            start_row=row,
            start_column=1,
            end_row=row,
            end_column=col_span,
        )
        cell = sheet.cell(row=row, column=1, value=title)
        cell.font = Font(bold=True, size=12, color="1F2937")
        cell.fill = PatternFill("solid", fgColor="E5E7EB")
        cell.alignment = Alignment(horizontal="left", vertical="center")
        cell.border = ReportService._excel_border()
        sheet.row_dimensions[row].height = 26
        return row + 1

    @staticmethod
    def _write_excel_table_header(
        sheet,
        row: int,
        headers: list[str],
    ) -> int:

        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill("solid", fgColor="1E3A8A")
        center = Alignment(horizontal="center", vertical="center", wrap_text=True)
        border = ReportService._excel_border()

        for col, heading in enumerate(headers, start=1):
            cell = sheet.cell(row=row, column=col, value=heading)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = center
            cell.border = border

        sheet.row_dimensions[row].height = 28
        return row + 1

    @staticmethod
    def _write_excel_data_row(
        sheet,
        row: int,
        values: list,
        *,
        banded: bool = False,
        left_cols: set[int] | None = None,
        date_cols: set[int] | None = None,
        int_cols: set[int] | None = None,
    ) -> int:

        left_cols = left_cols or set()
        date_cols = date_cols or set()
        int_cols = int_cols or set()
        border = ReportService._excel_border()
        band_fill = PatternFill("solid", fgColor="F9FAFB")
        data_font = Font(size=10, color="111827")
        center = Alignment(horizontal="center", vertical="center")
        left = Alignment(horizontal="left", vertical="center", wrap_text=True)

        for col, value in enumerate(values, start=1):
            cell = sheet.cell(row=row, column=col, value=value)
            cell.font = data_font
            cell.border = border
            if col in left_cols:
                cell.alignment = left
            else:
                cell.alignment = center
            if col in date_cols and value is not None:
                cell.number_format = "DD/MM/YYYY HH:MM"
            if col in int_cols and isinstance(value, (int, float)):
                cell.number_format = "#,##0"
            if banded:
                cell.fill = band_fill

        return row + 1

    @staticmethod
    def _set_column_widths(sheet, widths: list[int]) -> None:

        for index, width in enumerate(widths, start=1):
            sheet.column_dimensions[get_column_letter(index)].width = width

    @staticmethod
    def _write_excel_footer(
        sheet,
        row: int,
        text: str,
        col_span: int = 8,
    ) -> None:

        sheet.merge_cells(
            start_row=row,
            start_column=1,
            end_row=row,
            end_column=col_span,
        )
        cell = sheet.cell(row=row, column=1, value=text)
        cell.font = Font(size=9, italic=True, color="6B7280")
        cell.alignment = Alignment(
            horizontal="left", vertical="top", wrap_text=True
        )
        sheet.row_dimensions[row].height = 36

    def build_excel(
        self,
        db,
        start,
        end,
        device_id=None,
        domain=None,
        device_label: str | None = None,
    ) -> io.BytesIO:

        rows = self.summary_rows(db, start, end, device_id, domain)

        devices = self._per_device(db, start, end, rows)

        blocked_events = []

        if start is not None:

            blocked_events = self.query_repo.find_blocked_recent(
                db,
                start=start,
                limit=500,
            )

        org = self._organization(db)

        sorted_rows = self._rows_sorted_by_domain_usage(rows, devices)

        workbook = Workbook()

        # --- Hoja 1: Navegación por equipo (detalle principal) ---
        navigation = workbook.active
        navigation.title = "Navegación por equipo"

        next_row = self._write_excel_title_block(
            navigation,
            report_title="Historial DNS — Navegación por equipo",
            org=org,
            start=start,
            end=end,
            device_label=device_label,
            domain_filter=domain,
            col_span=7,
        )

        next_row = self._write_excel_section_title(
            navigation,
            next_row,
            "Detalle ordenado: dominios más visitados primero",
            col_span=7,
        )

        detail_headers = [
            "Equipo",
            "Dirección IP",
            "Dominio visitado",
            "Consultas DNS",
            "Primera consulta",
            "Última consulta",
            "Intentos bloqueados",
        ]
        detail_header_row = next_row
        next_row = self._write_excel_table_header(
            navigation, next_row, detail_headers
        )

        detail_data_start = next_row
        for index, row in enumerate(sorted_rows):
            row_ip = row.client_ip or row.ip_address
            next_row = self._write_excel_data_row(
                navigation,
                next_row,
                [
                    self._device_label(row),
                    row_ip or "—",
                    row.domain,
                    row.visit_count or 0,
                    _to_local(row.first_seen),
                    _to_local(row.last_seen),
                    row.blocked_count or 0,
                ],
                banded=index % 2 == 1,
                left_cols={1, 2, 3},
                date_cols={5, 6},
                int_cols={4, 7},
            )

        self._write_excel_footer(
            navigation,
            next_row + 1,
            "Orden: dominios con más consultas DNS primero. Fechas en hora "
            "local del servidor NSP.",
            col_span=7,
        )

        navigation.auto_filter.ref = (
            f"A{detail_header_row}:G{next_row - 1}"
        )
        navigation.freeze_panes = f"A{detail_data_start}"
        self._set_column_widths(navigation, [28, 16, 40, 14, 18, 18, 16])
        navigation.sheet_view.showGridLines = False

        # --- Hoja 2: Intentos bloqueados ---
        blocked_sheet = workbook.create_sheet("Intentos bloqueados")

        blocked_row = self._write_excel_title_block(
            blocked_sheet,
            report_title="Sitios y dominios con acceso denegado",
            org=org,
            start=start,
            end=end,
            device_label=device_label,
            domain_filter=domain,
            col_span=4,
        )

        blocked_summary = [
            row for row in sorted_rows if (row.blocked_count or 0) > 0
        ]

        blocked_row = self._write_excel_section_title(
            blocked_sheet,
            blocked_row,
            "Resumen por equipo y dominio (intentos bloqueados)",
            col_span=4,
        )

        blocked_headers = [
            "Equipo",
            "Dominio",
            "Intentos bloqueados",
            "Último intento",
        ]
        blocked_header_row = blocked_row
        blocked_row = self._write_excel_table_header(
            blocked_sheet, blocked_row, blocked_headers
        )

        blocked_data_start = blocked_row
        if blocked_summary:
            for index, row in enumerate(blocked_summary):
                blocked_row = self._write_excel_data_row(
                    blocked_sheet,
                    blocked_row,
                    [
                        (
                            row.device_hostname
                            or row.hostname
                            or row.client_ip
                            or row.ip_address
                            or "Desconocido"
                        ),
                        row.domain,
                        row.blocked_count or 0,
                        _to_local(row.last_seen),
                    ],
                    banded=index % 2 == 1,
                    left_cols={1, 2},
                    date_cols={4},
                    int_cols={3},
                )
        else:
            blocked_sheet.merge_cells(
                start_row=blocked_row,
                start_column=1,
                end_row=blocked_row,
                end_column=4,
            )
            cell = blocked_sheet.cell(
                row=blocked_row,
                column=1,
                value="No se registraron intentos bloqueados en este período.",
            )
            cell.alignment = Alignment(horizontal="left", vertical="center")
            blocked_row += 1

        if blocked_events:
            blocked_row += 1
            blocked_row = self._write_excel_section_title(
                blocked_sheet,
                blocked_row,
                "Últimos eventos bloqueados (detalle cronológico)",
                col_span=4,
            )
            event_headers = ["Equipo", "Dominio", "Fecha y hora"]
            blocked_row = self._write_excel_table_header(
                blocked_sheet, blocked_row, event_headers
            )
            for index, item in enumerate(blocked_events[:200]):
                blocked_row = self._write_excel_data_row(
                    blocked_sheet,
                    blocked_row,
                    [
                        item.get("device_name") or "Desconocido",
                        item.get("domain"),
                        _to_local(item.get("queried_at")),
                    ],
                    banded=index % 2 == 1,
                    left_cols={1, 2},
                    date_cols={3},
                )

        self._write_excel_footer(
            blocked_sheet,
            blocked_row + 1,
            "Los bloqueos corresponden a políticas configuradas "
            "(contenido no laboral, reglas de grupo, malware, etc.).",
            col_span=4,
        )

        blocked_sheet.auto_filter.ref = (
            f"A{blocked_header_row}:D{blocked_data_start - 1}"
            if blocked_summary
            else f"A{blocked_header_row}:D{blocked_header_row}"
        )
        blocked_sheet.freeze_panes = f"A{blocked_data_start}"
        self._set_column_widths(blocked_sheet, [28, 40, 18, 20])
        blocked_sheet.sheet_view.showGridLines = False

        buffer = io.BytesIO()
        workbook.save(buffer)
        buffer.seek(0)
        return buffer
