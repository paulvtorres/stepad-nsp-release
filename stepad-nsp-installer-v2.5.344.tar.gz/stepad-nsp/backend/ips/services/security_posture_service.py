"""Avisos de seguridad (postura) del NSP.

Revisa proactivamente la configuración/exposición y devuelve una lista de
avisos con severidad, detalle y recomendación — para que el administrador
vea de entrada lo que debe atender.
"""
from __future__ import annotations

import ipaddress
import json
import subprocess
import time
import urllib.request
from datetime import datetime, timedelta

from backend.shared.logging.logger import logger


_SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}

# Puertos con nombre legible (para el aviso de exposición en la WAN).
_SENSITIVE_PORTS = {
    "22": "SSH",
    "8443": "Panel/API del NSP",
    "21115": "RustDesk hbbs",
    "21116": "RustDesk hbbs",
    "21117": "RustDesk hbbr",
    "21118": "RustDesk hbbs",
    "21119": "RustDesk hbbr",
}


class SecurityPostureService:

    _public_cache = {"ts": 0.0, "ip": None}

    # ------------------------------------------------------------------
    def _run(self, args):
        try:
            return subprocess.run(
                args, capture_output=True, text=True, timeout=6
            ).stdout or ""
        except Exception:
            return ""

    def _listening(self):
        """[(addr, port)] de puertos TCP en LISTEN."""
        out = self._run(["ss", "-H", "-lnt"])
        items = []
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 4:
                local = parts[3]
                addr, _, port = local.rpartition(":")
                items.append((addr, port))
        return items

    def _default_wan(self):
        """(interfaz, IP) de la ruta por defecto (WAN)."""
        out = self._run(["ip", "-j", "route", "show", "default"])
        try:
            data = json.loads(out or "[]")
        except Exception:
            data = []
        if data:
            return data[0].get("dev"), data[0].get("prefsrc")
        return None, None

    def _public_ip(self):
        cache = self._public_cache
        now = time.time()
        if cache.get("ip") and now - cache.get("ts", 0) < 300:
            return cache["ip"]
        try:
            with urllib.request.urlopen(
                "https://api.ipify.org", timeout=6
            ) as response:
                ip = (response.read() or b"").decode().strip()
            if ip:
                self._public_cache = {"ts": now, "ip": ip}
                return ip
        except Exception:
            pass
        return cache.get("ip")

    @staticmethod
    def _is_private(ip):
        try:
            return ipaddress.ip_address(ip).is_private
        except Exception:
            return False

    # ------------------------------------------------------------------
    def get_posture(self, db=None) -> dict:
        advisories = []

        def add(sev, title, detail, rec):
            advisories.append({
                "severity": sev,
                "title": title,
                "detail": detail,
                "recommendation": rec,
            })

        # 1) Servicios sensibles escuchando en TODAS las interfaces (WAN).
        try:
            lis = self._listening()
            any_iface = ("0.0.0.0", "*", "::", "[::]", "")
            exposed_crit = sorted({
                p for (a, p) in lis
                if a in any_iface and p in ("22", "8443")
            }, key=lambda x: int(x))
            if exposed_crit:
                names = ", ".join(
                    f"{_SENSITIVE_PORTS.get(p, p)} ({p})" for p in exposed_crit
                )
                add(
                    "high",
                    "Servicios sensibles escuchando en la WAN",
                    f"Estos servicios escuchan en TODAS las interfaces: {names}. "
                    "Si el router de arriba publica esos puertos, quedan "
                    "expuestos a Internet.",
                    "Restringí SSH y el Panel/API a la LAN/Tailscale (no a la WAN).",
                )
            rustdesk = sorted({
                p for (a, p) in lis
                if a in any_iface and p in ("21115", "21116", "21117", "21118", "21119")
            })
            if rustdesk:
                add(
                    "info",
                    "RustDesk publicado en la WAN",
                    "Puertos 21115-21119 escuchan para acceso remoto (por diseño).",
                    "Si no usás RustDesk remoto, desactivalo o restringilo a la VPN.",
                )
        except Exception as error:
            logger.warning("posture: exposición: %s", error)

        # 2) NSP detrás de NAT (no está en el borde).
        try:
            wan_dev, wan_ip = self._default_wan()
            public_ip = self._public_ip()
            if (
                wan_ip
                and self._is_private(wan_ip)
                and public_ip
                and not self._is_private(public_ip)
            ):
                add(
                    "medium",
                    "El NSP está detrás de otro router (doble NAT)",
                    f"IP WAN del NSP: {wan_ip} (privada) · IP pública de salida: "
                    f"{public_ip}. El NSP NO está en el borde: no verá ni "
                    "bloqueará intentos de ingreso externos reales.",
                    "Para proteger el borde, poné el router de arriba en "
                    "bridge o hacé DMZ hacia el NSP. Si no, el NSP solo ve "
                    "tráfico de la LAN.",
                )
        except Exception as error:
            logger.warning("posture: nat: %s", error)

        # 3) Protecciones apagadas.
        try:
            off = []
            from backend.ips.services.threat_response_service import (
                threat_response_service,
            )
            from backend.ips.services.attack_response_service import (
                attack_response_service,
            )
            if db is not None:
                s = threat_response_service.get_settings(db)
                if not s.get("ips_fail_closed"):
                    off.append("Modo fail-closed (NFQUEUE) OFF")
                if not s.get("auto_block_inbound"):
                    off.append("Bloqueo automático del atacante OFF")
                if not s.get("quarantine_enabled"):
                    off.append("Cuarentena automática OFF")
            if not attack_response_service.get_block_p2p():
                off.append("Bloqueo de P2P/BitTorrent OFF")
            try:
                from backend.firewall.services.firewall_hardening_service import (
                    FirewallHardeningService,
                )
                h = FirewallHardeningService().get_settings()
                if not h.get("hardening_enabled"):
                    off.append("Hardening del firewall (deny-all) OFF")
            except Exception:
                pass
            if off:
                add(
                    "medium",
                    "Protecciones recomendadas desactivadas",
                    "Desactivadas: " + "; ".join(off) + ".",
                    "Activá las que apliquen para una postura más estricta.",
                )
        except Exception as error:
            logger.warning("posture: protecciones: %s", error)

        # 4) Feeds de inteligencia desactualizados / sin datos.
        try:
            from backend.ips.services.geoip_service import geoip_service
            meta = getattr(geoip_service, "meta", {}) or {}
            rows = meta.get("rows") or meta.get("count") or 0
            if not rows:
                add(
                    "low",
                    "GeoIP sin datos",
                    "No hay base GeoIP cargada (no se enriquecen país/ASN/org).",
                    "Actualizá las listas/feeds de inteligencia.",
                )
        except Exception as error:
            logger.warning("posture: geoip: %s", error)

        # 5) Alcance entrante (¿llega algo de Internet?).
        try:
            if db is not None:
                from sqlalchemy import func
                from backend.ips.models.inbound_attack_event import (
                    InboundAttackEvent,
                )
                since = datetime.utcnow() - timedelta(days=7)
                n = (
                    db.query(func.count())
                    .select_from(InboundAttackEvent)
                    .filter(InboundAttackEvent.last_seen >= since)
                    .scalar()
                ) or 0
                if n == 0:
                    add(
                        "info",
                        "Sin eventos de ingreso entrante (7 días)",
                        "No se registró tráfico entrante marcado como ataque; "
                        "consistente con el NSP detrás de NAT (poco expuesto).",
                        "Si esperás proteger ataques externos, publicá el NSP "
                        "en el borde (DMZ/bridge).",
                    )
        except Exception as error:
            logger.warning("posture: inbound: %s", error)

        advisories.sort(key=lambda a: _SEV_ORDER.get(a["severity"], 9))

        counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for a in advisories:
            counts[a["severity"]] = counts.get(a["severity"], 0) + 1

        return {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "worst": (advisories[0]["severity"] if advisories else "ok"),
            "counts": counts,
            "advisories": advisories,
        }


security_posture_service = SecurityPostureService()
