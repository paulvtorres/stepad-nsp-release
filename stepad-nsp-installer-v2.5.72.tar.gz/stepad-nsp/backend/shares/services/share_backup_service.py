"""
Versioned backups of shared volumes using restic (anti-ransomware).

Each job snapshots one directory (a shared volume mountpoint or folder)
into a dedicated, encrypted and deduplicated restic repository stored in
each unit's private vault folder:  {unit}/Respaldo/.backups/job-{id}.

The vault (the private "Respaldo" folder of every unit) is never exposed
through Samba -- shares.conf only references shared folder mountpoints under
/mnt/stepad-share -- so an SMB client (or ransomware moving through SMB)
cannot reach, list or delete the repositories.

Job definitions (characteristics) live in a hidden file inside each vault:
    {unit}/Respaldo/.respaldo.json

That file is the single source of truth for the backups: it assigns each new
job its sequential id and stores the schedule, retention, runtime state and
the flag that suppresses repeated "source missing" alerts. No database sync
is required, which avoids inconsistencies between the database and the disk.

A scheduler runs the enabled jobs on their schedule; when a job's source
directory disappears, an alert (SHARE_BACKUP_SOURCE_MISSING) is raised in
the alerts panel.

Retention keeps the newest N snapshots; when free space on the disk hosting
the repository drops below a threshold, `forget --keep-last N --prune`
trims old versions while preserving recent ones.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger
from backend.shared.utils.datetimes import to_iso_utc
from backend.shares.models.network_share_folder import NetworkShareFolder

SHARE_ROOT = Path("/mnt/stepad-share")
VOLUME_RESERVED_NAME = "Respaldo"
BACKUP_SUBDIR = ".backups"
CONFIG_FILENAME = ".respaldo.json"
CONFIG_SCHEMA = 1

ENV_FILE = Path("/etc/stepad/stepad.env")

RESTIC_PASSWORD_KEY = "STEPAD_RESTIC_PASSWORD"

POLL_SECONDS = 60

RECONCILE_SECONDS = 300

SOURCE_MISSING_ALERT = "SHARE_BACKUP_SOURCE_MISSING"


def _human_bytes(value: int | None) -> str:
    try:
        value = int(value or 0)
    except (TypeError, ValueError):
        value = 0
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024 or unit == "TiB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{int(value)} B"


def _empty_config() -> dict:
    return {"schema": CONFIG_SCHEMA, "next_job_id": 1, "jobs": []}


def _default_job() -> dict:
    return {
        "id": 0,
        "name": "",
        "source_path": "",
        "smb_user": "",
        "smb_password": "",
        "enabled": True,
        "schedule_mode": "daily",
        "schedule_hour": 2,
        "schedule_minute": 0,
        "schedule_times": None,
        "interval_minutes": None,
        "retention_count": 7,
        "prune_free_pct": 15,
        "folder_id": None,
        "change_hash": None,
        "tree_hash": None,
        "last_backup_at": None,
        "last_result": None,
        "last_snapshot_id": None,
        "last_bytes": 0,
        "source_missing_alerted": False,
    }


class Job(dict):
    """Job record augmented with its vault folder (never persisted)."""

    def __init__(self, *args, vault: Path | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.vault = vault


class ShareBackupService:

    def __init__(self):
        self._stop = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._running_jobs: set[int] = set()
        self._last_reconcile = 0.0

    # ------------------------------------------------------------------
    # vault / config file storage (single source of truth)
    # ------------------------------------------------------------------

    def _vaults(self) -> list[Path]:
        """Cada carpeta privada «Respaldo» de una unidad es una bóveda.
        Si dos rutas apuntan al mismo directorio (hardlinks), solo devuelve
        una de ellas (el camino más corto). Incluye unidades de red montadas."""
        seen_inodes: set[int] = set()
        vaults: list[Path] = []
        # SHARE_ROOT (unidades locales)
        roots = [SHARE_ROOT] if SHARE_ROOT.is_dir() else []
        # Agregar puntos de montaje de unidades de red
        network_base = Path("/mnt/stepad-network")
        if network_base.is_dir():
            for child in network_base.iterdir():
                if child.is_dir() and child not in roots:
                    roots.append(child)
        for root in roots:
            for volume in sorted(root.iterdir(), key=lambda c: len(str(c))):
                if not volume.is_dir():
                    continue
                vault = volume / VOLUME_RESERVED_NAME
                if not vault.is_dir():
                    continue
                try:
                    inode = os.stat(vault).st_ino
                except OSError:
                    continue
                if inode in seen_inodes:
                    continue
                seen_inodes.add(inode)
                vaults.append(vault)
        return vaults

    def _vault_for_source(self, source: str) -> Path | None:
        """Bóveda (carpeta Respaldo) de la unidad que contiene el origen."""
        if not source:
            return None
        # Network unit mounted at /mnt/stepad-network/{letter}
        if "/stepad-network/" in source:
            vault = Path(source) / "Respaldo"
            return vault if vault.is_dir() else None
        if not SHARE_ROOT.is_dir():
            return None
        path = Path(source)
        candidates = [c for c in SHARE_ROOT.iterdir() if c.is_dir()]
        # Prefer the shortest path when multiple volumes resolve to the
        # same directory (hardlinks / bind-mounts).
        candidates.sort(key=lambda c: len(str(c)))
        for volume in candidates:
            vault = volume / VOLUME_RESERVED_NAME
            if vault.is_dir() and (
                path == volume or str(path).startswith(str(volume) + "/")
            ):
                return vault
        return None

    def _dest_folder(self, source: str) -> Path:
        vault = self._vault_for_source(source)
        return vault if vault is not None else Path("")

    def _config_path(self, vault: Path) -> Path:
        return vault / CONFIG_FILENAME

    def _load_config(self, vault: Path) -> dict:
        try:
            payload = json.loads(self._config_path(vault).read_text("utf-8"))
            if isinstance(payload, dict) and isinstance(payload.get("jobs"), list):
                return payload
        except FileNotFoundError:
            pass
        except Exception as error:
            logger.warning("Config de respaldos ilegible en %s: %s", vault, error)
        return _empty_config()

    def _save_config(self, vault: Path, config: dict) -> None:
        vault.mkdir(parents=True, exist_ok=True)
        config.setdefault("schema", CONFIG_SCHEMA)
        config.setdefault("next_job_id", max((int(j.get("id") or 0) for j in config.get("jobs", [])), default=0) + 1)
        config.setdefault("jobs", [])
        path = self._config_path(vault)
        temp = path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temp, path)
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass

    def _all_jobs(self) -> list[Job]:
        jobs: list[Job] = []
        for vault in self._vaults():
            config = self._load_config(vault)
            for record in config.get("jobs", []):
                record = dict(_default_job(), **{k: v for k, v in record.items() if k in _default_job()})
                record["id"] = int(record.get("id") or 0)
                jobs.append(Job(record, vault=vault))
        jobs.sort(key=lambda j: j["id"])
        return jobs

    def _find_job(self, job_id: int) -> Job | None:
        for job in self._all_jobs():
            if int(job.get("id")) == int(job_id):
                return job
        return None

    def _save_job(self, job: Job) -> None:
        with self._lock:
            self._save_job_locked(job)

    def _save_job_locked(self, job: Job) -> None:
        config = self._load_config(job.vault)
        for index, record in enumerate(config.get("jobs", [])):
            if int(record.get("id") or 0) == int(job.get("id")):
                config["jobs"][index] = dict(job)
                break
        self._save_config(job.vault, config)

    def _repo_path(self, job: Job) -> Path:
        return job.vault / BACKUP_SUBDIR / f"job-{job.get('id')}"

    # ------------------------------------------------------------------
    # network share mounting
    # ------------------------------------------------------------------

    def _is_network_source(self, source: str) -> bool:
        """Detecta si la fuente es un share SMB de red o unidad de red montada."""
        return source.startswith("//") or source.startswith("\\\\") or "/stepad-network/" in source

    def _parse_network_source(self, source: str) -> dict | None:
        """Parsea un path SMB: //host/share/subfolder → {host, share, subfolder}."""
        clean = source.replace("\\", "/")
        if not clean.startswith("//"):
            return None
        parts = clean[2:].split("/")
        if len(parts) < 2:
            return None
        return {
            "host": parts[0],
            "share": parts[1],
            "subfolder": "/".join(parts[2:]) if len(parts) > 2 else "",
        }

    def _mount_point(self, job_id: int) -> Path:
        return Path(f"/mnt/stepad-backup-{job_id}")

    def _mount_share(self, job: Job, source: str) -> str | None:
        """Monta un share SMB como carpeta local. Retorna el punto de montaje o None si falla."""
        parsed = self._parse_network_source(source)
        if not parsed:
            return None
        mount_point = self._mount_point(job.get("id"))
        mount_point.mkdir(parents=True, exist_ok=True)
        user = job.get("smb_user", "")
        password = job.get("smb_password", "")
        opts = f"uid=0,gid=0,iocharset=utf8,vers=3.0"
        if user:
            opts = f"username={user},password={password},{opts}"
        else:
            opts = f"guest,{opts}"
        cmd = ["mount", "-t", "cifs", f"//{parsed['host']}/{parsed['share']}", str(mount_point), "-o", opts]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            if parsed["subfolder"]:
                return str(mount_point / parsed["subfolder"])
            return str(mount_point)
        else:
            logger.error("Failed to mount //%s/%s: %s", parsed["host"], parsed["share"], result.stderr)
            return None

    def _unmount_share(self, job: Job) -> None:
        """Desmonta un share SMB."""
        mount_point = self._mount_point(job.get("id"))
        if mount_point.exists():
            subprocess.run(["umount", str(mount_point)], capture_output=True, timeout=10)
            try:
                mount_point.rmdir()
            except Exception:
                pass

    def _repositories(self) -> list[Path]:
        """Todos los repositorios reales en las bóvedas privadas."""
        repos: list[Path] = []
        for vault in self._vaults():
            store = vault / BACKUP_SUBDIR
            if store.is_dir():
                for child in store.iterdir():
                    if child.is_dir() and child.name.startswith("job-"):
                        repos.append(child)
        return repos

    def _used_bytes(self) -> int:
        total = 0
        for repo in self._repositories():
            try:
                result = subprocess.run(
                    ["du", "-sb", str(repo)],
                    capture_output=True, text=True, timeout=30,
                )
                if result.returncode == 0:
                    total += int(result.stdout.split()[0])
            except Exception:
                pass
        return total

    def _vault_disk(self, vault: Path) -> dict | None:
        try:
            disk = shutil.disk_usage(vault)
            return {
                "path": str(vault),
                "total_bytes": disk.total,
                "used_bytes": disk.used,
                "free_bytes": disk.free,
                "free_pct": round(100 * disk.free / disk.total, 1) if disk.total else 100.0,
                "used_human": _human_bytes(disk.used),
                "total_human": _human_bytes(disk.total),
            }
        except Exception:
            return None

    # ------------------------------------------------------------------
    # restic commands
    # ------------------------------------------------------------------

    def _password(self) -> str:
        try:
            if ENV_FILE.exists():
                for line in ENV_FILE.read_text().splitlines():
                    if line.startswith(RESTIC_PASSWORD_KEY + "="):
                        value = line.split("=", 1)[1].strip().strip('"')
                        if value:
                            return value
        except Exception:
            pass
        import secrets

        key = secrets.token_hex(16)
        try:
            with open(ENV_FILE, "a") as file:
                file.write(f"\n{RESTIC_PASSWORD_KEY}={key}\n")
        except Exception as error:
            logger.warning("Could not persist restic password: %s", error)
        return key

    def _env(self) -> dict:
        return {
            **os.environ,
            "RESTIC_PASSWORD": self._password(),
            "LC_ALL": "C",
            "LANG": "C",
        }

    def _restic(self, job: Job, args: list[str], *, timeout: int = 3600) -> subprocess.CompletedProcess:
        command = ["restic", "-r", str(self._repo_path(job)), *args]
        return subprocess.run(
            command,
            env=self._env(),
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    def _ensure_repo(self, job: Job) -> None:
        repo = self._repo_path(job)
        repo.parent.mkdir(parents=True, exist_ok=True)
        if not repo.exists():
            repo.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(repo, 0o700)
            except Exception:
                pass
        # A fresh restic repo is initialized lazily on first successful run.
        probe = self._restic(job, ["snapshots", "--json"], timeout=60)
        if probe.returncode != 0:
            init = self._restic(job, ["init"], timeout=120)
            if init.returncode != 0:
                raise HTTPException(
                    status_code=500,
                    detail=f"No se pudo inicializar el repositorio restic: {init.stderr.strip()[:300]}",
                )

    def installed(self) -> bool:
        return bool(shutil.which("restic"))

    # ------------------------------------------------------------------
    # job CRUD + status
    # ------------------------------------------------------------------

    def list_jobs(self, db: Session = None) -> dict:
        jobs = self._all_jobs()

        vaults = self._vaults()
        repo_bytes = self._used_bytes()

        vaults_info = []
        total_free = 0
        total_size = 0
        for vault in vaults:
            info = self._vault_disk(vault)
            if info:
                vaults_info.append(info)
                total_free += info["free_bytes"]
                total_size += info["total_bytes"]

        free_pct = round(100 * total_free / total_size, 1) if total_size else 100.0

        return {
            "installed": self.installed(),
            "store_root": "Carpeta privada «Respaldo» de cada unidad",
            "store_used_bytes": repo_bytes,
            "store_used_human": _human_bytes(repo_bytes),
            "store_free_bytes": total_free,
            "store_free_pct": free_pct,
            "vaults": vaults_info,
            "jobs": [self._serialize(job) for job in jobs],
        }

    def _serialize(self, job: Job) -> dict:
        return {
            "id": job.get("id"),
            "name": job.get("name"),
            "source_path": job.get("source_path"),
            "destination_path": str(job.vault or self._dest_folder(job.get("source_path") or "")),
            "repository_path": str(self._repo_path(job)),
            "enabled": bool(job.get("enabled")),
            "schedule_mode": job.get("schedule_mode"),
            "folder_id": job.get("folder_id"),
            "schedule_hour": job.get("schedule_hour"),
            "schedule_minute": job.get("schedule_minute"),
            "schedule_times": self._times_list(job),
            "interval_minutes": job.get("interval_minutes"),
            "retention_count": job.get("retention_count"),
            "prune_free_pct": job.get("prune_free_pct"),
            "last_backup_at": job.get("last_backup_at"),
            "last_result": job.get("last_result"),
            "last_snapshot_id": job.get("last_snapshot_id"),
            "last_bytes": job.get("last_bytes"),
            "next_run": self._next_run(job),
        }

    def _next_run(self, job: Job) -> str | None:
        if not job.get("enabled"):
            return None
        if job.get("schedule_mode") == "interval":
            minutes = max(1, int(job.get("interval_minutes") or 60))
            return f"cada {minutes} min"
        if job.get("schedule_mode") == "on_change":
            return "al modificar archivos"
        times = self._times_list(job)
        if times:
            return ", ".join(times)
        return f"{int(job.get('schedule_hour') or 0):02d}:{int(job.get('schedule_minute') or 0):02d}"

    def _inode(self, path: str) -> int | None:
        """Devuelve el inodo de una ruta (para comparar hardlinks)."""
        try:
            return os.stat(path).st_ino
        except OSError:
            return None

    def _find_conflict(self, config: dict, source: str, exclude_id: int | None = None) -> tuple[dict | None, str]:
        """Busca un job cuya ruta se superponga con la fuente dada:
        coincidencia exacta → ('exact', record), subcarpeta/padre → ('parent_child', record),
        nada → (None, '')."""
        source_inode = self._inode(source)
        source_path = Path(source)
        for record in config.get("jobs", []):
            if exclude_id is not None and int(record.get("id") or 0) == int(exclude_id):
                continue
            existing = record.get("source_path") or ""
            if not existing:
                continue
            existing_inode = self._inode(existing)
            # Same inode → exact match (hardlink / same dir)
            if source_inode and existing_inode and source_inode == existing_inode:
                return record, "exact"
            existing_path = Path(existing)
            # Exact string match
            if source_path == existing_path:
                return record, "exact"
            # One is a parent of the other → conflict
            try:
                source_path.relative_to(existing_path)
                return record, "parent_child"
            except ValueError:
                pass
            try:
                existing_path.relative_to(source_path)
                return record, "parent_child"
            except ValueError:
                pass
        return None, ""

    def create_job(self, data, db: Session = None) -> dict:
        source = (getattr(data, "source_path", None) or "").strip()
        logger.info("create_job called: source=%s name=%s times=%s mode=%s",
                     source, getattr(data, "name", None),
                     getattr(data, "schedule_times", None),
                     getattr(data, "schedule_mode", None))

        # Validar fuente (local o red)
        is_network = self._is_network_source(source)
        if not is_network and (not source or not Path(source).is_dir()):
            logger.warning("create_job: source invalid: %s", source)
            raise HTTPException(
                status_code=400,
                detail="La ruta de origen no existe o no es un directorio.",
            )

        # Para fuentes de red, buscar vault en la propia unidad de red o en SHARE_ROOT
        if is_network:
            if "/stepad-network/" in source:
                vault = Path(source) / "Respaldo"
                if not vault.is_dir():
                    raise HTTPException(status_code=400, detail="La unidad de red no tiene carpeta Respaldo.")
            else:
                vault = self._vaults()[0] if self._vaults() else None
                if vault is None:
                    raise HTTPException(status_code=400, detail="No hay unidades disponibles para respaldos.")
        else:
            vault = self._vault_for_source(source)
            if vault is None or not vault.is_dir():
                logger.warning("create_job: no vault for source: %s (vault=%s)", source, vault)
                raise HTTPException(
                    status_code=400,
                    detail="La unidad del origen no tiene carpeta privada «Respaldo».",
                )
        with self._lock:
            config = self._load_config(vault)

            # Una sola programación por fuente: si la ruta ya tiene un job
            # (o un job padre/hijo) se edita ese en lugar de crear un duplicado.
            conflict, kind = self._find_conflict(config, source)
            if conflict is not None and kind == "parent_child":
                raise HTTPException(
                    status_code=400,
                    detail="Ya existe un respaldo para la ruta %s (o una carpeta padre/hijo). Solo se permite uno por carpeta." % (conflict.get("source_path") or ""),
                )
            if conflict is not None:
                job = Job(conflict, vault=vault)
            else:
                record = dict(_default_job())
                record.update({
                    "id": int(config.get("next_job_id") or 1),
                    "name": (getattr(data, "name", None) or "").strip() or Path(source).name,
                    "source_path": source,
                    "enabled": True if getattr(data, "enabled", None) is None else bool(data.enabled),
                    "smb_user": getattr(data, "smb_user", None) or "",
                    "smb_password": getattr(data, "smb_password", None) or "",
                })
                record["schedule_mode"] = (
                    data.schedule_mode
                    if getattr(data, "schedule_mode", None) in ("interval", "on_change")
                    else "daily"
                )
                name_exists = any(
                    r.get("name") == record["name"] and r.get("source_path") != source
                    for r in config.get("jobs", [])
                )
                if name_exists:
                    raise HTTPException(status_code=400, detail="Ya existe un respaldo con ese nombre.")
                config["next_job_id"] = int(record["id"]) + 1
                config.setdefault("jobs", []).append(record)
                job = Job(record, vault=vault)

            self._apply_job_data(job, data)
            config["jobs"] = [
                dict(r) for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id"))
            ]
            config["jobs"].append(dict(job))
            self._save_config(vault, config)

        self._dedupe_by_source(vault, source, job)
        self._sync_folder_policy(db, job)
        return self._serialize(self._find_job(job.get("id")) or job)

    def _apply_job_data(self, job: Job, data) -> None:
        if getattr(data, "name", None) is not None:
            job["name"] = (data.name or "").strip() or job.get("name") or ""
        if getattr(data, "smb_user", None) is not None:
            job["smb_user"] = (data.smb_user or "").strip()
        if getattr(data, "smb_password", None) is not None:
            job["smb_password"] = data.smb_password or ""
        if getattr(data, "enabled", None) is not None:
            job["enabled"] = bool(data.enabled)
        if getattr(data, "schedule_mode", None) is not None:
            if data.schedule_mode not in ("daily", "interval", "on_change"):
                raise HTTPException(status_code=400, detail="schedule_mode inválido.")
            job["schedule_mode"] = data.schedule_mode
        if getattr(data, "schedule_hour", None) is not None:
            job["schedule_hour"] = int(data.schedule_hour)
        if getattr(data, "schedule_minute", None) is not None:
            job["schedule_minute"] = int(data.schedule_minute)
        if getattr(data, "schedule_times", None) is not None:
            normalized = self._normalize_times(data.schedule_times)
            if normalized:
                job["schedule_times"] = normalized
                job["schedule_mode"] = "daily"
            elif job.get("schedule_mode") == "daily":
                job["schedule_times"] = None
        if getattr(data, "interval_minutes", None) is not None:
            job["interval_minutes"] = max(15, int(data.interval_minutes))
        if getattr(data, "retention_count", None) is not None:
            job["retention_count"] = max(1, int(data.retention_count))
        if getattr(data, "prune_free_pct", None) is not None:
            job["prune_free_pct"] = max(5, min(80, int(data.prune_free_pct)))

    def _dedupe_by_source(self, vault: Path, source: str, keep: Job) -> None:
        """Una sola programación por fuente: elimina duplicados y subcarpetas
        que queden cubiertas por el job mantenido."""
        source_inode = self._inode(source)
        source_path = Path(source)
        with self._lock:
            config = self._load_config(vault)
            kept: list[dict] = []
            for record in config.get("jobs", []):
                if int(record.get("id") or 0) == int(keep.get("id") or 0):
                    kept.append(record)
                    continue
                existing_source = record.get("source_path") or ""
                if not existing_source:
                    kept.append(record)
                    continue
                existing_inode = self._inode(existing_source)
                # Same inode → duplicate (hardlink)
                if source_inode and existing_inode and source_inode == existing_inode:
                    dup = Job(record, vault=vault)
                    self._remove_repo(dup)
                    continue
                existing_path = Path(existing_source)
                # Keep if not related (no parent/child)
                is_related = False
                try:
                    source_path.relative_to(existing_path)
                    is_related = True
                except ValueError:
                    pass
                try:
                    existing_path.relative_to(source_path)
                    is_related = True
                except ValueError:
                    pass
                if is_related:
                    dup = Job(record, vault=vault)
                    self._remove_repo(dup)
                    continue
                kept.append(record)
            config["jobs"] = kept
            self._save_config(vault, config)

    def update_job(self, job_id: int, data, db: Session = None) -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        new_source = getattr(data, "source_path", None)
        if new_source is not None:
            source = (new_source or "").strip()
            if not source or not Path(source).is_dir():
                raise HTTPException(status_code=400, detail="La ruta de origen no es válida.")
            vault = self._vault_for_source(source)
            if vault is None or not vault.is_dir():
                raise HTTPException(status_code=400, detail="La unidad no tiene carpeta Respaldo.")
            config = self._load_config(vault)
            conflict, kind = self._find_conflict(config, source, exclude_id=job_id)
            if conflict is not None and kind == "parent_child":
                raise HTTPException(
                    status_code=400,
                    detail=f"Ya existe un respaldo para la ruta {conflict.get('source_path')} (o una carpeta padre/hijo).",
                )
            job["source_path"] = source
            job.vault = vault
        with self._lock:
            self._apply_job_data(job, data)
            self._save_job_locked(job)
        if new_source is not None:
            self._dedupe_by_source(job.vault, job["source_path"], job)
        self._sync_folder_policy(db, job)
        return self._serialize(job)

    def delete_job(self, job_id: int) -> None:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        with self._lock:
            config = self._load_config(job.vault)
            config["jobs"] = [
                r for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            self._save_config(job.vault, config)
        self._remove_repo(job)

    def delete_jobs_for_folder(self, folder_id: int) -> None:
        """Elimina todos los jobs de una carpeta (cuando la carpeta se borra)."""
        for vault in self._vaults():
            config = self._load_config(vault)
            victims = [
                r for r in config.get("jobs", []) if int(r.get("folder_id") or 0) == int(folder_id or 0)
            ]
            if not victims:
                continue
            for record in victims:
                self._remove_repo(Job(record, vault=vault))
            alive = [
                r for r in config.get("jobs", []) if int(r.get("folder_id") or 0) != int(folder_id or 0)
            ]
            with self._lock:
                config["jobs"] = alive
                self._save_config(vault, config)

    def delete_jobs_for_source(self, source_path: str) -> None:
        """Elimina todos los jobs que apunten a una ruta de origen específica."""
        if not source_path:
            return
        for vault in self._vaults():
            config = self._load_config(vault)
            victims = [
                r for r in config.get("jobs", []) if r.get("source_path") == source_path
            ]
            if not victims:
                continue
            for record in victims:
                self._remove_repo(Job(record, vault=vault))
            alive = [
                r for r in config.get("jobs", []) if r.get("source_path") != source_path
            ]
            with self._lock:
                config["jobs"] = alive
                self._save_config(vault, config)

    def _remove_repo(self, job: Job) -> None:
        repo = self._repo_path(job)
        if repo.exists():
            try:
                shutil.rmtree(repo)
            except Exception as error:
                logger.warning("Could not remove repo %s: %s", repo, error)

    # ------------------------------------------------------------------
    # folder policy bridge (the config file is the source of truth; the
    # folder fields in the DB are only a read-only reflection)
    # ------------------------------------------------------------------

    def _find_folder_for_source(self, db: Session, source: str) -> NetworkShareFolder | None:
        if db is None or not source:
            return None
        from backend.shares.services.network_share_service import NetworkShareService

        svc = NetworkShareService()
        for folder in db.query(NetworkShareFolder).all():
            try:
                if svc._folder_path(db, folder) == source:
                    return folder
            except Exception:
                continue
        return None

    def _sync_folder_policy(self, db: Session, job: Job) -> None:
        """Refleja la programación del job (fuente de verdad) en la carpeta
        de la base de datos únicamente como caché de la interfaz."""
        folder = self._find_folder_for_source(db, job.get("source_path") or "")
        if folder is None:
            return
        folder.backup_mode = "on_change" if job.get("schedule_mode") == "on_change" else "times"
        folder.backup_retention = max(1, int(job.get("retention_count") or 7))
        if job.get("schedule_mode") == "daily":
            times = self._times_list(job)
            if times:
                folder.backup_times_per_day = max(1, min(24, len(times)))
        else:
            folder.backup_times_per_day = max(
                1, min(24, int(folder.backup_times_per_day or 1))
            )
        db.commit()

    def ensure_folder_job(self, db: Session, folder, source: str) -> None:
        """Convierte la política de respaldo de una carpeta en un job del
        archivo de configuración (bóveda). «off» elimina el job."""
        source = (source or "").strip()
        vault = self._vault_for_source(source) if source else None
        if folder is not None and getattr(folder, "backup_mode", None) == "off":
            if vault is not None and vault.is_dir():
                with self._lock:
                    config = self._load_config(vault)
                    victims = [
                        r for r in config.get("jobs", []) if r.get("source_path") == source
                    ]
                    if victims:
                        for record in victims:
                            self._remove_repo(Job(record, vault=vault))
                        config["jobs"] = [
                            r for r in config.get("jobs", []) if r.get("source_path") != source
                        ]
                        self._save_config(vault, config)
            return
        if vault is None or not vault.is_dir() or not source:
            return

        with self._lock:
            config = self._load_config(vault)
            existing = next(
                (r for r in config.get("jobs", []) if r.get("source_path") == source),
                None,
            )
            if existing is not None:
                job = Job(existing, vault=vault)
                job["enabled"] = True
                job["retention_count"] = max(
                    1, int(getattr(folder, "backup_retention", None) or job.get("retention_count") or 7)
                )
                job["folder_id"] = getattr(folder, "id", None)
            else:
                record = dict(_default_job())
                record.update({
                    "id": int(config.get("next_job_id") or 1),
                    "name": f"folder-{getattr(folder, 'id', '')}-{getattr(folder, 'name', '')}",
                    "source_path": source,
                    "enabled": True,
                    "folder_id": getattr(folder, "id", None),
                    "retention_count": max(1, int(getattr(folder, "backup_retention", None) or 7)),
                })
                if getattr(folder, "backup_mode", None) == "on_change":
                    record["schedule_mode"] = "on_change"
                    record["interval_minutes"] = None
                else:
                    record["schedule_mode"] = "interval"
                    times = max(1, min(24, int(getattr(folder, "backup_times_per_day", None) or 1)))
                    record["interval_minutes"] = max(15, 1440 // times)
                config["next_job_id"] = int(record["id"]) + 1
                config.setdefault("jobs", []).append(record)
                job = Job(record, vault=vault)

            config["jobs"] = [
                dict(r) for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            config["jobs"].append(dict(job))
            self._save_config(vault, config)

        self._dedupe_by_source(vault, source, job)
        self._sync_folder_policy(db, job)

    # ------------------------------------------------------------------
    # run / snapshots / files / download
    # ------------------------------------------------------------------

    def run_backup(self, job_id: int) -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")

        # Omitir si nada cambió desde el último respaldo real: así un horario o
        # un «Ejecutar ahora» sin modificaciones no crea versiones vacías.
        source = Path(job.get("source_path") or "")
        if source.is_dir():
            current = self._tree_signature(source)
            baseline = job.get("tree_hash")
            if baseline and current and current == baseline:
                detail = "Sin cambios desde el último respaldo. No se creó versión."
                job["last_result"] = detail[:500]
                job["last_backup_at"] = datetime.utcnow().isoformat() + "Z"
                self._save_job(job)
                return {
                    "success": True,
                    "skipped": True,
                    "message": detail,
                    "bytes_added": 0,
                    "bytes_added_human": "0 B",
                }

        with self._lock:
            if job.get("id") in self._running_jobs:
                return {"success": False, "message": "El respaldo ya está en ejecución."}
            self._running_jobs.add(job.get("id"))
        try:
            return self._run_backup_locked(job)
        finally:
            with self._lock:
                self._running_jobs.discard(job.get("id"))

    def _run_backup_locked(self, job: Job) -> dict:
        if not self.installed():
            raise HTTPException(
                status_code=400,
                detail="restic no está instalado. Instala el paquete: apt-get install -y restic",
            )
        source = Path(job.get("source_path") or "")
        mounted = None

        # Mount network share if needed
        if self._is_network_source(str(source)):
            mounted = self._mount_share(job, str(source))
            if not mounted:
                detail = "No se pudo montar el share de red. Verifique credenciales y conectividad."
                job["last_result"] = detail[:500]
                self._save_job(job)
                return {"success": False, "message": detail}
            source = Path(mounted)

        if not source.is_dir():
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            job["last_result"] = detail[:500]
            self._save_job(job)
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        try:
            self._ensure_repo(job)
        except HTTPException:
            if mounted:
                self._unmount_share(job)
            raise

        args = [
            "backup",
            str(source),
            "--host", "stepad",
            "--tag", f"job:{job.get('id')}",
            "--exclude-caches",
            "--json",
        ]
        try:
            result = self._restic(job, args, timeout=7200)
        except subprocess.TimeoutExpired:
            detail = "El respaldo tardó demasiado y se canceló."
            job["last_result"] = detail
            self._save_job(job)
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}
        except Exception as error:
            detail = f"Error ejecutando restic: {error}"
            job["last_result"] = detail[:500]
            self._save_job(job)
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        if mounted:
            self._unmount_share(job)

        if result.returncode != 0:
            detail = f"restic falló: {result.stderr.strip()[:400]}"
            job["last_result"] = detail
            self._save_job(job)
            return {"success": False, "message": detail}

        snapshot_id = None
        bytes_processed = 0
        for line in (result.stdout or "").splitlines():
            try:
                payload = json.loads(line)
            except Exception:
                continue
            if payload.get("message_type") == "summary":
                snapshot_id = payload.get("snapshot_id")
                bytes_processed = int(payload.get("total_bytes_processed") or 0)
                bytes_added = int(
                    payload.get("total_bytes_added_packed")
                    or payload.get("total_bytes_added")
                    or 0
                )
            elif payload.get("message_type") == "snapshot":
                snapshot_id = payload.get("snapshot_id") or payload.get("id") or snapshot_id

        job["last_backup_at"] = datetime.utcnow().isoformat() + "Z"
        job["last_snapshot_id"] = (snapshot_id or "")[:64]
        job["last_bytes"] = bytes_added
        fresh_hash = self._tree_signature(source)
        if fresh_hash is not None:
            job["tree_hash"] = fresh_hash
        job["last_result"] = (
            f"OK  snapshot {snapshot_id[:12] if snapshot_id else 'n/a'} "
            f"+{_human_bytes(bytes_added)} nuevos · {_human_bytes(bytes_processed)} escaneados"
        )
        job["source_missing_alerted"] = False
        self._save_job(job)

        pruned = self._maybe_prune(job)

        return {
            "success": True,
            "snapshot_id": snapshot_id,
            "snapshot_short": snapshot_id[:12] if snapshot_id else None,
            "bytes_processed": bytes_processed,
            "bytes_human": _human_bytes(bytes_processed),
            "bytes_added": bytes_added,
            "bytes_added_human": _human_bytes(bytes_added),
            "pruned": pruned,
        }

    def list_snapshots(self, job_id: int) -> list[dict]:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            return []
        try:
            self._ensure_repo(job)
        except HTTPException:
            return []
        result = self._restic(job, ["snapshots", "--json"], timeout=120)
        if result.returncode != 0:
            return []
        try:
            rows = json.loads(result.stdout or "[]")
        except Exception:
            rows = []
        snapshots = []
        for row in rows:
            summary = row.get("summary") or {}
            data_added = summary.get("data_added") or summary.get("total_bytes_added_packed") or 0
            snapshots.append({
                "id": row.get("id", ""),
                "short_id": row.get("short_id", ""),
                "time_iso": to_iso_utc(self._parse_restic_time(row.get("time"))),
                "time": (row.get("time") or "")[:19].replace("T", " "),
                "hostname": row.get("hostname"),
                "tags": row.get("tags") or [],
                "paths": row.get("paths") or [],
                "files_new": summary.get("files_new"),
                "files_changed": summary.get("files_changed"),
                "files_unmodified": summary.get("files_unmodified"),
                "data_added": data_added,
                "data_added_human": _human_bytes(data_added),
                "total_bytes_processed": summary.get("total_bytes_processed"),
                "total_bytes_human": _human_bytes(summary.get("total_bytes_processed")),
            })
        snapshots.sort(key=lambda s: s.get("time") or "", reverse=True)
        return snapshots

    def _parse_restic_time(self, value) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except Exception:
            try:
                return datetime.fromtimestamp(value)
            except Exception:
                return None

    def _normalize_times(self, value) -> str | None:
        """Acepta list[str] ['HH:MM','HH:MM'] o str 'HH:MM,HH:MM'.
        Normaliza y valida horas 00-23 y minutos 00-59. Devuelve
        None si no hay horas validas."""
        if value is None:
            return None
        if isinstance(value, str):
            raw = [t.strip() for t in (value or "").split(",")]
        else:
            raw = [str(t).strip() for t in value]
        hours = []
        for part in raw:
            if not part:
                continue
            try:
                hh, mm = part.split(":")
                hh = int(hh)
                mm = int(mm)
            except Exception:
                continue
            if 0 <= hh <= 23 and 0 <= mm <= 59:
                hours.append(f"{hh:02d}:{mm:02d}")
        hours = sorted(set(hours))
        return ",".join(hours) if hours else None

    def _times_list(self, job: Job) -> list:
        """Devuelve la lista de horas HH:MM del job (schedule_times o el
        schedule_hour:minute clásico)."""
        times = []
        for part in (job.get("schedule_times") or "").split(","):
            part = part.strip()
            if part:
                times.append(part)
        if not times:
            times = [f"{int(job.get('schedule_hour') or 0):02d}:{int(job.get('schedule_minute') or 0):02d}"]
        return times

    def _parse_job_time(self, value) -> datetime | None:
        if not value:
            return None
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if parsed.tzinfo is not None:
                parsed = parsed.replace(tzinfo=None)
            return parsed
        except Exception:
            return None

    def is_due(self, job: Job, now: datetime) -> bool:
        if not job.get("enabled"):
            return False
        if job.get("schedule_mode") == "interval":
            # N backups a day -> run every 24h/N (interval_minutes).
            last = self._parse_job_time(job.get("last_backup_at"))
            if last is None:
                return True
            interval = max(1, int(job.get("interval_minutes") or 60))
            elapsed = (now - last).total_seconds()
            return elapsed >= interval * 60
        if job.get("schedule_mode") == "on_change":
            # Handled by the change watcher, never by the clock.
            return False
        # daily: run at each configured time, once per time per day.
        times = self._times_list(job)
        minute_of_day = now.hour * 60 + now.minute
        last = self._parse_job_time(job.get("last_backup_at"))
        # Elige la hora más reciente que ya pasó hoy (>= now).
        reached = None
        for raw in times:
            try:
                hh, mm = (int(x) for x in raw.split(":"))
            except Exception:
                continue
            t = hh * 60 + mm
            if t <= minute_of_day:
                reached = t if reached is None else max(reached, t)
        if reached is None:
            return False
        if last is None:
            return True
        # Si ya se respaldó hoy a esa hora (o después), no repetir.
        if last.date() == now.date():
            last_min = last.hour * 60 + last.minute
            if last_min >= reached:
                return False
        return True

    def _tree_signature(self, root: Path) -> str | None:
        """Snapshot of (path, mtime, size) so on-change backups can detect edits."""
        try:
            entries = []
            for path in sorted(root.rglob("*")):
                if path.is_dir():
                    continue
                stat = path.stat()
                rel = path.relative_to(root).as_posix()
                entries.append(f"{rel}:{stat.st_mtime_ns}:{stat.st_size}")
            return hashlib.sha256(
                "\n".join(entries).encode("utf-8", "replace")
            ).hexdigest()
        except OSError:
            return None

    def _maybe_run_on_change(self, job: Job) -> None:
        """Backup the source only when files changed since the last successful run."""
        if job.get("schedule_mode") != "on_change" or not job.get("enabled"):
            return
        source = Path(job.get("source_path") or "")
        if not source.is_dir():
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            if job.get("last_result") != detail:
                job["last_result"] = detail
                self._save_job(job)
            return

        signature = self._tree_signature(source)
        if signature is None:
            return
        if job.get("change_hash") is None:
            # First baseline: we don't run an unsolicited backup, we just
            # record the current state. From the next change on, we back up.
            job["change_hash"] = signature
            self._save_job(job)
            return
        if signature == job.get("change_hash"):
            return
        try:
            result = self.run_backup(job.get("id"))
            # Refresh the baseline right after a successful run so the same
            # tree is not backed up again on the next tick.
            fresh = self._tree_signature(source)
            if fresh is not None:
                job["change_hash"] = fresh
                self._save_job(job)
            state = result.get("message", result)
            logger.info("On-change backup %s: %s", job.get("name"), state)
        except HTTPException as error:
            logger.warning(
                "On-change backup %s failed: %s", job.get("name"), error.detail
            )

    def _maybe_prune(self, job: Job) -> dict | None:
        repo = self._repo_path(job)
        if not repo.parent.exists():
            return None
        usage = shutil.disk_usage(repo.parent)
        if not usage.total:
            return None
        free_pct = 100 * usage.free / usage.total
        if free_pct >= float(job.get("prune_free_pct") or 15):
            return None
        return self.prune(job.get("id"))

    def prune(self, job_id: int) -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        retention = max(1, int(job.get("retention_count") or 7))
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        forget = self._restic(job, ["forget", "--keep-last", str(retention), "--prune"], timeout=7200)
        if forget.returncode != 0:
            logger.error("restic forget/prune failed: %s", forget.stderr)
        usage = shutil.disk_usage(self._repo_path(job).parent)
        free_pct = round(100 * usage.free / usage.total, 1) if usage.total else 100.0
        detail = (
            f"Se conservan las {retention} versiones más recientes y se "
            f"compactó el repositorio. Espacio libre: {free_pct}%."
            if forget.returncode == 0
            else f"La limpieza no terminó bien: {forget.stderr.strip()[:300]}"
        )
        job["last_result"] = detail[:500]
        self._save_job(job)
        return {"success": forget.returncode == 0, "message": detail, "free_pct": free_pct}

    def list_files(self, job_id: int, snapshot_id: str, prefix: str = "") -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"restic ls falló: {result.stderr.strip()[:300]}",
            )
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception:
            entries = []

        root = (job.get("source_path") or "/").rstrip("/")
        root_key = root.lstrip("/")
        prefix = (prefix or "").strip("/")
        base = prefix.split("/") if prefix else []
        folders: set[str] = set()
        files: list[dict] = []
        for entry in entries:
            rel = (entry.get("path") or "").lstrip("/")
            if root != "/":
                if rel == root_key:
                    continue
                if not rel.startswith(root_key + "/"):
                    continue
                rel = rel[len(root_key) + 1:]
            if not rel:
                continue
            parts = rel.split("/")
            if len(parts) != len(base) + 1:
                continue
            if parts[:len(base)] != base:
                continue
            item = parts[len(base)]
            full = f"{prefix}/{item}" if prefix else item
            if entry.get("type") == "dir":
                folders.add(item)
            else:
                files.append({
                    "name": item,
                    "path": full,
                    "size": entry.get("size"),
                    "size_human": _human_bytes(entry.get("size")),
                    "type": "file",
                })
            if len(folders) + len(files) > 3000:
                break

        def sort_key(item):
            return (item.get("name") or "").lower()

        return {
            "snapshot": snapshot_id,
            "prefix": prefix,
            "directories": sorted(folders, key=str.lower),
            "files": sorted(files, key=sort_key),
        }

    def _entry_is_dir(self, job: Job, snapshot_id: str, path: str) -> bool:
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            return False
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception:
            return False
        root = (job.get("source_path") or "/").rstrip("/")
        wanted = "/".join([
            seg for seg in [root, path.strip("/")] if seg.strip("/")
        ])
        for entry in entries:
            if (entry.get("path") or "").rstrip("/") == wanted.rstrip("/"):
                return entry.get("type") == "dir"
        return False

    @staticmethod
    def _parse_ndjson(stdout: str) -> list[dict]:
        rows = []
        for line in (stdout or "").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        return rows

    def download(self, job_id: int, snapshot_id: str, path: str):
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        root = (job.get("source_path") or "/").rstrip("/")
        rel = path.strip("/")
        abs_path = f"{root}/{rel}" if rel else root
        is_dir = self._entry_is_dir(job, snapshot_id, path)

        args = ["dump", snapshot_id, abs_path]
        if is_dir:
            args = ["dump", "--archive=tar", snapshot_id, abs_path]

        result = subprocess.run(
            ["restic", "-r", str(self._repo_path(job)), *args],
            env=self._env(),
            capture_output=True,
            timeout=3600,
        )
        if result.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"restic dump falló: {result.stderr.strip()[:300]}",
            )
        return result.stdout, is_dir, path

    # ------------------------------------------------------------------
    # reconciliation (config file is the source of truth; raise alert when
    # the source folder disappears)
    # ------------------------------------------------------------------

    def _reconcile(self, db: Session) -> None:
        for job in self._all_jobs():
            self._reconcile_job_source(db, job)
        self._gc_orphan_repos()

    def _reconcile_job_source(self, db: Session, job: Job) -> None:
        """Levanta una alerta cuando la carpeta origen ya no existe y la
        resuelve cuando vuelve a estar disponible."""
        source = Path(job.get("source_path") or "")
        missing = not source.is_dir()
        flagged = bool(job.get("source_missing_alerted"))

        if missing and not flagged:
            job["source_missing_alerted"] = True
            self._save_job(job)
            title = f"Origen de respaldo no encontrado: {job.get('name')}"
            message = (
                f"El respaldo «{job.get('name')}» no pudo comprobar su carpeta "
                f"de origen ({job.get('source_path')}). La carpeta o unidad no "
                f"está montada; el respaldo queda a la espera hasta que el "
                f"origen vuelva a estar disponible."
            )
            try:
                db.rollback()
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type=SOURCE_MISSING_ALERT,
                    severity="warning",
                    title=title,
                    message=message[:500],
                )
                db.commit()
                logger.warning("Alerta: %s", title)
            except Exception as error:
                logger.warning("Could not create source-missing alert: %s", error)
            return

        if not missing and flagged:
            job["source_missing_alerted"] = False
            self._save_job(job)
            logger.info("Origen de respaldo restaurado: %s", job.get("name"))

    def _gc_orphan_repos(self) -> None:
        """Elimina repositorios que ya no pertenecen a ningún job."""
        expected = {self._repo_path(job) for job in self._all_jobs()}
        for repo in self._repositories():
            if repo in expected:
                continue
            try:
                shutil.rmtree(repo)
                logger.info("Se eliminó un repositorio huérfano: %s", repo)
            except OSError as error:
                logger.warning(
                    "No se pudo eliminar el repositorio huérfano %s: %s",
                    repo,
                    error,
                )

    # ------------------------------------------------------------------
    # scheduler
    # ------------------------------------------------------------------

    def start_scheduler(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop = False
            self._thread = threading.Thread(
                target=self._loop,
                name="share-backup-scheduler",
                daemon=True,
            )
            self._thread.start()
            logger.info("Share backup scheduler started.")

    def stop_scheduler(self) -> None:
        self._stop = True
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=5)
        self._thread = None
        logger.info("Share backup scheduler stopped.")

    def _loop(self) -> None:
        for _ in range(4):
            if self._stop:
                return
            time.sleep(1)
        while not self._stop:
            try:
                self._tick()
            except Exception as error:
                logger.exception("Share backup tick failed: %s", error)
            for _ in range(POLL_SECONDS):
                if self._stop:
                    return
                time.sleep(1)

    def _tick(self) -> None:
        db = SessionLocal()
        try:
            if time.monotonic() - self._last_reconcile >= RECONCILE_SECONDS:
                self._reconcile(db)
                self._last_reconcile = time.monotonic()
            for job in self._all_jobs():
                if not job.get("enabled"):
                    continue
                if job.get("schedule_mode") == "on_change":
                    self._maybe_run_on_change(job)
                    continue
                if not self.is_due(job, datetime.utcnow()):
                    continue
                try:
                    result = self.run_backup(job.get("id"))
                    logger.info("Scheduled backup %s: %s", job.get("name"), result.get("message", result))
                except HTTPException as error:
                    logger.warning("Scheduled backup %s failed: %s", job.get("name"), error.detail)
        finally:
            db.close()