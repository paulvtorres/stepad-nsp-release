from datetime import datetime

from sqlalchemy import func, Integer
from sqlalchemy.orm import Session

from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.network.devices.models.network_device import NetworkDevice


class DnsQueryLogRepository:


    def save_many(
        self,
        db: Session,
        records: list[DnsQueryLog]
    ):

        db.bulk_save_objects(records)

        db.commit()


    def find_summary(
        self,
        db: Session,
        start: datetime | None = None,
        end: datetime | None = None,
        device_id: int | None = None,
        domain_contains: str | None = None
    ):
        """
        The "totalizado" view: one row per (device, domain), with
        visit count and first/last seen -- exactly "máquina 1 navegó
        en youtube desde el día X hasta el día Y, N veces".
        """

        query = (
            db.query(
                DnsQueryLog.device_id,
                DnsQueryLog.device_hostname,
                NetworkDevice.hostname,
                NetworkDevice.ip_address,
                DnsQueryLog.client_ip,
                DnsQueryLog.domain,
                func.count(DnsQueryLog.id).label("visit_count"),
                func.min(DnsQueryLog.queried_at).label("first_seen"),
                func.max(DnsQueryLog.queried_at).label("last_seen"),
                func.sum(
                    func.cast(DnsQueryLog.blocked, Integer)
                ).label("blocked_count"),
                func.count(
                    func.distinct(
                        func.date_trunc(
                            "minute",
                            DnsQueryLog.queried_at
                        )
                    )
                ).label("active_minutes")
            )
            .outerjoin(
                NetworkDevice,
                NetworkDevice.id == DnsQueryLog.device_id
            )
            .group_by(
                DnsQueryLog.device_id,
                DnsQueryLog.device_hostname,
                NetworkDevice.hostname,
                NetworkDevice.ip_address,
                DnsQueryLog.client_ip,
                DnsQueryLog.domain
            )
            .order_by(
                func.max(DnsQueryLog.queried_at).desc()
            )
        )

        if start:

            query = query.filter(DnsQueryLog.queried_at >= start)

        if end:

            query = query.filter(DnsQueryLog.queried_at <= end)

        if device_id:

            query = query.filter(DnsQueryLog.device_id == device_id)

        if domain_contains:

            query = query.filter(
                DnsQueryLog.domain.ilike(f"%{domain_contains}%")
            )

        return query.all()

    def find_device_active_minutes(
        self,
        db: Session,
        start: datetime | None = None,
        end: datetime | None = None,
        device_id: int | None = None,
    ) -> dict[int | None, int]:
        """
        Minutos distintos con actividad DNS por equipo (sin duplicar
        el mismo minuto entre dominios distintos).
        """

        query = (
            db.query(
                DnsQueryLog.device_id,
                func.count(
                    func.distinct(
                        func.date_trunc(
                            "minute",
                            DnsQueryLog.queried_at,
                        )
                    )
                ).label("active_minutes"),
            )
            .group_by(DnsQueryLog.device_id)
        )

        if start:

            query = query.filter(DnsQueryLog.queried_at >= start)

        if end:

            query = query.filter(DnsQueryLog.queried_at <= end)

        if device_id:

            query = query.filter(DnsQueryLog.device_id == device_id)

        return {
            row.device_id: int(row.active_minutes or 0)
            for row in query.all()
        }


    def delete_older_than(
        self,
        db: Session,
        cutoff: datetime
    ):

        deleted = (
            db.query(DnsQueryLog)
            .filter(DnsQueryLog.queried_at < cutoff)
            .delete(synchronize_session=False)
        )

        db.commit()

        return deleted


    def find_blocked_recent(
        self,
        db: Session,
        start: datetime,
        limit: int = 20
    ):
        """
        Recent blocked queries (for the "important notifications"
        section of the email report).
        """

        rows = (
            db.query(
                DnsQueryLog.device_id,
                NetworkDevice.hostname,
                NetworkDevice.ip_address,
                DnsQueryLog.domain,
                DnsQueryLog.queried_at
            )
            .join(
                NetworkDevice,
                NetworkDevice.id == DnsQueryLog.device_id,
                isouter=True
            )
            .filter(
                DnsQueryLog.blocked.is_(True),
                DnsQueryLog.queried_at >= start
            )
            .order_by(DnsQueryLog.queried_at.desc())
            .limit(limit)
            .all()
        )

        return [
            {
                "device_id": row.device_id,
                "device_name": row.hostname or row.ip_address or "Desconocido",
                "domain": row.domain,
                "queried_at": row.queried_at,
                "blocked_count": 1
            }
            for row in rows
        ]

    def find_totals(
        self,
        db: Session,
        start: datetime | None = None
    ):

        query = db.query(
            func.count(DnsQueryLog.id).label("total"),
            func.sum(
                func.cast(DnsQueryLog.blocked, Integer)
            ).label("blocked")
        )

        if start:

            query = query.filter(DnsQueryLog.queried_at >= start)

        row = query.one()

        return {
            "total": row.total or 0,
            "blocked": row.blocked or 0
        }


    def top_blocked_domains(
        self,
        db: Session,
        start: datetime | None = None,
        limit: int = 10
    ):

        query = (
            db.query(
                DnsQueryLog.domain,
                func.count(DnsQueryLog.id).label("attempts"),
                func.max(DnsQueryLog.queried_at).label("last_seen")
            )
            .filter(DnsQueryLog.blocked.is_(True))
        )

        if start:

            query = query.filter(DnsQueryLog.queried_at >= start)

        return (
            query
            .group_by(DnsQueryLog.domain)
            .order_by(func.count(DnsQueryLog.id).desc())
            .limit(limit)
            .all()
        )


    def top_blocked_devices(
        self,
        db: Session,
        start: datetime | None = None,
        limit: int = 10
    ):

        query = (
            db.query(
                DnsQueryLog.device_id,
                NetworkDevice.hostname,
                NetworkDevice.ip_address,
                func.count(DnsQueryLog.id).label("attempts")
            )
            .filter(DnsQueryLog.blocked.is_(True))
            .outerjoin(
                NetworkDevice,
                NetworkDevice.id == DnsQueryLog.device_id
            )
        )

        if start:

            query = query.filter(DnsQueryLog.queried_at >= start)

        return (
            query
            .group_by(
                DnsQueryLog.device_id,
                NetworkDevice.hostname,
                NetworkDevice.ip_address
            )
            .order_by(func.count(DnsQueryLog.id).desc())
            .limit(limit)
            .all()
        )


    def recent_blocked(
        self,
        db: Session,
        start: datetime | None = None,
        limit: int = 15
    ):

        query = (
            db.query(
                DnsQueryLog.domain,
                DnsQueryLog.client_ip,
                NetworkDevice.hostname,
                DnsQueryLog.queried_at
            )
            .filter(DnsQueryLog.blocked.is_(True))
            .outerjoin(
                NetworkDevice,
                NetworkDevice.id == DnsQueryLog.device_id
            )
        )

        if start:

            query = query.filter(DnsQueryLog.queried_at >= start)

        return (
            query
            .order_by(DnsQueryLog.queried_at.desc())
            .limit(limit)
            .all()
        )
