import { useEffect, useState } from "react";

import { getDhcpLogs } from "../../../services/api";


function DhcpLogPanel() {

    const [lines, setLines] = useState([]);

    const [search, setSearch] = useState("");

    const [filter, setFilter] = useState("");

    const [loading, setLoading] = useState(false);

    const [error, setError] = useState("");


    async function load(activeFilter = filter) {

        setLoading(true);

        setError("");

        try {

            const data = await getDhcpLogs(300, activeFilter);

            setLines(data.lines || []);

        } catch (err) {

            setError(err.message || "No se pudieron leer los logs DHCP.");

            setLines([]);

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {

        load();

        const timer = setInterval(() => load(filter), 15000);

        return () => clearInterval(timer);

    }, [filter]);


    function handleSearch(event) {

        event.preventDefault();

        setFilter(search.trim());

        load(search.trim());

    }


    return (

        <div className="registry-panel dhcp-log-panel">

            <h3>Registro DHCP (dnsmasq)</h3>

            <p className="registry-hint">
                Actividad reciente del servidor DHCP: ofertas, asignaciones,
                rechazos y equipos sin dirección disponible. Hora del servidor
                (Ecuador).
            </p>

            <form className="dhcp-log-toolbar" onSubmit={handleSearch}>

                <input
                    type="search"
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Filtrar por MAC, IP o texto (ej. VENTAS, ninguna dirección)"
                />

                <button type="submit" className={`secondary-button${loading ? " btn-busy" : ""}`} disabled={loading}>
                    Filtrar
                </button>

                <button
                    type="button"
                    className={`secondary-button${loading ? " btn-busy" : ""}`}
                    onClick={() => {
                        setSearch("");
                        setFilter("");
                        load("");
                    }}
                    disabled={loading}
                >
                    Limpiar
                </button>

                <button
                    type="button"
                    className={`secondary-button${loading ? " btn-busy" : ""}`}
                    onClick={() => load(filter)}
                    disabled={loading}
                >
                    Actualizar
                </button>

            </form>

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

            <pre className="dhcp-log-view">
                {
                    lines.length === 0 && !loading
                        ? "Sin entradas recientes en el log DHCP."
                        : lines.join("\n")
                }
            </pre>

        </div>

    );

}


export default DhcpLogPanel;
