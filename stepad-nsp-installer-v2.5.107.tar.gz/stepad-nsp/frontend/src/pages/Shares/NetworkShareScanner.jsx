import { useState } from "react";
import { getToken } from "../../auth/authStorage";

const API_URL = import.meta.env.VITE_API_URL || "/api/v1";

export default function NetworkShareScanner({ onSelect }) {
  const [hosts, setHosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedHost, setSelectedHost] = useState(null);
  const [selectedShare, setSelectedShare] = useState(null);
  const [credentials, setCredentials] = useState({ user: "", password: "" });
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [subnet, setSubnet] = useState("192.168.1.0/24");
  const [directIP, setDirectIP] = useState("");
  const [authShares, setAuthShares] = useState(null);
  const [browsePath, setBrowsePath] = useState("");
  const [browseItems, setBrowseItems] = useState(null);
  const [browseLoading, setBrowseLoading] = useState(false);

  async function handleScan() {
    setLoading(true); setError(null); setHosts([]);
    try {
      const token = getToken();
      const res = await fetch(`${API_URL}/shares/network/scan?subnet=${subnet}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      const data = await res.json();
      setHosts(data.hosts || []);
      if (data.total_hosts === 0) setError("No se encontraron equipos con shares SMB.");
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  }

  async function handleDirectConnect() {
    if (!directIP.trim()) return;
    setLoading(true); setError(null); setHosts([]); setAuthShares(null);
    try {
      const token = getToken();
      const res = await fetch(`${API_URL}/shares/network/scan?subnet=${directIP.trim()}/32`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      const data = await res.json();
      setHosts(data.hosts || []);
      if (data.total_hosts === 0) setSelectedHost({ ip: directIP.trim(), hostname: directIP.trim(), shares: [{ name: "(requiere credenciales)", type: "Auth" }] });
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  }

  async function handleListShares() {
    if (!selectedHost || !credentials.user) return;
    setLoading(true); setAuthShares(null); setError(null);
    try {
      const token = getToken();
      const params = new URLSearchParams({ host: selectedHost.ip, user: credentials.user, password: credentials.password });
      const res = await fetch(`${API_URL}/shares/network/list-shares?${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      const data = await res.json();
      const shares = data.shares || [];
      const authError = shares.find(s => s.name === "__AUTH_ERROR__");
      if (authError) { setError(authError.comment); setAuthShares(null); }
      else { setAuthShares(shares); if (shares.length === 0) setError("No se encontraron shares."); }
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  }

  async function handleBrowse(share, path) {
    if (!selectedHost || !credentials.user) return;
    setBrowseLoading(true); setError(null);
    try {
      const token = getToken();
      const params = new URLSearchParams({ host: selectedHost.ip, share, path: path || "", user: credentials.user, password: credentials.password });
      const res = await fetch(`${API_URL}/shares/network/browse?${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      const data = await res.json();
      setBrowseItems(data.items || []);
      setBrowsePath(path || "/");
      setSelectedShare(share);
    } catch (err) { setError(err.message); setBrowseItems(null); } finally { setBrowseLoading(false); }
  }

  async function handleTest() {
    if (!selectedShare || !selectedHost || !browsePath) return;
    setTesting(true); setTestResult(null);
    try {
      const token = getToken();
      const fullPath = browsePath === "/" ? selectedShare : `${selectedShare}${browsePath}`;
      const params = new URLSearchParams({ host: selectedHost.ip, share: fullPath, user: credentials.user, password: credentials.password });
      const res = await fetch(`${API_URL}/shares/network/test?${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setTestResult(await res.json());
    } catch (err) { setTestResult({ success: false, message: err.message }); } finally { setTesting(false); }
  }

  function handleBackup() {
    if (!selectedShare || !selectedHost || !testResult?.success) return;
    const fullPath = browsePath === "/" ? `//${selectedHost.ip}/${selectedShare}` : `//${selectedHost.ip}/${selectedShare}${browsePath}`;
    onSelect?.({ path: fullPath, host: selectedHost.ip, share: selectedShare, hostname: selectedHost.hostname, user: credentials.user, password: credentials.password, subfolder: browsePath });
  }

  function navigateUp() {
    const parts = browsePath.split("/").filter(Boolean);
    parts.pop();
    const newPath = parts.length ? "/" + parts.join("/") : "/";
    handleBrowse(selectedShare, newPath);
  }

  return (
    <div className="sh-network-scan">
      <div className="sh-scan-form">
        <label className="sh-bk-source-field">
          <span className="sh-bk-label">Subred</span>
          <input type="text" value={subnet} onChange={(e) => setSubnet(e.target.value)} placeholder="192.168.1.0/24" />
        </label>
        <button type="button" className="sh-btn sh-btn-sm primary" onClick={handleScan} disabled={loading}>{loading ? "Buscando..." : "Escanear"}</button>
        <span className="sh-muted" style={{margin: "0 4px"}}>o IP:</span>
        <input type="text" value={directIP} onChange={(e) => setDirectIP(e.target.value)} placeholder="192.168.1.59" style={{maxWidth:140}} />
        <button type="button" className="sh-btn sh-btn-sm" onClick={handleDirectConnect} disabled={loading || !directIP.trim()}>Conectar</button>
      </div>
      {error && <p className="sh-banner warn">{error}</p>}

      {hosts.map((host) => (
        <div key={host.ip} className="sh-scan-host">
          <div className="sh-scan-host-header" onClick={() => { setSelectedHost(selectedHost?.ip === host.ip ? null : host); setAuthShares(null); setBrowseItems(null); }}>
            <strong>{host.hostname || host.ip}</strong> <span className="sh-muted">({host.ip})</span>
            <span style={{marginLeft:8,fontSize:"0.7rem"}}>{selectedHost?.ip === host.ip ? "▼" : "▶"}</span>
          </div>
          {selectedHost?.ip === host.ip && (
            <div className="sh-scan-host-shares">
              {host.shares.filter(s => s.type !== "Auth").map((share) => (
                <div key={share.name} className="sh-scan-share" onClick={() => handleBrowse(share.name, "")}>
                  📁 {share.name} {share.comment && <span className="sh-muted">— {share.comment}</span>}
                </div>
              ))}
              {host.shares.some(s => s.type === "Auth") && (
                <div className="sh-scan-auth-form">
                  <span className="sh-muted">Credenciales:</span>
                  <input type="text" placeholder="Usuario" value={credentials.user} onChange={(e) => setCredentials({...credentials, user: e.target.value})} />
                  <input type="password" placeholder="Contraseña" value={credentials.password} onChange={(e) => setCredentials({...credentials, password: e.target.value})} />
                  <button type="button" className="sh-btn sh-btn-sm" onClick={handleListShares} disabled={loading || !credentials.user}>Ver shares</button>
                </div>
              )}
              {authShares && authShares.map((share) => (
                <div key={share.name} className="sh-scan-share" onClick={() => handleBrowse(share.name, "")}>
                  📁 {share.name} {share.comment && <span className="sh-muted">— {share.comment}</span>}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      {selectedHost && selectedShare && browseItems && (
        <div className="sh-scan-browse">
          <div className="sh-scan-breadcrumb">
            <span className="sh-muted">/{selectedShare}</span>
            {browsePath.split("/").filter(Boolean).map((part, i, arr) => {
              const fullPath = "/" + arr.slice(0, i + 1).join("/");
              return <span key={i} onClick={() => handleBrowse(selectedShare, fullPath)} className="sh-scan-breadcrumb-link">/{part}</span>;
            })}
          </div>
          {browsePath !== "/" && (
            <button type="button" className="sh-btn sh-btn-sm" onClick={navigateUp} style={{marginBottom:6}}>↑ Subir</button>
          )}
          {browseLoading ? <p className="sh-muted">Cargando...</p> : browseItems.length === 0 ? <p className="sh-muted">Carpeta vacía</p> : (
            browseItems.filter(i => i.type === "dir").map((item) => (
              <div key={item.name} className="sh-scan-share" onClick={() => handleBrowse(selectedShare, browsePath === "/" ? item.name : `${browsePath}/${item.name}`)}>
                📁 {item.name}
              </div>
            ))
          )}
          <div style={{marginTop:8,paddingTop:8,borderTop:"1px solid rgba(255,255,255,0.1)"}}>
            <span className="sh-muted" style={{fontSize:"0.8rem"}}>Carpeta actual: /{selectedShare}{browsePath}</span>
            <div style={{display:"flex",gap:8,marginTop:6}}>
              <button type="button" className="sh-btn sh-btn-sm" onClick={handleTest} disabled={testing}>{testing ? "Probando..." : "Probar conexión"}</button>
              {testResult?.success && <button type="button" className="sh-btn sh-btn-sm primary" onClick={handleBackup}>Respaldar esta carpeta</button>}
            </div>
            {testResult && <p className={testResult.success ? "sh-banner ok" : "sh-banner warn"} style={{marginTop:4}}>{testResult.message}</p>}
          </div>
        </div>
      )}

      <style>{`
        .sh-scan-form{display:flex;gap:8px;align-items:end;flex-wrap:wrap;margin-bottom:8px}
        .sh-scan-form input{max-width:160px}
        .sh-scan-host{margin:4px 0;padding:6px;border-radius:6px;background:rgba(255,255,255,0.03)}
        .sh-scan-host-header{cursor:pointer;padding:4px 0}
        .sh-scan-host-shares{padding-left:12px}
        .sh-scan-share{padding:4px 8px;margin:2px 0;border-radius:4px;cursor:pointer;border:1px solid transparent;font-size:0.85rem}
        .sh-scan-share:hover{background:rgba(255,255,255,0.05)}
        .sh-scan-share.selected{border-color:rgba(59,130,246,0.5);background:rgba(59,130,246,0.08)}
        .sh-scan-auth-form{margin:6px 0;padding:6px;border-radius:4px;background:rgba(255,255,255,0.03);display:flex;gap:6px;align-items:center;flex-wrap:wrap}
        .sh-scan-auth-form input{max-width:140px}
        .sh-scan-browse{margin-top:8px;padding:8px;border-radius:6px;border:1px solid rgba(255,255,255,0.1)}
        .sh-scan-breadcrumb{margin-bottom:6px;font-size:0.8rem;color:#93c5fd}
        .sh-scan-breadcrumb-link{cursor:pointer;margin:0 2px}
        .sh-scan-breadcrumb-link:hover{text-decoration:underline}
        .sh-banner.ok{background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);color:#86efac;padding:6px;border-radius:4px;font-size:0.85rem}
        .sh-banner.warn{background:rgba(234,179,8,0.1);border:1px solid rgba(234,179,8,0.3);color:#fde047;padding:6px;border-radius:4px;font-size:0.85rem}
      `}</style>
    </div>
  );
}
