import { useEffect, useState } from "react";

import { subscribe, snapshot, pendingCount } from "../../services/busyStore";

import "./GlobalSpinner.css";

const MIN_VISIBLE_MS = 300;

export default function GlobalSpinner() {
    const [label, setLabel] = useState(null);

    useEffect(() => {
        let timer = null;

        const check = () => {
            setLabel((prev) => {
                const next = snapshot();
                return next === prev ? prev : next;
            });
            if (timer) {
                clearTimeout(timer);
                timer = null;
            }
            if (snapshot() === null && pendingCount() > 0) {
                timer = setTimeout(check, MIN_VISIBLE_MS);
            }
        };

        check();
        const unsub = subscribe(check);
        return () => {
            if (timer) {
                clearTimeout(timer);
            }
            unsub();
        };
    }, []);

    if (!label) {
        return null;
    }

    return (
        <div className="gsp-bar" role="status" aria-live="polite">
            <span className="gsp-spinner" aria-hidden="true" />
            <span className="gsp-label">{label}…</span>
        </div>
    );
}