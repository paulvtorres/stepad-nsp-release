const MIN_VISIBLE_MS = 300;

const pending = new Map();
const listeners = new Set();

function emit() {
    listeners.forEach((fn) => fn());
}

export function begin(key, label = "") {
    if (pending.has(key)) {
        return;
    }
    pending.set(key, {
        label: label || String(key || ""),
        started: Date.now(),
    });
    emit();
}

export function end(key) {
    if (!pending.delete(key)) {
        return;
    }
    emit();
}

export function withBusy(key, label, promise) {
    begin(key, label);
    return Promise.resolve(promise).finally(() => end(key));
}

export function pendingCount() {
    return pending.size;
}

export function snapshot() {
    const now = Date.now();
    for (const item of pending.values()) {
        if (now - item.started >= MIN_VISIBLE_MS) {
            return item.label;
        }
    }
    return null;
}

export function subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
}