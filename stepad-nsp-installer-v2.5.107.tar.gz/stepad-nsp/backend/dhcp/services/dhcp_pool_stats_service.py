"""
Estadísticas del segmento DHCP: totales, online, offline y libres.
Cruza datos de la base de datos con los leases reales de dnsmasq.
"""

from __future__ import annotations

import ipaddress

from backend.core.database.session import SessionLocal
from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.groups.constants.group_dns_ip_reserve import (
    free_group_ip_count,
    group_ip_bounds,
    group_ip_capacity,
)
from backend.groups.models.device_group import DeviceGroup
from backend.network.devices.models.network_device import NetworkDevice
from backend.shared.config.config_service import ConfigService


def _ip_int(value: str | None) -> int | None:

    if not value:
        return None

    try:
        return int(ipaddress.IPv4Address(str(value)))
    except Exception:
        return None


def _range_size(start: str | None, end: str | None) -> int:

    a = _ip_int(start)
    b = _ip_int(end)

    if a is None or b is None or b < a:
        return 0

    return b - a + 1


def _in_range(ip: str | None, start: str | None, end: str | None) -> bool:

    value = _ip_int(ip)
    a = _ip_int(start)
    b = _ip_int(end)

    if value is None or a is None or b is None:
        return False

    return a <= value <= b


def _read_dnsmasq_leases() -> dict[str, str]:
    """
    Lee dnsmasq.leases y devuelve {mac: ip} de leases activos.
    """
    leases: dict[str, str] = {}

    try:
        content = DNSMASQ_LEASES_FILE.read_text(
            encoding="utf-8", errors="replace"
        )
    except (FileNotFoundError, OSError):
        return leases

    for line in content.splitlines():
        parts = line.split()
        if len(parts) < 3:
            continue
        mac = parts[1].strip().lower()
        ip = parts[2].strip()
        if mac and ip:
            leases[mac] = ip

    return leases


class DhcpPoolStatsService:

    def __init__(self):

        self.config_service = ConfigService()

    def get_stats(self) -> dict:

        dhcp = self.config_service.get_dhcp_config() or {}

        pool_start = dhcp.get("pool_start")
        pool_end = dhcp.get("pool_end")
        gateway = dhcp.get("gateway")

        pool_total = _range_size(pool_start, pool_end)

        try:
            g_first, g_last = group_ip_bounds(dhcp)
            group_start = str(g_first)
            group_end = str(g_last)
            group_total = group_ip_capacity(dhcp)
        except Exception:
            group_start = dhcp.get("group_ip_start")
            group_end = dhcp.get("group_ip_end")
            group_total = _range_size(group_start, group_end)

        # --- Leer leases reales de dnsmasq ---
        dnsmasq_leases = _read_dnsmasq_leases()
        leased_ips_in_pool = {
            ip for ip in dnsmasq_leases.values()
            if _in_range(ip, pool_start, pool_end)
        }

        db = SessionLocal()

        try:

            devices = (
                db.query(NetworkDevice)
                .filter(
                    NetworkDevice.ip_address.isnot(None),
                    NetworkDevice.mac_address.isnot(None),
                )
                .all()
            )

            online = 0
            offline = 0

            for device in devices:

                if not _in_range(device.ip_address, pool_start, pool_end):
                    continue

                if (device.status or "").upper() == "ONLINE":
                    online += 1
                else:
                    offline += 1

            # IPs en el pool que dnsmasq tiene lease pero NO estan en la DB
            # (dispositivos que obtuvieron IP por DHCP pero aun no fueron
            # registrados por discovery, o fueron eliminados de la DB).
            leased_not_in_db = leased_ips_in_pool - {
                d.ip_address for d in devices
                if _in_range(d.ip_address, pool_start, pool_end)
            }

            # Agregar esas IPs al conteo offline (ocupan IP aunque no
            # esten en la DB).
            offline += len(leased_not_in_db)

            used_group_ips = {
                g.dns_alias_ip
                for g in db.query(DeviceGroup).filter(
                    DeviceGroup.dns_alias_ip.isnot(None)
                ).all()
                if g.dns_alias_ip
            }

            group_used = sum(
                1
                for ip in used_group_ips
                if _in_range(ip, group_start, group_end)
            )
            group_free = max(0, group_total - group_used)

            try:
                group_free = free_group_ip_count(used_group_ips, dhcp)
                group_used = max(0, group_total - group_free)
            except Exception:
                pass

        finally:

            db.close()

        reserved = online + offline
        free = max(0, pool_total - reserved)
        total = pool_total + group_total
        total_free = free + group_free
        total_used = reserved + group_used

        return {
            "gateway": gateway,
            "pool_start": pool_start,
            "pool_end": pool_end,
            "group_ip_start": group_start,
            "group_ip_end": group_end,
            "devices": {
                "total": pool_total,
                "online": online,
                "offline": offline,
                "reserved": reserved,
                "free": free,
            },
            "groups": {
                "total": group_total,
                "used": group_used,
                "free": group_free,
            },
            "overall": {
                "total": total,
                "used": total_used,
                "online": online,
                "offline": offline,
                "free": total_free,
            },
            "dnsmasq_leases": len(dnsmasq_leases),
            "leases_not_in_db": len(leased_not_in_db),
        }
