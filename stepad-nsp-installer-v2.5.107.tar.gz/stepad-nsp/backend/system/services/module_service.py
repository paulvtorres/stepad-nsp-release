import subprocess

from sqlalchemy.orm import Session

from backend.shared.logging.logger import logger


# Catálogo de módulos/servicios con sus requisitos de hardware.
# Los requisitos se evalúan SOLO sobre los módulos activados para
# el cliente (no todos usan todos los servicios).
MODULES = [
    {
        "key": "ips",
        "name": "IPS / Anti-malware (Suricata)",
        "description": "Prevención de intrusiones con firmas actualizadas.",
        "min_cores": 2, "rec_cores": 4,
        "min_ram_mb": 4096, "rec_ram_mb": 8192,
    },
    {
        "key": "web_filter",
        "name": "Filtrado web/DNS por categorías",
        "description": "Bloqueo de sitios por categoría y perfiles por grupo.",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "bandwidth",
        "name": "Ancho de banda (QoS)",
        "description": "Límites de velocidad por dispositivo y grupo.",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "vpn",
        "name": "VPN WireGuard",
        "description": "Acceso remoto seguro por VPN.",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "group_dns",
        "name": "DNS por grupos",
        "description": "Recursor DNS independiente por grupo (perfiles por área).",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "backups",
        "name": "Respaldos cifrados",
        "description": "Copias automáticas cifradas y envío fuera del sitio.",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "siem",
        "name": "SIEM / Syslog",
        "description": "Reenvío de eventos a un servidor central.",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "hardening",
        "name": "Hardening / Deny-all",
        "description": "Política de denegación por defecto y restricciones.",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 1024, "rec_ram_mb": 2048,
    },
    {
        "key": "remote_access",
        "name": "Monitoreo remoto",
        "description": "Acceso remoto por Tailscale al panel de administración.",
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "rustdesk",
        "name": "Escritorio remoto (RustDesk)",
        "description": (
            "Servidor self-hosted tipo AnyDesk para que los usuarios "
            "accedan a sus PCs de la oficina."
        ),
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
    {
        "key": "network_disk",
        "name": "Disco de red (carpetas compartidas)",
        "description": (
            "Asigna un disco USB o adicional (nunca el del SO) como volumen "
            "compartido protegido. Los grupos definen acceso a cada carpeta."
        ),
        "min_cores": 1, "rec_cores": 2,
        "min_ram_mb": 2048, "rec_ram_mb": 4096,
    },
]


# Plan básico por defecto en instalación NUEVA (protección esencial):
# IPS activo por defecto; los módulos que exigen más recursos/config
# (QoS, DNS por grupos, SIEM) NO se marcan como activos hasta que el
# administrador los habilite explícitamente.
DEFAULT_OFF_MODULES = {"bandwidth", "group_dns", "siem", "rustdesk", "network_disk"}


class ModuleService:

    def get_modules(self, db: Session):

        from backend.system.models.module_settings import ModuleSetting

        rows = db.query(ModuleSetting).all()

        if rows:

            # Configuración explícita del administrador: se respeta.
            disabled = {
                row.module_key
                for row in rows
                if not row.enabled
            }

        else:

            # Instalación nueva: plan básico por defecto.
            disabled = set(DEFAULT_OFF_MODULES)

        result = []

        for module in MODULES:

            result.append({
                "key": module["key"],
                "name": module["name"],
                "description": module["description"],
                "enabled": module["key"] not in disabled,
                "min_cores": module["min_cores"],
                "rec_cores": module["rec_cores"],
                "min_ram_mb": module["min_ram_mb"],
                "rec_ram_mb": module["rec_ram_mb"],
            })

        return result

    def set_modules(
        self,
        db: Session,
        enabled_keys: list
    ):

        from backend.system.models.module_settings import ModuleSetting

        enabled_keys = set(enabled_keys or [])

        for module in MODULES:

            row = (
                db.query(ModuleSetting)
                .filter(ModuleSetting.module_key == module["key"])
                .first()
            )

            if row is None:

                row = ModuleSetting(module_key=module["key"])

                db.add(row)

            row.enabled = module["key"] in enabled_keys

        db.commit()

        # El módulo IPS controla el servicio Suricata: al activarlo,
        # arranca el IPS en línea; al desactivarlo, se detiene.
        if "ips" in enabled_keys:

            subprocess.run(
                ["systemctl", "enable", "--now", "suricata.service"],
                capture_output=True,
                text=True,
            )

        else:

            subprocess.run(
                ["systemctl", "disable", "--now", "suricata.service"],
                capture_output=True,
                text=True,
            )

        logger.info(
            "Módulos actualizados: %s",
            sorted(enabled_keys)
        )

        return self.get_modules(db)

    def enabled_requirements(self, db: Session):

        """Devuelve los requisitos máximos de los módulos ACTIVADOS."""

        modules = self.get_modules(db)

        enabled = [m for m in modules if m["enabled"]]

        max_cores = max((m["rec_cores"] for m in enabled), default=1)

        max_ram = max((m["rec_ram_mb"] for m in enabled), default=2048)

        min_cores = max((m["min_cores"] for m in enabled), default=1)

        min_ram = max((m["min_ram_mb"] for m in enabled), default=2048)

        return {
            "min_cores": min_cores,
            "rec_cores": max_cores,
            "min_ram_mb": min_ram,
            "rec_ram_mb": max_ram,
            "enabled_count": len(enabled),
            "enabled": enabled,
        }
