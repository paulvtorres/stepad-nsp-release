"""Folders belong to shared volumes

Revision ID: 0021
Revises: 0020
Create Date: 2026-09-05 20:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0021"
down_revision = "0020"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_folders",
        sa.Column("volume_id", sa.Integer(), nullable=True),
    )
    op.create_foreign_key(
        "fk_share_folders_volume",
        "network_share_folders",
        "network_share_volumes",
        ["volume_id"],
        ["id"],
        ondelete="CASCADE",
    )

    # folder_name unique per volume (not globally).
    op.drop_constraint(
        "network_share_folders_folder_name_key",
        "network_share_folders",
        type_="unique",
    )
    op.create_index(
        "ix_share_folders_volume_id",
        "network_share_folders",
        ["volume_id"],
    )
    op.create_unique_constraint(
        "uq_share_folder_volume_slug",
        "network_share_folders",
        ["volume_id", "folder_name"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_share_folder_volume_slug",
        "network_share_folders",
        type_="unique",
    )
    op.drop_index("ix_share_folders_volume_id", table_name="network_share_folders")
    op.create_unique_constraint(
        "network_share_folders_folder_name_key",
        "network_share_folders",
        ["folder_name"],
    )
    op.drop_constraint(
        "fk_share_folders_volume",
        "network_share_folders",
        type_="foreignkey",
    )
    op.drop_column("network_share_folders", "volume_id")
