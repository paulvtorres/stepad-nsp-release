"""Versioned backups of shared volumes (restic jobs)

Revision ID: 0024
Revises: 0023
Create Date: 2026-09-06 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0024"
down_revision = "0023"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "network_share_backup_jobs",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("name", sa.String(100), nullable=False, unique=True),
        sa.Column("source_path", sa.String(512), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("schedule_hour", sa.Integer(), nullable=False, server_default=sa.text("2")),
        sa.Column("schedule_minute", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("retention_count", sa.Integer(), nullable=False, server_default=sa.text("7")),
        sa.Column("prune_free_pct", sa.Integer(), nullable=False, server_default=sa.text("15")),
        sa.Column("last_backup_at", sa.DateTime(), nullable=True),
        sa.Column("last_result", sa.String(512), nullable=True),
        sa.Column("last_snapshot_id", sa.String(64), nullable=True),
        sa.Column("last_bytes", sa.BigInteger(), nullable=False, server_default=sa.text("0")),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )


def downgrade() -> None:
    op.drop_table("network_share_backup_jobs")