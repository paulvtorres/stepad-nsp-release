"""Shared volumes (named partitions)

Revision ID: 0020
Revises: 0019
Create Date: 2026-09-05 19:40:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0020"
down_revision = "0019"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "network_share_volumes",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("name", sa.String(length=100), nullable=False, unique=True),
        sa.Column("device_path", sa.String(length=128), nullable=False),
        sa.Column("device_uuid", sa.String(length=64), nullable=False, unique=True),
        sa.Column("mountpoint", sa.String(length=512), nullable=False),
        sa.Column(
            "sharing",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )

    op.create_table(
        "group_volume_access",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column(
            "group_id",
            sa.Integer(),
            sa.ForeignKey("device_groups.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "volume_id",
            sa.Integer(),
            sa.ForeignKey("network_share_volumes.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "access_mode",
            sa.String(length=10),
            nullable=False,
            server_default="read",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.UniqueConstraint(
            "group_id",
            "volume_id",
            name="uq_group_volume_access",
        ),
    )


def downgrade() -> None:
    op.drop_table("group_volume_access")
    op.drop_table("network_share_volumes")
