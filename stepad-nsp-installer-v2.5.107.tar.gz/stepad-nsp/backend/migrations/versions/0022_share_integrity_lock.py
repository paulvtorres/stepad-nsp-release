"""Share integrity lock columns

Revision ID: 0022
Revises: 0021
Create Date: 2026-09-05 20:40:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0022"
down_revision = "0021"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_settings",
        sa.Column(
            "integrity_watch_enabled",
            sa.Boolean(),
            nullable=False,
            server_default=sa.true(),
        ),
    )
    op.add_column(
        "network_share_settings",
        sa.Column(
            "integrity_locked",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )
    op.add_column(
        "network_share_settings",
        sa.Column("integrity_locked_at", sa.DateTime(), nullable=True),
    )
    op.add_column(
        "network_share_settings",
        sa.Column("integrity_lock_detail", sa.String(length=512), nullable=True),
    )
    op.add_column(
        "network_share_settings",
        sa.Column(
            "integrity_change_threshold",
            sa.Integer(),
            nullable=False,
            server_default="80",
        ),
    )


def downgrade() -> None:
    op.drop_column("network_share_settings", "integrity_change_threshold")
    op.drop_column("network_share_settings", "integrity_lock_detail")
    op.drop_column("network_share_settings", "integrity_locked_at")
    op.drop_column("network_share_settings", "integrity_locked")
    op.drop_column("network_share_settings", "integrity_watch_enabled")
