"""Share disk device columns

Revision ID: 0019
Revises: 0018
Create Date: 2026-09-05 16:30:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0019"
down_revision = "0018"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_settings",
        sa.Column("device_path", sa.String(length=128), nullable=True),
    )
    op.add_column(
        "network_share_settings",
        sa.Column("device_uuid", sa.String(length=64), nullable=True),
    )
    op.add_column(
        "network_share_settings",
        sa.Column(
            "disk_locked",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )


def downgrade() -> None:
    op.drop_column("network_share_settings", "disk_locked")
    op.drop_column("network_share_settings", "device_uuid")
    op.drop_column("network_share_settings", "device_path")
