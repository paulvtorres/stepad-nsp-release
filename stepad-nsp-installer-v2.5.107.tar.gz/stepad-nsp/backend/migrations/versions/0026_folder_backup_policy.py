"""Folder backup scheduling policy (versions)

Revision ID: 0026
Revises: 0025
Create Date: 2026-09-07 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0026"
down_revision = "0025"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_folders",
        sa.Column(
            "backup_mode",
            sa.String(20),
            nullable=False,
            server_default=sa.text("'off'"),
        ),
    )
    op.add_column(
        "network_share_folders",
        sa.Column(
            "backup_times_per_day",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("1"),
        ),
    )
    op.add_column(
        "network_share_folders",
        sa.Column(
            "backup_retention",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("7"),
        ),
    )


def downgrade() -> None:
    op.drop_column("network_share_folders", "backup_retention")
    op.drop_column("network_share_folders", "backup_times_per_day")
    op.drop_column("network_share_folders", "backup_mode")