"""Backup job scheduling modes (interval / on_change / folder link)

Revision ID: 0027
Revises: 0026
Create Date: 2026-09-07 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0027"
down_revision = "0026"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_backup_jobs",
        sa.Column(
            "schedule_mode",
            sa.String(20),
            nullable=False,
            server_default=sa.text("'daily'"),
        ),
    )
    op.add_column(
        "network_share_backup_jobs",
        sa.Column(
            "interval_minutes",
            sa.Integer(),
            nullable=True,
        ),
    )
    op.add_column(
        "network_share_backup_jobs",
        sa.Column(
            "change_hash",
            sa.String(64),
            nullable=True,
        ),
    )
    op.add_column(
        "network_share_backup_jobs",
        sa.Column(
            "folder_id",
            sa.Integer(),
            nullable=True,
        ),
    )
    op.create_index(
        "ix_network_share_backup_jobs_folder_id",
        "network_share_backup_jobs",
        ["folder_id"],
    )
    op.create_unique_constraint(
        "uq_backup_job_folder",
        "network_share_backup_jobs",
        ["folder_id"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_backup_job_folder",
        "network_share_backup_jobs",
        type_="unique",
    )
    op.drop_index(
        "ix_network_share_backup_jobs_folder_id",
        table_name="network_share_backup_jobs",
    )
    op.drop_column("network_share_backup_jobs", "folder_id")
    op.drop_column("network_share_backup_jobs", "change_hash")
    op.drop_column("network_share_backup_jobs", "interval_minutes")
    op.drop_column("network_share_backup_jobs", "schedule_mode")