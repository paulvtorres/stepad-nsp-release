"""Integrity watch pause for bulk uploads

Revision ID: 0023
Revises: 0022
Create Date: 2026-09-05 21:45:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0023"
down_revision = "0022"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_settings",
        sa.Column("integrity_paused_until", sa.DateTime(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("network_share_settings", "integrity_paused_until")
