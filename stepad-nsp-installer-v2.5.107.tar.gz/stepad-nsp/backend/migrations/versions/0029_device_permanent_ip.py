"""Add is_permanent flag to network_devices

Revision ID: 0029
Revises: 0028
Create Date: 2026-09-09 12:00:00.000000
"""
from alembic import op
import sqlalchemy as sa

revision = "0029"
down_revision = "0028"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_devices",
        sa.Column("is_permanent", sa.Boolean(), server_default="false", nullable=False),
    )


def downgrade() -> None:
    op.drop_column("network_devices", "is_permanent")
