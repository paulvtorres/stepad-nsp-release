"""Private-by-default share folders (shared flag)

Revision ID: 0025
Revises: 0024
Create Date: 2026-09-06 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0025"
down_revision = "0024"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_folders",
        sa.Column(
            "shared",
            sa.Boolean(),
            nullable=False,
            # Existing folders keep being published; brand-new folders are
            # created private by the application layer.
            server_default=sa.text("true"),
        ),
    )


def downgrade() -> None:
    op.drop_column("network_share_folders", "shared")