"""Backup job multiple daily times (schedule_times)

Revision ID: 0028
Revises: 0027
Create Date: 2026-09-07 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0028"
down_revision = "0027"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "network_share_backup_jobs",
        sa.Column(
            "schedule_times",
            sa.String(64),
            nullable=True,
        ),
    )


def downgrade() -> None:
    op.drop_column("network_share_backup_jobs", "schedule_times")