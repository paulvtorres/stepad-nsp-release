from typing import List

from backend.shared.config.config_loader import config

from backend.infrastructure.network.adapters.linux.linux_interface_provider import (
    LinuxInterfaceProvider,
)
from backend.network.interfaces.models.network_interface import NetworkInterface
from backend.network.interfaces.models.network_interface_info import (
    NetworkInterfaceInfo,
)
from backend.network.interfaces.registry.services.interface_registry_service import (
    InterfaceRegistryService,
)


class InterfaceService:

    def __init__(self):

        self.provider = LinuxInterfaceProvider()

        self.registry_service = InterfaceRegistryService()

    def list_interfaces(self, deep: bool = True) -> List[NetworkInterface]:

        infos = self.provider.list_interfaces(deep=deep)

        interfaces = []

        for info in infos:

            role = self.resolve_role(info)

            interfaces.append(

                NetworkInterface(

                    id=info.id,

                    name=info.name,

                    display_name=info.display_name,

                    ip=info.ipv4_address,

                    subnet_mask=info.subnet_mask,

                    mac=info.mac_address,

                    status=info.status,

                    role=role,

                    priority=self.resolve_priority(info),

                    interface_type=info.interface_type,

                    is_wan_candidate=(role == "WAN"),

                    is_lan_candidate=(role == "LAN"),

                    link_detected=info.link_detected,

                    connection_state=info.connection_state

                )

            )

        return interfaces

    def get_wan_interfaces(self) -> List[NetworkInterface]:
        """
        Every interface currently assigned WAN in the registry,
        cheapest priority first. NAT and encrypted-DNS blocking apply
        to the WHOLE list -- a second WAN is not a display detail, it
        is another uplink that needs masquerading and must be
        excluded from DNS-redirect rules.
        """

        return sorted(
            (
                interface
                for interface in self.list_interfaces()
                if interface.role == "WAN"
            ),
            key=lambda interface: interface.priority
        )

    def get_lan_interfaces(self) -> List[NetworkInterface]:
        """
        Every interface currently assigned LAN in the registry,
        cheapest priority first. The first entry is the PRIMARY LAN
        (the simple-mode segment from config.yaml, served by the
        systemd recursor + dnsmasq); additional LANs are meant to be
        implemented as zones (their own subnet/DHCP/DNS), which is
        where multi-LAN actually scales.
        """

        return sorted(
            (
                interface
                for interface in self.list_interfaces(deep=False)
                if interface.role == "LAN"
            ),
            key=lambda interface: interface.priority
        )

    def get_primary_wan(self) -> NetworkInterface | None:

        wans = self.get_wan_interfaces()

        return wans[0] if wans else None

    def get_primary_lan(self) -> NetworkInterface | None:

        lans = self.get_lan_interfaces()

        return lans[0] if lans else None

    def resolve_priority(
        self,
        interface: NetworkInterfaceInfo
    ) -> int:
        """
        Registry-owned, same source of truth as resolve_role: the
        lower the value the more preferred the card is within its
        role. Falls back to 100 when the registry has nothing (mirrors
        ManagedInterface.priority's default), which keeps ordering
        stable for the pre-assignment bootstrap path.
        """

        priority = self.registry_service.get_priority_for_mac(
            interface.mac_address
        )

        return priority if priority is not None else 100

    def resolve_role(
        self,
        interface: NetworkInterfaceInfo
    ) -> str:

        # PRIORITY 0 -- the persistent registry, identified by MAC.
        # This is the actual source of truth once at least one role
        # has been assigned through the web UI: it's the only thing
        # here that survives a hardware swap (new machine, replaced
        # card) or a kernel rename, since both of those change the
        # interface NAME but never the MAC. See
        # InterfaceRegistryService for the reconciliation that keeps
        # this in sync and migrates a bare config.yaml into it the
        # first time it runs.
        registry_role = self.registry_service.get_role_for_mac(
            interface.mac_address
        )

        if registry_role:

            return registry_role

        # PRIORITY 1 -- config.yaml, for an install that hasn't been
        # through the registry's first reconciliation pass yet (or
        # during that very pass, before the migration writes an
        # entry). This is deterministic and immune to boot-time
        # timing: it does NOT depend on the WAN interface having
        # already finished its DHCP negotiation (see below for why
        # that matters).
        #
        # Without this, role was resolved purely from
        # `interface.is_default_gateway` (i.e. whichever interface
        # "ip route" currently reports as the default route) with
        # everything else falling back to "LAN" (since
        # interface_type is always "ETHERNET" here). STEPAD starts
        # very early in the boot sequence -- if the WAN interface's
        # DHCP client hasn't obtained its lease/default route YET at
        # that exact moment, "ip route" shows no default route,
        # is_default_gateway is False for EVERY interface, and BOTH
        # the real WAN nic and the real LAN nic fall back to "LAN".
        # configure_lan() then applies the LAN gateway IP to
        # whichever of them happens to be listed first -- which can
        # be the WAN nic. The WAN DHCP lease arrives moments later
        # and is added alongside it (DHCP clients don't touch
        # addresses they didn't add themselves), leaving the WAN
        # interface with BOTH its real DHCP address AND STEPAD's LAN
        # gateway IP permanently stuck on it. Two interfaces then
        # answer ARP for the same LAN gateway IP, and LAN clients
        # intermittently get answered by the WAN side -- browsing
        # breaks.
        network_config = config.get("network", {})

        if network_config.get("initialized"):

            if interface.name == network_config.get("wan_interface"):

                return "WAN"

            if interface.name == network_config.get("lan_interface"):

                return "LAN"

            # A configured install where this interface is neither
            # the recorded WAN nor LAN nic (e.g. an interface added
            # after setup) -- don't guess, surface it as UNKNOWN
            # rather than risk it being auto-treated as LAN and
            # getting the gateway IP applied to it too.
            return "UNKNOWN"

        # PRIORITY 2 -- no config yet (first-run setup wizard, before
        # the admin has chosen WAN/LAN). Best-effort heuristic just
        # to populate candidate suggestions in the setup UI; never
        # used once config.yaml has real values.
        if interface.is_default_gateway:
            return "WAN"

        if interface.interface_type == "ETHERNET":
            return "LAN"

        return "UNKNOWN"