import json
import subprocess
import threading
import time

from datetime import datetime, timedelta
from ipaddress import ip_interface

from backend.core.config.paths import (
    MAINTENANCE_DIR,
    LAN_OVERRIDE_STATE_FILE
)

from backend.shared.config.config_loader import config_loader

from backend.network.interfaces.services.interface_service import (
    InterfaceService
)

from backend.network.configuration.providers.linux_interface_config_provider import (
    LinuxInterfaceConfigProvider
)

from backend.network.configuration.models.interface_address import (
    InterfaceAddress
)

from backend.core.dnsmasq.process_manager import dnsmasq_process_manager

from backend.shared.logging.logger import logger


MAX_DURATION_MINUTES = 15

WATCHDOG_POLL_SECONDS = 15


class TemporaryLanService:
    """
    Lets an admin temporarily move the NSP's LAN IP into a different
    subnet -- typically to reach a switch's default management IP
    (e.g. 192.168.0.1) that doesn't overlap with the real LAN range,
    reconfigure the switch, then revert.

    This is intentionally disruptive: while active, dnsmasq is
    stopped and the LAN interface no longer answers on its normal
    gateway/DNS IP, so every device on the LAN loses DHCP/DNS for the
    duration. That's the whole point (reaching a device that's NOT
    on the LAN subnet) -- the frontend is responsible for making this
    unmistakably clear before the person confirms.

    Hard-capped at MAX_DURATION_MINUTES and enforced by a watchdog
    thread (not just "trust the caller") so a crashed browser tab,
    lost SSH session, or backend restart mid-window can never leave
    the network stuck on the temporary IP indefinitely.
    """

    def __init__(self):

        self.interface_service = InterfaceService()

        self.provider = LinuxInterfaceConfigProvider()

        self._watchdog_started = False


    def _read_state(self):

        if not LAN_OVERRIDE_STATE_FILE.exists():

            return None

        try:

            return json.loads(LAN_OVERRIDE_STATE_FILE.read_text())

        except (json.JSONDecodeError, OSError):

            return None


    def _write_state(self, state: dict | None):

        MAINTENANCE_DIR.mkdir(parents=True, exist_ok=True)

        if state is None:

            LAN_OVERRIDE_STATE_FILE.unlink(missing_ok=True)

            return

        LAN_OVERRIDE_STATE_FILE.write_text(json.dumps(state))


    def get_status(self):

        state = self._read_state()

        if not state:

            return {"active": False}

        expires_at = datetime.fromisoformat(state["expires_at"])

        remaining_seconds = max(
            0,
            int((expires_at - datetime.utcnow()).total_seconds())
        )

        return {
            "active": True,
            "interface": state["interface"],
            "temporary_ip": state["temporary_ip"],
            "temporary_prefix": state["temporary_prefix"],
            "original_ip": state["original_ip"],
            "original_prefix": state["original_prefix"],
            "expires_at": state["expires_at"],
            "remaining_seconds": remaining_seconds
        }


    def start_temporary_ip(
        self,
        temporary_ip: str,
        temporary_prefix: int,
        duration_minutes: int
    ):

        if self._read_state():

            return {
                "success": False,
                "message": "A temporary LAN IP change is already active -- revert it first."
            }

        if duration_minutes <= 0 or duration_minutes > MAX_DURATION_MINUTES:

            return {
                "success": False,
                "message": f"duration_minutes must be between 1 and {MAX_DURATION_MINUTES}."
            }

        config = config_loader.reload()

        lan = self.interface_service.get_primary_lan()

        if lan is None:

            return {"success": False, "message": "LAN interface not detected"}

        original_ip = config["dhcp"]["gateway"]

        original_netmask = config["dhcp"]["netmask"]

        original_prefix = ip_interface(
            f"{original_ip}/{original_netmask}"
        ).network.prefixlen

        now = datetime.utcnow()

        expires_at = now + timedelta(minutes=duration_minutes)

        # Stop dnsmasq BEFORE moving the IP -- it's bound to the
        # original address and would otherwise be left in an
        # undefined state (still running, answering nothing, in the
        # way of a clean revert).
        dnsmasq_process_manager.stop()

        self._delete_address(lan.name, original_ip, original_prefix)

        add_result = self.provider.add_address(
            InterfaceAddress(
                interface=lan.name,
                ip=temporary_ip,
                prefix=temporary_prefix
            )
        )

        if add_result.returncode != 0:

            # Best-effort rollback so we don't strand the interface
            # with neither address configured.
            self.provider.add_address(
                InterfaceAddress(
                    interface=lan.name,
                    ip=original_ip,
                    prefix=original_prefix
                )
            )

            dnsmasq_process_manager.start()

            return {
                "success": False,
                "message": f"Failed to apply temporary IP: {add_result.stderr.strip()}"
            }

        self._write_state({
            "interface": lan.name,
            "original_ip": original_ip,
            "original_prefix": original_prefix,
            "temporary_ip": temporary_ip,
            "temporary_prefix": temporary_prefix,
            "started_at": now.isoformat() + "Z",
            "expires_at": expires_at.isoformat() + "Z"
        })

        logger.warning(
            f"LAN interface {lan.name} temporarily moved to "
            f"{temporary_ip}/{temporary_prefix} (reverts at {expires_at.isoformat()} UTC). "
            "DHCP/DNS on the normal LAN subnet are down until then."
        )

        return {
            "success": True,
            "message": f"LAN moved to {temporary_ip}/{temporary_prefix}, reverts in {duration_minutes} min",
            "expires_at": expires_at.isoformat() + "Z"
        }


    def _delete_address(self, interface: str, ip: str, prefix: int):

        subprocess.run(
            ["ip", "addr", "del", f"{ip}/{prefix}", "dev", interface],
            capture_output=True,
            text=True
        )


    def revert(self):

        state = self._read_state()

        if not state:

            return {"success": True, "message": "No temporary LAN IP change is active."}

        self._delete_address(
            state["interface"],
            state["temporary_ip"],
            state["temporary_prefix"]
        )

        add_result = self.provider.add_address(
            InterfaceAddress(
                interface=state["interface"],
                ip=state["original_ip"],
                prefix=state["original_prefix"]
            )
        )

        dnsmasq_process_manager.start()

        self._write_state(None)

        logger.warning(
            f"LAN interface {state['interface']} reverted to "
            f"{state['original_ip']}/{state['original_prefix']}."
        )

        return {
            "success": add_result.returncode == 0,
            "message": "Reverted to original LAN IP."
        }


    def start_watchdog(self):
        """
        Runs once per process (guarded by _watchdog_started), checked
        from ApiComponent at startup -- catches both a normal expiry
        AND the case where the backend restarted mid-window and needs
        to notice a stale override from disk.
        """

        if self._watchdog_started:

            return

        self._watchdog_started = True

        def _loop():

            while True:

                try:

                    status = self.get_status()

                    if status["active"] and status["remaining_seconds"] <= 0:

                        logger.warning(
                            "Temporary LAN IP window expired -- auto-reverting."
                        )

                        self.revert()

                except Exception as error:

                    logger.error(f"LAN override watchdog error: {error}")

                time.sleep(WATCHDOG_POLL_SECONDS)

        thread = threading.Thread(target=_loop, daemon=True)

        thread.start()


temporary_lan_service = TemporaryLanService()
