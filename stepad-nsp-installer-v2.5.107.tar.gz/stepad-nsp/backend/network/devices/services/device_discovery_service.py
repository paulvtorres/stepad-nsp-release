import ipaddress
import subprocess
import time

from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from backend.infrastructure.network.adapters.linux.arp_provider import (
    ARPProvider
)

from backend.infrastructure.network.services.hostname_resolver import (
    HostnameResolver
)

from backend.dhcp.services.dhcp_lease_service import (
    DhcpLeaseService
)

from backend.network.configuration.services.network_configuration_service import (
    NetworkConfigurationService,
)

from backend.network.services.lan_scope_service import LanScopeService

from backend.network.devices.models.network_device import (
    NetworkDevice,
)

from backend.network.devices.repositories.device_repository import (
    DeviceRepository
)

from backend.network.devices.services.device_classifier import (
    DeviceClassifier
)

from backend.network.zones.repositories.network_zone_repository import (
    NetworkZoneRepository
)

from backend.groups.services.group_service import (
    GroupService
)

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.shared.logging.logger import logger


# Ventana de "recien activo" por trafico DNS real: cubre celulares/
# tablets con ahorro de energia que no responden ARP a tiempo (quedan
# INCOMPLETE en la tabla de vecinos) pero siguen navegando -- sin esto
# se dan de baja (u nunca se agregan) pese a tener trafico continuo.
RECENT_DNS_ACTIVITY_MINUTES = 15


class DeviceDiscoveryService:


    def __init__(self):

        self.provider = ARPProvider()

        self.lease_service = DhcpLeaseService()

        self.hostname_resolver = HostnameResolver()

        self.network_configuration = NetworkConfigurationService()

        self.repository = DeviceRepository()

        self.classifier = DeviceClassifier()

        self.zone_repository = NetworkZoneRepository()

        self.lan_scope = LanScopeService()

        self.dns_log_repository = DnsQueryLogRepository()

    def _sweep_lan(
        self,
        network
    ):
        """
        Ping a todos los hosts del segmento LAN (paralelo) para poblar
        la tabla ARP. Los equipos encendidos pero sin trafico hacia el
        NSP no estan en ARP y se marcarian OFFLINE; al barrer, sus
        respuestas quedan en la tabla y el estado es fiel.
        """

        try:

            interface = network.get("interface")

            if interface and not self.lan_scope.is_lan_interface(interface):

                return

            cidr = network.get("network")

            net = ipaddress.ip_network(cidr, strict=False)

        except Exception:

            return

        # No barrer subredes gigantes.
        if net.num_addresses > 4096:

            return

        try:

            for host in net.hosts():

                subprocess.Popen(
                    ["ping", "-c", "1", "-W", "1", "-q", str(host)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

            # Dejar que las respuestas llenen la tabla ARP.
            time.sleep(2)

        except Exception:

            pass

    def synchronize(
        self,
        db: Session,
        *,
        deep: bool = True,
    ):
        # Este metodo hace barrido ping + resolucion de hostname por
        # cada equipo (red/subproceso, hasta ~1.5s cada uno,
        # secuencial). Si el caller ya hizo una lectura en `db` sin
        # comitear (p. ej. MonitoringComponent._check_new_devices),
        # esa transaccion queda abierta ("idle in transaction" en
        # Postgres) durante todo ese tiempo, bloqueando al scheduler y
        # pudiendo colgar la UI. Se cierra aqui antes de arrancar.
        #
        # deep=False: sin ping-storm del segmento; solo ARP/leases
        # (para el tick de monitoreo). deep=True: barrido completo
        # (boton "Escanear red").
        db.commit()

        lan_configs = self.lan_scope.lan_configurations()

        if not lan_configs:

            self._mark_all_devices_offline(db)

            return []

        lan_networks = self.lan_scope.lan_networks()

        devices_by_mac = {}

        for network in lan_configs:

            if deep:

                self._sweep_lan(network)

            interface = network.get("interface")

            if not interface:

                continue

            if not self.lan_scope.is_lan_interface(interface):

                continue

            for device in self.provider.list_devices(interface):

                if not self.lan_scope.is_discoverable(
                    device.ip_address,
                    interface,
                ):

                    continue

                key = device.mac_address.lower()

                devices_by_mac[key] = device

        devices = list(devices_by_mac.values())

        found_macs = set(devices_by_mac.keys())



        leases = [
            lease
            for lease in self.lease_service.list_leases()
            if self.lan_scope.is_lan_ip(lease.ip)
        ]



        leases_by_mac = {

            lease.mac.lower(): lease

            for lease in leases

            if lease.mac

        }



        saved_devices = []

        default_zone = self.zone_repository.find_default(db)

        recent_active_ips = self.dns_log_repository.recent_active_ips(
            db,
            datetime.utcnow() - timedelta(
                minutes=RECENT_DNS_ACTIVITY_MINUTES
            ),
        )

        for device in devices:

            lease = leases_by_mac.get(
                device.mac_address.lower()
            )

            if lease:

                device.hostname = lease.hostname

                device.device_type = self.classifier.classify(
                    device.hostname
                )

        # Resolucion en vivo (NetBIOS/mDNS/LLMNR), EN PARALELO para
        # todos los equipos no-infraestructura -- no solo los que
        # llegaron sin nombre. Esto es a proposito: el lease DHCP
        # puede quedar con el nombre VIEJO si el equipo cambio de
        # nombre pero todavia no renovo el lease (frecuente en
        # Windows), y antes solo se resolvia si "not device.hostname"
        # -- si ya habia un nombre (aunque fuera el viejo, desde el
        # lease) nunca se preguntaba al equipo su nombre actual. Igual
        # que "Actualizar informacion" (refresh_device), el nombre en
        # vivo manda sobre un lease desactualizado. Al ir en paralelo
        # (antes era secuencial, ~1.5s POR equipo) el costo total no
        # crece con la cantidad de equipos.
        from concurrent.futures import ThreadPoolExecutor

        resolvable = [
            device
            for device in devices
            if not DeviceClassifier.is_infrastructure(device.device_type)
        ]

        def _resolve_live_name(device):

            try:

                resolved, _source = (
                    self.hostname_resolver.resolve_with_source(
                        device.ip_address,
                        timeout=1.5,
                    )
                )

                return device.mac_address.lower(), resolved

            except Exception:

                return device.mac_address.lower(), None

        live_names_by_mac = {}

        if resolvable:

            with ThreadPoolExecutor(
                max_workers=min(32, len(resolvable))
            ) as pool:

                for mac, resolved in pool.map(
                    _resolve_live_name, resolvable
                ):

                    if resolved:

                        live_names_by_mac[mac] = resolved

        for device in devices:

            live_name = live_names_by_mac.get(
                device.mac_address.lower()
            )

            if live_name and (
                not device.hostname
                or live_name.lower() != device.hostname.lower()
            ):

                device.hostname = live_name

                device.device_type = self.classifier.classify(
                    live_name
                )

            # Fallback por MAC (OUI del fabricante): muchos telefonos IP,
            # impresoras y routers no declaran hostname ni responden a
            # netbios/mDNS/LLMNR. Si la clasificacion por nombre no los
            # marco como infraestructura, se intenta por fabricante.
            # Solo se aplica si el OUI da un resultado util (nunca
            # "UNKNOWN", para no pisar el tipo derivado del nombre).
            if not DeviceClassifier.is_infrastructure(
                device.device_type
            ):

                mac_type = DeviceClassifier.classify_by_mac(
                    device.mac_address
                )

                if mac_type != "UNKNOWN":

                    device.device_type = mac_type

        # Buscar todos los equipos ya conocidos de UNA sola vez (antes:
        # 1 query por equipo detectado -- con decenas/cientos de
        # equipos eran otras tantas idas y vueltas a la base).
        existing_by_mac = self.repository.find_by_macs(
            db,
            [device.mac_address for device in devices]
        )

        for device in devices:

            existing = existing_by_mac.get(
                device.mac_address.lower()
            )

            if existing:

                # Skip IP assignment for permanent devices only
                # ALWAYS update ip_address with real current IP from ARP/DHCP
                # permanent_ip is a SEPARATE field - only the reserved IP
                existing.ip_address = device.ip_address

                # NO pisar el nombre guardado (p. ej. fijado con
                # "Actualizar información") si el equipo no reporta uno
                # nuevo (lease o resolucion). Si device.hostname es None,
                # se conserva el nombre existente.
                if device.hostname:

                    # El nombre visible era un nombre fijado a mano que
                    # ya no coincide con el que reporta el equipo ahora
                    # -- igual que en "Actualizar informacion", se
                    # limpia para que se vea el nombre real y no uno
                    # congelado.
                    if (
                        existing.display_name
                        and existing.display_name.lower()
                        != device.hostname.lower()
                    ):

                        existing.display_name = None

                    existing.hostname = device.hostname

                existing.vendor = device.vendor

                existing.interface = device.interface

                existing.status = "ONLINE"

                existing.device_type = device.device_type

                existing.last_seen = datetime.utcnow()



                self.repository.update(
                    db,
                    existing
                )


                saved_devices.append(existing)



            else:


                model = NetworkDevice(

                    ip_address=device.ip_address,

                    mac_address=device.mac_address,

                    hostname=device.hostname,

                    vendor=device.vendor,

                    interface=device.interface,

                    status="ONLINE",

                    device_type=device.device_type,

                    zone_id=default_zone.id if default_zone else None,

                    first_seen=datetime.utcnow(),

                    last_seen=datetime.utcnow()

                )



                saved = self.repository.save(
                    db,
                    model
                )

                # New/unrecognized device lands in the default group
                # (Invitados) automatically; the admin moves it to its
                # department later. Los dispositivos de infraestructura
                # (impresoras, teléfonos IP, routers) NO pueden
                # pertenecer a grupos, así que no se asignan.
                if not DeviceClassifier.is_infrastructure(
                    model.device_type
                ):
                    try:

                        group_service = GroupService()

                        default_group = group_service.ensure_default_group(db)

                        group_service.repository.add_device(
                            db,
                            default_group.id,
                            saved.id
                        )

                    except Exception as error:

                        logger.warning(
                            f"Auto-assign to default group failed: {error}"
                        )

                saved_devices.append(saved)



        #
        # Marcar dispositivos desaparecidos como OFFLINE
        #

        existing_devices = self.repository.find_all(db)

        for existing in existing_devices:

            if not self.lan_scope.belongs_to_lan(
                existing.ip_address,
                existing.interface,
            ):

                continue

            if existing.mac_address.lower() not in found_macs:

                if existing.ip_address in recent_active_ips:

                    # No respondio el ARP a tiempo (tipico de moviles en
                    # ahorro de energia) pero SI genero trafico DNS real
                    # hace poco -- sigue online de verdad, no se marca
                    # caido ni se pisa el ultimo visto.
                    existing.status = "ONLINE"

                    existing.last_seen = datetime.utcnow()

                else:

                    existing.status = "OFFLINE"



                self.repository.update(
                    db,
                    existing
                )



        #
        # NO se purgan dispositivos por IP fuera de la red LAN actual:
        # al cambiar el segmento, los equipos conservan su registro (por
        # MAC), grupo y zona; su IP se actualiza cuando reconectan. El
        # borrado es SOLO manual (caso extremo) y preserva los logs.
        #


        #
        # Refrescar nombres desde los leases DHCP (el nombre
        # autoritativo). Esto cubre equipos que renovaron su lease
        # (con un hostname nuevo) pero que en este momento no figuran
        # en el ARP -- así "Escanear Red" sí actualiza el nombre.
        #
        # OJO: debe ser SOLO para equipos que no aparecieron en el ARP
        # de esta pasada (found_macs). Los que sí aparecieron ya se
        # procesaron arriba con resolucion en vivo, que puede haber
        # detectado un nombre MAS actual que el del lease (equipo
        # renombrado pero con lease todavia sin renovar) -- si este
        # segundo pase no los excluye, pisa ese nombre recien
        # detectado con el del lease viejo.
        #

        leased_by_mac = self.repository.find_by_macs(
            db,
            [
                lease.mac for lease in leases
                if lease.mac and lease.mac.lower() not in found_macs
            ]
        )

        for lease in leases:

            if not lease.mac:

                continue

            if lease.mac.lower() in found_macs:

                continue

            leased_device = leased_by_mac.get(lease.mac.lower())

            if leased_device is None:

                # Tiene lease DHCP (el equipo pidio y usa una IP nuestra)
                # pero nunca respondio ARP a tiempo en ningun barrido --
                # p. ej. celulares/tablets con ahorro de energia. Antes
                # esto significaba que JAMAS aparecia en el inventario
                # aunque llevara dias generando trafico DNS real. Se usa
                # la actividad DNS reciente para decidir si esta online
                # ahora, en vez de asumir "nunca visto = no existe".
                device_type = self.classifier.classify(lease.hostname)

                model = NetworkDevice(
                    ip_address=lease.ip,
                    mac_address=lease.mac,
                    hostname=lease.hostname,
                    vendor=None,
                    interface=None,
                    status=(
                        "ONLINE"
                        if lease.ip in recent_active_ips
                        else "OFFLINE"
                    ),
                    device_type=device_type,
                    zone_id=default_zone.id if default_zone else None,
                    first_seen=datetime.utcnow(),
                    last_seen=datetime.utcnow(),
                )

                saved = self.repository.save(db, model)

                if not DeviceClassifier.is_infrastructure(device_type):

                    try:

                        group_service = GroupService()

                        default_group = (
                            group_service.ensure_default_group(db)
                        )

                        group_service.repository.add_device(
                            db,
                            default_group.id,
                            saved.id
                        )

                    except Exception as error:

                        logger.warning(
                            f"Auto-assign to default group failed "
                            f"(lease-only device): {error}"
                        )

                saved_devices.append(saved)

                continue

            # El lease es la fuente autoritativa de la IP ACTUAL --
            # si el equipo dejo de responder ARP justo cuando dnsmasq
            # le reasigno otra IP, el registro se queda con la IP
            # vieja para siempre (el "no aparece" que reporta el
            # usuario es en realidad "aparece con la IP de hace
            # horas/dias"). Se corrige aqui, junto con el estado
            # online/offline usando el trafico DNS reciente en la
            # IP NUEVA (la vieja ya no tiene por que tener trafico).
            ip_changed = leased_device.ip_address != lease.ip

            if ip_changed and leased_device.ip_address:

                leased_device.ip_address = lease.ip

            is_online = lease.ip in recent_active_ips

            if is_online:

                leased_device.status = "ONLINE"

                leased_device.last_seen = datetime.utcnow()

            elif ip_changed:

                leased_device.status = "OFFLINE"

            hostname_changed = (
                bool(lease.hostname)
                and leased_device.hostname != lease.hostname
            )

            if hostname_changed:

                if (
                    leased_device.display_name
                    and leased_device.display_name.lower()
                    != lease.hostname.lower()
                ):

                    leased_device.display_name = None

                leased_device.hostname = lease.hostname

                leased_device.device_type = self.classifier.classify(
                    lease.hostname
                )

            if ip_changed or hostname_changed or is_online:

                self.repository.update(db, leased_device)


        return saved_devices


    def _mark_all_devices_offline(
        self,
        db: Session
    ):

        for device in self.repository.find_all(db):

            if device.status == "ONLINE":

                device.status = "OFFLINE"

                self.repository.update(db, device)