"""
Periodic SMART health checks for secondary disks used by network shares.

Alerts when overall health fails or bad-sector style counters appear
(reallocated / pending / uncorrectable / NVMe media errors).
"""

from __future__ import annotations

import json
import shutil
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from backend.core.config.paths import STEPAD_DIR
from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger


POLL_SECONDS = 30 * 60  # 30 minutes
STATUS_CACHE_SECONDS = 120
ALERT_COOLDOWN_SECONDS = 12 * 60 * 60  # 12 hours per fingerprint

STATE_PATH = STEPAD_DIR / "share-disk-health.json"

# SMART attribute IDs that often precede drive failure.
ATA_BAD_ATTRS = {
    5: "sectores_reasignados",
    187: "errores_no_corregidos",
    197: "sectores_pendientes",
    198: "sectores_offline_malos",
}

TEMP_WARN_C = 60
TEMP_CRIT_C = 70


class ShareDiskHealthService:

    def __init__(self):
        self._stop = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._cache: dict | None = None
        self._cache_at = 0.0

    def start_scheduler(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop = False
            self._thread = threading.Thread(
                target=self._loop,
                name="share-disk-health",
                daemon=True,
            )
            self._thread.start()
            logger.info("Share disk health watch started.")

    def stop_scheduler(self) -> None:
        self._stop = True
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=5)
        self._thread = None
        logger.info("Share disk health watch stopped.")

    def get_report(self, db=None, *, force: bool = False) -> dict:
        now = time.monotonic()
        if (
            not force
            and self._cache is not None
            and (now - self._cache_at) < STATUS_CACHE_SECONDS
        ):
            return self._cache

        owns = db is None
        if owns:
            db = SessionLocal()
        try:
            report = self._build_report(db)
        finally:
            if owns:
                db.close()

        self._cache = report
        self._cache_at = now
        return report

    def _loop(self) -> None:
        for _ in range(60):
            if self._stop:
                return
            time.sleep(1)

        while not self._stop:
            try:
                self._tick()
            except Exception as error:
                logger.exception("Share disk health tick failed: %s", error)
            for _ in range(POLL_SECONDS):
                if self._stop:
                    return
                time.sleep(1)

    def _tick(self) -> None:
        db = SessionLocal()
        try:
            report = self.get_report(db, force=True)
            self._maybe_alert(db, report)
        finally:
            db.close()

    def _build_report(self, db) -> dict:
        from backend.shares.services.network_share_service import (
            NetworkShareService,
        )

        service = NetworkShareService()
        disks = service.list_share_parent_disks(db)
        smart_ok = bool(shutil.which("smartctl"))

        checks = []
        worst = "ok"
        if not smart_ok:
            return {
                "smartctl_installed": False,
                "checked_at": datetime.now(timezone.utc).isoformat(),
                "disks": [],
                "worst": "unavailable",
                "message": (
                    "smartctl no está instalado. "
                    "Instala smartmontools para vigilar la salud del disco."
                ),
            }

        for disk in disks:
            check = self._check_disk(disk)
            checks.append(check)
            level = check.get("level") or "ok"
            if level == "critical":
                worst = "critical"
            elif level == "warning" and worst == "ok":
                worst = "warning"
            elif level == "unavailable" and worst == "ok":
                worst = "unavailable"

        return {
            "smartctl_installed": True,
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "disks": checks,
            "worst": worst,
            "message": None,
        }

    def _check_disk(self, disk: str) -> dict:
        base = {
            "device": disk,
            "level": "unavailable",
            "healthy": None,
            "model": None,
            "serial": None,
            "temperature_c": None,
            "issues": [],
            "metrics": {},
            "message": None,
        }

        data = self._smartctl_json(disk)
        if not data:
            # Try with -d sat for some USB bridges.
            data = self._smartctl_json(disk, extra=["-d", "sat"])
        if not data:
            base["message"] = "SMART no disponible en este disco (común en USB baratos)."
            return base

        model = (
            (data.get("model_name") or data.get("scsi_model_name") or "")
            .strip()
            or None
        )
        serial = (data.get("serial_number") or "").strip() or None
        base["model"] = model
        base["serial"] = serial

        issues: list[str] = []
        metrics: dict = {}
        level = "ok"

        passed = None
        health = data.get("smart_status") or {}
        if isinstance(health, dict) and "passed" in health:
            passed = bool(health.get("passed"))
            if not passed:
                issues.append("SMART reporta fallo de salud del disco.")
                level = "critical"

        temp = None
        temp_block = data.get("temperature") or {}
        if isinstance(temp_block, dict) and temp_block.get("current") is not None:
            try:
                temp = int(temp_block["current"])
            except (TypeError, ValueError):
                temp = None
        base["temperature_c"] = temp
        if temp is not None:
            metrics["temperature_c"] = temp
            if temp >= TEMP_CRIT_C:
                issues.append(f"Temperatura crítica: {temp}°C.")
                level = "critical"
            elif temp >= TEMP_WARN_C:
                issues.append(f"Temperatura alta: {temp}°C.")
                if level == "ok":
                    level = "warning"

        # ATA attributes
        table = data.get("ata_smart_attributes") or {}
        attrs = table.get("table") if isinstance(table, dict) else None
        if isinstance(attrs, list):
            for row in attrs:
                try:
                    attr_id = int(row.get("id"))
                except (TypeError, ValueError):
                    continue
                if attr_id not in ATA_BAD_ATTRS:
                    continue
                raw = row.get("raw") or {}
                value = raw.get("value") if isinstance(raw, dict) else None
                try:
                    value = int(value)
                except (TypeError, ValueError):
                    continue
                label = ATA_BAD_ATTRS[attr_id]
                metrics[label] = value
                if value > 0:
                    issues.append(f"{label.replace('_', ' ')}: {value}")
                    if attr_id in (197, 198) or value >= 10:
                        level = "critical"
                    elif level != "critical":
                        level = "warning"

        # NVMe
        nvme = data.get("nvme_smart_health_information_log") or {}
        if isinstance(nvme, dict) and nvme:
            crit = int(nvme.get("critical_warning") or 0)
            media = int(nvme.get("media_errors") or 0)
            used = int(nvme.get("percentage_used") or 0)
            metrics["nvme_critical_warning"] = crit
            metrics["nvme_media_errors"] = media
            metrics["nvme_percentage_used"] = used
            if crit:
                issues.append(f"NVMe critical_warning={crit}")
                level = "critical"
            if media > 0:
                issues.append(f"Errores de medio NVMe: {media}")
                level = "critical"
            if used >= 90:
                issues.append(f"Desgaste NVMe alto: {used}%")
                if level == "ok":
                    level = "warning"

        if passed is False:
            level = "critical"

        if not issues and passed is True:
            message = "Disco saludable según SMART."
        elif not issues and passed is None:
            message = "SMART leído, sin indicadores claros de fallo."
            level = "ok"
        else:
            message = "; ".join(issues)

        base.update({
            "level": level,
            "healthy": (level == "ok"),
            "issues": issues,
            "metrics": metrics,
            "message": message,
        })
        return base

    def _smartctl_json(self, disk: str, extra: list[str] | None = None) -> dict | None:
        cmd = ["smartctl", "-j", "-H", "-A", "-i"]
        if extra:
            cmd.extend(extra)
        cmd.append(disk)
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
        except Exception:
            return None

        # smartctl exits non-zero when health fails; JSON may still be valid.
        try:
            data = json.loads(result.stdout or "{}")
        except json.JSONDecodeError:
            return None

        if not data or data.get("json_format_version") is None and not data.get("device"):
            # Some versions still return useful keys without format version.
            if not data.get("smart_status") and not data.get("model_name"):
                return None
        return data

    def _maybe_alert(self, db, report: dict) -> None:
        if not report.get("smartctl_installed"):
            return

        state = self._load_state()
        alerts = state.setdefault("alerts", {})
        now = time.time()

        for disk in report.get("disks") or []:
            level = disk.get("level")
            if level not in ("warning", "critical"):
                continue

            device = disk.get("device") or ""
            fingerprint = f"{device}|{level}|{disk.get('message') or ''}"
            previous = alerts.get(device) or {}
            if (
                previous.get("fingerprint") == fingerprint
                and (now - float(previous.get("at") or 0)) < ALERT_COOLDOWN_SECONDS
            ):
                continue

            title = (
                f"Disco de red con problemas: {device}"
                if level == "critical"
                else f"Advertencia de disco de red: {device}"
            )
            message = disk.get("message") or "Indicadores SMART anómalos."
            severity = "critical" if level == "critical" else "warning"

            try:
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type="SHARE_DISK_HEALTH",
                    severity=severity,
                    title=title,
                    message=message[:500],
                )
            except Exception as error:
                logger.warning("Could not create disk health alert: %s", error)

            if level == "critical":
                try:
                    from backend.notifications.services.critical_alert_email_service import (
                        CriticalAlertEmailService,
                    )
                    CriticalAlertEmailService().send(
                        db,
                        title,
                        (
                            f"{message}\n\n"
                            "Revisa Disco de red en el NSP y considera "
                            "reemplazar o respaldar el disco a tiempo."
                        ),
                    )
                except Exception as error:
                    logger.warning("Could not email disk health alert: %s", error)

            alerts[device] = {"fingerprint": fingerprint, "at": now}
            logger.warning("Share disk health alert (%s): %s — %s", level, device, message)

        state["last_report"] = report
        self._save_state(state)

    def _load_state(self) -> dict:
        try:
            if STATE_PATH.exists():
                return json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
        return {}

    def _save_state(self, state: dict) -> None:
        try:
            STEPAD_DIR.mkdir(parents=True, exist_ok=True)
            STATE_PATH.write_text(
                json.dumps(state, indent=2, default=str),
                encoding="utf-8",
            )
        except Exception as error:
            logger.warning("Could not save disk health state: %s", error)


# Singleton used by status API + component.
share_disk_health_service = ShareDiskHealthService()
