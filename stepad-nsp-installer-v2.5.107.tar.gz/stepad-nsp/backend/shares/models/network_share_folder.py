from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NetworkShareFolder(Base):

    __tablename__ = "network_share_folders"
    __table_args__ = (
        UniqueConstraint(
            "volume_id",
            "folder_name",
            name="uq_share_folder_volume_slug",
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    # Samba share name (\\\\IP\\Name) — unique globally.
    name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)

    # Directory name under the volume mountpoint.
    folder_name: Mapped[str] = mapped_column(String(100), nullable=False)

    volume_id: Mapped[int | None] = mapped_column(
        Integer,
        ForeignKey("network_share_volumes.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )

    description: Mapped[str | None] = mapped_column(String(255), nullable=True)

    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

    # True -> published as a Samba share for LAN machines/groups.
    # False (default for new folders) -> reachable only from the NSP web app.
    shared: Mapped[bool] = mapped_column(Boolean, default=False)

    # Scheduled backup policy for the folder directory (private folders).
    # "off" (no schedule) | "times" (backup N times per day) | "on_change"
    # (backup when files change). Copies are versioned.
    backup_mode: Mapped[str] = mapped_column(String(20), default="off")
    backup_times_per_day: Mapped[int] = mapped_column(Integer, default=1)
    backup_retention: Mapped[int] = mapped_column(Integer, default=7)

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )


class GroupFolderAccess(Base):

    __tablename__ = "group_folder_access"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    group_id: Mapped[int] = mapped_column(
        ForeignKey("device_groups.id", ondelete="CASCADE"),
        nullable=False,
    )

    folder_id: Mapped[int] = mapped_column(
        ForeignKey("network_share_folders.id", ondelete="CASCADE"),
        nullable=False,
    )

    # "read" | "write"
    access_mode: Mapped[str] = mapped_column(String(10), default="read")

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )
