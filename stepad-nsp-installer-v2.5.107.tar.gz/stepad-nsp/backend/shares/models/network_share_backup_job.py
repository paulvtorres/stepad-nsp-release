from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NetworkShareBackupJob(Base):

    __tablename__ = "network_share_backup_jobs"

    __table_args__ = (
        UniqueConstraint(
            "folder_id",
            name="uq_backup_job_folder",
        ),
    )

    id: Mapped[int] = mapped_column(
        primary_key=True, autoincrement=True
    )

    # Pick name, e.g. "RESPALDOS".
    name: Mapped[str] = mapped_column(
        String(100), nullable=False, unique=True
    )

    # Absolute directory to snapshot (a shared volume mountpoint or folder).
    source_path: Mapped[str] = mapped_column(
        String(512), nullable=False
    )

    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

    # "daily" (schedule_hour:minute) | "interval" (interval_minutes)
    # | "on_change" (backup when the source tree changes).
    schedule_mode: Mapped[str] = mapped_column(String(20), default="daily")

    schedule_hour: Mapped[int] = mapped_column(Integer, default=2)

    schedule_minute: Mapped[int] = mapped_column(Integer, default=0)

    # Multiple daily times ("HH:MM,HH:MM") for daily mode. When set, it
    # overrides schedule_hour/schedule_minute and runs at each time.
    schedule_times: Mapped[str | None] = mapped_column(
        String(64), nullable=True
    )

    # Interval between backups (minutes) when schedule_mode == "interval".
    interval_minutes: Mapped[int | None] = mapped_column(
        Integer, nullable=True
    )

    # Signature of the source tree used to detect changes in "on_change" mode.
    change_hash: Mapped[str | None] = mapped_column(
        String(64), nullable=True
    )

    # Folder this job backs up (folder backup policies), null for manual jobs.
    folder_id: Mapped[int | None] = mapped_column(
        Integer,
        ForeignKey("network_share_folders.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # Newest N snapshots kept when pruning (forget --keep-last).
    retention_count: Mapped[int] = mapped_column(Integer, default=7)

    # Prune when free space on the backup disk drops below this %.
    prune_free_pct: Mapped[int] = mapped_column(Integer, default=15)

    last_backup_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )

    # Short, human readable result of the last run.
    last_result: Mapped[str | None] = mapped_column(
        String(512), nullable=True
    )

    last_snapshot_id: Mapped[str | None] = mapped_column(
        String(64), nullable=True
    )

    last_bytes: Mapped[int] = mapped_column(BigInteger, default=0)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow
    )

    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )