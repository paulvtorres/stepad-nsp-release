from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NetworkShareVolume(Base):

    __tablename__ = "network_share_volumes"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    # Name shown on the Windows network (\\\\IP\\Name).
    name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)

    device_path: Mapped[str] = mapped_column(String(128), nullable=False)

    device_uuid: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)

    mountpoint: Mapped[str] = mapped_column(String(512), nullable=False)

    sharing: Mapped[bool] = mapped_column(Boolean, default=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    updated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class GroupVolumeAccess(Base):

    __tablename__ = "group_volume_access"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    group_id: Mapped[int] = mapped_column(
        ForeignKey("device_groups.id", ondelete="CASCADE"),
        nullable=False,
    )

    volume_id: Mapped[int] = mapped_column(
        ForeignKey("network_share_volumes.id", ondelete="CASCADE"),
        nullable=False,
    )

    access_mode: Mapped[str] = mapped_column(String(10), default="read")

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
