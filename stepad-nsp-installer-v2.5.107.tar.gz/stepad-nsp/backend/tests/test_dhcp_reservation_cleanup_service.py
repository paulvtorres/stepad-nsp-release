import os
from datetime import datetime, timedelta
from types import SimpleNamespace

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from backend.dhcp.services.dhcp_reservation_cleanup_service import (
    DhcpReservationCleanupService,
    parse_run_time,
)


def test_cleanup_settings_defaults_and_clamp():

    store = {
        "dhcp": {
            "pool_start": "192.168.1.20",
            "pool_end": "192.168.1.200",
        }
    }

    class FakeConfig:

        def get_dhcp_config(self):
            return dict(store["dhcp"])

        def update_section(self, section, values):
            store[section] = dict(values)

    service = DhcpReservationCleanupService()
    service.config_service = FakeConfig()

    settings = service.get_settings()
    assert settings["enabled"] is True
    assert settings["days"] == 14
    assert settings["run_time"] == "03:00"
    assert settings["protect_infrastructure"] is True

    updated = service.update_settings(
        enabled=True,
        days=7,
        run_time="22:30",
    )
    assert updated["enabled"] is True
    assert updated["days"] == 7
    assert updated["run_time"] == "22:30"
    assert store["dhcp"]["reservation_cleanup_hour"] == 22
    assert store["dhcp"]["reservation_cleanup_minute"] == 30


def test_parse_run_time():

    assert parse_run_time("3:05") == (3, 5)
    assert parse_run_time("03:05") == (3, 5)

    try:
        parse_run_time("25:00")
        assert False
    except ValueError:
        pass


def test_is_due_daily_at_configured_time():

    store = {
        "dhcp": {
            "reservation_cleanup_enabled": True,
            "reservation_cleanup_days": 14,
            "reservation_cleanup_hour": 3,
            "reservation_cleanup_minute": 0,
            "reservation_cleanup_last_run_at": None,
        }
    }

    class FakeConfig:

        def get_dhcp_config(self):
            return dict(store["dhcp"])

        def update_section(self, section, values):
            store[section] = dict(values)

    service = DhcpReservationCleanupService()
    service.config_service = FakeConfig()
    settings = service.get_settings()

    before = datetime(2026, 9, 2, 2, 59, 0)
    assert service.is_due(settings, before) is False

    at_time = datetime(2026, 9, 2, 3, 0, 0)
    assert service.is_due(settings, at_time) is True

    store["dhcp"]["reservation_cleanup_last_run_at"] = (
        "2026-09-02T03:00:10"
    )
    settings = service.get_settings()
    later_same_day = datetime(2026, 9, 2, 15, 0, 0)
    assert service.is_due(settings, later_same_day) is False

    next_day = datetime(2026, 9, 3, 3, 0, 0)
    assert service.is_due(settings, next_day) is True


def test_list_candidates_skips_infrastructure(monkeypatch):

    cutoff_old = datetime.now() - timedelta(days=30)
    devices = [
        SimpleNamespace(
            id=1,
            hostname="old-phone",
            mac_address="aa:bb:cc:dd:ee:01",
            ip_address="192.168.1.50",
            device_type="MOBILE",
            status="OFFLINE",
            last_seen=cutoff_old,
        ),
        SimpleNamespace(
            id=2,
            hostname="printer",
            mac_address="aa:bb:cc:dd:ee:02",
            ip_address="192.168.1.51",
            device_type="PRINTER",
            status="OFFLINE",
            last_seen=cutoff_old,
        ),
        SimpleNamespace(
            id=3,
            hostname="recent",
            mac_address="aa:bb:cc:dd:ee:03",
            ip_address="192.168.1.52",
            device_type="MOBILE",
            status="OFFLINE",
            last_seen=datetime.now() - timedelta(days=1),
        ),
    ]

    class FakeQuery:
        def filter(self, *args, **kwargs):
            return self

        def order_by(self, *args, **kwargs):
            return self

        def all(self):
            return [
                d for d in devices
                if d.status == "OFFLINE" and d.last_seen < (
                    datetime.now() - timedelta(days=14)
                )
            ]

    class FakeDb:
        def query(self, *args, **kwargs):
            return FakeQuery()

        def close(self):
            return None

    service = DhcpReservationCleanupService()
    service.config_service = SimpleNamespace(
        get_dhcp_config=lambda: {
            "reservation_cleanup_enabled": True,
            "reservation_cleanup_days": 14,
            "reservation_cleanup_protect_infrastructure": True,
        }
    )

    monkeypatch.setattr(
        "backend.dhcp.services.dhcp_reservation_cleanup_service.SessionLocal",
        lambda: FakeDb(),
    )

    candidates = service.list_candidates()
    assert [c["id"] for c in candidates] == [1]
