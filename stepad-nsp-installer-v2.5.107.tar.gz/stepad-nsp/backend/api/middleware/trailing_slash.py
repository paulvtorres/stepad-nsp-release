"""
HTTP middleware that tolerates mixed trailing-slash conventions in API routes.

Some routes were registered with a trailing slash, others without, and
cached frontend bundles may call either form. Starlette's BaseHTTPMiddleware
only allows a single ``call_next`` per request, so instead of re-dispatching
internally we issue a 307 redirect whenever the alternate path maps to a
registered route; the browser/fetch client follows it transparently.
"""

from starlette.requests import Request
from starlette.responses import RedirectResponse


def register_trailing_slash_middleware(app):
    @app.middleware("http")
    async def tolerate_trailing_slash(request: Request, call_next):
        response = await call_next(request)

        if response.status_code not in (404, 405):
            return response

        path = request.url.path

        if path == "/" or path.endswith(".html"):
            return response

        alternate = path[:-1] if path.endswith("/") else path + "/"

        if alternate == path:
            return response

        if _route_exists(app, request.method, alternate):
            return RedirectResponse(
                str(request.url).replace(path, alternate),
                status_code=307,
            )

        return response


def _route_exists(app, method: str, path: str) -> bool:
    """Returns True only when a route is registered with this exact path."""
    for route in app.router.routes:
        registered = getattr(route, "path", None)
        if registered is None:
            continue
        if registered == path:
            return True
    return False
