"""API para gestión de unidades de red (mounts SMB)."""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles
from backend.shares.services.network_unit_service import NetworkUnitService

router = APIRouter(
    prefix="/shares/network-units",
    tags=["Network Units"],
)

service = NetworkUnitService()


class CreateUnitRequest(BaseModel):
    name: str
    host: str
    share: str
    letter: str
    user: str = ""
    password: str = ""


@router.get("")
def list_units(
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return {"units": service.list_units()}


@router.post("", status_code=201)
def create_unit(
    request: CreateUnitRequest,
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    try:
        unit = service.create_unit(
            name=request.name,
            host=request.host,
            share=request.share,
            letter=request.letter,
            user=request.user,
            password=request.password,
        )
        return unit
    except ValueError as e:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{unit_id}")
def delete_unit(
    unit_id: int,
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    service.delete_unit(unit_id)
    return {"success": True}


@router.put("/{unit_id}/toggle")
def toggle_unit(
    unit_id: int,
    enabled: bool,
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    unit = service.toggle_unit(unit_id, enabled)
    return unit
