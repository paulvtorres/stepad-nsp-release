from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.core.database.dependency import get_db
from backend.shares.services.web_file_service import WebFileService
from backend.shared.constants.user_roles import UserRoles

router = APIRouter(
    prefix="/shares/web",
    tags=["Network Disk Web Files"],
)

service = WebFileService()


@router.get("/units")
def list_units(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return {"units": service.list_units(db)}


@router.get("/list")
def list_dir(
    unit: str = Query(...),
    prefix: str = Query(default=""),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.list_dir(db, unit=unit, prefix=prefix)


@router.post("/upload")
async def upload(
    unit: str = Query(...),
    directory: str = Query(default=""),
    files: list[UploadFile] = File(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return await service.upload(db, unit=unit, dirname=directory, files=files)


@router.get("/download")
def download(
    unit: str = Query(...),
    path: str = Query(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    target = service.download(db, unit=unit, path=path)
    return FileResponse(
        target,
        media_type="application/octet-stream",
        filename=target.name,
    )


@router.post("/mkdir")
def mkdir(
    unit: str = Query(...),
    directory: str = Query(default=""),
    name: str = Query(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.mkdir(db, unit=unit, dirname=directory, name=name)


@router.post("/move")
def move(
    unit: str = Query(...),
    source: str = Query(...),
    dest: str = Query(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.move(db, unit=unit, source=source, dest=dest)


@router.delete("")
def delete(
    unit: str = Query(...),
    path: str = Query(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.remove(db, unit=unit, path=path)