import os
import shutil
import subprocess
import tempfile
import threading
import time

from datetime import datetime
from backend.shared.utils.datetimes import now_ecuador
from pathlib import Path

from sqlalchemy.orm import Session

from backend.backups.models.backup_settings import BackupSettings
from backend.shared.utils.datetimes import to_iso_utc

from backend.backups.repositories.backup_settings_repository import (
    BackupSettingsRepository
)

from backend.core.config.settings import Settings
from backend.shared.config.config_loader import config_loader

from backend.core.database.session import SessionLocal

from backend.notifications.services.email_subject_service import (
    BACKUP_VARIABLES,
    DEFAULT_BACKUP_SUBJECT,
    build_backup_subject,
)

from backend.shared.logging.logger import logger


BACKUP_DIR = Path("/etc/stepad/backups")

ENV_FILE = Path("/etc/stepad/stepad.env")


def _ignore_backups(directory, names):

    return [
        name for name in names
        if name == "backups" or name.endswith(".pid")
    ]


class BackupService:

    def __init__(self):

        self.repository = BackupSettingsRepository()

        self._scheduler_thread = None

        self._stop = False

    def get_settings(
        self,
        db: Session
    ) -> dict:

        settings = self.repository.get(db)

        return {
            "id": settings.id,
            "enabled": settings.enabled,
            "send_hour": settings.send_hour,
            "send_minute": settings.send_minute,
            "retention_count": settings.retention_count,
            "email_backup": settings.email_backup,
            "to_emails": settings.to_emails,
            "bcc_emails": settings.bcc_emails,
            "email_subject": settings.email_subject or "",
            "email_subject_default": DEFAULT_BACKUP_SUBJECT,
            "email_subject_variables": list(BACKUP_VARIABLES),
            "last_backup_at": to_iso_utc(settings.last_backup_at)
        }

    def save_settings(
        self,
        db: Session,
        data
    ) -> dict:

        settings = self.repository.get(db)

        if data.enabled is not None:
            settings.enabled = data.enabled

        if data.send_hour is not None:
            settings.send_hour = data.send_hour

        if data.send_minute is not None:
            settings.send_minute = data.send_minute

        if data.retention_count is not None:
            settings.retention_count = data.retention_count

        if data.email_backup is not None:
            settings.email_backup = data.email_backup

        if data.to_emails is not None:
            settings.to_emails = data.to_emails

        if data.bcc_emails is not None:
            settings.bcc_emails = data.bcc_emails

        if data.email_subject is not None:
            settings.email_subject = (data.email_subject or "").strip()

        self.repository.save(db, settings)

        return self.get_settings(db)

    def list_backups(
        self
    ) -> list[dict]:

        if not BACKUP_DIR.exists():

            return []

        backups = []

        for path in sorted(
            BACKUP_DIR.glob("stepad-backup-*.tar.gz.enc"),
            key=lambda p: p.stat().st_mtime,
            reverse=True
        ):

            backups.append({
                "name": path.name,
                "size": path.stat().st_size,
                "modified": to_iso_utc(
                    datetime.utcfromtimestamp(path.stat().st_mtime)
                )
            })

        return backups

    def _safe_backup_path(
        self,
        filename: str
    ) -> Path | None:

        if not filename or "/" in filename or ".." in filename:

            return None

        path = BACKUP_DIR / filename

        if not path.is_file():

            return None

        return path

    def create_backup(
        self,
        db: Session,
        settings: BackupSettings = None
    ) -> dict:

        settings = settings or self.repository.get(db)

        try:

            BACKUP_DIR.mkdir(parents=True, exist_ok=True)

            timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")

            filename = f"stepad-backup-{timestamp}.tar.gz"

            destination = BACKUP_DIR / filename

            with tempfile.TemporaryDirectory() as staging:

                stage = Path(staging)

                # 1) Database dump (via the application role).
                db_dump = stage / "database.sql.gz"

                env = os.environ.copy()

                env["PGPASSWORD"] = Settings.DB_PASSWORD

                dump_result = subprocess.run(
                    [
                        "bash", "-c",
                        f"/usr/bin/pg_dump -h {Settings.DB_HOST} "
                        f"-p {Settings.DB_PORT} -U {Settings.DB_USER} "
                        f"{Settings.DB_NAME} | gzip > {db_dump}"
                    ],
                    env=env,
                    capture_output=True,
                    text=True
                )

                if db_dump.stat().st_size == 0:

                    return {
                        "success": False,
                        "message": "Database dump failed"
                    }

                # 2) Runtime secrets (DB/JWT) -- needed for full recovery.
                if ENV_FILE.exists():

                    shutil.copy(ENV_FILE, stage / "stepad.env")

                # 3) Application YAML configuration.
                if Path(config_loader.config_path).exists():

                    shutil.copy(
                        config_loader.config_path,
                        stage / "config.yaml"
                    )

                # 4) The whole /etc/stepad tree (DNS, RPZ, zones,
                #    firewall state, WireGuard keys, TLS certs) minus
                #    the backups dir and pid files.
                if Path("/etc/stepad").exists():

                    shutil.copytree(
                        "/etc/stepad",
                        stage / "stepad",
                        ignore=_ignore_backups
                    )

                archive = subprocess.run(
                    ["tar", "czf", str(destination), "-C", str(stage), "."],
                    capture_output=True,
                    text=True
                )

                if archive.returncode != 0:

                    return {
                        "success": False,
                        "message": f"Archive failed: {archive.stderr.strip()}"
                    }

            # Cifrar el respaldo (AES-256) y eliminar el archivo plano.
            encrypted = self._encrypt(destination)

            if encrypted is None:

                return {
                    "success": False,
                    "message": "No se pudo cifrar el respaldo"
                }

            filename = encrypted.name

            destination = encrypted

            settings.last_backup_at = now_ecuador()

            self.repository.save(db, settings)

            removed = self._cleanup(settings)

            logger.info(
                f"Backup created (encrypted): {filename} "
                f"({destination.stat().st_size} bytes)."
            )

            if settings.email_backup:

                self._email_backup(destination, settings)

            return {
                "success": True,
                "filename": filename,
                "size": destination.stat().st_size,
                "removed_old": removed,
                "encrypted": True
            }

        except Exception as error:

            logger.exception(f"Backup failed: {error}")

            return {
                "success": False,
                "message": f"Backup failed: {error}"
            }

    def _get_backup_key(self) -> str:

        try:

            if ENV_FILE.exists():

                for line in ENV_FILE.read_text().splitlines():

                    if line.startswith("STEPAD_BACKUP_KEY="):

                        value = line.split("=", 1)[1].strip().strip('"')

                        if value:

                            return value

        except Exception:

            pass

        import secrets

        key = secrets.token_hex(16)

        try:

            with open(ENV_FILE, "a") as file:

                file.write(f"\nSTEPAD_BACKUP_KEY={key}\n")

        except Exception as error:

            logger.error(f"No se pudo guardar la clave de respaldo: {error}")

        return key

    def _encrypt(self, source: Path):

        key = self._get_backup_key()

        encrypted = source.with_suffix(source.suffix + ".enc")

        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-pbkdf2",
                "-salt", "-pass", f"pass:{key}",
                "-in", str(source),
                "-out", str(encrypted)
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:

            logger.error(
                f"Fallo al cifrar respaldo: {result.stderr.strip()}"
            )

            return None

        try:

            source.unlink()

        except Exception:

            pass

        return encrypted

    def _email_backup(self, path: Path, settings: BackupSettings):

        try:

            from backend.notifications.services.email_service import (
                EmailService
            )
            from backend.notifications.services.email_settings_service import (
                build_delivery_context,
            )
            from backend.core.database.session import SessionLocal

            db = SessionLocal()

            try:

                to_emails = (settings.to_emails or "").strip() or None

                bcc_emails = settings.bcc_emails or ""

                delivery = build_delivery_context(
                    db,
                    to_emails=to_emails,
                    bcc_emails=bcc_emails,
                )

                if delivery is None:

                    logger.info(
                        "Respaldos por email omitidos (correo no configurado)."
                    )

                    return

                if not EmailService()._recipients(delivery):

                    logger.info(
                        "Respaldos por email omitidos (sin destinatarios)."
                    )

                    return

                subject = build_backup_subject(db, settings.email_subject)

                EmailService().send_attachment(
                    delivery,
                    subject,
                    "Respaldo cifrado de la configuración STEPAD NSP (adjunto).",
                    path
                )

            finally:

                db.close()

        except Exception as error:

            logger.error(
                f"Fallo al enviar respaldo por email: {error}"
            )

    def _cleanup(
        self,
        settings: BackupSettings
    ) -> int:

        files = sorted(
            BACKUP_DIR.glob("stepad-backup-*.tar.gz.enc"),
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )

        removed = 0

        for old in files[settings.retention_count:]:

            try:

                old.unlink()

                removed += 1

            except OSError:

                pass

        return removed

    def delete_backup(
        self,
        filename: str
    ) -> dict:

        path = self._safe_backup_path(filename)

        if path is None:

            return {
                "success": False,
                "message": "Backup not found"
            }

        path.unlink()

        return {"success": True}

    def backup_path(
        self,
        filename: str
    ):

        return self._safe_backup_path(filename)

    def restore_backup(
        self,
        filename: str
    ):

        path = self._safe_backup_path(filename)

        if path is None:

            return {
                "success": False,
                "message": "Respaldo no encontrado"
            }

        import tempfile

        try:

            key = self._get_backup_key()

            with tempfile.TemporaryDirectory() as staging:

                stage = Path(staging)

                decrypted = stage / "backup.tar.gz"

                result = subprocess.run(
                    [
                        "openssl", "enc", "-d", "-aes-256-cbc",
                        "-pbkdf2", "-pass", f"pass:{key}",
                        "-in", str(path), "-out", str(decrypted)
                    ],
                    capture_output=True,
                    text=True,
                    timeout=120
                )

                if result.returncode != 0:

                    return {
                        "success": False,
                        "message": f"No se pudo descifrar: {result.stderr.strip()}"
                    }

                result = subprocess.run(
                    ["tar", "xzf", str(decrypted), "-C", str(stage)],
                    capture_output=True,
                    text=True,
                    timeout=120
                )

                if result.returncode != 0:

                    return {
                        "success": False,
                        "message": f"Error al extraer: {result.stderr.strip()}"
                    }

                restored = []

                # Restaurar /etc/stepad (DNS, RPZ, certificados, VPN...).
                if (stage / "stepad").exists():

                    subprocess.run(
                        ["rm", "-rf", "/etc/stepad"],
                        capture_output=True,
                        timeout=60
                    )

                    shutil.copytree(
                        stage / "stepad",
                        Path("/etc/stepad")
                    )

                    restored.append("configuración del sistema")

                # Restaurar config.yaml de la aplicación.
                if (stage / "config.yaml").exists():

                    shutil.copy(
                        stage / "config.yaml",
                        config_loader.config_path
                    )

                    restored.append("configuración de red")

                # Restaurar la base de datos.
                if (stage / "database.sql.gz").exists():

                    env = os.environ.copy()

                    env["PGPASSWORD"] = Settings.DB_PASSWORD

                    subprocess.run(
                        [
                            "psql", "-h", "127.0.0.1",
                            "-U", Settings.DB_USER, "-d", Settings.DB_NAME,
                            "-c", "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"
                        ],
                        env=env,
                        capture_output=True,
                        text=True,
                        timeout=120
                    )

                    dump = stage / "database.sql.gz"

                    result = subprocess.run(
                        [
                            "bash", "-c",
                            f"gunzip -c {dump} | psql -h 127.0.0.1 "
                            f"-U {Settings.DB_USER} -d {Settings.DB_NAME}"
                        ],
                        env=env,
                        capture_output=True,
                        text=True,
                        timeout=300
                    )

                    if result.returncode != 0:

                        return {
                            "success": False,
                            "message": f"Error al restaurar BD: {result.stderr.strip()[:300]}"
                        }

                    # Las interfaces físicas cambian de máquina (sus MAC
                    # no viajan): borrar el registro de interfaces para
                    # que el nuevo equipo las redetecte y se reasignen
                    # WAN/LAN desde cero.
                    subprocess.run(
                        [
                            "psql", "-h", "127.0.0.1",
                            "-U", Settings.DB_USER, "-d", Settings.DB_NAME,
                            "-c", "DELETE FROM managed_interfaces;"
                        ],
                        env=env,
                        capture_output=True,
                        text=True,
                        timeout=60
                    )

                    restored.append("base de datos")

            self._restart_in_background()

            return {
                "success": True,
                "message": (
                    "Respaldo restaurado (" + ", ".join(restored) +
                    "). Reiniciando servicios..."
                )
            }

        except Exception as error:

            logger.exception(f"Restore failed: {error}")

            return {
                "success": False,
                "message": f"Restore falló: {error}"
            }

    def _restart_in_background(self):

        import threading

        def run():

            try:

                subprocess.run(
                    ["systemctl", "restart", "stepad-nsp"],
                    timeout=60
                )

            except Exception:

                pass

        threading.Thread(
            target=run,
            daemon=True
        ).start()

    def is_due(
        self,
        settings: BackupSettings,
        now: datetime
    ) -> bool:

        if not settings.enabled:

            return False

        if (
            now.hour < settings.send_hour
            or (
                now.hour == settings.send_hour
                and now.minute < settings.send_minute
            )
        ):

            return False

        last = settings.last_backup_at

        if last is None:

            return True

        return last.date() < now.date()

    def _scheduler_loop(
        self
    ):

        logger.info("Backup scheduler started.")

        while not self._stop:

            try:

                db = SessionLocal()

                try:

                    settings = self.repository.get(db)

                    if self.is_due(settings, now_ecuador()):

                        result = self.create_backup(db, settings)

                        logger.info(f"Scheduled backup: {result}")

                finally:

                    db.close()

            except Exception as error:

                logger.exception(f"Backup scheduler error: {error}")

            time.sleep(60)

    def start_scheduler(
        self
    ):

        if self._scheduler_thread is not None:

            return

        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="backup-scheduler"
        )

        self._scheduler_thread.start()
