"""
Gestión de unidades de red (mounts SMB persistentes).
Cada unidad de red se monta como /mnt/stepad-network/{letter}
y aparece como carpeta local para respaldos.
"""
import json
import os
import re
import subprocess
from pathlib import Path
from backend.shared.logging.logger import logger

# NOTA: antes apuntaba a una ruta del entorno de desarrollo
# (/home/paulan/stepad-nsp/...), lo que rompía esta función en cualquier
# instalación real. /etc/stepad/ es donde vive el resto de la config
# runtime del NSP (stepad.env, credenciales admin, etc.).
CONFIG_FILE = Path("/etc/stepad/network_units.json")
# Ruta vieja (entorno de desarrollo del autor original): si existe y la
# nueva todavía no, se migra una sola vez para no perder unidades ya
# configuradas en una instalación que corrió con el bug.
_LEGACY_CONFIG_FILE = Path(
    "/home/paulan/stepad-nsp/backend/shared/config/network_units.json"
)
MOUNT_BASE = Path("/mnt/stepad-network")

# El frontend limita "letter" a 1 carácter, pero la API no lo validaba:
# quien llamara a POST /shares/network-units directamente podía mandar
# algo como "../etc" y MOUNT_BASE / letter escaparía del directorio de
# montajes esperado. Letras/números/"-"/"_" alcanza para el caso de uso
# real (una letra de unidad) y bloquea cualquier separador de ruta.
_SAFE_LETTER_RE = re.compile(r"^[A-Za-z0-9_-]{1,8}$")


class NetworkUnitService:

    def __init__(self):
        MOUNT_BASE.mkdir(parents=True, exist_ok=True)
        self._migrate_legacy_config()

    def _migrate_legacy_config(self) -> None:
        if CONFIG_FILE.exists() or not _LEGACY_CONFIG_FILE.exists():
            return
        try:
            CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
            CONFIG_FILE.write_bytes(_LEGACY_CONFIG_FILE.read_bytes())
            os.chmod(CONFIG_FILE, 0o600)
            logger.info(
                "Migrated network_units.json from legacy dev path %s to %s",
                _LEGACY_CONFIG_FILE,
                CONFIG_FILE,
            )
        except OSError as error:
            logger.warning("Could not migrate legacy network_units.json: %s", error)

    def _load(self) -> dict:
        try:
            return json.loads(CONFIG_FILE.read_text("utf-8"))
        except (FileNotFoundError, json.JSONDecodeError):
            return {"units": []}

    def _save(self, data: dict) -> None:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        # Contiene contraseñas SMB en texto plano: mismo criterio que el
        # resto de la config sensible del NSP (stepad.env, credenciales).
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except OSError:
            pass

    def list_units(self) -> list[dict]:
        data = self._load()
        units = []
        for unit in data.get("units", []):
            mount_point = MOUNT_BASE / unit["letter"]
            mounted = mount_point.is_mount()
            # No repetir la contraseña SMB en la respuesta de la API: quien
            # pueda listar unidades (hoy solo ADMIN, y a partir de este
            # cambio también OPERATOR de solo lectura) no necesita verla en
            # texto plano para saber que la unidad existe y está montada.
            safe_unit = {k: v for k, v in unit.items() if k != "password"}
            units.append({
                **safe_unit,
                "has_password": bool(unit.get("password")),
                "mount_point": str(mount_point),
                "mounted": mounted,
                "available": mounted and mount_point.is_dir(),
            })
        return units

    def create_unit(self, name: str, host: str, share: str, letter: str, user: str = "", password: str = "") -> dict:
        letter = (letter or "").strip().upper()
        if not _SAFE_LETTER_RE.match(letter):
            raise ValueError(
                "La letra de la unidad solo puede tener letras, números, "
                "'-' o '_' (máximo 8 caracteres)."
            )
        data = self._load()
        # Validar letra única
        if any(u["letter"] == letter for u in data.get("units", [])):
            raise ValueError(f"La letra {letter} ya está en uso.")
        unit = {
            "id": len(data.get("units", [])) + 1,
            "name": name,
            "host": host,
            "share": share,
            "letter": letter,
            "user": user,
            "password": password,
            "enabled": True,
        }
        data.setdefault("units", []).append(unit)
        self._save(data)
        # Montar inmediatamente
        self._mount_unit(unit)
        return unit

    def delete_unit(self, unit_id: int) -> None:
        data = self._load()
        unit = next((u for u in data.get("units", []) if u["id"] == unit_id), None)
        if unit:
            self._unmount_unit(unit)
            # Clean up backup jobs associated with this unit
            source_path = "/mnt/stepad-network/" + unit.get("letter", "")
            try:
                from backend.shares.services.share_backup_service import get_share_backup_service
                backup_svc = get_share_backup_service()
                backup_svc.delete_jobs_for_source(source_path)
            except Exception:
                pass
            data["units"] = [u for u in data["units"] if u["id"] != unit_id]
            self._save(data)

    def toggle_unit(self, unit_id: int, enabled: bool) -> dict:
        data = self._load()
        unit = next((u for u in data.get("units", []) if u["id"] == unit_id), None)
        if not unit:
            raise ValueError("Unidad no encontrada.")
        unit["enabled"] = enabled
        self._save(data)
        if enabled:
            self._mount_unit(unit)
        else:
            self._unmount_unit(unit)
        return unit

    def _mount_unit(self, unit: dict) -> bool:
        mount_point = MOUNT_BASE / unit["letter"]
        mount_point.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(mount_point, 0o755)
        except Exception:
            pass
        user = unit.get("user", "")
        password = unit.get("password", "")
        opts = f"uid=0,gid=0,iocharset=utf8,vers=3.0,nobrl,soft,echo_interval=15"
        if user:
            opts = f"username={user},password={password},{opts}"
        else:
            opts = f"guest,{opts}"
        cmd = ["mount", "-t", "cifs", f"//{unit['host']}/{unit['share']}", str(mount_point), "-o", opts]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            logger.info("Mounted //%s/%s at %s", unit["host"], unit["share"], mount_point)
            # Create private Respaldo vault folder for backup jobs
            respaldo = mount_point / "Respaldo"
            try:
                respaldo.mkdir(exist_ok=True)
                os.chmod(str(respaldo), 0o755)
            except Exception:
                pass
            return True
        else:
            logger.error("Failed to mount //%s/%s: %s", unit["host"], unit["share"], result.stderr)
            return False

    def _unmount_unit(self, unit: dict) -> None:
        mount_point = MOUNT_BASE / unit["letter"]
        if mount_point.exists():
            subprocess.run(["umount", str(mount_point)], capture_output=True, timeout=10)

    def mount_all(self) -> None:
        """Monta todas las unidades habilitadas (al iniciar el servicio)."""
        data = self._load()
        for unit in data.get("units", []):
            if unit.get("enabled", True):
                self._mount_unit(unit)
