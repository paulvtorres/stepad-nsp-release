"""
Watch shared volume trees for mass file changes (ransomware-like activity).

When many files are modified in a short window, force Samba shares to
read-only so further encryption stops. An admin must unlock from the UI.
"""

from __future__ import annotations

import subprocess
import threading
import time
from pathlib import Path

from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger


POLL_SECONDS = 15
# find -mmin: files modified in the last N minutes
WATCH_WINDOW_MINUTES = 1
SUSPICIOUS_THRESHOLD = 12
SUSPICIOUS_PATTERNS = (
    "*.encrypted",
    "*.locked",
    "*.crypto",
    "*.crypt",
    "*.onion",
    "*.aaaa",
    "*.micro",
    "*.zzz",
    "*.enc",
)


class ShareIntegrityWatchService:

    def __init__(self):
        self._stop = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._last_trip_monotonic = 0.0

    def start_scheduler(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop = False
            self._thread = threading.Thread(
                target=self._loop,
                name="share-integrity-watch",
                daemon=True,
            )
            self._thread.start()
            logger.info("Share integrity watch started.")

    def stop_scheduler(self) -> None:
        self._stop = True
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=5)
        self._thread = None
        logger.info("Share integrity watch stopped.")

    def _loop(self) -> None:
        # Warm-up: avoid locking right after boot while mounts settle.
        for _ in range(POLL_SECONDS * 2):
            if self._stop:
                return
            time.sleep(1)

        while not self._stop:
            try:
                self._tick()
            except Exception as error:
                logger.exception("Share integrity watch tick failed: %s", error)
            for _ in range(POLL_SECONDS):
                if self._stop:
                    return
                time.sleep(1)

    def _tick(self) -> None:
        from backend.shares.services.network_share_service import (
            NetworkShareService,
        )

        db = SessionLocal()
        try:
            service = NetworkShareService()
            row = service._settings(db)
            if not getattr(row, "integrity_watch_enabled", True):
                return
            if getattr(row, "integrity_locked", False):
                return
            if service.is_integrity_paused(db, row=row):
                return

            # No escanear mientras un respaldo "por horario" (daily/
            # interval) esté en curso: es lectura masiva legítima del
            # árbol de origen y no debe poder disparar el bloqueo por
            # error. La ventana sin vigilancia dura solo lo que dura ESE
            # respaldo -- se reactiva sola en el siguiente tick apenas
            # termina. "on_change" queda fuera a propósito (pendiente).
            from backend.shares.services.share_backup_service import (
                get_share_backup_service,
            )
            if get_share_backup_service().has_active_protected_backup():
                return

            roots = service.list_integrity_roots(db)
            if not roots:
                return

            threshold = int(getattr(row, "integrity_change_threshold", None) or 80)
            threshold = max(20, min(5000, threshold))

            changed = 0
            suspicious = 0
            details: list[str] = []

            for root in roots:
                c = self._count_recent_files(root, WATCH_WINDOW_MINUTES)
                s = self._count_suspicious(root, WATCH_WINDOW_MINUTES)
                changed += c
                suspicious += s
                if c or s:
                    details.append(f"{root}: {c} cambios, {s} sospechosos")

            trip = None
            if changed >= threshold:
                trip = (
                    f"Muchos archivos modificados de golpe ({changed} en "
                    f"~{WATCH_WINDOW_MINUTES} min, umbral {threshold}). "
                    + "; ".join(details[:4])
                )
            elif suspicious >= SUSPICIOUS_THRESHOLD:
                trip = (
                    f"Extensiones sospechosas de ransomware ({suspicious} "
                    f"archivos recientes). " + "; ".join(details[:4])
                )

            if not trip:
                return

            # Debounce repeated trips if unlock races.
            now = time.monotonic()
            if now - self._last_trip_monotonic < 30:
                return
            self._last_trip_monotonic = now

            service.trip_integrity_lock(db, detail=trip[:500])
        finally:
            db.close()

    def _count_recent_files(self, root: str, minutes: int) -> int:
        path = Path(root)
        if not path.is_dir():
            return 0
        try:
            result = subprocess.run(
                [
                    "find", str(path),
                    "-xdev",
                    "-path", "*/Respaldo", "-prune", "-o",
                    "-type", "f",
                    "-mmin", f"-{max(1, minutes)}",
                    "-printf", "1",
                ],
                capture_output=True,
                text=True,
                timeout=25,
            )
        except Exception:
            return 0
        if result.returncode not in (0, 1):
            return 0
        return len(result.stdout or "")

    def _count_suspicious(self, root: str, minutes: int) -> int:
        path = Path(root)
        if not path.is_dir():
            return 0

        # find path -type f -mmin -N \( -iname '*.encrypted' -o ... \)
        # Exclude the backup vault folder (Respaldo)
        expr: list[str] = [
            "find", str(path),
            "-xdev",
            "-path", "*/Respaldo", "-prune", "-o",
            "-type", "f",
            "-mmin", f"-{max(1, minutes)}",
            "(",
        ]
        for i, pattern in enumerate(SUSPICIOUS_PATTERNS):
            if i:
                expr.append("-o")
            expr.extend(["-iname", pattern])
        expr.extend([")", "-printf", "1"])

        try:
            result = subprocess.run(
                expr,
                capture_output=True,
                text=True,
                timeout=25,
            )
        except Exception:
            return 0
        if result.returncode not in (0, 1):
            return 0
        return len(result.stdout or "")
