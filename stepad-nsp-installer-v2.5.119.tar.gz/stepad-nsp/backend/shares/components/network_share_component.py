from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality
from backend.shares.services.network_share_service import NetworkShareService
from backend.shares.services.share_disk_health_service import (
    share_disk_health_service,
)
from backend.shares.services.share_integrity_watch_service import (
    ShareIntegrityWatchService,
)
from backend.shares.services.share_backup_service import get_share_backup_service
from backend.shares.services.network_unit_service import NetworkUnitService
from backend.shared.logging.logger import logger


class NetworkShareComponent(BaseComponent):

    name = "network_shares"

    criticality = ComponentCriticality.OPTIONAL

    def __init__(self):
        self.service = NetworkShareService()
        self.integrity_watch = ShareIntegrityWatchService()
        # Singleton: the API routes (share_backups.py) and the monitoring
        # watchdog also use get_share_backup_service(). Instantiating
        # ShareBackupService() directly here used to create a SECOND,
        # independent scheduler with its own in-memory state (running-jobs
        # set, etc.), so the "en curso"/"running" flag shown by the API
        # never matched what this component's scheduler was actually
        # doing, and both schedulers could pick the same due job at once.
        self.backup_scheduler = get_share_backup_service()
        self.network_units = NetworkUnitService()
        self.disk_health = share_disk_health_service

    def start(self):
        logger.info("NetworkShareComponent started.")
        try:
            self.service.ensure_boot()
        except Exception as error:
            logger.error("Network share boot error: %s", error)
        try:
            self.integrity_watch.start_scheduler()
        except Exception as error:
            logger.error("Share integrity watch start error: %s", error)
        try:
            self.network_units.mount_all()
        except Exception as error:
            logger.error("Network units mount error: %s", error)
        try:
            self.backup_scheduler.start_scheduler()
        except Exception as error:
            logger.error("Share backup scheduler start error: %s", error)
        try:
            self.disk_health.start_scheduler()
        except Exception as error:
            logger.error("Share disk health watch start error: %s", error)

    def stop(self):
        try:
            self.integrity_watch.stop_scheduler()
        except Exception as error:
            logger.error("Share integrity watch stop error: %s", error)
        try:
            self.backup_scheduler.stop_scheduler()
        except Exception as error:
            logger.error("Share backup scheduler stop error: %s", error)
        try:
            self.disk_health.stop_scheduler()
        except Exception as error:
            logger.error("Share disk health watch stop error: %s", error)
        logger.info("NetworkShareComponent stopped.")
