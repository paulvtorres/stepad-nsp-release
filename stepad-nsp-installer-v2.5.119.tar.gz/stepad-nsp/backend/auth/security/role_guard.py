from fastapi import Depends, HTTPException

from backend.auth.security.jwt_auth import get_current_user
from backend.shared.constants.user_roles import UserRoles


def require_role(minimum_role: str):
    """
    Exige que el usuario tenga al menos `minimum_role` según la jerarquía
    de UserRoles.LEVELS (ADMIN > OPERATOR). Un ADMIN siempre pasa
    cualquier require_role(); un OPERATOR solo pasa require_role(OPERATOR).

    Antes esto comparaba con `!=` (igualdad exacta), así que un rol
    OPERATOR nunca podía pasar NINGUNA ruta, ni siquiera las de solo
    lectura -- toda la superficie de la API exigía ADMIN literal. Con
    niveles, agregar `require_role(UserRoles.OPERATOR)` a una ruta de
    lectura no le quita acceso a los ADMIN existentes (su nivel sigue
    siendo el más alto), y por fin le da a OPERATOR el "acceso de
    lectura/operación" que ya prometía la documentación.
    """

    required_level = UserRoles.LEVELS.get(minimum_role, 0)

    def role_checker(
        current_user: dict = Depends(get_current_user)
    ):

        user_role = current_user.get("role")
        user_level = UserRoles.LEVELS.get(user_role, 0)

        if user_level < required_level:

            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions"
            )

        return current_user

    return role_checker