class UserRoles:

    ADMIN = "ADMIN"

    OPERATOR = "OPERATOR"


# Jerarquía de privilegios: un nivel mayor incluye todo lo que puede hacer
# uno menor. Hoy solo hay dos roles, pero esto deja espacio para agregar
# más sin tener que tocar cada ruta otra vez.
#
# ADMIN    (2): acceso total, incluida cualquier acción que modifique
#                configuración (firewall, red, usuarios, respaldos, etc.).
# OPERATOR (1): acceso de lectura/operación -- puede ver dashboards,
#                monitoreo, alertas, logs y estado, pero no crear, editar
#                ni borrar configuración. Ver docs/Guia-Instalacion-
#                Operacion.md, sección de mínimo privilegio.
ROLE_LEVELS = {
    UserRoles.OPERATOR: 1,
    UserRoles.ADMIN: 2,
}
UserRoles.LEVELS = ROLE_LEVELS