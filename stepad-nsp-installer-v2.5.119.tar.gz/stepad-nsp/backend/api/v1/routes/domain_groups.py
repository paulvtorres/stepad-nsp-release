from fastapi import APIRouter, Depends
from pydantic import BaseModel

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.content.services.domain_group_service import (
    DomainGroupService,
)


router = APIRouter(
    prefix="/domain-groups",
    tags=["Domain Groups"],
)

service = DomainGroupService()


class CreateGroupRequest(BaseModel):

    name: str

    description: str | None = None


class AddDomainRequest(BaseModel):

    domain: str


@router.get("/")
def list_groups(
    db: Session = Depends(get_db),
    _: dict = Depends(require_role(UserRoles.OPERATOR)),
):

    return service.list_groups(db)


@router.post("/")
def create_group(
    request: CreateGroupRequest,
    db: Session = Depends(get_db),
    _: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.create_group(db, request.name, request.description)


@router.delete("/{group_id}")
def delete_group(
    group_id: int,
    db: Session = Depends(get_db),
    _: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.delete_group(db, group_id)


@router.post("/{group_id}/domains")
def add_domain(
    group_id: int,
    request: AddDomainRequest,
    db: Session = Depends(get_db),
    _: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.add_domain(db, group_id, request.domain)


@router.delete("/{group_id}/domains/{domain}")
def remove_domain(
    group_id: int,
    domain: str,
    db: Session = Depends(get_db),
    _: dict = Depends(require_role(UserRoles.ADMIN)),
):

    return service.remove_domain(db, group_id, domain)
