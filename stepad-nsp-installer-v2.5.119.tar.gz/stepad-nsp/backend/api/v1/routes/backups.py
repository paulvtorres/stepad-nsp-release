from fastapi import APIRouter, Depends, UploadFile, File
from fastapi.responses import FileResponse

from pathlib import Path

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.backups.services.backup_service import BackupService
from backend.backups.schemas.backup_settings import BackupSettingsRequest


router = APIRouter(
    prefix="/backups",
    tags=["Backups"]
)

service = BackupService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.get_settings(db)


@router.put("/settings")
def save_settings(
    request: BackupSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.save_settings(db, request)


@router.get("/")
def list_backups(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.OPERATOR))
):

    return service.list_backups()


@router.post("/create")
def create_backup(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.create_backup(db)


@router.get("/{filename}/download")
def download_backup(
    filename: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    path = service.backup_path(filename)

    if path is None:

        from fastapi import HTTPException

        raise HTTPException(
            status_code=404,
            detail="Backup not found"
        )

    return FileResponse(
        path=str(path),
        media_type="application/gzip",
        filename=path.name
    )


@router.delete("/{filename}")
def delete_backup(
    filename: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.delete_backup(filename)


@router.post("/upload")
async def upload_backup(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    filename = file.filename or "stepad-backup.enc"

    filename = filename.replace("/", "").replace("..", "")

    target = Path("/etc/stepad/backups") / filename

    target.parent.mkdir(parents=True, exist_ok=True)

    with open(target, "wb") as output:

        while chunk := await file.read(1024 * 1024):

            output.write(chunk)

    return {
        "success": True,
        "filename": filename,
        "message": f"Respaldo {filename} subido."
    }


@router.post("/{filename}/restore")
def restore_backup(
    filename: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):

    return service.restore_backup(filename)
