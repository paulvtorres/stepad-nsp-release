"""
Verifica el segundo paso del fix de roles: un conjunto acotado y
revisado a mano de rutas GET puramente de lectura (dashboards de
respaldo, listado de unidades de red, reporte de cumplimiento, etc.)
ahora acepta OPERATOR además de ADMIN, mientras que toda ruta que crea,
modifica, borra o entrega contenido de archivos sigue exigiendo ADMIN
exacto -- exactamente como antes de este cambio.

No se usa TestClient/httpx (no son dependencias declaradas del
proyecto): se extrae el dependency callable de `Depends(require_role(...))`
directamente de la firma de cada función de ruta y se invoca a mano.
"""

import inspect
import os

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

import pytest
from fastapi import HTTPException

from backend.shared.constants.user_roles import UserRoles


def _role_dependency(func, param_name="current_user"):
    """Extrae el callable interno de Depends(require_role(...)) de una
    ruta, para poder probarlo sin pasar por FastAPI/TestClient."""
    sig = inspect.signature(func)
    default = sig.parameters[param_name].default
    return default.dependency


def _assert_accepts(dependency, role):
    result = dependency(current_user={"role": role, "sub": "1"})
    assert result["role"] == role


def _assert_rejects(dependency, role):
    with pytest.raises(HTTPException) as excinfo:
        dependency(current_user={"role": role, "sub": "1"})
    assert excinfo.value.status_code == 403


# -- Rutas que ahora deben aceptar OPERATOR (y seguir aceptando ADMIN) --

def test_alerts_intrusion_script_accepts_operator():
    from backend.api.v1.routes import alerts
    dep = _role_dependency(alerts.download_intrusion_script)
    _assert_accepts(dep, UserRoles.OPERATOR)
    _assert_accepts(dep, UserRoles.ADMIN)


def test_system_backups_list_accepts_operator():
    from backend.api.v1.routes import backups
    dep = _role_dependency(backups.list_backups)
    _assert_accepts(dep, UserRoles.OPERATOR)
    _assert_accepts(dep, UserRoles.ADMIN)


def test_device_ip_pool_accepts_operator():
    from backend.api.v1.routes import devices
    dep = _role_dependency(devices.get_ip_pool)
    _assert_accepts(dep, UserRoles.OPERATOR)


def test_domain_groups_list_accepts_operator():
    from backend.api.v1.routes import domain_groups
    dep = _role_dependency(domain_groups.list_groups, param_name="_")
    _assert_accepts(dep, UserRoles.OPERATOR)


def test_network_units_list_accepts_operator():
    from backend.api.v1.routes import network_units
    dep = _role_dependency(network_units.list_units)
    _assert_accepts(dep, UserRoles.OPERATOR)


def test_compliance_report_accepts_operator():
    from backend.api.v1.routes import reports
    dep = _role_dependency(reports.compliance_report)
    _assert_accepts(dep, UserRoles.OPERATOR)


def test_share_backups_list_history_snapshots_accept_operator():
    from backend.api.v1.routes import share_backups
    for func in (
        share_backups.list_backups,
        share_backups.get_backup_history,
        share_backups.list_snapshots,
    ):
        dep = _role_dependency(func)
        _assert_accepts(dep, UserRoles.OPERATOR)


# -- Rutas mutantes / de contenido de archivos que deben SEGUIR exigiendo
# ADMIN exacto -- este cambio no debía tocarlas.

def test_system_backup_download_and_create_still_require_admin():
    from backend.api.v1.routes import backups
    for func in (backups.download_backup, backups.create_backup):
        dep = _role_dependency(func)
        _assert_rejects(dep, UserRoles.OPERATOR)
        _assert_accepts(dep, UserRoles.ADMIN)


def test_domain_groups_create_still_requires_admin():
    from backend.api.v1.routes import domain_groups
    dep = _role_dependency(domain_groups.create_group, param_name="_")
    _assert_rejects(dep, UserRoles.OPERATOR)


def test_network_units_write_routes_still_require_admin():
    from backend.api.v1.routes import network_units
    for func in (
        network_units.create_unit,
        network_units.delete_unit,
        network_units.toggle_unit,
    ):
        dep = _role_dependency(func)
        _assert_rejects(dep, UserRoles.OPERATOR)


def test_share_backups_write_and_file_routes_still_require_admin():
    from backend.api.v1.routes import share_backups
    for func in (
        share_backups.create_backup,
        share_backups.update_backup,
        share_backups.delete_backup,
        share_backups.run_backup_job,
        share_backups.list_snapshot_files,
        share_backups.download_snapshot_path,
        share_backups.prune_backups,
    ):
        dep = _role_dependency(func)
        _assert_rejects(dep, UserRoles.OPERATOR)
        _assert_accepts(dep, UserRoles.ADMIN)


def test_network_scan_and_share_web_files_still_require_admin():
    # Estas quedaron deliberadamente fuera de OPERATOR: permiten probar
    # credenciales SMB, listar archivos con credenciales, o navegar/
    # descargar contenido real de archivos.
    from backend.api.v1.routes import network_scan, share_web_files

    for func in (
        network_scan.scan_network,
        network_scan.test_share_connection,
        network_scan.list_shares_with_credentials,
        network_scan.browse_share_content,
    ):
        dep = _role_dependency(func)
        _assert_rejects(dep, UserRoles.OPERATOR)

    for func in (share_web_files.list_dir, share_web_files.download):
        dep = _role_dependency(func)
        _assert_rejects(dep, UserRoles.OPERATOR)


def test_users_list_still_requires_admin():
    # Gestión/identidad de cuentas admin, no "operación" del NSP.
    from backend.api.v1.routes import users
    dep = _role_dependency(users.get_users)
    _assert_rejects(dep, UserRoles.OPERATOR)
