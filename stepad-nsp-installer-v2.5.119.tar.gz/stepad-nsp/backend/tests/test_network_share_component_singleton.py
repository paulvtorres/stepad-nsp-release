"""
Regresión: `NetworkShareComponent` instanciaba su propio `ShareBackupService()`
en vez de usar `get_share_backup_service()`, así que el scheduler que
realmente corre en producción (arrancado por este componente al boot) era
un objeto DISTINTO al que usan las rutas de la API (`share_backups.py`) y
el watchdog de `monitoring_component.py`.

Consecuencias que esto causaba, ambas relevantes para "indicar que un
respaldo se está llevando a cabo":
- El flag `running`/`running_since` que ve la API nunca reflejaba lo que
  el scheduler de verdad estaba haciendo (cada uno tenía su propio
  `_running_jobs` en memoria).
- El watchdog de `monitoring_component.py` podía arrancar un SEGUNDO
  scheduler (creía que el primero -- de otro objeto -- no existía),
  duplicando la ejecución de jobs.

Este test fija que ambos consumidores compartan la misma instancia.
"""

import os

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from backend.shares.components.network_share_component import (
    NetworkShareComponent,
)
from backend.shares.services.share_backup_service import (
    get_share_backup_service,
)


def test_component_backup_scheduler_is_the_shared_singleton():
    component = NetworkShareComponent()

    assert component.backup_scheduler is get_share_backup_service()


def test_singleton_accessor_returns_the_same_object_across_calls():
    assert get_share_backup_service() is get_share_backup_service()
