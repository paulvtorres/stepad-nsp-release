"""
Cubre tres arreglos sobre `NetworkUnitService` ("Unidades de red"):

1. `CONFIG_FILE` ya no apunta a la ruta de desarrollo del autor original
   (/home/paulan/stepad-nsp/...) -- eso rompía la función en cualquier
   instalación real -- y una unidad ya configurada bajo esa ruta vieja
   se migra sola una vez a /etc/stepad/network_units.json.
2. El archivo de config (contiene contraseñas SMB en texto plano) queda
   con permisos 0600, igual que el resto de la config sensible del NSP.
3. El campo "letter" se valida en el servicio (no solo en el frontend):
   sin esto, `MOUNT_BASE / letter` con algo como "../etc" podía escapar
   del directorio de montajes esperado.
"""

import json
import os
import stat

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

import pytest

from backend.shares.services import network_unit_service as module


def _make_service(tmp_path, monkeypatch, *, legacy_data=None):
    config_file = tmp_path / "etc-stepad" / "network_units.json"
    mount_base = tmp_path / "mnt-stepad-network"
    legacy_file = tmp_path / "legacy" / "network_units.json"

    monkeypatch.setattr(module, "CONFIG_FILE", config_file)
    monkeypatch.setattr(module, "MOUNT_BASE", mount_base)
    monkeypatch.setattr(module, "_LEGACY_CONFIG_FILE", legacy_file)

    if legacy_data is not None:
        legacy_file.parent.mkdir(parents=True, exist_ok=True)
        legacy_file.write_text(json.dumps(legacy_data), encoding="utf-8")

    # Evita montar CIFS de verdad al crear/activar unidades.
    monkeypatch.setattr(module.NetworkUnitService, "_mount_unit", lambda self, unit: True)
    monkeypatch.setattr(module.NetworkUnitService, "_unmount_unit", lambda self, unit: None)

    service = module.NetworkUnitService()
    return service, config_file, legacy_file


def test_config_file_is_not_the_developer_hardcoded_path():
    # No debe volver a apuntar a la máquina de un desarrollador específico.
    assert "paulan" not in str(module.CONFIG_FILE)
    assert str(module.CONFIG_FILE).startswith("/etc/stepad/")


def test_new_install_creates_config_under_configured_path(tmp_path, monkeypatch):
    service, config_file, _legacy = _make_service(tmp_path, monkeypatch)

    service.create_unit(name="Disco", host="192.168.1.50", share="datos", letter="Z")

    assert config_file.exists()
    data = json.loads(config_file.read_text("utf-8"))
    assert data["units"][0]["letter"] == "Z"


def test_legacy_config_is_migrated_once(tmp_path, monkeypatch):
    legacy_payload = {"units": [{"id": 1, "letter": "Y", "name": "Vieja",
                                  "host": "h", "share": "s", "user": "", "password": "", "enabled": True}]}
    service, config_file, legacy_file = _make_service(
        tmp_path, monkeypatch, legacy_data=legacy_payload
    )

    # La migración corrió en el constructor: la unidad vieja ya está
    # disponible en la ruta nueva, sin que el usuario tenga que rehacerla.
    assert config_file.exists()
    units = service.list_units()
    assert any(u["letter"] == "Y" for u in units)


def test_legacy_config_is_not_migrated_if_new_config_already_exists(
    tmp_path, monkeypatch
):
    legacy_payload = {"units": [{"id": 1, "letter": "Y", "name": "Vieja",
                                  "host": "h", "share": "s", "user": "", "password": "", "enabled": True}]}
    service, config_file, legacy_file = _make_service(
        tmp_path, monkeypatch, legacy_data=legacy_payload
    )
    # Ya migró una vez arriba; ahora agregamos otra unidad por la vía normal.
    service.create_unit(name="Nueva", host="h2", share="s2", letter="X")

    # Una segunda instancia (ej. tras un restart) no debe pisar lo que ya
    # hay en la ruta nueva con el contenido viejo de nuevo.
    service2 = module.NetworkUnitService()
    letters = {u["letter"] for u in service2.list_units()}
    assert letters == {"Y", "X"}


def test_config_file_permissions_are_owner_only(tmp_path, monkeypatch):
    service, config_file, _legacy = _make_service(tmp_path, monkeypatch)

    service.create_unit(name="Disco", host="h", share="s", letter="Z")

    mode = stat.S_IMODE(os.stat(config_file).st_mode)
    assert mode == 0o600


@pytest.mark.parametrize("letter", ["../etc", "A/B", "..", "", "A" * 9, "a b"])
def test_create_unit_rejects_unsafe_letters(tmp_path, monkeypatch, letter):
    service, _config_file, _legacy = _make_service(tmp_path, monkeypatch)

    with pytest.raises(ValueError):
        service.create_unit(name="Disco", host="h", share="s", letter=letter)


@pytest.mark.parametrize("letter", ["Z", "z", "DATA", "disk-1", "disk_1"])
def test_create_unit_accepts_safe_letters(tmp_path, monkeypatch, letter):
    service, _config_file, _legacy = _make_service(tmp_path, monkeypatch)

    unit = service.create_unit(name="Disco", host="h", share="s", letter=letter)

    assert unit["letter"] == letter.upper()


def test_create_unit_rejects_path_traversal_via_letter_before_mount(
    tmp_path, monkeypatch
):
    # Verificación end-to-end: con la letra maliciosa, jamás se llega a
    # construir un mount_point fuera de MOUNT_BASE.
    service, _config_file, _legacy = _make_service(tmp_path, monkeypatch)

    mount_calls = []
    monkeypatch.setattr(
        module.NetworkUnitService,
        "_mount_unit",
        lambda self, unit: mount_calls.append(unit) or True,
    )

    with pytest.raises(ValueError):
        service.create_unit(name="Disco", host="h", share="s", letter="../../etc")

    assert mount_calls == []


def test_list_units_never_exposes_plaintext_password(tmp_path, monkeypatch):
    """
    list_units() se expone ahora también a OPERATOR (ver
    test_operator_role_route_access.py), así que no puede seguir
    devolviendo la contraseña SMB en texto plano como antes
    (`**unit` incluía "password" tal cual se guardó en disco).
    """
    service, _config_file, _legacy = _make_service(tmp_path, monkeypatch)

    service.create_unit(
        name="Disco", host="192.168.1.50", share="datos",
        letter="Z", user="admin", password="super-secreta-123",
    )

    units = service.list_units()

    assert len(units) == 1
    assert "password" not in units[0]
    assert units[0]["has_password"] is True
    # El usuario (no secreto) sí puede seguir mostrándose.
    assert units[0]["user"] == "admin"


def test_list_units_has_password_false_when_no_password_set(tmp_path, monkeypatch):
    service, _config_file, _legacy = _make_service(tmp_path, monkeypatch)

    service.create_unit(name="Disco", host="h", share="s", letter="Z")

    units = service.list_units()

    assert units[0]["has_password"] is False
    assert "password" not in units[0]
