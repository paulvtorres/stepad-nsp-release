"""
Verifica que `ShareIntegrityWatchService._tick()` se salte por completo su
escaneo (y por lo tanto no pueda disparar el bloqueo antiransomware)
mientras `ShareBackupService.has_active_protected_backup()` sea True --
que es exactamente la ventana de un respaldo "por horario" en ejecución.
"""

import os
from types import SimpleNamespace

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

from backend.shares.services import share_integrity_watch_service as module


class FakeRow:
    integrity_watch_enabled = True
    integrity_locked = False


class FakeNetworkShareService:
    def __init__(self, paused, roots_probe):
        self._paused = paused
        self._roots_probe = roots_probe

    def _settings(self, db):
        return FakeRow()

    def is_integrity_paused(self, db, row=None):
        return self._paused

    def list_integrity_roots(self, db):
        self._roots_probe["called"] = True
        return []


def _make_watch(monkeypatch, *, backup_active, paused=False):
    roots_probe = {"called": False}

    watch = module.ShareIntegrityWatchService.__new__(
        module.ShareIntegrityWatchService
    )
    watch._stop = False
    watch._thread = None
    watch._lock = __import__("threading").Lock()
    watch._last_trip_monotonic = 0.0

    monkeypatch.setattr(module, "SessionLocal", lambda: SimpleNamespace(close=lambda: None))
    monkeypatch.setattr(
        "backend.shares.services.network_share_service.NetworkShareService",
        lambda: FakeNetworkShareService(paused, roots_probe),
    )
    monkeypatch.setattr(
        "backend.shares.services.share_backup_service.get_share_backup_service",
        lambda: SimpleNamespace(
            has_active_protected_backup=lambda: backup_active
        ),
    )

    return watch, roots_probe


def test_tick_skips_scan_while_scheduled_backup_is_running(monkeypatch):
    watch, roots_probe = _make_watch(monkeypatch, backup_active=True)

    watch._tick()

    assert roots_probe["called"] is False


def test_tick_scans_normally_when_no_backup_is_running(monkeypatch):
    watch, roots_probe = _make_watch(monkeypatch, backup_active=False)

    watch._tick()

    assert roots_probe["called"] is True


def test_tick_still_respects_manual_pause_regardless_of_backup_state(
    monkeypatch,
):
    # Una pausa manual (antiransomware desactivado a mano) sigue
    # respetándose primero, sin depender de si hay un respaldo corriendo.
    watch, roots_probe = _make_watch(
        monkeypatch, backup_active=False, paused=True
    )

    watch._tick()

    assert roots_probe["called"] is False
