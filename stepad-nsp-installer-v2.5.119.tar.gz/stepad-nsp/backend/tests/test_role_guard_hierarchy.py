"""
Regresión para el mecanismo de roles: antes `require_role` comparaba con
`!=` (igualdad exacta), así que un usuario OPERATOR nunca podía pasar
NINGUNA ruta protegida -- ni siquiera las de solo lectura, porque el 100%
de las 161 rutas protegidas del backend exigían literalmente "ADMIN".
El rol OPERATOR, documentado como "acceso de lectura/operación" y
disponible en el formulario de creación de usuarios del frontend, era
inalcanzable en la práctica.

Este test fija el nuevo contrato basado en niveles (UserRoles.LEVELS):
ADMIN sigue pasando cualquier require_role(); OPERATOR ahora sí puede
pasar require_role(OPERATOR); ninguno de los dos gana privilegios que no
tenía antes en las rutas que ya exigían ADMIN.
"""

import os

os.environ.setdefault("STEPAD_ENV", "development")
os.environ.setdefault("DB_PASSWORD", "test")
os.environ.setdefault("STEPAD_JWT_SECRET", "test-jwt-secret")

import pytest
from fastapi import HTTPException

from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles


def _call(minimum_role, user_role):
    checker = require_role(minimum_role)
    return checker(current_user={"role": user_role, "sub": "1"})


def test_admin_passes_admin_requirement():
    result = _call(UserRoles.ADMIN, UserRoles.ADMIN)
    assert result["role"] == UserRoles.ADMIN


def test_operator_is_rejected_by_admin_requirement():
    # Comportamiento preexistente que NO debe cambiar: las rutas que ya
    # exigían ADMIN (creación de usuarios, reglas de firewall, etc.)
    # siguen sin dejar pasar a un OPERATOR.
    with pytest.raises(HTTPException) as excinfo:
        _call(UserRoles.ADMIN, UserRoles.OPERATOR)
    assert excinfo.value.status_code == 403


def test_operator_passes_operator_requirement():
    # Este es el fix: antes esto también fallaba porque comparaba con
    # igualdad exacta contra "ADMIN" en cada ruta.
    result = _call(UserRoles.OPERATOR, UserRoles.OPERATOR)
    assert result["role"] == UserRoles.OPERATOR


def test_admin_also_passes_operator_requirement():
    # Jerarquía: un ADMIN puede hacer todo lo que puede un OPERATOR.
    result = _call(UserRoles.OPERATOR, UserRoles.ADMIN)
    assert result["role"] == UserRoles.ADMIN


def test_unknown_role_is_rejected_by_any_requirement():
    # Nivel desconocido = 0, por debajo de cualquier rol real -- deny by
    # default en vez de fallar abierto ante un rol mal escrito/corrupto.
    with pytest.raises(HTTPException):
        _call(UserRoles.OPERATOR, "GUEST")
    with pytest.raises(HTTPException):
        _call(UserRoles.ADMIN, "GUEST")


def test_missing_role_in_token_is_rejected():
    checker = require_role(UserRoles.OPERATOR)
    with pytest.raises(HTTPException) as excinfo:
        checker(current_user={"sub": "1"})
    assert excinfo.value.status_code == 403
