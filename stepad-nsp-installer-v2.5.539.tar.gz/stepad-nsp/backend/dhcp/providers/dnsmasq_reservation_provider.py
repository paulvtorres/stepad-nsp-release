import os


from backend.core.config.paths import (
    DOMAINS_CONFIG,
    RESERVATIONS_CONFIG 
)


class DnsmasqReservationProvider:


    def write_reservations(
        self,
        reservations: list[dict]
    ):

        DOMAINS_CONFIG.parent.mkdir(

            parents=True,

            exist_ok=True

        )


        tmp = RESERVATIONS_CONFIG.with_suffix(RESERVATIONS_CONFIG.suffix + ".tmp")

        with open(
            tmp,
            "w"
        ) as file:


            for reservation in reservations:

                # set:zoneN lets dnsmasq route this device into its
                # zone's dhcp-range (see
                # NetworkZoneService._regenerate_zone_dhcp) even when
                # several zones share one physical wire via IP
                # aliasing -- with a real VLAN sub-interface the tag
                # is redundant with dnsmasq's own per-interface
                # matching, but harmless either way.
                tags = []

                zone_tag = reservation.get("zone_tag")

                if zone_tag:

                    tags.append(f"set:{zone_tag}")

                # set:grpN associa el equipo a su grupo DNS. Se escribe
                # AQUI (dentro de la reserva) y NO como dhcp-host aparte
                # en groups_dns.conf: un dhcp-host duplicado sin IP le
                # dice a dnsmasq "no asignes IP a esta MAC" y rompe las
                # reservas (ninguna dirección disponible).
                group_tag = reservation.get("group_tag")

                if group_tag:

                    tags.append(f"set:{group_tag}")

                tag_part = ",".join(tags)

                if tag_part:

                    tag_part += ","

                # Formato de dhcp-hostsfile: MAC,IP,... (sin "dhcp-host=").
                file.write(

                    f"{reservation['mac']},"
                    f"{tag_part}"
                    f"{reservation['ip']},"
                    f"{reservation.get('hostname','')}\n"

                )

        os.replace(tmp, RESERVATIONS_CONFIG)


        return {

            "success": True,

            "file": str(
                RESERVATIONS_CONFIG
            ),

            "total": len(reservations)

        }