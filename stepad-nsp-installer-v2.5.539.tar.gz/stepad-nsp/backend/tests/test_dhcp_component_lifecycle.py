from backend.dhcp.components.dhcp_component import DhcpComponent


class FakeScheduler:

    def __init__(self):
        self.stopped = False

    def start_scheduler(self):
        pass

    def stop_scheduler(self):
        self.stopped = True


class FakeProvider:

    def __init__(self, running):
        self.running = running
        self.stopped = False

    def status(self):
        return {"running": self.running, "pid": 123}

    def stop(self):
        self.stopped = True
        raise AssertionError("no debe detener dnsmasq")


class FakeService:

    def __init__(self):
        self.called = False

    def apply_config(self):
        self.called = True
        return {"success": True, "service": {"pid": 123}}


def test_stop_no_detiene_dnsmasq():
    component = DhcpComponent.__new__(DhcpComponent)
    component._sync_stop = False
    component._sync_thread = None
    component._lease_monitor_stop = False
    component._lease_monitor_thread = None
    component.cleanup_service = FakeScheduler()
    component.alert_service = FakeScheduler()
    component.provider = FakeProvider(running=True)

    component.stop()

    assert component.provider.stopped is False


def test_start_reutiliza_dnsmasq_activo():
    component = DhcpComponent.__new__(DhcpComponent)
    component.provider = FakeProvider(running=True)
    component.service = FakeService()
    component.cleanup_service = FakeScheduler()
    component.alert_service = FakeScheduler()
    component._sync_thread = object()
    component._lease_monitor_thread = object()
    component.process = None

    component.start()

    assert component.service.called is False
    assert component.process == 123
