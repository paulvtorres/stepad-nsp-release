"""restic runner: command, environment and progress.

Extracted from `share_backup_service` (monolith) without behavior changes.
The process (Popen with stall detection) stays in the service; the pure,
testable pieces live here.
"""

import json
import os


MIN_ETA_PERCENT = 5.0
MIN_ETA_SECONDS = 20
MAX_ETA_SECONDS = 7 * 86400

# Lowest priority: backups must not compete with normal operation.
_PRIORITY_PREFIX = ["nice", "-n", "19", "ionice", "-c", "3"]


def command(repo: str, args: list[str]) -> list[str]:

    """restic command with idle CPU and IO priority."""

    return [*_PRIORITY_PREFIX, "restic", "-r", repo, *args]


def env(password: str) -> dict:

    return {
        **os.environ,
        "RESTIC_PASSWORD": password,
        "LC_ALL": "C",
        "LANG": "C",
    }


def rich_progress(data: dict) -> dict:

    """Normalized progress (0-100 percent and reliable ETA)."""

    base = {
        "files_done": data.get("files_done", 0),
        "files_total": data.get("files_total", 0),
        "bytes_done": data.get("bytes_done", 0),
        "bytes_total": data.get("bytes_total", 0),
        "current_file": (
            data.get("current_files", [""])[0]
            if data.get("current_files")
            else ""
        ),
    }

    percent = data.get("percent_done")

    if percent is not None:

        try:

            percent = float(percent)

        except (TypeError, ValueError):

            percent = None

        else:

            if percent <= 1.0:

                percent = percent * 100.0

            percent = round(min(100.0, max(0.0, percent)), 1)

    if percent is None and data.get("total_files_processed"):

        done = int(data.get("files_done") or 0)
        total = int(data.get("total_files_processed") or 0)
        percent = round(100.0 * done / total, 1) if total else None

    base["percent"] = percent

    elapsed = data.get("seconds_elapsed")

    if elapsed is not None:

        base["elapsed_seconds"] = int(elapsed)

    eta = data.get("seconds_remaining")

    if eta is None and percent is not None:

        if percent > 0 and elapsed is not None:

            eta = int(round((elapsed / (percent / 100.0)) * (1 - percent / 100.0)))

        else:

            total_b = data.get("total_bytes_processed")

            if total_b and percent:

                bytes_done = float(data.get("bytes_done") or 0)
                elapsed_f = float(elapsed or 0)

                if bytes_done > 0 and elapsed_f > 0 and percent < 100:

                    eta = int(round((total_b - bytes_done) * elapsed_f / bytes_done))

    if (
        eta is not None
        and percent is not None
        and percent >= MIN_ETA_PERCENT
        and (elapsed or 0) >= MIN_ETA_SECONDS
    ):

        base["eta_seconds"] = max(0, min(int(eta), MAX_ETA_SECONDS))

    return base


def parse_unreadable(stderr: str, limit: int = 20) -> tuple[int, list[str]]:
    """Count files restic could not read (exit code 3 keeps the snapshot).

    Returns (count, first `limit` distinct messages/paths).
    """
    seen = set()
    items: list[str] = []
    for raw in (stderr or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        payload = None
        if line.startswith("{"):
            try:
                payload = json.loads(line)
            except ValueError:
                payload = None
        if isinstance(payload, dict) and payload.get("message_type") == "error":
            error = payload.get("error") or {}
            item = str(payload.get("item") or "").strip()
            reason = str(error.get("message") or "").strip()
            detail = f"{item} — {reason}" if item and reason else (item or reason)
            if detail and detail not in seen:
                seen.add(detail)
                items.append(detail)
            continue
        low = line.lower()
        if (
            "failed to save" in low
            or "error:" in low
            or "cannot open" in low
            or "permission denied" in low
        ):
            if line not in seen:
                seen.add(line)
                items.append(line)
    return len(items), items[:limit]


def unreadable_detail(count: int, samples: list[str]) -> str:
    if count <= 0:
        return ""
    shown = "; ".join(str(item) for item in samples[:3])
    suffix = f": {shown}" if shown else ""
    return f"{count} archivo(s) ilegible(s) (se omitieron){suffix}"
