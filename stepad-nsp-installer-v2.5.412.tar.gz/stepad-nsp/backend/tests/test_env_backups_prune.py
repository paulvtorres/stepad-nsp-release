from pathlib import Path

from backend.core.config.secret_manager import prune_env_backups


def _make(folder: Path, count: int) -> None:

    for index in range(count):

        (folder / f"stepad.env.202610{(index % 9) + 1:02d}-0000{index:02d}.manual").write_text(
            "X=1", encoding="utf-8"
        )


def test_keeps_only_newest(tmp_path):

    _make(tmp_path, 25)

    deleted = prune_env_backups(tmp_path, keep=10, max_age_days=3650)

    assert deleted == 15

    assert len(list(tmp_path.glob("stepad.env.*"))) == 10


def test_ignores_unrelated_files(tmp_path):

    _make(tmp_path, 5)

    (tmp_path / "otro.txt").write_text("x")

    prune_env_backups(tmp_path, keep=2, max_age_days=3650)

    assert (tmp_path / "otro.txt").exists()

    assert len(list(tmp_path.glob("stepad.env.*"))) == 2


def test_missing_directory_is_safe(tmp_path):

    assert prune_env_backups(tmp_path / "nope", keep=5) == 0
