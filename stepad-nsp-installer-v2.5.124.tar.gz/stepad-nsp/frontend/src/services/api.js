import { apiClient } from "./apiClient";
import {
    RuleAction,
    RuleType,
} from "../constants";
 

export async function getInterfaces() {


    return apiClient.get(
        "/interfaces/"
    );


}



//
// Interface registry -- persistent, MAC-based WAN/LAN identity
//

export async function getRegisteredInterfaces() {

    return apiClient.get(
        "/interfaces/registry/"
    );

}


export async function rescanInterfaces() {

    return apiClient.post(
        "/interfaces/registry/rescan"
    );

}


export async function getPendingInterfaceActions() {

    return apiClient.get(
        "/interfaces/registry/pending"
    );

}


export async function assignInterfaceRole(interfaceId, payload) {

    return apiClient.post(
        `/interfaces/registry/${interfaceId}/assign`,
        payload
    );

}


export async function unassignInterfaceRole(interfaceId) {

    return apiClient.post(
        `/interfaces/registry/${interfaceId}/unassign`,
        {}
    );

}


export async function deleteRegisteredInterface(interfaceId) {

    return apiClient.delete(
        `/interfaces/registry/${interfaceId}`
    );

}


export async function testInterfaceConnectivity(interfaceId) {

    return apiClient.post(
        `/interfaces/registry/${interfaceId}/test-connectivity`,
        {}
    );

}


export async function compareWan() {

    return apiClient.post(
        "/interfaces/registry/compare-wan",
        {}
    );

}



export async function getInterfaceDiagnosis() {


    return apiClient.get(
        "/interfaces/diagnosis"
    );


}



export async function getDevices() {


    return apiClient.get(
        "/devices/"
    );

}


export async function getDevicesLiveStatus() {


    return apiClient.get(
        "/devices/live-status"
    );

}


export async function scanDevices() {


    return apiClient.post(
        "/devices/scan"
    );


}



export async function getDevice(id) {


    return apiClient.get(
        `/devices/${id}`
    );


}



export async function getDeviceRules(deviceId) {


    return apiClient.get(
        `/devices/${deviceId}/rules`
    );


}



export async function deleteDeviceRule(ruleId) {


    return apiClient.delete(
        `/devices/rules/${ruleId}`
    );


}

export async function getSecurityRules() {


    return apiClient.get(
        "/security/rules/"
    );


}



export async function createSecurityRule(domain, options = {}) {

    return apiClient.post(
        "/security/rules/",
        {
            action: RuleAction.BLOCK,
            rule_type: RuleType.DOMAIN,
            value: domain,
            enabled: true,
            is_permanent: options.isPermanent || false,
            schedule_id: options.scheduleId || null
        }
    );

}



export async function deleteSecurityRule(id) {


    return apiClient.delete(
        `/security/rules/${id}`
    );


}



//
// Zones
//

export async function getZones() {

    return apiClient.get(
        "/zones/"
    );

}


export async function createZone(zone) {

    return apiClient.post(
        "/zones/",
        zone
    );

}


export async function updateZone(zoneId, updates) {

    return apiClient.patch(
        `/zones/${zoneId}`,
        updates
    );

}


export async function deleteZone(zoneId) {

    return apiClient.delete(
        `/zones/${zoneId}`
    );

}


export async function getZoneRules(zoneId) {

    return apiClient.get(
        `/zones/${zoneId}/rules`
    );

}


export async function createZoneRule(zoneId, rule) {

    return apiClient.post(
        `/zones/${zoneId}/rules`,
        rule
    );

}


export async function deleteZoneRule(ruleId) {

    return apiClient.delete(
        `/zones/rules/${ruleId}`
    );

}



//
// Schedules
//

export async function getSchedules() {

    return apiClient.get(
        "/schedules/"
    );

}


export async function createSchedule(schedule) {

    return apiClient.post(
        "/schedules/",
        schedule
    );

}


export async function deleteSchedule(scheduleId) {

    return apiClient.delete(
        `/schedules/${scheduleId}`
    );

}



//
// Devices -- zone assignment
//

export async function updateDevice(deviceId, updates) {

    return apiClient.patch(
        `/devices/${deviceId}`,
        updates
    );

}


export async function refreshDevice(deviceId) {

    return apiClient.post(
        `/devices/${deviceId}/refresh`
    );

}


export async function linkDevice(deviceId, primaryDeviceId) {

    return apiClient.post(
        `/devices/${deviceId}/link/${primaryDeviceId}`,
        {}
    );

}


export async function unlinkDevice(deviceId) {

    return apiClient.delete(
        `/devices/${deviceId}/link`
    );

}

export async function deleteDevice(deviceId) {

    return apiClient.delete(
        `/devices/${deviceId}`
    );

}



//
// Network maintenance -- temporary LAN IP
//

export async function getTemporaryLanIpStatus() {

    return apiClient.get(
        "/network/maintenance/temporary-lan-ip"
    );

}


export async function startTemporaryLanIp(payload) {

    return apiClient.post(
        "/network/maintenance/temporary-lan-ip",
        payload
    );

}


export async function revertTemporaryLanIp() {

    return apiClient.post(
        "/network/maintenance/temporary-lan-ip/revert",
        {}
    );

}



//
// Navigation logs
//

export async function getNavigationSummary(filters = {}) {

    const params = new URLSearchParams();

    if (filters.start) params.append("start", filters.start);
    if (filters.end) params.append("end", filters.end);
    if (filters.deviceId) params.append("device_id", filters.deviceId);
    if (filters.domain) params.append("domain", filters.domain);

    const query = params.toString();

    return apiClient.get(
        `/logs/navigation/summary${query ? `?${query}` : ""}`
    );

}


export async function getSniConnections(minutes = 10) {

    return apiClient.get(
        `/logs/navigation/sni?minutes=${minutes}`
    );

}


export async function exportNavigationSummary(filters = {}) {

    const params = new URLSearchParams();

    if (filters.start) params.append("start", filters.start);
    if (filters.end) params.append("end", filters.end);
    if (filters.deviceId) params.append("device_id", filters.deviceId);
    if (filters.domain) params.append("domain", filters.domain);

    const query = params.toString();

    return apiClient.download(
        `/logs/navigation/export${query ? `?${query}` : ""}`
    );

}


//
// Email account (global SMTP)
//

export async function getEmailSettings() {

    return apiClient.get(
        "/email/settings"
    );

}


export async function saveEmailSettings(payload) {

    return apiClient.put(
        "/email/settings",
        payload,
        { timeoutMs: 15000 }
    );

}


export async function testEmailSettings(toEmail = null) {

    return apiClient.post(
        "/email/test",
        { to_email: toEmail || null },
        { timeoutMs: 45000 }
    );

}


//
// Email notifications — navegación (programado) y alertas (inmediatas)
//

export async function getNavigationReportSettings() {

    return apiClient.get(
        "/notifications/reports/settings"
    );

}


export async function saveNavigationReportSettings(payload) {

    return apiClient.put(
        "/notifications/reports/settings",
        payload
    );

}


export async function getAlertNotificationSettings() {

    return apiClient.get(
        "/notifications/alerts/settings"
    );

}


export async function saveAlertNotificationSettings(payload) {

    return apiClient.put(
        "/notifications/alerts/settings",
        payload
    );

}


/** @deprecated Use getNavigationReportSettings / getAlertNotificationSettings */
export async function getNotificationSettings() {

    return apiClient.get(
        "/notifications/settings"
    );

}


/** @deprecated Use saveNavigationReportSettings / saveAlertNotificationSettings */
export async function saveNotificationSettings(payload) {

    return apiClient.put(
        "/notifications/settings",
        payload
    );

}


export async function testNotification() {

    return apiClient.post(
        "/notifications/test",
        {}
    );

}


export async function sendNotificationNow() {

    return apiClient.post(
        "/notifications/send-now",
        {}
    );

}


//
// Backups
//

export async function getBackupSettings() {

    return apiClient.get(
        "/backups/settings"
    );

}


export async function saveBackupSettings(payload) {

    return apiClient.put(
        "/backups/settings",
        payload
    );

}


export async function getBackups() {

    return apiClient.get(
        "/backups/"
    );

}


export async function createBackup() {

    return apiClient.post(
        "/backups/create",
        {}
    );

}


export async function downloadBackup(filename) {

    return apiClient.download(
        `/backups/${encodeURIComponent(filename)}/download`
    );

}


export async function deleteBackup(filename) {

    return apiClient.delete(
        `/backups/${encodeURIComponent(filename)}`
    );

}


export async function uploadBackup(file) {

    const form = new FormData();

    form.append("file", file);

    return apiClient.upload(`/backups/upload`, form);

}


export async function restoreBackup(filename) {

    return apiClient.post(
        `/backups/${encodeURIComponent(filename)}/restore`
    );

}

// Cloud log backup (rclone)

export async function getCloudSettings() {

    return apiClient.get(
        "/cloud-storage/settings"
    );

}

export async function saveCloudSettings(payload) {

    return apiClient.put(
        "/cloud-storage/settings",
        payload
    );

}

export async function testCloudConnection() {

    return apiClient.post(
        "/cloud-storage/test"
    );

}

export async function uploadCloudLogs() {

    return apiClient.post(
        "/cloud-storage/upload"
    );

}

// WAN monitor

export async function getDomainGroups() {

    return apiClient.get(
        "/domain-groups/"
    );

}

export async function createDomainGroup(name, description) {

    return apiClient.post(
        "/domain-groups/",
        { name, description }
    );

}

export async function deleteDomainGroup(id) {

    return apiClient.delete(
        `/domain-groups/${id}`
    );

}

export async function addDomainGroupDomain(id, domain) {

    return apiClient.post(
        `/domain-groups/${id}/domains`,
        { domain }
    );

}

export async function removeDomainGroupDomain(id, domain) {

    return apiClient.delete(
        `/domain-groups/${id}/domains/${encodeURIComponent(domain)}`
    );

}


export async function getWanMonitorStatus() {

    return apiClient.get(
        "/wan-monitor/status"
    );

}

export async function getWanMonitorHistory(hours) {

    return apiClient.get(
        `/wan-monitor/history?hours=${hours}`
    );

}

export async function saveWanMonitorSettings(payload) {

    return apiClient.put(
        "/wan-monitor/settings",
        payload
    );

}

export async function snapshotWanMonitor() {

    return apiClient.post(
        "/wan-monitor/snapshot"
    );

}


//
// Organization (company data)
//

export async function getOrganizationSettings() {

    return apiClient.get(
        "/organization/settings"
    );

}


export async function saveOrganizationSettings(payload) {

    return apiClient.put(
        "/organization/settings",
        payload
    );

}


export async function getSystemVersion() {

    return apiClient.get(
        "/system/version"
    );

}


//
// Alerts, audit and monitoring
//

export async function getAlerts(limit = 50, unreadOnly = false) {

    return apiClient.get(
        `/alerts/?limit=${limit}&unread_only=${unreadOnly}`
    );

}


export async function getAlertsUnreadCount() {

    return apiClient.get(
        "/alerts/unread-count"
    );

}


export async function markAlertRead(id) {

    return apiClient.post(
        `/alerts/${id}/read`,
        {}
    );

}


export async function quarantineAlert(id) {

    return apiClient.post(
        `/alerts/${id}/quarantine`,
        {}
    );

}


export async function markAllAlertsRead() {
    return apiClient.post(
        "/alerts/read-all",
        {}
    );

}


export async function downloadIntrusionDiagnosticScript() {

    return apiClient.download(
        "/alerts/intrusion-diagnostic-script"
    );

}


export async function getAuditLogs(filters = {}) {

    const params = new URLSearchParams();

    if (filters.action) params.append("action", filters.action);
    if (filters.resource) params.append("resource", filters.resource);
    if (filters.start) params.append("start", filters.start);
    if (filters.end) params.append("end", filters.end);
    if (filters.limit) params.append("limit", filters.limit);

    const query = params.toString();

    return apiClient.get(
        `/audit/${query ? `?${query}` : ""}`
    );

}


export async function getSystemMonitoring() {

    return apiClient.get(
        "/system/monitoring"
    );

}


export async function getHardware() {

    return apiClient.get(
        "/system/hardware"
    );

}


export async function getModules() {

    return apiClient.get(
        "/system/modules"
    );

}


export async function setModules(enabledKeys) {

    return apiClient.put(
        "/system/modules",
        { enabled_keys: enabledKeys }
    );

}


//
// SIEM / compliance
//

export async function getSyslogSettings() {

    return apiClient.get(
        "/integration/syslog"
    );

}


export async function saveSyslogSettings(payload) {

    return apiClient.put(
        "/integration/syslog",
        payload
    );

}


export async function testSyslog() {

    return apiClient.post(
        "/integration/syslog/test",
        {}
    );

}


export async function getComplianceRetention() {

    return apiClient.get(
        "/reports/compliance/retention"
    );

}


export async function saveComplianceRetention(payload) {

    return apiClient.put(
        "/reports/compliance/retention",
        payload
    );

}


export async function getLogsReview() {

    return apiClient.get(
        "/reports/compliance/logs-review"
    );

}


export async function saveLogsReview(payload) {

    return apiClient.put(
        "/reports/compliance/logs-review",
        payload
    );

}


export async function markLogsReview() {

    return apiClient.post(
        "/reports/compliance/logs-review/mark"
    );

}


export async function exportComplianceReport(start, end) {

    const params = new URLSearchParams();

    if (start) params.append("start", start);
    if (end) params.append("end", end);

    const query = params.toString();

    return apiClient.download(
        `/reports/compliance${query ? `?${query}` : ""}`
    );

}


//
// Content categories (web filtering)
//

export async function getContentCategories() {

    return apiClient.get(
        "/content-categories/"
    );

}


export async function getContentCategory(key) {

    return apiClient.get(
        `/content-categories/${key}`
    );

}


export async function setCategoryEnabled(key, enabled) {

    return apiClient.put(
        `/content-categories/${key}/enabled`,
        { enabled }
    );

}


export async function addCategoryDomain(key, domain) {

    return apiClient.post(
        `/content-categories/${key}/domains`,
        { domain }
    );

}


export async function removeCategoryDomain(key, domain) {

    return apiClient.delete(
        `/content-categories/${key}/domains/${encodeURIComponent(domain)}`
    );

}


export async function refreshContentFeed(key) {

    return apiClient.post(
        `/content-categories/${key}/refresh`
    );

}


//
// Config revisions (snapshot + rollback)
//

export async function getConfigRevisions() {

    return apiClient.get(
        "/config-revisions/"
    );

}


export async function captureConfigRevision(label) {

    return apiClient.post(
        "/config-revisions/capture",
        { label }
    );

}


export async function getConfigRevision(id) {

    return apiClient.get(
        `/config-revisions/${id}`
    );

}


export async function restoreConfigRevision(id) {

    return apiClient.post(
        `/config-revisions/${id}/restore`,
        {}
    );

}


//
// Updates
//

export async function getUpdateStatus() {

    return apiClient.get(
        "/system/update-status"
    );

}


export async function runUpdate() {

    return apiClient.post(
        "/system/update",
        {}
    );

}



//
// Firewall -- encrypted DNS (DoT/DoH) blocking
//

export async function getEncryptedDnsStatus() {

    return apiClient.get(
        "/firewall/encrypted-dns/status"
    );

}


export async function enableEncryptedDnsBlocking(persist = false) {

    return apiClient.post(
        "/firewall/encrypted-dns/enable",
        { persist }
    );

}


export async function disableEncryptedDnsBlocking() {

    return apiClient.post(
        "/firewall/encrypted-dns/disable",
        {}
    );

}


export async function refreshEncryptedDnsBlocklist() {

    return apiClient.post(
        "/firewall/encrypted-dns/refresh-blocklist",
        {}
    );

}


export async function enableServiceBlockBlocking(persist = false) {

    return apiClient.post(
        "/firewall/encrypted-dns/service-block/enable",
        { persist }
    );

}


export async function disableServiceBlockBlocking() {

    return apiClient.post(
        "/firewall/encrypted-dns/service-block/disable",
        {}
    );

}


export async function getFirewallHardening() {

    return apiClient.get(
        "/firewall/hardening"
    );

}


export async function getWanProbes(hours = 24, limit = 100) {

    const params = new URLSearchParams({
        hours: String(hours),
        limit: String(limit),
    });

    return apiClient.get(
        `/firewall/wan-probes?${params.toString()}`
    );

}


export async function setFirewallHardening(enabled) {

    return apiClient.put(
        "/firewall/hardening",
        { enabled }
    );

}


export async function markFirewallReview() {

    return apiClient.post(
        "/firewall/hardening/review"
    );

}


export async function markAccessReview() {

    return apiClient.post(
        "/firewall/hardening/access-review"
    );

}


export async function saveAccessWindow(startHour, endHour) {

    return apiClient.put(
        "/firewall/hardening/access-window",
        { start_hour: startHour, end_hour: endHour }
    );

}



//
// Protection -- attack / evasion detection summary
//

export async function getProtectionSummary(hours = 24, domain = "") {

    const params = new URLSearchParams({ hours: String(hours) });

    const trimmed = (domain || "").trim();

    if (trimmed) {
        params.append("domain", trimmed);
    }

    return apiClient.get(
        `/protection/summary?${params}`
    );

}


export async function getIpsStatus() {

    return apiClient.get(
        "/ips/status"
    );

}


export async function getThreatResponse() {

    return apiClient.get(
        "/ips/threat-response"
    );

}


export async function updateThreatResponse(payload) {

    return apiClient.put(
        "/ips/threat-response",
        payload
    );

}


export async function getMalwareEvents(limit = 10) {

    return apiClient.get(
        `/ips/malware-events?limit=${limit}`
    );

}


export async function getQuarantinedDevices() {

    return apiClient.get(
        "/ips/quarantine"
    );

}


export async function getQuarantineCount() {

    return apiClient.get(
        "/ips/quarantine/count"
    );

}


export async function releaseQuarantine(deviceId) {

    return apiClient.post(
        `/ips/quarantine/${deviceId}/release`,
        {}
    );

}


export async function getQuarantineEmailSettings() {

    return apiClient.get(
        "/notifications/quarantine/settings"
    );

}


export async function saveQuarantineEmailSettings(payload) {

    return apiClient.put(
        "/notifications/quarantine/settings",
        payload
    );

}


export async function refreshThreatIntel() {

    return apiClient.post(
        "/ips/threat-intel/refresh"
    );

}


//
// Users -- account management (admin)
//

export async function getUsers() {

    return apiClient.get(
        "/users/"
    );

}


export async function createUser(payload) {

    return apiClient.post(
        "/users/",
        payload
    );

}


export async function changeUserRole(userId, role) {

    return apiClient.put(
        `/users/${userId}/role`,
        { role }
    );

}


export async function changeUserStatus(userId, enabled) {

    return apiClient.put(
        `/users/${userId}/status`,
        { enabled }
    );

}


export async function changePassword(currentPassword, newPassword) {

    return apiClient.post(
        "/auth/change-password",
        {
            current_password: currentPassword,
            new_password: newPassword
        }
    );

}


export async function mfaSetup() {

    return apiClient.post(
        "/auth/mfa/setup",
        {}
    );

}


export async function mfaConfirm(code) {

    return apiClient.post(
        "/auth/mfa/confirm",
        { code }
    );

}


export async function mfaDisable(currentPassword) {

    return apiClient.post(
        "/auth/mfa/disable",
        { current_password: currentPassword }
    );

}


export async function loginMfa(mfaToken, code) {

    return apiClient.post(
        "/auth/login/mfa",
        {
            mfa_token: mfaToken,
            code
        }
    );

}


//
// Port forwarding (DMZ)
//

export async function getPortForwards() {

    return apiClient.get(
        "/port-forwards/"
    );

}


export async function createPortForward(payload) {

    return apiClient.post(
        "/port-forwards/",
        payload
    );

}


export async function updatePortForward(id, payload) {

    return apiClient.patch(
        `/port-forwards/${id}`,
        payload
    );

}


export async function deletePortForward(id) {

    return apiClient.delete(
        `/port-forwards/${id}`
    );

}


//
// VPN (WireGuard remote access)
//

export async function getVpnStatus() {

    return apiClient.get(
        "/vpn/status"
    );

}


export async function getVpnPeers() {

    return apiClient.get(
        "/vpn/peers"
    );

}


export async function getVpnSessions() {

    return apiClient.get(
        "/vpn/sessions"
    );

}


export async function createVpnPeer(payload) {

    return apiClient.post(
        "/vpn/peers",
        payload
    );

}


export async function updateVpnPeer(id, payload) {

    return apiClient.patch(
        `/vpn/peers/${id}`,
        payload
    );

}


export async function deleteVpnPeer(id) {

    return apiClient.delete(
        `/vpn/peers/${id}`
    );

}


//
//
// Tailscale
//

export async function getTailscaleStatus() {

    return apiClient.get(
        "/vpn/tailscale"
    );

}


export async function connectTailscale(authKey) {

    return apiClient.post(
        "/vpn/tailscale/connect",
        { auth_key: authKey }
    );

}


export async function disconnectTailscale() {

    return apiClient.post(
        "/vpn/tailscale/disconnect"
    );

}


export async function getTailscaleShares() {

    return apiClient.get(
        "/vpn/tailscale/shares"
    );

}


export async function createTailscaleShare(capacity, email) {

    return apiClient.post(
        "/vpn/tailscale/shares",
        { capacity: capacity, email: email || null }
    );

}


export async function revokeTailscaleShare(inviteId) {

    return apiClient.delete(
        `/vpn/tailscale/shares/${inviteId}`
    );

}


//
// RustDesk (self-hosted remote desktop)
////

export async function getRustdeskStatus() {

    return apiClient.get(
        "/rustdesk/status"
    );

}


export async function updateRustdeskConfig(payload) {

    return apiClient.put(
        "/rustdesk/config",
        payload
    );

}


//
// Network disk / shared folders (Samba + device groups)
//

export async function getShareStatus() {

    return apiClient.get("/shares/status");

}


export async function updateShareConfig(payload) {

    return apiClient.put("/shares/config", payload);

}


export async function assignShareDisk(device) {

    return apiClient.post("/shares/disk", { device });

}


export async function releaseShareDisk() {

    return apiClient.post("/shares/disk/release", {});

}


export async function formatShareDisk(payload) {

    return apiClient.post("/shares/disk/format", payload);

}


export async function deleteSharePartition(payload) {

    return apiClient.post("/shares/disk/delete-partition", payload);

}


export async function createSharePartition(payload) {

    return apiClient.post("/shares/disk/create-partition", payload);

}


export async function unlockShareIntegrity() {

    return apiClient.post("/shares/integrity/unlock", {});

}


export async function pauseShareIntegrity(hours = 2) {

    return apiClient.post("/shares/integrity/pause", { hours });

}


export async function resumeShareIntegrity() {

    return apiClient.post("/shares/integrity/resume", {});

}


export async function shareVolume(payload) {

    return apiClient.post("/shares/volumes/share", payload);

}


export async function unshareVolume(volumeId) {

    return apiClient.post(`/shares/volumes/${volumeId}/unshare`, {});

}


export async function getGroupShareVolumes(groupId) {

    return apiClient.get(`/shares/groups/${groupId}/volumes`);

}


export async function setGroupShareVolumes(groupId, payload) {

    return apiClient.put(`/shares/groups/${groupId}/volumes`, payload);

}


export async function createShareFolder(payload) {

    return apiClient.post("/shares/folders", payload);

}


export async function deleteShareFolder(folderId) {

    return apiClient.delete(`/shares/folders/${folderId}`);

}


export async function setShareFolderGroups(folderId, payload) {

    return apiClient.put(`/shares/folders/${folderId}/groups`, payload);

}


export async function setShareFolderShared(folderId, shared) {

    return apiClient.put(`/shares/folders/${folderId}/share`, { shared });

}


export async function setShareFolderBackupPolicy(folderId, policy) {

    return apiClient.put(`/shares/folders/${folderId}/backup-policy`, policy);

}


export async function getGroupShareFolders(groupId) {

    return apiClient.get(`/shares/groups/${groupId}/folders`);

}


export async function setGroupShareFolders(groupId, payload) {

    return apiClient.put(`/shares/groups/${groupId}/folders`, payload);

}


//
// Shares -- versioned backups (restic)
//

export async function getShareBackups() {

    return apiClient.get("/shares/backups");

}


export async function createShareBackup(payload) {

    return apiClient.post("/shares/backups", payload);

}


export async function updateShareBackup(jobId, payload) {

    return apiClient.put(`/shares/backups/${jobId}`, payload);

}


export async function deleteShareBackup(jobId) {

    return apiClient.delete(`/shares/backups/${jobId}`);

}


export async function runShareBackup(jobId) {

    return apiClient.post(`/shares/backups/${jobId}/run`);

}


export async function pruneShareBackup(jobId) {

    return apiClient.post(`/shares/backups/${jobId}/prune`);

}


export async function getShareBackupSnapshots(jobId) {

    return apiClient.get(`/shares/backups/${jobId}/snapshots`);

}


export async function getShareBackupHistory(jobId) {

    return apiClient.get(`/shares/backups/${jobId}/history`);

}


export async function getShareBackupSnapshotFiles(jobId, snapshotId, prefix = "") {

    const params = new URLSearchParams();
    if (prefix) params.set("prefix", prefix);
    const qs = params.toString();

    return apiClient.get(
        `/shares/backups/${jobId}/snapshots/${snapshotId}/files${qs ? `?${qs}` : ""}`,
    );

}


export async function downloadShareBackup(jobId, snapshotId, path = "/") {

    const params = new URLSearchParams({ path });
    return apiClient.download(
        `/shares/backups/${jobId}/snapshots/${snapshotId}/download?${params.toString()}`,
    );

}


// Shares -- web file explorer (protected storage)

export async function getWebFileUnits() {

    return apiClient.get("/shares/web/units");

}


export async function getWebFileList(unit, prefix = "") {

    const params = new URLSearchParams({ unit });
    if (prefix) params.set("prefix", prefix);
    return apiClient.get(`/shares/web/list?${params.toString()}`);

}


export async function uploadWebFile(unit, directory, files) {

    const form = new FormData();
    for (const file of files) {
        const rel = file.webkitRelativePath || file.name;
        form.append("files", file, rel);
    }
    const params = new URLSearchParams({ unit });
    if (directory) params.set("directory", directory);
    return apiClient.upload(`/shares/web/upload?${params.toString()}`, form);

}


export async function downloadWebFile(unit, path) {

    const params = new URLSearchParams({ unit, path });
    return apiClient.download(`/shares/web/download?${params.toString()}`);

}


export async function mkdirWebFile(unit, directory, name) {

    const params = new URLSearchParams({ unit, directory, name });
    return apiClient.post(`/shares/web/mkdir?${params.toString()}`, {});

}


export async function deleteWebFile(unit, path) {

    const params = new URLSearchParams({ unit, path });
    return apiClient.delete(`/shares/web?${params.toString()}`);

}


export async function moveWebFile(unit, source, dest) {

    const params = new URLSearchParams({ unit, source, dest });
    return apiClient.post(`/shares/web/move?${params.toString()}`, {});

}


//
// DHCP -- LAN network segment
//

export async function getDhcpHealth() { return apiClient.get("/dhcp/health"); }

export async function getDeviceSettings() { return apiClient.get("/devices/settings"); }

export async function updateDeviceSettings(settings) { return apiClient.put("/devices/settings", settings); }

export async function getIpPool() { return apiClient.get("/devices/ip-pool"); }

export async function getDhcpConfig() {

    return apiClient.get(
        "/dhcp/config"
    );

}


export async function setLanSegment(payload) {

    return apiClient.post(
        "/network/lan/set",
        payload
    );

}


export async function getDhcpExclusions() {

    return apiClient.get(
        "/dhcp/exclusions"
    );

}


export async function setDhcpExclusions(ips) {

    return apiClient.post(
        "/dhcp/exclusions",
        { ips }
    );

}


export async function getDhcpLogs(lines = 200, search = "") {

    const params = new URLSearchParams({ lines: String(lines) });

    const trimmed = (search || "").trim();

    if (trimmed) {
        params.append("search", trimmed);
    }

    return apiClient.get(
        `/dhcp/logs?${params}`
    );

}


export async function getDhcpStatus() {

    return apiClient.get("/dhcp/status");

}


export async function restartDhcp() {

    return apiClient.post("/dhcp/restart");

}


export async function applyDhcp() {

    return apiClient.post("/dhcp/apply");

}


export async function getDhcpCleanupSettings() {

    return apiClient.get("/dhcp/cleanup");

}


export async function saveDhcpCleanupSettings(payload) {

    return apiClient.put("/dhcp/cleanup", payload);

}


export async function runDhcpCleanup(payload = {}) {

    return apiClient.post("/dhcp/cleanup/run", payload);

}


export async function getDhcpPoolStats() {

    return apiClient.get("/dhcp/pool-stats");

}


export async function getDhcpAlertSettings() {

    return apiClient.get("/dhcp/alerts");

}


export async function saveDhcpAlertSettings(payload) {

    return apiClient.put("/dhcp/alerts", payload);

}


export async function runDhcpAlertCheck(payload = {}) {

    return apiClient.post("/dhcp/alerts/check", payload);

}


//
// System actions
//

export async function restartSystem() {

    return apiClient.post(
        "/system/restart",
        {}
    );

}


export async function rebootMachine() {

    return apiClient.post(
        "/system/reboot",
        { confirm: true }
    );

}


export async function shutdownMachine() {

    return apiClient.post(
        "/system/shutdown",
        { confirm: true }
    );

}


export async function getRemoteAdmin() {

    return apiClient.get(
        "/system/remote-admin"
    );

}


export async function setRemoteAdmin(enabled) {

    return apiClient.post(
        "/system/remote-admin",
        { enabled }
    );

}


//
// Groups (departments)
//

export async function getGroups() {

    return apiClient.get(
        "/groups/"
    );

}


export async function createGroup(payload) {

    return apiClient.post(
        "/groups/",
        payload
    );

}


export async function updateGroup(id, payload) {

    return apiClient.patch(
        `/groups/${id}`,
        payload
    );

}


export async function deleteGroup(id) {

    return apiClient.delete(
        `/groups/${id}`
    );

}


export async function getGroupDevices(id) {

    return apiClient.get(
        `/groups/${id}/devices`
    );

}


export async function addGroupDevice(groupId, deviceId) {

    return apiClient.put(
        `/groups/${groupId}/devices/${deviceId}`,
        {}
    );

}


export async function removeGroupDevice(groupId, deviceId) {

    return apiClient.delete(
        `/groups/${groupId}/devices/${deviceId}`
    );

}


export async function getGroupRules(id) {

    return apiClient.get(
        `/groups/${id}/rules`
    );

}


export async function addGroupRule(groupId, action, domain) {

    return apiClient.post(
        `/groups/${groupId}/rules`,
        { action, domain }
    );

}


export async function deleteGroupRule(ruleId) {

    return apiClient.delete(
        `/groups/rules/${ruleId}`
    );

}


export async function getGroupCategories(groupId) {

    return apiClient.get(
        `/groups/${groupId}/categories`
    );

}


export async function setGroupCategories(groupId, keys) {

    return apiClient.put(
        `/groups/${groupId}/categories`,
        { keys }
    );

}