import { useEffect, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getVpnStatus,
    getVpnPeers,
    getVpnSessions,
    createVpnPeer,
    updateVpnPeer,
    deleteVpnPeer,
    getTailscaleStatus,
    connectTailscale,
    disconnectTailscale,
    getTailscaleShares,
    createTailscaleShare,
    revokeTailscaleShare
} from "../../services/api";

import { formatDateTime } from "../../utils/datetime";

import "./vpn.css";


function Vpn() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [peers, setPeers] = useState([]);

    const [sessions, setSessions] = useState([]);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState(null);

    const [created, setCreated] = useState(null);

    const [busy, setBusy] = useState(false);

    const [ts, setTs] = useState(null);

    const [authKey, setAuthKey] = useState("");

    const [shares, setShares] = useState([]);

    const [shareHint, setShareHint] = useState(null);

    const [inviteCapacity, setInviteCapacity] = useState("1");

    const [inviteEmail, setInviteEmail] = useState("");

    const [sharesBusy, setSharesBusy] = useState(false);

    const [form, setForm] = useState({
        name: "",
        client_note: "",
        expires_at: ""
    });


    function load() {

        Promise.all([
            getVpnStatus(),
            getVpnPeers(),
            getVpnSessions(),
            getTailscaleStatus(),
            getTailscaleShares()
        ])

            .then(([s, p, sess, ts, sh]) => {
                setStatus(s);
                setPeers(p || []);
                setSessions(sess || []);
                setTs(ts);
                if (sh && sh.success) {
                    setShares(sh.invites || []);
                    setShareHint(null);
                } else if (sh && sh.error) {
                    setShares([]);
                    setShareHint(sh.message || sh.error);
                }
            })

            .catch((err) => setError(err.message))

            .finally(() => setLoading(false));

    }


    useEffect(() => {

        load();

        const interval = setInterval(load, 15000);

        return () => clearInterval(interval);

    }, []);


    async function handleCreate() {

        setError(null);

        setBusy(true);

        try {

            const result = await createVpnPeer({
                name: form.name,
                client_note: form.client_note || null,
                expires_at: form.expires_at || null
            });

            setCreated(result);

            setForm({ name: "", client_note: "", expires_at: "" });

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleDelete(peer) {

        setError(null);

        setBusy(true);

        try {

            await deleteVpnPeer(peer.id);

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleToggle(peer) {

        setError(null);

        setBusy(true);

        try {

            await updateVpnPeer(peer.id, { enabled: !peer.enabled });

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const activeCount = sessions.filter((s) => s.active).length;

    async function handleTailscaleConnect() {

        setError(null);

        setBusy(true);

        try {

            await connectTailscale(authKey.trim());

            setAuthKey("");

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleTailscaleDisconnect() {

        setError(null);

        setBusy(true);

        try {

            await disconnectTailscale();

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleCreateShare() {

        setError(null);

        setSharesBusy(true);

        try {

            const result = await createTailscaleShare(
                Number(inviteCapacity),
                inviteEmail.trim() || null
            );

            if (result && !result.success) {

                setShareHint(result.message || result.error);

                setShares([]);

            } else {

                setShareHint(null);

                load();

            }

        } catch (err) {

            setError(err.message);

        } finally {

            setSharesBusy(false);

        }

    }


    async function handleRevokeShare(inviteId) {

        setError(null);

        setSharesBusy(true);

        try {

            await revokeTailscaleShare(inviteId);

            setShareHint(null);

            load();

        } catch (err) {

            setError(err.message);

        } finally {

            setSharesBusy(false);

        }

    }


    async function handleCopyInvite(url) {

        setError(null);

        try {

            await navigator.clipboard.writeText(url);

            setShareHint("Enlace de invitación copiado.");

        } catch (err) {

            setError(err.message);

        }

    }


    return (

        <div className="vpn-panel">

            <h2>VPN de acceso remoto (WireGuard)</h2>

            <p className="vpn-hint">

                Todo acceso administrativo remoto debe realizarse a
                través de esta VPN cifrada. Cuando la política estricta
                está activa
                (<code>STEPAD_VPN_REQUIRE_REMOTE_ADMIN</code>), la web
                de administración queda limitada a LAN/VPN desde la WAN.

            </p>

            {error && (
                <div className="vpn-error">{error}</div>
            )}

            {
                status && (
                    <div className="vpn-status-grid">

                        <div className="vpn-status-card">
                            <div className="vpn-status-label">Interfaz</div>
                            <div className="vpn-status-value">{status.interface}</div>
                        </div>

                        <div className="vpn-status-card">
                            <div className="vpn-status-label">Red VPN</div>
                            <div className="vpn-status-value">{status.address}</div>
                        </div>

                        <div className="vpn-status-card">
                            <div className="vpn-status-label">Puerto UDP</div>
                            <div className="vpn-status-value">{status.listen_port}</div>
                        </div>

                        <div className="vpn-status-card">
                            <div className="vpn-status-label">Clave pública del servidor</div>
                            <div className="vpn-status-value vpn-code">{status.public_key}</div>
                        </div>

                        <div className="vpn-status-card">
                            <div className="vpn-status-label">Sesiones activas</div>
                            <div className="vpn-status-value">{activeCount} / {status.peers} peers</div>
                        </div>

                    </div>
                )
            }


            {
                isAdmin && (
                    <div className="vpn-create">

                        <h3>Autorizar nuevo acceso remoto</h3>

                        <p className="vpn-hint">

                            Debe estar autorizado, documentado y
                            justificado antes de habilitarse. Indica la
                            justificación en "Motivo" y, si es temporal,
                            una fecha de caducidad.

                        </p>

                        <div className="vpn-form">

                            <label>
                                Nombre (persona / proveedor)
                                <input
                                    type="text"
                                    value={form.name}
                                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                                    placeholder="ej. Proveedor Soporte S.A."
                                />
                            </label>

                            <label>
                                Motivo / justificación
                                <input
                                    type="text"
                                    value={form.client_note}
                                    onChange={(e) => setForm({ ...form, client_note: e.target.value })}
                                    placeholder="ej. Trabajo contratado: actualización firmware"
                                />
                            </label>

                            <label>
                                Caducidad (opcional, vacío = permanente)
                                <input
                                    type="datetime-local"
                                    value={form.expires_at}
                                    onChange={(e) => setForm({ ...form, expires_at: e.target.value })}
                                />
                            </label>

                            <button
                                className="primary-button"
                                onClick={handleCreate}
                                disabled={busy || !form.name}
                            >
                                {busy ? "Generando..." : "Autorizar y generar acceso"}
                            </button>

                        </div>

                    </div>
                )
            }


            {
                created && (
                    <div className="vpn-created">

                        <h3>Acceso generado — guarda esta configuración</h3>

                        <p className="vpn-hint">

                            La clave privada solo se muestra una vez.
                            Guárdala y entrégala al autorizado; si se
                            pierde, elimina el peer y vuelve a generarlo.

                        </p>

                        <pre className="vpn-config">
                            {created.config}
                        </pre>

                        <div className="vpn-close">
                            <button
                                className="secondary-button"
                                onClick={() => setCreated(null)}
                            >
                                Cerrar
                            </button>
                        </div>

                    </div>
                )
            }


            <h3>Peers autorizados</h3>

            {
                loading && <p>Cargando...</p>
            }

            {
                !loading && peers.length === 0 && (
                    <p className="vpn-empty">No hay accesos remotos autorizados.</p>
                )
            }

            <table className="vpn-table">

                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>IP VPN</th>
                        <th>Motivo</th>
                        <th>Caduca</th>
                        <th>Estado</th>
                        <th>Actividad</th>
                        {isAdmin && <th>Acciones</th>}
                    </tr>
                </thead>

                <tbody>

                    {
                        peers.map((peer) => (
                            <tr key={peer.id} className={!peer.enabled ? "row-disabled" : ""}>

                                <td>{peer.name}</td>

                                <td className="vpn-code">{peer.allowed_ip}</td>

                                <td>{peer.client_note || "—"}</td>

                                <td>{peer.expires_at ? formatDateTime(peer.expires_at) : "Permanente"}</td>

                                <td>
                                    <span className={`rule-state ${peer.enabled ? "enabled" : "disabled"}`}>
                                        {peer.enabled ? "ACTIVO" : "INACTIVO"}
                                    </span>
                                </td>

                                <td>
                                    {
                                        peer.active
                                            ? `Conectado (hace ${peer.last_handshake_seconds_ago}s)`
                                            : peer.last_handshake_seconds_ago != null
                                                ? `Última conexión hace ${Math.floor(peer.last_handshake_seconds_ago / 60)}m`
                                                : "Nunca conectado"
                                    }
                                </td>

                                {
                                    isAdmin && (
                                        <td>
                                            <button
                                                className="secondary-button small"
                                                onClick={() => handleToggle(peer)}
                                                disabled={busy}
                                            >
                                                {peer.enabled ? "Desactivar" : "Activar"}
                                            </button>
                                            <button
                                                className="danger-button small"
                                                onClick={() => handleDelete(peer)}
                                                disabled={busy}
                                            >
                                                Revocar
                                            </button>
                                        </td>
                                    )
                                }

                            </tr>
                        ))
                    }

                </tbody>

            </table>


            <h3>Supervisión de sesiones (revisión semanal/mensual)</h3>

            <table className="vpn-table">

                <thead>
                    <tr>
                        <th>Peer</th>
                        <th>IP origen</th>
                        <th>Estado</th>
                        <th>Última conexión</th>
                        <th>Traffic RX/TX</th>
                    </tr>
                </thead>

                <tbody>

                    {
                        sessions.length === 0 && (
                            <tr><td colSpan={5} className="vpn-empty">Sin sesiones registradas.</td></tr>
                        )
                    }

                    {
                        sessions.map((s, index) => (
                            <tr key={index}>

                                <td className="vpn-code">{s.public_key.slice(0, 18)}…</td>

                                <td>{s.endpoint || "—"}</td>

                                <td>
                                    <span className={`rule-state ${s.active ? "enabled" : "disabled"}`}>
                                        {s.active ? "ACTIVA" : "INACTIVA"}
                                    </span>
                                </td>

                                <td>
                                    {
                                        s.latest_handshake
                                            ? formatDateTime(s.latest_handshake * 1000)
                                            : "—"
                                    }
                                </td>

                                <td>
                                    {(s.rx_bytes / 1024).toFixed(0)} KB / {(s.tx_bytes / 1024).toFixed(0)} KB
                                </td>

                            </tr>
                        ))
                    }

                </tbody>

            </table>


            <div className="vpn-tailscale">

                <h3>Acceso remoto por Tailscale</h3>

                <p className="vpn-hint">

                    Une este NSP a tu red Tailscale para administrarlo
                    desde cualquier lugar: web y SSH con una IP de VPN
                    fija, sin depender de la LAN ni de la IP pública.

                </p>

                {
                    ts && (
                        <div className="vpn-status-grid">

                            <div className="vpn-status-card">
                                <div className="vpn-status-label">Estado</div>
                                <div className="vpn-status-value">
                                    {
                                        ts.state === "connected"
                                            ? "CONECTADO"
                                            : ts.state === "need_login"
                                                ? "SIN CONECTAR"
                                                : "NO INSTALADO"
                                    }
                                </div>
                            </div>

                            <div className="vpn-status-card">
                                <div className="vpn-status-label">IP de VPN</div>
                                <div className="vpn-status-value vpn-code">{ts.ip || "—"}</div>
                            </div>

                            <div className="vpn-status-card">
                                <div className="vpn-status-label">Punto final</div>
                                <div className="vpn-status-value vpn-code">{ts.hostname || "—"}</div>
                            </div>

                            {
                                ts.ip && (
                                    <div className="vpn-status-card">
                                        <div className="vpn-status-label">Web remota</div>
                                        <div className="vpn-status-value vpn-code">
                                            <a href={ts.web_url} target="_blank" rel="noreferrer">{ts.web_url}</a>
                                        </div>
                                    </div>
                                )
                            }

                            {
                                ts.ip && (
                                    <div className="vpn-status-card">
                                        <div className="vpn-status-label">SSH</div>
                                        <div className="vpn-status-value vpn-code">{ts.ssh}</div>
                                    </div>
                                )
                            }

                        </div>
                    )
                }

                {
                    isAdmin && ts && ts.state === "connected" && (
                        <div className="vpn-create">

                            <h4>Estado</h4>

                            <p className="vpn-hint">

                                Ya puedes ingresar a la web desde tu red
                                Tailscale con
                                <code> {ts.web_url}</code> y por SSH con
                                <code> {ts.ssh}</code>.

                            </p>

                            <button
                                className="vpn-close"
                                onClick={handleTailscaleDisconnect}
                                disabled={busy}
                            >
                                Desconectar Tailscale
                            </button>

                        </div>
                    )
                }

                {
                    isAdmin && ts && ts.state !== "connected" && (
                        <div className="vpn-create">

                            <h4>Conectar a Tailscale</h4>

                            <p className="vpn-hint">

                                Genera una pre-auth key en
                                <a href="https://login.tailscale.com" target="_blank" rel="noreferrer"> login.tailscale.com</a>
                                {' → '}Settings{' → '}Keys (marca Reusable) y pégala aquí.

                            </p>

                            <div className="vpn-form">

                                <label>Pre-auth key (tskey-auth-...)</label>

                                <input
                                    type="text"
                                    value={authKey}
                                    onChange={(e) => setAuthKey(e.target.value)}
                                    placeholder="tskey-auth-…"
                                />

                            </div>

                            <button
                                className="vpn-close"
                                onClick={handleTailscaleConnect}
                                disabled={busy || !authKey.trim()}
                            >
                                Conectar
                            </button>

                        </div>
                    )
                }

                {
                    isAdmin && ts && ts.state === "connected" && (
                        <div className="vpn-create">

                            <h4>Compartir este NSP por invitación</h4>

                            <p className="vpn-hint">

                                Genera un enlace para que otra persona se conecte
                                SOLO a este NSP (web y SSH) con su propia cuenta
                                de Tailscale (gratis en login.tailscale.com).
                                No necesita IP pública ni abrir puertos, y no ve
                                el resto de tu red.

                            </p>

                            <div className="vpn-form vpn-share-row">

                                <label>
                                    Tipo
                                    <select
                                        value={inviteCapacity}
                                        onChange={(e) => setInviteCapacity(e.target.value)}
                                    >
                                        <option value="1">Un solo uso</option>
                                        <option value="100">Varios usos (100)</option>
                                    </select>
                                </label>

                                <label>
                                    Email del invitado (opcional)
                                    <input
                                        type="email"
                                        value={inviteEmail}
                                        onChange={(e) => setInviteEmail(e.target.value)}
                                        placeholder="correo@ejemplo.com"
                                    />
                                </label>

                            </div>

                            <button
                                className="vpn-close"
                                onClick={handleCreateShare}
                                disabled={sharesBusy}
                            >
                                Generar enlace de invitación
                            </button>

                            {
                                shareHint && (
                                    <p className="vpn-error">{shareHint}</p>
                                )
                            }

                            {
                                shares.length > 0 && (
                                    <table className="vpn-table">
                                        <thead>
                                            <tr>
                                                <th>Invitado</th>
                                                <th>Estado</th>
                                                <th>Usos</th>
                                                <th>Creado</th>
                                                <th>Enlace</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                shares.map((inv) => (
                                                    <tr key={inv.id}>
                                                        <td>{inv.email || "Por enlace"}</td>
                                                        <td>{inv.state}</td>
                                                        <td>{inv.capacity}</td>
                                                        <td>
                                                            {inv.created_at ? formatDateTime(inv.created_at) : "—"}
                                                        </td>
                                                        <td className="vpn-code">
                                                            {
                                                                inv.invite_url
                                                                    ? (
                                                                        <a href={inv.invite_url} target="_blank" rel="noreferrer">
                                                                            abrir invitación
                                                                        </a>
                                                                    )
                                                                    : "por email"
                                                            }
                                                        </td>
                                                        <td>
                                                            <div className="vpn-actions">
                                                                {
                                                                    inv.invite_url && (
                                                                        <button
                                                                            className="vpn-close"
                                                                            onClick={() => handleCopyInvite(inv.invite_url)}
                                                                            disabled={sharesBusy}
                                                                        >
                                                                            Copiar
                                                                        </button>
                                                                    )
                                                                }
                                                                <button
                                                                    className="vpn-close"
                                                                    onClick={() => handleRevokeShare(inv.id)}
                                                                    disabled={sharesBusy}
                                                                >
                                                                    Revocar
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                ))
                                            }
                                        </tbody>
                                    </table>
                                )
                            }

                        </div>
                    )
                }

            </div>

        </div>

    );

}


export default Vpn;
