# STEPAD NSP — Guía de contexto y trabajo

Esta guía permite retomar el trabajo en STEPAD NSP en cualquier sesión
(chat/editor nuevo) sin perder el hilo. Léela primero.

## Qué es
Plataforma Network Security Platform (NSP) con backend Python/FastAPI + frontend
React (Vite), PostgreSQL/Alembic, dnsmasq (DHCP+DNS), pdns-recursor (filtrado),
Suricata (IPS), Samba (archivos en red), restic (respaldos), Tailscale (acceso
remoto), WireGuard (VPN). Maneja discos/particiones, carpetas compartidas,
respaldos versionados, DHCP con reservas de IP, zonas de red (LAN/VLAN) y
cortes/reportes de conectividad.

## Máquinas y acceso
- **Dev (fuente del código)**: host `debian`, LAN `192.168.100.194`, Tailscale `100.92.205.99`.
  - SSH: `paulan@host` / pass `admin` (a veces pide 2 intentos: reintentar).
  - UI: `https://<host>:8443` — admin `admin` / `admin123`.
- **Prod (respaldos/discos)**: Tailscale `100.97.46.90`, LAN `192.168.100.11`.
  - SSH: `paulan@host` / pass `admin`.
  - UI: `https://<host>:8443` — admin / `$Coys0318` (contiene `$`, en shell escapar).
- **Router de red del sitio**: Tailscale `100.116.102.19` — enp2s0=192.168.1.1 (LAN usuarios), enp1s0 WAN.
- DB: usuario `stepad_app`, db `stepad_nsp`. Password en `/etc/stepad/stepad.env` (clave `DB_PASSWORD`; en dev `paulan2000`).
- API admin: se obtiene token con `POST /api/v1/auth/login`.

## Flujo de trabajo (importante, no romper)
1. **Todo cambio se hace en DEV** (repositorio fuente). Nunca parchear prod a mano.
2. Se prueba en DEV; solo tras OK se **versiona**: actualizar `VERSION`, commit,
   `git tag -a vX.Y.Z`, push (main + tag).
3. Se arma el instalador: `export NVM_DIR="$HOME/.nvm" && source "$NVM_DIR/nvm.sh"` + `bash make-installer.sh`
   (valida shell+python+heredoc antes de crear `stepad-nsp-installer-vX.Y.Z.tar.gz`).
4. Se publica: copiar `installer*.tar.gz`, `get-stepad.sh` y `VERSION` al repo
   `stepad-nsp-release` (GitHub pages) y push.
5. El usuario actualiza las máquinas con:
   `echo admin | sudo -S bash -c "curl -fsSL https://raw.githubusercontent.com/paulvtorres/stepad-nsp-release/main/get-stepad.sh | bash"`
   (NO ejecutar actualización de prod manualmente salvo pedido explícito).

## Decisiones de diseño clave (refactorizaciones hechas)
- **Fuente única de verdad para reservas de IP**: la reserva ES `device.permanent_ip` en la DB.
  `DhcpReservationService.synchronize()` solo escribe `dhcp-host` para dispositivos con
  `permanent_ip` (nunca para cualquiera con IP dinámica). Un único escritor de
  `reservations.conf`, y al sincronizar **reinicia dnsmasq**.
- **No-robo de IP**: al reservar una IP que ya está en uso por OTRA MAC (DB o lease
  de dnsmasq activa) → rechazo 400 "Liberá esa IP antes". Implementado en
  `device_service.update_device` → `_find_ip_owner`.
- **Zonas de red = pool**: cada zona (LAN/VLAN) tiene su segmento/DHCP. Al asignar
  una tarjeta LAN con UNA zona → se une sola sin preguntar. Con varias zonas
  libres → selector (`zone_choices` en `ensure_zone_for_lan`, diálogo en UI).
  `zone_interface_resolver` resuelve por MAC → nombre → IP/CIDR (nunca `enpTest` fantasma).
- **Respaldo ligado a partición**: al crear una partición tipo "backup" se crea su
  programación por defecto (`_ensure_default_backup_job`). Destino solo puede ser
  una partición `backup`; origen nunca una `backup`. Al eliminar la partición se
  purga la bóveda (`_purge_backup_vault_for`). "Desactivar" no borra datos
  (delete_job conserva repo; `delete_job_and_repo` exige confirmación `ELIMINAR`).
- **Claves/secretos nunca se pierden**: SecretManager central + `env-backups/`
  (respaldo por cada update) + auto-restauración + respaldo del sistema.
- **Internet no se corta por IPS**: Suricata con `queue-bypass: yes` (frente a
  fallo, el tráfico pasa). Monitor WAN registra cada corte y restablecimiento
  (tabla `wan_monitor_outages`, endpoint `/wan-monitor/outages`, tarjeta en UI).
- **Online de dispositivos**: `live-status` usa ping + ARP del kernel. Fix: leer
  `flags 0x2` (REACHABLE) de `/proc/net/arp` (no la máscara `*`), para que un
  equipo con firewall que no responde ping pero con ARP completado se marque ON.

## Fixes por versión (los más relevantes)
- v2.5.200: instalador preserva secretos (clave restic ya no se pierde).
- v2.5.201: get-stepad respalda env en cada update.
- v2.5.203: auto-restauración de clave restic.
- v2.5.205+: particiones por rol (shared/backup/private) + montaje por demanda.
- v2.5.220: Suricata `queue-bypass` (WAN no se corta) + verificador conectividad.
- v2.5.222: instalador ya no se corta en frontend por NVM_DIR (comillas simples).
- v2.5.223: programación auto en partición backup + logs de cortes internet.
- v2.5.226: reporte de cortes de internet en UI (Monitoreo WAN).
- Pendientes de v2.5.227+: refactor reservas (fuente única + no-robo + pool
  excluido) y zona en interfaces (una zona = auto, varias = selector).

## Pendientes / en curso
- **¡NO VERSIONAR hasta que el usuario avise explícitamente!** Hacer cambios
  en el repo está bien, pero NO hacer bump de VERSION, tag ni publicar release.
  El 25/09 se deshizo un versionado no autorizado (v2.5.235). Preguntar siempre.
- **Instalador (install.sh)**: al final, mostrar un resumen claro del resultado
  de la instalación (p. ej. "Instalación completada con errores" o "OK"), si
  alguno de los pasos falló. Hoy los fallos de pasos intermedios pueden pasar
  desapercibidos si el script continúa y termina sin avisar.
- **Origen de red y ⚠️ "Origen no disponible"**: un origen de RED (//host o
  /mnt/stepad-network/X) se monta por demanda al ejecutar el respaldo; el ⚠️
  preventivo no debe depender de que esté montado en ese momento. `_serialize`
  ya trata orígenes de red como "disponibles"; el fallo real se registra en el
  log/resultado de la corrida (ver _mount_share/_ensure_network_unit_mounted).
  El instalador limpia placeholders residuales sin origen en
  /mnt/stepad-share/*/Respaldo/.respaldo.json (no montaje real + jobs vacíos).
- **Resize de particiones (v2.5.231++)**: implementado. Agrandar = seguro online;
  reducir = solo ext4 y DESMONTADA. Requiere parted e2fsprogs xfsprogs. Falta
  probarlo sobre partición real con espacio contiguo.
- El usuario hace los cambios de IPs de máquinas el fin de semana.

## Notas operativas
- Los `config.yaml` locales de cada máquina NO se versionan (solo timestamp
  local). Al versionar, `git checkout backend/shared/config/config.yaml`.
- En prod, deshabilitar Suricata para recuperar WAN en emergencia: `sudo systemctl stop suricata`.
- `rm`/borrado de reservas/bóvedas solo vía app (nunca a mano).