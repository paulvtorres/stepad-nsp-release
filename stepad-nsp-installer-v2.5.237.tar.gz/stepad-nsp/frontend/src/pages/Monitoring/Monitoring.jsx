import { useEffect, useState } from "react";
import {
    getWanMonitorStatus,
    getWanMonitorHistory,
    getWanMonitorOutages,
    saveWanMonitorSettings,
    snapshotWanMonitor,
} from "../../services/api";
import { useAuth } from "../../auth/useAuth";
import { formatDateTime } from "../../utils/datetime";
import { OutagesCard } from "./OutagesCard";
import "./monitoring.css";


const PERIODS = [
    { hours: 24, label: "24 h" },
    { hours: 168, label: "7 días" },
    { hours: 720, label: "30 días" },
];


function formatBps(bps) {

    if (!bps) return "0 b/s";

    if (bps >= 1e6) return `${(bps / 1e6).toFixed(1)} Mb/s`;

    if (bps >= 1e3) return `${(bps / 1e3).toFixed(0)} Kb/s`;

    return `${bps.toFixed(0)} b/s`;

}




function SignalBars({ score, online }) {

    const bars = [1, 2, 3, 4, 5];

    return (

        <div className={`signal-bars ${online ? "" : "offline"}`} aria-label={`Señal ${score} de 5`}>

            {
                bars.map((level) => (

                    <span
                        key={level}
                        className={`signal-bar ${level <= score ? "active" : ""}`}
                        style={{ height: `${8 + level * 5}px` }}
                    />

                ))
            }

        </div>

    );

}


function CheckStatus({ label, ok, detail }) {

    let state = "unknown";

    if (ok === true) state = "ok";

    if (ok === false) state = "fail";

    return (

        <div className={`wan-check wan-check-${state}`}>

            <span className="wan-check-dot" />

            <div>
                <strong>{label}</strong>
                {detail && <span>{detail}</span>}
            </div>

        </div>

    );

}


function LineChart({ points, height, stroke, yMax, ySuffix, label, formatValue }) {

    const width = 360;

    if (!points || points.length < 2) {

        return (

            <div className="wan-chart">

                <div className="wan-chart-label">{label}</div>

                <div className="wan-chart-empty">Sin datos en este período.</div>

            </div>

        );

    }
    const max = yMax || Math.max(...points.map((p) => p), 1) * 1.15;

    const step = width / (points.length - 1);

    const coords = points.map((p, i) => {

        const x = i * step;

        const y = height - (Math.min(p, max) / max) * (height - 12) - 6;

        return [x, y];

    });

    const path = coords.map(([x, y], i) => (i === 0 ? `M ${x} ${y}` : `L ${x} ${y}`)).join(" ");

    const last = points[points.length - 1];

    const display = formatValue ? formatValue(last) : `${last}${ySuffix || ""}`;

    return (

        <div className="wan-chart">

            <div className="wan-chart-header">

                <span className="wan-chart-label">{label}</span>

                <span className="wan-chart-current">{display}</span>

            </div>

            <svg
                width="100%"
                height={height}
                viewBox={`0 0 ${width} ${height}`}
                preserveAspectRatio="none"
            >

                {[0.25, 0.5, 0.75].map((ratio) => (

                    <line
                        key={ratio}
                        x1={0}
                        y1={height * ratio}
                        x2={width}
                        y2={height * ratio}
                        className="wan-chart-grid"
                    />

                ))}

                <path d={`${path} L ${width} ${height} L 0 ${height} Z`} className="wan-chart-area" style={{ fill: stroke }} />

                <path d={path} className="wan-chart-line" style={{ stroke }} />

            </svg>

            <div className="wan-chart-footer">
                {points.length} muestras · máx. {formatValue ? formatValue(max) : `${max.toFixed(0)}${ySuffix || ""}`}
            </div>

        </div>

    );

}


function WanInterfaceCard({ name, iface, summary, series, rangeHours }) {

    const quality = iface?.quality || {};

    const online = quality.online !== false && iface?.link_up && iface?.ping_ok;

    const historyPoints = series || [];

    return (

        <section className="wan-card">

            <div className="wan-card-hero">

                <div className="wan-card-identity">

                    <SignalBars score={quality.score || 0} online={online} />

                    <div>

                        <h4>{name}</h4>

                        <span className={`wan-quality wan-quality-${quality.label || "unknown"}`}>
                            {quality.label_es || (online ? "Conectado" : "Sin conexión")}
                        </span>

                    </div>

                </div>

                <div className="wan-card-meta">

                    <div>
                        <span className="wan-meta-label">Última muestra</span>
                        <span className="wan-meta-value">{formatDateTime(iface?.timestamp, "—")}</span>
                    </div>

                    {
                        summary?.uptime_pct != null && (
                            <div>
                                <span className="wan-meta-label">Disponibilidad ({rangeHours}h)</span>
                                <span className="wan-meta-value">{summary.uptime_pct}%</span>
                            </div>
                        )
                    }

                </div>

            </div>

            <div className="wan-metrics">

                <div className="wan-metric">
                    <span className="wan-metric-label">Latencia</span>
                    <span className="wan-metric-value">
                        {iface?.latency_ms != null ? `${iface.latency_ms.toFixed(0)} ms` : "—"}
                    </span>
                    {
                        summary?.avg_latency_ms != null && (
                            <span className="wan-metric-hint">prom. {summary.avg_latency_ms} ms</span>
                        )
                    }
                </div>

                <div className="wan-metric">
                    <span className="wan-metric-label">Pérdida</span>
                    <span className="wan-metric-value">{iface?.packet_loss ?? 0}%</span>
                    {
                        summary?.avg_packet_loss != null && (
                            <span className="wan-metric-hint">prom. {summary.avg_packet_loss}%</span>
                        )
                    }
                </div>

                <div className="wan-metric">
                    <span className="wan-metric-label">Enlace</span>
                    <span className="wan-metric-value">
                        {iface?.link_speed_mbps ? `${iface.link_speed_mbps} Mb/s` : (iface?.link_up ? "Conectado" : "Caído")}
                    </span>
                </div>

                <div className="wan-metric">
                    <span className="wan-metric-label">Descarga</span>
                    <span className="wan-metric-value">{formatBps(iface?.rx_bps)}</span>
                </div>

                <div className="wan-metric">
                    <span className="wan-metric-label">Subida</span>
                    <span className="wan-metric-value">{formatBps(iface?.tx_bps)}</span>
                </div>

            </div>

            <div className="wan-checks">

                <CheckStatus label="Cable / enlace" ok={iface?.link_up} />

                <CheckStatus
                    label="Gateway"
                    ok={iface?.gateway_ok}
                    detail={iface?.gateway_ip || undefined}
                />

                <CheckStatus label="Ping externo" ok={iface?.ping_ok} />

                <CheckStatus label="Resolución DNS" ok={iface?.dns_ok} />

                <CheckStatus
                    label="HTTP"
                    ok={iface?.http_ok}
                    detail={iface?.http_ok === null ? "Desactivado" : undefined}
                />

            </div>

            <div className="wan-charts">

                <LineChart
                    points={historyPoints.map((h) => h.latency_ms || 0)}
                    height={88}
                    stroke="#38bdf8"
                    label="Latencia"
                    ySuffix=" ms"
                    formatValue={(v) => `${v.toFixed(0)} ms`}
                />

                <LineChart
                    points={historyPoints.map((h) => h.packet_loss || 0)}
                    height={88}
                    stroke="#facc15"
                    label="Pérdida de paquetes"
                    ySuffix="%"
                    yMax={100}
                    formatValue={(v) => `${v.toFixed(1)}%`}
                />

                <LineChart
                    points={historyPoints.map((h) => h.rx_bps || 0)}
                    height={88}
                    stroke="#22c55e"
                    label="Descarga"
                    formatValue={formatBps}
                />

                <LineChart
                    points={historyPoints.map((h) => h.tx_bps || 0)}
                    height={88}
                    stroke="#a855f7"
                    label="Subida"
                    formatValue={formatBps}
                />

            </div>

        </section>

    );

}




function formatDuration(seconds) {
    if (seconds == null) return "—";
    const m = Math.floor(seconds / 60);
    const h = Math.floor(m / 60);
    const d = Math.floor(h / 24);
    if (d > 0) return `${d}d ${h % 24}h`;
    if (h > 0) return `${h}h ${m % 60}m`;
    if (m > 0) return `${m}m`;
    return `${seconds}s`;
}


export default function Monitoring() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [settings, setSettings] = useState(null);

    const [history, setHistory] = useState({ series: {}, summary: {} });

    const [outages, setOutages] = useState([]);

    const [range, setRange] = useState(24);

    const [msg, setMsg] = useState(null);

    const [busy, setBusy] = useState(false);

    const [settingsOpen, setSettingsOpen] = useState(false);

    const [lastRefresh, setLastRefresh] = useState(null);


    async function loadStatus() {

        try {

            const data = await getWanMonitorStatus();

            setStatus(data);

            if (!settings) setSettings(data.settings);

            setLastRefresh(new Date());

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        }

    }


    async function loadHistory() {

        try {

            const data = await getWanMonitorHistory(range);

            if (data?.series) {

                setHistory(data);

            } else {

                setHistory({ series: data || {}, summary: {} });

            }

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        }

    }


    async function loadOutages() {

        try {

            const data = await getWanMonitorOutages(range);

            setOutages(Array.isArray(data) ? data : []);

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        }

    }


    async function refreshAll() {

        setBusy(true);

        await loadStatus();

        await loadHistory();

        await loadOutages();

        setBusy(false);

    }


    useEffect(() => {

        refreshAll();

        const timer = setInterval(() => {

            loadStatus();

            loadHistory();

            loadOutages();

        }, 30000);

        return () => clearInterval(timer);

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    useEffect(() => {

        loadHistory();

        loadOutages();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [range]);


    async function handleSave() {

        setMsg(null);

        setBusy(true);

        try {

            const saved = await saveWanMonitorSettings({
                enabled: settings.enabled,
                interval_seconds: Number(settings.interval_seconds),
                ping_targets: settings.ping_targets,
                http_enabled: settings.http_enabled,
                http_url: settings.http_url,
                alert_threshold: Number(settings.alert_threshold),
                retention_days: Number(settings.retention_days),
            });

            setSettings(saved);

            setMsg("Configuración guardada.");

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }

    }


    async function handleSnapshot() {

        setMsg(null);

        setBusy(true);

        try {

            await snapshotWanMonitor();

            await refreshAll();

            setMsg("Muestra tomada.");

        } catch (err) {

            setMsg(`Error: ${err.message}`);

        } finally {

            setBusy(false);

        }

    }


    const interfaces = status?.interfaces || {};

    const ifaceNames = Object.keys(interfaces);

    const intervalLabel = settings?.interval_seconds || 60;


    return (

        <div className="monitoring-page">

            <header className="monitoring-header">

                <div>

                    <h2 className="monitoring-title">Internet (WAN)</h2>

                    <p className="monitoring-hint">
                        Calidad del enlace, latencia, pérdida de paquetes y ancho de banda.
                        Muestreo cada {intervalLabel}s.
                        {
                            lastRefresh && (
                                <> · Actualizado {formatDateTime(lastRefresh)}</>
                            )
                        }
                    </p>

                </div>

                <div className="monitoring-actions">

                    <div className="period-selector">

                        {
                            PERIODS.map((period) => (

                                <button
                                    key={period.hours}
                                    type="button"
                                    className={range === period.hours ? "period active" : "period"}
                                    onClick={() => setRange(period.hours)}
                                >
                                    {period.label}
                                </button>

                            ))
                        }

                    </div>

                    <button
                        type="button"
                        className="primary-button"
                        onClick={refreshAll}
                        disabled={busy}
                    >
                        {busy ? "Actualizando..." : "Actualizar"}
                    </button>

                </div>

            </header>

            {
                msg && (
                    <div className="monitoring-message">{msg}</div>
                )
            }

            {
                ifaceNames.length === 0 ? (

                    <div className="wan-empty-state">

                        <h3>Sin interfaz WAN configurada</h3>

                        <p>
                            Ve a <strong>Red → Interfaces</strong> y asigna el rol WAN
                            a la tarjeta conectada a internet para empezar el monitoreo.
                        </p>

                    </div>

                ) : (

                    ifaceNames.map((name) => (

                        <WanInterfaceCard
                            key={name}
                            name={name}
                            iface={interfaces[name]}
                            summary={history.summary?.[name]}
                            series={history.series?.[name]}
                            rangeHours={range}
                        />

                    ))

                )
            }

            <OutagesCard outages={outages} />

            <section className="wan-settings-section">

                <button
                    type="button"
                    className="wan-settings-toggle"
                    onClick={() => setSettingsOpen((open) => !open)}
                >
                    {settingsOpen ? "▾" : "▸"} Configuración del monitoreo
                </button>

                {
                    settingsOpen && settings && (

                        <div className="wan-settings-panel">

                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    checked={settings.enabled}
                                    disabled={!isAdmin}
                                    onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
                                />
                                Monitoreo automático habilitado
                            </label>

                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    checked={settings.http_enabled}
                                    disabled={!isAdmin}
                                    onChange={(e) => setSettings({ ...settings, http_enabled: e.target.checked })}
                                />
                                Chequeo HTTP (verifica respuesta web real)
                            </label>

                            <div className="schedule-row">

                                <label>
                                    Intervalo (segundos)
                                    <input
                                        type="number"
                                        value={settings.interval_seconds}
                                        min={15}
                                        max={3600}
                                        disabled={!isAdmin}
                                        onChange={(e) => setSettings({ ...settings, interval_seconds: e.target.value })}
                                    />
                                </label>

                                <label>
                                    Alertar tras fallos seguidos
                                    <input
                                        type="number"
                                        value={settings.alert_threshold}
                                        min={1}
                                        max={60}
                                        disabled={!isAdmin}
                                        onChange={(e) => setSettings({ ...settings, alert_threshold: e.target.value })}
                                    />
                                </label>

                                <label>
                                    Conservar historial (días)
                                    <input
                                        type="number"
                                        value={settings.retention_days}
                                        min={1}
                                        max={365}
                                        disabled={!isAdmin}
                                        onChange={(e) => setSettings({ ...settings, retention_days: e.target.value })}
                                    />
                                </label>

                            </div>

                            <label>
                                Destinos de ping (separados por coma)
                                <input
                                    type="text"
                                    value={settings.ping_targets}
                                    disabled={!isAdmin}
                                    onChange={(e) => setSettings({ ...settings, ping_targets: e.target.value })}
                                />
                            </label>

                            <label>
                                URL del chequeo HTTP
                                <input
                                    type="text"
                                    value={settings.http_url}
                                    disabled={!isAdmin}
                                    onChange={(e) => setSettings({ ...settings, http_url: e.target.value })}
                                />
                            </label>

                            <div className="confirm-actions">

                                <button
                                    type="button"
                                    className="primary-button"
                                    onClick={handleSave}
                                    disabled={busy || !isAdmin}
                                >
                                    Guardar
                                </button>

                                <button
                                    type="button"
                                    className="secondary-button"
                                    onClick={handleSnapshot}
                                    disabled={busy || !isAdmin}
                                >
                                    Tomar muestra ahora
                                </button>

                            </div>

                        </div>

                    )
                }

            </section>

        </div>

    );

}
