export function OutagesCard({ outages }) {
    const items = Array.isArray(outages) ? outages : [];
    const open = items.filter((o) => !o.ended_at);
    const closed = items.filter((o) => o.ended_at);
    const totalSeconds = closed.reduce((acc, o) => acc + (o.duration_seconds || 0), 0);
    const fmt = (iso) => {
        if (!iso) return "—";
        const d = new Date(iso);
        return d.toLocaleString("es-EC", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    };

    return (
        <section className="wan-card wan-outages-card">
            <div className="wan-card-hero">
                <div className="wan-card-identity">
                    <span className="wan-check-dot wan-check-bad" />
                    <div>
                        <strong>Cortes de internet (reporte)</strong>
                        <span className="wan-card-sub">Tiempo sin señal registrado</span>
                    </div>
                </div>
                <div className="wan-card-meta">
                    {closed.length > 0 && (
                        <span className="wan-meta-value">
                            {closed.length} corte{closed.length !== 1 ? "s" : ""}
                            {" · "}{formatDuration(totalSeconds)} sin internet
                        </span>
                    )}
                    {open.length > 0 && (
                        <span className="wan-meta-value wan-outage-open">
                            {open.length} corte activo ahora
                        </span>
                    )}
                </div>
            </div>

            {items.length === 0 ? (
                <div className="wan-chart-empty">Sin cortes registrados en este período.</div>
            ) : (
                <table className="devices-table" style={{ minWidth: 0, marginTop: 10 }}>
                    <thead>
                        <tr><th>Inicio del corte</th><th>Fin / restablecimiento</th><th>Duración</th><th>Estado</th></tr>
                    </thead>
                    <tbody>
                        {items.map((o) => (
                            <tr key={o.id}>
                                <td>{fmt(o.started_at)}</td>
                                <td>{fmt(o.ended_at)}</td>
                                <td>{formatDuration(o.duration_seconds)}</td>
                                <td>
                                    {o.ended_at
                                        ? <span style={{ color: "#f87171" }}>caída</span>
                                        : <span style={{ color: "#fbbf24", fontWeight: 600 }}>activa</span>}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </section>
    );
}
