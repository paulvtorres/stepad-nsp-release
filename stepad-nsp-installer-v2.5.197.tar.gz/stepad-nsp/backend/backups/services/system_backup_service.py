"""Backup de configuracion del sistema NSP.

Diferente de BackupService (que respalda carpetas de datos),
este servicio respalda:
- PostgreSQL (dump completo)
- Archivos de configuracion (/etc/stepad/)
- Estado de nftables
- Configuracion de Suricata
- GeoIP database
- Claves y secretos

Destinos: USB local, /var/backups/stepad, o cloud (S3/B2 via restic).
"""

import gzip
import json
import os
import subprocess
import threading
import time

from datetime import datetime
from pathlib import Path

from backend.shared.logging.logger import logger


BACKUP_CONFIG = Path("/etc/stepad/system-backup-config.json")
DEFAULT_USB_PATH = "/mnt/backup/stepad"
RESTIC_PASSWORD_FILE = Path("/etc/stepad/backup-password.txt")
SYSTEM_BACKUP_DIR = Path("/var/backups/stepad")

SYSTEM_BACKUP_FAILED_ALERT = "SYSTEM_BACKUP_FAILED"

# Archivos y directorios a respaldar
CONFIG_PATHS = [
    "/etc/stepad/stepad.env",
    "/etc/stepad/dns/dnsmasq.conf",
    "/etc/stepad/dns/group-dns",
    "/etc/stepad/nftables.conf",
    "/etc/stepad/suricata",
    "/etc/stepad/geoip",
    "/etc/systemd/system/stepad-nsp.service",
    "/etc/systemd/system/stepad-nsp.service.d",
]


class SystemBackupService:

    def __init__(self):
        self._config = self._load_config()
        self._stop = False
        self._scheduler_thread: threading.Thread | None = None
        self._last_scheduled_run = None

    def _load_config(self) -> dict:
        if BACKUP_CONFIG.exists():
            try:
                return json.loads(BACKUP_CONFIG.read_text())
            except Exception:
                pass
        return {
            "enabled": True,
            "destination": "local",
            "usb_path": str(DEFAULT_USB_PATH),
            "cloud_backend": "",
            "keep_daily": 7,
            "keep_weekly": 4,
            "keep_monthly": 6,
            "schedule_enabled": True,
            "schedule_hour": 3,
            "schedule_minute": 0,
        }

    def save_config(self, config: dict):
        self._config = config
        BACKUP_CONFIG.parent.mkdir(parents=True, exist_ok=True)
        BACKUP_CONFIG.write_text(json.dumps(config, indent=2))

    def get_config(self) -> dict:
        return self._config.copy()

    def detect_usb(self) -> str | None:
        try:
            result = subprocess.run(
                ["lsblk", "-o", "NAME,SIZE,TYPE,MOUNTPOINT,FSTYPE", "-nr"],
                capture_output=True, text=True, timeout=5,
            )
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 4 and "part" in parts[2]:
                    mountpoint = parts[3]
                    fstype = parts[4] if len(parts) > 4 else ""
                    if mountpoint.startswith("/mnt") and fstype in ("vfat", "ext4", "ntfs", "exfat"):
                        return mountpoint
        except Exception:
            pass
        return None

    def _get_repo_path(self) -> str | None:
        dest = self._config.get("destination", "local")
        if dest == "usb":
            usb = self.detect_usb()
            if usb:
                return os.path.join(usb, "stepad-system-backup")
            return None
        elif dest == "cloud":
            return self._config.get("cloud_backend", "")
        else:
            SYSTEM_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            return str(SYSTEM_BACKUP_DIR / "restic-repo")
        return None

    def _ensure_repo(self, repo: str):
        if not os.path.exists(os.path.join(repo, "config")):
            subprocess.run(
                ["sudo", "restic", "init", "--repo", repo],
                capture_output=True, timeout=30,
            )

    def _password_args(self) -> list:
        if RESTIC_PASSWORD_FILE.exists():
            return ["--password-file", str(RESTIC_PASSWORD_FILE)]
        return []

    def _raise_alert(self, title: str, message: str) -> None:
        try:
            from backend.core.database.session import SessionLocal
            from backend.alerts.services.alert_service import AlertService
            db = SessionLocal()
            try:
                AlertService().create(
                    db,
                    alert_type=SYSTEM_BACKUP_FAILED_ALERT,
                    severity="warning",
                    title=title,
                    message=(message or "")[:500],
                )
                db.commit()
            finally:
                db.close()
        except Exception as error:
            logger.warning("No se pudo crear alerta de respaldo del sistema: %s", error)

    def create_backup(self, reason: str = "manual") -> dict:
        repo = self._get_repo_path()
        if not repo:
            self._raise_alert(
                "Respaldo del sistema: sin destino disponible",
                "No se pudo respaldar la configuración del NSP: "
                "no hay unidad USB, disco o backend cloud configurado.",
            )
            return {"success": False, "error": "No hay destino disponible"}

        self._ensure_repo(repo)

        dump_path = self._dump_postgres()

        try:
            cmd = [
                "sudo", "restic", "backup",
                "--repo", repo,
                *self._password_args(),
                "--tag", reason,
                "--host", "stepad-nsp",
            ]

            for p in CONFIG_PATHS:
                if os.path.exists(p):
                    cmd.append(p)

            if dump_path:
                cmd.append(dump_path)

            # Agregar version del NSP al tag
            try:
                vfile = Path("/etc/stepad/version")
                if vfile.exists():
                    version = vfile.read_text().strip()
                    cmd.extend(["--tag", "version:" + version])
            except Exception:
                pass

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

            if result.returncode != 0:
                self._raise_alert(
                    "Respaldo del sistema falló",
                    f"restic no pudo respaldar la configuración del NSP: "
                    f"{(result.stderr or '').strip()[:400]}",
                )
                return {"success": False, "error": result.stderr}

            self._cleanup(repo)

            if dump_path and os.path.exists(dump_path):
                os.unlink(dump_path)

            return {"success": True, "repo": repo, "reason": reason}

        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def _dump_postgres(self) -> str | None:
        try:
            env = {}
            env_file = Path("/etc/stepad/stepad.env")
            if env_file.exists():
                for line in env_file.read_text().splitlines():
                    if "=" in line and not line.startswith("#"):
                        k, v = line.split("=", 1)
                        env[k.strip()] = v.strip().strip("'").strip('"')

            dump_path = "/tmp/stepad-sys-backup-db.sql.gz"
            proc = subprocess.run(
                ["pg_dump", "-h", "127.0.0.1", "-U",
                 env.get("DB_USER", "stepad_app"),
                 env.get("DB_NAME", "stepad_nsp")],
                capture_output=True, timeout=120,
                env={**os.environ, "PGPASSWORD": env.get("DB_PASSWORD", "")},
            )
            if proc.returncode != 0:
                logger.warning("System backup: pg_dump fallo: %s", proc.stderr[:200])
                return None

            with gzip.open(dump_path, "wb") as f:
                f.write(proc.stdout)
            return dump_path
        except Exception as exc:
            logger.warning("System backup: error pg_dump: %s", exc)
            return None

    def _cleanup(self, repo: str):
        try:
            subprocess.run(
                ["sudo", "restic", "forget", "--repo", repo,
                 *self._password_args(),
                 "--keep-daily", str(self._config.get("keep_daily", 7)),
                 "--keep-weekly", str(self._config.get("keep_weekly", 4)),
                 "--keep-monthly", str(self._config.get("keep_monthly", 6)),
                 "--prune"],
                capture_output=True, timeout=60,
            )
        except Exception:
            pass

    def list_snapshots(self) -> list:
        repo = self._get_repo_path()
        if not repo:
            return []
        try:
            result = subprocess.run(
                ["sudo", "restic", "snapshots", "--repo", repo,
                 *self._password_args(), "--json"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                return json.loads(result.stdout)
        except Exception:
            pass
        return []

    def restore(self, snapshot_id: str = "latest") -> dict:
        repo = self._get_repo_path()
        if not repo:
            return {"success": False, "error": "No hay repositorio"}

        try:
            # 1. Restaurar archivos
            result = subprocess.run(
                ["sudo", "restic", "restore", snapshot_id,
                 "--repo", repo, *self._password_args(),
                 "--exclude", "/tmp/*",
                 "--target", "/"],
                capture_output=True, text=True, timeout=300,
            )
            if result.returncode != 0:
                return {"success": False, "error": result.stderr}

            # 2. Ejecutar migraciones Alembic (actualiza schema si hay diff)
            logger.info("Restore: ejecutando migraciones Alembic...")
            try:
                subprocess.run(
                    ["sudo", ".venv/bin/python3", "-m", "backend.scripts.migrate_schema"],
                    cwd="/home/paulan/stepad-nsp",
                    capture_output=True, text=True, timeout=120,
                )
            except Exception as exc:
                logger.warning("Restore: migraciones fallaron: %s", exc)

            # 3. Recargar servicios
            subprocess.run(["sudo", "systemctl", "daemon-reload"], timeout=10)
            subprocess.run(["sudo", "systemctl", "restart", "stepad-nsp.service"], timeout=30)

            return {"success": True, "snapshot": snapshot_id}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def check_compatibility(self, snapshot_id: str = "latest") -> dict:
        """Verifica si un backup es compatible con la version actual."""
        import re

        repo = self._get_repo_path()
        if not repo:
            return {"compatible": True, "warning": "No hay repositorio"}

        backup_version = None
        try:
            result = subprocess.run(
                ["sudo", "restic", "tags", "--repo", repo,
                 *self._password_args(), "--json"],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0:
                tags = json.loads(result.stdout)
                for tag in tags:
                    if tag.startswith("version:"):
                        backup_version = tag.split(":", 1)[1]
        except Exception:
            pass

        current_version = None
        try:
            vfile = Path("/etc/stepad/version")
            if vfile.exists():
                current_version = vfile.read_text().strip()
        except Exception:
            pass

        if not backup_version or not current_version:
            return {
                "compatible": True,
                "warning": "No se pudo determinar version del backup o del sistema",
                "backup_version": backup_version,
                "current_version": current_version,
            }

        def parse_ver(v):
            m = re.match(r"v?(\d+)\.(\d+)\.(\d+)", v)
            return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)

        bv = parse_ver(backup_version)
        cv = parse_ver(current_version)

        if bv == cv:
            return {"compatible": True, "message": "Versiones iguales"}

        if bv < cv:
            return {
                "compatible": True,
                "warning": (
                    "Backup de version %s restaurando en %s. "
                    "Las migraciones se ejecutaran automaticamente."
                ) % (backup_version, current_version),
                "backup_version": backup_version,
                "current_version": current_version,
            }

        if bv > cv:
            return {
                "compatible": False,
                "warning": (
                    "Backup de version %s es MAS NUEVO que la version "
                    "instalada (%s). Restaurar puede causar perdida de datos. "
                    "Actualice el NSP primero."
                ) % (backup_version, current_version),
                "backup_version": backup_version,
                "current_version": current_version,
            }

        return {"compatible": True}

    def get_status(self) -> dict:
        snapshots = self.list_snapshots()
        last = snapshots[-1] if snapshots else None
        return {
            "total_backups": len(snapshots),
            "last_backup": last.get("time") if last else None,
            "last_id": last.get("id") if last else None,
            "destination": self._config.get("destination", "local"),
            "usb_available": self.detect_usb() is not None,
            "enabled": self._config.get("enabled", True),
            "schedule_enabled": self._config.get("schedule_enabled", True),
            "schedule_hour": self._config.get("schedule_hour", 3),
            "schedule_minute": self._config.get("schedule_minute", 0),
        }

    def _scheduler_loop(self) -> None:
        logger.info("System backup scheduler started.")
        while not self._stop:
            try:
                config = self.get_config()
                if config.get("enabled", True) and config.get("schedule_enabled", True):
                    if self.is_due(config):
                        result = self.create_backup(reason="scheduled")
                        logger.info(
                            "System backup (scheduled): %s",
                            result.get("success") is True,
                        )
                        self._last_scheduled_run = datetime.now().strftime(
                            "%Y-%m-%dT%H:%M:%S"
                        )
            except Exception as error:
                logger.exception("System backup scheduler error: %s", error)
            for _ in range(30):
                if self._stop:
                    return
                time.sleep(2)

    def is_due(self, config: dict) -> bool:
        try:
            now = datetime.now()
            hour = int(config.get("schedule_hour", 3) or 3)
            minute = int(config.get("schedule_minute", 0) or 0)
            if (now.hour, now.minute) != (hour, minute):
                return False
            today = now.strftime("%Y-%m-%d")
            return self._last_scheduled_run is None or not self._last_scheduled_run.startswith(today)
        except Exception:
            return False

    def start_scheduler(self) -> None:
        if self._scheduler_thread is not None and self._scheduler_thread.is_alive():
            return
        self._stop = False
        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="system-backup-scheduler",
        )
        self._scheduler_thread.start()

    def stop_scheduler(self) -> None:
        self._stop = True
        thread = self._scheduler_thread
        if thread and thread.is_alive():
            thread.join(timeout=3)
        self._scheduler_thread = None


system_backup_service = SystemBackupService()
