from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database.base import Base


class NetworkShareVolume(Base):
    __tablename__ = "network_share_volumes"

    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True,
    )

    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        unique=True,
    )

    device_path: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
    )

    device_uuid: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        unique=True,
    )

    mountpoint: Mapped[str] = mapped_column(
        String(512),
        nullable=False,
    )

    sharing: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
    )

    mount_on_boot: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )


class GroupVolumeAccess(Base):
    """Acceso de un grupo de dispositivos a una unidad compartida completa.

    Refleja la tabla `group_volume_access` creada en la migración 0020.
    """

    __tablename__ = "group_volume_access"

    __table_args__ = (
        UniqueConstraint(
            "group_id",
            "volume_id",
            name="uq_group_volume_access",
        ),
    )

    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True,
    )

    group_id: Mapped[int] = mapped_column(
        ForeignKey("device_groups.id", ondelete="CASCADE"),
        nullable=False,
    )

    volume_id: Mapped[int] = mapped_column(
        ForeignKey("network_share_volumes.id", ondelete="CASCADE"),
        nullable=False,
    )

    # "read" | "write"
    access_mode: Mapped[str] = mapped_column(
        String(10),
        default="read",
        nullable=False,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )
