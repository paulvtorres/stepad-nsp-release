"""Proteccion contra fuerza bruta.

Monitorea intentos de login fallidos. Si una IP supera el umbral,
la bloquea automaticamente en nftables y genera alerta.
Desbloqueo automatico despues de un tiempo configurable.
"""

import time
import subprocess
import threading

from collections import defaultdict
from datetime import datetime, timedelta

from backend.shared.logging.logger import logger


# Configuracion por defecto
MAX_ATTEMPTS = 5
WINDOW_SECONDS = 300  # 5 minutos
BLOCK_DURATION_SECONDS = 3600  # 1 hora
NFT_SET = "auto_bruteforce_v4"
NFT_SET_V6 = "auto_bruteforce_v6"
NFT_CHAIN = "attack-block"


class BruteForceProtection:

    def __init__(self):
        self._attempts = defaultdict(list)  # ip -> [timestamp, ...]
        self._blocked = {}  # ip -> unblock_at
        self._lock = threading.Lock()
        self._max_attempts = MAX_ATTEMPTS
        self._window = WINDOW_SECONDS
        self._block_duration = BLOCK_DURATION_SECONDS

    def configure(self, max_attempts=None, window=None, block_duration=None):
        if max_attempts is not None:
            self._max_attempts = max_attempts
        if window is not None:
            self._window = window
        if block_duration is not None:
            self._block_duration = block_duration

    def record_failed_attempt(self, ip: str) -> dict:
        """Registra un intento fallido. Retorna si la IP fue bloqueada."""
        now = time.time()

        with self._lock:
            # Limpiar intentos viejos
            self._attempts[ip] = [
                t for t in self._attempts[ip]
                if now - t < self._window
            ]
            self._attempts[ip].append(now)

            if len(self._attempts[ip]) >= self._max_attempts:
                return self._block_ip(ip, reason="brute-force (%d intentos en %ds)"
                                      % (len(self._attempts[ip]), self._window))

        return {"blocked": False}

    def record_successful_login(self, ip: str):
        """Limpia intentos al hacer login exitoso."""
        with self._lock:
            self._attempts.pop(ip, None)

    def is_blocked(self, ip: str) -> bool:
        """Verifica si una IP esta bloqueada."""
        with self._lock:
            if ip not in self._blocked:
                return False
            if time.time() > self._blocked[ip]:
                # Desbloqueo automatico
                self._unblock_ip(ip)
                return False
            return True

    def _block_ip(self, ip: str, reason: str = "") -> dict:
        """Bloquea una IP en nftables."""
        now = time.time()
        self._blocked[ip] = now + self._block_duration
        self._attempts.pop(ip, None)

        # Agregar a nft set
        try:
            import ipaddress
            addr = ipaddress.ip_address(ip)
            nft_set = NFT_SET_V6 if addr.version == 6 else NFT_SET
        except ValueError:
            nft_set = NFT_SET

        try:
            subprocess.run(
                ["sudo", "nft", "add", "element", "inet", "stepad", nft_set, "{", ip, "}"],
                capture_output=True, timeout=5,
            )
        except Exception as exc:
            logger.error("BruteForce: no pude bloquear %s en nft: %s", ip, exc)

        logger.warning(
            "BruteForce: IP %s bloqueada por %s (desbloqueo en %ds)",
            ip, reason, self._block_duration,
        )

        return {
            "blocked": True,
            "ip": ip,
            "reason": reason,
            "unblocks_at": datetime.utcnow() + timedelta(seconds=self._block_duration),
        }

    def _unblock_ip(self, ip: str):
        """Desbloquea una IP en nftables."""
        self._blocked.pop(ip, None)

        try:
            import ipaddress
            addr = ipaddress.ip_address(ip)
            nft_set = NFT_SET_V6 if addr.version == 6 else NFT_SET
        except ValueError:
            nft_set = NFT_SET

        try:
            subprocess.run(
                ["sudo", "nft", "delete", "element", "inet", "stepad", nft_set, "{", ip, "}"],
                capture_output=True, timeout=5,
            )
        except Exception:
            pass

        logger.info("BruteForce: IP %s desbloqueada automaticamente", ip)

    def get_blocked_ips(self) -> list:
        """Retorna IPs bloqueadas con tiempo restante."""
        now = time.time()
        result = []
        with self._lock:
            for ip, unblock_at in self._blocked.items():
                remaining = unblock_at - now
                if remaining > 0:
                    result.append({
                        "ip": ip,
                        "remaining_seconds": int(remaining),
                        "unblocks_at": datetime.utcfromtimestamp(unblock_at).isoformat(),
                    })
        return result

    def get_stats(self) -> dict:
        """Retorna estadisticas."""
        with self._lock:
            return {
                "blocked_count": len([t for t in self._blocked.values() if t > time.time()]),
                "total_attempts": sum(len(v) for v in self._attempts.values()),
                "tracked_ips": len(self._attempts),
                "config": {
                    "max_attempts": self._max_attempts,
                    "window_seconds": self._window,
                    "block_duration_seconds": self._block_duration,
                },
            }


# Singleton
brute_force_protection = BruteForceProtection()
