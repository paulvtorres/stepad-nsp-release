import { useEffect, useState } from "react";

import {
    getDhcpConfig,
    setLanSegment,
    setDhcpExclusions,
} from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";


function LanSegmentPanel() {

    const [config, setConfig] = useState(null);

    const [network, setNetwork] = useState("");

    const [groupIpStart, setGroupIpStart] = useState("");

    const [groupIpEnd, setGroupIpEnd] = useState("");

    const [poolStart, setPoolStart] = useState("");

    const [poolEnd, setPoolEnd] = useState("");

    const [exclusions, setExclusions] = useState("");

    const [busy, setBusy] = useState(false);

    const [message, setMessage] = useState("");

    const [error, setError] = useState("");


    async function load() {

        try {

            const data = await getDhcpConfig();

            setConfig(data);

            setNetwork(`${data.network}/${data.netmask}`);
            setGroupIpStart(data.group_ip_start || "");
            setGroupIpEnd(data.group_ip_end || "");
            setPoolStart(data.pool_start);
            setPoolEnd(data.pool_end);
            setExclusions((data.excluded_ips || []).join(", "));

        } catch (e) {

            setError("No se pudo leer la configuración DHCP.");

        }

    }


    useEffect(() => {

        load();

    }, []);


    function parseExclusions() {

        return exclusions
            .split(",")
            .map((x) => x.trim())
            .filter(Boolean);

    }

    function groupIpCount() {
        if (!groupIpStart || !groupIpEnd) {
            return config?.group_ip_count || 0;
        }
        try {
            const a = groupIpStart.split(".").map(Number);
            const b = groupIpEnd.split(".").map(Number);
            const start = ((a[0] << 24) >>> 0) + (a[1] << 16) + (a[2] << 8) + a[3];
            const end = ((b[0] << 24) >>> 0) + (b[1] << 16) + (b[2] << 8) + b[3];
            return Math.max(0, end - start + 1);
        } catch {
            return config?.group_ip_count || 0;
        }
    }


    async function handleApplySegment() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setLanSegment({
                network,
                pool_start: poolStart,
                pool_end: poolEnd,
                excluded_ips: parseExclusions(),
                group_ip_start: groupIpStart || undefined,
                group_ip_end: groupIpEnd || undefined,
            });

            if (result?.success === false) {
                setError(result.message || "No se pudo aplicar el segmento.");
            } else {
                setMessage(result?.message || "Segmento aplicado.");
            }

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudo aplicar el segmento."
            );

        } finally {

            setBusy(false);

        }

    }


    async function handleSaveExclusions() {

        setBusy(true);

        setMessage("");

        setError("");

        try {

            const result = await setDhcpExclusions(parseExclusions());

            setMessage(
                result?.success
                    ? "Exclusiones guardadas y DHCP reaplicado."
                    : "Exclusiones guardadas."
            );

            await load();

        } catch (e) {

            setError(
                e?.response?.data?.detail
                || e?.response?.data?.message
                || "No se pudieron guardar las exclusiones."
            );

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="registry-panel">

            <h3>Segmento LAN y DHCP</h3>

            <p className="registry-hint">
                El segmento se divide en tres zonas: gateway (.1),
                <strong> IPs de grupos</strong> (DNS/filtrado, una por grupo)
                y <strong>pool DHCP de equipos</strong>. Si no reservás IPs
                para grupos, el NSP no podrá crear más grupos cuando se
                agoten. Por defecto se reservan 10 IPs (.10–.19).
            </p>

            {
                config && (
                    <div className="lan-stat-row">
                        <span className="lan-stat">
                            <span>Segmento</span>
                            <strong>{config.network}/{config.netmask}</strong>
                        </span>
                        <span className="lan-stat">
                            <span>Gateway</span>
                            <strong>{config.gateway}</strong>
                        </span>
                        <span className="lan-stat">
                            <span>IPs grupos</span>
                            <strong>
                                {config.group_ip_start && config.group_ip_end
                                    ? `${config.group_ip_start}–${config.group_ip_end}`
                                    : "—"}
                                {config.group_ip_count
                                    ? ` (${config.group_ip_count})`
                                    : ""}
                            </strong>
                        </span>
                        <span className="lan-stat">
                            <span>Pool equipos</span>
                            <strong>{config.pool_start}–{config.pool_end}</strong>
                        </span>
                        {
                            config.excluded_ips?.length > 0 && (
                                <span className="lan-stat">
                                    <span>Excluidas</span>
                                    <strong>{config.excluded_ips.join(", ")}</strong>
                                </span>
                            )
                        }
                    </div>
                )
            }

            <WriteGuard>

                <div className="registry-form-panel">

                    <div className="registry-form-grid">

                        <label className="registry-form-full">
                            Red (CIDR)
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.0/24"
                                value={network}
                                onChange={(e) => setNetwork(e.target.value)}
                            />
                        </label>

                    </div>

                    <p className="registry-section-label">
                        Reservado para grupos (DNS) — {groupIpCount() || "?"} grupos máx.
                    </p>

                    <div className="registry-form-grid">

                        <label>
                            Grupos desde
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.10"
                                value={groupIpStart}
                                onChange={(e) => setGroupIpStart(e.target.value)}
                            />
                        </label>

                        <label>
                            Grupos hasta
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.19"
                                value={groupIpEnd}
                                onChange={(e) => setGroupIpEnd(e.target.value)}
                            />
                        </label>

                    </div>

                    <p className="registry-section-label">
                        Pool DHCP de equipos (PCs, impresoras, etc.)
                    </p>

                    <div className="registry-form-grid">

                        <label>
                            Pool DHCP desde
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.20"
                                value={poolStart}
                                onChange={(e) => setPoolStart(e.target.value)}
                            />
                        </label>

                        <label>
                            Pool DHCP hasta
                            <input
                                type="text"
                                placeholder="ej. 192.168.1.150"
                                value={poolEnd}
                                onChange={(e) => setPoolEnd(e.target.value)}
                            />
                        </label>

                    </div>

                    <label className="registry-form-full">
                        IPs excluidas extra (IP o rango, separadas por coma)
                        <input
                            type="text"
                            placeholder="ej. 192.168.1.200-192.168.1.210"
                            value={exclusions}
                            onChange={(e) => setExclusions(e.target.value)}
                        />
                    </label>

                    <div className="confirm-actions registry-form-actions">

                        <button
                            className={`primary-button${busy ? " btn-busy" : ""}`}
                            onClick={handleApplySegment}
                            disabled={busy}
                        >
                            Cambiar segmento
                        </button>

                        <button
                            className={`secondary-button${busy ? " btn-busy" : ""}`}
                            onClick={handleSaveExclusions}
                            disabled={busy}
                        >
                            Guardar exclusiones
                        </button>

                    </div>

                </div>

            </WriteGuard>

            {message && (
                <p className="registry-message ok">✔ {message}</p>
            )}

            {error && (
                <p className="registry-message error">✖ {error}</p>
            )}

        </div>

    );

}

export default LanSegmentPanel;
