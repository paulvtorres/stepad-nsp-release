import { useEffect, useMemo, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getShareStatus,
    shareVolume,
    unshareVolume,
    formatShareDisk,
    deleteSharePartition,
    createSharePartition,
    unlockShareIntegrity,
    pauseShareIntegrity,
    resumeShareIntegrity,
    createShareFolder,
    deleteShareFolder,
    setShareFolderGroups,
    setShareFolderShared,
    setShareFolderBackupPolicy,
    getWebFileList,
} from "../../services/api";

import FolderExplorer from "./SharesExplorer";
import { getToken } from "../../auth/authStorage";

const _API_URL = import.meta.env.VITE_API_URL || "/api/v1";

async function fetchSilent(endpoint) {
    const token = getToken();
    const response = await fetch(`${_API_URL}${endpoint}`, {
        headers: {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
        },
    });
    if (!response.ok) throw new Error(`API Error ${response.status}`);
    return response.json();
}
import ShareBackupsPanel from "./SharesBackupsPanel";
import NetworkShareScanner from "./NetworkShareScanner";
import NetworkUnitsCard from "./NetworkUnitsCard";

import "./shares.css";


function formatSize(bytes) {
    if (bytes == null || !Number.isFinite(bytes) || bytes < 0) return "—";
    if (bytes === 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const idx = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const value = bytes / 1024 ** idx;
    return `${value.toFixed(value >= 100 || idx === 0 ? 0 : 1)} ${units[idx]}`;
}

function freeGbOf(bytes) {
    if (bytes == null || !Number.isFinite(bytes)) return 0;
    return bytes / (1024 ** 3);
}

function fmtGb(gb) {
    if (!Number.isFinite(gb) || gb <= 0) return "0";
    return gb >= 100 ? String(Math.floor(gb)) : String(Math.round(gb * 10) / 10);
}


function Shares() {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);
    const [groups, setGroups] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);
    const [names, setNames] = useState({});
    const [selectedDevice, setSelectedDevice] = useState(null);
    const [newPart, setNewPart] = useState({});     // disk -> { sizeGb, role }
    const [folderDraft, setFolderDraft] = useState("");
    const [confirmUp, setConfirmUp] = useState(null); // { id, label, run }
    const [permOpen, setPermOpen] = useState(null);   // folderId with open panel
    const [permDraft, setPermDraft] = useState({});   // folderId -> [{group_id, access_mode}]
    const [openFolder, setOpenFolder] = useState(null);
    const [backupOpen, setBackupOpen] = useState(null);   // folder being scheduled
    const [backupDraft, setBackupDraft] = useState({});   // folderId -> {mode, times_per_day, retention}
    const [backupAnchor, setBackupAnchor] = useState(null);
    const [networkShare, setNetworkShare] = useState(null);  // folder path for respaldos tab anchor

    const [view, setView] = useState("unidades");   // unidades | carpetas | respaldos

    useEffect(() => {
        if (!notice) return undefined;
        const timer = setTimeout(() => setNotice(null), 5000);
        return () => clearTimeout(timer);
    }, [notice]);

    function load() {
        return Promise.all([
            fetchSilent("/shares/status"),
            fetchSilent("/groups").catch(() => []),
        ])
            .then(([s, g]) => {
                setStatus(s);
                setGroups(g || []);
            })
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(load, 20000);
        return () => clearInterval(timer);
    }, []);

    const volumes = useMemo(() => (status?.volumes || []), [status]);
    const folders = useMemo(() => (status?.folders || []), [status]);
    const disks = useMemo(() => (status?.disks || []), [status]);

    // Subcarpetas de las carpetas compartidas (un nivel) para poder elegirlas
    // como origen de respaldo desde el panel (ej. Compartida/XML).
    const [subfolderSources, setSubfolderSources] = useState([]);

    useEffect(() => {
        let cancelled = false;
        (async () => {
            const items = [];
            const sharedFolders = (folders || []).filter((fl) => fl.shared && fl.path);
            for (const fl of sharedFolders) {
                const volume = volumes.find((v) => v.id === fl.volume_id);
                if (!volume?.mountpoint) continue;
                const parts = fl.path.split("/").filter(Boolean);
                const prefix = parts[parts.length - 1] || "";
                try {
                    const listing = await getWebFileList(volume.mountpoint, prefix);
                    for (const dir of listing.directories || []) {
                        items.push({
                            path: [volume.mountpoint, prefix, dir.name].filter(Boolean).join("/"),
                            label: `${prefix}/${dir.name}`,
                            kind: fl.shared ? "Compartida" : "Privada",
                            isVolume: false,
                            volumeName: volume.name || "",
                        });
                    }
                } catch {
                    // Si una carpeta no se puede listar, se omite.
                }
            }
            if (!cancelled) setSubfolderSources(items);
        })();
        return () => { cancelled = true; };
    }, [volumes, folders]);

    const backupSources = useMemo(() => {
        const opts = [];
        // Solo carpetas COMPARTIDAS de datos se ofrecen como origen a respaldar.
        // Las carpetas privadas (y el destino de respaldo) no deben aparecer:
        // el origen son los datos compartidos que se quieren proteger.
        for (const fl of folders) {
            if (!fl.path || !fl.shared) continue;
            const volume = volumes.find((v) => v.id === fl.volume_id);
            const label = fl.name || fl.path;
            const kind = "Compartida";
            opts.push({
                path: fl.path,
                label: label,
                kind: kind,
                isVolume: false,
                volumeName: volume?.name || "",
            });
        }
        // Subcarpetas dentro de carpetas compartidas (ej. Compartida/XML).
        for (const sub of subfolderSources) {
            if (sub.path !== backupAnchor) opts.push(sub);
        }
        // Dedup por path
        const seen = new Set();
        return opts.filter((o) => (seen.has(o.path) ? false : (seen.add(o.path), true)));
    }, [volumes, folders, backupAnchor, subfolderSources]);

    const allPartitions = useMemo(() => {
        const list = [];
        for (const disk of disks) {
            for (const part of disk.partitions || []) {
                list.push({ ...part, disk: disk.disk, model: disk.model, transport: disk.transport });
            }
        }
        return list;
    }, [disks]);

    const selectedPart = useMemo(
        () => allPartitions.find((p) => p.device === selectedDevice) || null,
        [allPartitions, selectedDevice]
    );

    const selectedUnit = useMemo(() => {
        if (!selectedPart?.volume_id) return null;
        return volumes.find((v) => v.id === selectedPart.volume_id) || null;
    }, [selectedPart, volumes]);

    const unitFolders = useMemo(
        () => (selectedUnit
            ? folders.filter((f) => f.volume_id === selectedUnit.id)
            : []),
        [selectedUnit, folders]
    );

    useEffect(() => {
        if (selectedDevice) return;
        const firstUnit = allPartitions.find((p) => p.volume_id);
        const next = firstUnit?.device
            || (allPartitions.length ? allPartitions[0].device : null);
        if (next) {
            const id = setTimeout(() => setSelectedDevice(next), 0);
            return () => clearTimeout(id);
        }
    }, [allPartitions, selectedDevice]);

    function partForm(disk) {
        return newPart[disk] || { sizeGb: "", role: "share" };
    }

    function setPartForm(disk, patch) {
        setNewPart((prev) => ({
            ...prev,
            [disk]: { ...partForm(disk), ...patch },
        }));
    }

    function setUpError(message) {
        setError(message || null);
    }

    function askConfirm(id, label, run) {
        setConfirmUp({ id, label, run });
    }

    function runConfirmed() {
        const run = confirmUp?.run;
        if (!run) return;
        setConfirmUp(null);
        run();
    }

    function isConfirming(id) {
        return confirmUp?.id === id;
    }

    async function doAction(fn, success) {
        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await fn();
            if (next) setStatus(next);
            if (success) setNotice(success);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleShare(part) {
        const device = part?.device;
        if (!device) return;
        const name = (names[device] || "").trim();
        if (!name) {
            setUpError("Escribe un nombre para la unidad.");
            return;
        }
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await shareVolume({ device, name });
            setStatus(next);
            setSelectedDevice(device);
            setOpenFolder(null);
            setNotice(`«${name}» activada como unidad.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleUnshare(part) {
        const volumeId = part?.volume_id;
        const device = part?.device;
        if (!volumeId || !device) return;
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await unshareVolume(volumeId);
            setStatus(next);
            setOpenFolder(null);
            setNotice(next?.message || `Unidad ${device} desactivada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleFormat(part) {
        const device = part?.device;
        if (!device) return;
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await formatShareDisk({
                device,
                confirm: "FORMATEAR",
                assign: false,
                whole_disk: false,
            });
            setStatus(next);
            setNotice(next?.message || `${device} formateado.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDeletePartition(part) {
        const device = part?.device;
        if (!device) return;

        if (part.volume_id || part.sharing) {
            setUpError("Desactiva la unidad antes de eliminar la partición.");
            return;
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await deleteSharePartition({
                device,
                confirm: "ELIMINAR",
            });
            setStatus(next);
            setSelectedDevice(null);
            setNotice(next?.message || `Partición ${device} eliminada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleCreatePartition(disk, opts = {}) {
        const device = disk?.device;
        if (!device) return;

        const form = partForm(device);
        const useRemaining = Boolean(opts.useRemaining);
        const role = opts.role || form.role || "share";
        let sizeGb = null;
        if (!useRemaining) {
            const raw = opts.sizeGb != null ? opts.sizeGb : form.sizeGb;
            sizeGb = Number(raw);
            if (!Number.isFinite(sizeGb) || sizeGb <= 0) {
                setUpError("Indica el tamaño en GB.");
                return;
            }
        }

        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await createSharePartition({
                disk: device,
                size_gb: useRemaining ? null : sizeGb,
                use_remaining: useRemaining,
                role,
            });
            setStatus(next);
            if (next?.created_device) {
                setSelectedDevice(next.created_device);
            }
            setNotice(next?.message || "Partición creada.");
            const nextDisk = (next?.disks || []).find((d) => d.device === device);
            const remainGb = freeGbOf(nextDisk?.free);
            setPartForm(device, {
                sizeGb: remainGb > 0 ? fmtGb(remainGb) : "",
            });
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleCreateFolder() {
        if (!selectedUnit?.id) return;
        const name = folderDraft.trim();
        if (!name) {
            setUpError("Escribe un nombre para la carpeta.");
            return;
        }
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            await createShareFolder({ name, volume_id: selectedUnit.id });
            setFolderDraft("");
            const next = await getShareStatus();
            setStatus(next);
            setNotice(`Carpeta «${name}» creada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDeleteFolder(folder) {
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            await deleteShareFolder(folder.id);
            setPermOpen((current) => (current === folder.id ? null : current));
            if (openFolder?.id === folder.id) setOpenFolder(null);
            const next = await getShareStatus();
            setStatus(next);
            setNotice(`Carpeta «${folder.name}» eliminada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleShareFolder(folder) {
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await setShareFolderShared(folder.id, true);
            setStatus((prev) => ({ ...prev, folders: prev.folders.map((f) => (
                f.id === next.id ? next : f
            )) }));
            setNotice(`Carpeta «${folder.name}» compartida en la red.`);
            setPermOpen(folder.id);
            setPermDraft((prev) => ({
                ...prev,
                [folder.id]: (folder.groups || []).map((g) => ({
                    group_id: g.group_id,
                    access_mode: g.access_mode,
                })),
            }));
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleUnshareFolder(folder) {
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await setShareFolderShared(folder.id, false);
            setStatus((prev) => ({ ...prev, folders: prev.folders.map((f) => (
                f.id === next.id ? next : f
            )) }));
            setPermOpen((current) => (current === folder.id ? null : current));
            setNotice(`Carpeta «${folder.name}» vuelve a ser privada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function openPerms(folder) {
        if (permOpen === folder.id) {
            setPermOpen(null);
            return;
        }
        setPermOpen(folder.id);
        setPermDraft((prev) => ({
            ...prev,
            [folder.id]: (folder.groups || []).map((g) => ({
                group_id: g.group_id,
                access_mode: g.access_mode,
            })),
        }));
    }

    function togglePermGroup(groupId) {
        setPermDraft((prev) => {
            const current = [...(prev[permOpen] || [])];
            const existing = current.find((g) => g.group_id === groupId);
            if (existing) {
                return {
                    ...prev,
                    [permOpen]: current.filter((g) => g.group_id !== groupId),
                };
            }
            return {
                ...prev,
                [permOpen]: [...current, { group_id: groupId, access_mode: "read" }],
            };
        });
    }

    function changePermMode(groupId, mode) {
        setPermDraft((prev) => ({
            ...prev,
            [permOpen]: (prev[permOpen] || []).map((g) =>
                g.group_id === groupId ? { ...g, access_mode: mode } : g
            ),
        }));
    }

    async function savePerms(folder) {
        const grants = permDraft[folder.id] || [];
        setBusy(true);
        setUpError(null);
        try {
            await setShareFolderGroups(folder.id, {
                groups: grants.map((g) => ({
                    group_id: g.group_id,
                    access_mode: g.access_mode,
                })),
            });
            const refreshed = await getShareStatus();
            setStatus(refreshed);
            setPermOpen(null);
            setNotice(
                grants.length === 0
                    ? `«${folder.name}» está compartida sin restricciones.`
                    : `Permisos de «${folder.name}» actualizados.`
            );
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function makePublic(folder) {
        setPermDraft((prev) => ({ ...prev, [folder.id]: [] }));
        setBusy(true);
        setUpError(null);
        try {
            await setShareFolderGroups(folder.id, { groups: [] });
            const refreshed = await getShareStatus();
            setStatus(refreshed);
            setPermOpen(null);
            setNotice(`«${folder.name}» está compartida sin restricciones.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function openBackupPolicy(folder) {
        const job = folder.backup && folder.backup.job_id;
        if (job) {
            setBackupAnchor({
                path: folder.path || null,
                folderId: folder.id,
                jobId: job,
            });
        } else {
            setBackupAnchor(null);
        }
        setView("respaldos");
    }

    function updateBackupDraft(folderId, patch) {
        setBackupDraft((prev) => ({
            ...prev,
            [folderId]: {
                ...(prev[folderId] || { mode: "times", times_per_day: 4, retention: 7 }),
                ...patch,
            },
        }));
    }

    async function handleSaveBackupPolicy(event) {
        event.preventDefault();
        const folder = backupOpen;
        if (!folder) return;
        const draft = backupDraft[folder.id] || { mode: "times", times_per_day: 4, retention: 7 };
        setBusy(true);
        setUpError(null);
        setNotice(null);
        try {
            const next = await setShareFolderBackupPolicy(folder.id, {
                mode: draft.mode,
                times_per_day: Number(draft.times_per_day) || 1,
                retention: Number(draft.retention) || 7,
            });
            setStatus((prev) => ({ ...prev, folders: prev.folders.map((f) => (
                f.id === next.id ? next : f
            )) }));
            setBackupOpen(null);
            setNotice(
                draft.mode === "off"
                    ? `Respaldo programado de «${folder.name}» cancelado.`
                    : `Respaldo de «${folder.name}» programado (versionado).`
            );
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function folderAccessLabel(folder) {
        if (!folder.shared) {
            return { text: "Privada (solo web)", cls: "private" };
        }
        const grants = folder.groups || [];
        if (grants.length === 0) {
            return { text: "Compartida", cls: "public" };
        }
        const write = grants.some((g) => g.access_mode === "write");
        return {
            text: `Compartida · ${grants.length} grupo${grants.length === 1 ? "" : "s"}`,
            cls: write ? "private" : "readonly",
        };
    }

    function partitionState(part) {
        if (part.volume_id) return { text: "Activa", cls: "green" };
        if (part.fstype) return { text: "Con formato", cls: "" };
        return { text: "Sin formato", cls: "readonly" };
    }

    function renderActionButton(id, actionLabel, onAction, options = {}) {
        const { danger = false, primary = false, disabled = false, title } = options;
        if (isConfirming(id)) {
            return (
                <span className="sh-confirm-inline">
                    <span>{confirmUp.label}</span>
                    <button
                        type="button"
                        className="sh-btn sh-btn-sm danger"
                        disabled={busy}
                        onClick={runConfirmed}
                    >
                        Confirmar
                    </button>
                    <button
                        type="button"
                        className="sh-btn sh-btn-sm"
                        disabled={busy}
                        onClick={() => setConfirmUp(null)}
                    >
                        Cancelar
                    </button>
                </span>
            );
        }
        return (
            <button
                type="button"
                className={["sh-btn", "sh-btn-sm", danger ? "danger" : "", primary ? "primary" : ""]
                    .filter(Boolean).join(" ")}
                disabled={disabled || busy}
                title={title}
                onClick={() => {
                    if (options.confirmLabel) {
                        askConfirm(id, options.confirmLabel, onAction);
                    } else {
                        onAction();
                    }
                }}
            >
                {actionLabel}
            </button>
        );
    }

    if (loading && !status) {
        return <div className="sh-page"><p className="sh-loading">Cargando…</p></div>;
    }

    const sambaOk = Boolean(status?.samba?.installed);
    const integrity = status?.integrity || {};
    const integrityLocked = Boolean(integrity.locked);
    const integrityPaused = Boolean(integrity.paused);
    const diskHealth = status?.disk_health || null;
    const diskHealthProblems = (diskHealth?.disks || []).filter(
        (d) => d.level === "warning" || d.level === "critical"
    );

    return (
        <div className="sh-page">
            <header className="sh-hero">
                <p className="sh-eyebrow">Almacenamiento</p>
                <h1>Unidades de disco</h1>
                <p className="sh-lede">
                    Administrá discos y particiones, creá carpetas compartidas o
                    privadas y programá respaldos automáticos protegidos.
                </p>
            </header>

            {!sambaOk && (
                <div className="sh-banner warn">
                    Falta Samba. En el servidor: <code>sudo apt-get install -y samba</code>
                </div>
            )}

            {diskHealthProblems.length > 0 && (
                <div className={`sh-banner ${diskHealth?.worst === "critical" ? "error" : "warn"}`}>
                    <strong>Salud del disco:</strong>
                    <ul className="sh-health-list">
                        {diskHealthProblems.map((d) => (
                            <li key={d.device}>
                                <code>{d.device}</code>
                                {d.model ? ` (${d.model})` : ""} — {d.message}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {integrityLocked && (
                <div className="sh-banner error sh-integrity-banner">
                    <div>
                        <strong>Escritura bloqueada por protección antiransomware.</strong>
                        <p>
                            {integrity.detail
                                || "Se detectaron cambios masivos de archivos."}
                        </p>
                    </div>
                    {isAdmin && (
                        <button
                            type="button"
                            className="sh-btn danger"
                            disabled={busy || integrityPaused}
                            onClick={() => {
                                if (!confirm(
                                    "¿Reactivar escritura? Revisa antes que no haya ransomware activo."
                                )) return;
                                doAction(
                                    () => unlockShareIntegrity().then(setStatus),
                                    "Escritura reactivada."
                                );
                            }}
                        >
                            Reactivar escritura
                        </button>
                    )}
                </div>
            )}

            {error && <div className="sh-banner error">{error}</div>}
            {notice && <div className="sh-banner ok sh-notice">{notice}</div>}


            <nav className="sh-view-tabs" role="tablist" aria-label="Secciones de almacenamiento">
                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "unidades"}
                    className={view === "unidades" ? "active" : ""}
                    onClick={() => setView("unidades")}
                >
                    Unidades
                </button>
                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "carpetas"}
                    className={view === "carpetas" ? "active" : ""}
                    onClick={() => setView("carpetas")}
                >
                    Carpetas
                </button>
                <button
                    type="button"
                    role="tab"
                    aria-selected={view === "respaldos"}
                    className={view === "respaldos" ? "active" : ""}
                    onClick={() => {
                        setBackupAnchor(null);
                        setView("respaldos");
                    }}
                >
                    Respaldos
                </button>
            </nav>

            {view === "unidades" && (
                <section className="sh-split sh-units-view">
                    <aside className="sh-pane sh-side">
                        <div className="sh-side-window">
                            <h2>Discos y particiones</h2>
                    {disks.length === 0 ? (
                        <p className="sh-empty">Conecta un disco USB o un disco adicional.</p>
                    ) : (
                        <div className="sh-side-list">
                            {disks.map((disk) => (
                                <div key={disk.device} className="sh-side-disk">
                                    <div className="sh-side-disk-head">
                                        <span className="sh-badge">{disk.bus || "DISCO"}</span>
                                        <strong>{disk.device}</strong>
                                        {disk.model ? (
                                            <span className="sh-muted sh-side-model">{disk.model}</span>
                                        ) : null}
                                        <span className="sh-muted">
                                            {formatSize(disk.size)}
                                            {disk.free > 0 ? ` · libre ${formatSize(disk.free)}` : ""}
                                        </span>
                                    </div>

                                    <ul className="sh-part-list">
                                        {(disk.partitions || []).map((part) => {
                                            const state = partitionState(part);
                                            const active = selectedDevice === part.device;
                                            const nameValue = names[part.device] ?? "";
                                            return (
                                                <li
                                                    key={part.device}
                                                    className={[
                                                        "sh-part-row",
                                                        part.volume_id ? "sharing" : "",
                                                        active ? "selected" : "",
                                                    ].filter(Boolean).join(" ")}
                                                    onClick={() => {
                                                        setSelectedDevice(part.device);
                                                        setOpenFolder(null);
                                                    }}
                                                >
                                                    <div className="sh-part-main">
                                                        <div className="sh-part-title">
                                                            <strong>{part.device}</strong>
                                                            <span className="sh-part-meta">
                                                                {formatSize(part.size)}
                                                            </span>
                                                            <span className="sh-part-meta">
                                                                {part.fstype || "sin formato"}
                                                            </span>
                                                        </div>
                                                        {!part.volume_id && part.fstype && (
                                                            <label
                                                                className="sh-name-field"
                                                                onClick={(e) => e.stopPropagation()}
                                                            >
                                                                <input
                                                                    type="text"
                                                                    value={nameValue}
                                                                    disabled={!isAdmin || busy}
                                                                    placeholder="Nombre de la unidad"
                                                                    maxLength={64}
                                                                    onChange={(e) =>
                                                                        setNames((prev) => ({
                                                                            ...prev,
                                                                            [part.device]: e.target.value,
                                                                        }))
                                                                    }
                                                                />
                                                            </label>
                                                        )}
                                                    </div>
                                                    <span className={`sh-badge ${state.cls}`}>
                                                        {state.text}
                                                    </span>
                                                    {isAdmin && (
                                                        <div
                                                            className="sh-side-actions"
                                                            onClick={(e) => e.stopPropagation()}
                                                        >
                                                            {part.volume_id ? (
                                                                <>
                                                                    {renderActionButton(
                                                                        `unshare:${part.device}`,
                                                                        "Desactivar",
                                                                        () => handleUnshare(part),
                                                                        { danger: true, confirmLabel: "¿Desactivar la unidad y sus carpetas?" }
                                                                    )}
                                                                </>
                                                            ) : !part.fstype ? (
                                                                <>
                                                                    {renderActionButton(
                                                                        `fmt:${part.device}`,
                                                                        "Formatear",
                                                                        () => handleFormat(part),
                                                                        { confirmLabel: "¿Formatear? Se borrará todo el contenido." }
                                                                    )}
                                                                    {part.deletable && renderActionButton(
                                                                        `del:${part.device}`,
                                                                        "Eliminar",
                                                                        () => handleDeletePartition(part),
                                                                        { danger: true, confirmLabel: "¿Eliminar la partición?" }
                                                                    )}
                                                                </>
                                                            ) : (
                                                                <>
                                                                    {renderActionButton(
                                                                        `share:${part.device}`,
                                                                        "Activar",
                                                                        () => handleShare(part),
                                                                        { primary: true, disabled: !nameValue.trim() }
                                                                    )}
                                                                    {renderActionButton(
                                                                        `del:${part.device}`,
                                                                        "Eliminar",
                                                                        () => handleDeletePartition(part),
                                                                        { danger: true, confirmLabel: "¿Eliminar la partición?" }
                                                                    )}
                                                                </>
                                                            )}
                                                        </div>
                                                    )}
                                                </li>
                                            );
                                        })}
                                    </ul>

                                    {isAdmin && disk.can_create_partition && (
                                        <div className="sh-create-part">
                                            <form
                                                className="sh-create-form"
                                                onSubmit={(e) => {
                                                    e.preventDefault();
                                                    handleCreatePartition(disk);
                                                }}
                                            >
                                                <input
                                                    type="number"
                                                    min="0.1"
                                                    step="any"
                                                    value={partForm(disk.device).sizeGb}
                                                    disabled={busy}
                                                    placeholder={`TB libre ${fmtGb(freeGbOf(disk.free))}`}
                                                    title={`Tamaño en GB (máx ${fmtGb(freeGbOf(disk.free))})`}
                                                    onChange={(e) =>
                                                        setPartForm(disk.device, { sizeGb: e.target.value })
                                                    }
                                                />
                                                <button
                                                    type="submit"
                                                    className="sh-btn primary"
                                                    disabled={busy}
                                                >
                                                    Nueva partición
                                                </button>
                                                {renderActionButton(
                                                    `all:${disk.device}`,
                                                    "Todo el libre",
                                                    () => handleCreatePartition(disk, { useRemaining: true }),
                                                    { disabled: busy }
                                                )}
                                            </form>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}


                        </div>

                        <NetworkUnitsCard />

                    </aside>

                    <main className="sh-pane sh-main">
                        {selectedPart ? (
                            <div className="sh-unit-detail">
                                <p className="sh-eyebrow">Partición seleccionada</p>
                                <h3>
                                    {selectedPart.volume_id
                                        ? selectedUnit?.name || selectedPart.device
                                        : selectedPart.device}
                                </h3>
                                <p className="sh-part-hint">
                                    {formatSize(selectedPart.size)}
                                    {" · "}
                                    {selectedPart.fstype || "sin formato"}
                                </p>
                                {selectedUnit ? (
                                    <div className="sh-unit-detail-actions">
                                        <button
                                            type="button"
                                            className="sh-btn primary"
                                            onClick={() => setView("carpetas")}
                                        >
                                            Ver carpetas de «{selectedUnit.name}» →
                                        </button>
                                        <p className="sh-part-hint">
                                            {unitFolders.length} carpeta(s) · montado en{" "}
                                            <code className="sh-inline-code">{selectedUnit.mountpoint}</code>
                                        </p>
                                    </div>
                                ) : (
                                    <div className="sh-unit-detail-actions">
                                        <button
                                            type="button"
                                            className="sh-btn primary"
                                            disabled={busy || !(names[selectedPart.device] || "").trim()}
                                            onClick={() => handleShare(selectedPart)}
                                        >
                                            Activar como unidad de red
                                        </button>
                                        {!selectedPart.fstype && renderActionButton(
                                            `fmt:${selectedPart.device}`,
                                            "Formatear",
                                            () => handleFormat(selectedPart),
                                            { confirmLabel: "¿Formatear? Se borrará todo el contenido." }
                                        )}
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="sh-main-placeholder">
                                <p className="sh-empty">
                                    Seleccioná un disco o partición de la izquierda.
                                </p>
                            </div>
                        )}
                    </main>
                </section>
            )}

            {view === "carpetas" && (
                <section className="sh-split sh-split-3 sh-folders-view">
                    <aside className="sh-pane sh-side">
                        {selectedUnit ? (
                            <div className="sh-side-window">
                                <h2>
                                    Carpetas
                                    <span className="sh-part-meta"> · {selectedUnit.name}</span>
                                </h2>
                            {isAdmin && (
                                <form
                                    className="sh-folder-create"
                                    onSubmit={(e) => {
                                        e.preventDefault();
                                        handleCreateFolder();
                                    }}
                                >
                                    <input
                                        type="text"
                                        value={folderDraft}
                                        disabled={busy}
                                        placeholder="Nueva carpeta"
                                        maxLength={64}
                                        onChange={(e) => setFolderDraft(e.target.value)}
                                    />
                                    <button
                                        type="submit"
                                        className="sh-btn primary"
                                        disabled={busy || !folderDraft.trim()}
                                    >
                                        Crear
                                    </button>
                                </form>
                            )}

                            {unitFolders.length === 0 ? (
                                <p className="sh-empty">
                                    {isAdmin
                                        ? "Crea una carpeta para empezar. Las carpetas son privadas hasta que las compartís."
                                        : "No hay carpetas."}
                                </p>
                            ) : (
                                <ul className="sh-folder-list">
                                    {unitFolders.map((folder) => {
                                        const access = folderAccessLabel(folder);
                                        const draft = permDraft[folder.id];
                                        const isOpen = permOpen === folder.id;
                                        const isSelected = openFolder?.id === folder.id;
                                        const backup = folder.backup || {};
                                        return (
                                            <li
                                                key={folder.id}
                                                className={[
                                                    "sh-folder-card",
                                                    isSelected ? "selected" : "",
                                                ].filter(Boolean).join(" ")}
                                            >
                                                <div
                                                    className="sh-folder-row"
                                                    onClick={() => {
                                                        setOpenFolder(folder);
                                                        setPermOpen(null);
                                                    }}
                                                >
                                                    <span className="sh-folder-icon">
                                                        {folder.shared ? "🌐" : "🔒"}
                                                    </span>
                                                    <div className="sh-folder-info">
                                                        <strong>{folder.name}</strong>
                                                        {folder.unc_path && (
                                                            <code className="sh-inline-code">{folder.unc_path}</code>
                                                        )}
                                                        {backup.enabled && (
                                                            <span className="sh-bk-chip">
                                                                {backup.mode === "on_change"
                                                                    ? "respaldo al cambiar archivos"
                                                                    : `respaldo ${backup.times_per_day}/día`}
                                                            </span>
                                                        )}
                                                    </div>
                                                    <span className={`sh-badge ${access.cls}`}>{access.text}</span>
                                                    {isAdmin && (
                                                        <span
                                                            className="sh-folder-actions"
                                                            onClick={(e) => e.stopPropagation()}
                                                        >
                                                            <button
                                                                type="button"
                                                                className="sh-btn sh-btn-sm primary"
                                                                disabled={busy}
                                                                onClick={() => {
                                                                    setOpenFolder(folder);
                                                                    setPermOpen(null);
                                                                }}
                                                            >
                                                                Abrir
                                                            </button>
                                                            {!folder.shared ? (
                                                                <>
                                                                    <button
                                                                        type="button"
                                                                        className="sh-btn sh-btn-sm"
                                                                        disabled={busy}
                                                                        onClick={() => handleShareFolder(folder)}
                                                                    >
                                                                        Compartir
                                                                    </button>
                                                                    <button
                                                                        type="button"
                                                                        className={[
                                                                            "sh-btn",
                                                                            "sh-btn-sm",
                                                                            backup.enabled ? "active" : "",
                                                                        ].filter(Boolean).join(" ")}
                                                                        disabled={busy}
                                                                        onClick={() => openBackupPolicy(folder)}
                                                                        title={backup.enabled ? "Ver respaldos programados de esta carpeta" : "Programar respaldos versionados"}
                                                                    >
                                                                        {backup.enabled ? "Respaldos ✓" : "Programar respaldos"}
                                                                    </button>
                                                                </>
                                                            ) : (
                                                                <>
                                                                    <button
                                                                        type="button"
                                                                        className="sh-btn sh-btn-sm"
                                                                        disabled={busy}
                                                                        onClick={() => openPerms(folder)}
                                                                    >
                                                                        {isOpen ? "Cerrar" : "Permisos"}
                                                                    </button>
                                                                    {renderActionButton(
                                                                        `unshare-folder:${folder.id}`,
                                                                        "Dejar de compartir",
                                                                        () => handleUnshareFolder(folder),
                                                                        { danger: true, confirmLabel: "¿Hacer la carpeta privada de nuevo (solo web)?" }
                                                                    )}
                                                                </>
                                                            )}
                                                            {renderActionButton(
                                                                `del-folder:${folder.id}`,
                                                                "Eliminar",
                                                                () => handleDeleteFolder(folder),
                                                                { danger: true, confirmLabel: "¿Eliminar la carpeta?" }
                                                            )}
                                                        </span>
                                                    )}
                                                </div>

                                                {isOpen && folder.shared && isAdmin && (
                                                    <div className="sh-perm-panel">
                                                        <p className="sh-perm-note">
                                                            Sin grupos marcados, cualquier equipo de la red accede.
                                                        </p>
                                                        {groups.length === 0 ? (
                                                            <p className="sh-part-hint">No hay grupos de dispositivos.</p>
                                                        ) : (
                                                            <ul className="sh-perm-list">
                                                                {groups.map((group) => {
                                                                    const grant = (draft || []).find(
                                                                        (g) => g.group_id === group.id
                                                                    );
                                                                    return (
                                                                        <li key={group.id} className="sh-perm-row">
                                                                            <label className="sh-perm-check">
                                                                                <input
                                                                                    type="checkbox"
                                                                                    checked={Boolean(grant)}
                                                                                    disabled={busy}
                                                                                    onChange={() => togglePermGroup(group.id)}
                                                                                />
                                                                                <span className="sh-perm-name">
                                                                                    {group.name}
                                                                                    {group.is_default
                                                                                        ? <em> · por defecto</em>
                                                                                        : null}
                                                                                    <small>
                                                                                        {" "}
                                                                                        ({group.devices} equipos
                                                                                        {group.is_default ? "" : ` · ${group.rules} reglas`})
                                                                                    </small>
                                                                                </span>
                                                                            </label>
                                                                            {grant && (
                                                                                <span className="sh-mode">
                                                                                    <button
                                                                                        type="button"
                                                                                        className={grant.access_mode === "read" ? "active" : ""}
                                                                                        disabled={busy}
                                                                                        onClick={() =>
                                                                                            changePermMode(group.id, "read")
                                                                                        }
                                                                                    >
                                                                                        Lectura
                                                                                    </button>
                                                                                    <button
                                                                                        type="button"
                                                                                        className={grant.access_mode === "write" ? "active" : ""}
                                                                                        disabled={busy}
                                                                                        onClick={() =>
                                                                                            changePermMode(group.id, "write")
                                                                                        }
                                                                                    >
                                                                                        Escritura
                                                                                    </button>
                                                                                </span>
                                                                            )}
                                                                        </li>
                                                                    );
                                                                })}
                                                            </ul>
                                                        )}
                                                        {(draft || []).length === 0 && (
                                                            <p className="sh-perm-lock-hint">
                                                                Sin restricciones · todos los equipos tienen
                                                                Lectura/Escritura.
                                                            </p>
                                                        )}
                                                        <div className="sh-perm-actions">
                                                            <button
                                                                type="button"
                                                                className="sh-btn"
                                                                disabled={busy}
                                                                onClick={() => makePublic(folder)}
                                                            >
                                                                Sin restricciones
                                                            </button>
                                                            <button
                                                                type="button"
                                                                className="sh-btn primary"
                                                                disabled={busy}
                                                                onClick={() => savePerms(folder)}
                                                            >
                                                                Guardar
                                                            </button>
                                                        </div>
                                                    </div>
                                                )}
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </div>


                        ) : (
                            <div className="sh-main-placeholder">
                                <p className="sh-empty">
                                    Séleccioná una unidad activa en «Unidades» para ver sus carpetas.
                                </p>
                            </div>
                        )}
                    </aside>

                <main className="sh-pane sh-main">
                    {openFolder ? (
                        <FolderExplorer
                            folder={openFolder}
                            onClose={() => setOpenFolder(null)}
                        />
                    ) : (
                        <div className="sh-main-placeholder">
                            <p className="sh-empty">
                                {selectedUnit
                                    ? "Seleccioná una carpeta a la izquierda para ver sus archivos y carpetas."
                                    : "Seleccioná una unidad arriba para ver sus carpetas."}
                            </p>
                        </div>
                    )}
                </main>


                </section>
            )}

            {view === "respaldos" && (
                <section className="sh-respaldo-view">
                    <h2>Respaldos</h2>

                    {isAdmin && (
                        <div className="sh-integrity-section">
                            {!integrityPaused && !integrityLocked && (
                            <div className="sh-pause-bar">
                                <span>Carga masiva (pausa antiransomware):</span>
                                {[1, 2, 4, 8].map((h) => (
                                    <button
                                        key={h}
                                        type="button"
                                        className="sh-btn"
                                        disabled={busy}
                                        onClick={() => {
                                            if (!confirm(
                                                `¿Pausar la protección antiransomware por ${h} hora(s)?`
                                            )) return;
                                            doAction(
                                                () => pauseShareIntegrity(h).then(setStatus),
                                                `Protección pausada ${h} h.`
                                            );
                                        }}
                                    >
                                        Pausar {h} h
                                    </button>
                                ))}
                            </div>
                        )}
                        {integrityPaused && !integrityLocked && (
                            <div className="sh-pause-bar">
                                <span>Protección antiransomware pausada.</span>
                                <button
                                    type="button"
                                    className="sh-btn"
                                    disabled={busy}
                                    onClick={() => doAction(
                                        () => resumeShareIntegrity().then(setStatus),
                                        "Protección reactivada."
                                    )}
                                >
                                    Reactivar
                                </button>
                            </div>
                        )}


                        </div>
                    )}

                    <ShareBackupsPanel
                            sources={backupSources}
                            anchorSource={backupAnchor}
                        />

                        {isAdmin && (
                            <div className="sh-network-scan-section" style={{marginTop: 24, borderTop: "1px solid rgba(255,255,255,0.1)", paddingTop: 16}}>
                                <NetworkShareScanner
                                    onSelect={(share) => {
                                        setNetworkShare(share);
                                        setBackupAnchor(share.path);
                                        setView("respaldos");
                                    }}
                                />
                            </div>
                        )}


                </section>
            )}

            {backupOpen && (
                <div className="sh-confirm-overlay" onClick={() => setBackupOpen(null)}>
                    <form
                        className="sh-confirm sh-backup-dialog"
                        onClick={(e) => e.stopPropagation()}
                        onSubmit={handleSaveBackupPolicy}
                    >
                        <h4>Programar respaldos de «{backupOpen.name}»</h4>
                        <p className="sh-part-hint">
                            Copias cifradas y <strong>versionadas</strong> (restic): vas a poder
                            volver a cualquier versión anterior de cada archivo de esta carpeta.
                        </p>

                        <div className="sh-bk-mode">
                            {[
                                { v: "times", t: "N veces al día", d: "Copia automática varias veces por día." },
                                { v: "on_change", t: "Al cambiar archivos", d: "Respaldá cada vez que se modifique un archivo." },
                                { v: "off", t: "No programar", d: "Sin respaldos automáticos." },
                            ].map((opt) => (
                                <label key={opt.v} className="sh-mode-choice">
                                    <input
                                        type="radio"
                                        name={`sh-bk-${backupOpen.id}`}
                                        checked={(backupDraft[backupOpen.id]?.mode || "times") === opt.v}
                                        disabled={busy}
                                        onChange={() => updateBackupDraft(backupOpen.id, { mode: opt.v })}
                                    />
                                    <span className="sh-mode-text">
                                        <strong>{opt.t}</strong>
                                        <small>{opt.d}</small>
                                    </span>
                                </label>
                            ))}
                        </div>

                        {(backupDraft[backupOpen.id]?.mode || "times") === "times" && (
                            <label className="sh-bk-row">
                                <span>Copias por día</span>
                                <input
                                    type="number"
                                    min="1"
                                    max="24"
                                    value={backupDraft[backupOpen.id]?.times_per_day ?? 4}
                                    disabled={busy}
                                    onChange={(e) =>
                                        updateBackupDraft(backupOpen.id, { times_per_day: e.target.value })
                                    }
                                />
                                <span className="sh-muted">
                                    cada ~{24 / (Number(backupDraft[backupOpen.id]?.times_per_day) || 4)} h
                                </span>
                            </label>
                        )}

                        <label className="sh-bk-row">
                            <span>Conservar versiones</span>
                            <input
                                type="number"
                                min="1"
                                max="365"
                                value={backupDraft[backupOpen.id]?.retention ?? 7}
                                disabled={busy}
                                onChange={(e) =>
                                    updateBackupDraft(backupOpen.id, { retention: e.target.value })
                                }
                            />
                        </label>

                        <div className="sh-perm-actions">
                            <button
                                type="button"
                                className="sh-btn"
                                disabled={busy}
                                onClick={() => setBackupOpen(null)}
                            >
                                Cancelar
                            </button>
                            <button
                                type="submit"
                                className="sh-btn primary"
                                disabled={busy}
                            >
                                Guardar
                            </button>
                        </div>
                    </form>
                </div>
            )}


        </div>
    );

}


export default Shares;
