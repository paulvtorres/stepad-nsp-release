"""
Gestión de unidades de red (mounts SMB persistentes).
Cada unidad de red se monta como /mnt/stepad-network/{letter}
y aparece como carpeta local para respaldos.
"""
import json
import os
import subprocess
from pathlib import Path
from backend.shared.logging.logger import logger

CONFIG_FILE = Path("/home/paulan/stepad-nsp/backend/shared/config/network_units.json")
MOUNT_BASE = Path("/mnt/stepad-network")


class NetworkUnitService:

    def __init__(self):
        MOUNT_BASE.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict:
        try:
            return json.loads(CONFIG_FILE.read_text("utf-8"))
        except (FileNotFoundError, json.JSONDecodeError):
            return {"units": []}

    def _save(self, data: dict) -> None:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def list_units(self) -> list[dict]:
        data = self._load()
        units = []
        for unit in data.get("units", []):
            mount_point = MOUNT_BASE / unit["letter"]
            mounted = mount_point.is_mount()
            units.append({
                **unit,
                "mount_point": str(mount_point),
                "mounted": mounted,
                "available": mounted and mount_point.is_dir(),
            })
        return units

    def create_unit(self, name: str, host: str, share: str, letter: str, user: str = "", password: str = "") -> dict:
        data = self._load()
        # Validar letra única
        if any(u["letter"] == letter for u in data.get("units", [])):
            raise ValueError(f"La letra {letter} ya está en uso.")
        unit = {
            "id": len(data.get("units", [])) + 1,
            "name": name,
            "host": host,
            "share": share,
            "letter": letter.upper(),
            "user": user,
            "password": password,
            "enabled": True,
        }
        data.setdefault("units", []).append(unit)
        self._save(data)
        # Montar inmediatamente
        self._mount_unit(unit)
        return unit

    def delete_unit(self, unit_id: int) -> None:
        data = self._load()
        unit = next((u for u in data.get("units", []) if u["id"] == unit_id), None)
        if unit:
            self._unmount_unit(unit)
            data["units"] = [u for u in data["units"] if u["id"] != unit_id]
            self._save(data)

    def toggle_unit(self, unit_id: int, enabled: bool) -> dict:
        data = self._load()
        unit = next((u for u in data.get("units", []) if u["id"] == unit_id), None)
        if not unit:
            raise ValueError("Unidad no encontrada.")
        unit["enabled"] = enabled
        self._save(data)
        if enabled:
            self._mount_unit(unit)
        else:
            self._unmount_unit(unit)
        return unit

    def _mount_unit(self, unit: dict) -> bool:
        mount_point = MOUNT_BASE / unit["letter"]
        mount_point.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(mount_point, 0o755)
        except Exception:
            pass
        user = unit.get("user", "")
        password = unit.get("password", "")
        opts = f"uid=0,gid=0,iocharset=utf8,vers=3.0"
        if user:
            opts = f"username={user},password={password},{opts}"
        else:
            opts = f"guest,{opts}"
        cmd = ["mount", "-t", "cifs", f"//{unit['host']}/{unit['share']}", str(mount_point), "-o", opts]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            logger.info("Mounted //%s/%s at %s", unit["host"], unit["share"], mount_point)
            return True
        else:
            logger.error("Failed to mount //%s/%s: %s", unit["host"], unit["share"], result.stderr)
            return False

    def _unmount_unit(self, unit: dict) -> None:
        mount_point = MOUNT_BASE / unit["letter"]
        if mount_point.exists():
            subprocess.run(["umount", str(mount_point)], capture_output=True, timeout=10)

    def mount_all(self) -> None:
        """Monta todas las unidades habilitadas (al iniciar el servicio)."""
        data = self._load()
        for unit in data.get("units", []):
            if unit.get("enabled", True):
                self._mount_unit(unit)
