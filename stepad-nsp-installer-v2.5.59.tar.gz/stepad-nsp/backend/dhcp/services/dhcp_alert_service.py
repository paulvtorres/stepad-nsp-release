"""
Alertas por correo de problemas DHCP (caída, diagnóstico fallido,
pocas IPs libres) con programación diaria opcional.
"""

from __future__ import annotations

import threading
import time
from datetime import datetime

from backend.core.database.session import SessionLocal
from backend.dhcp.services.dhcp_health_service import DhcpHealthService
from backend.dhcp.services.dhcp_pool_stats_service import DhcpPoolStatsService
from backend.dhcp.services.dhcp_reservation_cleanup_service import (
    format_run_time,
    parse_run_time,
)
from backend.shared.config.config_service import ConfigService
from backend.shared.logging.logger import logger


DEFAULT_ALERT_HOUR = 8
DEFAULT_ALERT_MINUTE = 0
DEFAULT_POOL_LOW_THRESHOLD = 10
DEFAULT_CHECK_INTERVAL_MINUTES = 15


class DhcpAlertService:

    def __init__(self):

        self.config_service = ConfigService()
        self.health_service = DhcpHealthService()
        self.pool_stats_service = DhcpPoolStatsService()
        self._stop = False
        self._scheduler_thread = None
        self._lock = threading.Lock()

    def get_settings(self) -> dict:

        dhcp = self.config_service.get_dhcp_config() or {}

        hour = int(
            dhcp.get("alert_hour", DEFAULT_ALERT_HOUR)
            if dhcp.get("alert_hour") is not None
            else DEFAULT_ALERT_HOUR
        )
        minute = int(
            dhcp.get("alert_minute", DEFAULT_ALERT_MINUTE)
            if dhcp.get("alert_minute") is not None
            else DEFAULT_ALERT_MINUTE
        )
        hour = max(0, min(23, hour))
        minute = max(0, min(59, minute))

        threshold = int(
            dhcp.get("pool_low_threshold", DEFAULT_POOL_LOW_THRESHOLD)
            or DEFAULT_POOL_LOW_THRESHOLD
        )
        threshold = max(1, min(500, threshold))

        return {
            "service_alert_enabled": bool(
                dhcp.get("service_alert_email_enabled", True)
            ),
            "scheduled_check_enabled": bool(
                dhcp.get("alert_schedule_enabled", False)
            ),
            "run_hour": hour,
            "run_minute": minute,
            "run_time": format_run_time(hour, minute),
            "check_interval_minutes": int(
                dhcp.get("check_interval_minutes", DEFAULT_CHECK_INTERVAL_MINUTES)
                or DEFAULT_CHECK_INTERVAL_MINUTES
            ),
            "pool_low_alert_enabled": bool(
                dhcp.get("pool_low_alert_enabled", False)
            ),
            "pool_low_threshold": threshold,
            "last_run_at": dhcp.get("alert_last_run_at"),
            "last_result": dhcp.get("alert_last_result"),
        }

    def update_settings(
        self,
        *,
        service_alert_enabled: bool | None = None,
        scheduled_check_enabled: bool | None = None,
        run_time: str | None = None,
        run_hour: int | None = None,
        run_minute: int | None = None,
        pool_low_alert_enabled: bool | None = None,
        pool_low_threshold: int | None = None,
    ) -> dict:

        dhcp = dict(self.config_service.get_dhcp_config() or {})

        if service_alert_enabled is not None:
            dhcp["service_alert_email_enabled"] = bool(
                service_alert_enabled
            )

        if scheduled_check_enabled is not None:
            dhcp["alert_schedule_enabled"] = bool(
                scheduled_check_enabled
            )

        if run_time is not None:
            hour, minute = parse_run_time(run_time)
            dhcp["alert_hour"] = hour
            dhcp["alert_minute"] = minute
        else:
            if run_hour is not None:
                hour = int(run_hour)
                if hour < 0 or hour > 23:
                    raise ValueError("La hora debe estar entre 0 y 23.")
                dhcp["alert_hour"] = hour
            if run_minute is not None:
                minute = int(run_minute)
                if minute < 0 or minute > 59:
                    raise ValueError(
                        "Los minutos deben estar entre 0 y 59."
                    )
                dhcp["alert_minute"] = minute

        if pool_low_alert_enabled is not None:
            dhcp["pool_low_alert_enabled"] = bool(pool_low_alert_enabled)

        if pool_low_threshold is not None:
            value = int(pool_low_threshold)
            if value < 1 or value > 500:
                raise ValueError(
                    "El umbral de IPs libres debe estar entre 1 y 500."
                )
            dhcp["pool_low_threshold"] = value

        self.config_service.update_section("dhcp", dhcp)

        return self.get_settings()

    def service_email_allowed(self) -> bool:

        return bool(self.get_settings().get("service_alert_enabled", True))

    def _parse_last_run(self, value) -> datetime | None:

        if not value:
            return None

        if isinstance(value, datetime):
            return value

        text = str(value).strip().replace("Z", "")

        try:
            return datetime.fromisoformat(text)
        except ValueError:
            return None

    def is_due(
        self,
        settings: dict | None = None,
        now: datetime | None = None,
    ) -> bool:

        settings = settings or self.get_settings()
        now = now or datetime.now()

        if not settings.get("scheduled_check_enabled"):
            return False

        # Modo intervalo: cada N minutos (nuevo)
        interval = int(settings.get("check_interval_minutes", DEFAULT_CHECK_INTERVAL_MINUTES))
        if interval > 0:
            last = self._parse_last_run(settings.get("last_run_at"))
            if last is None:
                return True
            elapsed_minutes = (now - last).total_seconds() / 60
            return elapsed_minutes >= interval

        # Modo horario: una vez al día a la hora configurada
        hour = int(settings.get("run_hour", DEFAULT_ALERT_HOUR))
        minute = int(settings.get("run_minute", DEFAULT_ALERT_MINUTE))

        if now.hour < hour or (
            now.hour == hour and now.minute < minute
        ):
            return False

        last = self._parse_last_run(settings.get("last_run_at"))

        if last is None:
            return True

        return last.date() < now.date()

    def collect_problems(self) -> list[dict]:

        problems = []

        snap = self.health_service.inspect()

        if not snap.get("running"):
            problems.append(
                {
                    "code": "down",
                    "severity": "critical",
                    "title": "DHCP caído",
                    "message": (
                        "El servicio DHCP (dnsmasq) no está en ejecución. "
                        "Los equipos no pueden recibir IP."
                    ),
                }
            )
        elif snap.get("stuck"):
            problems.append(
                {
                    "code": "stuck",
                    "severity": "critical",
                    "title": "DHCP colgado",
                    "message": (
                        f"dnsmasq escucha pero no procesa peticiones "
                        f"(cola UDP 67 = {snap.get('recv_q')} bytes)."
                    ),
                }
            )

        try:

            from backend.dhcp.services.dhcp_diagnosis_service import (
                DhcpDiagnosisService,
            )

            diagnosis = DhcpDiagnosisService().diagnose()
            checks = getattr(diagnosis, "checks", None) or []

            for check in checks:
                status = (
                    check.get("status")
                    if isinstance(check, dict)
                    else getattr(check, "status", None)
                )
                name = (
                    check.get("name")
                    if isinstance(check, dict)
                    else getattr(check, "name", "Check")
                )
                detail = (
                    check.get("message")
                    if isinstance(check, dict)
                    else getattr(check, "message", "")
                )

                if str(status).upper() in {"FAIL", "FAILED", "ERROR"}:
                    problems.append(
                        {
                            "code": "diagnosis",
                            "severity": "warning",
                            "title": f"Diagnóstico DHCP: {name}",
                            "message": str(detail or status),
                        }
                    )

        except Exception as error:

            logger.warning(
                "DHCP alert: no se pudo correr diagnóstico: %s",
                error,
            )

        settings = self.get_settings()
        stats = self.pool_stats_service.get_stats()
        free = int(stats.get("devices", {}).get("free") or 0)
        threshold = int(settings.get("pool_low_threshold") or 10)

        # Pool agotado: 0 IPs libres (error "ninguna dirección disponible")
        if free == 0:
            problems.append(
                {
                    "code": "pool_exhausted",
                    "severity": "critical",
                    "title": "Pool DHCP agotado",
                    "message": (
                        f"NO QUEDAN IPs libres en el pool. Los equipos "
                        f"nuevos NO pueden conectarse. "
                        f"Online={stats['devices']['online']}, "
                        f"total pool={stats['devices']['total']}. "
                        f"Amplíe el pool o reduzca el tiempo de lease."
                    ),
                }
            )
        elif settings.get("pool_low_alert_enabled") and free <= threshold:
            problems.append(
                {
                    "code": "pool_low",
                    "severity": "warning",
                    "title": "Pocas IPs libres en el pool DHCP",
                    "message": (
                        f"Quedan {free} IP(s) libre(s) en el pool de "
                        f"equipos (umbral: {threshold}). "
                        f"Online={stats['devices']['online']}, "
                        f"offline={stats['devices']['offline']}, "
                        f"total pool={stats['devices']['total']}."
                    ),
                }
            )

        return problems

    def run_check(
        self,
        *,
        send_email: bool = True,
        force_email: bool = False,
    ) -> dict:

        with self._lock:

            problems = self.collect_problems()
            healthy = len(problems) == 0

            emailed = False

            if send_email and (force_email or not healthy):

                if problems:
                    emailed = self._send_problems_email(problems)
                elif force_email:
                    emailed = self._send_ok_email()

            self._record_run(
                "ok" if healthy else "problems",
                len(problems),
            )

            return {
                "success": True,
                "healthy": healthy,
                "problems": problems,
                "count": len(problems),
                "emailed": emailed,
                "message": (
                    "DHCP saludable."
                    if healthy
                    else f"Se detectaron {len(problems)} problema(s)."
                ),
            }

    def _send_problems_email(self, problems: list[dict]) -> bool:

        try:

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            titles = ", ".join(p["title"] for p in problems[:3])
            title = f"Advertencia DHCP: {titles}"
            if len(problems) > 3:
                title += f" (+{len(problems) - 3})"

            items = "".join(
                f"<li><strong>{p['title']}</strong>: {p['message']}</li>"
                for p in problems
            )
            message = " | ".join(
                f"{p['title']}: {p['message']}" for p in problems
            )
            html = (
                "<p>Se detectaron problemas en el servicio DHCP del NSP:</p>"
                f"<ul>{items}</ul>"
                "<p>Revise <em>Red → DHCP</em> en el panel.</p>"
            )

            db = SessionLocal()

            try:

                return bool(
                    CriticalAlertEmailService().send(
                        db,
                        title,
                        message,
                        html_body=html,
                    )
                )

            finally:

                db.close()

        except Exception as error:

            logger.warning(
                "DHCP alert: no se envió correo de problemas: %s",
                error,
            )
            return False

    def _send_ok_email(self) -> bool:

        try:

            from backend.notifications.services.critical_alert_email_service import (
                CriticalAlertEmailService,
            )

            db = SessionLocal()

            try:

                return bool(
                    CriticalAlertEmailService().send(
                        db,
                        "DHCP OK",
                        "La verificación programada de DHCP no encontró problemas.",
                        html_body=(
                            "<p>Verificación diaria de DHCP: "
                            "<strong>sin problemas</strong>.</p>"
                        ),
                    )
                )

            finally:

                db.close()

        except Exception as error:

            logger.warning(
                "DHCP alert: no se envió correo OK: %s",
                error,
            )
            return False

    def _record_run(self, result: str, count: int) -> None:

        dhcp = dict(self.config_service.get_dhcp_config() or {})
        dhcp["alert_last_run_at"] = (
            datetime.utcnow().isoformat(timespec="seconds") + "Z"
        )
        dhcp["alert_last_result"] = f"{result}:{count}"
        self.config_service.update_section("dhcp", dhcp)

    def _scheduler_loop(self) -> None:

        logger.info("DHCP alert scheduler started.")

        while not self._stop:

            try:

                settings = self.get_settings()

                if self.is_due(settings):

                    result = self.run_check(send_email=True)

                    logger.info(
                        "Scheduled DHCP alert check: healthy=%s emailed=%s",
                        result.get("healthy"),
                        result.get("emailed"),
                    )

            except Exception as error:

                logger.exception(
                    "DHCP alert scheduler error: %s",
                    error,
                )

            for _ in range(60):

                if self._stop:
                    return

                time.sleep(1)

    def start_scheduler(self) -> None:

        if self._scheduler_thread is not None:
            return

        self._stop = False
        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="dhcp-alert-scheduler",
        )
        self._scheduler_thread.start()

    def stop_scheduler(self) -> None:

        self._stop = True
