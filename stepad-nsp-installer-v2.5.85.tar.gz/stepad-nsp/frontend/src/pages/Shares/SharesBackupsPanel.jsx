import { useEffect, useRef, useState } from "react";

import {
    createShareBackup,
    updateShareBackup,
    deleteShareBackup,
    runShareBackup,
    pruneShareBackup,
    getShareBackupSnapshots,
    getShareBackupSnapshotFiles,
    downloadShareBackup,
} from "../../services/api";

import { getToken } from "../../auth/authStorage";

const _API_URL = import.meta.env.VITE_API_URL || "/api/v1";

const LAST_SOURCE_KEY = "stepad.backupOrigin";

function getLastBackupSource() {
    try {
        return window.localStorage.getItem(LAST_SOURCE_KEY) || "";
    } catch {
        return "";
    }
}

async function fetchSilent(endpoint) {
    const token = getToken();
    const response = await fetch(`${_API_URL}${endpoint}`, {
        headers: {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
        },
    });
    if (!response.ok) throw new Error(`API Error ${response.status}`);
    return response.json();
}

function formatSize(bytes) {
    if (bytes == null || !Number.isFinite(bytes) || bytes < 0) return "—";
    if (bytes === 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const idx = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const value = bytes / 1024 ** idx;
    return `${value.toFixed(value >= 100 || idx === 0 ? 0 : 1)} ${units[idx]}`;
}


export default function ShareBackupsPanel({ sources = [], anchorSource = null }) {
    // El ancla puede venir como string (path) o como objeto
    // {path, folderId, jobId} para enlazar por job aunque el path
    // no coincida textualmente (hardlinks, montajes).
    const anchorPath = typeof anchorSource === "string" ? anchorSource : (anchorSource?.path || null);
    const anchorJobId = typeof anchorSource === "object" ? (anchorSource?.jobId || null) : null;
    const anchor = anchorPath;

    // sources puede venir como lista de rutas (strings, API vieja) o como
    // objetos {path, label, isVolume} (UI nueva). Normalizamos.
    const sourceOptions = (sources || []).map((s) => {
        if (typeof s === "string") {
            return { path: s, label: s, isVolume: false, kind: "", volumeName: "" };
        }
        return {
            path: s.path,
            label: s.label || s.path,
            isVolume: Boolean(s.isVolume),
            kind: s.kind || "",
            volumeName: s.volumeName || "",
        };
    });

    // Si anchor no está en sourceOptions, agregarlo para que el combo lo muestre
    const allSourceOptions = anchor && !sourceOptions.some((s) => s.path === anchor)
        ? [...sourceOptions, { path: anchor, label: anchor, isVolume: false, kind: "Origen", volumeName: "" }]
        : sourceOptions;

    const [data, setData] = useState(null);   // { installed, store_*, jobs }
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);

    const [form, setForm] = useState(() => {
        // Si hay anchor (carpeta seleccionada), pre-llenar el origen
        const saved = anchor || getLastBackupSource() || "";
        return {
            name: "",
            source_path: saved,
            schedule_mode: "daily",
            schedule_times: ["13:30", "18:00"],
            schedule_hour: "13",
            schedule_minute: "30",
            retention_count: "7",
            prune_free_pct: "15",
        };
    });

    const [editingId, setEditingId] = useState(null);   // job existente en edición
    const prefilledSource = useRef(null);               // fuente ya cargada en el form

    const [snapOpen, setSnapOpen] = useState(null);          // jobId
    const [snapshots, setSnapshots] = useState({});          // jobId -> list
    const [snapLoading, setSnapLoading] = useState(null);    // jobId
    const [browse, setBrowse] = useState(null);
    const [browseLoading, setBrowseLoading] = useState(false);

    useEffect(() => {
        if (!notice) return undefined;
        const timer = setTimeout(() => setNotice(null), 6000);
        return () => clearTimeout(timer);
    }, [notice]);

    function jobForSource(source) {
        if (!source || !data?.jobs) return null;
        return data.jobs.find((j) => j.source_path === source) || null;
    }

    const editJob = editingId
        ? (data?.jobs || []).find((j) => j.id === editingId) || null
        : null;

    const formSource = (editJob
        ? editJob.source_path
        : (form.source_path || anchor || "").trim()) || "";

    // Al elegir la fuente (carpeta anclada o combo) se precarga el job que ya
    // exista para esa ruta: una sola programación por respaldo se edita y
    // nunca se duplica. El guard evita pisar la selección del usuario en los
    // polls (el origen NO se reescribe una vez elegido).
    useEffect(() => {
        const id = setTimeout(() => {
            const source = (form.source_path || anchor || "").trim();
            if (!source || !data) return;
            if (prefilledSource.current === source) return;
            prefilledSource.current = source;
            const existing = data.jobs.find((j) => j.source_path === source) || null;
            if (existing) {
                setEditingId(existing.id);
                setForm((f) => ({
                    ...f,
                    source_path: existing.source_path || f.source_path,
                    schedule_mode: existing.schedule_mode || f.schedule_mode,
                    schedule_times:
                        existing.schedule_times && existing.schedule_times.length > 0
                            ? existing.schedule_times
                            : f.schedule_times,
                    schedule_hour: String(existing.schedule_hour ?? f.schedule_hour),
                    schedule_minute: String(existing.schedule_minute ?? f.schedule_minute),
                    retention_count: String(existing.retention_count ?? f.retention_count),
                    prune_free_pct: String(existing.prune_free_pct ?? f.prune_free_pct),
                }));
            } else {
                setEditingId(null);
            }
        }, 0);
        return () => clearTimeout(id);
    }, [anchor, form.source_path, data]);

    function load() {
        return fetchSilent("/shares/backups")
            .then(setData)
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(() => {
            fetchSilent("/shares/backups")
                .then(setData)
                .catch(() => {});
        }, 30000);
        return () => clearInterval(timer);
    }, []);

    async function handleCreate(event) {
        event.preventDefault();
        const source = editJob
            ? editJob.source_path
            : (form.source_path || anchor || "").trim();
        if (!source) {
            setError("Indica la ruta a respaldar (ej. la raíz de una unidad compartida).");
            return;
        }
        try {
            window.localStorage.setItem(LAST_SOURCE_KEY, source);
        } catch { /* localStorage no disponible */ }
        const payload = {
            name: form.name.trim() || undefined,
            source_path: source,
            schedule_mode: form.schedule_mode || "daily",
            schedule_hour: Number(form.schedule_hour) || 13,
            schedule_minute: Number(form.schedule_minute) || 30,
            schedule_times: form.schedule_times || undefined,
            retention_count: Number(form.retention_count) || 7,
            prune_free_pct: Number(form.prune_free_pct) || 15,
            smb_user: undefined,
            smb_password: undefined,
        };
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const existing = editJob || jobForSource(source);
            if (existing) {
                await updateShareBackup(existing.id, payload);
                setNotice("Respaldo actualizado.");
            } else {
                await createShareBackup(payload);
                setNotice("Respaldo creado.");
            }
            prefilledSource.current = null;
            await load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleRun(job) {
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const res = await runShareBackup(job.id);
            await load();
            if (res && res.skipped) {
                setNotice("Sin cambios desde el último respaldo. No se creó versión.");
            } else {
                setNotice("Respaldo ejecutado.");
            }
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handlePrune(job) {
        if (!window.confirm(
            `¿Compactar el repositorio de «${job.name}»?\n\n`
            + `Se borran las versiones más antiguas y solo las ${job.retention_count} más recientes quedan.`
        )) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            const result = await pruneShareBackup(job.id);
            await load();
            setNotice(result?.message || "Repositorio compactado.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleToggle(job) {
        setBusy(true);
        setError(null);
        try {
            await updateShareBackup(job.id, { enabled: !job.enabled });
            await load();
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleRemove(job) {
        if (!window.confirm(
            `¿Eliminar el job «${job.name}»?\n\n`
            + "También se borra su repositorio de respaldos (no se puede deshacer)."
        )) return;
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            await deleteShareBackup(job.id);
            if (snapOpen === job.id) {
                setSnapOpen(null);
                setBrowse(null);
            }
            await load();
            setNotice("Job eliminado.");
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function openSnapshots(job) {
        if (snapLoading) return;
        const willOpen = snapOpen === job.id;
        setSnapOpen(willOpen ? null : job.id);
        if (willOpen) {
            setBrowse(null);
            return;
        }
        if (snapshots[job.id]) return;
        setSnapLoading(job.id);
        setError(null);
        try {
            const res = await getShareBackupSnapshots(job.id);
            setSnapshots((prev) => ({ ...prev, [job.id]: res?.snapshots || [] }));
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setSnapLoading(null);
        }
    }

    async function browseSnapshot(jobId, snapshotId, prefix) {
        if (browseLoading) return;
        setBrowseLoading(true);
        setError(null);
        try {
            const listing = await getShareBackupSnapshotFiles(jobId, snapshotId, prefix || "");
            setBrowse({ jobId, snapshotId, prefix: prefix || "", listing });
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBrowseLoading(false);
        }
    }

    async function handleDownloadEntry(jobId, snapshotId, entry) {
        if (busy) return;
        setBusy(true);
        setError(null);
        try {
            const blob = await downloadShareBackup(jobId, snapshotId, entry.path);
            const isDir = entry.type === "dir";
            const name = (entry.path.split("/").pop() || "restauracion").trim() || "restauracion";
            const url = URL.createObjectURL(blob);
            const element = document.createElement("a");
            element.href = url;
            element.download = isDir ? `${name}.tar` : name;
            document.body.appendChild(element);
            element.click();
            element.remove();
            setTimeout(() => URL.revokeObjectURL(url), 4000);
        } catch (err) {
            setError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    const jobs = (data?.jobs || []).filter(
        (job) => (anchorPath ? (job.source_path === anchorPath || (anchorJobId && job.id === anchorJobId)) : true)
    );

    return (
        <section className="sh-bk-panel">
            <div className="sh-bk-head">
                <div>
                    <p className="sh-eyebrow">Protección · v3</p>
                    <h2>{anchor ? `Respaldo de «${anchor.split("/").pop() || "esta carpeta"}»` : "Resguardos versionados"}</h2>
                    <p className="sh-lede">
                        Copias cifradas y versionadas; podés restaurar una versión anterior.
                    </p>
                </div>
                {data?.installed && (
                    <div className="sh-bk-meta">
                        <span className="sh-badge">restic OK</span>
                        <span className="sh-muted">
                            usado {data.store_used_human} · libre {(data.store_free_pct ?? 100)}%
                        </span>
                        {data.vaults && data.vaults.map((v) => (
                            <span key={v.path} className="sh-bk-vault-chip" title={v.path}>
                                💾 {v.used_human} / {v.total_human} ({v.free_pct}% libre)
                            </span>
                        ))}
                    </div>
                )}
            </div>

            {!loading && data?.installed === false && (
                <div className="sh-banner warn">
                    Falta restic en el servidor. Instala: <code>sudo apt-get install -y restic</code>
                </div>
            )}

            {error && <div className="sh-banner warn" style={{marginBottom: 8}}>{error}</div>}
            {notice && <div className="sh-banner" style={{marginBottom: 8, background:"rgba(34,197,94,0.15)", border:"1px solid rgba(34,197,94,0.3)", color:"#86efac", padding:"6px", borderRadius:"4px", fontSize:"0.85rem"}}>{notice}</div>}

            <div className="sh-bk-body">
                <div className="sh-bk-form">
                    <h3>{editingId ? "Actualizar respaldo" : anchor ? "Programar respaldo" : "Programar nuevo respaldo"}</h3>
                    <form className="sh-bk-form-grid" onSubmit={handleCreate}>
                        <label className="sh-bk-source-field">
                            <span className="sh-bk-label">Origen a respaldar</span>
                            {editJob ? (
                                <input
                                    type="text"
                                    value={editJob.source_path}
                                    readOnly
                                    disabled={busy}
                                />
                            ) : allSourceOptions && allSourceOptions.length > 0 ? (
                                <select
                                    value={formSource}
                                    disabled={busy}
                                    onChange={(e) => {
                                        prefilledSource.current = null;
                                        setEditingId(null);
                                        setForm((f) => ({ ...f, source_path: e.target.value }));
                                    }}
                                >
                                    <option value="">
                                        Seleccioná el origen a respaldar…
                                    </option>
                                    {allSourceOptions.map((s) => (
                                        <option key={s.path} value={s.path}>
                                            {s.isVolume
                                                ? `Unidad · ${s.label}`
                                                : `${s.kind ? s.kind : "Carpeta"} · ${s.label}`
                                                    + (s.volumeName ? ` (${s.volumeName})` : "")}
                                            {" — "}
                                            {s.path}
                                        </option>
                                    ))}
                                </select>
                            ) : (
                                <input
                                    type="text"
                                    placeholder="Ruta a respaldar: /mnt/stepad-share/carpeta"
                                    value={form.source_path}
                                    disabled={busy}
                                    maxLength={512}
                                    onChange={(e) => {
                                        prefilledSource.current = null;
                                        setEditingId(null);
                                        setForm((f) => ({ ...f, source_path: e.target.value }));
                                    }}
                                />
                            )}
                        </label>



                        {!anchor && (
                            <input
                                type="text"
                                placeholder="Nombre (opcional)"
                                value={form.name}
                                disabled={busy}
                                maxLength={64}
                                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                            />
                        )}
<div className="sh-bk-mode-pick">
                            <p className="sh-bk-label">Tipo de respaldo</p>
                            <label className="sh-mode-choice">
                                <input
                                    type="radio"
                                    name="bk-mode"
                                    checked={form.schedule_mode === "daily"}
                                    disabled={busy}
                                    onChange={() => setForm((f) => ({ ...f, schedule_mode: "daily" }))}
                                />
                                <span className="sh-mode-text">
                                    <strong>Por horario (N veces al día)</strong>
                                    <small>Respalda automáticamente a las horas que elijas.</small>
                                </span>
                            </label>
                            <label className="sh-mode-choice">
                                <input
                                    type="radio"
                                    name="bk-mode"
                                    checked={form.schedule_mode === "on_change"}
                                    disabled={busy}
                                    onChange={() => setForm((f) => ({ ...f, schedule_mode: "on_change" }))}
                                />
                                <span className="sh-mode-text">
                                    <strong>Al cambiar archivos</strong>
                                    <small>Respalda cuando se detecta un cambio en la carpeta origen.</small>
                                </span>
                            </label>
                        </div>

                        {form.schedule_mode === "daily" && (
                            <div className="sh-bk-times">
                                <p className="sh-bk-label">Horas del día (HH:MM)</p>
                                {(form.schedule_times || []).map((t, index) => (
                                    <div key={index} className="sh-bk-time-row">
                                        <input
                                            type="time"
                                            value={t}
                                            disabled={busy}
                                            onChange={(e) => {
                                                const next = [...(form.schedule_times || [])];
                                                next[index] = e.target.value;
                                                setForm((f) => ({ ...f, schedule_times: next }));
                                            }}
                                        />
                                        <button
                                            type="button"
                                            className="sh-btn sh-btn-sm danger"
                                            disabled={busy || (form.schedule_times || []).length <= 1}
                                            onClick={() => {
                                                const next = (form.schedule_times || []).filter(
                                                    (_, i) => i !== index
                                                );
                                                setForm((f) => ({ ...f, schedule_times: next }));
                                            }}
                                        >
                                            Quitar
                                        </button>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    className="sh-btn sh-btn-sm"
                                    disabled={busy}
                                    onClick={() =>
                                        setForm((f) => ({
                                            ...f,
                                            schedule_times: [...(f.schedule_times || []), "12:00"],
                                        }))
                                    }
                                >
                                    + Agregar hora
                                </button>
                            </div>
                        )}

                        <div className="sh-bk-form-row">
                            <label>
                                Conservar
                                <input
                                    type="number"
                                    min="1"
                                    max="365"
                                    value={form.retention_count}
                                    disabled={busy}
                                    title="Número de versiones recientes que se conservan al compactar"
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, retention_count: e.target.value }))
                                    }
                                />
                            </label>
                            <label>
                                Compactar bajo %
                                <input
                                    type="number"
                                    min="5"
                                    max="80"
                                    value={form.prune_free_pct}
                                    disabled={busy}
                                    title="Compacta cuando quede menos de este % de espacio libre"
                                    onChange={(e) =>
                                        setForm((f) => ({ ...f, prune_free_pct: e.target.value }))
                                    }

                                />
                            </label>
                        </div>
                        <button type="submit" className="sh-btn primary" disabled={busy}>
                            {editingId ? "Actualizar respaldo" : "Guardar respaldo"}
                        </button>
                    </form>
                </div>

                <div className="sh-bk-list">
                    {loading ? (
                        <p className="sh-loading">Cargando…</p>
                    ) : jobs.length === 0 ? (
                        <p className="sh-empty">
                            {anchor
                                ? `Esta carpeta aún no está respaldada: ${anchor}. Programala a la izquierda.`
                                : "Aún no hay jobs. Crea uno indicando la raíz de la unidad o carpeta a proteger."}
                        </p>
                    ) : (
                        jobs.map((job) => {
                            const isOpen = snapOpen === job.id;
                            const snaps = snapshots[job.id];
                            return (
                                <article key={job.id} className="sh-bk-job">
                                    <div className="sh-bk-job-head">
                                        <div className="sh-bk-job-title">
                                            <strong>{job.name}</strong>
                                            <span className="sh-bk-pathline">
                                                <span className="sh-muted">Origen:</span>{" "}
                                                <code className="sh-inline-code">{job.source_path}</code>
                                            </span>
                                            <span className="sh-bk-pathline">
                                                <span className="sh-muted">Destino:</span>{" "}
                                                <code className="sh-inline-code">
                                                    {job.destination_path || job.repository_path || "(sin crear aún)"}
                                                </code>
                                            </span>
                                            <span className={`sh-badge ${job.enabled ? "green" : "readonly"}`}>
                                                {job.enabled ? "programado" : "apagado"}
                                            </span>
                                            {job.enabled && (
                                                <span className="sh-muted">
                                                    {job.schedule_mode === "on_change"
                                                        ? "respaldando al cambiar archivos"
                                                        : (job.schedule_times && job.schedule_times.length > 0
                                                            ? `todos los días a las ${job.schedule_times.join(", ")}`
                                                            : `todos los días ${String(job.schedule_hour).padStart(2, "0")}:${String(job.schedule_minute).padStart(2, "0")}`)}
                                                    {" · conserva "}
                                                    {`${job.retention_count}`} versiones
                                                </span>
                                            )}
                                        </div>
                                        <div className="sh-bk-job-actions">
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm primary"
                                                disabled={busy}
                                                onClick={() => handleRun(job)}
                                            >
                                                Ejecutar ahora
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy || snapLoading === job.id}
                                                onClick={() => openSnapshots(job)}
                                            >
                                                {isOpen ? "Cerrar versiones" : "Versiones"}
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => handlePrune(job)}
                                                title="Borrar versiones antiguas según retención"
                                            >
                                                Compactar
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => handleToggle(job)}
                                            >
                                                {job.enabled ? "Apagar" : "Activar"}
                                            </button>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm danger"
                                                disabled={busy}
                                                onClick={() => handleRemove(job)}
                                            >
                                                Eliminar
                                            </button>
                                        </div>
                                    </div>
                                    {job.running && (
                                        <p className="sh-bk-last" style={{color: "#fbbf24"}}>
                                            <span className="sh-bk-last-status">⏳ Respaldando...</span>
                                        </p>
                                    )}
                                    {!job.running && job.last_result && (
                                        <p className="sh-bk-last">
                                            <span className="sh-bk-last-status">
                                                {job.last_bytes === 0
                                                    ? "⏸ Sin cambios"
                                                    : "✅ Respaldado"}
                                            </span>
                                            {job.last_backup_at && (
                                                <span className="sh-bk-last-date">
                                                    {" · "}
                                                    {new Date(job.last_backup_at).toLocaleString("es-EC", {
                                                        day: "2-digit",
                                                        month: "short",
                                                        hour: "2-digit",
                                                        minute: "2-digit",
                                                    })}
                                                </span>
                                            )}
                                            <span className="sh-muted">
                                                {" · "}
                                                {job.last_result}
                                            </span>
                                        </p>
                                    )}

                                    {isOpen && (
                                        <div className="sh-bk-snapshots">
                                            {snapLoading === job.id ? (
                                                <p className="sh-loading">Cargando versiones…</p>
                                            ) : !snaps ? null : snaps.length === 0 ? (
                                                <p className="sh-empty">
                                                    Sin versiones todavía. Pulsa «Ejecutar ahora».
                                                </p>
                                            ) : (
                                                <table className="sh-bk-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Fecha</th>
                                                            <th>Snapshot</th>
                                                            <th>Tamaño</th>
                                                            <th>Cambios</th>
                                                            <th />
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {snaps.map((snap) => (
                                                            <tr key={snap.id}>
                                                                <td>{snap.time}</td>
                                                                <td>
                                                                    <code className="sh-muted">
                                                                        {snap.short_id}
                                                                    </code>
                                                                </td>
                                                                <td>{snap.total_bytes_human || "—"}</td>
                                                                <td className="sh-muted">
                                                                    +{snap.files_new ?? "?"} ·
                                                                    {snap.data_added_human
                                                                        ? `${snap.data_added_human} nuevos`
                                                                        : "—"}
                                                                </td>
                                                                <td>
                                                                    <button
                                                                        type="button"
                                                                        className="sh-btn sh-btn-sm"
                                                                        disabled={busy || browseLoading}
                                                                        onClick={() =>
                                                                            browseSnapshot(
                                                                                job.id,
                                                                                snap.id,
                                                                                ""
                                                                            )
                                                                        }
                                                                    >
                                                                        Explorar / descargar
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            )}

                                            {browse
                                                && browse.jobId === job.id
                                                && (
                                                <div className="sh-bk-browse">
                                                    <div className="sh-bk-crumbs">
                                                        <button
                                                            type="button"
                                                            className="sh-btn sh-btn-sm"
                                                            disabled={busy || browseLoading}
                                                            onClick={() =>
                                                                browseSnapshot(
                                                                    job.id,
                                                                    browse.snapshotId,
                                                                    ""
                                                                )
                                                            }
                                                        >
                                                            raíz
                                                        </button>
                                                        {browse.prefix.split("/").filter(Boolean)
                                                            .map((part, idx) => {
                                                                const up = browse.prefix
                                                                    .split("/")
                                                                    .filter(Boolean)
                                                                    .slice(0, idx + 1);
                                                                return (
                                                                    <span key={`${part}-${idx}`}>
                                                                        {" / "}
                                                                        <button
                                                                            type="button"
                                                                            className="sh-btn sh-btn-sm"
                                                                            disabled={busy || browseLoading}
                                                                            onClick={() =>
                                                                                browseSnapshot(
                                                                                    job.id,
                                                                                    browse.snapshotId,
                                                                                    up.join("/")
                                                                                )
                                                                            }
                                                                        >
                                                                            {part}
                                                                        </button>
                                                                    </span>
                                                                );
                                                            })}
                                                    </div>
                                                    {browseLoading && (
                                                        <p className="sh-loading">Cargando…</p>
                                                    )}
                                                    {(browse.listing?.directories || []).map(
                                                        (dir) => (
                                                            <div key={dir} className="sh-bk-entry">
<button
                                                                        type="button"
                                                                        className="sh-bk-dir"
                                                                        disabled={busy || browseLoading}
                                                                        onClick={() =>
                                                                            browseSnapshot(
                                                                                job.id,
                                                                                browse.snapshotId,
                                                                                [browse.prefix, dir].filter(Boolean).join("/")
                                                                            )
                                                                        }
                                                                    >
                                                                    📁 {dir}/
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    className="sh-btn sh-btn-sm"
                                                                    disabled={busy}
                                                                    onClick={() =>
                                                                        handleDownloadEntry(
                                                                            job.id,
                                                                            browse.snapshotId,
                                                                            {
                                                                                path: [browse.prefix, dir].filter(Boolean).join("/"),
                                                                                type: "dir",
                                                                            }
                                                                        )
                                                                    }
                                                                >
                                                                    Descargar carpeta (.tar)
                                                                </button>
                                                            </div>
                                                        )
                                                    )}
                                                    {(browse.listing?.files || []).map((file) => (
                                                        <div key={file.path} className="sh-bk-entry">
                                                            <span className="sh-bk-file">
                                                                📄 {file.name}
                                                                <span className="sh-muted">
                                                                    {" "}
                                                                    ({file.size_human})
                                                                </span>
                                                            </span>
                                                            <button
                                                                type="button"
                                                                className="sh-btn sh-btn-sm"
                                                                disabled={busy}
                                                                onClick={() =>
                                                                    handleDownloadEntry(
                                                                        job.id,
                                                                        browse.snapshotId,
                                                                        { path: file.path, type: "file" }
                                                                    )
                                                                }
                                                            >
                                                                Descargar
                                                            </button>
                                                        </div>
                                                    ))}
                                                    {browse.listing
                                                        && (browse.listing.directories || []).length === 0
                                                        && (browse.listing.files || []).length === 0
                                                        && (
                                                        <p className="sh-empty">Carpeta vacía.</p>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </article>
                            );
                        })
                    )}
                </div>
            </div>
        </section>
    );
}