import time

from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy import func
from sqlalchemy.orm import Session

from backend.alerts.services.alert_service import AlertService

from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.dns.logging.threat_domains import classify_blocked_domain

from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository
)
from backend.notifications.services.email_service import EmailService
from backend.notifications.services.email_settings_service import (
    build_delivery_context
)
from backend.notifications.services.email_subject_service import (
    build_alert_subject
)

from backend.shared.logging.logger import logger


CLEANUP_SCRIPT_PATH = (
    Path(__file__).resolve().parents[2]
    / "notifications" / "assets" / "limpiador_gtservices.ps1"
)


class SecurityDnsAlertService:
    """Detecta bloqueos de DNS que indican una amenaza activa (pool de
    mineria de criptomonedas o dominio del feed de malware/phishing) y
    dispara una alerta PRIORITARIA: se crea con severidad "critical" en
    el panel (asi el usuario la ve como prioridad, con el badge rojo del
    campanazo) y, si esta configurado, se envia un correo inmediato con
    el script de limpieza adjunto -- separado del reporte periodico de
    navegacion.
    """

    WINDOW_MINUTES = 5

    # 30 min: evita reenviar el mismo correo cada 30s (cadencia del
    # monitor) mientras el equipo sigue reintentando el mismo dominio,
    # pero vuelve a avisar si el intento persiste bastante tiempo.
    COOLDOWN_SECONDS = 1800

    def __init__(self):

        self.alert_service = AlertService()

        self.email_service = EmailService()

        self.notification_repo = NotificationSettingsRepository()

        # key -> ultimo timestamp de alerta. En memoria del proceso;
        # si el backend se reinicia, puede volver a alertar una vez
        # mas para la misma amenaza, lo cual es preferible a perder
        # el aviso.
        self._cooldown = {}

    def _should_alert(self, key: str) -> bool:

        last = self._cooldown.get(key)

        if last is None:

            return True

        return (time.time() - last) >= self.COOLDOWN_SECONDS

    def _mark(self, key: str):

        self._cooldown[key] = time.time()

    def check(self, db: Session):

        since = datetime.utcnow() - timedelta(minutes=self.WINDOW_MINUTES)

        rows = (
            db.query(
                DnsQueryLog.device_id,
                DnsQueryLog.device_hostname,
                DnsQueryLog.client_ip,
                DnsQueryLog.domain,
                func.count(DnsQueryLog.id).label("attempts"),
            )
            .filter(
                DnsQueryLog.blocked.is_(True),
                DnsQueryLog.queried_at >= since,
            )
            .group_by(
                DnsQueryLog.device_id,
                DnsQueryLog.device_hostname,
                DnsQueryLog.client_ip,
                DnsQueryLog.domain,
            )
            .all()
        )

        for row in rows:

            try:

                classification = classify_blocked_domain(db, row.domain)

                if not classification:

                    continue

                key = f"{row.device_id or row.client_ip}:{row.domain}"

                if not self._should_alert(key):

                    continue

                self._mark(key)

                self._raise_alert(db, row, classification)

            except Exception as error:

                logger.exception(
                    f"Chequeo de amenaza DNS fallo para {row.domain}: "
                    f"{error}"
                )

    def _raise_alert(self, db: Session, row, classification: dict):

        device_label = (
            row.device_hostname or row.client_ip or "Equipo desconocido"
        )

        ip = row.client_ip or "?"

        title = f"{classification['label']}: {device_label}"

        message = (
            f"{ip} -> {row.domain} "
            f"({row.attempts} intento(s) bloqueado(s) en los últimos "
            f"{self.WINDOW_MINUTES} min)"
        )

        self.alert_service.create(
            db,
            "SECURITY_DNS_THREAT",
            "critical",
            title,
            message,
        )

        logger.warning(f"Amenaza DNS detectada: {message}")

        self._send_email(
            db, device_label, ip, row.domain, title, message,
            classification["kind"],
        )

    def _send_email(
        self,
        db: Session,
        device_label: str,
        ip: str,
        domain: str,
        title: str,
        message: str,
        kind: str,
    ):

        try:

            settings = self.notification_repo.get(db)

            if not settings.security_dns_alert_enabled:

                return

            recipients = (
                settings.security_dns_alert_emails
                or settings.to_emails
                or ""
            )

            if not recipients.strip():

                return

            delivery = build_delivery_context(
                db,
                to_emails=recipients,
                cc_emails=settings.security_dns_alert_cc_emails or "",
                bcc_emails=settings.security_dns_alert_bcc_emails or "",
            )

            if delivery is None:

                return

            subject = build_alert_subject(db, settings.alert_subject, title=title)

            threat_label = (
                "minería de criptomonedas (cryptojacking)"
                if kind == "mining"
                else "malware o phishing"
            )

            html_body = f"""
                <h2 style="color:#dc2626;">⚠ {title}</h2>
                <p>Se detectó que el equipo <strong>{device_label}</strong>
                ({ip}) intentó repetidamente comunicarse con
                <strong>{domain}</strong>, un dominio bloqueado por
                STEPAD NSP asociado a
                {threat_label}.</p>
                <p>{message}</p>
                <p><strong>Qué hacer:</strong></p>
                <ol>
                    <li>Revise el equipo indicado en persona o de forma
                    remota.</li>
                    <li>Ejecute el script adjunto
                    (<code>limpiador-gtservices.txt</code>): guárdelo
                    quitando el ".txt" del nombre (debe quedar terminado
                    en ".ps1") y ejecútelo en PowerShell como
                    Administrador. Por defecto solo diagnostica; si
                    detecta algo, vuelva a ejecutarlo agregando
                    <code>-Limpiar</code> para eliminarlo
                    automáticamente (proceso minero, carpetas de
                    persistencia y tareas programadas ocultas).</li>
                    <li>Ejecute un antivirus completo en el equipo.</li>
                    <li>Revise el detalle completo y el historial en el
                    panel de <strong>Alertas</strong> de STEPAD NSP.</li>
                </ol>
                <p style="color:#6b7280;font-size:12px;">
                Esta alerta se marca como prioritaria (crítica) en el
                panel de Alertas. Configure los destinatarios en
                Ajustes → Notificaciones → Alertas de seguridad (DNS).
                </p>
            """

            script_bytes = b""

            if CLEANUP_SCRIPT_PATH.exists():

                script_bytes = CLEANUP_SCRIPT_PATH.read_bytes()

            if script_bytes:

                self.email_service.send_html_with_attachment(
                    delivery,
                    subject,
                    html_body,
                    script_bytes,
                    "limpiador-gtservices.txt",
                    attachment_subtype="plain",
                )

            else:

                self.email_service.send_html(delivery, subject, html_body)

        except Exception as error:

            logger.exception(f"No se pudo enviar la alerta de amenaza DNS: {error}")
