from fastapi import HTTPException

from sqlalchemy.orm import Session

from backend.groups.models.device_group import DeviceGroup
from backend.groups.repositories.device_group_repository import (
    DeviceGroupRepository
)

from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.rules.repositories.device_access_rule_repository import (
    DeviceAccessRuleRepository
)

from backend.network.devices.models.network_device import NetworkDevice

from backend.audit.services.audit_service import AuditService

from backend.content.models.content_category import (
    ContentCategory,
    GroupCategory,
)
from backend.content.services.content_category_service import (
    ROOT_CATEGORY_KEYS,
)

from backend.bandwidth.services.bandwidth_service import BandwidthService

from backend.groups.constants.group_dns_ip_reserve import (
    group_ip_bounds,
    next_free_group_ip,
)
from backend.shared.logging.logger import logger


DEFAULT_GROUP_NAME = "Invitados"

_UNSET = object()


class GroupService:

    def __init__(self):

        self.repository = DeviceGroupRepository()

        self.rule_repository = DeviceAccessRuleRepository()

        self.audit_service = AuditService()

    def _used_alias_ips(
        self,
        db: Session,
        *,
        exclude_group_id: int | None = None,
    ) -> set[str]:
        q = db.query(DeviceGroup.dns_alias_ip).filter(
            DeviceGroup.dns_alias_ip.isnot(None)
        )
        if exclude_group_id is not None:
            q = q.filter(DeviceGroup.id != exclude_group_id)
        return {row[0] for row in q.all() if row[0]}

    def _allocate_dns_alias_ip(self, db: Session) -> str:
        """Reserva una IP libre del subrango de grupos o falla con 400."""
        free = next_free_group_ip(self._used_alias_ips(db))
        if free is None:
            first, last = group_ip_bounds()
            raise HTTPException(
                status_code=400,
                detail=(
                    f"No hay IPs libres en el subrango de grupos "
                    f"({first}-{last}). Amplía group_ip_start/"
                    f"group_ip_end (o group_ip_count) en la "
                    f"configuración DHCP, o elimina un grupo existente."
                ),
            )
        return free

    def _ensure_group_has_alias_ip(
        self,
        db: Session,
        group: DeviceGroup,
    ) -> DeviceGroup:
        """Backfill lazy: grupos antiguos sin columna poblada."""
        if group.dns_alias_ip:
            return group
        try:
            group.dns_alias_ip = self._allocate_dns_alias_ip(db)
            db.commit()
            db.refresh(group)
        except HTTPException:
            logger.warning(
                "Grupo %s sin dns_alias_ip y sin IPs libres en el subrango",
                group.id,
            )
        return group

        self.bandwidth_service = BandwidthService()

    # ------------------------------------------------------------------
    # Groups
    # ------------------------------------------------------------------

    def ensure_default_group(
        self,
        db: Session
    ) -> DeviceGroup:

        default = self.repository.find_default(db)

        if default is None:

            group = self.repository.find_all(db)

            if group:

                existing = next(
                    (g for g in group if g.name == DEFAULT_GROUP_NAME),
                    None
                )

                if existing is not None:

                    existing.is_default = True

                    db.commit()

                    db.refresh(existing)

                    default = existing

        if default is None:

            new_group = DeviceGroup(
                name=DEFAULT_GROUP_NAME,
                description="Dispositivos no asignados a un departamento",
                is_default=True,
                dns_alias_ip=self._allocate_dns_alias_ip(db),
            )

            default = self.repository.save(db, new_group)

        else:

            default = self._ensure_group_has_alias_ip(db, default)

        # Invitados: sin bloqueos extra de grupo (solo los de raiz globales).
        self._ensure_default_group_profile(db, default)

        return default

    def _root_category_ids(
        self,
        db: Session
    ) -> set[int]:

        return {
            row.id
            for row in (
                db.query(ContentCategory)
                .filter(ContentCategory.key.in_(ROOT_CATEGORY_KEYS))
                .all()
            )
        }

    def _ensure_default_group_profile(
        self,
        db: Session,
        group: DeviceGroup
    ) -> None:
        """
        El grupo por defecto (Invitados) no lleva perfil de navegacion:
        solo aplican bloqueos de raiz (porno, apuestas, juegos) via DNS
        global. Restricciones extra van en otros grupos.
        """

        if not group.is_default:

            return

        rows = (
            db.query(GroupCategory)
            .filter(GroupCategory.group_id == group.id)
            .all()
        )

        if not rows:

            return

        changed = False

        for row in rows:

            db.delete(row)

            changed = True

        if changed:

            db.commit()

            self._sync_group_dns(db, group.id, None)

    def reconcile_unassigned_devices(
        self,
        db: Session
    ) -> dict:

        # Todo equipo pertenece a un grupo: los que quedaron sin grupo
        # (p. ej. descubiertos antes de asignar, o tras quitar del
        # default) pasan al grupo por defecto.
        default = self.repository.find_default(db)

        if default is None:

            return {"success": False, "message": "No default group"}

        from backend.groups.models.device_group import GroupDevice

        assigned = {
            row[0]
            for row in db.query(GroupDevice.device_id).all()
        }

        added = 0

        for (device_id,) in db.query(NetworkDevice.id).all():

            if device_id in assigned:

                continue

            self.repository.add_device(db, default.id, device_id)

            added += 1

        if added:

            logger.info(
                f"Reconcile: {added} equipos sin grupo asignados a "
                f"'{default.name}'."
            )

            # Regenerar reglas de bloqueo IP/SNI del grupo por defecto.
            from backend.groups.services.sni_block_service import (
                sni_block_service
            )

            sni_block_service.sync_all(db)

        return {"success": True, "added": added}

    def list_groups(
        self,
        db: Session
    ):

        groups = self.repository.find_all(db)

        result = []

        for group in groups:

            result.append({
                "id": group.id,
                "name": group.name,
                "description": group.description,
                "is_default": group.is_default,
                "bandwidth_limit_kbps": group.bandwidth_limit_kbps,
                "dns_alias_ip": group.dns_alias_ip,
                "devices": len(self.repository.device_ids(db, group.id)),
                "rules": len(self._group_rules(db, group.id)),
            })

        return result

    def _to_dict(
        self,
        db: Session,
        group: DeviceGroup
    ):

        return {
            "id": group.id,
            "name": group.name,
            "description": group.description,
            "is_default": group.is_default,
            "bandwidth_limit_kbps": group.bandwidth_limit_kbps,
            "dns_alias_ip": group.dns_alias_ip,
            "devices": len(self.repository.device_ids(db, group.id)),
            "rules": len(self._group_rules(db, group.id)),
        }

    def create_group(
        self,
        db: Session,
        name: str,
        description: str | None,
        user_id: int | None
    ):

        name = name.strip()

        existing = (
            db.query(DeviceGroup)
            .filter(DeviceGroup.name == name)
            .first()
        )

        if existing:

            raise HTTPException(
                status_code=400,
                detail="Ya existe un grupo con ese nombre"
            )

        alias_ip = self._allocate_dns_alias_ip(db)

        group = DeviceGroup(
            name=name,
            description=description,
            is_default=False,
            dns_alias_ip=alias_ip,
        )

        saved = self.repository.save(db, group)

        self._assign_base_categories(db, saved)

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="GROUP_CREATED",
            resource="GROUP",
            description=(
                f"Created group {saved.name} (DNS alias {alias_ip})"
            ),
        )

        return self._to_dict(db, saved)

    def update_group(
        self,
        db: Session,
        group_id: int,
        name: str | None,
        description: str | None,
        is_default: bool | None,
        bandwidth_limit_kbps: int | None,
        user_id: int | None
    ):

        group = self.repository.find_by_id(db, group_id)

        if group is None:

            raise HTTPException(
                status_code=404,
                detail="Group not found"
            )

        if name is not None:
            group.name = name.strip()

        if description is not None:
            group.description = description or None

        if bandwidth_limit_kbps is not _UNSET:

            group.bandwidth_limit_kbps = bandwidth_limit_kbps

        if is_default is not None and is_default:

            current_default = self.repository.find_default(db)

            if current_default and current_default.id != group.id:

                current_default.is_default = False

                db.commit()

            group.is_default = True

        db.commit()

        db.refresh(group)

        if bandwidth_limit_kbps is not _UNSET:

            try:

                self.bandwidth_service.apply()

            except Exception as error:

                logger.error(
                    "Fallo al aplicar ancho de banda del grupo: %s",
                    error
                )

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="GROUP_UPDATED",
            resource="GROUP",
            description=f"Updated group {group.name}"
        )

        return self._to_dict(db, group)

    def delete_group(
        self,
        db: Session,
        group_id: int,
        user_id: int | None
    ):

        group = self.repository.find_by_id(db, group_id)

        if group is None:

            raise HTTPException(
                status_code=404,
                detail="Group not found"
            )

        if group.is_default:

            raise HTTPException(
                status_code=400,
                detail="No se puede eliminar el grupo por defecto"
            )

        alias_ip = group.dns_alias_ip
        device_ids = list(self.repository.device_ids(db, group_id))
        default = self.repository.find_default(db)

        # Mover equipos al grupo default ANTES de borrar, para que el
        # sync DNS les asigne el alias/default y no queden apuntando
        # al IP fantasma del grupo eliminado.
        if default is not None and device_ids:

            for device_id in device_ids:

                self.repository.remove_device(db, group_id, device_id)
                self.repository.add_device(db, default.id, device_id)

        for rule in self._group_rules(db, group_id):

            self.rule_repository.delete(db, rule)

        self.repository.delete(db, group)

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="GROUP_DELETED",
            resource="GROUP",
            description=(
                f"Deleted group {group.name}"
                + (f" (liberó alias {alias_ip})" if alias_ip else "")
            ),
        )

        try:
            from backend.groups.services.group_dns_service import (
                group_dns_service,
            )

            group_dns_service.sync_all(db)
        except Exception as error:
            logger.exception(
                f"Group DNS sync tras borrar grupo fallo: {error}"
            )

        try:
            from backend.groups.services.sni_block_service import (
                sni_block_service,
            )

            sni_block_service.sync_all(db)
        except Exception as error:
            logger.exception(
                f"SNI sync tras borrar grupo fallo: {error}"
            )

        # Regenerar DHCP para que option DNS deje de apuntar al alias
        # borrado (los clientes lo toman en el próximo renew/lease).
        try:
            from backend.dhcp.services.dhcp_service import DhcpService

            DhcpService().apply_config()
        except Exception as error:
            logger.exception(
                f"DHCP apply tras borrar grupo fallo: {error}"
            )

        return {"success": True}

    # ------------------------------------------------------------------
    # Device membership
    # ------------------------------------------------------------------

    def _group_rules(
        self,
        db: Session,
        group_id: int
    ):

        return (
            db.query(DeviceAccessRule)
            .filter(DeviceAccessRule.group_id == group_id)
            .all()
        )

    def group_devices(
        self,
        db: Session,
        group_id: int
    ):

        ids = self.repository.device_ids(db, group_id)

        devices = (
            db.query(NetworkDevice)
            .filter(NetworkDevice.id.in_(ids))
            .all()
        ) if ids else []

        return [
            {
                "id": device.id,
                "hostname": device.hostname,
                "ip_address": device.ip_address,
                "mac_address": device.mac_address,
                "vendor": device.vendor,
                "zone_id": device.zone_id,
            }
            for device in devices
        ]

    def add_device(
        self,
        db: Session,
        group_id: int,
        device_id: int,
        user_id: int | None
    ):

        group = self.repository.find_by_id(db, group_id)

        if group is None:

            raise HTTPException(
                status_code=404,
                detail="Group not found"
            )

        device = db.get(NetworkDevice, device_id)

        if device is None:

            raise HTTPException(
                status_code=404,
                detail="Device not found"
            )

        # Los dispositivos de infraestructura (impresoras, telefonos IP,
        # routers) no pueden pertenecer a grupos: son equipos de red,
        # no de usuario, y no aplican politicas de navegacion/dominio.
        from backend.network.devices.services.device_classifier import (
            DeviceClassifier
        )

        if DeviceClassifier.is_infrastructure(device.device_type):

            raise HTTPException(
                status_code=400,
                detail=(
                    "Los dispositivos de red (impresoras, telefonos IP, "
                    "routers) no pueden pertenecer a grupos."
                )
            )

        # Un equipo pertenece a UN SOLO grupo: al asignarlo a este
        # grupo se quita de cualquier otro en el que estuviera.
        for gid in self.repository.group_ids_for_device(db, device_id):

            if gid != group_id:

                self.repository.remove_device(db, gid, device_id)

        self.repository.add_device(db, group_id, device_id)

        self._sync_device_dns(db, device_id, user_id)

        try:

            self.bandwidth_service.apply()

        except Exception as error:

            logger.error(
                "Fallo al reaplicar ancho de banda: %s",
                error
            )

        return {"success": True}

    def remove_device(
        self,
        db: Session,
        group_id: int,
        device_id: int,
        user_id: int | None
    ):

        group = self.repository.find_by_id(db, group_id)

        if group is not None and group.is_default:

            raise HTTPException(
                status_code=400,
                detail=(
                    "No se puede quitar un equipo de Invitados. "
                    "Abra el grupo destino y asignelo desde ahi."
                ),
            )

        self.repository.remove_device(db, group_id, device_id)

        # Al quitar un equipo del grupo pasa al grupo por defecto
        # (todo equipo siempre pertenece a algun grupo). Si el grupo por
        # defecto es el mismo del que se quita, queda sin grupo (caso
        # poco comun: el default no suele ser el de trabajo).
        default = self.repository.find_default(db)

        if default is not None and default.id != group_id:

            self.repository.add_device(db, default.id, device_id)

        self._sync_device_dns(db, device_id, user_id)

        try:

            self.bandwidth_service.apply()

        except Exception as error:

            logger.error(
                "Fallo al reaplicar ancho de banda: %s",
                error
            )

        return {"success": True}

    def groups_for_device(
        self,
        db: Session,
        device_id: int
    ):

        ids = self.repository.group_ids_for_device(db, device_id)

        groups = (
            db.query(DeviceGroup)
            .filter(DeviceGroup.id.in_(ids))
            .all()
        ) if ids else []

        return [
            {"id": group.id, "name": group.name}
            for group in groups
        ]

    # ------------------------------------------------------------------
    # Group rules (domain ALLOW / BLOCK)
    # ------------------------------------------------------------------

    def list_rules(
        self,
        db: Session,
        group_id: int
    ):

        rules = self._group_rules(db, group_id)

        return [
            {
                "id": rule.id,
                "action": rule.action,
                "domain": rule.value,
                "enabled": rule.enabled,
                "is_permanent": rule.is_permanent,
            }
            for rule in rules
        ]

    def add_rule(
        self,
        db: Session,
        group_id: int,
        action: str,
        domain: str,
        user_id: int | None
    ):

        group = self.repository.find_by_id(db, group_id)

        if group is None:

            raise HTTPException(
                status_code=404,
                detail="Group not found"
            )

        if group.is_default:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Invitados no admite reglas de grupo. "
                    "Use otro departamento para bloqueos adicionales."
                ),
            )

        if action.upper() not in ("BLOCK", "ALLOW"):

            raise HTTPException(
                status_code=400,
                detail="action must be BLOCK or ALLOW"
            )

        domain = domain.strip().lower()

        # Expansión padre -> hijos (ej. bloquear youtube.com tambien
        # agrega googlevideo.com, ytimg.com...).
        from backend.content.services.domain_group_service import (
            DomainGroupService
        )

        if action.upper() == "BLOCK":

            domains = DomainGroupService().expand_domains(db, domain)

        else:

            domains = [domain]

        saved = None

        for d in domains:

            existing = (
                db.query(DeviceAccessRule)
                .filter(
                    DeviceAccessRule.group_id == group_id,
                    DeviceAccessRule.value == d,
                    DeviceAccessRule.action == action.upper()
                )
                .first()
            )

            if existing:

                if saved is None:

                    saved = existing

                continue

            rule = DeviceAccessRule(
                device_id=None,
                action=action.upper(),
                rule_type="DOMAIN",
                value=d,
                scope="GROUP",
                group_id=group_id,
                enabled=True,
                is_permanent=False,
                created_by=user_id
            )

            r = self.rule_repository.save(db, rule)

            if saved is None:

                saved = r

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="GROUP_RULE_" + action.upper(),
            resource="GROUP",
            description=(
                f"{action.upper()} {domain} (+hijos) in group {group.name}"
            )
        )

        self._sync_group_dns(db, group_id, user_id)

        return {
            "id": saved.id if saved else None,
            "action": action.upper(),
            "domain": domain,
            "enabled": True,
        }

    def delete_rule(
        self,
        db: Session,
        rule_id: int,
        user_id: int | None
    ):

        rule = self.rule_repository.find_by_id(db, rule_id)

        if rule is None or rule.group_id is None:

            raise HTTPException(
                status_code=404,
                detail="Rule not found"
            )

        group_id = rule.group_id

        self.rule_repository.delete(db, rule)

        self._sync_group_dns(db, group_id, user_id)

        return {"success": True}

    # ------------------------------------------------------------------
    # Enforcement hooks (filled by the per-group DNS engine)
    # ------------------------------------------------------------------

    def _sync_group_dns(
        self,
        db: Session,
        group_id: int,
        user_id: int | None
    ):

        try:

            from backend.groups.services.group_dns_service import (
                group_dns_service
            )

            group_dns_service.sync_group(db, group_id)

            from backend.groups.services.sni_block_service import (
                sni_block_service
            )

            sni_block_service.sync_group(db, group_id)

        except Exception as error:

            logger.exception(f"Group DNS sync failed: {error}")

    def group_categories(
        self,
        db: Session,
        group_id: int
    ):

        group = self.repository.find_by_id(db, group_id)

        if group is None:

            raise HTTPException(
                status_code=404,
                detail="Group not found"
            )

        rows = (
            db.query(GroupCategory)
            .filter(GroupCategory.group_id == group_id)
            .all()
        )

        category_ids = {row.category_id for row in rows}

        categories = (
            db.query(ContentCategory)
            .filter(ContentCategory.id.in_(category_ids))
            .all()
        ) if category_ids else []

        return [
            {
                "key": category.key,
                "name": category.name,
            }
            for category in categories
        ]

    def set_group_categories(
        self,
        db: Session,
        group_id: int,
        keys: list[str],
        user_id: int | None
    ):

        group = self.repository.find_by_id(db, group_id)

        if group is None:

            raise HTTPException(
                status_code=404,
                detail="Group not found"
            )

        if group.is_default:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Invitados solo tiene bloqueos generales de red. "
                    "Cree otro grupo para restricciones adicionales."
                ),
            )

        keys = [key for key in keys if key not in ROOT_CATEGORY_KEYS]

        for row in db.query(GroupCategory).filter(
            GroupCategory.group_id == group_id
        ).all():

            db.delete(row)

        if keys:

            categories = (
                db.query(ContentCategory)
                .filter(ContentCategory.key.in_(keys))
                .all()
            )

            for category in categories:

                db.add(GroupCategory(
                    group_id=group_id,
                    category_id=category.id
                ))

        db.commit()

        self.audit_service.create_log(
            db=db,
            user_id=user_id,
            action="GROUP_CATEGORIES_UPDATED",
            resource="GROUP",
            description=f"Perfil de navegación actualizado para {group.name}"
        )

        self._sync_group_dns(db, group_id, user_id)

        return self.group_categories(db, group_id)

    def _sync_device_dns(
        self,
        db: Session,
        device_id: int,
        user_id: int | None
    ):

        try:

            from backend.groups.services.group_dns_service import (
                group_dns_service
            )

            group_dns_service.sync_device(db, device_id)

            # Al cambiar la membresia del equipo tambien se regeneran
            # las reglas de bloqueo IP/SNI de sus grupos (si no, un
            # equipo nuevo en un grupo no hereda el bloqueo).
            from backend.groups.services.sni_block_service import (
                sni_block_service
            )

            sni_block_service.sync_all(db)

        except Exception as error:

            logger.exception(f"Device DNS sync failed: {error}")
