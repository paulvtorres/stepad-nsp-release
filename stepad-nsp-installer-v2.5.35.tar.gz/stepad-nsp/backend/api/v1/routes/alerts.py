from pathlib import Path

from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import FileResponse

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user

from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles

from backend.alerts.services.alert_service import AlertService


router = APIRouter(
    prefix="/alerts",
    tags=["Alerts"]
)

service = AlertService()

INTRUSION_SCRIPT_PATH = (
    Path(__file__).resolve().parents[3]
    / "notifications" / "assets" / "diagnostico_intrusos.ps1"
)

MINER_CLEANUP_SCRIPT_PATH = (
    Path(__file__).resolve().parents[3]
    / "notifications" / "assets" / "limpiador_gtservices.ps1"
)


@router.get("/intrusion-diagnostic-script")
def download_intrusion_script(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    """
    Descarga manual (no adjunto de correo) del script de diagnostico de
    intrusion/acceso remoto no autorizado, para correrlo en cualquier
    equipo Windows sospechoso bajo demanda.
    """

    if not INTRUSION_SCRIPT_PATH.exists():

        raise HTTPException(
            status_code=404,
            detail="Script de diagnostico no encontrado"
        )

    return FileResponse(
        path=str(INTRUSION_SCRIPT_PATH),
        media_type="application/octet-stream",
        filename="diagnostico_intrusos.ps1"
    )


@router.get("/miner-cleanup-script")
def download_miner_cleanup_script(
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    """
    Descarga manual del limpiador automatico de minero de criptomonedas
    (gtservices/SRBMiner y variantes: carpetas "Perform"/"Netframework",
    tareas programadas ocultas, scripts .bat/.vbs de relanzamiento).
    Por defecto solo diagnostica; con "-Limpiar" elimina de verdad.
    """

    if not MINER_CLEANUP_SCRIPT_PATH.exists():

        raise HTTPException(
            status_code=404,
            detail="Script de limpieza no encontrado"
        )

    return FileResponse(
        path=str(MINER_CLEANUP_SCRIPT_PATH),
        media_type="application/octet-stream",
        filename="limpiador_gtservices.ps1"
    )


@router.get("/")
def list_alerts(
    limit: int = Query(50, ge=1, le=200),
    unread_only: bool = Query(False),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return {
        "alerts": service.list(db, limit=limit, unread_only=unread_only),
        "unread": service.unread_count(db)
    }


@router.get("/unread-count")
def unread_count(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return {
        "unread": service.unread_count(db),
        "critical": service.critical_unread_count(db)
    }


@router.post("/{alert_id}/read")
def mark_read(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.mark_read(db, alert_id)


@router.post("/read-all")
def mark_all_read(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    return service.mark_all_read(db)


@router.post("/{alert_id}/quarantine")
def quarantine_from_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN))
):
    """
    Accion inmediata desde una alerta del IPS: aísla el equipo que la
    originó (bloquea su MAC) sin salir del Panel. Parsea la IP origen
    del mensaje (formato "IP -> dst:puerto").
    """

    import re

    from backend.alerts.models.alert import Alert
    from backend.network.devices.repositories.device_repository import (
        DeviceRepository
    )
    from backend.firewall.services.firewall_service import FirewallService
    from backend.audit.services.audit_service import AuditService

    alert = db.get(Alert, alert_id)

    if not alert:

        raise HTTPException(
            status_code=404,
            detail="Alerta no encontrada"
        )

    match = re.search(
        r"([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)\s*->",
        alert.message or ""
    )

    if not match:

        raise HTTPException(
            status_code=400,
            detail="No se pudo identificar la IP origen de la alerta"
        )

    src_ip = match.group(1)

    device = DeviceRepository().find_by_ip(
        db,
        src_ip
    )

    if not device:

        raise HTTPException(
            status_code=404,
            detail=f"No hay un equipo registrado con la IP {src_ip}"
        )

    result = FirewallService().block_device(
        device.mac_address
    )

    if not result.get("success"):

        raise HTTPException(
            status_code=500,
            detail="No se pudo aislar el equipo"
        )

    device.blocked = True

    db.commit()

    service.mark_read(db, alert_id)

    name = device.display_name or device.hostname or src_ip

    description = (
        f"Aislamiento manual desde alerta: {name} ({src_ip}) "
        f"bloqueado por: {alert.title}"
    )

    try:

        AuditService().create_log(
            db,
            current_user.get("id") if isinstance(current_user, dict) else None,
            "QUARANTINE",
            "device",
            description
        )

    except Exception:

        pass

    return {
        "success": True,
        "device": name,
        "ip": src_ip,
        "mac": device.mac_address,
        "alert": alert.title,
    }
