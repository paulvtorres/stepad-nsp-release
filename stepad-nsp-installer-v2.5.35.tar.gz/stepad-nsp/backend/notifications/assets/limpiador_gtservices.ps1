<#
    STEPAD NSP - Limpiador de minero de criptomonedas (gtservices / SRBMiner
    y variantes similares: "Perform", "Netframework.4.5.2", tareas
    programadas ocultas bajo carpetas de sistema)
    ---------------------------------------------------------------------

    Este script automatiza la limpieza que normalmente se hace a mano
    cuando STEPAD NSP detecta que un equipo intenta comunicarse con un
    dominio de mineria de criptomonedas (cryptojacking). Busca y elimina
    los indicadores de compromiso (IOC) conocidos de esta familia de
    malware:

      - Proceso minero "gtservices.exe" (SRBMiner-MULTI) y otros nombres
        tipicos de minero.
      - Carpetas de persistencia disfrazadas: C:\Perform,
        C:\Netframework.4.5.2 (y variantes con nombres parecidos).
      - Scripts .bat/.vbs que relanzan el minero en bucle ("system.bat",
        "Audio system.bat/vbs", "update.vbs", "mouse.bat", etc.) y los
        procesos cmd.exe/wscript.exe que los mantienen corriendo.
      - Tareas programadas escondidas en rutas que imitan carpetas del
        sistema (ej. "\Microsoft\Windows\Autochk\") -- esa ruta NO trae
        tareas de fabrica en Windows, asi que cualquier tarea ahi es
        sospechosa.

    POR DEFECTO SOLO DIAGNOSTICA (no borra nada). Para limpiar de verdad:

        .\limpiador_gtservices.ps1 -Limpiar

    COMO USARLO:
      1. Guarda este archivo con extension .ps1 (si tu correo/descarga lo
         entrego como .txt, quita el ".txt" del nombre).
      2. Abre PowerShell COMO ADMINISTRADOR y ejecuta:
           Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
           .\limpiador_gtservices.ps1            (solo diagnostico)
           .\limpiador_gtservices.ps1 -Limpiar   (limpieza real)
      3. Si tras limpiar alguna carpeta no se pudo borrar por "en uso",
         vuelve a correr el script con -Limpiar una segunda vez (el
         primer paso mata los procesos que la bloquean, el segundo ya
         puede borrarla sin problema).
#>

param(
    [switch]$Limpiar
)

$ErrorActionPreference = "SilentlyContinue"

function Section($titulo) {
    Write-Host ""
    Write-Host "== $titulo ==" -ForegroundColor Cyan
}

Write-Host "=== STEPAD NSP: limpiador de minero de criptomonedas ===" -ForegroundColor Cyan
Write-Host "Equipo: $env:COMPUTERNAME    Fecha: $(Get-Date)" -ForegroundColor White
Write-Host "Modo: $(if ($Limpiar) { 'LIMPIEZA (se borra/detiene todo lo detectado)' } else { 'SOLO DIAGNOSTICO (no borra nada)' })" -ForegroundColor $(if ($Limpiar) { "Red" } else { "Yellow" })

$esAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltinRole]::Administrator
)

if (-not $esAdmin) {
    Write-Host ""
    Write-Host "AVISO: no se esta ejecutando como Administrador. La limpieza puede" -ForegroundColor Yellow
    Write-Host "fallar (tareas programadas, procesos protegidos). Cierra y vuelve a" -ForegroundColor Yellow
    Write-Host "abrir PowerShell con 'Ejecutar como administrador'." -ForegroundColor Yellow
}

# Nombres de proceso tipicos de minero (ampliable).
$NombresMinero = @(
    "gtservices", "xmrig", "xmr-stak", "cpuminer", "minerd", "ccminer",
    "nheqminer", "ethminer", "t-rex", "phoenixminer", "lolminer", "nbminer",
    "srbminer", "cryptonight", "wincpu", "cnminer", "gminer",
    "xmrig-cuda", "teamredminer"
)

# Rutas/carpetas conocidas de este incidente (persistencia disfrazada).
$CarpetasConocidas = @(
    "C:\Perform",
    "C:\Netframework.4.5.2"
)

# Patrones de script/relanzador conocidos (para matar procesos que los
# ejecutan: cmd.exe /c "<algo>.bat", wscript "<algo>.vbs", etc.).
$PatronesScript = "Perform|Netframework|system\.bat|Audio system|gtservices|mouse\.bat|mouse\.exe"


# ---------------------------------------------------------------------------
Section "1) Procesos del minero y de los scripts que lo relanzan"
# ---------------------------------------------------------------------------

$procesosMinero = Get-Process | Where-Object {
    $nombre = $_.ProcessName.ToLower()
    $NombresMinero | Where-Object { $nombre -like "*$_*" }
}

$procesosScript = Get-CimInstance Win32_Process | Where-Object {
    $_.CommandLine -match $PatronesScript
}

$todosLosProcesos = @()
if ($procesosMinero) { $todosLosProcesos += $procesosMinero | Select-Object Name, Id, @{n = "CommandLine"; e = { $_.Path } } }
if ($procesosScript) { $todosLosProcesos += $procesosScript | Select-Object ProcessName, ProcessId, CommandLine | Select-Object @{n = "Name"; e = { $_.ProcessName } }, @{n = "Id"; e = { $_.ProcessId } }, CommandLine }

if ($todosLosProcesos) {

    $todosLosProcesos | Format-Table -AutoSize
    Write-Host "Se encontraron procesos del minero o de sus scripts de relanzamiento." -ForegroundColor Red

    if ($Limpiar) {

        if ($procesosMinero) {
            $procesosMinero | ForEach-Object {
                Write-Host "  Deteniendo $($_.ProcessName) (PID $($_.Id))" -ForegroundColor Red
                Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
            }
        }

        if ($procesosScript) {
            $procesosScript | ForEach-Object {
                Write-Host "  Deteniendo PID $($_.ProcessId): $($_.CommandLine)" -ForegroundColor Red
                Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
            }
        }

        Start-Sleep -Seconds 2

    }

} else {

    Write-Host "No hay procesos del minero ni de sus scripts corriendo ahora." -ForegroundColor Green

}


# ---------------------------------------------------------------------------
Section "2) Tareas programadas sospechosas"
# ---------------------------------------------------------------------------
# Ademas de buscar por nombre, se revisa el CONTENIDO de la accion de cada
# tarea (a veces el nombre visible es inocuo, tipo "Proxy", pero ejecuta un
# script desde una carpeta de persistencia).

$tareasSospechosas = Get-ScheduledTask | Where-Object {
    $accion = ($_.Actions | Out-String)
    ($accion -match $PatronesScript) -or
    ($_.TaskPath -like "*Autochk*") -or
    ($_.TaskName -match "audio|proxy|gtservices")
}

if ($tareasSospechosas) {

    $tareasSospechosas | ForEach-Object {
        [PSCustomObject]@{
            Tarea  = $_.TaskName
            Ruta   = $_.TaskPath
            Accion = ($_.Actions | Out-String).Trim()
        }
    } | Format-List

    Write-Host "Se encontraron tareas programadas sospechosas." -ForegroundColor Red

    if ($Limpiar) {

        $tareasSospechosas | ForEach-Object {
            Write-Host "  Eliminando tarea: $($_.TaskPath)$($_.TaskName)" -ForegroundColor Red
            Unregister-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -Confirm:$false -ErrorAction SilentlyContinue
        }

    }

} else {

    Write-Host "No se encontraron tareas programadas sospechosas." -ForegroundColor Green

}


# ---------------------------------------------------------------------------
Section "3) Carpetas de persistencia conocidas"
# ---------------------------------------------------------------------------

$carpetasEncontradas = $CarpetasConocidas | Where-Object { Test-Path $_ }

if ($carpetasEncontradas) {

    $carpetasEncontradas | ForEach-Object { Write-Host "  Encontrada: $_" -ForegroundColor Red }

    if ($Limpiar) {

        $carpetasEncontradas | ForEach-Object {
            Write-Host "  Borrando: $_" -ForegroundColor Red
            Remove-Item $_ -Recurse -Force -ErrorAction SilentlyContinue
            if (Test-Path $_) {
                Write-Host "    No se pudo borrar completo (puede seguir bloqueada por un proceso)." -ForegroundColor Yellow
                Write-Host "    Vuelve a correr el script con -Limpiar una segunda vez." -ForegroundColor Yellow
            } else {
                Write-Host "    Eliminada correctamente." -ForegroundColor Green
            }
        }

    }

} else {

    Write-Host "No se encontraron las carpetas de persistencia conocidas (C:\Perform, C:\Netframework.4.5.2)." -ForegroundColor Green

}


# ---------------------------------------------------------------------------
Section "4) KMSPico y activadores piratas (puerta de entrada tipica de este malware)"
# ---------------------------------------------------------------------------
# Este malware suele venir empaquetado dentro de instaladores piratas
# (activadores de Windows/Office, "Adobe pack", etc.). KMSPico en
# particular aparece con frecuencia junto a este minero.

$kmspico = Get-ItemProperty @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
) -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match "KMSPico|KMS Pico|KMSAuto" }

$carpetaKms = @("C:\Program Files\KMSPico", "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\KMSPico") |
    Where-Object { Test-Path $_ }

if ($kmspico -or $carpetaKms) {

    if ($kmspico) { $kmspico | Select-Object DisplayName, DisplayVersion | Format-Table -AutoSize }
    if ($carpetaKms) { $carpetaKms | ForEach-Object { Write-Host "  Carpeta: $_" -ForegroundColor Red } }

    Write-Host "Se encontro KMSPico/activador pirata instalado. Se recomienda" -ForegroundColor Yellow
    Write-Host "desinstalarlo manualmente desde 'Agregar o quitar programas'" -ForegroundColor Yellow
    Write-Host "(este script no lo desinstala automaticamente por seguridad)." -ForegroundColor Yellow

} else {

    Write-Host "No se encontro KMSPico ni activadores piratas conocidos." -ForegroundColor Green

}


# ---------------------------------------------------------------------------
Section "5) Archivo hosts (algunos mineros/adware lo modifican)"
# ---------------------------------------------------------------------------

$hostsPath = "$env:WINDIR\System32\drivers\etc\hosts"
$hostsLineas = Get-Content $hostsPath -ErrorAction SilentlyContinue |
    Where-Object { $_ -and -not $_.TrimStart().StartsWith("#") }

if ($hostsLineas) {
    Write-Host "Lineas activas (no comentarios) en el archivo hosts:" -ForegroundColor Yellow
    $hostsLineas | ForEach-Object { Write-Host "  $_" }
    Write-Host "Revisa que cada linea sea legitima (normalmente el archivo esta vacio de reglas)." -ForegroundColor Yellow
} else {
    Write-Host "El archivo hosts no tiene reglas activas (normal)." -ForegroundColor Green
}


# ---------------------------------------------------------------------------
Section "Resultado"
# ---------------------------------------------------------------------------

if (-not $Limpiar) {

    Write-Host ""
    Write-Host "Este fue un diagnostico. Si viste elementos en rojo arriba, corre:" -ForegroundColor Cyan
    Write-Host "    .\limpiador_gtservices.ps1 -Limpiar" -ForegroundColor White
    Write-Host "para eliminarlos de verdad." -ForegroundColor Cyan

} else {

    Write-Host ""
    Write-Host "Limpieza ejecutada. Verificacion final:" -ForegroundColor Cyan

    $quedaProceso = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match $PatronesScript }
    $quedaCarpeta = $CarpetasConocidas | Where-Object { Test-Path $_ }
    $quedaTarea = Get-ScheduledTask | Where-Object {
        $accion = ($_.Actions | Out-String)
        ($accion -match $PatronesScript) -or ($_.TaskPath -like "*Autochk*")
    }

    if (-not $quedaProceso -and -not $quedaCarpeta -and -not $quedaTarea) {
        Write-Host "LIMPIO: no quedan procesos, carpetas ni tareas del malware conocido." -ForegroundColor Green
    } else {
        Write-Host "AVISO: todavia queda algo. Vuelve a correr '.\limpiador_gtservices.ps1 -Limpiar'." -ForegroundColor Red
        if ($quedaProceso) { $quedaProceso | Select-Object ProcessId, CommandLine | Format-Table -AutoSize }
        if ($quedaCarpeta) { $quedaCarpeta | ForEach-Object { Write-Host "  Carpeta: $_" -ForegroundColor Red } }
        if ($quedaTarea) { $quedaTarea | ForEach-Object { Write-Host "  Tarea: $($_.TaskPath)$($_.TaskName)" -ForegroundColor Red } }
    }

    Write-Host ""
    Write-Host "Pasos que siguen (manuales, recomendados):" -ForegroundColor Cyan
    Write-Host "  1. Analisis completo con Windows Defender: Start-MpScan -ScanType FullScan"
    Write-Host "  2. Si se detecto KMSPico arriba, desinstalalo desde 'Agregar o quitar programas'."
    Write-Host "  3. Cambia las contrasenas usadas desde este equipo, desde OTRO equipo limpio."

}
