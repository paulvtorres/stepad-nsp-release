import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getFirewallHardening,
    setFirewallHardening,
    markFirewallReview,
    markAccessReview,
    saveAccessWindow
} from "../../../services/api";

import { formatDate } from "../../../utils/datetime";


function FirewallHardening() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);

    const [busy, setBusy] = useState(false);

    const [error, setError] = useState(null);


    async function load() {

        try {

            const data = await getFirewallHardening();

            setStatus(data);

        } catch (err) {

            setError(err.message);

        }

    }


    useEffect(() => {

        load();

    }, []);


    useEffect(() => {

        if (status?.admin_access_window) {

            setWinStartHour(
                status.admin_access_window.start_hour ?? ""
            );

            setWinEndHour(
                status.admin_access_window.end_hour ?? ""
            );

        }

    }, [status]);


    async function handleToggle(enabled) {

        if (enabled) {

            const ok = window.confirm(
                "Activar DENY-ALL: se bloqueará TODO el acceso entrante " +
                "desde Internet (incluido SSH), permitiendo solo tráfico " +
                "establecido, salida de la red y acceso por LAN/VPN. " +
                "¿Continuar?"
            );

            if (!ok) return;

        }

        setBusy(true);

        try {

            await setFirewallHardening(enabled);

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleReview() {

        setBusy(true);

        try {

            await markFirewallReview();

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const enabled = status?.hardening_enabled ?? false;

    const applied = status?.applied ?? false;

    const overdue = status?.review_overdue ?? false;

    const lastReview = status?.last_review;

    const accessOverdue = status?.access_review?.overdue ?? false;

    const accessLastReview = status?.access_review?.last_review;

    const winStart = status?.admin_access_window?.start_hour ?? "";

    const winEnd = status?.admin_access_window?.end_hour ?? "";

    const [winStartHour, setWinStartHour] = useState(winStart);

    const [winEndHour, setWinEndHour] = useState(winEnd);


    async function handleSaveWindow() {

        setBusy(true);

        try {

            await saveAccessWindow(
                winStartHour === "" ? null : Number(winStartHour),
                winEndHour === "" ? null : Number(winEndHour)
            );

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleAccessReview() {

        setBusy(true);

        try {

            await markAccessReview();

            await load();

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    return (

        <div className="domain-rules">

            <h3>Hardening del firewall (deny-all)</h3>

            <p className="security-description" style={{ marginTop: 0 }}>
                Política de seguridad por defecto: denegar todo lo que no
                esté explícitamente permitido. Protege el equipo de
                administración y la red del acceso entrante desde Internet.
            </p>

            {
                error && (
                    <div className="maintenance-error" style={{ marginBottom: 12 }}>
                        {error}
                    </div>
                )
            }

            <div className="hardening-row">

                <div className="hardening-info">

                    <strong>Deny-all por defecto</strong>

                    <div className="hardening-meta">
                        {
                            applied
                                ? "Aplicado: solo tráfico establecido, salida LAN/VPN y DNS/DHCP permitidos."
                                : "No aplicado: la política permite todo por defecto."
                        }
                    </div>

                </div>

                {
                    isAdmin && (
                        <button
                            className={`category-toggle ${enabled ? "on" : ""}`}
                            onClick={() => handleToggle(!enabled)}
                            disabled={busy}
                        >
                            {enabled ? "Desactivar" : "Activar"}
                        </button>
                    )
                }

            </div>

            <hr className="hardening-divider" />

            <div className="hardening-row">

                <div className="hardening-info">

                    <strong>Revisión periódica de reglas</strong>

                    <div className="hardening-meta">
                        Última revisión:{" "}
                        {lastReview
                            ? formatDate(lastReview)
                            : "nunca"}
                        {" "}· se recomienda cada 6 meses.
                    </div>

                    {
                        overdue && (
                            <div className="hardening-overdue">
                                ⚠ Revisión de reglas pendiente (más de 6 meses).
                            </div>
                        )
                    }

                </div>

                {
                    isAdmin && (
                        <button
                            className="secondary-button small"
                            onClick={handleReview}
                            disabled={busy}
                        >
                            Marcar revisión
                        </button>
                    )
                }

            </div>

            <hr className="hardening-divider" />

            <div className="hardening-row">

                <div className="hardening-info">

                    <strong>Revisión de accesos administrativos</strong>

                    <div className="hardening-meta">
                        Última revisión:{" "}
                        {accessLastReview
                            ? formatDate(accessLastReview)
                            : "nunca"}
                        {" "}· se recomienda cada 6 meses.
                    </div>

                    {
                        accessOverdue && (
                            <div className="hardening-overdue">
                                ⚠ Revisión de accesos pendiente (más de 6 meses).
                            </div>
                        )
                    }

                </div>

                {
                    isAdmin && (
                        <button
                            className="secondary-button small"
                            onClick={handleAccessReview}
                            disabled={busy}
                        >
                            Marcar revisión
                        </button>
                    )
                }

            </div>

            <hr className="hardening-divider" />

            <div className="hardening-info">

                <strong>Horario de acceso administrativo</strong>

                <div className="hardening-meta">
                    Fuera de esta ventana se rechaza el inicio de sesión
                    (déjalo vacío para permitir siempre).
                </div>

            </div>

            <div className="hardening-window">

                <label>
                    Desde (hora 0-23)
                    <input
                        type="number"
                        min="0"
                        max="23"
                        value={winStartHour}
                        onChange={(e) => setWinStartHour(e.target.value)}
                        disabled={busy || !isAdmin}
                    />
                </label>

                <label>
                    Hasta (hora 0-23)
                    <input
                        type="number"
                        min="0"
                        max="23"
                        value={winEndHour}
                        onChange={(e) => setWinEndHour(e.target.value)}
                        disabled={busy || !isAdmin}
                    />
                </label>

                {
                    isAdmin && (
                        <button
                            className="primary-button small"
                            onClick={handleSaveWindow}
                            disabled={busy}
                        >
                            Guardar horario
                        </button>
                    )
                }

            </div>

        </div>

    );

}


export default FirewallHardening;
