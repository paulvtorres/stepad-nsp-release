"""Deriva presencia y conflicto de IP a partir de observaciones.

Los escritores solo dejan observaciones (ARP/lease/DNS). Este servicio
es el único que materializa `current_ip`, `presence_status` y
`ip_conflict`; el listado de dispositivos solo lee.
"""

import subprocess
from pathlib import Path

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.session import SessionLocal
from backend.dhcp.domain.leases import read_leases
from backend.dhcp.domain.neighbors import arp_mac_by_ip
from backend.network.devices.models.device_ip_observation import (
    DeviceIpObservation,
)
from backend.network.devices.models.network_device import NetworkDevice
from backend.network.devices.services.ip_history_service import (
    IpHistoryService,
)
from backend.shared.datetime_utils import utcnow
from backend.shared.logging.logger import logger


ONLINE = "ONLINE"
PROBABLE = "PROBABLE"
OFFLINE = "OFFLINE"
UNKNOWN = "UNKNOWN"


class DevicePresenceService:

    def record_observation(
        self,
        db,
        mac_address,
        ip_address,
        source,
        expires_at=None,
    ):
        mac = (mac_address or "").lower().strip()
        ip = (ip_address or "").strip()

        if not mac or not ip:
            return None

        row = (
            db.query(DeviceIpObservation)
            .filter(
                DeviceIpObservation.mac_address == mac,
                DeviceIpObservation.ip_address == ip,
                DeviceIpObservation.source == source,
            )
            .first()
        )

        if row is None:
            row = DeviceIpObservation(
                mac_address=mac,
                ip_address=ip,
                source=source,
            )
            db.add(row)

        row.observed_at = utcnow()
        row.expires_at = expires_at

        return row

    def _active_leases(self):
        import time

        now = int(time.time())
        result = {}

        for lease in read_leases(DNSMASQ_LEASES_FILE):
            if lease.infinite or lease.expires_at > now:
                result[(lease.mac or "").lower()] = lease.ip

        return result

    def _arp(self):
        """MAC -> {ip, state} usando `ip neigh`."""

        result = {}

        try:
            proc = subprocess.run(
                ["ip", "neigh", "show"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in proc.stdout.splitlines():
                parts = line.split()
                if len(parts) < 4 or "lladdr" not in parts:
                    continue
                ip = parts[0]
                try:
                    mac = parts[parts.index("lladdr") + 1].lower()
                except (ValueError, IndexError):
                    continue
                state = parts[-1].upper()
                result[mac] = {"ip": ip, "state": state}
        except (OSError, subprocess.SubprocessError):
            pass

        if result:
            return result

        # Fallback para sistemas sin `ip neigh`.
        try:
            return {
                (mac or "").lower(): {"ip": ip, "state": "UNKNOWN"}
                for ip, mac in arp_mac_by_ip(
                    Path("/proc/net/arp").read_text(encoding="utf-8")
                ).items()
            }
        except OSError:
            return {}

    def reconcile(self, db=None) -> dict:
        own = db is None
        if own:
            db = SessionLocal()

        try:
            leases = self._active_leases()
            arp = self._arp()
            devices = db.query(NetworkDevice).all()
            by_mac = {
                (device.mac_address or "").lower(): device
                for device in devices
            }

            # Observaciones: el lease manda sobre ARP para la IP actual,
            # pero ambas se guardan para poder explicar la presencia.
            for mac, ip in leases.items():
                self.record_observation(db, mac, ip, "lease")

            for mac, info in arp.items():
                ip = info.get("ip")
                state = info.get("state", "UNKNOWN")
                if ip and state not in ("FAILED", "INCOMPLETE"):
                    self.record_observation(
                        db,
                        mac,
                        ip,
                        "arp_reachable" if state in (
                            "REACHABLE", "DELAY", "PROBE", "PERMANENT"
                        ) else "arp_stale",
                    )

            owners_by_ip = {}
            for mac, ip in leases.items():
                owners_by_ip.setdefault(ip, set()).add(mac)
            for mac, info in arp.items():
                ip = info.get("ip")
                state = info.get("state", "UNKNOWN")
                if ip and state not in ("FAILED", "INCOMPLETE"):
                    owners_by_ip.setdefault(ip, set()).add(mac)

            conflict_ips = {
                ip for ip, macs in owners_by_ip.items() if len(macs) > 1
            }

            if conflict_ips:
                try:
                    from backend.alerts.services.alert_service import AlertService

                    for ip in conflict_ips:
                        macs = sorted(owners_by_ip[ip])
                        AlertService().create(
                            db,
                            alert_type="DHCP_IP_DUPLICATE_ACTIVE",
                            severity="critical",
                            title=f"IP duplicada activa: {ip}",
                            message=(
                                f"Hay más de un equipo observado con {ip}: "
                                + ", ".join(macs)
                                + ". Revisar si es un conflicto real; "
                                "la lista no oculta el conflicto."
                            ),
                        )
                except Exception as error:
                    logger.debug("device_presence_service alert: %s", error)

            for mac, device in by_mac.items():
                lease_ip = leases.get(mac)
                arp_info = arp.get(mac) or {}
                arp_state = arp_info.get("state", "UNKNOWN")
                arp_ip = (
                    arp_info.get("ip")
                    if arp_state not in ("FAILED", "INCOMPLETE")
                    else None
                )
                current = lease_ip or arp_ip or ""

                if lease_ip:
                    source = "lease"
                    presence = ONLINE
                elif arp_ip and arp_state in (
                    "REACHABLE", "DELAY", "PROBE", "PERMANENT"
                ):
                    source = "arp"
                    presence = ONLINE
                elif arp_ip and arp_state == "STALE":
                    source = "arp_stale"
                    presence = PROBABLE
                elif arp_ip:
                    source = "arp"
                    presence = OFFLINE
                else:
                    source = None
                    presence = OFFLINE if device.last_seen else UNKNOWN

                conflict = bool(
                    current and len(owners_by_ip.get(current, ())) > 1
                )

                previous = device.current_ip or ""

                if previous and previous != current:
                    IpHistoryService().record_closed(
                        db, device, previous, "presence"
                    )

                if current:
                    device.last_ip = current

                device.current_ip = current
                device.presence_source = source
                device.presence_at = utcnow() if current else device.presence_at
                device.presence_status = presence
                device.ip_conflict = conflict

                # `ip_address` queda como campo legado de última IP. La
                # verdad actual está en `current_ip`; no se pisa aquí.

                db.add(device)

            db.commit()

            return {
                "success": True,
                "devices": len(devices),
                "conflicts": sum(
                    1 for device in devices if device.ip_conflict
                ),
            }

        except Exception:
            db.rollback()
            raise
        finally:
            if own:
                db.close()
