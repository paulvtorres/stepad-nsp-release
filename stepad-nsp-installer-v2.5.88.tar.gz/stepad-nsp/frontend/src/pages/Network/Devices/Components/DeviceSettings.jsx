import { useEffect, useState } from "react";

import { getZones, updateDevice, refreshDevice, getIpPool } from "../../../../services/api";


function DeviceSettings({ device }) {

    const [zones, setZones] = useState([]);

    const [bandwidthMbps, setBandwidthMbps] = useState("");

    const [zoneId, setZoneId] = useState("");

    const [isPermanent, setIsPermanent] = useState(false);
    const [formIp, setFormIp] = useState("");
    const [ipPool, setIpPool] = useState(null);
    const [busy, setBusy] = useState(false);

    const [notice, setNotice] = useState(null);

    const [error, setError] = useState(null);


    useEffect(() => {

        getZones()

            .then(setZones)

            .catch(() => {});

    }, []);


    useEffect(() => {

        if (device) {

            setBandwidthMbps(
                device.bandwidth_limit_kbps
                    ? (device.bandwidth_limit_kbps / 1000)
                    : ""
            );

            setZoneId(device.zone_id || "");
            setIsPermanent(Boolean(device.is_permanent));
            setFormIp(device.ip_address || "");

        }

    }, [device?.id]);


    if (!device) {

        return <p>Selecciona un dispositivo...</p>;

    }


    async function handleSave() {

        setBusy(true);

        setError(null);

        setNotice(null);

        const kbps = bandwidthMbps === "" ? null : (Number(bandwidthMbps) * 1000);

        if (kbps !== null && (!Number.isFinite(kbps) || kbps <= 0)) {

            setError("Ingresa un valor válido en Mbps.");

            setBusy(false);

            return;

        }

        try {

            await updateDevice(device.id, {
                zone_id: zoneId ? Number(zoneId) : null,
                bandwidth_limit_kbps: kbps,
                is_permanent: isPermanent,
                ip_address: isPermanent && formIp ? formIp : device.ip_address
            });

            setNotice("Configuración guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleRefresh() {

        setBusy(true);

        setError(null);

        setNotice(null);

        try {

            const result = await refreshDevice(device.id);

            setNotice(
                result?.message || "Dispositivo actualizado."
            );

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function loadIpPool() {
            try {
                const data = await getIpPool();
                setIpPool(data);
            } catch {
                setIpPool(null);
            }
        }

    return (

        <div className="card">

            <h3>Configuración del dispositivo</h3>

            {
                error && (
                    <div className="maintenance-error" style={{ marginBottom: 12 }}>
                        {error}
                    </div>
                )
            }

            {
                notice && (
                    <div className="notification-ok">{notice}</div>
                )
            }

            <table>

                <tbody>

                    <tr>
                        <td style={{ width: 220 }}>Nombre de equipo</td>
                        <td>{device.hostname || "-"}</td>
                    </tr>

                    <tr>
                        <td>Tipo</td>
                        <td>{device.device_type || "-"}</td>
                    </tr>

                    <tr>
                        <td>Estado</td>
                        <td>{device.status || "-"}</td>
                    </tr>

                    <tr>
                        <td>Dirección MAC</td>
                        <td>{device.mac_address || "-"}</td>
                    </tr>

                    <tr>
                        <td>Dirección IP</td>
                        <td>{device.ip_address || "-"}</td>
                    </tr>

                    <tr>
                        <td>Interfaz</td>
                        <td>{device.interface || "-"}</td>
                    </tr>

                </tbody>

            </table>

            <h4 style={{ margin: "16px 0 8px" }}>Zona</h4>

            <select
                value={zoneId}
                onChange={(e) => setZoneId(e.target.value)}
                disabled={busy}
            >
                <option value="">Sin asignar</option>
                {
                    zones.map((zone) => (
                        <option key={zone.id} value={zone.id}>
                            {zone.name}
                            {zone.is_default ? " (default)" : ""}
                        </option>
                    ))
                }
            </select>

            <h4 style={{ margin: "16px 0 8px" }}>Ancho de banda (Mbps)</h4>

            <input
                type="number"
                min="1"
                placeholder="Mbps (vacío = sin límite)"
                value={bandwidthMbps}
                onChange={(e) => setBandwidthMbps(e.target.value)}
                disabled={busy}
                style={{ width: 220 }}
            />

            <h4 style={{ margin: "16px 0 8px" }}>Reserva IP</h4>

            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: "0.9rem" }}>
                <input
                    type="checkbox"
                    checked={isPermanent}
                    onChange={(e) => {
                        setIsPermanent(e.target.checked);
                        if (e.target.checked && !ipPool) loadIpPool();
                    }}
                    disabled={busy}
                />
                IP permanente (reserva fija — nunca se limpia automáticamente)
            </label>

            {isPermanent && ipPool && (
                <div style={{ marginTop: 8, padding: 8, border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, fontSize: "0.85rem" }}>
                    <p style={{ margin: "0 0 6px", fontWeight: 600 }}>IPs libres en el pool ({ipPool.free_count}):</p>
                    <div style={{ maxHeight: 120, overflowY: "auto", display: "flex", flexWrap: "wrap", gap: 4 }}>
                        {ipPool.free_ips.map((ip) => (
                            <span
                                key={ip}
                                onClick={() => setFormIp(ip)}
                                style={{
                                    padding: "2px 6px",
                                    borderRadius: 4,
                                    cursor: "pointer",
                                    background: formIp === ip ? "rgba(34,197,94,0.3)" : "rgba(255,255,255,0.05)",
                                    border: "1px solid " + (formIp === ip ? "rgba(34,197,94,0.5)" : "rgba(255,255,255,0.1)"),
                                    color: formIp === ip ? "#86efac" : "#94a3b8",
                                    fontSize: "0.8rem"
                                }}
                            >
                                {ip}
                            </span>
                        ))}
                    </div>
                    {ipPool.offline_ips.length > 0 && (
                        <>
                            <p style={{ margin: "8px 0 4px", fontWeight: 600, color: "#fbbf24" }}>IPs de equipos apagados ({ipPool.offline_ips.length}):</p>
                            <div style={{ maxHeight: 80, overflowY: "auto" }}>
                                {ipPool.offline_ips.map((d) => (
                                    <div
                                        key={d.id}
                                        onClick={() => setFormIp(d.ip)}
                                        style={{
                                            padding: "2px 6px",
                                            borderRadius: 4,
                                            cursor: "pointer",
                                            background: formIp === d.ip ? "rgba(251,191,36,0.2)" : "transparent",
                                            border: "1px solid " + (formIp === d.ip ? "rgba(251,191,36,0.4)" : "transparent"),
                                            fontSize: "0.8rem"
                                        }}
                                    >
                                        {d.ip} — {d.hostname} (apagado)
                                    </div>
                                ))}
                            </div>
                        </>
                    )}
                    <input
                        type="text"
                        placeholder="O escribí una IP manualmente"
                        value={formIp}
                        onChange={(e) => setFormIp(e.target.value)}
                        disabled={busy}
                        style={{ width: "100%", marginTop: 6, padding: "4px 8px", fontSize: "0.85rem", boxSizing: "border-box" }}
                    />
                </div>
            )}

            <div className="confirm-actions" style={{ marginTop: 18 }}>

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={busy}
                >
                    {busy ? "Guardando..." : "Guardar"}
                </button>

                <button
                    className="secondary-button"
                    onClick={handleRefresh}
                    disabled={busy}
                >
                    Actualizar datos del equipo
                </button>

            </div>

        </div>

    );

}


export default DeviceSettings;
