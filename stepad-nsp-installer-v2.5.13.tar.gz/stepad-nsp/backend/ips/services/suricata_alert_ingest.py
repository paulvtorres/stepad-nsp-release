import json
import time

from pathlib import Path

from backend.core.database.session import SessionLocal

from backend.alerts.services.alert_service import AlertService

from backend.notifications.services.email_service import EmailService

from backend.notifications.repositories.notification_settings_repository import (
    NotificationSettingsRepository
)

from backend.siem.services.syslog_service import SyslogService

from backend.shared.logging.logger import logger

from backend.ips.services.threat_response_service import (
    threat_response_service
)


EVE_LOG = Path("/var/log/suricata/eve.json")

STATE_FILE = Path("/etc/stepad/ips/eve_offset")

DEDUPE_WINDOW_SECONDS = 1800

POLL_INTERVAL = 20


class SuricataAlertIngest:


    def __init__(self):

        self.alert_service = AlertService()

        self.email_service = EmailService()

        self.notification_repo = NotificationSettingsRepository()

        self.syslog_service = SyslogService()

        self._recent = {}

        self._offset = 0

        self._load_offset()


    def _load_offset(self):

        try:

            self._offset = int(
                STATE_FILE.read_text().strip()
            )

        except Exception:

            # Primera vez: empezar desde el final del archivo para no
            # ingestar el historial anterior a la instalacion.
            try:

                if EVE_LOG.exists():

                    self._offset = EVE_LOG.stat().st_size

            except Exception:

                self._offset = 0


    def _save_offset(self):

        try:

            STATE_FILE.parent.mkdir(
                parents=True,
                exist_ok=True
            )

            STATE_FILE.write_text(str(self._offset))

        except Exception as error:

            logger.warning(
                "No pude guardar el offset de eve.json: %s",
                error
            )


    def _severity(
        self,
        suricata_severity
    ):

        mapping = {
            1: "critical",
            2: "warning",
        }

        return mapping.get(suricata_severity, "info")


    def _process_event(
        self,
        event
    ):

        if event.get("event_type") != "alert":

            return

        alert = event.get("alert", {})

        signature = alert.get("signature", "Deteccion IPS")

        category = alert.get("category", "")

        src_ip = event.get("src_ip", "")

        dst_ip = event.get("dest_ip", "")

        dst_port = event.get("dest_port", "")

        key = (
            signature,
            src_ip,
            dst_ip
        )

        now = time.time()

        last = self._recent.get(key)

        if last and now - last < DEDUPE_WINDOW_SECONDS:

            return

        self._recent[key] = now

        severity = self._severity(alert.get("severity"))

        title = f"IPS: {signature}"[:255]

        message = (
            f"{signature} | {category} | "
            f"{src_ip} -> {dst_ip}:{dst_port}"
        )[:500]

        db = SessionLocal()

        try:

            try:

                threat_response_service.handle_event(db, event)

            except Exception as error:

                logger.exception(
                    "Fallo la respuesta ante amenazas: %s",
                    error
                )

            self.alert_service.create(
                db,
                alert_type="suricata",
                severity=severity,
                title=title,
                message=message
            )

            try:

                self.syslog_service.forward_ips_alert(
                    db,
                    event,
                    severity,
                )

            except Exception as error:

                logger.warning(
                    "Fallo reenvio syslog de alerta IPS: %s",
                    error,
                )

        finally:

            db.close()

        threat_response_service.resync_if_stale()

        if severity == "critical":

            self._notify_critical(title, message)


    def _notify_critical(
        self,
        title: str,
        message: str
    ):

        try:

            db = SessionLocal()

            try:

                settings = self.notification_repo.get(db)

                if settings.enabled:

                    self.email_service.send_html(
                        settings,
                        title,
                        f"<h3>{title}</h3><pre>{message}</pre>"
                    )

            finally:

                db.close()

        except Exception as error:

            logger.error(
                "Fallo la notificacion critica del IPS: %s",
                error
            )


    def poll_once(self):

        try:

            if not EVE_LOG.exists():

                return

            size = EVE_LOG.stat().st_size

            if size <= self._offset:

                return

            with open(EVE_LOG, "r") as file:

                file.seek(self._offset)

                for line in file:

                    line = line.strip()

                    if not line:

                        continue

                    try:

                        event = json.loads(line)

                    except ValueError:

                        continue

                    self._process_event(event)

                self._offset = file.tell()

            self._save_offset()

        except Exception as error:

            logger.error(
                "Error al leer eve.json de Suricata: %s",
                error
            )


    def run_forever(self):

        logger.info(
            "Ingesta de alertas Suricata iniciada (eve.json)."
        )

        while True:

            try:

                self.poll_once()

            except Exception as error:

                logger.exception(
                    "Error en el bucle de Suricata: %s",
                    error
                )

            time.sleep(POLL_INTERVAL)
