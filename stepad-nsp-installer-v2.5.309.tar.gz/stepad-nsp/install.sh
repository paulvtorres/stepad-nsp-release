#!/usr/bin/env bash
#
# STEPAD NSP - instalador para Debian 12 limpio.
#
# Uso (como root, DENTRO de la carpeta del repositorio):
#   sudo bash install.sh
#
# Hace TODO automáticamente y al final imprime cómo entrar a la web
# y las credenciales iniciales.
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

APP_USER="${APP_USER:-paulan}"
REPO_URL="${REPO_URL:-git@github.com:paulvtorres/stepad-nsp.git}"
REPO_BRANCH="${REPO_BRANCH:-main}"
# Tailscale se instala SIEMPRE con el instalador para poder
# administrar el NSP remotamente. Si pones STEPAD_TAILSCALE_KEY
# (pre-auth key), además se une a tu red Tailscale automáticamente.
TAILSCALE_KEY="${STEPAD_TAILSCALE_KEY:-}"
TAILSCALE_HOSTNAME="${STEPAD_HOSTNAME:-stepad-nsp}"
# Zona horaria del NSP (ej. STEPAD_TIMEZONE=America/Guayaquil). Si no
# se indica, se deja la del sistema.
STEPAD_TIMEZONE="${STEPAD_TIMEZONE:-}"

if [ "$(id -u)" -ne 0 ]; then
    echo "Ejecuta como root: sudo bash install.sh"
    exit 1
fi

# Fijar zona horaria si se indico (para que los logs del sistema y el
# NSP muestren la hora local del cliente).
if [ -n "${STEPAD_TIMEZONE}" ]; then
    echo "==> Fijando zona horaria: ${STEPAD_TIMEZONE}"
    timedatectl set-timezone "${STEPAD_TIMEZONE}" 2>/dev/null \
        || ln -sfn "/usr/share/zoneinfo/${STEPAD_TIMEZONE}" /etc/localtime
fi

# Marcador de apagado limpio: permite detectar reinicios repentinos
# (corte de energia, crash). Se escribe al apagarse de forma normal y
# el NSP lo comprueba al arrancar (RebootTracker).
cat > /usr/local/bin/stepad-clean-shutdown.sh <<'EOF'
#!/bin/bash
mkdir -p /etc/stepad
date -Iseconds > /etc/stepad/.clean_shutdown
EOF
chmod +x /usr/local/bin/stepad-clean-shutdown.sh

 cat > /etc/systemd/system/stepad-clean-shutdown.service <<'EOF'
[Unit]
Description=STEPAD clean shutdown marker
DefaultDependencies=false
Before=shutdown.target reboot.target halt.target kexec.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/true
ExecStop=/usr/local/bin/stepad-clean-shutdown.sh

[Install]
WantedBy=multi-user.target
EOF
 systemctl daemon-reload
systemctl enable stepad-clean-shutdown.service >/dev/null 2>&1 || true
systemctl start stepad-clean-shutdown.service >/dev/null 2>&1 || true

# Feed diario de malware/phishing (URLhaus + OpenPhish): mantiene la
# lista de dominios maliciosos actualizada (diario a las 03:40).
cat > /usr/local/bin/stepad-malware-feed.sh <<'EOF'
#!/bin/bash
export $(grep -v "^#" /etc/stepad/stepad.env | xargs) 2>/dev/null
cd /home/paulan/stepad-nsp
.venv/bin/python3 -c "from backend.content.services.malware_feed_service import MalwareFeedService; print(MalwareFeedService().refresh())" >> /tmp/malware-feed.log 2>&1
EOF
chmod +x /usr/local/bin/stepad-malware-feed.sh

cat > /etc/systemd/system/stepad-malware-feed.service <<'EOF'
[Unit]
Description=STEPAD malware/phishing DNS feed update
[Service]
Type=oneshot
ExecStart=/usr/local/bin/stepad-malware-feed.sh
EOF

cat > /etc/systemd/system/stepad-malware-feed.timer <<'EOF'
[Unit]
Description=STEPAD malware feed daily update
[Timer]
OnCalendar=*-*-* 03:40:00
Persistent=true
[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload
systemctl enable stepad-malware-feed.timer >/dev/null 2>&1 || true
systemctl start stepad-malware-feed.timer >/dev/null 2>&1 || true
# Primera carga inmediata (best-effort).
/usr/local/bin/stepad-malware-feed.sh || true

# Detectar si ya existe una versión instalada para advertir antes
# de actualizar (evita pisar una instalación sin avisar).
ALREADY_INSTALLED=0
if [ -f "/etc/stepad/stepad.env" ] || systemctl list-unit-files 2>/dev/null | grep -q "stepad-nsp.service"; then
    ALREADY_INSTALLED=1
fi

if [ "${ALREADY_INSTALLED}" = "1" ]; then
    echo ""
    echo "======================================================================"
    echo "⚠  YA EXISTE una versión de STEPAD NSP instalada en este equipo."
    echo "    El instalador la ACTUALIZARÁ manteniendo la configuración y datos."
    echo "======================================================================"
    echo ""
    if [ "${STEPAD_UPDATE:-0}" = "1" ]; then
        # Actualización disparada desde la web (ya confirmada por el admin).
        RESPUESTA=S
    elif [ -t 0 ]; then
        printf "¿Deseas continuar con la actualización? (S/N): "
        read -r RESPUESTA
    else
        # Sin terminal (p. ej. curl | sudo bash): continuar sin preguntar.
        RESPUESTA=S
    fi
    case "${RESPUESTA}" in
        [sS]|[sS][iI]|[yY]|[yY][eE][sS])
            echo ""
            echo "Continuando con la actualización..."
            ;;
        *)
            echo "Instalación cancelada."
            exit 1
            ;;
    esac
fi

# Si estamos dentro del código (paquete descargado o repo clonado),
# úsalo tal cual; si no, clónalo.
APP_DIR="/home/${APP_USER}/stepad-nsp"
# Si el instalador corre desde /tmp, copiar codigo al destino final
if [ "${SCRIPT_DIR}" != "${APP_DIR}" ] && [ -d "${SCRIPT_DIR}/backend" ]; then
    echo "    Copiando codigo de ${SCRIPT_DIR} a ${APP_DIR}..."
    cp -ru "${SCRIPT_DIR}/backend" "${APP_DIR}/"
    cp -ru "${SCRIPT_DIR}/frontend" "${APP_DIR}/"
    cp -ru "${SCRIPT_DIR}/scripts" "${APP_DIR}/"
    cp -ru "${SCRIPT_DIR}/docs" "${APP_DIR}/" 2>/dev/null
    cp -u "${SCRIPT_DIR}/install.sh" "${APP_DIR}/" 2>/dev/null
    cp -u "${SCRIPT_DIR}/install.py" "${APP_DIR}/" 2>/dev/null
    cp -u "${SCRIPT_DIR}/requirements.txt" "${APP_DIR}/" 2>/dev/null
    cp -u "${SCRIPT_DIR}/VERSION" "${APP_DIR}/" 2>/dev/null
    cp -u "${SCRIPT_DIR}/get-stepad.sh" "${APP_DIR}/" 2>/dev/null
    cp -u "${SCRIPT_DIR}/make-installer.sh" "${APP_DIR}/" 2>/dev/null
    cp -u "${SCRIPT_DIR}/alembic.ini" "${APP_DIR}/" 2>/dev/null
    chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"
    echo "    Codigo copiado a ${APP_DIR}"
fi

echo "==> [1/8] Usuario de aplicación"
id -u "${APP_USER}" >/dev/null 2>&1 || useradd -m -s /bin/bash "${APP_USER}"

echo "==> [2/8] Código"
if [ ! -d "${APP_DIR}/backend" ] || [ ! -f "${APP_DIR}/install.py" ]; then
    if [ ! -d "${APP_DIR}/.git" ]; then
        sudo -u "${APP_USER}" git clone -b "${REPO_BRANCH}" "${REPO_URL}" "${APP_DIR}"
    else
        sudo -u "${APP_USER}" git -C "${APP_DIR}" pull --ff-only origin "${REPO_BRANCH}"
    fi
fi
if [ "$(stat -c %U "${APP_DIR}")" != "${APP_USER}" ]; then
    chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"
fi

echo "==> [3/8] Dependencias del sistema"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y \
    git curl unzip build-essential \
    python3 python3-venv python3-pip \
    postgresql \
    wireguard-tools nftables dnsmasq pdns-recursor openssl \
    samba-common-bin samba parted smartmontools e2fsprogs xfsprogs \
    iproute2 ethtool iputils-ping rclone \
    restic \
    suricata suricata-update
# En maquina NUEVA postgres queda DETENIDO tras el apt-get install: si solo
# se habilita (enable) las proximas queries de install.py fallan con error
# de SQL (psql no conecta). Hay que arrancarlo y esperar a que este listo.
systemctl enable postgresql
systemctl start postgresql 2>/dev/null || true
for i in $(seq 1 30); do
    if command -v pg_isready >/dev/null 2>&1 && pg_isready -h 127.0.0.1 >/dev/null 2>&1; then
        break
    fi
    sleep 1
done
# Samba (disco de red): no arrancar hasta que el admin lo active en la UI.
systemctl stop smbd.service nmbd.service 2>/dev/null || true
systemctl disable smbd.service nmbd.service 2>/dev/null || true
# Neutralizar los shares integrados [homes]/[printers] del smb.conf de Debian:
# de lo contrario el guest se mapea a "nobody" y Windows ve un recurso
# "\\IP\nobody" junto a los shares reales. La app lo re-aplica en cada
# regeneracion (samba_share_provider._ensure_system_include), pero aqui se
# deja hecho ya en la instalacion.
if [ -f /etc/samba/smb.conf ]; then
    python3 - <<'PY'
from pathlib import Path
import re

p = Path("/etc/samba/smb.conf")
if not p.exists():
    raise SystemExit(0)
text = p.read_text(encoding="utf-8")
for name in ("homes", "printers", "print$"):
    pat = re.compile(r"^\[%s\].*?(?=^\[|\Z)" % re.escape(name), re.M | re.S)
    match = pat.search(text)
    if match and not match.group(0).lstrip().startswith((";", "#")):
        def repl(m):
            return "\n".join(
                ln if not ln.strip() or ln.startswith((";", "#")) else ";" + ln
                for ln in m.group(0).splitlines()
            )
        text, _ = pat.subn(repl, text, count=1)
        print("    Samba: share integrado [%s] deshabilitado" % name)
p.write_text(text, encoding="utf-8")
PY
fi
# El filtrado web (reglas DOMAIN) depende de pdns-recursor: se deja
# habilitado para que arranque con el sistema (el NSP escribe su config).
systemctl enable pdns-recursor.service 2>/dev/null || true

echo "==> [4/8] Node.js (para el frontend)"
# Si Node.js 22+ ya existe, no re-instalar (evita colgarse en nvm).
NODE_OK=0
if sudo -u "${APP_USER}" bash -lc 'source "$HOME/.nvm/nvm.sh" 2>/dev/null && node --version 2>/dev/null' | grep -qE '^v(2[2-9]|[3-9][0-9])'; then
    NODE_OK=1
    echo "    Node.js ya instalado, saltando."
fi
if [ "${NODE_OK}" = "0" ]; then
    sudo -u "${APP_USER}" bash -lc '
        export NVM_DIR="$HOME/.nvm"
        if [ ! -s "$NVM_DIR/nvm.sh" ]; then
            curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
        fi
        . "$NVM_DIR/nvm.sh"
        nvm install 22 || true
        nvm alias default 22 || true
    ' || true
fi

echo "==> [5/8] Entorno Python"
# Robustez: NO recrear el venv desde cero en cada update. Un recreado a
# medias (si un paso falla, p. ej. apt con lock) deja el venv vacío y el
# servicio no arranca tras el update. Si el venv existe con las deps core
# se conserva y se actualizan; solo cuando falta se crea.
if [ ! -x "${APP_DIR}/.venv/bin/python3" ] || ! sudo -u "${APP_USER}" "${APP_DIR}/.venv/bin/python3" -c "import fastapi" 2>/dev/null; then
    sudo -u "${APP_USER}" python3 -m venv "${APP_DIR}/.venv"
fi
# Instalar/actualizar SIEMPRE (idempotente): si el update anterior quedó a
# medias, esto completa deps y deja el entorno usable sin recrear.
sudo -u "${APP_USER}" "${APP_DIR}/.venv/bin/pip" install --upgrade pip
sudo -u "${APP_USER}" "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt"
if ! sudo -u "${APP_USER}" "${APP_DIR}/.venv/bin/python3" -c "import fastapi, sqlalchemy, uvicorn, psycopg2" 2>/dev/null; then
    echo "    AVISO: faltan dependencias; instalando requirements_full…"
    sudo -u "${APP_USER}" "${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements_full.txt" || true
fi

echo "==> [6/8] Base de datos, secretos y administrador"
# Backward-compat hotfix: older installers (v2.5.18) cached on CDN missed String import. Harmless if already fixed.
BACKUP_MODEL="${APP_DIR}/backend/backups/models/backup_settings.py"
if [ -f "${BACKUP_MODEL}" ] && grep -q '^from sqlalchemy import Boolean, DateTime, Integer$' "${BACKUP_MODEL}"; then
    sed -i 's/from sqlalchemy import Boolean, DateTime, Integer/from sqlalchemy import Boolean, DateTime, Integer, String/' "${BACKUP_MODEL}"
    echo "    Aplicado hotfix String en backup_settings.py"
fi
STEPAD_APP_DIR="${APP_DIR}" APP_USER="${APP_USER}" \
    "${APP_DIR}/.venv/bin/python3" "${APP_DIR}/install.py"

# Esquema de base de datos vía Alembic (fuente única de verdad).
# Reemplaza a create_all y a las migraciones sueltas: marca la baseline
# según el estado real de la base y aplica `upgrade head` (nunca
# re-crea tablas ya existentes). Se ejecuta como root porque
# /etc/stepad/stepad.env es 0600 y solo root lo puede leer.
( cd "${APP_DIR}" && .venv/bin/python3 -m backend.scripts.migrate_schema ) \
    && echo "Esquema de base de datos listo (alembic upgrade head)." \
    || echo "AVISO: no se pudo migrar el esquema; se reintenta en el arranque del servicio."

# Verificacion post-migracion: asegurar columnas criticas que Alembic
# podria haber marcado como aplicadas sin crear realmente.
DB_PASS=$(grep '^DB_PASSWORD=' /etc/stepad/stepad.env | cut -d= -f2)
PGPASSWORD="${DB_PASS}" psql -U stepad_app -d stepad_nsp -h localhost -tAc \
    "SELECT column_name FROM information_schema.columns \
     WHERE table_name='network_share_volumes' AND column_name='mount_on_boot';" \
    | grep -q mount_on_boot || {
    echo "    Reparando columna mount_on_boot en network_share_volumes..."
    PGPASSWORD="${DB_PASS}" psql -U stepad_app -d stepad_nsp -h localhost -c \
        "ALTER TABLE network_share_volumes ADD COLUMN IF NOT EXISTS mount_on_boot BOOLEAN NOT NULL DEFAULT true;"
}

echo "==> [7/8] Frontend"
# Usar Node.js existente; solo instalar nvm si no hay ninguno.
# El instalador corre con `set -u`. El script interno va entre COMILLAS
# SIMPLES para que el shell padre NO toque sus variables (HOME, NVM_DIR,
# nodo), evitando "variable sin asignar". APP_DIR se pasa por env.
if [ -f "${APP_DIR}/frontend/dist/index.html" ]; then
    echo "    Frontend ya compilado en el paquete; se recompila..."
fi
sudo -u "${APP_USER}" env APP_DIR="${APP_DIR}" bash -lc '
    export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
    if [ -s "$NVM_DIR/nvm.sh" ]; then
        . "$NVM_DIR/nvm.sh"
    elif command -v node >/dev/null 2>&1; then
        node_bin="$(command -v node)"
        node_dir="$(dirname "$node_bin")"
        export PATH="$node_dir:$PATH"
    else
        curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
        . "$NVM_DIR/nvm.sh"
        nvm install 22 || true
    fi
    cd "$APP_DIR/frontend"
    npm install || true
    npm run build
' || {
    if [ -f "${APP_DIR}/frontend/dist/index.html" ]; then
        echo "AVISO: no se pudo recompilar el frontend; se usa dist/ del paquete."
    else
        echo "ERROR: no se pudo compilar el frontend (revisa node/npm)."
        exit 1
    fi
}

if [ ! -f "${APP_DIR}/frontend/dist/index.html" ]; then
    echo "ERROR: falta ${APP_DIR}/frontend/dist/index.html — la UI no abrirá."
    exit 1
fi

echo "==> [8/8] Servicio"
sed "s|/home/paulan/stepad-nsp|${APP_DIR}|g" \
    "${APP_DIR}/stepad-nsp.service" \
    > /etc/systemd/system/stepad-nsp.service
systemctl daemon-reload
systemctl enable stepad-nsp.service
# Arrancar el recursor antes del NSP: el NSP espera su socket de control
# hasta 20s y luego le carga la config de filtrado.
systemctl start pdns-recursor.service 2>/dev/null || true

# --- Cortar servicios viejos JUSTO ANTES del restart (atomico) ---
# dnsmasq: la app lo maneja directamente (process_manager). Se para y
# mascara el servicio systemd para que no choque con el de la app.
systemctl stop dnsmasq.service 2>/dev/null || true
systemctl disable dnsmasq.service 2>/dev/null || true
systemctl mask dnsmasq.service 2>/dev/null || true

# ---------------------------------------------------------------------
# Limpieza de bóvedas de respaldo residuales (placeholder fantasma).
# Una partición "backup" desmontada puede dejar en el root un directorio
# /mnt/stepad-share/<volumen>/Respaldo con un .respaldo.json cuyo único
# job tiene origen VACÍO (placeholder creado al registrar la partición).
# Ese residuo hacía aparecer "Origen no disponible" / "Falta elegir
# origen" aunque el respaldo real (con origen) viva dentro de la
# partición. Se elimina cuando: no es un montaje real, el volumen no
# está registrado como activo, y el config solo contiene jobs sin
# origen (placeholder). La programación real se conserva intacta (vive
# dentro de la partición, se ve al montarse para el respaldo).
# ---------------------------------------------------------------------
echo "==> Limpiando bóvedas de respaldo residuales (placeholders sin origen)..."
if [ -d "/mnt/stepad-share" ]; then
    for vol in /mnt/stepad-share/*/; do
        [ -d "${vol}" ] || continue
        cfg="${vol}Respaldo/.respaldo.json"
        [ -f "${cfg}" ] || continue
        # Si es un montaje real actual, no es residuo.
        mountpoint -q "$(dirname "${vol}")" 2>/dev/null && continue
        # Se considera placeholder solo si TODOS los jobs tienen origen vacío.
        if printf '%s' "$(cat "${cfg}")" | grep -q '"source_path": ""' 2>/dev/null; then
            rm -f "${cfg}"
            echo "    Limpiado placeholder residual de respaldo: ${vol}Respaldo"
        fi
    done
fi

# "restart" y no "start": en una ACTUALIZACION el servicio ya esta
# corriendo (con el codigo VIEJO en memoria) y "systemctl start" sobre
# un servicio activo es un no-op -- los archivos en disco quedan al dia
# pero el proceso sigue ejecutando el codigo anterior hasta el proximo
# reinicio manual. "restart" carga el codigo nuevo tanto en instalacion
# limpia (equivalente a start) como en actualizacion.
systemctl restart stepad-nsp.service

# ---------------------------------------------------------------------
# Preservación de conectividad WAN + Tailscale en cada update.
# Un update nunca debe dejarte sin acceso remoto: se verifica al final
# y, si algo cortó la salida, se reporta junto con la causa más probable
# (Suricata IPS / NFQUEUE). La vía remota es sagrada; los servicios
# internos (DHCP/Samba) pueden apagarse sin que esto se rompa.
# ---------------------------------------------------------------------
echo "==> Verificando conectividad WAN y Tailscale tras la actualización..."

wan_ok=0
if command -v ping >/dev/null 2>&1; then
    if ping -c2 -W3 1.1.1.1 >/dev/null 2>&1; then
        wan_ok=1
    fi
fi

ts_ok=0
if command -v tailscale >/dev/null 2>&1; then
    if TS_IP="$(tailscale ip -4 2>/dev/null | head -1)" && [ -n "$TS_IP" ]; then
        ts_ok=1
    fi
fi

if [ "$wan_ok" = 1 ] && [ "$ts_ok" = 1 ]; then
    echo "    ✓ WAN OK · Tailscale OK"
elif [ "$wan_ok" = 1 ]; then
    echo "    ⚠ WAN OK pero Tailscale sin IP — ejecuta: sudo tailscale up"
elif [ "$ts_ok" = 1 ]; then
    echo "    ⚠ Tailscale OK pero SIN salida WAN — causa probable: Suricata IPS. Prueba: sudo systemctl stop suricata"
else
    echo "    ✗ Sin WAN ni Tailscale. Causa probable: Suricata IPS / NFQUEUE o corte del proveedor."
    echo "      Para restaurar la red: sudo systemctl stop suricata"
fi

# Guardar la versión instalada (para el check de actualizaciones).
if [ -f "${SCRIPT_DIR}/VERSION" ]; then
    mkdir -p /etc/stepad
    cp "${SCRIPT_DIR}/VERSION" /etc/stepad/version
    echo "==> Versión instalada: $(cat /etc/stepad/version)"
fi

echo "==> [9/9] Suricata (IPS) - listo para activar"

# Config IPS: NFQUEUE 0 (en linea, modo IPS)
mkdir -p /etc/systemd/system/suricata.service.d
cat > /etc/systemd/system/suricata.service.d/override.conf <<'EOF'
[Service]
ExecStart=
ExecStart=/usr/bin/suricata -D -q 0 -c /etc/suricata/suricata.yaml --pidfile /run/suricata.pid
EOF

# Config Suricata: HOME_NET, modo IPS (NFQUEUE 0), reglas SNI de
# grupos y socket de control (script dedicado, sin heredoc).
mkdir -p /var/lib/suricata/rules
python3 "${SCRIPT_DIR}/scripts/configure_suricata.py"

# Rotación de logs Suricata (eve.json, suricata.log) + reset de offsets STEPAD.
if [ -f "${SCRIPT_DIR}/scripts/logrotate/stepad-suricata" ]; then
    cp "${SCRIPT_DIR}/scripts/logrotate/stepad-suricata" /etc/logrotate.d/stepad-suricata
    echo "    Logrotate Suricata instalado (/etc/logrotate.d/stepad-suricata)"
fi

# Suricata activo desde el arranque: el bloqueo por grupo (DNS+IP+SNI)
# y el IPS dependen de que la cola NFQUEUE sea procesada.
systemctl enable suricata.service >/dev/null 2>&1 || true

# Actualizacion diaria de reglas
cat > /usr/local/bin/stepad-suricata-update.sh <<'EOF'
#!/bin/bash
suricata-update >/tmp/suricata-update.log 2>&1 || exit 1
suricatasc -c reload-rules >/dev/null 2>&1
EOF
chmod +x /usr/local/bin/stepad-suricata-update.sh

cat > /etc/systemd/system/stepad-suricata-update.service <<'EOF'
[Unit]
Description=STEPAD Suricata signature update
[Service]
Type=oneshot
ExecStart=/usr/local/bin/stepad-suricata-update.sh
EOF

cat > /etc/systemd/system/stepad-suricata-update.timer <<'EOF'
[Unit]
Description=STEPAD Suricata signature update daily
[Timer]
OnCalendar=*-*-* 04:17:00
Persistent=true
[Install]
WantedBy=timers.target
EOF
systemctl enable stepad-suricata-update.timer >/dev/null 2>&1 || true

# Descarga inicial de reglas (best-effort; necesita internet)
echo "    Descargando reglas de Suricata (ET)..."
suricata-update >/tmp/suricata-update.log 2>&1 || true

# suricata-update regenera suricata.yaml y vuelve a poner "af-packet: eth0"
# (interfaz inexistente en muchos equipos -> Suricata no arranca). Hay que
# reaplicar la config propia DESPUES del update para que arranque bien.
python3 "${SCRIPT_DIR}/scripts/configure_suricata.py"

# Suricata queda habilitado por defecto: el bloqueo por SNI (capa de
# respaldo al DNS) debe estar activo desde el arranque para no depender
# solo del DNS del cliente.
systemctl enable suricata.service >/dev/null 2>&1 || true


echo "==> Instalando Tailscale (acceso remoto por VPN)..."
curl -fsSL https://tailscale.com/install.sh | sh || true

# El acceso remoto (WAN/Tailscale) es CRITICO y nunca debe perderse en un
# update. Aunque no haya authkey nueva: si el equipo YA estaba unido a
# Tailscale, tailscaled debe estar activo y re-unirse con su misión previa
# (tailscale up sin authkey conserva la config existente).
systemctl enable tailscaled.service >/dev/null 2>&1 || true
systemctl start tailscaled.service >/dev/null 2>&1 || true

if [ -n "${TAILSCALE_KEY}" ]; then
    echo "==> Uniendo el NSP a Tailscale..."
    tailscale up --authkey="${TAILSCALE_KEY}" --hostname="${TAILSCALE_HOSTNAME}" || true
else
    # Sin clave nueva: si había una unión previa (== el equipo ya estaba en
    # la red de Tailscale), se vuelve a levantar con esa config. Nunca se
    # deja al NSP sin vía remota por un update que no trajo authkey.
    if tailscale ip -4 >/dev/null 2>&1 || [ -d /var/lib/tailscale ]; then
        echo "==> Re-activando acceso remoto previo (Tailscale)..."
        tailscale up || true
    fi
fi

echo
echo "======================================================"
echo "  STEPAD NSP INSTALADO"
echo "======================================================"
echo "  Acceso web:"
WEB_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [ -z "${WEB_IP}" ]; then
    WEB_IP="<IP-de-este-equipo>"
fi
echo "      LAN:    https://${WEB_IP}:8443"

TS_IP="$(tailscale ip -4 2>/dev/null | head -1)"
if [ -n "${TS_IP}" ]; then
    echo "      Remoto: https://${TS_IP}:8443 (via Tailscale)"
    echo
    echo "  SSH remoto (desde cualquier lado):"
    echo "      ssh paulan@${TS_IP}"
else
    echo
    echo "  Tailscale instalado. Para acceso remoto desde cualquier lugar:"
    echo "    - en la web:  VPN > Conectar a Tailscale (pre-auth key)"
    echo "    - o terminal: sudo tailscale up --authkey=tskey-auth-XXXX"
fi
echo
echo "  Usuario: admin"
echo "  Contraseña: la que tengas configurada (cámbiala en"
echo "      Ajustes > Usuarios si lo necesitas)"
echo
echo "  IMPORTANTE al entrar:"
echo "    1. Activa la MFA (recomendado)."
echo "    2. Registra los datos de tu empresa."
echo "    3. Asigna las tarjetas WAN/LAN en 'Interfaces'."
echo "    4. Pon contraseña al usuario SSH (paulan): sudo passwd paulan"
echo "======================================================"
