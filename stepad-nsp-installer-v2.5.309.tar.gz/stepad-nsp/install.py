"""
STEPAD NSP non-interactive installer.

Run as root on a provisioned Debian (deps + repo + venv already in
place via install.sh). It:
  1. loads any existing secrets (idempotent re-runs),
  2. generates missing secrets,
  3. creates the PostgreSQL role + database,
  4. creates the tables,
  5. creates the initial administrator (password printed once),
  6. writes /etc/stepad/stepad.env and the admin credentials file.
"""

import os
import secrets
import subprocess

from pathlib import Path

ENV_FILE = Path("/etc/stepad/stepad.env")

APP_DIR = Path(
    os.getenv(
        "STEPAD_APP_DIR",
        f"/home/{os.getenv('APP_USER', 'paulan')}/stepad-nsp",
    )
)


def load_existing_env():

    values = {}

    if ENV_FILE.exists():

        for line in ENV_FILE.read_text(
            encoding="utf-8"
        ).splitlines():

            line = line.strip()

            if not line or "=" not in line or line.startswith("#"):

                continue

            key, value = line.split("=", 1)

            values[key.strip()] = value.strip().strip("\"'")

    return values


# ------------------------------------------------------------------
# Resolve secrets BEFORE importing backend modules so Settings picks
# them up from os.environ (Settings is evaluated at import time).
# ------------------------------------------------------------------
existing = load_existing_env()

db_password = (
    existing.get("DB_PASSWORD")
    or os.getenv("DB_PASSWORD")
    or secrets.token_urlsafe(16)
)

jwt_secret = (
    existing.get("STEPAD_JWT_SECRET")
    or os.getenv("STEPAD_JWT_SECRET")
    or secrets.token_urlsafe(48)
)

db_host = existing.get("DB_HOST") or os.getenv("DB_HOST") or "127.0.0.1"

db_port = existing.get("DB_PORT") or os.getenv("DB_PORT") or "5432"

db_name = existing.get("DB_NAME") or os.getenv("DB_NAME") or "stepad_nsp"

db_user = existing.get("DB_USER") or os.getenv("DB_USER") or "stepad_app"

DEFAULT_ADMIN_PASSWORD = "$Coys0318"

admin_password = (
    existing.get("STEPAD_ADMIN_PASSWORD")
    or os.getenv("STEPAD_ADMIN_PASSWORD")
    or DEFAULT_ADMIN_PASSWORD
)

os.environ["STEPAD_ENV"] = "production"

os.environ["DB_PASSWORD"] = db_password

os.environ["DB_HOST"] = db_host

os.environ["DB_PORT"] = db_port

os.environ["DB_NAME"] = db_name

os.environ["DB_USER"] = db_user

os.environ["STEPAD_JWT_SECRET"] = jwt_secret

os.environ["STEPAD_DNS_ENGINE"] = "powerdns_rpz"


# Now the backend modules can be imported safely.
from backend.core.database.connection import engine
from backend.core.database.base import Base
from backend.core.database.session import SessionLocal

from backend.network.devices.models.network_device import NetworkDevice
from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.users.models.user import User
from backend.audit.models.audit_log import AuditLog
from backend.nat.models.port_forward import PortForward
from backend.vpn.models.vpn_peer import VpnPeer
from backend.notifications.models.notification_settings import NotificationSettings
from backend.backups.models.backup_settings import BackupSettings
from backend.organization.models.organization_settings import OrganizationSettings
from backend.alerts.models.alert import Alert
from backend.siem.models.syslog_settings import SyslogSettings
from backend.siem.models.compliance_settings import ComplianceSettings
from backend.content.models.content_category import ContentCategory, CategoryDomain
from backend.config_revisions.models.config_revision import ConfigRevision
from backend.network.zones.models.network_zone import NetworkZone
from backend.network.zones.models.schedule import Schedule
from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.network.interfaces.registry.models.managed_interface import (
    ManagedInterface
)

from backend.users.services.user_service import UserService
from backend.users.security.password_hasher import PasswordHasher


def wait_for_postgres(timeout: int = 30) -> bool:
    """Espera a que PostgreSQL responda (en maquina nueva tarda en
    levantarse). Devuelve True si esta listo antes del timeout."""
    import time
    for _ in range(timeout):
        try:
            result = subprocess.run(
                ["runuser", "-u", "postgres", "--", "psql", "-tAc", "SELECT 1"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip() == "1":
                return True
        except Exception:
            pass
        time.sleep(1)
    return False


def psql(sql: str) -> str:

    result = subprocess.run(
        ["runuser", "-u", "postgres", "--", "psql", "-tAc", sql],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"PostgreSQL falló ejecutando: {sql}\n"
            f"stderr: {result.stderr.strip()}"
        )

    return result.stdout.strip()


def ensure_database():

    if not wait_for_postgres():
        raise RuntimeError(
            "PostgreSQL no respondió. Verificá que el servicio esté "
            "activo (systemctl status postgresql)."
        )

    role = psql(
        f"SELECT 1 FROM pg_roles WHERE rolname='{db_user}'"
    )

    if not role:

        psql(
            f"CREATE ROLE {db_user} LOGIN PASSWORD '{db_password}'"
        )

        print(f"✓ PostgreSQL role '{db_user}' created")

    else:

        psql(
            f"ALTER ROLE {db_user} WITH LOGIN PASSWORD '{db_password}'"
        )

        print(f"✓ PostgreSQL role '{db_user}' ready")

    database = psql(
        f"SELECT 1 FROM pg_database WHERE datname='{db_name}'"
    )

    if not database:

        psql(f"CREATE DATABASE {db_name} OWNER {db_user}")

        print(f"✓ PostgreSQL database '{db_name}' created")

    else:

        print(f"✓ PostgreSQL database '{db_name}' ready")


def write_env_file():

    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)

    frontend_dist = APP_DIR / "frontend" / "dist"

    # Claves que el instalador administra (verdad de origen).
    managed = {
        "STEPAD_ENV",
        "STEPAD_DNS_ENGINE",
        "DB_HOST",
        "DB_PORT",
        "DB_NAME",
        "DB_USER",
        "DB_PASSWORD",
        "STEPAD_JWT_SECRET",
        "STEPAD_VPN_REQUIRE_REMOTE_ADMIN",
        "STEPAD_FRONTEND_DIST",
    }

    # Cualquier otra clave ya presente (p.ej. STEPAD_RESTIC_PASSWORD,
    # generada por el backend para sus repositorios restic) se PRESERVA:
    # reescribir el archivo de punta a punta borraba esa línea en cada
    # reinstalación, y entonces el backend generaba una password NUEVA que
    # ya no abría los repos existentes ("wrong password or no key found"),
    # rompiendo todos los respaldos de la máquina.
    preserved = {
        key: value
        for key, value in existing.items()
        if key not in managed
    }

    lines = [
        "STEPAD_ENV=production",
        "STEPAD_DNS_ENGINE=powerdns_rpz",
        f"DB_HOST={db_host}",
        f"DB_PORT={db_port}",
        f"DB_NAME={db_name}",
        f"DB_USER={db_user}",
        f"DB_PASSWORD={db_password}",
        f"STEPAD_JWT_SECRET={jwt_secret}",
        "STEPAD_VPN_REQUIRE_REMOTE_ADMIN=false",
        f"STEPAD_FRONTEND_DIST={frontend_dist}",
    ]

    for key, value in sorted(preserved.items()):
        lines.append(f"{key}={value}")

    ENV_FILE.write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8"
    )

    ENV_FILE.chmod(0o600)

    print(f"✓ Runtime secrets written to {ENV_FILE} (mode 0600)")


def install():

    print("========================================")
    print("      STEPAD NSP Installation")
    print("========================================")

    ensure_database()

    # Ejecutar migraciones de Alembic ANTES de cualquier consulta.
    # install.sh tambien las llama despues, pero aqui necesitamos las
    # tablas ya creadas para poder crear el usuario admin.
    try:
        from backend.core.database.schema_migrations import run_migrations
        run_migrations()
        print("✓ Esquema aplicado (alembic upgrade head)")
    except Exception as e:
        print(f"⚠ Migración falló (se reintenta en el arranque): {e}")

    write_env_file()

    db = SessionLocal()

    try:

        hasher = PasswordHasher()

        service = UserService()

        existing_admin = (
            db.query(User)
            .filter(User.username == "admin")
            .first()
        )

        if existing_admin:
            existing_admin.password_hash = hasher.hash(admin_password)
            existing_admin.failed_attempts = 0
            existing_admin.locked_until = None
            db.commit()
            print("✓ Administrator password reset to current default")

        else:

            service.create_admin(
                db=db,
                username="admin",
                password_hash=hasher.hash(admin_password)
            )

            print("✓ Administrator user created")

            print()
            print("  Administrator user created (admin).")
            print()

    finally:

        db.close()

    print("========================================")
    print(" Installation completed successfully")
    print("========================================")


if __name__ == "__main__":

    install()
