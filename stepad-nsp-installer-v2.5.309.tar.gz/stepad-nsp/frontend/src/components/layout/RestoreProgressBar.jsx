import { useEffect, useState } from "react";
import { apiClient } from "../../services/apiClient";

function fmtMB(bytes) {
    if (!bytes) return "0 MB";
    return `${(bytes / 1024 / 1024).toFixed(0)} MB`;
}

export default function RestoreProgressBar() {
    const [active, setActive] = useState(null);

    useEffect(() => {
        let stopped = false;
        async function poll() {
            try {
                const res = await apiClient.get("/shares/backups/restore-active");
                setActive(res || null);
            } catch (e) {
                // ignora errores transitorios; la barra reaparecerá sola
            }
        }
        poll();
        const iv = setInterval(poll, 2000);
        return () => {
            stopped = true;
            clearInterval(iv);
        };
    }, []);

    if (!active) return null;

    const st = active.status || {};
    const prog = st.progress || {};
    const pct = typeof prog.percent === "number" ? prog.percent : 0;
    const dest = (st.result && st.result.restore_to) || active.restore_to || "";

    return (
        <div className="sh-rs-global">
            <div className="sh-rs-line">
                <span className="sh-rs-label">
                    Restaurando en {dest || "destino"}…
                </span>
                <strong className="sh-rs-pct">{Math.round(pct)}%</strong>
            </div>
            <div className="sh-usage-bar">
                <div
                    className="sh-usage-fill"
                    style={{ width: `${Math.min(100, pct)}%` }}
                ></div>
            </div>
            <div className="sh-rs-sub">
                <span>{fmtMB(prog.bytes_done)}</span>
                {typeof prog.eta_seconds === "number" && prog.eta_seconds > 0 && (
                    <span>ETA ~{Math.round(prog.eta_seconds / 60)} min</span>
                )}
            </div>
        </div>
    );
}