import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../../../auth/useAuth";

import { useNetworkSegment } from "../../../network/useNetworkSegment";

import { getDevices, scanDevices, getDevicesLiveStatus, updateDevice, linkDevice, unlinkDevice } from "../../../services/api";

import WriteGuard from "../../../components/WriteGuard";

import { formatDateTime } from "../../../utils/datetime";

import "./devices.css";


function Devices() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const {
        selectedLan,
        selectedZones,
        selectedZoneIds,
        hostsDefaultZone,
        lanCards,
    } = useNetworkSegment();


    const [devices, setDevices] = useState([]);

    const zones = selectedZones;

    const [search, setSearch] = useState("");

    const [filter, setFilter] = useState("ALL");

    const [showExtra, setShowExtra] = useState(false);

    const [linkOpen, setLinkOpen] = useState(null);

    const [linkPrimary, setLinkPrimary] = useState("");

    const [sortKey, setSortKey] = useState("status");

    const [sortDir, setSortDir] = useState("asc");


    const navigate = useNavigate();

    const [scanning, setScanning] = useState(false);

    const [liveStatus, setLiveStatus] = useState({});

    const [liveReady, setLiveReady] = useState(false);

    async function refreshLiveStatus() {

        try {

            const data = await getDevicesLiveStatus();

            setLiveStatus(data?.live || {});

            setLiveReady(true);

        } catch (error) {

            console.error(error);

        }

    }

    useEffect(() => {

        loadDevices();

        refreshLiveStatus();

        // Refresco automatico cada 30s: las luces se actualizan solas
        // (sin pulsar "Escanear red").
        const timer = setInterval(() => {

            getDevices()

                .then(setDevices)

                .catch(() => {});

        }, 30000);

        // Ping ligero en segundo plano cada 15s: actualiza la luz
        // segun si cada equipo responde AHORA.
        const liveTimer = setInterval(() => {

            refreshLiveStatus();

        }, 15000);

        function daysOffline(device) {
        if (connectionOf(device) === "online") return null;
        if (!device.last_seen) return null;
        const last = new Date(device.last_seen);
        if (isNaN(last.getTime())) return null;
        const now = new Date();
        return Math.max(0, Math.floor((now - last) / (1000 * 60 * 60 * 24)));
    }

    return () => {
            clearInterval(timer);
            clearInterval(liveTimer);
        };

    }, []);


    async function handleZoneChange(deviceId, zoneId) {

        try {

            await updateDevice(
                deviceId,
                { zone_id: zoneId ? Number(zoneId) : null }
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleDeviceBandwidth(device, value) {

        const mbps = String(value).trim();

        const kbps = mbps === "" ? null : (Number(mbps) * 1000);

        if (kbps !== null && (!Number.isFinite(kbps) || kbps <= 0)) {

            alert("Ingresa un valor válido en Mbps");

            loadDevices();

            return;

        }

        try {

            await updateDevice(
                device.id,
                { bandwidth_limit_kbps: kbps }
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

            alert("No se pudo guardar el ancho de banda.");

        }

    }


    async function handleLinkDevice(deviceId, primaryDeviceId) {

        if (!primaryDeviceId) {

            return;

        }

        try {

            await linkDevice(
                deviceId,
                Number(primaryDeviceId)
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function handleUnlinkDevice(deviceId) {

        try {

            await unlinkDevice(
                deviceId
            );

            await loadDevices();

        } catch (error) {

            console.error(error);

        }

    }


    async function loadDevices() {

        setScanning(true);

        try {

            const data = await getDevices();

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }


    async function handleScan() {

        setScanning(true);

        try {

            const data = await scanDevices();

            setDevices(data);

        } catch (error) {

            console.error(error);

        } finally {

            setScanning(false);

        }

    }

const deviceTypes = {

    COMPUTER: "💻 Computadora",

    MOBILE: "📱 Celular",

    PRINTER: "🖨 Impresora",

    ROUTER: "📡 Router",

    IP_PHONE: "☎️ Teléfono",

    CAMERA: "🎥 Cámara",

    ACCESO: "🛡️ Acceso/Asistencia",

    OTRO: "❓ Otro",

    HOST: "❓ Otro",

    UNKNOWN: "❓ Otro"

};


const statusLabels = {

    ONLINE: "En línea",

    OFFLINE: "Sin conexión",

    UNKNOWN: "Desconocido",

    BLOCKED: "Bloqueado"

};

    const CONNECTION_TITLE = {
        pending: "Comprobando conexión…",
        online: "En línea",
        offline: "Sin conexión"
    };

    function connectionOf(device) {

        const ip = device.ip_address;

        if (ip && Object.prototype.hasOwnProperty.call(liveStatus, ip)) {

            return liveStatus[ip] ? "online" : "offline";

        }

        if (!liveReady) {

            return "pending";

        }

        return device.status === "ONLINE" ? "online" : "offline";

    }


    const filteredDevices = devices.filter((device) => {


        const text = (

            `${device.hostname || ""}
             ${device.ip_address || ""}
             ${device.mac_address || ""}`

        ).toLowerCase();



        const matchesSearch =
            text.includes(
                search.toLowerCase()
            );



        const connection = connectionOf(device);

        const matchesStatus =
            filter === "ALL"
            || (filter === "ONLINE" && connection === "online")
            || (filter === "OFFLINE" && connection === "offline")
            || (filter !== "ONLINE" && filter !== "OFFLINE" && device.status === filter);

        // Misma pantalla; el selector de tarjeta/red filtra el alcance.
        let matchesSegment = true;

        if (lanCards.length > 1) {

            if (device.zone_id) {

                matchesSegment = selectedZoneIds.has(device.zone_id);

            } else {

                matchesSegment = hostsDefaultZone || selectedZones.length === 0;

            }

        }

        return matchesSearch && matchesStatus && matchesSegment;


    });


    const sortedDevices = [...filteredDevices].sort((a, b) => {

        let va, vb;

        if (sortKey === "status") {

            // asc = en línea, comprobando, sin conexión.
            const order = { online: 0, pending: 1, offline: 2 };

            va = order[connectionOf(a)] ?? 1;

            vb = order[connectionOf(b)] ?? 1;
        } else if (sortKey === "ip_address") {
            const lastOctet = (ip) => parseInt((ip || "").split(".").pop()) || 0;
            va = lastOctet(a.ip_address);
            vb = lastOctet(b.ip_address);

        } else {

            va = (a[sortKey] ?? "").toString().toLowerCase();

            vb = (b[sortKey] ?? "").toString().toLowerCase();

        }

        if (va < vb) return sortDir === "asc" ? -1 : 1;

        if (va > vb) return sortDir === "asc" ? 1 : -1;

        return 0;

    });


    function exportToExcel() {
        const header = ["Nombre", "MAC", "IP", "Estado", "Dias desconectado"];
        const rows = sortedDevices.map((d) => {
            const days = daysOffline(d);
            return [
                d.display_name || d.hostname || "",
                d.mac_address || "",
                d.ip_address || "",
                connectionOf(d) === "online" ? "Online" : "Offline",
                days !== null ? days + " dias" : "0",
            ];
        });
        const csv = [header, ...rows].map((r) => r.map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(",")).join("\n");
        const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "dispositivos_" + new Date().toISOString().slice(0, 10) + ".csv";
        a.click();
        URL.revokeObjectURL(url);
    }

    function handleSort(key) {

        if (sortKey === key) {

            setSortDir((d) => (d === "asc" ? "desc" : "asc"));

        } else {

            setSortKey(key);

            setSortDir("asc");

        }

    }





    const onlineDevices =
        devices.filter((d) => connectionOf(d) === "online").length;

    const offlineDevices =
        devices.filter((d) => connectionOf(d) === "offline").length;





    function daysOffline(device) {
        if (connectionOf(device) === "online") return null;
        if (!device.last_seen) return null;
        const last = new Date(device.last_seen);
        const now = new Date();
        const diff = Math.floor((now - last) / (1000 * 60 * 60 * 24));
        return diff;
    }

    function formatDate(date) {

        return formatDateTime(date, "-");

    }





    return (


        <div className="devices-container">


            <div className="devices-header">

                <div>

                    <h2>

                        Dispositivos de red

                    </h2>

                    <p>

                        {
                            lanCards.length > 1
                                ? (
                                    <>
                                        Equipos del segmento seleccionado arriba
                                        {selectedLan
                                            ? ` (${selectedLan.display_name || selectedLan.current_name || selectedLan.last_seen_name || "LAN"})`
                                            : ""}
                                        . Cambia la tarjeta en la barra superior para ver otra red.
                                    </>
                                )
                                : "Descubre, monitorea y administra los equipos conectados a tu red protegida."
                        }

                    </p>

                </div>

                <button

                    className={`scan-button ${scanning ? "scanning" : ""}`}

                    onClick={handleScan}

                    disabled={scanning}

                    title="Escaneo profundo (una vez): actualiza nombres, tipo y sistema operativo detectados. El estado en línea ya se comprueba solo con ping."

                >

                    <span className="scan-icon">

                        {scanning ? "⟳" : "🔄"}

                    </span>

                    {scanning ? "Escaneando..." : "Escanear red"}

                </button>

                <span
                    className={`devices-live-hint ${liveReady ? "" : "pending"}`}
                    title="Al abrir, las luces salen en gris hasta el primer ping. Luego verde = en línea, rojo = sin conexión."
                >
                    {liveReady ? "● Estado en vivo (ping cada 15s)" : "● Comprobando conexión…"}
                </span>

            </div>

            <div className="device-summary">

                <div className="summary-item">

                    <span className="summary-label">
                        Total de dispositivos
                    </span>

                    <span className="summary-value">
                        {devices.length}
                    </span>

                </div>

                <div className="summary-divider"></div>

                <div className="summary-item">

                    <span className="summary-label">
                        En línea
                    </span>

                    <span className="summary-value online">
                        {liveReady ? onlineDevices : "—"}
                    </span>

                </div>

                <div className="summary-divider"></div>

                <div className="summary-item">

                    <span className="summary-label">
                        Sin conexión
                    </span>

                    <span className="summary-value offline">
                        {liveReady ? offlineDevices : "—"}
                    </span>

                </div>

            </div>

            <div className="device-toolbar">

                <input

                    type="text"

                    placeholder="Buscar por nombre, IP o MAC..."

                    value={search}

                    onChange={
                        e => setSearch(e.target.value)
                    }

                />

                <select

                    value={filter}

                    onChange={
                        e => setFilter(e.target.value)
                    }

                >

                    <option value="ALL">
                        Todos
                    </option>

                    <option value="ONLINE">
                        En línea
                    </option>

                    <option value="OFFLINE">
                        Sin conexión
                    </option>

                    <option value="UNKNOWN">
                        Desconocidos
                    </option>

                </select>

                <button
                    className="secondary-button"
                    style={{ marginLeft: 8 }}
                    onClick={() => setShowExtra(!showExtra)}
                >
                    {showExtra ? "Ocultar detalles" : "Ver detalles"}
                </button>
                <button
                    className="secondary-button"
                    style={{ marginLeft: 8 }}
                    onClick={exportToExcel}
                >
                    Exportar Excel
                </button>
            </div>




            <div className="devices-table-wrap">

            <div className="table-card">

                <table className="devices-table">


                    <thead>

                        <tr>

                            <th style={{ width: 70 }}>

                                <button
                                    className="th-sort"
                                    onClick={() => handleSort("status")}
                                    title="Ordenar por estado (online/offline)"
                                >
                                    On/Off {sortKey === "status" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>

                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("hostname")}>
                                    Nombre {sortKey === "hostname" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("device_type")}>
                                    Tipo {sortKey === "device_type" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("os_name")}>
                                    Sistema {sortKey === "os_name" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>

                            <th>
                                <button className="th-sort" onClick={() => handleSort("ip_address")}>
                                    IP {sortKey === "ip_address" ? (sortDir === "asc" ? "▲" : "▼") : ""}
                                </button>
                            </th>
                            <th style={{ width: 70, textAlign: "center" }}>Días off</th>
                            <th style={{ width: 80, textAlign: "center" }}>Días off</th>

                            {
                                showExtra && (
                                    <>
                                        <th>MAC</th>

                                        <th>Zona</th>

                                        <th>Última vez</th>

                                        <th>Acciones</th>
                                    </>
                                )
                            }


                        </tr>

                    </thead>




                    <tbody>


                        {
                            sortedDevices.map((device) => (


                                <tr key={device.id}>


                                    <td>

                                        <span
                                            className={`device-live-dot ${connectionOf(device)}`}
                                            title={CONNECTION_TITLE[connectionOf(device)]}
                                        />
                                    </td>



                                    <td>

                                        <div className="device-name-cell">

                                            <span className="device-name-value">
                                                {device.hostname || "Desconocido"}
                                            </span>

                                        </div>

                                    </td>


                                    <td>

                                        <span className={`device-type ${device.device_type?.toLowerCase()}`}>

                                            {

                                                deviceTypes[

                                                device.device_type?.toUpperCase()

                                                ]

                                                ||

                                                "❓ Desconocido"

                                            }

                                        </span>

                                    </td>

                                    <td>

                                        <span className="device-os">
                                            {device.os_name || "Desconocido"}
                                        </span>

                                    </td>

                                    <td>

                                        {device.ip_address}

                                    </td>

                                    <td style={{ textAlign: "center" }}>
                                        {(() => {
                                            const d = daysOffline(device);
                                            if (d === null) return <span style={{ color: "#4ade80" }}>●</span>;
                                            return <span style={{ color: d > 30 ? "#f87171" : d > 7 ? "#fbbf24" : "#94a3b8", fontSize: "0.85rem" }}>{d}</span>;
                                        })()}
                                    </td>


                                    {
                                        showExtra && (
                                            <>

                                    <td>

                                        <div className="mac-cell">

                                            {device.mac_address || "-"}

                                            {
                                                (device.linked_devices || []).length > 0 && (
                                                    <span className="linked-badge">
                                                        +{device.linked_devices.length} NICs
                                                    </span>
                                                )
                                            }

                                        </div>

                                    </td>




                                    <td>

                                        {
                                            isAdmin ? (
                                                <select
                                                    value={device.zone_id || ""}
                                                    onChange={(e) =>
                                                        handleZoneChange(
                                                            device.id,
                                                            e.target.value
                                                        )
                                                    }
                                                >

                                                    <option value="">
                                                        Sin asignar
                                                    </option>

                                                    {
                                                        zones.map((zone) => (
                                                            <option
                                                                key={zone.id}
                                                                value={zone.id}
                                                            >
                                                                {zone.name}
                                                                {zone.is_default ? " (default)" : ""}
                                                            </option>
                                                        ))
                                                    }

                                                </select>
                                            ) : (
                                                <span className="zone-readonly">
                                                    {device.zone_id
                                                        ? (zones.find((z) => z.id === device.zone_id)?.name || device.zone_id)
                                                        : "Sin asignar"}
                                                </span>
                                            )
                                        }
                                    </td>




                                    <td>

                                        {formatDate(device.last_seen)}

                                    </td>

                                    <td>

                                        <div className="manage-menu">

                                            <button
                                                className="manage-button"
                                                onClick={() =>
                                                    navigate(
                                                        `/network/devices/${device.id}`
                                                    )
                                                }
                                            >

                                                Gestionar

                                            </button>

                                            <button
                                                className="manage-button"
                                                onClick={() => {
                                                    setLinkOpen(linkOpen === device.id ? null : device.id);
                                                    setLinkPrimary("");
                                                }}
                                            >
                                                Vincular
                                            </button>

                                            {
                                                linkOpen === device.id && (
                                                    <div style={{ marginTop: 6, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                                                        <select
                                                            value={linkPrimary}
                                                            onChange={(e) => setLinkPrimary(e.target.value)}
                                                        >
                                                            <option value="">-- Equipo principal --</option>
                                                            {
                                                                devices
                                                                    .filter((d) => d.id !== device.id)
                                                                    .map((d) => (
                                                                        <option key={d.id} value={d.id}>
                                                                            {d.hostname || d.ip_address || d.mac_address || `#${d.id}`}
                                                                        </option>
                                                                    ))
                                                            }
                                                        </select>
                                                        <button
                                                            className="secondary-button small"
                                                            disabled={!linkPrimary}
                                                            onClick={() => {
                                                                handleLinkDevice(device.id, Number(linkPrimary));
                                                                setLinkOpen(null);
                                                            }}
                                                        >
                                                            Confirmar
                                                        </button>
                                                    </div>
                                                )
                                            }

                                        </div>

                                    </td>

                                            </>
                                        )
                                    }

                                </tr>


                            ))
                        }


                    </tbody>


                </table>

                {
                    scanning && (
                        <div className="devices-scan-overlay">
                            <div className="devices-spinner"></div>
                            <p>Escaneando red, espere...</p>
                        </div>
                    )
                }

            </div>

            </div>
        </div>


    );


}


export default Devices;