/** Presets SMTP — debe coincidir con backend/notifications/constants/email_providers.py */

export const EMAIL_PROVIDERS = [
    {
        key: "gmail",
        label: "Gmail / Google Workspace",
        smtp_host: "smtp.gmail.com",
        smtp_port: 587,
        hint: (
            "Con verificación en dos pasos activa, use una "
            + "contraseña de aplicación (no la contraseña normal)."
        ),
    },
    {
        key: "outlook",
        label: "Outlook.com / Hotmail",
        smtp_host: "smtp-mail.outlook.com",
        smtp_port: 587,
        hint: "Use la contraseña de su cuenta Microsoft.",
    },
    {
        key: "office365",
        label: "Microsoft 365 / Exchange",
        smtp_host: "smtp.office365.com",
        smtp_port: 587,
        hint: "Cuenta corporativa Microsoft 365 o Exchange Online.",
    },
    {
        key: "yahoo",
        label: "Yahoo Mail",
        smtp_host: "smtp.mail.yahoo.com",
        smtp_port: 587,
        hint: "Genere una contraseña de aplicación en la seguridad de Yahoo.",
    },
    {
        key: "custom",
        label: "Otro / personalizado",
        smtp_host: "",
        smtp_port: 587,
        hint: "Indique servidor SMTP, puerto, cuenta y contraseña.",
    },
];


export function findEmailProvider(key) {

    return EMAIL_PROVIDERS.find((item) => item.key === key) || null;

}


export function defaultProviderForm(providerKey = "gmail") {

    const preset = findEmailProvider(providerKey) || EMAIL_PROVIDERS[0];

    return {
        provider: preset.key,
        smtp_host: preset.smtp_host,
        smtp_port: preset.smtp_port,
        account_email: "",
        smtp_password: "",
    };

}
