import { useEffect, useState } from "react";

import { useAuth } from "../../../auth/useAuth";

import {
    getNotificationSettings,
    saveNotificationSettings,
    sendNotificationNow,
} from "../../../services/api";

import "../settings.css";


function formatDateTime(value) {

    if (!value) return "Nunca";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return "—";

    return date.toLocaleString();

}


function NotificationSection() {

    const { user } = useAuth();

    const isAdmin = user?.role === "ADMIN";

    const [form, setForm] = useState({
        enabled: false,
        to_emails: "",
        frequency: "daily",
        send_hour: 8,
        send_minute: 0,
    });

    const [status, setStatus] = useState({
        config_ready: false,
        config_issues: [],
        email_config_ready: false,
        email_provider_label: "",
        email_account: "",
        next_send_hint: "",
        schedule_label: "",
        report_period: "",
        frequency_label: "",
        last_sent_at: null,
        scheduler_running: false,
    });

    const [error, setError] = useState(null);

    const [notice, setNotice] = useState(null);

    const [busy, setBusy] = useState(false);


    function applySettings(data) {

        setForm({
            enabled: data.enabled,
            to_emails: data.to_emails || "",
            frequency: data.frequency || "daily",
            send_hour: data.send_hour ?? 8,
            send_minute: data.send_minute ?? 0,
        });

        setStatus({
            config_ready: Boolean(data.config_ready),
            config_issues: data.config_issues || [],
            email_config_ready: Boolean(data.email_config_ready),
            email_provider_label: data.email_provider_label || "",
            email_account: data.email_account || "",
            next_send_hint: data.next_send_hint || "",
            schedule_label: data.schedule_label || "",
            report_period: data.report_period || "",
            frequency_label: data.frequency_label || "",
            last_sent_at: data.last_sent_at || null,
            scheduler_running: Boolean(data.scheduler_running),
        });

    }


    async function reloadSettings() {

        const data = await getNotificationSettings();

        applySettings(data);

        return data;

    }


    useEffect(() => {

        let cancelled = false;

        getNotificationSettings()

            .then((data) => {
                if (!cancelled) applySettings(data);
            })

            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };

    }, []);


    async function handleSave() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const saved = await saveNotificationSettings({
                enabled: form.enabled,
                to_emails: form.to_emails,
                frequency: form.frequency,
                send_hour: Number(form.send_hour),
                send_minute: Number(form.send_minute),
            });

            applySettings(saved);

            setNotice("Programación de reportes guardada.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    async function handleSendNow() {

        setError(null);

        setNotice(null);

        setBusy(true);

        try {

            const result = await sendNotificationNow();

            if (result.success === false) {

                setError(result.message || "No se pudo enviar el reporte.");

                return;

            }

            await reloadSettings();

            setNotice(result.message || "Reporte enviado con Excel adjunto.");

        } catch (err) {

            setError(err.message);

        } finally {

            setBusy(false);

        }

    }


    const recipientCount = form.to_emails
        .split(",")
        .map((email) => email.trim())
        .filter(Boolean).length;


    return (

        <div className="notify-panel">

            <div className="notify-header">

                <div>

                    <h3>Reportes automáticos por correo</h3>

                    <p className="notify-lead">

                        Programa el envío del resumen de navegación (Historial DNS)
                        con Excel adjunto. La cuenta SMTP se configura en la
                        pestaña <strong>Correo</strong>.

                    </p>

                </div>

                <label className={`notify-master-toggle ${form.enabled ? "on" : ""}`}>
                    <input
                        type="checkbox"
                        checked={form.enabled}
                        disabled={!isAdmin}
                        onChange={(e) =>
                            setForm({ ...form, enabled: e.target.checked })
                        }
                    />
                    <span>{form.enabled ? "Activo" : "Inactivo"}</span>
                </label>

            </div>


            {error && (
                <div className="maintenance-error">{error}</div>
            )}

            {notice && (
                <div className="notification-ok">{notice}</div>
            )}


            {
                !status.email_config_ready && (
                    <div className="org-warning-banner">
                        Configure la cuenta de correo en{" "}
                        <strong>Ajustes → Correo</strong> antes de activar
                        los reportes automáticos.
                    </div>
                )
            }


            <div className="notify-status-grid">

                <div className={`notify-status-card ${form.enabled ? "ok" : "muted"}`}>
                    <span className="notify-status-label">Estado</span>
                    <strong>{form.enabled ? "Programado" : "Desactivado"}</strong>
                    <span className="notify-status-meta">
                        {status.scheduler_running
                            ? "Servicio en ejecución"
                            : "Servicio no detectado"}
                    </span>
                </div>

                <div className="notify-status-card">
                    <span className="notify-status-label">Último envío</span>
                    <strong>{formatDateTime(status.last_sent_at)}</strong>
                    <span className="notify-status-meta">
                        {status.schedule_label || "Sin programación"}
                    </span>
                </div>

                <div className={`notify-status-card ${status.config_ready ? "ok" : "warn"}`}>
                    <span className="notify-status-label">Listo para enviar</span>
                    <strong>{status.config_ready ? "Sí" : "No"}</strong>
                    <span className="notify-status-meta">
                        {status.config_ready
                            ? `${recipientCount} destinatario(s)`
                            : (status.config_issues || []).join(", ") || "Revise correo y destinatarios"}
                    </span>
                </div>

                <div className={`notify-status-card ${status.email_config_ready ? "ok" : "warn"}`}>
                    <span className="notify-status-label">Cuenta de correo</span>
                    <strong>{status.email_config_ready ? "Configurada" : "Pendiente"}</strong>
                    <span className="notify-status-meta">
                        {status.email_account
                            ? `${status.email_provider_label}: ${status.email_account}`
                            : "Ajustes → Correo"}
                    </span>
                </div>

                <div className="notify-status-card">
                    <span className="notify-status-label">Próximo envío</span>
                    <strong>{status.next_send_hint || "—"}</strong>
                    <span className="notify-status-meta">
                        Hora local del servidor NSP
                    </span>
                </div>

            </div>


            <div className="notify-report-preview">

                <h4>Contenido del reporte</h4>

                <ul>
                    <li>Resumen ejecutivo por equipo (consultas DNS y bloqueos)</li>
                    <li>Detalle de dominios visitados en el período</li>
                    <li>Intentos de acceso bloqueados</li>
                    <li>
                        Período del envío automático:{" "}
                        <strong>{status.report_period || "según frecuencia"}</strong>
                    </li>
                    <li>Archivo adjunto: <strong>historial-dns_*.xlsx</strong></li>
                </ul>

            </div>


            <div className="notify-section">

                <h4>Destinatarios y programación</h4>

                <div className="notify-form-grid">

                    <label className="notify-wide">
                        Destinatarios del reporte
                        <input
                            type="text"
                            value={form.to_emails}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, to_emails: e.target.value })
                            }
                            placeholder="dueno@empresa.com, ti@empresa.com"
                        />
                        <span className="notify-field-hint">
                            Separe varios correos con coma. También se usan para alertas del sistema si no hay otro destino.
                        </span>
                    </label>

                    <label>
                        Frecuencia
                        <select
                            value={form.frequency}
                            disabled={!isAdmin}
                            onChange={(e) =>
                                setForm({ ...form, frequency: e.target.value })
                            }
                        >
                            <option value="daily">Diaria — últimas 24 h</option>
                            <option value="weekly">Semanal — últimos 7 días</option>
                            <option value="monthly">Mensual — últimos 30 días</option>
                        </select>
                    </label>

                    <label>
                        Hora de envío
                        <input
                            type="time"
                            disabled={!isAdmin}
                            value={`${String(form.send_hour).padStart(2, "0")}:${String(form.send_minute).padStart(2, "0")}`}
                            onChange={(e) => {
                                const [h, m] = e.target.value.split(":");
                                setForm({
                                    ...form,
                                    send_hour: Number(h),
                                    send_minute: Number(m),
                                });
                            }}
                        />
                        <span className="notify-field-hint">
                            Hora del servidor donde corre el NSP.
                        </span>
                    </label>

                </div>

            </div>


            <div className="notify-actions">

                <button
                    className="primary-button"
                    onClick={handleSave}
                    disabled={busy || !isAdmin}
                >
                    {busy ? "Guardando..." : "Guardar programación"}
                </button>

                <button
                    className="secondary-button"
                    onClick={handleSendNow}
                    disabled={busy || !isAdmin}
                >
                    Enviar reporte ahora
                </button>

            </div>

            {!isAdmin && (
                <p className="notify-readonly">Solo administradores pueden modificar esta sección.</p>
            )}

        </div>

    );

}


export default NotificationSection;
