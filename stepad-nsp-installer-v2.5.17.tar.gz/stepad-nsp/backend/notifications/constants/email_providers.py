EMAIL_PROVIDERS = {
    "gmail": {
        "label": "Gmail / Google Workspace",
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 587,
        "hint": (
            "Con verificación en dos pasos activa, use una "
            "contraseña de aplicación (no la contraseña normal)."
        ),
    },
    "outlook": {
        "label": "Outlook.com / Hotmail",
        "smtp_host": "smtp-mail.outlook.com",
        "smtp_port": 587,
        "hint": "Use la contraseña de su cuenta Microsoft.",
    },
    "office365": {
        "label": "Microsoft 365 / Exchange",
        "smtp_host": "smtp.office365.com",
        "smtp_port": 587,
        "hint": "Cuenta corporativa Microsoft 365 o Exchange Online.",
    },
    "yahoo": {
        "label": "Yahoo Mail",
        "smtp_host": "smtp.mail.yahoo.com",
        "smtp_port": 587,
        "hint": "Genere una contraseña de aplicación en la seguridad de Yahoo.",
    },
    "custom": {
        "label": "Otro / personalizado",
        "smtp_host": "",
        "smtp_port": 587,
        "hint": "Indique servidor SMTP, puerto, cuenta y contraseña.",
    },
}


def detect_provider(
    smtp_host: str,
) -> str:

    host = (smtp_host or "").strip().lower()

    for key, preset in EMAIL_PROVIDERS.items():

        if key == "custom":
            continue

        if preset["smtp_host"].lower() == host:

            return key

    return "custom"


def provider_preset(
    provider: str,
) -> dict:

    return EMAIL_PROVIDERS.get(provider, EMAIL_PROVIDERS["custom"])
