from sqlalchemy import inspect, text
from sqlalchemy.exc import IntegrityError, OperationalError, ProgrammingError
from sqlalchemy.orm import Session

from backend.notifications.models.email_settings import EmailSettings
from backend.notifications.models.notification_settings import (
    NotificationSettings,
)
from backend.notifications.constants.email_providers import detect_provider

from backend.shared.logging.logger import logger


def _table_exists(db: Session, name: str) -> bool:

    bind = db.get_bind()

    return name in inspect(bind).get_table_names()


def _create_email_settings_table(db: Session) -> None:

    bind = db.get_bind()

    logger.warning(
        "Tabla email_settings ausente; creando esquema."
    )

    EmailSettings.__table__.create(bind, checkfirst=True)


def _seed_from_notifications(db: Session) -> EmailSettings | None:

    if not _table_exists(db, "notification_settings"):

        return None

    source = db.get(NotificationSettings, 1)

    if source is None:

        return None

    row = EmailSettings(
        id=1,
        provider=detect_provider(source.smtp_host or ""),
        smtp_host=source.smtp_host or "",
        smtp_port=source.smtp_port or 587,
        smtp_user=source.smtp_user,
        smtp_password=source.smtp_password,
        from_email=source.from_email or "",
    )

    db.add(row)

    try:

        db.commit()

    except IntegrityError:

        db.rollback()

        return db.get(EmailSettings, 1)

    db.refresh(row)

    return row


def _default_email_settings() -> EmailSettings:

    return EmailSettings(
        id=1,
        provider="custom",
        smtp_host="",
        smtp_port=587,
        smtp_user=None,
        smtp_password=None,
        from_email="",
    )


def _ensure_email_settings_row(db: Session) -> EmailSettings:

    if not _table_exists(db, "email_settings"):

        _create_email_settings_table(db)

    settings = db.get(EmailSettings, 1)

    if settings is not None:

        return settings

    settings = _seed_from_notifications(db)

    if settings is not None:

        return settings

    settings = _default_email_settings()

    db.add(settings)

    try:

        db.commit()

    except IntegrityError:

        db.rollback()

        existing = db.get(EmailSettings, 1)

        if existing is not None:

            return existing

        raise

    db.refresh(settings)

    return settings


def _repair_provider_column(db: Session, settings: EmailSettings) -> EmailSettings:

    if (settings.provider or "").strip():

        return settings

    settings.provider = detect_provider(settings.smtp_host or "")

    db.commit()

    db.refresh(settings)

    return settings


class EmailSettingsRepository:

    def get(
        self,
        db: Session,
    ) -> EmailSettings:

        try:

            settings = _ensure_email_settings_row(db)

            return _repair_provider_column(db, settings)

        except (OperationalError, ProgrammingError) as error:

            db.rollback()

            message = str(error).lower()

            if _table_exists(db, "email_settings") and "provider" in message:

                try:

                    db.execute(
                        text(
                            """
                            ALTER TABLE email_settings
                            ADD COLUMN IF NOT EXISTS provider VARCHAR(32)
                            NOT NULL DEFAULT 'custom'
                            """
                        )
                    )

                    db.commit()

                    settings = _ensure_email_settings_row(db)

                    return _repair_provider_column(db, settings)

                except Exception as alter_error:

                    db.rollback()

                    logger.exception(
                        "No se pudo reparar columna provider: %s",
                        alter_error,
                    )

            logger.exception(
                "Error accediendo email_settings: %s",
                error,
            )

            # Último intento: recrear fila por si la tabla quedó a medias.
            try:

                if _table_exists(db, "email_settings"):

                    db.execute(
                        text(
                            """
                            INSERT INTO email_settings (
                                id, provider, smtp_host, smtp_port,
                                smtp_user, smtp_password, from_email
                            )
                            VALUES (
                                1, 'custom', '', 587, NULL, NULL, ''
                            )
                            ON CONFLICT (id) DO NOTHING
                            """
                        )
                    )

                    db.commit()

                    row = db.get(EmailSettings, 1)

                    if row is not None:

                        return row

            except Exception as repair_error:

                db.rollback()

                logger.exception(
                    "Reparación email_settings falló: %s",
                    repair_error,
                )

            raise

    def save(
        self,
        db: Session,
        settings: EmailSettings,
    ):

        db.add(settings)

        db.commit()

        db.refresh(settings)

        return settings
