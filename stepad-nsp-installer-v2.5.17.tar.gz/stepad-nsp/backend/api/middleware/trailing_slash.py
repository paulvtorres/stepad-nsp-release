"""
HTTP middleware that tolerates mixed trailing-slash conventions in API routes.

Some routes were registered with a trailing slash, others without, and
cached frontend bundles may call either form. For mutating methods a 307
redirect would work but adds a round trip; this middleware retries the
alternate path internally so POST/PUT/PATCH bodies are preserved.
"""

from starlette.requests import Request
from starlette.responses import RedirectResponse


def register_trailing_slash_middleware(app):
    @app.middleware("http")
    async def tolerate_trailing_slash(request: Request, call_next):

        response = await call_next(request)

        if response.status_code not in (404, 405):

            return response

        path = request.url.path

        if path == "/" or path.endswith(".html"):

            return response

        alternate = path[:-1] if path.endswith("/") else path + "/"

        if alternate == path:

            return response

        # GET requests: a redirect is cheap and cache-friendly.
        if request.method == "GET":

            return RedirectResponse(
                str(request.url).replace(path, alternate),
                status_code=307,
            )

        scope = dict(request.scope)
        scope["path"] = alternate
        scope["raw_path"] = alternate.encode()

        retry = await call_next(Request(scope))

        if retry.status_code in (404, 405):

            return response

        return retry
