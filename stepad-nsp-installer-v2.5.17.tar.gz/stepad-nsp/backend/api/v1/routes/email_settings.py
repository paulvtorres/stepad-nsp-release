from fastapi import APIRouter, Depends, HTTPException

from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role

from backend.shared.constants.user_roles import UserRoles
from backend.shared.logging.logger import logger

from backend.notifications.services.email_settings_service import (
    EmailSettingsService,
)
from backend.notifications.schemas.email_settings import (
    EmailSettingsRequest,
)


router = APIRouter(
    prefix="/email",
    tags=["Email"],
)

service = EmailSettingsService()


@router.get("/settings")
def get_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):

    try:

        return service.get_settings(db)

    except Exception as error:

        logger.exception("GET /email/settings failed: %s", error)

        raise HTTPException(
            status_code=500,
            detail=f"No se pudo leer la cuenta de correo: {error}",
        ) from error


@router.get("/providers")
def list_providers(
    current_user: dict = Depends(get_current_user),
):

    return service.list_providers()


@router.put("/settings")
def save_settings(
    request: EmailSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    try:

        return service.save_settings(db, request)

    except Exception as error:

        logger.exception("PUT /email/settings failed: %s", error)

        raise HTTPException(
            status_code=500,
            detail=f"No se pudo guardar la cuenta de correo: {error}",
        ) from error


@router.post("/test")
def send_test(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):

    try:

        return service.send_test(db, None)

    except Exception as error:

        logger.exception("POST /email/test failed: %s", error)

        raise HTTPException(
            status_code=500,
            detail=f"No se pudo enviar la prueba: {error}",
        ) from error
