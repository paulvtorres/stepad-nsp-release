import { useEffect, useState } from "react";

import {
    createThreatPolicy,
    deleteThreatPolicy,
    getThreatPolicies,
    getThreatPolicyHistory,
    restoreThreatPolicyRevision,
    simulateThreatPolicy,
    updateThreatPolicy,
} from "../../services/api";


const EMPTY_SIMULATION = {
    signature: "",
    category: "",
    severity: "warning",
    src_ip: "",
    dst_ip: "",
    dst_port: "",
};

const EMPTY_FORM = {
    name: "",
    match_type: "category",
    match_value: "",
    action: "alert",
    priority: 100,
    enabled: true,
    description: "",
};

const MATCH_LABELS = {
    category: "Categoría",
    signature: "Firma",
    default: "Default",
};

const ACTION_LABELS = {
    ignore: "Ignorar",
    alert: "Solo alerta",
    quarantine: "Cuarentena automática",
    block_c2: "Bloquear C2",
    quarantine_and_block_c2: "Cuarentena + bloquear C2",
};


function matchText(policy) {

    if (policy.match_type === "default") return "Cualquier detección";

    return `${MATCH_LABELS[policy.match_type]}: ${policy.match_value}`;

}


export default function ThreatPolicyPanel({ isAdmin }) {

    const [policies, setPolicies] = useState([]);

    const [history, setHistory] = useState([]);

    const [form, setForm] = useState(EMPTY_FORM);

    const [editingId, setEditingId] = useState(null);

    const [loading, setLoading] = useState(true);

    const [working, setWorking] = useState(false);

    const [error, setError] = useState("");

    const [simForm, setSimForm] = useState(EMPTY_SIMULATION);

    const [simulation, setSimulation] = useState(null);

    const [simulating, setSimulating] = useState(false);


    async function simulate(event) {

        event.preventDefault();

        setSimulating(true);

        setSimulation(null);

        try {

            const result = await simulateThreatPolicy({
                ...simForm,
                dst_port: simForm.dst_port ? Number(simForm.dst_port) : null,
            });

            setSimulation(result);

        } catch (err) {

            setError(err.message || "No se pudo simular la detección.");

        } finally {

            setSimulating(false);

        }

    }


    async function load() {

        setLoading(true);

        try {

            const [result, historyResult] = await Promise.all([
                getThreatPolicies(),
                getThreatPolicyHistory(20),
            ]);

            setPolicies(result?.policies || []);
            setHistory(historyResult?.history || []);

            setError("");

        } catch (err) {

            setError(err.message || "No se pudieron cargar las políticas.");

        } finally {

            setLoading(false);

        }

    }


    useEffect(() => {
        load();
    }, []);


    function edit(policy) {

        setEditingId(policy.id);

        setForm({
            name: policy.name,
            match_type: policy.match_type,
            match_value: policy.match_value || "",
            action: policy.action,
            priority: policy.priority,
            enabled: policy.enabled,
            description: policy.description || "",
        });

    }


    function reset() {

        setEditingId(null);

        setForm(EMPTY_FORM);

    }


    async function submit(event) {

        event.preventDefault();

        if (!isAdmin) return;

        setWorking(true);

        setError("");

        try {

            const payload = {
                ...form,
                priority: Number(form.priority),
            };

            if (editingId) {

                await updateThreatPolicy(editingId, payload);

            } else {

                await createThreatPolicy(payload);

            }

            reset();

            await load();

        } catch (err) {

            setError(err.message || "No se pudo guardar la política.");

        } finally {

            setWorking(false);

        }

    }


    async function toggle(policy) {

        if (!isAdmin) return;

        setWorking(true);

        try {

            await updateThreatPolicy(policy.id, {
                ...policy,
                enabled: !policy.enabled,
            });

            await load();

        } catch (err) {

            setError(err.message || "No se pudo cambiar la política.");

        } finally {

            setWorking(false);

        }

    }


    async function restore(revision) {

        if (!isAdmin) return;

        if (!window.confirm(
            `¿Revertir "${revision.policy_name || "esta política"}" al estado anterior?`
        )) return;

        setWorking(true);

        try {

            await restoreThreatPolicyRevision(revision.id);

            await load();

        } catch (err) {

            setError(err.message || "No se pudo revertir la política.");

        } finally {

            setWorking(false);

        }

    }


    async function remove(policy) {

        if (!isAdmin) return;

        if (!window.confirm(`¿Eliminar la política "${policy.name}"?`)) return;

        setWorking(true);

        try {

            await deleteThreatPolicy(policy.id);

            await load();

        } catch (err) {

            setError(err.message || "No se pudo eliminar la política.");

        } finally {

            setWorking(false);

        }

    }


    return (

        <section className="threat-policy-panel">

            <div className="threat-policy-head">

                <div>
                    <h4>Política de respuesta IPS</h4>
                    <p>
                        Decide qué se alerta, qué se aísla y qué se bloquea.
                        La cuarentena automática global sigue siendo un
                        interruptor maestro.
                    </p>
                </div>
            </div>

            {error && <div className="threat-message">{error}</div>}

            <form className="threat-simulation-form" onSubmit={simulate}>

                <div className="threat-policy-head">
                    <div>
                        <h4>Probar una detección</h4>
                        <p>
                            Simula una firma antes de recibirla. No aísla,
                            no bloquea y no modifica la política.
                        </p>
                    </div>
                </div>

                <div className="threat-simulation-grid">
                    <label>
                        Firma
                        <input
                            value={simForm.signature}
                            onChange={(e) => setSimForm({ ...simForm, signature: e.target.value })}
                            placeholder="GPL SNMP public access udp"
                            required
                        />
                    </label>
                    <label>
                        Categoría
                        <input
                            value={simForm.category}
                            onChange={(e) => setSimForm({ ...simForm, category: e.target.value })}
                            placeholder="Attempted Information Leak"
                        />
                    </label>
                    <label>
                        Severidad
                        <select
                            value={simForm.severity}
                            onChange={(e) => setSimForm({ ...simForm, severity: e.target.value })}
                        >
                            <option value="warning">Warning</option>
                            <option value="critical">Critical</option>
                            <option value="info">Info</option>
                        </select>
                    </label>
                    <label>
                        IP origen
                        <input
                            value={simForm.src_ip}
                            onChange={(e) => setSimForm({ ...simForm, src_ip: e.target.value })}
                            placeholder="192.168.1.50"
                        />
                    </label>
                    <label>
                        IP destino
                        <input
                            value={simForm.dst_ip}
                            onChange={(e) => setSimForm({ ...simForm, dst_ip: e.target.value })}
                            placeholder="8.8.8.8"
                        />
                    </label>
                    <label>
                        Puerto destino
                        <input
                            type="number"
                            value={simForm.dst_port}
                            onChange={(e) => setSimForm({ ...simForm, dst_port: e.target.value })}
                            placeholder="443"
                        />
                    </label>
                </div>

                <div className="threat-policy-form-actions">
                    <button type="submit" className="secondary-button" disabled={simulating}>
                        {simulating ? "Simulando…" : "Simular"}
                    </button>
                </div>

                {simulation && (
                    <div className={`threat-simulation-result ${simulation.quarantine ? "danger" : "safe"}`}>
                        <strong>
                            {simulation.matched
                                ? `${simulation.policy?.name}: ${simulation.action_label}`
                                : "Sin política coincidente"}
                        </strong>
                        <p>{simulation.reason}</p>
                        <ul>
                            <li>Alerta: {simulation.alert ? "sí" : "no"}</li>
                            <li>Cuarentena: {simulation.quarantine ? "sí" : "no"}</li>
                            <li>Bloqueo C2: {simulation.block_c2 ? "sí" : "no"}</li>
                        </ul>
                    </div>
                )}

            </form>

            {loading ? (
                <p className="protection-empty">Cargando políticas…</p>
            ) : (
                <div className="threat-policy-table-wrap">
                    <table className="protection-table threat-policy-table">
                        <thead>
                            <tr>
                                <th>Prioridad</th>
                                <th>Nombre</th>
                                <th>Coincidencia</th>
                                <th>Acción</th>
                                <th>Estado</th>
                                <th />
                            </tr>
                        </thead>
                        <tbody>
                            {policies.map((policy) => (
                                <tr key={policy.id}>
                                    <td>{policy.priority}</td>
                                    <td>
                                        <strong>{policy.name}</strong>
                                        {policy.description && (
                                            <div className="threat-policy-description">
                                                {policy.description}
                                            </div>
                                        )}
                                    </td>
                                    <td>{matchText(policy)}</td>
                                    <td>{ACTION_LABELS[policy.action] || policy.action}</td>
                                    <td>{policy.enabled ? "Activa" : "Inactiva"}</td>
                                    <td className="threat-policy-actions">
                                        {isAdmin && (
                                            <>
                                                <button
                                                    type="button"
                                                    className="secondary-button"
                                                    onClick={() => edit(policy)}
                                                    disabled={working}
                                                >
                                                    Editar
                                                </button>
                                                <button
                                                    type="button"
                                                    className="secondary-button"
                                                    onClick={() => toggle(policy)}
                                                    disabled={working}
                                                >
                                                    {policy.enabled ? "Desactivar" : "Activar"}
                                                </button>
                                                <button
                                                    type="button"
                                                    className="secondary-button danger"
                                                    onClick={() => remove(policy)}
                                                    disabled={working}
                                                >
                                                    Eliminar
                                                </button>
                                            </>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {isAdmin && (
                <form className="threat-policy-form" onSubmit={submit}>
                    <h4>{editingId ? "Editar política" : "Nueva política"}</h4>

                    <div className="threat-policy-grid">
                        <label>
                            Nombre
                            <input
                                value={form.name}
                                onChange={(e) => setForm({ ...form, name: e.target.value })}
                                maxLength={80}
                                required
                            />
                        </label>

                        <label>
                            Tipo de coincidencia
                            <select
                                value={form.match_type}
                                onChange={(e) => setForm({ ...form, match_type: e.target.value })}
                            >
                                <option value="category">Categoría</option>
                                <option value="signature">Firma</option>
                                <option value="default">Default</option>
                            </select>
                        </label>

                        <label>
                            Valor (separar por coma)
                            <input
                                value={form.match_value}
                                onChange={(e) => setForm({ ...form, match_value: e.target.value })}
                                disabled={form.match_type === "default"}
                                placeholder="ej. snmp public access"
                            />
                        </label>

                        <label>
                            Acción
                            <select
                                value={form.action}
                                onChange={(e) => setForm({ ...form, action: e.target.value })}
                            >
                                {Object.entries(ACTION_LABELS).map(([value, label]) => (
                                    <option key={value} value={value}>{label}</option>
                                ))}
                            </select>
                        </label>

                        <label>
                            Prioridad
                            <input
                                type="number"
                                min={0}
                                max={10000}
                                value={form.priority}
                                onChange={(e) => setForm({ ...form, priority: e.target.value })}
                            />
                        </label>

                        <label className="threat-policy-check">
                            <input
                                type="checkbox"
                                checked={form.enabled}
                                onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                            />
                            Activa
                        </label>

                        <label className="threat-policy-wide">
                            Descripción
                            <input
                                value={form.description}
                                onChange={(e) => setForm({ ...form, description: e.target.value })}
                                maxLength={255}
                            />
                        </label>
                    </div>

                    <div className="threat-policy-form-actions">
                        <button type="submit" className="primary-button" disabled={working}>
                            {working ? "Guardando…" : editingId ? "Guardar cambios" : "Crear política"}
                        </button>
                        {editingId && (
                            <button type="button" className="secondary-button" onClick={reset}>
                                Cancelar
                            </button>
                        )}
                    </div>
                </form>
            )}

            <div className="threat-policy-history">

                <h4>Historial de cambios</h4>

                {history.length === 0 ? (
                    <p className="protection-empty">Sin cambios registrados.</p>
                ) : (
                    <div className="threat-policy-table-wrap">
                        <table className="protection-table threat-policy-table">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Acción</th>
                                    <th>Política</th>
                                    <th>Usuario</th>
                                    <th />
                                </tr>
                            </thead>
                            <tbody>
                                {history.map((revision) => (
                                    <tr key={revision.id}>
                                        <td>
                                            {revision.created_at
                                                ? new Date(revision.created_at).toLocaleString()
                                                : "—"}
                                        </td>
                                        <td>{revision.action}</td>
                                        <td>{revision.policy_name || "—"}</td>
                                        <td>{revision.username || "sistema"}</td>
                                        <td>
                                            {isAdmin && (
                                                <button
                                                    type="button"
                                                    className="secondary-button"
                                                    onClick={() => restore(revision)}
                                                    disabled={working}
                                                >
                                                    Revertir
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

            </div>

        </section>

    );

}
