from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.api.schemas.shares_request import (
    AssignShareDiskRequest,
    CreateShareFolderRequest,
    FormatShareDiskRequest,
    SetFolderGroupsRequest,
    SetGroupFoldersRequest,
    SetGroupVolumesRequest,
    ShareVolumeRequest,
    UpdateShareSettingsRequest,
)
from backend.auth.security.jwt_auth import get_current_user
from backend.auth.security.role_guard import require_role
from backend.core.database.dependency import get_db
from backend.shares.services.network_share_service import NetworkShareService
from backend.shared.constants.user_roles import UserRoles


router = APIRouter(
    prefix="/shares",
    tags=["Network Disk"],
)

service = NetworkShareService()


@router.get("/status")
def get_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return service.get_status(db)


@router.put("/config")
def update_config(
    request: UpdateShareSettingsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.update_settings(
        db,
        enabled=request.enabled,
        share_root=request.share_root,
        workgroup=request.workgroup,
        server_name=request.server_name,
    )


@router.post("/volumes/share")
def share_volume(
    request: ShareVolumeRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.share_volume(db, device=request.device, name=request.name)


@router.post("/volumes/{volume_id}/unshare")
def unshare_volume(
    volume_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.unshare_volume(db, volume_id)


@router.get("/groups/{group_id}/volumes")
def get_group_volumes(
    group_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return service.list_group_volumes(db, group_id)


@router.put("/groups/{group_id}/volumes")
def set_group_volumes(
    group_id: int,
    request: SetGroupVolumesRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.set_group_volumes(
        db,
        group_id,
        [v.model_dump() for v in request.volumes],
    )


@router.post("/disk")
def assign_disk(
    request: AssignShareDiskRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.assign_disk(db, request.device)


@router.post("/disk/release")
def release_disk(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.release_disk(db)


@router.post("/disk/format")
def format_disk(
    request: FormatShareDiskRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.format_disk(
        db,
        request.device,
        confirm=request.confirm,
        assign=request.assign,
        whole_disk=request.whole_disk,
    )


@router.get("/folders")
def list_folders(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return service.list_folders(db)


@router.post("/folders")
def create_folder(
    request: CreateShareFolderRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.create_folder(
        db,
        name=request.name,
        volume_id=request.volume_id,
        folder_name=request.folder_name,
        description=request.description,
    )


@router.delete("/folders/{folder_id}")
def delete_folder(
    folder_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.delete_folder(db, folder_id)


@router.put("/folders/{folder_id}/groups")
def set_folder_groups(
    folder_id: int,
    request: SetFolderGroupsRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.set_folder_groups(
        db,
        folder_id,
        [g.model_dump() for g in request.groups],
    )


@router.get("/groups/{group_id}/folders")
def get_group_folders(
    group_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return service.list_group_folders(db, group_id)


@router.put("/groups/{group_id}/folders")
def set_group_folders(
    group_id: int,
    request: SetGroupFoldersRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.set_group_folders(
        db,
        group_id,
        [f.model_dump() for f in request.folders],
    )


@router.post("/apply")
def apply_shares(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(UserRoles.ADMIN)),
):
    return service.apply(db)
