from sqlalchemy import Boolean, DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from datetime import datetime

from backend.core.database.base import Base


class NetworkShareSettings(Base):

    __tablename__ = "network_share_settings"

    id: Mapped[int] = mapped_column(primary_key=True)

    enabled: Mapped[bool] = mapped_column(Boolean, default=False)

    # Absolute path where shared folders live (mounted secondary disk).
    share_root: Mapped[str | None] = mapped_column(String(512), nullable=True)

    # Block device assigned as the network share disk (e.g. /dev/sdb1).
    device_path: Mapped[str | None] = mapped_column(String(128), nullable=True)

    # Persistent identity so the disk is remounted after reboot.
    device_uuid: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # When True the disk is the dedicated share volume and must not be
    # unmounted casually — only released from the NSP UI.
    disk_locked: Mapped[bool] = mapped_column(Boolean, default=False)

    workgroup: Mapped[str] = mapped_column(String(64), default="WORKGROUP")

    server_name: Mapped[str | None] = mapped_column(String(64), nullable=True)

    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )
