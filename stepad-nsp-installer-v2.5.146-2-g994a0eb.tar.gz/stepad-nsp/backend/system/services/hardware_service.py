import os
import platform
import socket
import subprocess
import time

from pathlib import Path

import psutil


SYSFS_NET = Path("/sys/class/net")

DMI = Path("/sys/class/dmi/id")


def _read(path):
    try:
        return path.read_text(encoding="utf-8", errors="ignore").strip()
    except Exception:
        return None


def _read_dmi(name):
    return _read(DMI / name)


class HardwareService:

    def get_hardware_info(
        self,
        enabled_requirements: dict | None = None
    ):

        cpu = self._cpu()

        memory = self._memory()

        return {
            "hostname": socket.gethostname(),
            "os": self._os_pretty(),
            "kernel": platform.release(),
            "platform": platform.platform(),
            "uptime_seconds": int(time.time() - psutil.boot_time()),
            "cpu": cpu,
            "memory": memory,
            "motherboard": self._motherboard(),
            "bios": self._bios(),
            "interfaces": self._interfaces(),
            "disks": self._disks(),
            "temperatures": self._temperatures(),
            "requirements": self._requirements(cpu, memory),
            "modules": self._module_checks(cpu, memory, enabled_requirements),
        }

    def _module_checks(self, cpu, memory, enabled_requirements):

        checks = []

        if not enabled_requirements:

            return checks

        cores = cpu.get("cores")

        ram_mb = memory.get("total_mb")

        for module in enabled_requirements.get("enabled", []):

            missing = []

            if cores is not None and cores < module["min_cores"]:

                missing.append(f"mín. {module['min_cores']} núcleos")

            if ram_mb is not None and ram_mb < module["min_ram_mb"]:

                missing.append(
                    f"mín. {round(module['min_ram_mb'] / 1024)} GB RAM"
                )

            checks.append({
                "key": module["key"],
                "name": module["name"],
                "status": "ok" if not missing else "critical",
                "missing": missing,
                "message": (
                    "El equipo cumple el mínimo para este módulo."
                    if not missing
                    else "Hardware insuficiente: " + ", ".join(missing)
                ),
            })

        return checks

    def _grade(self, value, minimum, recommended):

        if value is None:

            return {"status": "unknown", "value": value}

        if value >= recommended:

            return {"status": "ok", "value": value}

        if value >= minimum:

            return {"status": "warning", "value": value}

        return {"status": "critical", "value": value}

    def _requirements(self, cpu, memory):

        disk_free_gb = None

        try:

            disk_free_gb = round(
                psutil.disk_usage("/").free / 1024**3,
                1
            )

        except Exception:

            pass

        nic_speed = None

        for interface in self._interfaces():

            speed = interface.get("speed_mbps")

            if speed:

                nic_speed = max(nic_speed or 0, speed)

        cpu_check = self._grade(cpu.get("cores"), 2, 4)

        ram_check = self._grade(memory.get("total_mb"), 4096, 8192)

        disk_check = self._grade(disk_free_gb, 20, 40)

        nic_check = self._grade(nic_speed, 100, 1000)

        return {
            "cpu_cores": {
                "label": "CPU (núcleos)",
                "minimum": 2,
                "recommended": 4,
                "value": cpu_check["value"],
                "status": cpu_check["status"],
                "message": "4+ núcleos recomendados para IPS Suricata.",
            },
            "ram_mb": {
                "label": "Memoria (MB)",
                "minimum": 4096,
                "recommended": 8192,
                "value": ram_check["value"],
                "status": ram_check["status"],
                "message": "8 GB+ recomendados (Suricata usa ~600 MB).",
            },
            "disk_free_gb": {
                "label": "Disco libre (GB)",
                "minimum": 20,
                "recommended": 40,
                "value": disk_check["value"],
                "status": disk_check["status"],
                "message": "40 GB+ para logs (1 año) y respaldos.",
            },
            "nic_speed_mbps": {
                "label": "Tarjeta de red (Mbps)",
                "minimum": 100,
                "recommended": 1000,
                "value": nic_check["value"],
                "status": nic_check["status"],
                "message": "Gigabit recomendado para el enlace de red.",
            },
        }

    def _os_pretty(self):
        try:
            for line in Path("/etc/os-release").read_text(
                encoding="utf-8", errors="ignore"
            ).splitlines():
                if line.startswith("PRETTY_NAME="):
                    return line.split("=", 1)[1].strip().strip('"')
        except Exception:
            pass
        return platform.system() + " " + platform.release()

    def _cpu(self):
        info = {"cores": psutil.cpu_count(logical=False), "threads": psutil.cpu_count(logical=True)}
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        info["model"] = line.split(":", 1)[1].strip()
                        break
        except Exception:
            info["model"] = platform.processor()
        load1, load5, load15 = os.getloadavg()
        info["load"] = [round(load1, 2), round(load5, 2), round(load15, 2)]
        info["usage_percent"] = round(psutil.cpu_percent(interval=0.2), 1)
        return info

    def _memory(self):
        mem = psutil.virtual_memory()
        swap = psutil.swap_memory()
        return {
            "total_mb": round(mem.total / 1024**2),
            "used_mb": round(mem.used / 1024**2),
            "available_mb": round(mem.available / 1024**2),
            "percent": mem.percent,
            "swap_total_mb": round(swap.total / 1024**2),
            "swap_used_mb": round(swap.used / 1024**2),
        }

    def _motherboard(self):
        return {
            "vendor": _read_dmi("sys_vendor"),
            "product": _read_dmi("product_name"),
            "board_vendor": _read_dmi("board_vendor"),
            "board_name": _read_dmi("board_name"),
            "board_version": _read_dmi("board_version"),
            "board_serial": _read_dmi("board_serial"),
        }

    def _bios(self):
        return {
            "vendor": _read_dmi("bios_vendor"),
            "version": _read_dmi("bios_version"),
            "date": _read_dmi("bios_date"),
        }

    def _interfaces(self):
        interfaces = []
        for entry in sorted(SYSFS_NET.iterdir()):
            name = entry.name
            speed = _read(entry / "speed")
            interfaces.append({
                "name": name,
                "mac": _read(entry / "address"),
                "operstate": _read(entry / "operstate"),
                "speed_mbps": int(speed) if speed and speed.isdigit() else None,
                "type": self._iface_type(entry),
                "addresses": self._iface_addresses(name),
            })
        return interfaces

    def _iface_type(self, entry):
        iface_type = _read(entry / "type")
        mapping = {"1": "Ethernet", "772": "Wi-Fi", "65534": "Loopback", "65536": "Tunel/Virtual"}
        return mapping.get(iface_type, "Otro")

    def _iface_addresses(self, name):
        try:
            result = subprocess.run(
                ["ip", "-o", "addr", "show", "dev", name],
                capture_output=True,
                text=True,
                timeout=5,
            )
            addresses = []
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 4:
                    ip = parts[3].split("/")[0]
                    if ip and not ip.startswith("fe80"):
                        addresses.append(ip)
            return addresses
        except Exception:
            return []

    def _disks(self):
        disks = []
        for entry in sorted(Path("/sys/block").iterdir()):
            name = entry.name
            if name.startswith(("loop", "ram", "zram")):
                continue
            size_sectors = _read(entry / "size")
            rotational = _read(entry / "queue/rotational")
            size_gb = round(int(size_sectors) * 512 / 1024**3, 1) if size_sectors and size_sectors.isdigit() else None
            disk_info = {
                "name": name,
                "model": _read(entry / "device/model"),
                "size_gb": round(int(size_sectors) * 512 / 1024**3, 1) if size_sectors and size_sectors.isdigit() else None,
                "type": "HDD" if rotational == "1" else "SSD",
            }
            used_gb = None
            mountpoint = None
            for part in psutil.disk_partitions():
                if part.device.startswith(f"/dev/{name}"):
                    mountpoint = part.mountpoint
                    try:
                        usage = psutil.disk_usage(part.mountpoint)
                        used_gb = round(usage.used / 1024**3, 1)
                        break
                    except (PermissionError, OSError):
                        pass
            if used_gb is not None:
                disk_info["used_gb"] = used_gb
                disk_info["mountpoint"] = mountpoint
            disks.append(disk_info)
            })
        return disks

    def _temperatures(self):
        temps = {}
        try:
            temps_ = psutil.sensors_temperatures()
            for label, entries in temps_.items():
                if entries:
                    temps[label] = round(entries[0].current, 1) if entries[0].current else None
        except Exception:
            pass
        return temps
