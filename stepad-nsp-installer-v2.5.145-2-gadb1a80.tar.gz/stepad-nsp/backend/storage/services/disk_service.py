"""Gestion de discos conectados al NSP."""

import os
import subprocess
import json

from pathlib import Path
from datetime import datetime

from backend.shared.logging.logger import logger


MOUNT_BASE = "/mnt/stepad-disk"


class DiskService:

    def __init__(self):
        Path(MOUNT_BASE).mkdir(parents=True, exist_ok=True)

    def list_disks(self) -> list:
        disks = []
        try:
            result = subprocess.run(
                ["lsblk", "-J", "-o", "NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,MODEL"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for device in data.get("blockdevices", []):
                    if device.get("type") != "disk":
                        continue
                    disk = {
                        "name": device["name"],
                        "model": (device.get("model") or "").strip() or "Desconocido",
                        "size": device.get("size", ""),
                        "partitions": [],
                    }
                    for part in device.get("children", []):
                        if part.get("type") != "part":
                            continue
                        disk["partitions"].append({
                            "name": part["name"],
                            "size": part.get("size", ""),
                            "fstype": part.get("fstype") or "desconocido",
                            "mountpoint": part.get("mountpoint") or "",
                            "mounted": bool(part.get("mountpoint")),
                        })
                    disks.append(disk)
        except Exception as exc:
            logger.error("DiskService: %s", exc)
        return disks

    def mount(self, device: str, fstype: str = None) -> dict:
        try:
            dev_path = f"/dev/{device}"
            if not os.path.exists(dev_path):
                return {"success": False, "error": f"No existe {dev_path}"}
            mount_point = f"{MOUNT_BASE}/{device}"
            Path(mount_point).mkdir(parents=True, exist_ok=True)
            fs = fstype or self._detect_fs(dev_path)
            if fs == "ntfs":
                cmd = ["ntfs-3g", dev_path, mount_point]
            else:
                cmd = ["mount", dev_path, mount_point]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                cmd_ro = ["ntfs-3g", dev_path, mount_point, "-o", "ro"] if fs == "ntfs" else ["mount", "-o", "ro", dev_path, mount_point]
                result = subprocess.run(cmd_ro, capture_output=True, text=True, timeout=30)
                if result.returncode != 0:
                    return {"success": False, "error": result.stderr}
                return {"success": True, "mountpoint": mount_point, "readonly": True}
            return {"success": True, "mountpoint": mount_point, "readonly": False}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def unmount(self, device: str) -> dict:
        try:
            mount_point = f"{MOUNT_BASE}/{device}"
            result = subprocess.run(["umount", mount_point], capture_output=True, text=True, timeout=10)
            if result.returncode != 0:
                result = subprocess.run(["umount", "-l", mount_point], capture_output=True, text=True, timeout=10)
            return {"success": result.returncode == 0, "error": result.stderr}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def list_directory(self, path: str) -> list:
        try:
            target = Path(path)
            if not target.exists() or not target.is_dir():
                return []
            items = []
            for item in sorted(target.iterdir()):
                try:
                    stat = item.stat()
                    items.append({
                        "name": item.name,
                        "type": "directory" if item.is_dir() else "file",
                        "size": stat.st_size if item.is_file() else None,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    })
                except PermissionError:
                    items.append({"name": item.name, "type": "restricted", "size": None, "modified": None})
            return items
        except Exception:
            return []

    def create_folder(self, path: str, name: str) -> dict:
        try:
            folder = Path(path) / name
            if folder.exists():
                return {"success": False, "error": "Ya existe"}
            folder.mkdir(parents=True, exist_ok=True)
            return {"success": True, "path": str(folder)}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def delete_item(self, path: str) -> dict:
        try:
            target = Path(path)
            if not target.exists():
                return {"success": False, "error": "No existe"}
            if target.is_dir():
                target.rmdir()
            else:
                target.unlink()
            return {"success": True}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    def _detect_fs(self, device: str) -> str:
        try:
            result = subprocess.run(["blkid", "-s", "TYPE", "-o", "value", device], capture_output=True, text=True, timeout=5)
            return result.stdout.strip().lower()
        except Exception:
            return ""


disk_service = DiskService()
