import { useEffect, useMemo, useState } from "react";

import { useAuth } from "../../auth/useAuth";

import {
    getShareStatus,
    shareVolume,
    unshareVolume,
    formatShareDisk,
    deleteSharePartition,
    createSharePartition,
    unlockShareIntegrity,
    pauseShareIntegrity,
    resumeShareIntegrity,
    createShareFolder,
    deleteShareFolder,
    setShareFolderGroups,
    getGroups,
} from "../../services/api";

import "./shares.css";


function formatSize(bytes) {
    const n = Number(bytes);
    if (!Number.isFinite(n) || n <= 0) return "";
    const units = ["B", "KB", "MB", "GB", "TB"];
    let value = n;
    let i = 0;
    while (value >= 1024 && i < units.length - 1) {
        value /= 1024;
        i += 1;
    }
    return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}


function Shares() {

    const { user } = useAuth();
    const isAdmin = user?.role === "ADMIN";

    const [status, setStatus] = useState(null);
    const [groups, setGroups] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);
    const [names, setNames] = useState({});
    const [selectedDevice, setSelectedDevice] = useState(null);
    const [newPart, setNewPart] = useState({});     // diskDevice -> { sizeGb, role }
    const [folderDraft, setFolderDraft] = useState("");
    const [confirmUp, setConfirmUp] = useState(null); // { id, label, run }
    const [permOpen, setPermOpen] = useState(null);   // folderId with open panel
    const [permDraft, setPermDraft] = useState({});   // folderId -> [{group_id, access_mode}]

    useEffect(() => {
        if (!notice) return undefined;
        const timer = setTimeout(() => setNotice(null), 5000);
        return () => clearTimeout(timer);
    }, [notice]);

    function load() {
        Promise.all([getShareStatus(), getGroups().catch(() => [])])
            .then(([s, g]) => {
                setStatus(s);
                setGroups(g || []);
            })
            .catch((err) => setError(err.message || String(err)))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        load();
        const timer = setInterval(load, 20000);
        return () => clearInterval(timer);
    }, []);

    const disks = useMemo(() => status?.disks || [], [status]);

    const lanIp = status?.lan_ip;

    const allPartitions = useMemo(() => {
        const list = [];
        for (const disk of disks) {
            for (const part of disk.partitions || []) {
                list.push({ ...part, disk: disk.disk, model: disk.model, transport: disk.transport });
            }
        }
        return list;
    }, [disks]);

    const selected = useMemo(() => {
        if (!selectedDevice) return null;
        return allPartitions.find((p) => p.device === selectedDevice) || null;
    }, [allPartitions, selectedDevice]);

    useEffect(() => {
        if (!selectedDevice && allPartitions.length) {
            const shared = allPartitions.find((p) => p.sharing);
            setSelectedDevice((shared || allPartitions[0]).device);
        } else if (
            selectedDevice
            && allPartitions.length
            && !allPartitions.some((p) => p.device === selectedDevice)
        ) {
            const shared = allPartitions.find((p) => p.sharing);
            setSelectedDevice((shared || allPartitions[0]).device);
        }
    }, [allPartitions, selectedDevice]);

    const defaultGroup = useMemo(
        () => groups.find((g) => g.is_default) || null,
        [groups]
    );

    const selectedFolders = useMemo(() => {
        if (!selected?.volume_id) return [];
        return (status?.folders || []).filter(
            (f) => f.volume_id === selected.volume_id
        );
    }, [status, selected]);

    function partForm(diskDevice) {
        return newPart[diskDevice] || { sizeGb: "", role: "share" };
    }

    function setPartForm(diskDevice, patch) {
        setNewPart((prev) => ({
            ...prev,
            [diskDevice]: { ...partForm(diskDevice), ...patch },
        }));
    }

    function setUpError(message) {
        setError(message || null);
    }

    function askConfirm(id, label, run) {
        setConfirmUp({ id, label, run });
    }

    function runConfirmed() {
        const run = confirmUp?.run;
        if (!run) return;
        setConfirmUp(null);
        run();
    }

    async function handleShare(unit, event) {
        event?.stopPropagation();
        const device = unit?.device;
        if (!device) return;

        const name = (names[device] || unit.share_name || "").trim();
        if (!name) {
            setUpError("Escribe un nombre para la unidad compartida.");
            return;
        }

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await shareVolume({ device, name });
            setStatus(next);
            setSelectedDevice(device);
            setNotice(next?.message || `«${name}» compartida.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleUnshare(unit) {
        const volumeId = unit?.volume_id;
        const name = unit?.share_name || unit?.device;
        if (!volumeId) return;

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await unshareVolume(volumeId);
            setStatus(next);
            setNotice(`Se dejó de compartir «${name}».`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleFormat(unit) {
        const device = unit?.device;
        if (!device) return;

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await formatShareDisk({
                device,
                confirm: "FORMATEAR",
                assign: false,
                whole_disk: false,
            });
            setStatus(next);
            setNotice(next?.message || `${device} formateado.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleFormatWholeDisk(disk) {
        const device = disk?.device;
        if (!device) return;

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await formatShareDisk({
                device,
                confirm: "FORMATEAR",
                assign: false,
                whole_disk: true,
            });
            setStatus(next);
            if (next?.formatted_device) {
                setSelectedDevice(next.formatted_device);
            }
            setNotice(next?.message || `${device} formateado (1 partición ext4).`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDeletePartition(unit) {
        const device = unit?.device;
        if (!device) return;

        if (unit.sharing) {
            setUpError("Deja de compartir la partición antes de eliminarla.");
            return;
        }

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await deleteSharePartition({
                device,
                confirm: "ELIMINAR",
            });
            setStatus(next);
            setSelectedDevice(null);
            setNotice(next?.message || `Partición ${device} eliminada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleCreatePartition(disk, opts = {}) {
        const device = disk?.device;
        if (!device) return;

        const form = partForm(device);
        const useRemaining = Boolean(opts.useRemaining);
        const role = opts.role || form.role || "share";
        let sizeGb = null;
        if (!useRemaining) {
            const raw = opts.sizeGb != null ? opts.sizeGb : form.sizeGb;
            sizeGb = Number(raw);
            if (!Number.isFinite(sizeGb) || sizeGb <= 0) {
                setUpError("Indica el tamaño en GB.");
                return;
            }
        }

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await createSharePartition({
                disk: device,
                size_gb: useRemaining ? null : sizeGb,
                use_remaining: useRemaining,
                role,
            });
            setStatus(next);
            if (next?.created_device) {
                setSelectedDevice(next.created_device);
            }
            setNotice(next?.message || "Partición creada.");
            setPartForm(device, { sizeGb: "" });
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handlePauseIntegrity(hours) {
        const duration = hours || 1;
        if (!confirm(
            `¿Pausar la protección antiransomware por ${duration} hora(s)?\n\n`
            + "Úsalo solo para cargar muchos archivos. "
            + "Mientras esté pausada, un ransomware no se cortará automáticamente."
        )) return;

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            const next = await pauseShareIntegrity(duration);
            setStatus(next);
            setNotice(next?.message || `Protección pausada ${duration} h.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleCreateFolder() {
        if (!selected?.volume_id) return;
        const name = folderDraft.trim();
        if (!name) {
            setUpError("Escribe un nombre para la carpeta.");
            return;
        }

        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            await createShareFolder({
                name,
                volume_id: selected.volume_id,
            });
            setFolderDraft("");
            const next = await getShareStatus();
            setStatus(next);
            setNotice(`Carpeta «${name}» creada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function handleDeleteFolder(folder) {
        setUpError(null);
        setNotice(null);
        setBusy(true);
        try {
            await deleteShareFolder(folder.id);
            setPermOpen((current) => (current === folder.id ? null : current));
            const next = await getShareStatus();
            setStatus(next);
            setNotice(`Carpeta «${folder.name}» eliminada.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function openPerms(folder) {
        if (permOpen === folder.id) {
            setPermOpen(null);
            return;
        }
        setPermOpen(folder.id);
        setPermDraft((prev) => ({
            ...prev,
            [folder.id]: (folder.groups || []).map((g) => ({
                group_id: g.group_id,
                access_mode: g.access_mode,
            })),
        }));
    }

    function togglePermGroup(groupId) {
        setPermDraft((prev) => {
            const current = [...(prev[permOpen] || [])];
            const existing = current.find((g) => g.group_id === groupId);
            if (existing) {
                return {
                    ...prev,
                    [permOpen]: current.filter((g) => g.group_id !== groupId),
                };
            }
            return {
                ...prev,
                [permOpen]: [...current, { group_id: groupId, access_mode: "read" }],
            };
        });
    }

    function changePermMode(groupId, mode) {
        setPermDraft((prev) => ({
            ...prev,
            [permOpen]: (prev[permOpen] || []).map((g) =>
                g.group_id === groupId ? { ...g, access_mode: mode } : g
            ),
        }));
    }

    async function savePerms(folder) {
        const grants = permDraft[folder.id] || [];
        setBusy(true);
        setUpError(null);
        try {
            await setShareFolderGroups(folder.id, {
                groups: grants.map((g) => ({
                    group_id: g.group_id,
                    access_mode: g.access_mode,
                })),
            });
            const refreshed = await getShareStatus();
            setStatus(refreshed);
            setPermOpen(null);
            setNotice(
                grants.length === 0
                    ? `«${folder.name}» es pública para todos los equipos.`
                    : `Permisos de «${folder.name}» actualizados.`
            );
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    async function makePublic(folder) {
        setPermDraft((prev) => ({ ...prev, [folder.id]: [] }));
        setBusy(true);
        setUpError(null);
        try {
            await setShareFolderGroups(folder.id, { groups: [] });
            const refreshed = await getShareStatus();
            setStatus(refreshed);
            setPermOpen(null);
            setNotice(`«${folder.name}» es pública para todos los equipos.`);
        } catch (err) {
            setUpError(err.message || String(err));
        } finally {
            setBusy(false);
        }
    }

    function folderAccessLabel(folder) {
        const grants = folder.groups || [];
        if (grants.length === 0) {
            return { text: "Todos · Lectura/Escritura", cls: "public" };
        }
        const write = grants.some((g) => g.access_mode === "write");
        return {
            text: `${grants.length} grupo${grants.length === 1 ? "" : "s"} · ${write ? "Lectura/Escritura" : "Solo lectura"}`,
            cls: write ? "private" : "readonly",
        };
    }

    function isConfirming(id) {
        return confirmUp?.id === id;
    }

    function renderActionButton(id, actionLabel, onAction, options = {}) {
        const { danger = false, primary = false, disabled = false, title } = options;
        if (isConfirming(id)) {
            return (
                <span className="sh-confirm">
                    <span>{confirmUp.label}</span>
                    <button
                        type="button"
                        className="sh-btn sh-btn-sm danger"
                        disabled={busy}
                        onClick={runConfirmed}
                    >
                        Confirmar
                    </button>
                    <button
                        type="button"
                        className="sh-btn sh-btn-sm"
                        disabled={busy}
                        onClick={() => setConfirmUp(null)}
                    >
                        Cancelar
                    </button>
                </span>
            );
        }
        return (
            <button
                type="button"
                className={["sh-btn", "sh-btn-sm", danger ? "danger" : "", primary ? "primary" : ""]
                    .filter(Boolean).join(" ")}
                disabled={disabled || busy}
                title={title}
                onClick={() => {
                    if (options.confirmLabel) {
                        askConfirm(id, options.confirmLabel, onAction);
                    } else {
                        onAction();
                    }
                }}
            >
                {actionLabel}
            </button>
        );
    }

    if (loading && !status) {
        return <div className="sh-page"><p className="sh-loading">Cargando…</p></div>;
    }

    const sambaOk = Boolean(status?.samba?.installed);
    const integrity = status?.integrity || {};
    const integrityLocked = Boolean(integrity.locked);
    const integrityPaused = Boolean(integrity.paused);
    const diskHealth = status?.disk_health || null;
    const diskHealthProblems = (diskHealth?.disks || []).filter(
        (d) => d.level === "warning" || d.level === "critical"
    );

    return (
        <div className="sh-page sh-split-page">
            <header className="sh-hero">
                <div>
                    <p className="sh-eyebrow">Red</p>
                    <h1>Disco de red</h1>
                    <p className="sh-lede">
                        Unidades a la izquierda · carpetas y permisos a la derecha
                        {lanIp ? <> · acceso desde Windows: <code className="sh-inline-code">\\{lanIp}\</code></> : null}.
                    </p>
                </div>
            </header>

            {!sambaOk && (
                <div className="sh-banner warn">
                    Falta Samba. En el servidor: <code>sudo apt-get install -y samba</code>
                </div>
            )}

            {diskHealth && diskHealth.smartctl_installed === false && (
                <div className="sh-banner warn">
                    Vigilancia SMART no disponible. Instala: <code>sudo apt-get install -y smartmontools</code>
                </div>
            )}

            {diskHealthProblems.length > 0 && (
                <div className={`sh-banner ${diskHealth?.worst === "critical" ? "error" : "warn"}`}>
                    <strong>Salud del disco:</strong>
                    <ul className="sh-health-list">
                        {diskHealthProblems.map((d) => (
                            <li key={d.device}>
                                <code>{d.device}</code>
                                {d.model ? ` (${d.model})` : ""} — {d.message}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {integrityPaused && !integrityLocked && (
                <div className="sh-banner warn sh-integrity-banner">
                    <div>
                        <strong>Protección antiransomware pausada</strong>
                        <p>
                            Puedes cargar archivos sin cortes.
                            {integrity.paused_until
                                ? ` Se reactivará: ${new Date(integrity.paused_until).toLocaleString()}.`
                                : ""}
                        </p>
                    </div>
                    {isAdmin && (
                        <button
                            type="button"
                            className="sh-btn primary"
                            disabled={busy}
                            onClick={() => {
                                setUpError(null);
                                setNotice(null);
                                setBusy(true);
                                resumeShareIntegrity()
                                    .then(setStatus)
                                    .then(() => setNotice("Protección reactivada."))
                                    .catch((err) => setUpError(err.message || String(err)))
                                    .finally(() => setBusy(false));
                            }}
                        >
                            Reactivar
                        </button>
                    )}
                </div>
            )}

            {!integrityPaused && !integrityLocked && isAdmin && (
                <div className="sh-pause-bar">
                    <span>Carga masiva:</span>
                    {[1, 2, 4, 8].map((h) => (
                        <button
                            key={h}
                            type="button"
                            className="sh-btn"
                            disabled={busy}
                            onClick={() => handlePauseIntegrity(h)}
                        >
                            Pausar {h} h
                        </button>
                    ))}
                </div>
            )}

            {integrityLocked && (
                <div className="sh-banner error sh-integrity-banner">
                    <div>
                        <strong>Escritura bloqueada por protección antiransomware.</strong>
                        <p>
                            {integrity.detail
                                || "Se detectaron cambios masivos de archivos."}
                        </p>
                        <p>Los compartidos están en solo lectura. Revisa los PCs de la LAN para reactivar.</p>
                    </div>
                    {isAdmin && (
                        <button
                            type="button"
                            className="sh-btn danger"
                            disabled={busy}
                            onClick={() => {
                                if (!confirm(
                                    "¿Reactivar escritura? Revisa antes que no haya ransomware activo."
                                )) return;
                                setUpError(null);
                                setNotice(null);
                                setBusy(true);
                                unlockShareIntegrity()
                                    .then(setStatus)
                                    .then(() => setNotice("Escritura reactivada."))
                                    .catch((err) => setUpError(err.message || String(err)))
                                    .finally(() => setBusy(false));
                            }}
                        >
                            Reactivar escritura
                        </button>
                    )}
                </div>
            )}

            {error && <div className="sh-banner error">{error}</div>}
            {notice && <div className="sh-banner ok sh-notice">{notice}</div>}

            <div className="sh-split">
                <section className="sh-pane sh-pane-left">
                    <h2>Unidades</h2>
                    {disks.length === 0 ? (
                        <p className="sh-empty">Conecta un disco USB o uno adicional distinto del sistema.</p>
                    ) : (
                        disks.map((disk) => {
                            const bus = (disk.transport || "").toLowerCase() === "usb"
                                ? "USB"
                                : (disk.transport || "disco").toUpperCase();
                            const totalBytes = Number(disk.size) || 0;
                            const freeBytes = Number(disk.free) || 0;
                            const partitions = disk.partitions || [];
                            return (
                                <div key={disk.disk} className="sh-disk-block">
                                    <div className="sh-disk-head">
                                        <span className="sh-badge">{bus}</span>
                                        <strong>/dev/{disk.disk}</strong>
                                        {disk.model ? <span className="sh-muted">{disk.model}</span> : null}
                                        <span className="sh-muted">
                                            {formatSize(totalBytes)}
                                            {freeBytes > 0 ? ` · libre ${formatSize(freeBytes)}` : ""}
                                        </span>
                                    </div>

                                    <ul className="sh-part-list">
                                        {partitions.map((unit) => {
                                            const sharing = Boolean(unit.sharing);
                                            const active = selectedDevice === unit.device;
                                            const nameValue = names[unit.device] ?? (unit.share_name || "");

                                            return (
                                                <li
                                                    key={unit.device}
                                                    className={[
                                                        "sh-part-row",
                                                        sharing ? "sharing" : "",
                                                        active ? "selected" : "",
                                                    ].filter(Boolean).join(" ")}
                                                    onClick={() => setSelectedDevice(unit.device)}
                                                >
                                                    <div className="sh-part-main">
                                                        <div className="sh-part-title">
                                                            <strong>{unit.device}</strong>
                                                            <span className="sh-part-meta">{formatSize(unit.size)}</span>
                                                            <span className="sh-part-meta">{unit.fstype || "sin formato"}</span>
                                                            {sharing ? (
                                                                <span className="sh-badge green">Compartida · {unit.share_name}</span>
                                                            ) : unit.fstype ? (
                                                                <span className="sh-badge">Lista</span>
                                                            ) : null}
                                                        </div>
                                                        {!sharing && unit.fstype && (
                                                            <label
                                                                className="sh-name-field"
                                                                onClick={(e) => e.stopPropagation()}
                                                            >
                                                                <span>Nombre</span>
                                                                <input
                                                                    type="text"
                                                                    value={nameValue}
                                                                    disabled={!isAdmin || busy}
                                                                    placeholder="ej. Producción"
                                                                    maxLength={64}
                                                                    onChange={(e) =>
                                                                        setName(unit.device, e.target.value)
                                                                    }
                                                                />
                                                            </label>
                                                        )}
                                                    </div>
                                                    {isAdmin && (
                                                        <div
                                                            className="sh-part-actions"
                                                            onClick={(e) => e.stopPropagation()}
                                                        >
                                                            {sharing ? (
                                                                renderActionButton(
                                                                    `unshare:${unit.device}`,
                                                                    "Dejar de compartir",
                                                                    () => handleUnshare(unit),
                                                                    { danger: true, confirmLabel: "¿Dejar de compartir?" }
                                                                )
                                                            ) : !unit.fstype ? (
                                                                <>
                                                                    {renderActionButton(
                                                                        `fmt:${unit.device}`,
                                                                        "Formatear",
                                                                        () => handleFormat(unit),
                                                                        { confirmLabel: "¿Formatear? Se borrará todo." }
                                                                    )}
                                                                    {renderActionButton(
                                                                        `del:${unit.device}`,
                                                                        "Eliminar partición",
                                                                        () => handleDeletePartition(unit),
                                                                        { danger: true, confirmLabel: "¿Eliminar la partición?" }
                                                                    )}
                                                                </>
                                                            ) : (
                                                                <>
                                                                    {renderActionButton(
                                                                        `share:${unit.device}`,
                                                                        "Compartir",
                                                                        () => handleShare(unit),
                                                                        { primary: true, disabled: !nameValue.trim() }
                                                                    )}
                                                                    {renderActionButton(
                                                                        `del:${unit.device}`,
                                                                        "Eliminar partición",
                                                                        () => handleDeletePartition(unit),
                                                                        { danger: true, confirmLabel: "¿Eliminar la partición?" }
                                                                    )}
                                                                </>
                                                            )}
                                                        </div>
                                                    )}
                                                </li>
                                            );
                                        })}
                                    </ul>

                                    {isAdmin && disk.partitions.length === 0 && (
                                        <div className="sh-create-part">
                                            <p className="sh-part-hint">
                                                Disco sin particiones. Puedes formatearlo
                                                (crea una única partición ext4) o crear
                                                una partición con el tamaño que quieras.
                                            </p>
                                            {renderActionButton(
                                                `fmt-disk:${disk.device}`,
                                                "Formatear disco",
                                                () => handleFormatWholeDisk(disk),
                                                { danger: true, confirmLabel: "¿Formatear todo el disco? Se borrará." }
                                            )}
                                        </div>
                                    )}

                                    {isAdmin && disk.can_create_partition && (
                                        <div className="sh-create-part">
                                            <form
                                                className="sh-create-form"
                                                onSubmit={(e) => {
                                                    e.preventDefault();
                                                    handleCreatePartition(disk);
                                                }}
                                            >
                                                <input
                                                    type="number"
                                                    min="0.1"
                                                    step="any"
                                                    value={partForm(disk.device).sizeGb}
                                                    disabled={busy}
                                                    placeholder="Tamaño (GB)"
                                                    onChange={(e) =>
                                                        setPartForm(disk.device, { sizeGb: e.target.value })
                                                    }
                                                />
                                                <select
                                                    className="sh-create-select"
                                                    value={partForm(disk.device).role}
                                                    disabled={busy}
                                                    onChange={(e) =>
                                                        setPartForm(disk.device, { role: e.target.value })
                                                    }
                                                >
                                                    <option value="share">Para compartir</option>
                                                    <option value="backup">Para respaldo</option>
                                                </select>
                                                <button type="submit" className="sh-btn primary" disabled={busy}>
                                                    Crear partición
                                                </button>
                                            </form>
                                            <button
                                                type="button"
                                                className="sh-btn sh-btn-sm"
                                                disabled={busy}
                                                onClick={() => handleCreatePartition(disk, { useRemaining: true })}
                                            >
                                                Usar todo el espacio libre
                                            </button>
                                        </div>
                                    )}
                                </div>
                            );
                        })
                    )}
                </section>

                <section className="sh-pane sh-pane-right">
                    <h2>Carpetas</h2>
                    {!selected ? (
                        <p className="sh-empty">Selecciona una partición a la izquierda.</p>
                    ) : !selected.sharing ? (
                        <div className="sh-empty-block">
                            <p className="sh-empty">
                                <strong>{selected.device}</strong> no está compartida.
                            </p>
                            <p className="sh-empty">
                                {isAdmin
                                    ? "Escribe un nombre a la izquierda y pulsa Compartir."
                                    : "Pide a un administrador que la comparta."}
                            </p>
                        </div>
                    ) : (
                        <>
                            <div className="sh-content-head">
                                <span className="sh-badge green">Compartida</span>
                                <strong>{selected.share_name}</strong>
                                <span className="sh-muted">{selected.device}</span>
                                {selected.unc_path ? (
                                    <code className="sh-inline-code">{selected.unc_path}</code>
                                ) : null}
                            </div>

                            <div className="sh-toolbar">
                                {isAdmin && (
                                    <form
                                        className="sh-folder-create"
                                        onSubmit={(e) => {
                                            e.preventDefault();
                                            handleCreateFolder();
                                        }}
                                    >
                                        <input
                                            type="text"
                                            value={folderDraft}
                                            disabled={busy}
                                            placeholder="Nueva carpeta"
                                            maxLength={64}
                                            onChange={(e) => setFolderDraft(e.target.value)}
                                        />
                                        <button
                                            type="submit"
                                            className="sh-btn primary"
                                            disabled={busy || !folderDraft.trim()}
                                        >
                                            Crear
                                        </button>
                                    </form>
                                )}
                            </div>

                            {selectedFolders.length === 0 ? (
                                <div className="sh-empty-block">
                                    <p className="sh-empty">
                                        La unidad completa es visible para <strong>todos los equipos</strong>
                                        {defaultGroup ? ` (grupo por defecto «${defaultGroup.name}»)`.concat(".") : "."}
                                    </p>
                                    {isAdmin && (
                                        <p className="sh-empty">
                                            Crea una carpeta arriba para ordenar y asignar permisos por grupo.
                                        </p>
                                    )}
                                </div>
                            ) : (
                                <ul className="sh-folder-list">
                                    {selectedFolders.map((folder) => {
                                        const access = folderAccessLabel(folder);
                                        const draft = permDraft[folder.id];
                                        const isOpen = permOpen === folder.id;
                                        return (
                                            <li key={folder.id} className="sh-folder-card">
                                                <div className="sh-folder-row">
                                                    <span className="sh-folder-icon">📁</span>
                                                    <div className="sh-folder-info">
                                                        <strong>{folder.name}</strong>
                                                        {folder.unc_path ? (
                                                            <code className="sh-inline-code">{folder.unc_path}</code>
                                                        ) : null}
                                                    </div>
                                                    <span className={`sh-badge ${access.cls}`}>{access.text}</span>
                                                    {isAdmin && (
                                                        <span className="sh-folder-actions">
                                                            {renderActionButton(
                                                                `del-folder:${folder.id}`,
                                                                "Eliminar",
                                                                () => handleDeleteFolder(folder),
                                                                { danger: true, confirmLabel: "¿Eliminar la carpeta?" }
                                                            )}
                                                            <button
                                                                type="button"
                                                                className="sh-btn sh-btn-sm"
                                                                disabled={busy}
                                                                onClick={() => openPerms(folder)}
                                                            >
                                                                {isOpen ? "Cerrar" : "Permisos"}
                                                            </button>
                                                        </span>
                                                    )}
                                                </div>

                                                {isOpen && isAdmin && (
                                                    <div className="sh-perm-panel">
                                                        <p className="sh-perm-note">
                                                            Los grupos son los mismos que usás para reglas de bloqueo.
                                                            Sin grupos marcados, la carpeta es pública (grupo por defecto
                                                            {defaultGroup ? ` «${defaultGroup.name}»` : ""}).
                                                        </p>
                                                        {groups.length === 0 ? (
                                                            <p className="sh-part-hint">No hay grupos de dispositivos.</p>
                                                        ) : (
                                                            <ul className="sh-perm-list">
                                                                {groups.map((group) => {
                                                                    const grant = (draft || []).find(
                                                                        (g) => g.group_id === group.id
                                                                    );
                                                                    return (
                                                                        <li key={group.id} className="sh-perm-row">
                                                                            <label className="sh-perm-check">
                                                                                <input
                                                                                    type="checkbox"
                                                                                    checked={Boolean(grant)}
                                                                                    disabled={busy}
                                                                                    onChange={() => togglePermGroup(group.id)}
                                                                                />
                                                                                <span className="sh-perm-name">
                                                                                    {group.name}
                                                                                    {group.is_default
                                                                                        ? <em> · por defecto</em>
                                                                                        : null}
                                                                                    <small>
                                                                                        {" "}
                                                                                        {group.is_default
                                                                                            ? `(${group.devices} equipos, sin reglas)`
                                                                                            : `(${group.devices} equipos · ${group.rules} reglas)`}
                                                                                    </small>
                                                                                </span>
                                                                            </label>
                                                                            {grant && (
                                                                                <span className="sh-mode">
                                                                                    <button
                                                                                        type="button"
                                                                                        className={grant.access_mode === "read" ? "active" : ""}
                                                                                        disabled={busy}
                                                                                        onClick={() =>
                                                                                            changePermMode(group.id, "read")
                                                                                        }
                                                                                    >
                                                                                        Lectura
                                                                                    </button>
                                                                                    <button
                                                                                        type="button"
                                                                                        className={grant.access_mode === "write" ? "active" : ""}
                                                                                        disabled={busy}
                                                                                        onClick={() =>
                                                                                            changePermMode(group.id, "write")
                                                                                        }
                                                                                    >
                                                                                        Escritura
                                                                                    </button>
                                                                                </span>
                                                                            )}
                                                                        </li>
                                                                    );
                                                                })}
                                                            </ul>
                                                        )}
                                                        {(draft || []).length === 0 && (
                                                            <p className="sh-perm-lock-hint">
                                                                Pública · todos los equipos tienen Lectura/Escritura
                                                                de {defaultGroup ? `«${defaultGroup.name}»` : "todos"} por defecto.
                                                            </p>
                                                        )}
                                                        <div className="sh-perm-actions">
                                                            <button
                                                                type="button"
                                                                className="sh-btn"
                                                                disabled={busy}
                                                                onClick={() => makePublic(folder)}
                                                            >
                                                                Hacer pública
                                                            </button>
                                                            <button
                                                                type="button"
                                                                className="sh-btn primary"
                                                                disabled={busy}
                                                                onClick={() => savePerms(folder)}
                                                            >
                                                                Guardar
                                                            </button>
                                                        </div>
                                                    </div>
                                                )}

                                                {!isAdmin && !isOpen && access.cls === "public" && (
                                                    <p className="sh-part-hint">
                                                        Visible para todos los equipos.
                                                    </p>
                                                )}
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </>
                    )}
                </section>
            </div>
        </div>
    );
}


export default Shares;