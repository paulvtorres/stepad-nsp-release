"""Validación y normalización de direcciones de correo del NSP.

Los encabezados SMTP se escriben en ASCII. Aceptar una dirección con
caracteres Unicode (por ejemplo `sopòrte@...`) hacía fallar el envío
recién al construir el mensaje, silenciosamente para el operador.
"""

from __future__ import annotations

import re

from email.utils import parseaddr

_ADDR = re.compile(
    r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@"
    r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
    r"(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$"
)


def parse_email_list(value) -> list[str]:
    """Parse a comma/semicolon/space-separated list of ASCII addresses."""

    if value is None:
        return []

    raw = str(value).strip()

    if not raw:
        return []

    result = []
    seen = set()

    for part in re.split(r"[,;\s]+", raw):

        part = part.strip()

        if not part:
            continue

        _, address = parseaddr(part)

        address = (address or "").strip()

        if not address:
            raise ValueError(f"Correo inválido: {part!r}")

        if any(ord(char) > 127 for char in address):
            raise ValueError(
                f"El correo {address!r} contiene caracteres no ASCII; "
                "corregilo (por ejemplo, soporte@dominio.com)."
            )

        if not _ADDR.fullmatch(address):
            raise ValueError(f"Correo inválido: {address!r}")

        key = address.lower()

        if key not in seen:
            seen.add(key)
            result.append(address)

    return result


def validate_email_field(value, label: str) -> list[str]:
    try:
        return parse_email_list(value)
    except ValueError as error:
        raise ValueError(f"{label}: {error}") from error
