import pytest

from backend.notifications.utils.email_addresses import parse_email_list


def test_parse_email_list_accepts_common_separators():
    assert parse_email_list("a@example.com, b@example.com; c@example.com") == [
        "a@example.com",
        "b@example.com",
        "c@example.com",
    ]


def test_parse_email_list_deduplicates_case_insensitive():
    assert parse_email_list("A@example.com, a@example.com") == ["A@example.com"]


def test_parse_email_list_rejects_non_ascii_local_part():
    with pytest.raises(ValueError, match="no ASCII"):
        parse_email_list("sopòrte593@gmail.com")


def test_parse_email_list_rejects_invalid_address():
    with pytest.raises(ValueError, match="Correo inválido"):
        parse_email_list("sin-arroba")
