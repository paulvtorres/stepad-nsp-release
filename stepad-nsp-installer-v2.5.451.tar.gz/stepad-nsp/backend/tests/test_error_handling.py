from backend.api.middleware.error_handling import map_exception


def test_permission_error_is_403():

    assert map_exception(PermissionError("x")) == (403, "Permiso denegado")


def test_missing_file_is_404():

    assert map_exception(FileNotFoundError("x")) == (404, "Recurso no encontrado")


def test_timeout_is_504():

    assert map_exception(TimeoutError("x")) == (504, "Tiempo de espera agotado")


def test_unknown_error_is_500():

    assert map_exception(RuntimeError("x")) == (500, "Error interno del servidor")

    assert map_exception(ValueError("bug")) == (500, "Error interno del servidor")
