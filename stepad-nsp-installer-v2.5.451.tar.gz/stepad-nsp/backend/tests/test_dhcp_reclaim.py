"""Liberación automática de leases cuando el pool se agota."""

from datetime import datetime

from backend.dhcp.domain.leases import Lease
from backend.dhcp.domain.reclaim import select_reclaimable


CUT = datetime(2026, 10, 20)


def _lease(mac, ip):
    return Lease(0, mac, ip)


def test_libera_equipo_inactivo_ausente_y_sin_reserva():

    leases = [_lease("aa:00", "192.168.1.30")]

    meta = {
        "aa:00": {"last_seen": datetime(2026, 10, 1), "permanent": ""},
    }

    assert select_reclaimable(leases, set(), meta, CUT) == ["192.168.1.30"]


def test_no_libera_si_esta_en_la_red():

    leases = [_lease("aa:00", "192.168.1.30")]

    meta = {"aa:00": {"last_seen": datetime(2026, 10, 1), "permanent": ""}}

    assert select_reclaimable(leases, {"192.168.1.30"}, meta, CUT) == []


def test_no_libera_reservas():

    leases = [_lease("aa:00", "192.168.1.30")]

    meta = {
        "aa:00": {"last_seen": datetime(2026, 10, 1), "permanent": "192.168.1.30"},
    }

    assert select_reclaimable(leases, set(), meta, CUT) == []


def test_no_libera_equipos_recientes():

    leases = [_lease("aa:00", "192.168.1.30")]

    meta = {"aa:00": {"last_seen": datetime(2026, 10, 25), "permanent": ""}}

    assert select_reclaimable(leases, set(), meta, CUT) == []


def test_no_libera_sin_registro_en_la_base():

    leases = [_lease("aa:00", "192.168.1.30")]

    assert select_reclaimable(leases, set(), {}, CUT) == []


def test_no_libera_sin_fecha_de_ultima_conexion():

    leases = [_lease("aa:00", "192.168.1.30")]

    meta = {"aa:00": {"last_seen": None, "permanent": ""}}

    assert select_reclaimable(leases, set(), meta, CUT) == []
