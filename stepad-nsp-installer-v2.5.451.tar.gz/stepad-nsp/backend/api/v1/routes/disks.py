from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import FileResponse
import os
import subprocess

from backend.auth.security.role_guard import require_role
from backend.shared.constants.user_roles import UserRoles
from backend.storage.services.disk_service import disk_service

from backend.shared.logging.logger import logger


router = APIRouter(prefix="/disks", tags=["disks"])

_ADMIN = Depends(require_role(UserRoles.ADMIN))

_ROLE_LABELS = {"private": "Privada", "backup": "Respaldo", "shared": "Compartida"}


def _fs_label(device: str | None) -> str | None:
    if not device:
        return None
    try:
        out = subprocess.run(
            ["lsblk", "-no", "LABEL", device],
            capture_output=True, text=True, timeout=5,
        )
        for line in (out.stdout or "").splitlines():
            if line.strip():
                return line.strip()
    except Exception as error:
        logger.debug("disks._fs_label: %s", error)
    return None


def _device_for(path: str, uuid: str | None, device_path: str | None) -> str | None:
    try:
        out = subprocess.run(
            ["findmnt", "-no", "SOURCE", path],
            capture_output=True, text=True, timeout=5,
        )
        src = (out.stdout or "").strip().splitlines()
        if src and src[0]:
            return src[0]
    except Exception as error:
        logger.debug("disks._device_for: %s", error)
    if uuid and os.path.exists(f"/dev/disk/by-uuid/{uuid}"):
        return f"/dev/disk/by-uuid/{uuid}"
    if device_path and os.path.exists(device_path):
        return device_path
    return None


@router.get("/")
def list_disks(user=_ADMIN):
    # Limpiar stale al listar discos
    disk_service.cleanup_stale_mounts()
    return {"disks": disk_service.list_disks()}


@router.post("/mount")
def mount_disk(device: str, user=_ADMIN):
    return disk_service.mount(device)


@router.post("/unmount")
def unmount_disk(device: str, user=_ADMIN):
    return disk_service.unmount(device)


@router.get("/check")
def check_storage(user=Depends(require_role(UserRoles.OPERATOR))):
    """Verifica dispositivos conectados, limpia history stale y genera alertas."""
    # 1. Limpiar mount points y directorios stale
    cleaned = disk_service.cleanup_stale_mounts()

    # 2. Verificar respaldos afectados
    affected_backups = []
    try:
        from backend.shares.services.share_backup_service import ShareBackupService
        svc = ShareBackupService()
        jobs = svc._all_jobs()
        for job in jobs:
            dest = str(job.vault or svc._dest_folder(job.get("source_path") or ""))
            dest_parent = str(__import__("pathlib").Path(dest).parent)
            if not __import__("pathlib").Path(dest_parent).exists():
                affected_backups.append({
                    "id": job.get("id"),
                    "name": job.get("name"),
                    "destination": dest_parent,
                })
    except Exception as error:
        logger.debug("disks.check_storage: %s", error)
    return {
        "cleaned": cleaned,
        "affected_backups": affected_backups,
        "message": f"{len(cleaned)} directorios stale limpiados, {len(affected_backups)} respaldos afectados" if cleaned or affected_backups else "Todo OK",
    }


@router.get("/explore")
def explore_directory(path: str = Query(...), user=Depends(require_role(UserRoles.OPERATOR))):
    # Limpiar stale antes de explorar
    disk_service.cleanup_stale_mounts()
    return disk_service.explore(path)


@router.get("/mount-points")
def list_mount_points(
    exclude_backup: bool = Query(default=False),
    user=Depends(require_role(UserRoles.OPERATOR)),
):
    """Lista puntos de montaje útiles para el usuario (discos, USB, unidades de red).

    Incluye también los volúmenes registrados por el NSP aunque estén
    DESMONTADOS (p. ej. una partición privada o de respaldo): así el
    selector de restauración muestra todas las unidades, no solo las
    montadas en este momento."""
    # Limpiar directorios stale de discos desconectados
    disk_service.cleanup_stale_mounts()
    roots = disk_service._allowed_roots()
    seen = set()
    filtered = []
    for r in sorted(roots, key=lambda x: len(str(x)), reverse=True):
        path = str(r)
        if any(path.startswith(p) for p in ["/dev", "/proc", "/sys", "/run", "/etc"]):
            continue
        if any(path.startswith(s + "/") for s in seen):
            continue
        if path == "/mnt" and len(seen) > 0:
            continue
        seen.add(path)
        filtered.append({"path": path})

    # Agregar volúmenes registrados aunque estén desmontados (privadas,
    # compartidas, respaldo, USB). Evita duplicados con los ya listados.
    try:
        from backend.core.database.session import SessionLocal
        from backend.shares.models.network_share_volume import NetworkShareVolume
        db_sess = SessionLocal()
        try:
            for volume in db_sess.query(NetworkShareVolume).all():
                mp = str(getattr(volume, "mountpoint", "") or "").strip().rstrip("/")
                if not mp:
                    continue
                if any(p == mp for p in seen):
                    continue
                parents = [s for s in seen if mp.startswith(s + "/")]
                if parents:
                    continue  # ya cubierto por un ancestro
                seen.add(mp)
                filtered.append({"path": mp})
        finally:
            db_sess.close()
    except Exception as error:
        logger.debug("disks.list_mount_points: %s", error)
    # Enriquecer cada destino con identidad ÚTIL (rol + etiqueta + espacio),
    # nunca solo la ruta/letra de kernel.
    vol_by_mp = {}
    try:
        from backend.core.database.session import SessionLocal
        from backend.shares.models.network_share_volume import NetworkShareVolume
        _s = SessionLocal()
        try:
            for v in _s.query(NetworkShareVolume).all():
                mp = str(getattr(v, "mountpoint", "") or "").strip().rstrip("/")
                if mp:
                    vol_by_mp[mp] = v
        finally:
            _s.close()
    except Exception as error:
        logger.debug("disks.list_mount_points: %s", error)
    for entry in filtered:
        p = entry["path"]
        vol = vol_by_mp.get(str(p).rstrip("/"))
        purpose = (getattr(vol, "purpose", None) or "") if vol else ""
        vname = (getattr(vol, "name", None) or "") if vol else ""
        if not purpose and str(p).startswith("/mnt/stepad-network"):
            purpose = "network"
        role = _ROLE_LABELS.get(purpose) or ("Red" if purpose == "network" else "")
        device = _device_for(
            p,
            getattr(vol, "device_uuid", None),
            getattr(vol, "device_path", None),
        )
        fs_label = _fs_label(device)
        total = free = None
        try:
            st = os.statvfs(p)
            total = st.f_blocks * st.f_frsize
            free = st.f_bavail * st.f_frsize
        except Exception as error:
            logger.debug("disks.list_mount_points: %s", error)
        entry["role"] = purpose or None
        entry["purpose"] = purpose or None
        entry["volume_name"] = vname or None
        entry["fs_label"] = fs_label
        entry["total_bytes"] = total
        entry["free_bytes"] = free
        entry["mounted"] = os.path.ismount(p)
        parts = []
        if role:
            parts.append(role)
        if purpose == "network":
            parts.append(str(p).rstrip("/").split("/")[-1])
        elif vname and not vname.startswith("sd"):
            parts.append(vname)
        if fs_label:
            parts.append(fs_label)
        entry["label"] = " · ".join(parts) if parts else None

    # JAMÁS mostrar particiones de respaldo como destino de RESTAURACIÓN
    # (nunca se restaura sobre donde viven los repos).
    if exclude_backup:
        filtered = [
            e for e in filtered
            if (e.get("purpose") or e.get("role")) != "backup"
        ]

    return {"mount_points": filtered}


@router.get("/info")
def item_info(path: str = Query(...), user=_ADMIN):
    return disk_service.info(path)


@router.get("/search")
def search_items(path: str = Query(...), q: str = Query(...), user=_ADMIN):
    return disk_service.search(path, q)


@router.post("/mkdir")
def create_folder(path: str, name: str, user=_ADMIN):
    return disk_service.create_folder(path, name)


@router.post("/rename")
def rename_item(path: str, name: str, user=_ADMIN):
    return disk_service.rename(path, name)


@router.post("/move")
def move_item(source: str, dest: str, user=_ADMIN):
    return disk_service.move(source, dest)


@router.post("/copy")
def copy_item(source: str, dest: str, user=_ADMIN):
    return disk_service.copy(source, dest)


@router.delete("/delete")
def delete_item(path: str, recursive: bool = False, user=_ADMIN):
    return disk_service.delete_item(path, recursive=recursive)


@router.get("/download")
def download_item(path: str = Query(...), user=_ADMIN):
    target = disk_service.download_path(path)
    return FileResponse(
        target,
        media_type="application/octet-stream",
        filename=target.name,
    )


@router.post("/upload")
async def upload_items(
    path: str = Query(...),
    files: list[UploadFile] = File(...),
    user=_ADMIN,
):
    return await disk_service.upload(path, files)