from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response

from sqlalchemy import func
from sqlalchemy.orm import Session

from backend.core.database.dependency import get_db

from backend.auth.security.role_guard import require_role

from backend.dns.logging.repositories.dns_query_log_repository import (
    DnsQueryLogRepository
)

from backend.dns.logging.models.dns_query_log import DnsQueryLog

from backend.dns.logging.models.sni_log import SniLog

from backend.network.devices.models.network_device import NetworkDevice

from backend.shared.utils.datetimes import local_to_utc

from backend.notifications.services.report_service import ReportService

from backend.shared.constants.user_roles import UserRoles


router = APIRouter(
    prefix="/logs/navigation",
    tags=["Navigation Logs"],
    dependencies=[Depends(require_role(UserRoles.ADMIN))],
)


repository = DnsQueryLogRepository()

report_service = ReportService()



@router.get("/summary")
def get_navigation_summary(
    start: datetime | None = Query(None),
    end: datetime | None = Query(None),
    device_id: int | None = Query(None),
    domain: str | None = Query(None),
    db: Session = Depends(get_db),
):

    # Sin rango, escanear las millones de filas de navegación es muy
    # lento (~1 min). Por defecto se muestran los últimos 7 días, que es
    # lo que el panel "Páginas más visitadas" espera; el front puede pedir
    # un rango mayor explícitamente.
    if start is None:
        start = datetime.now() - timedelta(days=7)
    if end is None:
        end = datetime.now()

    rows = repository.find_summary(
        db,
        start=local_to_utc(start),
        end=local_to_utc(end),
        device_id=device_id,
        domain_contains=domain
    )

    return [
        {
            "device_id": row.device_id,
            "device_name": (
                row.device_hostname
                or row.hostname
                or row.ip_address
                or "Desconocido"
            ),
            "device_ip": row.client_ip or row.ip_address,
            "domain": row.domain,
            "visit_count": row.visit_count,
            "first_seen": _utc_aware(row.first_seen),
            "last_seen": _utc_aware(row.last_seen),
            "blocked_count": row.blocked_count or 0,
            "active_minutes": row.active_minutes or 0
        }
        for row in rows
    ]


@router.get("/live")
def get_live_browsing(
    db: Session = Depends(get_db),
):

    # Equipos con consultas DNS en los ultimos 10 minutos -> "navegando
    # ahora". El panel lo pinta en vivo.
    since = datetime.utcnow() - timedelta(minutes=10)

    rows = (
        db.query(
            DnsQueryLog.device_id,
            DnsQueryLog.client_ip,
            func.count(DnsQueryLog.id).label("queries"),
            func.max(DnsQueryLog.queried_at).label("last_seen"),
        )
        .filter(
            DnsQueryLog.queried_at >= since,
            DnsQueryLog.device_id.isnot(None),
            # Solo navegacion EFECTIVA: si el dominio estaba bloqueado,
            # el intento no cuenta como "navegando ahora".
            DnsQueryLog.blocked.is_(False),
        )
        .group_by(
            DnsQueryLog.device_id,
            DnsQueryLog.client_ip,
        )
        .order_by(
            func.count(DnsQueryLog.id).desc()
        )
        .all()
    )

    names = {}

    device_ids = [r.device_id for r in rows if r.device_id]

    if device_ids:

        for device in (
            db.query(NetworkDevice)
            .filter(NetworkDevice.id.in_(device_ids))
            .all()
        ):

            names[device.id] = (
                device.display_name
                or device.hostname
                or device.ip_address
                or "Desconocido"
            )

    active = [
        {
            "device_id": r.device_id,
            "device_name": names.get(
                r.device_id,
                "Desconocido"
            ),
            "ip": r.client_ip,
            "queries": r.queries,
            "last_seen": _utc_aware(r.last_seen),
        }
        for r in rows
    ]

    return {
        "active_count": len(active),
        "active": active,
    }


@router.get("/sni")
def get_sni_connections(
    minutes: int = Query(2, ge=1, le=1440),
    db: Session = Depends(get_db),
):

    # Dominios a los que cada equipo se CONECTO (SNI de TLS) AHORA
    # (ventana corta ~2 min). Complementa al DNS: captura la navegacion
    # en el momento, cada conexion HTTPS.
    from datetime import timedelta

    since = datetime.utcnow() - timedelta(minutes=minutes)

    rows = (
        db.query(
            SniLog.src_ip,
            SniLog.domain,
            func.count(SniLog.id).label("connections"),
            func.max(SniLog.created_at).label("last_seen"),
        )
        .filter(SniLog.created_at >= since)
        .group_by(
            SniLog.src_ip,
            SniLog.domain,
        )
        .order_by(
            func.count(SniLog.id).desc()
        )
        .all()
    )

    ips = [r.src_ip for r in rows]

    names = {}

    if ips:

        for device in (
            db.query(NetworkDevice)
            .filter(NetworkDevice.ip_address.in_(ips))
            .all()
        ):

            names[device.ip_address] = (
                device.display_name
                or device.hostname
                or device.ip_address
                or "Desconocido"
            )

    return {
        "minutes": minutes,
        "connections": [
            {
                "device_name": names.get(
                    r.src_ip,
                    r.src_ip
                ),
                "ip": r.src_ip,
                "domain": r.domain,
                "connections": r.connections,
                "last_seen": _utc_aware(r.last_seen),
            }
            for r in rows
        ],
    }


def _utc_aware(value):
    """Los logs se guardan en UTC (naive); se marcan como UTC para que
    el frontend los convierta a la hora local del navegador."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


@router.get("/export")
def export_navigation_summary(
    start: datetime | None = Query(None),
    end: datetime | None = Query(None),
    device_id: int | None = Query(None),
    domain: str | None = Query(None),
    db: Session = Depends(get_db),
):

    # Mismo criterio que /summary: sin rango, limitar a los últimos 7 días
    # para no exportar millones de filas (lentísimo y pesado).
    if start is None:
        start = datetime.now() - timedelta(days=7)
    if end is None:
        end = datetime.now()

    utc_start = local_to_utc(start)
    utc_end = local_to_utc(end)

    device_label = None

    if device_id is not None:

        device = db.get(NetworkDevice, device_id)

        if device is not None:

            device_label = (
                device.hostname
                or device.ip_address
                or f"ID {device_id}"
            )

    buffer = report_service.build_excel(
        db,
        start=utc_start,
        end=utc_end,
        device_id=device_id,
        domain=domain,
        device_label=device_label,
    )

    start_tag = start.strftime("%Y%m%d") if start else "inicio"
    end_tag = end.strftime("%Y%m%d") if end else "fin"

    filename = f"historial-dns_{start_tag}-{end_tag}.xlsx"

    return Response(
        content=buffer.getvalue(),
        media_type=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                f'attachment; filename="{filename}"'
            )
        }
    )
