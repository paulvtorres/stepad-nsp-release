"""Standard health and Prometheus metrics endpoints."""

import ipaddress
import os
import shutil
import subprocess
import time

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse

from sqlalchemy import text
from sqlalchemy.orm import Session

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.dependency import get_db
from backend.shared.constants.app_version import APP_VERSION
from backend.shared.logging.logger import logger
from pathlib import Path


router = APIRouter(tags=["observability"])

_STARTED_AT = time.time()

PRIVATE_NETWORKS = tuple(
    ipaddress.ip_network(net)
    for net in (
        "127.0.0.0/8",
        "::1/128",
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
        "100.64.0.0/10",
    )
)


def is_private_client(host: str) -> bool:

    """Allow metrics only from loopback, LAN, Tailscale or private ranges."""

    try:

        address = ipaddress.ip_address((host or "").strip())

    except ValueError:

        return False

    return any(address in network for network in PRIVATE_NETWORKS)


def _lease_count() -> int:

    try:

        with open(DNSMASQ_LEASES_FILE, encoding="utf-8") as handle:

            return sum(1 for line in handle if line.strip())

    except OSError:

        return 0


def _process_running(pattern: str) -> int:

    try:

        result = subprocess.run(
            ["pgrep", "-f", pattern],
            capture_output=True,
            timeout=5,
        )

        return 1 if result.returncode == 0 else 0

    except Exception:

        return 0


def _installed_version() -> str:

    try:

        return Path("/etc/stepad/version").read_text("utf-8").strip()

    except OSError:

        return APP_VERSION


@router.get("/healthz")
def healthz(db: Session = Depends(get_db)):

    database_ok = True

    try:

        db.execute(text("SELECT 1"))

    except Exception as error:

        logger.debug("healthz: database check failed: %s", error)

        database_ok = False

    return JSONResponse(
        {
            "status": "ok" if database_ok else "degraded",
            "version": _installed_version(),
            "uptime_seconds": int(time.time() - _STARTED_AT),
            "database": database_ok,
        },
        status_code=200 if database_ok else 503,
    )


@router.get("/metrics", response_class=PlainTextResponse)
def metrics(request: Request, db: Session = Depends(get_db)):

    client = request.client.host if request.client else ""

    if not is_private_client(client):

        raise HTTPException(status_code=403, detail="Forbidden")

    lines: list[str] = []

    def metric(name: str, value, labels: str = "", kind: str = "gauge"):

        lines.append(f"# TYPE {name} {kind}")
        lines.append(f"{name}{labels} {value}")

    try:

        usage = shutil.disk_usage("/")

        metric("stepad_up", 1)
        metric("stepad_uptime_seconds", int(time.time() - _STARTED_AT))
        metric("stepad_disk_free_bytes", usage.free)
        metric("stepad_disk_total_bytes", usage.total)
        metric(
            "stepad_disk_used_percent",
            round(usage.used * 100 / usage.total, 2),
        )

        try:

            db_size = db.execute(
                text("SELECT pg_database_size(current_database())")
            ).scalar()

            metric("stepad_database_size_bytes", int(db_size or 0))

            unread = db.execute(
                text("SELECT count(*) FROM alerts WHERE read = false")
            ).scalar()

            metric("stepad_alerts_unread", int(unread or 0))

            last_backup = db.execute(
                text("SELECT last_backup_at FROM backup_settings LIMIT 1")
            ).scalar()

            if last_backup is not None:

                age = (datetime_utc_now() - last_backup).total_seconds()

                metric("stepad_backup_age_seconds", int(max(0, age)))

                metric("stepad_backup_ok", 1 if age < 36 * 3600 else 0)

            else:

                metric("stepad_backup_ok", 0)

        except Exception as error:

            logger.debug("metrics: database metrics failed: %s", error)

            metric("stepad_database_ok", 0)

        metric("stepad_dhcp_leases", _lease_count())
        metric("stepad_service_up", _process_running("dnsmasq"), '{service="dnsmasq"}')
        metric("stepad_service_up", _process_running("pdns_recursor"), '{service="pdns"}')

        try:

            active = subprocess.run(
                ["systemctl", "is-active", "suricata"],
                capture_output=True,
                text=True,
                timeout=5,
            ).stdout.strip()

            metric(
                "stepad_service_up",
                1 if active == "active" else 0,
                '{service="suricata"}',
            )

        except Exception:

            metric("stepad_service_up", 0, '{service="suricata"}')

        try:

            from backend.backups.services.restore_verification_service import (
                RestoreVerificationService,
            )

            state = RestoreVerificationService().status()

            metric(
                "stepad_backup_restore_verified",
                1 if state.get("success") else 0,
            )

        except Exception:

            pass

    except Exception as error:

        logger.warning("metrics: unexpected failure: %s", error)

        lines = ["# TYPE stepad_up gauge", "stepad_up 0"]

    return PlainTextResponse("\n".join(lines) + "\n")


def datetime_utc_now():

    from datetime import datetime

    return datetime.utcnow()
