"""Central error handling: clear JSON responses and a support reference.

Domain code still raises HTTPException with precise 4xx/409 messages.
Anything unexpected is logged with a traceback and returned as JSON with a
short request reference, instead of a bare "Internal Server Error".
"""

import uuid

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from backend.shared.logging.logger import logger


def map_exception(error: Exception) -> tuple[int, str]:

    """Map well-known OS errors to clear statuses; everything else is 500."""

    if isinstance(error, PermissionError):

        return 403, "Permiso denegado"

    if isinstance(error, FileNotFoundError):

        return 404, "Recurso no encontrado"

    if isinstance(error, TimeoutError):

        return 504, "Tiempo de espera agotado"

    return 500, "Error interno del servidor"


async def unhandled_exception_handler(
    request: Request,
    error: Exception,
) -> JSONResponse:

    reference = uuid.uuid4().hex[:12]

    status_code, detail = map_exception(error)

    logger.exception(
        "Error no controlado [%s] %s %s: %s",
        reference,
        request.method,
        request.url.path,
        error,
    )

    return JSONResponse(
        status_code=status_code,
        content={
            "detail": (
                f"{detail} (ref: {reference})"
                if status_code >= 500
                else detail
            ),
            "request_id": reference,
        },
        headers={"X-Request-ID": reference},
    )


def register_error_handlers(app: FastAPI) -> None:

    app.add_exception_handler(Exception, unhandled_exception_handler)
