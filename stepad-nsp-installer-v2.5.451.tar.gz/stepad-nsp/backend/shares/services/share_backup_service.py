"""
Versioned backups of shared volumes using restic (anti-ransomware).

Each job snapshots one directory (a shared volume mountpoint or folder)
into a dedicated, encrypted and deduplicated restic repository stored in
each unit's private vault folder:  {unit}/Respaldo/.backups/job-{id}.

The vault (the private "Respaldo" folder of every unit) is never exposed
through Samba -- shares.conf only references shared folder mountpoints under
/mnt/stepad-share -- so an SMB client (or ransomware moving through SMB)
cannot reach, list or delete the repositories.

Job definitions (characteristics) live in a hidden file inside each vault:
    {unit}/Respaldo/.respaldo.json

That file is the single source of truth for the backups: it assigns each new
job its sequential id and stores the schedule, retention, runtime state and
the flag that suppresses repeated "source missing" alerts. No database sync
is required, which avoids inconsistencies between the database and the disk.

A scheduler runs the enabled jobs on their schedule; when a job's source
directory disappears, an alert (SHARE_BACKUP_SOURCE_MISSING) is raised in
the alerts panel.

Retention keeps the newest N snapshots; when free space on the disk hosting
the repository drops below a threshold, `forget --keep-last N --prune`
trims old versions while preserving recent ones.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import threading
import time
from datetime import datetime, timedelta
from backend.shared.utils.datetimes import now_ecuador
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger
from backend.shares.services import share_backup_schedule as schedule_cache
from backend.shares.services import share_backup_store as config_store
from backend.shares.services import share_backup_schedule_time as schedule_time
from backend.shares.services import share_backup_restic as restic_runner
from backend.shares.services import share_backup_restore_ledger as restore_ledger
from backend.shared.security import secret_box
from backend.shared.utils.datetimes import to_iso_utc

# Limpieza: límite de ancho de banda del tráfico de red de los respaldos
# (QoS tc+ifb), por job: evita que restic sature el enlace hacia el origen.
from backend.shares.services import net_rate_shaper
from backend.shares.models.network_share_folder import NetworkShareFolder
from backend.shares.models.network_share_volume import NetworkShareVolume

SHARE_ROOT = Path("/mnt/stepad-share")
VOLUME_RESERVED_NAME = "Respaldo"
BACKUP_SUBDIR = ".backups"
CONFIG_FILENAME = config_store.CONFIG_FILENAME
CONFIG_SCHEMA = config_store.CONFIG_SCHEMA

# Watchdog de memoria: arranca UNA vez por proceso; si el backend se queda
# reteniendo RAM sin respaldo/restauración en curso, reinicia el servicio
# para que la NSP nunca quede bloqueada.
_MEMORY_WATCHDOG_STARTED = False

_MOUNT_INFO_CACHE: dict[str, tuple[float, set[str]]] = {}


def is_mountpoint_in_mountinfo(path: str) -> bool:
    """True si `path` figura como punto de montaje en /proc/mounts.

    Lectura instantánea (nunca toca el filesystem), segura con shares de red
    caídos. Un "mount fantasma" del namespace del servicio aparece aquí sin
    que el contenido real sea accesible."""
    try:
        with open("/proc/mounts", encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                parts = raw.split()
                if len(parts) >= 2 and parts[1].rstrip("/") == path.rstrip("/"):
                    return True
    except OSError:
        pass
    return False


def mount_point_name(path: Path) -> str | None:
    """Nombre del mount más cercano (ancestro o igual) sin tocar el FS.

    Lee ``/proc/mounts`` (instantáneo, no se cuelga) y devuelve el mountpoint
    más específico que contiene a ``path``, o None si no hay ninguno. Nunca
    ejecuta syscalls sobre el filesystem, así que es seguro con shares de red
    caídos."""
    text = str(path)
    cache = _MOUNT_INFO_CACHE.get(text)
    now = time.monotonic()
    if cache and now - cache[0] < 2.0:
        mounts = cache[1]
    else:
        mounts: set[str] = set()
        try:
            with open("/proc/mounts", encoding="utf-8", errors="replace") as fh:
                for raw in fh:
                    parts = raw.split()
                    if len(parts) >= 2:
                        mounts.add(parts[1])
        except OSError:
            return None
        _MOUNT_INFO_CACHE[text] = (now, mounts)
    best = None
    for mp in mounts:
        if text == mp or text.startswith(mp.rstrip("/") + "/"):
            if best is None or len(mp) > len(best):
                best = mp
    return best

POLL_SECONDS = 60

RECONCILE_SECONDS = 300

# Raíces del sistema operativo: nunca se tratan como unidades de datos.
_SYSTEM_MOUNTS = {
    "/", "/boot", "/boot/efi", "/home", "/var", "/usr", "/etc", "/opt",
    "/srv", "/tmp", "/root", "/bin", "/sbin", "/lib", "/dev", "/proc",
    "/sys", "/run", "[SWAP]", "/snap",
}

SOURCE_MISSING_ALERT = "SHARE_BACKUP_SOURCE_MISSING"

# Alerta cuando un job lleva varios intentos fallidos seguidos (ver
# _finish_run). Antes solo existía alerta para "la carpeta desapareció";
# cualquier otro fallo (credenciales, restic roto, disco lleno, timeout)
# no generaba ninguna señal visible para el usuario -- solo una línea
# en logger.warning() que nadie revisa.
BACKUP_FAILING_ALERT = "SHARE_BACKUP_FAILING"

# Mantenimiento dinámico por job (todo genérico, sin valores por-máquina):
#  - integridad del repo (restic check) con intervalo configurable por job;
#  - test de restauración (demuestra el RTO) con intervalo y destino por job;
#  - watchdog de "ventana perdida": avisa si un job programado no corrió
#    su horario/interv a tiempo.
BACKUP_CHECK_FAILED_ALERT = "SHARE_BACKUP_CHECK_FAILED"
BACKUP_TEST_RESTORE_FAILED_ALERT = "SHARE_BACKUP_TEST_RESTORE_FAILED"
BACKUP_OVERDUE_ALERT = "SHARE_BACKUP_OVERDUE"

# Tolerancia del watchdog: minutos de cola después de la ventana para
# considerar "perdida" (evita falsos positivos con corridas en curso).
OVERDUE_GRACE_MINUTES = 15

# Ventana (min), después del horario programado, dentro de la cual el job
# diario todavía se considera "a tiempo" y se ejecuta. Fuera de esa ventana
# NO corre (no se "pone al día"): solo ejecuta en su franja programada.
SCHEDULE_SLOT_TOLERANCE_MINUTES = 30

# Detección de respaldo "colgado": si un respaldo (de red) no produce NINGUNA
# salida de restic durante este tiempo, se considera interrumpido (origen sin
# respuesta) y se aborta para que el próximo horario lo retome, en vez de
# quedar horas colgado sin registrar nada.
BACKUP_STALL_SECONDS = 1800

# Fiabilidad del ETA (tiempo restante estimado) mostrado durante un respaldo.
# Al inicio de la corrida la proyección es basura (poco progreso -> ">1 h").
# Solo se publica cuando hay suficiente avance y tiempo transcurrido; así no
# se muestra un "más de 1 hora" falso en los primeros segundos.

# Ruta del caché de programación (multi-bóveda). Constante de módulo para que
# los tests puedan apuntar a un tmp_path sin escribir en /etc/stepad.
SCHEDULE_CACHE_PATH = Path("/etc/stepad/backup_schedule.json")

# Bitácora persistente de RESTAURACIONES (para detectar/reanudar una
# restauración interrumpida tras un reinicio, corte o apagón). Constante de
# módulo para que los tests puedan apuntar a un tmp_path.
RESTORE_STATE_PATH = Path(
    os.environ.get("RESTORE_STATE_PATH", "/etc/stepad/restore_state.json")
)

# A partir de cuántos fallos consecutivos se levanta esa alerta. Menos
# que esto se asume que puede ser un problema transitorio (ej. un
# reinicio de red de un minuto) y no vale la pena alarmar todavía.
FAILURE_ALERT_THRESHOLD = 3

# Backoff entre reintentos tras un fallo, en minutos, según cuántos
# fallos consecutivos lleva el job (índice 0 = tras el 1er fallo, etc.;
# el último valor se repite para cualquier cantidad mayor de fallos).
# Sin esto, un job roto (ej. contraseña SMB incorrecta) se reintentaba
# cada POLL_SECONDS (60s) sin límite -- lo suficiente para bloquear una
# cuenta de Active Directory por política de intentos fallidos en
# cuestión de minutos.
FAILURE_BACKOFF_MINUTES = [5, 15, 30, 60]

# Cuántas corridas (éxito o fallo) se guardan por job en su bitácora.
HISTORY_LIMIT = 30


def _human_bytes(value: int | None) -> str:
    try:
        value = int(value or 0)
    except (TypeError, ValueError):
        value = 0
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024 or unit == "TiB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{int(value)} B"


def _empty_config() -> dict:
    return config_store.empty_config()


def _default_job() -> dict:
    return {
        "id": 0,
        "name": "",
        "source_path": "",
        "smb_user": "",
        "smb_password": "",
        "enabled": True,
        "schedule_mode": "daily",
        "schedule_hour": 2,
        "schedule_minute": 0,
        "schedule_times": None,
        "interval_minutes": None,
        "retention_count": 7,
        "prune_free_pct": 15,
        "folder_id": None,
        "change_hash": None,
        "tree_hash": None,
        "last_backup_at": None,
        "last_result": None,
        "last_snapshot_id": None,
        "last_bytes": 0,
        "source_missing_alerted": False,
        # Seguimiento de fallos consecutivos, para el backoff de is_due()
        # y la alerta de BACKUP_FAILING_ALERT (ver _finish_run).
        "consecutive_failures": 0,
        "last_attempt_at": None,
        "failure_alert_active": False,
        # Pausa manual (botón «saltar»): el job no corre hasta este instante.
        "skip_until": None,
        # Bitácora de corridas (más reciente al final); ver HISTORY_LIMIT.
        "history": [],
        # Límite de ancho de banda del respaldo de red (Mbps). None = auto
        # (50% del enlace, para no saturar la conectividad de los usuarios);
        # 0 = sin límite (explícito). Solo aplica a orígenes de red.
        "rate_limit_mbps": None,
        # Mantenimiento dinámico por job (política, no valores por-máquina):
        #  - check de integridad del repo (restic check) cada N días;
        #  - test de restauración cada N días a un scratch configurable;
        #    habilitado SOLO si el admin define test_restore_scratch.
        "check_enabled": True,
        "check_interval_days": 7,
        "last_check_at": None,
        "last_check_result": None,
        "test_restore_enabled": False,
        "test_restore_interval_days": 30,
        "test_restore_scratch": None,
        "last_test_restore_at": None,
        "last_test_restore_result": None,
        # Watchdog de ventana perdida (auto, sin config): se limpia en cuanto
        # el job vuelve a correr.
        "overdue_alerted": False,
    }


class Job(dict):
    """Job record augmented with its vault folder (never persisted)."""

    def __init__(self, *args, vault: Path | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.vault = vault
        self._start_memory_watchdog()
        self._net_reach_cache: dict[str, tuple[float, bool]] = {}

    def _start_memory_watchdog(self) -> None:
        """Red de seguridad anti-bloqueo: si el backend se queda reteniendo
        MEMORIA (p. ej. un streaming de descarga que no se cerró) y NO hay un
        respaldo/restauración en curso, reinicia el servicio automáticamente.
        Así la NSP nunca se queda bloqueada por un proceso colgado."""
        if os.environ.get("STEPAD_ENV") == "development":
            return
        global _MEMORY_WATCHDOG_STARTED
        if _MEMORY_WATCHDOG_STARTED:
            return
        _MEMORY_WATCHDOG_STARTED = True

        def _kv_bytes(path: str, key: str):
            try:
                for line in Path(path).read_text().splitlines():
                    if line.startswith(key):
                        return int(line.split()[1]) * 1024
            except Exception as error:
                logger.debug("share_backup_service._kv_bytes: %s", error)
                return None
            return None

        def _run():
            consecutive = 0
            while True:
                time.sleep(30)
                try:
                    total = _kv_bytes("/proc/meminfo", "MemTotal:")
                    rss = _kv_bytes("/proc/self/status", "VmRSS:")
                    if not total or not rss:
                        consecutive = 0
                        continue
                    ratio = rss / total
                    busy = False
                    if getattr(self, "_running_jobs", None):
                        busy = bool(self._running_jobs)
                    if getattr(self, "_restore_status", None):
                        for _rid, rst in self._restore_status.items():
                            if rst and rst.get("running"):
                                busy = True
                                break
                    if not busy:
                        # Señal dura: cualquier proceso restic vivo (backup,
                        # restauración o dump de descarga) = operación en curso
                        # -> NO reiniciar jamás a mitad.
                        try:
                            rep = subprocess.run(
                                ["pgrep", "-x", "restic"],
                                capture_output=True, timeout=10,
                            )
                            busy = rep.returncode == 0
                        except Exception as error:
                            logger.debug("share_backup_service._run: %s", error)
                    if ratio >= 0.80 and not busy:
                        consecutive += 1
                    else:
                        consecutive = 0
                    if consecutive >= 3:
                        logger.critical(
                            "Memoria CRÍTICA: proceso al %.0f%% de RAM sin "
                            "respaldo/restauración en curso. Reinicio "
                            "automático para no dejar la NSP bloqueada.",
                            ratio * 100,
                        )
                        subprocess.run(
                            ["systemctl", "restart", "stepad-nsp"],
                            capture_output=True, timeout=60,
                        )
                        return
                except Exception as error:
                    logger.warning("Watchdog de memoria: %s", error)

        threading.Thread(target=_run, daemon=True, name="mem-watchdog").start()


# Module-level singleton so the scheduler is shared across callers
# (monitoring component starts it; must not spawn duplicates).
_shared_instance = None


def get_share_backup_service():
    global _shared_instance
    if _shared_instance is None:
        _shared_instance = ShareBackupService()
    return _shared_instance


def next_global_job_id() -> int:
    """Próximo id de job único a nivel global (para creadores externos, p. ej.
    el job por defecto de una partición de respaldo)."""
    return get_share_backup_service()._next_global_job_id()


class ShareBackupService:

    def __init__(self):
        self._stop = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._running_jobs: set[int] = set()
        # Timestamp (ISO) de inicio de cada job en ejecución, para mostrar
        # "respaldo en curso desde hace N min" en la UI.
        self._running_since: dict[int, str] = {}
        # Contador de respaldos "por horario" (daily/interval) en curso.
        # Mientras sea > 0, el watch antiransomware (share_integrity_watch_
        # service) se salta su escaneo -- ver has_active_protected_backup().
        # on_change queda deliberadamente FUERA de esta protección.
        self._active_protected_backups = 0
        self._last_reconcile = 0.0
        # Migración one-shot: ids de job únicos entre bóvedas (evita que dos
        # bóvedas generen el mismo id y el scheduler ejecute el job equivocado).
        self._ids_renumbered = False
        # Ops de mantenimiento en curso por job: {(kind, job_id)}. Evita
        # lanzar dos check/test-restore simultáneos del mismo job.
        self._maintenance_active: set[tuple[str, int]] = set()
        # Mantenimiento SERIAL a nivel global: aunque haya muchos jobs, en un
        # mismo momento corre a lo sumo un check/test-restore (evita
        # estampidas de restic al desplegar o con muchas bóvedas).
        self._maintenance_lock = threading.Lock()
        # Procesos restic en curso por job (para poder "Parar").
        self._procs: dict[int, "subprocess.Popen"] = {}
        # Jobs cuyo respaldo en curso fue cancelado por el usuario.
        self._cancel_requested: set[int] = set()
        # Caché de tamaños de carpetas (path -> (monotonic, bytes)).
        self._size_cache: dict[str, tuple[float, int]] = {}
        # Progreso de respaldos en curso: job_id -> {files_done, files_total, bytes_done, bytes_total, current_file}
        self._progress: dict[int, dict] = {}
        # Resultado/estado de restauraciones en curso: job_id -> {running, error, result}
        self._restore_status: dict[int, dict] = {}
        # Última razón por la que no se pudo medir el origen (para la UI).
        self._last_size_error: str | None = None

    # ------------------------------------------------------------------
    # vault / config file storage (single source of truth)
    # ------------------------------------------------------------------

    @staticmethod
    def _inode(path):
        try:
            return os.stat(path).st_ino
        except (OSError, ValueError):
            return None

    def _vaults(self, db: Session | None = None) -> list[Path]:
        """Todas las bóvedas de respaldo (destinos posibles).

        Incluye:
          - la carpeta privada «Respaldo» de cada unidad local (convención);
          - cualquier subcarpeta de una unidad local que ya actúe como bóveda
            (tiene config `.respaldo.json` o repos `.backups`), detectada por
            archivos para que un repo real nunca se pierda sin la BD;
          - las unidades de red montadas (se listan, pero no valen como
            destino de respaldo);
          - si se pasa `db`, además TODAS las carpetas privadas de unidades
            locales (aunque aún no tengan respaldos).
        Si dos rutas apuntan al mismo directorio (hardlinks), solo devuelve
        una de ellas (el camino más corto)."""
        def as_vault(leaf: Path) -> Path | None:
            if not self._dir_live(leaf or Path()):
                return None
            try:
                inode = os.stat(leaf).st_ino
            except OSError:
                return None
            if inode in seen_inodes:
                return None
            seen_inodes.add(inode)
            return leaf

        seen_inodes: set[int] = set()
        vaults: list[Path] = []
        # SHARE_ROOT: unidades locales (unidad1/Respaldo, etc.)
        if SHARE_ROOT.is_dir():
            # Candidatos legítimos = directorios que son puntos de montaje
            # reales O que corresponden a un volumen registrado en la BD.
            # Evita que un montaje residual (p. ej. /mnt/stepad-share/sda1
            # que quedó en el root al eliminar/desmontar su partición) siga
            # apareciendo como bóveda fantasma con su programación vieja.
            registered = set()
            try:
                session = db or SessionLocal()
                try:
                    for row in session.query(NetworkShareVolume).all():
                        mp = (getattr(row, "mountpoint", None) or "").rstrip("/")
                        if mp:
                            registered.add(mp)
                finally:
                    if db is None:
                        session.close()
            except Exception as error:
                logger.warning("_vaults: no pude leer volúmenes registrados: %s", error)
            for volume in sorted(SHARE_ROOT.iterdir(), key=lambda c: len(str(c))):
                if not volume.is_dir():
                    continue
                # Debe ser un mount real o coincidir con un volumen registrado.
                volume_str = str(volume).rstrip("/")
                if (
                    not is_mountpoint_in_mountinfo(volume_str)
                    and volume_str not in registered
                ):
                    continue
                vault = as_vault(volume / VOLUME_RESERVED_NAME)
                if vault is None and volume_str in registered:
                    # RAÍZ (v2.5.308): la bóveda «Respaldo» de una partición
                    # REGISTRADA no debe desaparecer de la UI por un fallo
                    # transitorio del sondeo live (_dir_live corre en un
                    # thread que se abandona a los 2 s; bajo carga puede
                    # devolver False aunque la partición esté montada). Si la
                    # carpeta Respaldo existe físicamente, se mantiene: el
                    # config se lee del disco o cae al caché de programación.
                    reserved = volume / VOLUME_RESERVED_NAME
                    try:
                        if reserved.is_dir() and str(reserved).rstrip("/") not in {
                            str(v).rstrip("/") for v in vaults
                        }:
                            vaults.append(reserved)
                    except OSError:
                        pass
                elif vault is not None:
                    vaults.append(vault)
                # Subcarpetas de la unidad que ya son bóveda (config/repo).
                try:
                    children = list(volume.iterdir())
                except OSError:
                    children = []
                for child in children:
                    if not child.is_dir() or child.name == VOLUME_RESERVED_NAME:
                        continue
                    if child.name.startswith("."):
                        continue
                    if (child / CONFIG_FILENAME).is_file() or (child / BACKUP_SUBDIR).is_dir():
                        extra = as_vault(child)
                        if extra is not None:
                            vaults.append(extra)
        # Unidades de red: /mnt/stepad-network/{letter}/Respaldo
        network_base = Path("/mnt/stepad-network")
        if network_base.is_dir():
            try:
                network_entries = list(network_base.iterdir())
            except OSError:
                network_entries = []
            for mount_point in network_entries:
                # No listar rutas de una unidad de red desconectada: su
                # contenido no es legible y solo genera avisos falsos de
                # "repo huérfano" o destinos fantasma.
                if not self._dir_live(mount_point):
                    continue
                vault = as_vault(mount_point / VOLUME_RESERVED_NAME)
                if vault is not None:
                    vaults.append(vault)
        # Discos/externos/USB: cualquier montaje de datos detectado
        # dinámicamente en /proc/mounts (NSP es dinámico: se puede quitar un
        # disco y poner otro sin tocar config; no hay rutas fijas).
        self._add_data_mount_vaults(vaults_list=vaults, seen_inodes=seen_inodes, as_vault=as_vault)
        # Con BD: todas las carpetas privadas de unidades locales cuentan
        # como destino aunque todavía no tengan ningún respaldo.
        if db is not None:
            try:
                volumes = {
                    v.id: v
                    for v in db.query(NetworkShareVolume).all()
                    if v.mountpoint and "/mnt/stepad-network/" not in (v.mountpoint or "")
                }
                folders = db.query(NetworkShareFolder).filter(
                    NetworkShareFolder.shared.is_(False)
                ).all()
                for folder in folders:
                    volume = volumes.get(folder.volume_id)
                    root = Path(volume.mountpoint) if volume else None
                    if root is None or not folder.folder_name:
                        continue
                    extra = as_vault(root / folder.folder_name)
                    if extra is not None:
                        vaults.append(extra)
            except Exception as error:
                logger.warning("_vaults: no se pudieron cargar carpetas privadas: %s", error)
        return vaults

    def _add_data_mount_vaults(
        self,
        *,
        vaults_list: list,
        seen_inodes: set,
        as_vault,
    ) -> None:
        """Agrega bóvedas «Respaldo» desde cualquier montaje de datos activo.

        Lee /proc/mounts (nunca se cuelga) y considera los puntos de montaje
        con filesystems de datos (ext4, ntfs, exfat, vfat, cifs, xfs, btrfs…)
        que NO son el sistema. Para cada uno busca la carpeta «Respaldo» y
        subcarpetas con config/repo de respaldo. Así el NSP es dinámico: se
        puede quitar una unidad y poner otra y la bóveda se detecta sola."""
        if not hasattr(self, "_data_fstypes"):
            self._data_fstypes = {
                "ext2", "ext3", "ext4", "xfs", "btrfs", "ntfs", "ntfs3",
                "exfat", "vfat", "msdos", "fuseblk", "cifs", "smb3",
                "iso9660", "udf",
            }
        data_roots: set[str] = set()
        try:
            with open("/proc/mounts", encoding="utf-8", errors="replace") as fh:
                for raw in fh:
                    parts = raw.split()
                    if len(parts) < 2:
                        continue
                    fstype = parts[2]
                    mountpoint = parts[1]
                    if fstype not in self._data_fstypes:
                        continue
                    if mountpoint in _SYSTEM_MOUNTS:
                        continue
                    if mountpoint.startswith("/boot"):
                        continue
                    data_roots.add(mountpoint)
        except OSError:
            return

        for root_str in sorted(data_roots, key=len):
            root = Path(root_str)
            # El mount raíz puede estar caído (red): no tocar ni colgarse.
            if not self._dir_live(root):
                continue
            # «Respaldo» en la raíz de la unidad.
            vault = as_vault(root / VOLUME_RESERVED_NAME)
            if vault is not None:
                vaults_list.append(vault)
            # Subcarpetas de la unidad que ya son bóveda (config/repo).
            try:
                children = list(root.iterdir())
            except OSError:
                continue
            for child in children:
                if not self._dir_live(child):
                    continue
                if not child.is_dir() or child.name == VOLUME_RESERVED_NAME:
                    continue
                if child.name.startswith("."):
                    continue
                if (child / CONFIG_FILENAME).is_file() or (child / BACKUP_SUBDIR).is_dir():
                    extra = as_vault(child)
                    if extra is not None:
                        vaults_list.append(extra)

    def _vault_for_source(self, source: str) -> Path | None:
        """Bóveda (carpeta Respaldo) de la unidad que contiene el origen."""
        if not source:
            return None
        # Network source: use LOCAL vault, not the network vault
        if "/stepad-network/" in source or source.startswith("//") or source.startswith("\\\\"):
            local_vaults = [v for v in self._vaults() if "/stepad-network/" not in str(v)]
            return local_vaults[0] if local_vaults else (self._vaults()[0] if self._vaults() else None)
        if not SHARE_ROOT.is_dir():
            return None
        path = Path(source)
        candidates = [c for c in SHARE_ROOT.iterdir() if c.is_dir()]
        # Prefer the shortest path when multiple volumes resolve to the
        # same directory (hardlinks / bind-mounts).
        candidates.sort(key=lambda c: len(str(c)))
        for volume in candidates:
            vault = volume / VOLUME_RESERVED_NAME
            if vault.is_dir() and (
                path == volume or str(path).startswith(str(volume) + "/")
            ):
                return vault
        return None

    def _dest_folder(self, source: str) -> Path:
        vault = self._vault_for_source(source)
        return vault if vault is not None else Path("")

    def _vault_from_destination_path(self, destination: str, db: Session | None = None) -> Path | None:
        """Resuelve el destino elegido por el usuario a una bóveda local.

        Vale cualquier carpeta privada de una unidad local (incluida la
        convención «Respaldo»). Las de unidades de red montadas en
        stepad-network no. Devuelve None si no coincide con ninguna.
        """
        if not destination:
            return None
        target = Path(destination).resolve()
        for vault in self._vaults(db):
            if "/stepad-network/" in str(vault):
                continue
            if Path(str(vault)).resolve() == target:
                return vault
        return None

    def _mount_destination_if_backup(
        self,
        db: Session | None,
        vault,
    ) -> bool:
        """
        Antes de VALIDAR/guardar un job, si el destino vive en una
        partición de finalidad "backup" que está desmontada (montaje por
        demanda), la monta y crea la carpeta «Respaldo». Devuelve True si
        el destino quedó disponible.
        """
        if vault is None:
            return True
        try:
            vault_str = str(vault).strip().rstrip("/")
            from backend.shares.models.network_share_volume import NetworkShareVolume
            session = db or SessionLocal()
            own = session is db
            try:
                for volume in session.query(NetworkShareVolume).all():
                    purpose = getattr(volume, "purpose", "shared") or "shared"
                    if purpose != "backup":
                        continue
                    mp = str(volume.mountpoint or "").rstrip("/")
                    if not mp:
                        continue
                    if vault_str == mp or vault_str.startswith(mp + "/"):
                        from backend.shares.providers.share_disk_mount_provider import (
                            ShareDiskMountProvider,
                        )
                        provider = ShareDiskMountProvider()
                        if not provider.is_mounted_at(mp):
                            result = provider.mount_now(
                                uuid=volume.device_uuid,
                                mountpoint=mp,
                            )
                            if not result.get("success"):
                                logger.warning(
                                    "No se pudo montar partición Respaldo %s "
                                    "para guardar el job: %s",
                                    volume.name,
                                    result.get("message"),
                                )
                                return False
                        Path(mp).mkdir(parents=True, exist_ok=True)
                        (Path(mp) / "Respaldo").mkdir(
                            parents=True, exist_ok=True
                        )
                        return True
                return True
            finally:
                if not own:
                    session.close()
        except Exception as error:
            logger.warning("_mount_destination_if_backup: %s", error)
            return True

    def _assert_destination_is_backup(
        self,
        db: Session | None,
        vault,
    ) -> None:
        """
        El destino de un respaldo DEBE vivir dentro de una partición con
        finalidad "backup". Nunca se respalda sobre una unidad compartida
        ni privada (serían blanco de la red o de la web).
        """
        if vault is None:
            return
        try:
            vault_str = str(vault).strip().rstrip("/")
            if not vault_str:
                return
            from backend.shares.models.network_share_volume import NetworkShareVolume
            session = db or SessionLocal()
            own = session is db
            try:
                for volume in session.query(NetworkShareVolume).all():
                    purpose = getattr(volume, "purpose", "shared") or "shared"
                    mp = str(volume.mountpoint or "").rstrip("/")
                    if not mp:
                        continue
                    if vault_str == mp or vault_str.startswith(mp + "/"):
                        if purpose != "backup":
                            raise HTTPException(
                                status_code=400,
                                detail=(
                                    f"El destino «{vault_str}» está en una "
                                    f"partición «{volume.name}» de finalidad "
                                    f"«{purpose}». El destino de un respaldo "
                                    "debe ser una partición de tipo "
                                    "«Respaldo»."
                                ),
                            )
                        return
            finally:
                if not own:
                    session.close()
        except HTTPException:
            raise
        except Exception as error:
            logger.warning("_assert_destination_is_backup: %s", error)

    def _create_vault_for_source(self, source: str) -> "Path | None":
        """Crea la carpeta privada «Respaldo» de la unidad local que contiene
        el origen (primer uso). Devuelve la bóveda creada o None si el origen
        no vive en una unidad local."""
        if not source or "/stepad-network/" in source or source.startswith("//") or source.startswith("\\"):
            return None
        if not SHARE_ROOT.is_dir():
            return None
        path = Path(source)
        candidates = sorted(
            (c for c in SHARE_ROOT.iterdir() if c.is_dir()),
            key=lambda c: len(str(c)),
        )
        for volume in candidates:
            if path != volume and not str(path).startswith(str(volume) + "/"):
                continue
            vault = volume / VOLUME_RESERVED_NAME
            try:
                vault.mkdir(parents=True, exist_ok=True)
                return vault
            except OSError as error:
                logger.warning("No se pudo crear la carpeta «Respaldo» %s: %s", vault, error)
                return None
        return None

    def _create_vault_from_destination(self, destination: str) -> "Path | None":
        """Crea la carpeta privada «Respaldo» elegida como destino cuando aún
        no existe, solo si pertenece a una unidad LOCAL (carpeta raíz de
        SHARE_ROOT). Devuelve la bóveda o None si no califica."""
        if not destination or "/stepad-network/" in destination or not SHARE_ROOT.is_dir():
            return None
        target = Path(destination)
        if target.name != VOLUME_RESERVED_NAME:
            return None
        volume = target.parent
        if volume == SHARE_ROOT or volume.parent != SHARE_ROOT or not volume.is_dir():
            return None
        try:
            target.mkdir(parents=True, exist_ok=True)
            return target
        except OSError as error:
            logger.warning("No se pudo crear la carpeta «Respaldo» %s: %s", target, error)
            return None

    def _config_path(self, vault: Path) -> Path:
        return config_store.config_path(vault)

    def _load_config(self, vault: Path) -> dict:
        """FUENTE ÚNICA de lectura del config de una bóveda.

        - Si la partición está montada y su `.respaldo.json` es legible, el
          config REAL es la autoridad; además se aprovecha para REFRESCAR el
          espejo en caché si quedó desfasado (auto-reparación).
        - Si no es accesible (partición desmontada por demanda entre
          corridas), se sirve del espejo en caché (multi-bóveda, mirror
          completo, sin credenciales SMB).
        Nunca devuelve un registro parcial."""
        real = config_store.read_config(vault)
        if real is not None:
            try:
                self._ensure_cache_mirror(vault, real.get("jobs") or [])
            except Exception as error:
                logger.warning("No se pudo refrescar caché de %s: %s", vault, error)
            return real
        jobs = self._cache_jobs_for(vault)
        if jobs is not None:
            return {"jobs": jobs, "next_job_id": len(jobs) + 1}
        return _empty_config()

    # ------------------------------------------------------------------
    # Caché espejo multi-bóveda: fuente de lectura cuando la partición de
    # respaldo está desmontada. Formato v2 {"version":2,"by_vault":{path:[jobs]}}
    # (acepta el formato viejo v1 de una sola bóveda). Espeja el job COMPLETO
    # salvo credenciales SMB.
    # ------------------------------------------------------------------

    @staticmethod
    def _cache_entry_for(jobs: list) -> list:
        return schedule_cache.entry_for(jobs)

    def _read_cache_map(self) -> dict:
        return schedule_cache.read_cache_map(SCHEDULE_CACHE_PATH)

    def _write_cache_map(self, by_vault: dict) -> None:
        schedule_cache.write_cache_map(SCHEDULE_CACHE_PATH, by_vault)

    def _cache_jobs_for(self, vault: Path) -> list | None:
        return schedule_cache.jobs_for(SCHEDULE_CACHE_PATH, vault)

    def _mirror_to_cache(self, vault: Path, jobs: list) -> None:
        schedule_cache.mirror(SCHEDULE_CACHE_PATH, vault, jobs)

    def remove_schedule_cache_entry(self, vault: Path) -> None:
        """Elimina del espejo la entrada de una bóveda (p. ej. al borrar
        una partición de respaldo): así no queda rastro de esa
        programación."""
        schedule_cache.remove_entry(SCHEDULE_CACHE_PATH, vault)

    def _ensure_cache_mirror(self, vault: Path, jobs: list) -> None:
        """Refresca el espejo SOLO si difiere (evita escrituras repetidas)."""
        schedule_cache.ensure_mirror(SCHEDULE_CACHE_PATH, vault, jobs)

    def _save_config(self, vault: Path, config: dict) -> None:
        config = config_store.write_config(vault, config)
        # Espejo en caché (multi-bóveda): garantiza que la programación, el
        # historial y el estado sigan visibles aunque la partición de respaldo
        # esté desmontada. Una sola ruta de escritura (_mirror_to_cache).
        try:
            self._mirror_to_cache(vault, config.get("jobs", []))
        except Exception as error:
            logger.warning("No se pudo actualizar caché de programación: %s", error)

    def _ensure_backup_vaults_mounted(self) -> None:
        """Monta por demanda las particiones de finalidad backup registradas.

        La programación real de un respaldo vive DENTRO de la partición
        "backup" (montaje por demanda). Si la partición está desmontada (lo
        normal entre corridas), el config real no es legible y el scheduler
        solo ve los residuos del root (placeholders con origen vacío) →
        se pierde la programación y no corre el respaldo. Aquí se montan
        antes de listar/ejecutar jobs para que `_vaults()`/`_load_config`
        lean el config real de la partición.
        """
        try:
            from backend.shares.models.network_share_volume import NetworkShareVolume
            session = SessionLocal()
            try:
                volumes = session.query(NetworkShareVolume).all()
            finally:
                session.close()
        except Exception as error:
            logger.warning("_ensure_backup_vaults_mounted: %s", error)
            return
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )
        provider = ShareDiskMountProvider()
        warned = getattr(self, "_mount_warned", None)
        if warned is None:
            warned = set()
            self._mount_warned = warned
        for volume in volumes:
            purpose = getattr(volume, "purpose", "shared") or "shared"
            if purpose != "backup":
                continue
            mp = str(getattr(volume, "mountpoint", "") or "").rstrip("/")
            uuid = getattr(volume, "device_uuid", "") or ""
            if not mp or not uuid:
                continue
            mount_key = (
                getattr(volume, "id", None)
                or getattr(volume, "name", "")
                or uuid
            )
            try:
                if provider.is_mounted_at(mp):
                    continue
            except Exception as error:
                logger.debug("share_backup_service._ensure_backup_vaults_mounted: %s", error)
                continue
            try:
                result = provider.mount_now(uuid=uuid, mountpoint=mp)
                if not result.get("success"):
                    message = result.get("message")
                    if mount_key not in warned:
                        warned.add(mount_key)
                        logger.warning(
                            "No se pudo montar (por demanda) la partición backup %s: %s",
                            getattr(volume, "name", ""),
                            message,
                        )
                    else:
                        logger.debug(
                            "Sigue sin montar la partición backup %s: %s",
                            getattr(volume, "name", ""),
                            message,
                        )
                else:
                    warned.discard(mount_key)
                    # Verificar que el mount quedó SETTLED en mountinfo (no
                    # solo findmnt) antes de seguir: si el proceso arrancó
                    # antes de que la partición estuviera lista, un mount que
                    # acaba de completarse puede no ser visible todavía en
                    # /proc/self/mountinfo, y _vaults() (que lo comprueba)
                    # omitiría esta bóveda → se perdería la programación
                    # del respaldo hasta un reinicio. Esperar y reintentar.
                    settled = False
                    for _wait in range(10):
                        try:
                            if is_mountpoint_in_mountinfo(mp):
                                settled = True
                                break
                        except Exception as error:
                            logger.debug("share_backup_service._ensure_backup_vaults_mounted: %s", error)
                        time.sleep(0.5)
                    if not settled:
                        logger.warning(
                            "Partición backup %s montada pero no visible aún "
                            "en mountinfo (%s); se reintentará en el próximo "
                            "ciclo.",
                            getattr(volume, "name", ""),
                            str(mp),
                        )
            except Exception as error:
                logger.warning(
                    "mount_now backup %s falló: %s",
                    getattr(volume, "name", ""),
                    error,
                )

    def _all_jobs(self) -> list[Job]:
        self._ensure_backup_vaults_mounted()
        jobs: list[Job] = []
        vaults = self._vaults()
        # RAÍZ: incluir SIEMPRE la bóveda de cada partición de respaldo
        # REGISTRADA, aunque esté desmontada en este momento (montaje por
        # demanda: entre corridas la partición se desmonta). Su config se
        # lee del disco o cae a la caché multi-bóveda; así la programación
        # nunca desaparece de la UI ni del scheduler tras una corrida.
        try:
            session = SessionLocal()
            try:
                known = {str(v).rstrip("/") for v in vaults}
                for row in session.query(NetworkShareVolume).all():
                    mp = str(getattr(row, "mountpoint", "") or "").rstrip("/")
                    if not mp or "/mnt/stepad-network/" in mp:
                        continue
                    candidate = Path(mp) / VOLUME_RESERVED_NAME
                    if str(candidate).rstrip("/") not in known:
                        vaults.append(candidate)
                        known.add(str(candidate).rstrip("/"))
            finally:
                session.close()
        except Exception as error:
            logger.warning("_all_jobs: no pude completar bóvedas registradas: %s", error)
        for vault in vaults:
            config = self._load_config(vault)
            for record in config.get("jobs", []):
                # Incluye también los jobs placeholder (creados junto a la
                # partición, sin origen asignado aún): representan la
                # programación ligada a esa partición de respaldo. El
                # usuario la ve y le asigna origen al guardar (se convierte
                # en el respaldo real); hasta entonces el origen aparece
                # vacío (placeholder).
                record = dict(_default_job(), **{k: v for k, v in record.items() if k in _default_job()})
                record["id"] = int(record.get("id") or 0)
                jobs.append(Job(record, vault=vault))
        jobs.sort(key=lambda j: j["id"])
        return jobs

    def _find_job(self, job_id: int, *, vault: "Path | None" = None) -> Job | None:
        """Resuelve un job por id. Con `vault`, restringe la búsqueda a esa
        bóveda (los ids son únicos globalmente tras la migración, pero la
        restricción protege bóvedas que aún no se hayan podido renumerar,
        p. ej. por estar desmontadas)."""
        for job in self._all_jobs():
            if int(job.get("id")) != int(job_id):
                continue
            if vault is not None:
                if getattr(job, "vault", None) is None:
                    continue
                if Path(str(job.vault)).resolve() != Path(str(vault)).resolve():
                    continue
            return job
        return None

    def _global_max_job_id(self) -> int:
        """Mayor id de job existente en CUALQUIER bóveda (y en la tabla DB
        heredada si aún tiene filas). Base para los ids únicos globales."""
        max_id = 0
        try:
            from backend.shares.models.network_share_backup_job import NetworkShareBackupJob
            from sqlalchemy import func as _func
            sess = SessionLocal()
            try:
                _m = sess.query(_func.max(NetworkShareBackupJob.id)).scalar()
                if _m:
                    max_id = max(max_id, int(_m))
            finally:
                sess.close()
        except Exception as error:
            logger.debug("share_backup_service._global_max_job_id: %s", error)
        for vault in self._vaults():
            try:
                config = self._load_config(vault)
            except Exception as error:
                logger.debug("share_backup_service._global_max_job_id: %s", error)
                continue
            for record in config.get("jobs", []):
                try:
                    max_id = max(max_id, int(record.get("id") or 0))
                except (TypeError, ValueError):
                    pass
        return max_id

    def _next_global_job_id(self) -> int:
        """Próximo id de job ÚNICO a nivel global (todas las bóvedas)."""
        with self._lock:
            return self._global_max_job_id() + 1

    def _ensure_unique_job_ids(self) -> None:
        """Migración one-shot: renumerar jobs con id duplicado entre bóvedas.

        Antes los ids eran por-bóveda (next_job_id local), así dos particiones
        backup podían crear el mismo id=1; _find_job() devolvía el primero y
        el scheduler ejecutaba un respaldo equivocado en loop. Aquí se
        renumera la segunda aparición y se renombra su repo
        .backups/job-<viejo> -> .backups/job-<nuevo> (mismo filesystem, no
        copia datos). Solo se tocan bóvedas LOCALES montadas; las desmontadas
        se renumeran en un arranque posterior. Nunca debe propagar errores
        (se invoca al arrancar el scheduler y solo hace falta una vez)."""
        try:
            if getattr(self, "_ids_renumbered", False):
                return
            self._ids_renumbered = True
        except Exception as error:
            logger.warning("_ensure_unique_job_ids: %s", error)
            return
        try:
            seen: dict[int, str] = {}
            max_id = self._global_max_job_id()
            for vault in self._vaults():
                if "/mnt/stepad-network/" in str(vault):
                    continue
                if not self._dir_live(vault):
                    continue
                config = self._load_config(vault)
                changed = False
                for record in config.get("jobs", []):
                    jid = int(record.get("id") or 0)
                    if not jid:
                        continue
                    if jid in seen:
                        old_repo = vault / BACKUP_SUBDIR / f"job-{jid}"
                        max_id += 1
                        new_id = max_id
                        new_repo = vault / BACKUP_SUBDIR / f"job-{new_id}"
                        try:
                            if old_repo.exists() and not new_repo.exists():
                                os.rename(str(old_repo), str(new_repo))
                            record["id"] = new_id
                            changed = True
                            logger.info(
                                "Job duplicado %s en %s -> renumerado a %s "
                                "(id global único); repo renombrado.",
                                jid, vault, new_id,
                            )
                        except OSError as error:
                            logger.warning(
                                "No se pudo renumerar job %s de %s (duplicado): %s",
                                jid, vault, error,
                            )
                    else:
                        seen[jid] = str(vault)
                if changed:
                    config["next_job_id"] = max(
                        int(config.get("next_job_id") or 1),
                        max((int(r.get("id") or 0) for r in config.get("jobs", [])), default=0) + 1,
                    )
                    self._save_config(vault, config)
        except Exception as error:
            logger.warning("_ensure_unique_job_ids: %s", error)

    def _save_job(self, job: Job) -> None:
        with self._lock:
            self._save_job_locked(job)

    def _save_job_locked(self, job: Job) -> None:
        config = self._load_config(job.vault)
        for index, record in enumerate(config.get("jobs", [])):
            if int(record.get("id") or 0) == int(job.get("id")):
                config["jobs"][index] = dict(job)
                break
        self._save_config(job.vault, config)

    def _repo_path(self, job: Job) -> Path:
        return job.vault / BACKUP_SUBDIR / f"job-{job.get('id')}"

    # ------------------------------------------------------------------
    # network share mounting
    # ------------------------------------------------------------------

    def _is_network_source(self, source: str) -> bool:
        """Detecta si la fuente es un share SMB de red o unidad de red montada."""
        return source.startswith("//") or source.startswith("\\\\") or "/stepad-network/" in source

    def _network_source_ip(self, job: "Job") -> str | None:
        """IP del servidor del origen de red del job (para limitar su tráfico).

        Se obtiene del mount SMB actual (`addr=` en /proc/mounts); si no,
        por hostname de la unidad de red. Devuelve None si no se puede
        resolver (entonces el respaldo corre sin límite, nunca se rompe)."""
        src = str(job.get("source_path") or "")
        if not src:
            return None
        try:
            ip = net_rate_shaper.source_ip_for_mount(src.rstrip("/"))
            if ip:
                return ip
            letter = (src.split("/stepad-network/")[-1] or "").strip("/").upper()
            try:
                from backend.shares.services.network_unit_service import NetworkUnitService
                units = NetworkUnitService()._load().get("units") or []
                for unit in units:
                    if str(unit.get("letter") or "").upper() == letter:
                        return net_rate_shaper.source_ip_for_host(str(unit.get("host") or ""))
            except Exception as error:
                logger.debug("share_backup_service._network_source_ip: %s", error)
        except Exception as error:
            logger.debug("share_backup_service._network_source_ip: %s", error)
        return None

    def _parse_network_source(self, source: str) -> dict | None:
        """Parsea un path SMB: //host/share/subfolder → {host, share, subfolder}."""
        clean = source.replace("\\", "/")
        if not clean.startswith("//"):
            return None
        parts = clean[2:].split("/")
        if len(parts) < 2:
            return None
        return {
            "host": parts[0],
            "share": parts[1],
            "subfolder": "/".join(parts[2:]) if len(parts) > 2 else "",
        }

    def _mount_point(self, job_id: int) -> Path:
        return Path(f"/mnt/stepad-backup-{job_id}")

    def _mount_share(self, job: Job, source: str) -> str | None:
        """Monta un share SMB como carpeta local. Retorna el punto de montaje o None si falla."""
        parsed = self._parse_network_source(source)
        if not parsed:
            return None
        mount_point = self._mount_point(job.get("id"))
        mount_point.mkdir(parents=True, exist_ok=True)
        user = job.get("smb_user", "")
        password = job.get("smb_password", "")
        # Auto-fetch credentials from network unit if empty
        if not user and "/stepad-network/" in source:
            try:
                from backend.shares.services.network_unit_service import NetworkUnitService
                nu_svc = NetworkUnitService()
                letter = source.split("/stepad-network/")[-1].strip("/").split("/")[0]
                for u in nu_svc._load().get("units", []):
                    if u.get("letter") == letter:
                        user = u.get("user", "")
                        password = secret_box.decrypt(u.get("password", ""))
                        break
            except Exception as error:
                logger.debug("share_backup_service._mount_share: %s", error)
        opts = f"uid=0,gid=0,iocharset=utf8,vers=3.0,nobrl,soft,rw,timeo=50,retrans=1,echo_interval=5,actimeo=20,cache=strict"
        if user:
            opts = f"username={user},password={password},{opts}"
        else:
            opts = f"guest,{opts}"
        # Resolver por NOMBRE a la IP ACTUAL del servidor (registro DHCP de la
        # NSP). Así el respaldo por horario no depende de /etc/hosts viejo y
        # sigue reconociendo la unidad aunque el servidor cambie de IP.
        target_host = parsed["host"]
        try:
            from backend.shares.services.network_unit_service import NetworkUnitService
            resolved = NetworkUnitService()._resolve_host_ip(parsed["host"])
            if resolved:
                target_host = resolved
        except Exception as error:
            logger.debug("share_backup_service._mount_share: %s", error)
        cmd = ["mount", "-t", "cifs", f"//{target_host}/{parsed['share']}", str(mount_point), "-o", opts]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            if parsed["subfolder"]:
                return str(mount_point / parsed["subfolder"])
            return str(mount_point)
        else:
            logger.error("Failed to mount //%s/%s: %s", parsed["host"], parsed["share"], result.stderr)
            return None

    def _unmount_share(self, job: Job) -> None:
        """Desmonta un share SMB."""
        mount_point = self._mount_point(job.get("id"))
        if mount_point.exists():
            subprocess.run(["umount", str(mount_point)], capture_output=True, timeout=10)
            try:
                mount_point.rmdir()
            except Exception as error:
                logger.debug("share_backup_service._unmount_share: %s", error)
    def _ensure_network_unit_mounted(self, source: str) -> bool:
        """Monta la unidad de red registrada que da origen a `source`.

        Acepta rutas como ``/mnt/stepad-network/M/subcarpeta`` y usa la
        configuración de ``network_units.json`` (credenciales incluidas).
        evitar ``NetworkUnitService.list_units()``: ahí se marca
        "montada" con ``is_mount()``, una syscall que cuelga en D-state si el
        share está caído. Devuelve True si el origen quedó montado y legible.
        """
        base = "/mnt/stepad-network/"
        if "/stepad-network/" not in source:
            return False
        try:
            raw = source.split("/stepad-network/", 1)[1]
            letter = raw.split("/", 1)[0].strip().upper()
        except Exception as error:
            logger.debug("share_backup_service._ensure_network_unit_mounted: %s", error)
            return False
        if not letter:
            return False
        try:
            config = json.loads(
                Path("/etc/stepad/network_units.json").read_text(encoding="utf-8")
            )
        except Exception as error:
            logger.debug("share_backup_service._ensure_network_unit_mounted: %s", error)
            return False
        unit = None
        for candidate in config.get("units", []):
            if (candidate.get("letter") or "").upper() == letter:
                unit = candidate
                break
        if not unit:
            return False
        mount_point = Path(base + letter)
        mount_point.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(mount_point, 0o755)
        except Exception as error:
            logger.debug("share_backup_service._ensure_network_unit_mounted: %s", error)
        user = unit.get("user", "")
        password = secret_box.decrypt(unit.get("password", ""))
        opts = f"uid=0,gid=0,iocharset=utf8,vers=3.0,nobrl,soft,rw,timeo=50,retrans=1,echo_interval=5,actimeo=20,cache=strict"
        if user:
            opts = f"username={user},password={password},{opts}"
        else:
            opts = f"guest,{opts}"
        try:
            host = unit.get("host", "")
            share = unit.get("share", "")
            cmd = ["mount", "-t", "cifs", f"//{host}/{share}", str(mount_point), "-o", opts]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
            ok = result.returncode == 0
        except (subprocess.TimeoutExpired, OSError):
            ok = False
        return ok and self._dir_live(Path(base + letter))

    def _repositories(self) -> list[Path]:
        """Todos los repositorios reales en las bóvedas privadas LOCALES.

        Solo bóvedas locales del propio NSP: las bóvedas de red
        (/mnt/stepad-network/*) que existan son residuos legacy de otro
        sistema o del origen, y borrarlas produce fallos de permiso en el
        share CIFS y avisos falsos. La limpieza de basura debe ser local y
        fiable."""
        repos: list[Path] = []
        for vault in self._vaults():
            if "/stepad-network/" in str(vault):
                continue
            store = vault / BACKUP_SUBDIR
            if not store.is_dir():
                continue
            # No tocar bóvedas que viven sobre un sistema de archivos no
            # montado (unidades de red desconectadas): recorrerlas o borrar
            # nada ahí solo produce errores de I/O y avisos falsos.
            if not self._dir_live(store):
                continue
            for child in store.iterdir():
                if child.is_dir() and child.name.startswith("job-"):
                    repos.append(child)
        return repos

    def _dir_live(self, path: Path) -> bool:
        """True si el directorio es legible (evita cifs desconectados que
        cuelgan en D-state al hacer stat/readdir).

        Hacer ``os.stat``/``os.path.ismount``/``iterdir`` sobre un share CIFS
        cuyo servidor se cayó puede bloquear el hilo en kernel (D-state) sin
        que ningún timeout de Python ayude. La prueba corre en un thread
        aparte y se abandona a los 2s: si cuelga, el resto del servicio
        sigue operando (solo ese thread queda varado hasta que el kernel
        aborte por timeo)."""
        path = Path(path)

        # Confirmar que el directorio (o un ancestro) figura como mount real:
        # leer /proc/mounts es instantáneo y NUNCA se cuelga, a diferencia de
        # os.path.ismount() que hace una syscall al filesystem sujeto a fallo.
        if "/stepad-network/" in str(path):
            probe_path = path
            while True:
                if mount_point_name(probe_path):
                    break
                parent = probe_path.parent
                if parent == probe_path:
                    return False
                probe_path = parent

        outcome: list[bool] = []

        def _probe():
            try:
                for _ in Path(path).iterdir():
                    break
                outcome.append(True)
            except OSError:
                outcome.append(False)

        probe_thread = threading.Thread(target=_probe, daemon=True)
        probe_thread.start()
        probe_thread.join(timeout=2.0)
        if probe_thread.is_alive():
            # Cifs sin respuesta: considerar no disponible y seguir.
            return False
        return bool(outcome and outcome[0])

    def _used_bytes(self) -> int:
        total = 0
        for repo in self._repositories():
            if self._is_network_source(str(repo)):
                continue
            try:
                result = subprocess.run(
                    ["du", "-sb", str(repo)],
                    capture_output=True, text=True, timeout=5,
                )
                if result.returncode == 0:
                    total += int(result.stdout.split()[0])
            except Exception as error:
                logger.debug("share_backup_service._used_bytes: %s", error)
        return total

    def _vault_disk(self, vault: Path) -> dict | None:
        try:
            disk = self._disk_usage_with_timeout(vault, timeout=5)
            return {
                "path": str(vault),
                "total_bytes": disk.total,
                "used_bytes": disk.used,
                "free_bytes": disk.free,
                "free_pct": round(100 * disk.free / disk.total, 1) if disk.total else 100.0,
                "used_human": _human_bytes(disk.used),
                "total_human": _human_bytes(disk.total),
            }
        except Exception as error:
            logger.debug("share_backup_service._vault_disk: %s", error)
            return None

    def _disk_usage_with_timeout(self, path: Path, timeout: float = 5) -> "os.statvfs_result | None":
        result: list = []

        def _probe():
            try:
                result.append(shutil.disk_usage(path))
            except Exception as error:
                logger.debug("share_backup_service._probe: %s", error)
                result.append(None)

        thread = threading.Thread(target=_probe, daemon=True)
        thread.start()
        thread.join(timeout=timeout)
        if thread.is_alive() or not result:
            return None
        return result[0]

    # ------------------------------------------------------------------
    # restic commands
    # ------------------------------------------------------------------

    def _password(self) -> str:
        # Fuente única y centralizada: si la clave falta en el env, se
        # restaura desde los backups del actualizador; solo se genera
        # nueva si no existe NINGUNA copia, y entonces se persiste en
        # todos los sitios a la vez. Evita que un update o reinicio
        # vuelva a huérfanar los repositorios.
        from backend.core.config.secret_manager import get_restic_password
        return get_restic_password()

    def _env(self) -> dict:
        return restic_runner.env(self._password())

    @staticmethod
    def _restic_cmd(repo: str, args: list[str]) -> list[str]:
        """Comando restic con CPU/E-S en prioridad idle (ver runner)."""
        return restic_runner.command(repo, args)

    def _restic(self, job: Job, args: list[str], *, timeout: int = 3600, track: bool = False, stall_timeout: int = 0) -> subprocess.CompletedProcess:
        command = self._restic_cmd(str(self._repo_path(job)), args)
        job_id = int(job.get("id") or 0)
        proc = subprocess.Popen(
            command,
            env=self._env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        # SOLO el respaldo real se registra en _procs/_progress (para el
        # indicador "en curso", el botón Parar y el progreso). Otras
        # operaciones (snapshots, check, restore, prune…) NO deben pisar ese
        # estado ni aparecer como "respaldando".
        if track:
            self._procs[job_id] = proc
        deadline = time.monotonic() + timeout
        stdout_chunks: list[str] = []

        # Lector de stdout en un hilo aparte: restic escribe progreso JSON
        # continuamente por el pipe. Si se lee de forma lenta (línea a línea
        # con sleeps), el pipe se llena y restic queda BLOQUEADO escribiendo
        # (5% CPU esperando), aunque el disco/red den ~100 MB/s. Drenar en un
        # hilo evita ese ahogo.
        import threading as _th

        activity = [time.monotonic()]

        def _drain():
            try:
                for line in proc.stdout:
                    stdout_chunks.append(line)
                    activity[0] = time.monotonic()
                    if not track:
                        continue
                    try:
                        data = json.loads(line)
                        if not isinstance(data, dict):
                            continue
                        if data.get("message_type") in ("status", "progress", "restore"):
                            self._progress[job_id] = self._rich_progress(data)
                    except (json.JSONDecodeError, KeyError):
                        pass
            except Exception as error:
                logger.debug("share_backup_service._drain: %s", error)
        drain_thread = _th.Thread(target=_drain, daemon=True)
        drain_thread.start()

        try:
            while True:
                code = proc.poll()
                if code is not None:
                    drain_thread.join(timeout=2)
                    remaining = proc.stdout.read() or ""
                    if remaining:
                        stdout_chunks.append(remaining)
                    stdout = "".join(stdout_chunks)
                    stderr = proc.stderr.read() if proc.stderr else ""
                    return subprocess.CompletedProcess(command, code, stdout, stderr)
                if track and job_id in self._cancel_requested:
                    self._terminate_proc(proc)
                    try:
                        stdout, stderr = proc.communicate(timeout=30)
                    except subprocess.TimeoutExpired:
                        stdout, stderr = "", ""
                    return subprocess.CompletedProcess(command, -9, stdout, stderr)
                if track and stall_timeout and (time.monotonic() - activity[0]) > stall_timeout:
                    # Sin salida de restic en mucho tiempo: origen colgado.
                    self._terminate_proc(proc)
                    try:
                        stdout, stderr = proc.communicate(timeout=30)
                    except subprocess.TimeoutExpired:
                        stdout, stderr = "".join(stdout_chunks), ""
                    logger.warning(
                        "Respaldo '%s': sin progreso por %d s; se aborta (origen sin responder).",
                        job.get("name"), stall_timeout,
                    )
                    return subprocess.CompletedProcess(
                        command, -15,
                        stdout or "".join(stdout_chunks),
                        (stderr or "") + "\nInterrumpido: sin progreso del origen (posible caída de red).",
                    )
                if time.monotonic() >= deadline:
                    self._terminate_proc(proc)
                    raise subprocess.TimeoutExpired(command, timeout)
                time.sleep(0.5)
        finally:
            if track:
                self._procs.pop(job_id, None)
                self._progress.pop(job_id, None)

    def _terminate_proc(self, proc: "subprocess.Popen") -> None:
        try:
            proc.terminate()
        except OSError:
            pass
        try:
            proc.kill()
        except OSError:
            pass

    def get_progress(self, job_id: int) -> dict:
        """Devuelve el progreso actual de un respaldo en curso."""
        progress = self._progress.get(job_id, {})
        running = job_id in self._procs
        return {
            "running": running,
            "files_done": progress.get("files_done", 0),
            "files_total": progress.get("files_total", 0),
            "bytes_done": progress.get("bytes_done", 0),
            "bytes_total": progress.get("bytes_total", 0),
            "current_file": progress.get("current_file", ""),
            "percent": progress.get("percent"),
            "elapsed_seconds": progress.get("elapsed_seconds"),
            "eta_seconds": progress.get("eta_seconds"),
        }

    @staticmethod
    def _rich_progress(data: dict) -> dict:
        """Progreso normalizado (0-100 y ETA confiable); ver runner."""
        return restic_runner.rich_progress(data)

    def _ensure_repo(self, job: Job) -> None:
        repo = self._repo_path(job)
        repo.parent.mkdir(parents=True, exist_ok=True)
        if not repo.exists():
            repo.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(repo, 0o700)
            except Exception as error:
                logger.debug("share_backup_service._ensure_repo: %s", error)
        # A fresh restic repo is initialized lazily on first successful run.
        probe = self._restic(job, ["snapshots", "--json"], timeout=60)
        if probe.returncode != 0:
            if "already locked" in (probe.stderr or ""):
                # Lock restante de un proceso anterior (cayó/colgado): se
                # libera para que el respaldo no quede esperando para siempre.
                self._restic(job, ["unlock"], timeout=60)
                probe = self._restic(job, ["snapshots", "--json"], timeout=60)
            if probe.returncode != 0:
                # Solo inicializar si el error es "no es un repositorio":
                # si y solo si restic no encuentra config. Si el repo ya
                # existe inicializado (aunque el probe falle por otra
                # razón: password distinta, daño, lock), NO se re-inicializa
                # — `restic init` en un repo existente falla con "config
                # file already exists" y rompe el respaldo innecesariamente.
                stderr = (probe.stderr or "").lower()
                looks_empty = (
                    "is there a repository" in stderr
                    or "does not look like a repository" in stderr
                    or (
                        "no repository" in stderr
                        and "password" not in stderr
                    )
                )
                if looks_empty:
                    init = self._restic(job, ["init"], timeout=120)
                    if init.returncode != 0:
                        init_err = (init.stderr or "").lower()
                        if "config file already exists" in init_err:
                            # Raza: otra corrida acabó de inicializar.
                            return
                        raise HTTPException(
                            status_code=500,
                            detail=f"No se pudo inicializar el repositorio restic: {init.stderr.strip()[:300]}",
                        )
                elif "wrong password" in stderr or "no key found" in stderr:
                    # La password guardada no abre este repo (rotó o se
                    # regeneró en algún reinicio). El respaldo no puede
                    # avanzar con un repo inaccesible: se descarta el
                    # repo huérfano (conservando los datos como
                    # .discarded-*) y se inicializa uno nuevo con la
                    # password actual, de modo que "Ejecutar ahora"
                    # siempre funcione.
                    try:
                        discard = repo.with_name(repo.name + ".discarded")
                        discard.parent.mkdir(parents=True, exist_ok=True)
                        if discard.exists():
                            import shutil
                            shutil.rmtree(discard)
                        os.replace(repo, discard)
                        logger.warning(
                            f"Repo inaccesible (password no coincide); "
                            f"movido a {discard} y se re-inicializa."
                        )
                    except Exception as error:
                        raise HTTPException(
                            status_code=500,
                            detail=(
                                "No se pudo re-crear el repositorio restic "
                                f"(password desincronizada): {error}"
                            ),
                        )
                    repo.mkdir(parents=True, exist_ok=True)
                    try:
                        os.chmod(repo, 0o700)
                    except Exception as error:
                        logger.debug("share_backup_service._ensure_repo: %s", error)
                    init = self._restic(job, ["init"], timeout=120)
                    if init.returncode != 0:
                        raise HTTPException(
                            status_code=500,
                            detail=f"No se pudo inicializar el repositorio restic: {init.stderr.strip()[:300]}",
                        )

    def installed(self) -> bool:
        return bool(shutil.which("restic"))

    # ------------------------------------------------------------------
    # job CRUD + status
    # ------------------------------------------------------------------

    def list_jobs(self, db: Session = None) -> dict:
        jobs = self._all_jobs()

        vaults = self._vaults(db)
        repo_bytes = self._used_bytes()

        vaults_info = []
        total_free = 0
        total_size = 0
        for vault in vaults:
            info = self._vault_disk(vault)
            if info:
                vaults_info.append(info)
                total_free += info["free_bytes"]
                total_size += info["total_bytes"]

        free_pct = round(100 * total_free / total_size, 1) if total_size else 100.0

        return {
            "installed": self.installed(),
            "store_root": "Carpeta privada «Respaldo» de cada unidad",
            "store_used_bytes": repo_bytes,
            "store_used_human": _human_bytes(repo_bytes),
            "store_free_bytes": total_free,
            "store_free_pct": free_pct,
            "vaults": vaults_info,
            "jobs": [self._serialize(job) for job in jobs],
        }

    def _network_source_ok(self, source: str) -> bool:
        """Disponibilidad EN VIVO de una unidad de red: si está montada y
        legible True; si no, que su host actual (IP del registro DHCP)
        responda. Con caché corto (~15 s) para no pinguear en cada poll."""
        try:
            if self._dir_live(Path(source)):
                return True
        except Exception as error:
            logger.debug("share_backup_service._network_source_ok: %s", error)
        import time as _time
        now = _time.monotonic()
        letter = source.split("/stepad-network/")[-1].split("/")[0]
        cached = self._net_reach_cache.get(letter)
        if cached and now - cached[0] < 15:
            return cached[1]
        ok = False
        try:
            from backend.shares.services.network_unit_service import NetworkUnitService
            nu = NetworkUnitService()
            host = None
            for u in nu._load().get("units", []):
                if u.get("letter") == letter:
                    host = u.get("host") or ""
                    break
            if host:
                ip = nu._resolve_host_ip(host)
                ok = bool(ip) and nu._ip_alive(ip)
        except Exception as error:
            logger.debug("share_backup_service._network_source_ok: %s", error)
            ok = False
        self._net_reach_cache[letter] = (now, ok)
        return ok

    def _serialize(self, job: Job) -> dict:
        # Un origen de RED (//host/share o /mnt/stepad-network/X) se monta por
        # demanda al ejecutar el respaldo; si hoy no está montado NO es un
        # "origen no disponible": solo falta la conexión al momento de correr,
        # y ese fallo se registra en el log/resultado de la corrida (ver
        # _mount_share / _ensure_network_unit_mounted). Para no confundir con
        # un ⚠️ falso en la lista, los orígenes de red se consideran
        # "disponibles" siempre (se intentará montar al respaldar); solo los
        # orígenes LOCALES dependen del montaje físico actual.
        source = (job.get("source_path") or "").strip()
        network_source = self._is_network_source(source)
        source_exists = bool(source)
        source_ok = source_exists
        if source_exists and not network_source:
            source_exists = self._dir_live(Path(source))
            source_ok = source_exists
        elif source_exists and network_source:
            # Estado EN VIVO de la unidad de red: montada legible, o su host
            # actual responde (IP del registro DHCP). Evita que un error
            # viejo de la corrida ("Host is down") se muestre como caída.
            source_ok = self._network_source_ok(source)
            source_exists = source_ok
        return {
            "id": job.get("id"),
            "name": job.get("name"),
            "source_exists": source_exists,
            "source_ok": source_ok,
            "destination_exists": bool(
                Path(str(job.vault or self._dest_folder(job.get("source_path") or ""))).parent.exists()
            ),
            "source_path": job.get("source_path"),
            "destination_path": str(job.vault or self._dest_folder(job.get("source_path") or "")),
            "repository_path": str(self._repo_path(job)),
            "enabled": bool(job.get("enabled")),
            "schedule_mode": job.get("schedule_mode"),
            "folder_id": job.get("folder_id"),
            "schedule_hour": job.get("schedule_hour"),
            "schedule_minute": job.get("schedule_minute"),
            "schedule_times": self._times_list(job),
            "interval_minutes": job.get("interval_minutes"),
            "retention_count": job.get("retention_count"),
            "prune_free_pct": job.get("prune_free_pct"),
            "rate_limit_mbps": job.get("rate_limit_mbps"),
            "check_enabled": bool(job.get("check_enabled", True)),
            "check_interval_days": int(job.get("check_interval_days") or 7),
            "last_check_at": job.get("last_check_at"),
            "last_check_result": job.get("last_check_result"),
            "test_restore_enabled": bool(job.get("test_restore_enabled", False)),
            "test_restore_interval_days": int(job.get("test_restore_interval_days") or 30),
            "test_restore_scratch": job.get("test_restore_scratch"),
            "last_test_restore_at": job.get("last_test_restore_at"),
            "last_test_restore_result": job.get("last_test_restore_result"),
            "last_backup_at": job.get("last_backup_at"),
            "running": job.get("id") in self._running_jobs,
            "running_since": self._running_since.get(job.get("id")),
            "last_result": job.get("last_result"),
            "skip_until": job.get("skip_until"),
            "last_snapshot_id": job.get("last_snapshot_id"),
            "last_bytes": job.get("last_bytes"),
            "consecutive_failures": int(job.get("consecutive_failures") or 0),
            "failing": bool(job.get("failure_alert_active")),
            "next_run": self._next_run(job),
        }

    def _next_run(self, job: Job) -> str | None:
        if not job.get("enabled"):
            return None
        if job.get("schedule_mode") == "interval":
            minutes = max(1, int(job.get("interval_minutes") or 60))
            return f"cada {minutes} min"
        if job.get("schedule_mode") == "on_change":
            return "al modificar archivos"
        times = self._times_list(job)
        if times:
            return ", ".join(times)
        return f"{int(job.get('schedule_hour') or 0):02d}:{int(job.get('schedule_minute') or 0):02d}"

    def _folder_size(self, path_str: str) -> int | None:
        """Tamaño aparente (bytes) de la carpeta origen, con timeout y caché
        corta. Devuelve None si no se pudo medir (red lenta, permisos)."""
        path = str(path_str)
        cache_key = "size:" + path
        cached = self._size_cache.get(cache_key)
        if cached and time.monotonic() - cached[0] < 300:
            return cached[1]

        is_network = "/stepad-network/" in path

        # Una unidad de red registrada pero desconectada aparece como carpeta
        # vacía: du la mediría como 0 bytes (engañoso) o fallaría. Mejor
        # reportar "no se pudo medir" y dejar claro que falta el mount.
        if not self._dir_live(Path(path)):
            self._last_size_error = (
                "unidad de red no montada"
                if is_network
                else "directorio no disponible"
            )
            self._size_cache[cache_key] = (time.monotonic(), None)
            return None

        result_box: list[int] = []

        def _run_du():
            try:
                r = subprocess.run(
                    ["du", "-sb", "--apparent-size", path],
                    capture_output=True,
                    text=True,
                    timeout=25,
                )
                if r.returncode == 0 and r.stdout:
                    first = r.stdout.splitlines()[0]
                    result_box.append(int(first.split()[0]))
            except (subprocess.TimeoutExpired, OSError, ValueError, IndexError):
                pass

        # En red el `du` puede quedarse en stat (cifs colgado); se ejecuta en
        # un hilo y se abandona si no respondió en unos segundos, para que el
        # guardado del respaldo nunca se congele por medir el origen.
        probe = threading.Thread(target=_run_du, daemon=True)
        probe.start()
        probe.join(timeout=(4.0 if is_network else 40.0))
        if probe.is_alive() or not result_box:
            self._last_size_error = (
                "unidad de red lenta o sin permisos"
                if is_network
                else "sin permisos"
            )
            self._size_cache[cache_key] = (time.monotonic(), None)
            return None

        size = result_box[0]
        self._size_cache[cache_key] = (time.monotonic(), size)
        return size

    def _vault_free_bytes(self, vault: Path) -> int | None:
        try:
            disk = self._disk_usage_with_timeout(vault, timeout=5)
            return disk.free if disk is not None else None
        except Exception as error:
            logger.debug("share_backup_service._vault_free_bytes: %s", error)
            return None

    def space_check(self, source: str = "", destination: str = "") -> dict:
        """Compara el tamaño del origen con el espacio libre del destino."""
        src = (source or "").strip()
        dst = (destination or "").strip()
        free_bytes = None
        free_human = ""
        if dst:
            free_bytes = self._vault_free_bytes(Path(dst))
            if free_bytes is not None:
                free_human = _human_bytes(free_bytes)
        if not src or not self._dir_live(Path(src)):
            if src and "/stepad-network/" in src:
                # ANTES de declararlo no disponible, intentar montar la
                # unidad de red por demanda (igual que al ejecutar el
                # respaldo): evita el falso "origen no disponible" al
                # GUARDAR un respaldo a una unidad que solo está registrada
                # y desmontada por diseño (montaje por demanda).
                try:
                    mounted_ok = self._ensure_network_unit_mounted(src)
                    if mounted_ok and self._dir_live(Path(src)):
                        # Montó: re-medir normal (fluye al tamaño abajo).
                        src_mounted = True
                    else:
                        src_mounted = False
                except Exception as error:
                    logger.debug("share_backup_service.space_check: %s", error)
                    src_mounted = False
                if not src_mounted:
                    note = (
                        "El origen es una unidad de red que no está "
                        "disponible (no montada o sin respuesta). Conecta "
                        "la unidad (o verifica que el equipo origen esté "
                        "encendido) antes de guardar el respaldo."
                    )
                    return {
                        "source_size": None,
                        "source_size_human": "",
                        "free_bytes": free_bytes,
                        "free_human": free_human,
                        "sufficient": None,
                        "missing_bytes": 0,
                        "missing_pct": None,
                        "note": note,
                    }
                # si montó, continuar a medir tamaño abajo
                pass
            else:
                note = "No se pudo medir el origen (red lenta o sin permisos)."
                return {
                    "source_size": None,
                    "source_size_human": "",
                    "free_bytes": free_bytes,
                    "free_human": free_human,
                    "sufficient": None,
                    "missing_bytes": 0,
                    "missing_pct": None,
                    "note": note,
                }
        size = self._folder_size(src)
        if size is None:
            reason = getattr(self, "_last_size_error", None)
            if reason == "unidad de red no montada":
                note = (
                    "El origen es una unidad de red que no está montada. "
                    "Conecta la unidad (o verifica que el equipo origen esté "
                    "encendido) antes de guardar el respaldo."
                )
            elif reason == "unidad de red lenta o sin permisos":
                note = (
                    "El origen es una unidad de red y no se pudo medir su "
                    "contenido (lenta o sin permisos). Podés guardar igual: "
                    "el respaldo se validará al ejecutarse."
                )
            else:
                note = "No se pudo medir el origen (red lenta o sin permisos)."
            return {
                "source_size": None,
                "source_size_human": "",
                "free_bytes": free_bytes,
                "free_human": free_human,
                "sufficient": None,
                "missing_bytes": 0,
                "missing_pct": None,
                "note": note,
            }
        missing = max(0, size - (free_bytes or 0)) if free_bytes is not None else 0
        pct = round(100 * missing / size) if size else 0
        sufficient = (free_bytes is not None) and (free_bytes >= size)
        return {
            "source_size": size,
            "source_size_human": _human_bytes(size),
            "free_bytes": free_bytes,
            "free_human": free_human,
            "sufficient": sufficient,
            "missing_bytes": missing if not sufficient else 0,
            "missing_pct": pct if not sufficient else 0,
        }

    def _validate_create_space(self, source: str, vault: Path) -> None:
        """Bloquea crear el respaldo si el primer respaldo completo no entra."""
        size = self._folder_size(source)
        if size is None:
            return
        free = self._vault_free_bytes(vault)
        if free is None or free >= size:
            return
        missing = size - free
        pct = round(100 * missing / size) if size else 0
        raise HTTPException(
            status_code=400,
            detail=(
                "Falta espacio en el destino: el respaldo completo del origen "
                f"necesita {_human_bytes(size)} y solo hay {_human_bytes(free)} "
                f"libres (falta {_human_bytes(missing)}, ~{pct}%). "
                "Libera espacio o elige otro destino."
            ),
        )

    def _next_slot_at(self, job: Job, now: datetime) -> datetime:
        if job.get("schedule_mode") == "interval":
            minutes = max(1, int(job.get("interval_minutes") or 60))
            return now + timedelta(minutes=minutes)
        if job.get("schedule_mode") == "on_change":
            return now + timedelta(minutes=60)
        times = self._times_list(job)
        slots = []
        for raw in times:
            try:
                hh, mm = (int(x) for x in raw.split(":"))
            except Exception as error:
                logger.debug("share_backup_service._next_slot_at: %s", error)
                continue
            slots.append(hh * 60 + mm)
        if not slots:
            slots = [
                int(job.get("schedule_hour") or 0) * 60
                + int(job.get("schedule_minute") or 0),
            ]
        minute_of_day = now.hour * 60 + now.minute
        future = [t for t in slots if t > minute_of_day]
        if future:
            t = min(future)
            return now.replace(hour=t // 60, minute=t % 60, second=0, microsecond=0)
        t = min(slots)
        day = now.date() + timedelta(days=1)
        return datetime(day.year, day.month, day.day, t // 60, t % 60)

    def _cancel_running_backup(self, job_id: int) -> bool:
        """Cancela un respaldo en curso de `job_id` (no pierde lo ya
        respaldado: restic retoma sin resubir). True si había uno corrido."""
        job_id = int(job_id or 0)
        if job_id not in self._running_jobs:
            return False
        self._cancel_requested.add(job_id)
        proc = self._procs.get(job_id)
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass
        return True

    def skip_to_next_slot(self, job_id: int) -> dict:
        """Pausa el job: cancela un respaldo en curso (si lo hay) y no
        vuelve a correr hasta la próxima hora programada.

        Es la acción «parar y retomar en el siguiente horario»: útil cuando
        se necesita detener el respaldo (ej. porque la gente vuelve a
        trabajar) sin perder lo ya respaldado — restic retoma luego sin
        resubir lo subido."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")

        cancelled = self._cancel_running_backup(job.get("id"))

        nxt = self._next_slot_at(job, now_ecuador())
        job["skip_until"] = nxt.isoformat()
        self._save_job(job)
        return {
            "cancelled": cancelled,
            "next_at": nxt.isoformat(),
            "next_label": nxt.strftime("%d/%m %H:%M"),
        }

    def stop_backup(self, job_id: int) -> dict:
        """Cancela el respaldo en curso: no avanza last_backup_at y el
        próximo corre en el siguiente horario programado."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        job_id = int(job.get("id") or 0)
        if job_id not in self._running_jobs:
            return {"running": False, "message": "No hay ningún respaldo en ejecución."}
        self._cancel_requested.add(job_id)
        proc = self._procs.get(job_id)
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass
        return {
            "running": True,
            "message": "Respaldo cancelado. El próximo correrá en su horario.",
        }

    def _find_conflict(self, config: dict, source: str, exclude_id: int | None = None) -> tuple[dict | None, str]:
        """Busca un job cuya ruta se superponga con la fuente dada:
        coincidencia exacta → ('exact', record), subcarpeta/padre → ('parent_child', record),
        nada → (None, '')."""
        source_inode = self._inode(source)
        source_path = Path(source)
        for record in config.get("jobs", []):
            if exclude_id is not None and int(record.get("id") or 0) == int(exclude_id):
                continue
            existing = record.get("source_path") or ""
            if not existing:
                continue
            existing_inode = self._inode(existing)
            # Same inode → exact match (hardlink / same dir)
            if source_inode and existing_inode and source_inode == existing_inode:
                return record, "exact"
            existing_path = Path(existing)
            # Exact string match
            if source_path == existing_path:
                return record, "exact"
            # One is a parent of the other → conflict
            try:
                source_path.relative_to(existing_path)
                return record, "parent_child"
            except ValueError:
                pass
            try:
                existing_path.relative_to(source_path)
                return record, "parent_child"
            except ValueError:
                pass
        return None, ""

    def create_job(self, data, db: Session = None) -> dict:
        source = (getattr(data, "source_path", None) or "").strip()
        logger.info("create_job called: source=%s name=%s times=%s mode=%s",
                     source, getattr(data, "name", None),
                     getattr(data, "schedule_times", None),
                     getattr(data, "schedule_mode", None))

        # Validar fuente (local o red)
        is_network = self._is_network_source(source)
        # Auto-fill SMB credentials from network unit if not provided
        if is_network and "/stepad-network/" in source:
            try:
                from backend.shares.services.network_unit_service import NetworkUnitService
                nu_svc = NetworkUnitService()
                letter = source.split("/stepad-network/")[-1].strip("/")
                nu_data = nu_svc._load()
                for u in nu_data.get("units", []):
                    if u.get("letter") == letter:
                        if not getattr(data, "smb_user", None):
                            data.smb_user = u.get("user", "")
                        if not getattr(data, "smb_password", None):
                            data.smb_password = u.get("password", "")
                        break
            except Exception as error:
                logger.debug("share_backup_service.create_job: %s", error)
        # Montar por demanda el origen de red al GUARDAR: la unidad puede
        # estar registrada pero desmontada (montaje por demanda). Sin esto,
        # al crear un 2do respaldo a una unidad de red (p. ej. N) la
        # validación/espacio la reporta "origen no disponible". Solo se
        # monta si no está montada; si la unidad está apagada se deja pasar
        # (el respaldo fallará con aviso al ejecutarse, no al guardar).
        if is_network and "/stepad-network/" in source:
            try:
                if not self._dir_live(Path(source)):
                    self._ensure_network_unit_mounted(source)
            except Exception as error:
                logger.debug("share_backup_service.create_job: %s", error)
        if not is_network and (not source or not Path(source).is_dir()):
            logger.warning("create_job: source invalid: %s", source)
            raise HTTPException(
                status_code=400,
                detail="La ruta de origen no existe o no es un directorio.",
            )

        # Destino explícito elegido por el usuario (carpeta privada
        # «Respaldo» de la unidad destino). Si viene, tiene prioridad sobre
        # el destino automático (la bóveda de la unidad del origen).
        destination = (getattr(data, "destination_path", None) or "").strip()
        if destination:
            # El destino suele vivir en una partición "backup" que está
            # DESMONTADA (montaje por demanda). Se monta primero, no sea
            # que la validación de "existe la carpeta" falle por eso.
            self._mount_destination_if_backup(db, Path(destination))
            dest_path = Path(destination)
            if not dest_path.is_dir():
                logger.warning("create_job: invalid destination: %s", destination)
                raise HTTPException(
                    status_code=400,
                    detail="El destino no existe o no es un directorio.",
                )
            vault = dest_path
        elif is_network:
            local_vaults = [v for v in self._vaults() if "/stepad-network/" not in str(v)]
            vault = local_vaults[0] if local_vaults else (self._vaults()[0] if self._vaults() else None)
            if vault is None:
                raise HTTPException(status_code=400, detail="No hay unidades locales disponibles para respaldos.")
        else:
            vault = self._vault_for_source(source)
            if vault is None or not vault.is_dir():
                vault = self._create_vault_for_source(source)
            if vault is None or not vault.is_dir():
                logger.warning("create_job: no vault for source: %s (vault=%s)", source, vault)
                raise HTTPException(
                    status_code=400,
                    detail="La unidad del origen no tiene carpeta privada «Respaldo».",
                )
        # El destino DEBE estar en una partición de finalidad "backup"
        # (nunca se respalda sobre una compartida/privada).
        self._assert_destination_is_backup(db, vault)
        # Si el destino es una partición "backup" desmontada (montaje por
        # demanda), la monta y asegura la carpeta «Respaldo» antes de
        # validar espacio y guardar.
        if not self._mount_destination_if_backup(db, vault):
            raise HTTPException(
                status_code=400,
                detail=(
                    "No se pudo montar la partición de respaldo del "
                    "destino. Verifica que el disco esté conectado."
                ),
            )
        # Validar espacio: el respaldo inicial completo debe caber en el destino.
        self._validate_create_space(source, vault)

        with self._lock:
            config = self._load_config(vault)

            # Una sola programación por fuente: si la ruta ya tiene un job
            # (o un job padre/hijo) se edita ese en lugar de crear un duplicado.
            conflict, kind = self._find_conflict(config, source)
            # Si el user todavía no configuró ningún origen, la bóveda tiene
            # solo el job placeholder creado junto con la partición (source_path
            # vacío). En ese caso NO se crea un segundo job: se convierte el
            # placeholder en el respaldo real (se le asigna este origen), para
            # que nunca quede un job vacío mostrando "Origen no disponible".
            if conflict is None:
                for placeholder in config.get("jobs", []):
                    if not (placeholder.get("source_path") or "").strip():
                        conflict = placeholder
                        kind = "placeholder"
                        break
            if conflict is not None and kind == "parent_child":
                raise HTTPException(
                    status_code=400,
                    detail="Ya existe un respaldo para la ruta %s (o una carpeta padre/hijo). Solo se permite uno por carpeta." % (conflict.get("source_path") or ""),
                )
            if conflict is not None:
                job = Job(conflict, vault=vault)
                if kind == "placeholder":
                    job["source_path"] = source
            else:
                record = dict(_default_job())
                # ID ÚNICO a nivel global (todas las bóvedas): max id de
                # CUALQUIER bóveda + 1 (incluye configs de otras bóvedas y la
                # tabla DB heredada si aún tiene filas). Un id repetido entre
                # bóvedas hacía que _find_job() resolviera el job equivocado.
                new_id = self._next_global_job_id()
                record.update({
                    "id": new_id,
                    "name": (getattr(data, "name", None) or "").strip() or Path(source).name,
                    "source_path": source,
                    "enabled": True if getattr(data, "enabled", None) is None else bool(data.enabled),
                    "smb_user": getattr(data, "smb_user", None) or "",
                    "smb_password": getattr(data, "smb_password", None) or "",
                })
                record["schedule_mode"] = (
                    data.schedule_mode
                    if getattr(data, "schedule_mode", None) == "interval"
                    else "daily"
                )
                name_exists = any(
                    r.get("name") == record["name"] and r.get("source_path") != source
                    for r in config.get("jobs", [])
                )
                if name_exists:
                    raise HTTPException(status_code=400, detail="Ya existe un respaldo con ese nombre.")
                config["next_job_id"] = new_id + 1
                config.setdefault("jobs", []).append(record)
                job = Job(record, vault=vault)

            self._apply_job_data(job, data)
            config["jobs"] = [
                dict(r) for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id"))
            ]
            config["jobs"].append(dict(job))
            self._save_config(vault, config)

        self._dedupe_by_source(vault, source, job)
        self._sync_folder_policy(db, job)
        return self._serialize(job)

    def _apply_job_data(self, job: Job, data) -> None:
        if getattr(data, "name", None) is not None:
            job["name"] = (data.name or "").strip() or job.get("name") or ""
        if getattr(data, "smb_user", None) is not None:
            job["smb_user"] = (data.smb_user or "").strip()
        if getattr(data, "smb_password", None) is not None:
            job["smb_password"] = data.smb_password or ""
        if getattr(data, "enabled", None) is not None:
            job["enabled"] = bool(data.enabled)
        if getattr(data, "schedule_mode", None) is not None:
            if data.schedule_mode == "on_change":
                # Riesgo de ransomware: respaldar "al cambiar archivos"
                # podría guardar versiones modificadas por el virus. Solo
                # se respalda por horario.
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "El modo «al cambiar archivos» no está disponible: "
                        "por seguridad solo se respalda por horario."
                    ),
                )
            if data.schedule_mode not in ("daily", "interval"):
                raise HTTPException(status_code=400, detail="schedule_mode inválido.")
            job["schedule_mode"] = data.schedule_mode
        if getattr(data, "schedule_hour", None) is not None:
            job["schedule_hour"] = int(data.schedule_hour)
        if getattr(data, "schedule_minute", None) is not None:
            job["schedule_minute"] = int(data.schedule_minute)
        if getattr(data, "schedule_times", None) is not None:
            normalized = self._normalize_times(data.schedule_times)
            if normalized:
                job["schedule_times"] = normalized
                job["schedule_mode"] = "daily"
            elif job.get("schedule_mode") == "daily":
                job["schedule_times"] = None
        if getattr(data, "interval_minutes", None) is not None:
            job["interval_minutes"] = max(15, int(data.interval_minutes))
        if getattr(data, "retention_count", None) is not None:
            job["retention_count"] = max(1, int(data.retention_count))
        if getattr(data, "prune_free_pct", None) is not None:
            job["prune_free_pct"] = max(5, min(80, int(data.prune_free_pct)))
        if getattr(data, "rate_limit_mbps", None) is not None:
            job["rate_limit_mbps"] = max(0, int(data.rate_limit_mbps))
        # --- Mantenimiento (política por job, configurables) ---
        if getattr(data, "check_enabled", None) is not None:
            job["check_enabled"] = bool(data.check_enabled)
        if getattr(data, "check_interval_days", None) is not None:
            job["check_interval_days"] = max(1, int(data.check_interval_days))
        if getattr(data, "test_restore_enabled", None) is not None:
            job["test_restore_enabled"] = bool(data.test_restore_enabled)
        if getattr(data, "test_restore_interval_days", None) is not None:
            job["test_restore_interval_days"] = max(1, int(data.test_restore_interval_days))
        if getattr(data, "test_restore_scratch", None) is not None:
            job["test_restore_scratch"] = (str(data.test_restore_scratch).strip() or None)

    def _dedupe_by_source(self, vault: Path, source: str, keep: Job) -> None:
        """Una sola programación por fuente: elimina duplicados y subcarpetas
        que queden cubiertas por el job mantenido."""
        source_inode = self._inode(source)
        source_path = Path(source)
        with self._lock:
            config = self._load_config(vault)
            kept: list[dict] = []
            for record in config.get("jobs", []):
                if int(record.get("id") or 0) == int(keep.get("id") or 0):
                    kept.append(record)
                    continue
                existing_source = record.get("source_path") or ""
                if not existing_source:
                    kept.append(record)
                    continue
                existing_inode = self._inode(existing_source)
                # Same inode → duplicate (hardlink)
                if source_inode and existing_inode and source_inode == existing_inode:
                    dup = Job(record, vault=vault)
                    self._remove_repo(dup)
                    continue
                existing_path = Path(existing_source)
                # Keep if not related (no parent/child)
                is_related = False
                try:
                    source_path.relative_to(existing_path)
                    is_related = True
                except ValueError:
                    pass
                try:
                    existing_path.relative_to(source_path)
                    is_related = True
                except ValueError:
                    pass
                if is_related:
                    dup = Job(record, vault=vault)
                    self._remove_repo(dup)
                    continue
                kept.append(record)
            config["jobs"] = kept
            self._save_config(vault, config)

    def update_job(self, job_id: int, data, db: Session = None) -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        # Rechazar cambio de destino: el repo de restic ya vive en la
        # carpeta Respaldo del job.
        requested_dest = getattr(data, "destination_path", None)
        if requested_dest:
            dest = (requested_dest or "").strip()
            if dest:
                resolved = self._vault_from_destination_path(dest, db)
                if (
                    resolved is None
                    or Path(str(job.vault)).resolve() != Path(str(resolved)).resolve()
                ):
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            "El destino de un respaldo ya creado no se puede "
                            "cambiar; crea uno nuevo respaldando otra vez."
                        ),
                    )
        new_source = getattr(data, "source_path", None)
        if new_source is not None:
            source = (new_source or "").strip()
            current_source = (job.get("source_path") or "").strip()
            if not source:
                # Origen en blanco: solo se permite conservar el actual.
                # El origen se elige la primera vez; los cambios de horario
                # no deben exigirlo de nuevo.
                if not current_source:
                    raise HTTPException(
                        status_code=400,
                        detail="Elige el origen a respaldar (la primera vez que configurás este respaldo).",
                    )
                source = current_source
            if current_source and source != current_source:
                # El origen se fija la primera vez; una vez que el respaldo
                # ya guardó datos NO se puede re-apuntar a otra carpeta
                # (la bóveda/repo viven ligados a este origen).
                has_run = bool(job.get("last_backup_at"))
                if has_run:
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            "El origen de un respaldo ya configurado no se "
                            "puede cambiar; para respaldar otra carpeta "
                            "elimina esta partición y vuelve a crearla."
                        ),
                    )
            # Origen de red: se monta a demanda, puede estar desmontada al
            # editar el horario; no se exige el dir presente en ese momento.
            if not self._is_network_source(source) and not Path(source).is_dir():
                raise HTTPException(status_code=400, detail="La ruta de origen no es válida.")
            vault = self._vault_for_source(source)
            if vault is None or not vault.is_dir():
                raise HTTPException(status_code=400, detail="La unidad no tiene carpeta Respaldo.")
            config = self._load_config(vault)
            conflict, kind = self._find_conflict(config, source, exclude_id=job_id)
            if conflict is not None and kind == "parent_child":
                raise HTTPException(
                    status_code=400,
                    detail=f"Ya existe un respaldo para la ruta {conflict.get('source_path')} (o una carpeta padre/hijo).",
                )
            job["source_path"] = source
            job.vault = vault
        with self._lock:
            self._apply_job_data(job, data)
            self._save_job_locked(job)
        # «Desactivar» también detiene un respaldo en curso: lo ya
        # respaldado se conserva y, al reactivar, restic retoma sin resubir.
        enabled_req = getattr(data, "enabled", None)
        if enabled_req is False:
            cancelled = self._cancel_running_backup(job.get("id"))
            if cancelled:
                logger.info(
                    "Respaldo %s desactivado; se canceló la ejecución en curso.",
                    job.get("name"),
                )
                # Marcar el resultado como un pausado por desactivación, NO
                # como error: el usuario no canceló por falla, sino que
                # desactivó la programación mientras corría.
                if not job.get("last_result") or job.get("last_result", "").startswith("Respaldo cancelado"):
                    job["last_result"] = "Pausado (se desactivó la programación)"
                    with self._lock:
                        self._save_job_locked(job)
        if new_source is not None:
            self._dedupe_by_source(job.vault, job["source_path"], job)
        self._sync_folder_policy(db, job)
        return self._serialize(job)

    def delete_job(self, job_id: int) -> None:
        """Elimina SOLO la programación (no toca los datos del respaldo).

        La partición de respaldo es la entidad que conserva el repo: quitar
        una programación nunca borra el histórico. Para borrar también los
        datos se usa `delete_job_and_repo` con confirmación explícita.
        """
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        with self._lock:
            config = self._load_config(job.vault)
            config["jobs"] = [
                r for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            self._save_config(job.vault, config)
        # NO se llama a _remove_repo: los datos pertenecen a la partición.

    def delete_job_and_repo(self, job_id: int, *, confirm: str) -> dict:
        """Borra la programación Y el repositorio restic de ese respaldo.

        Es la única vía de perder el histórico; exige confirmación explícita
        (confirm == "ELIMINAR") y avisa que incluye perder el acceso a la
        información respaldada.
        """
        if (confirm or "").strip().upper() != "ELIMINAR":
            raise HTTPException(
                status_code=400,
                detail=("Para borrar el respaldo y sus datos escribe ELIMINAR."),
            )
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        # No borrar un repo que está en ejecución.
        if job.get("id") in self._running_jobs:
            raise HTTPException(
                status_code=400,
                detail="El respaldo está en ejecución; desactívalo/espéralo antes de borrar sus datos.",
            )
        with self._lock:
            config = self._load_config(job.vault)
            config["jobs"] = [
                r for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            self._save_config(job.vault, config)
        repo = self._repo_path(job)
        removed = repo.exists() and repo.is_dir()
        if removed:
            try:
                shutil.rmtree(repo)
            except Exception as error:
                logger.warning("No se pudo borrar repo %s: %s", repo, error)
                raise HTTPException(
                    status_code=500,
                    detail=f"No se pudo borrar el repositorio: {error}",
                )
        return {
            "success": True,
            "programming_removed": True,
            "data_removed": removed,
            "message": (
                "Programación eliminada"
                + (" y datos del respaldo borrados." if removed else ".")
            ),
        }

    def delete_jobs_for_folder(self, folder_id: int) -> None:
        """Elimina la programación de los jobs de una carpeta (sin tocar
        los repos; los datos quedan en la partición de respaldo)."""
        for vault in self._vaults():
            config = self._load_config(vault)
            victims = [
                r for r in config.get("jobs", []) if int(r.get("folder_id") or 0) == int(folder_id or 0)
            ]
            if not victims:
                continue
            alive = [
                r for r in config.get("jobs", []) if int(r.get("folder_id") or 0) != int(folder_id or 0)
            ]
            with self._lock:
                config["jobs"] = alive
                self._save_config(vault, config)

    def delete_jobs_for_source(self, source_path: str) -> None:
        """Elimina la programación de los jobs apuntando a ese origen (no
        toca los repos; los datos quedan en la partición de respaldo)."""
        if not source_path:
            return
        for vault in self._vaults():
            config = self._load_config(vault)
            victims = [
                r for r in config.get("jobs", []) if r.get("source_path") == source_path
            ]
            if not victims:
                continue
            alive = [
                r for r in config.get("jobs", []) if r.get("source_path") != source_path
            ]
            with self._lock:
                config["jobs"] = alive
                self._save_config(vault, config)

    def delete_jobs_for_mountpoint(self, mountpoint: str) -> dict:
        """Elimina TODA la programación ligada a una partición (y sus repos).

        La programación de un respaldo vive ligada a la partición de
        respaldo: al eliminar la partición, el usuario asume el riesgo y
        se pierde tanto el origen como el histórico. Por eso aquí se
        eliminan los jobs cuyo ORIGEN o cuya BÓVEDA (destino) quedan
        dentro de `mountpoint`, borrando también sus repositorios restic.

        Devuelve un resumen de lo eliminado (para el mensaje en la UI).
        """
        if not mountpoint:
            return {"removed_jobs": [], "removed_repos": 0}
        try:
            root = Path(mountpoint).resolve()
        except OSError:
            return {"removed_jobs": [], "removed_repos": 0}

        removed_jobs: list[str] = []
        removed_repos = 0

        def inside(path: Path) -> bool:
            try:
                p = path.resolve()
            except OSError:
                return False
            return p == root or root in p.parents

        with self._lock:
            for vault in self._vaults():
                config = self._load_config(vault)
                victims = [
                    r for r in config.get("jobs", [])
                    if inside(Path(str(r.get("source_path") or ""))
                              or str(vault))
                    or inside(Path(str(vault)))
                ]
                if not victims:
                    continue
                alive = [r for r in config.get("jobs", []) if r not in victims]
                config["jobs"] = alive
                self._save_config(vault, config)
                for record in victims:
                    job = Job(record, vault=vault)
                    name = job.get("name") or job.get("source_path")
                    if name:
                        removed_jobs.append(str(name))
                    repo = self._repo_path(job)
                    try:
                        if repo.exists() and repo.is_dir():
                            shutil.rmtree(repo)
                            removed_repos += 1
                    except Exception as error:
                        logger.warning(
                            "delete_jobs_for_mountpoint: no pude borrar repo %s: %s",
                            repo, error,
                        )

        return {
            "removed_jobs": removed_jobs,
            "removed_repos": removed_repos,
        }

    def _remove_repo(self, job: Job) -> None:
        repo = self._repo_path(job)
        if repo.exists():
            try:
                shutil.rmtree(repo)
            except Exception as error:
                logger.warning("Could not remove repo %s: %s", repo, error)

    # ------------------------------------------------------------------
    # folder policy bridge (the config file is the source of truth; the
    # folder fields in the DB are only a read-only reflection)
    # ------------------------------------------------------------------

    def _find_folder_for_source(self, db: Session, source: str) -> NetworkShareFolder | None:
        if db is None or not source:
            return None
        from backend.shares.services.network_share_service import NetworkShareService

        svc = NetworkShareService()
        for folder in db.query(NetworkShareFolder).all():
            try:
                if svc._folder_path(db, folder) == source:
                    return folder
            except Exception as error:
                logger.debug("share_backup_service._find_folder_for_source: %s", error)
                continue
        return None

    def _sync_folder_policy(self, db: Session, job: Job) -> None:
        """Refleja la programación del job (fuente de verdad) en la carpeta
        de la base de datos únicamente como caché de la interfaz."""
        folder = self._find_folder_for_source(db, job.get("source_path") or "")
        if folder is None:
            return
        folder.backup_mode = "on_change" if job.get("schedule_mode") == "on_change" else "times"
        folder.backup_retention = max(1, int(job.get("retention_count") or 7))
        if job.get("schedule_mode") == "daily":
            times = self._times_list(job)
            if times:
                folder.backup_times_per_day = max(1, min(24, len(times)))
        else:
            folder.backup_times_per_day = max(
                1, min(24, int(folder.backup_times_per_day or 1))
            )
        db.commit()

    def ensure_folder_job(self, db: Session, folder, source: str) -> None:
        """Convierte la política de respaldo de una carpeta en un job del
        archivo de configuración (bóveda). «off» elimina el job."""
        source = (source or "").strip()
        vault = self._vault_for_source(source) if source else None
        if folder is not None and getattr(folder, "backup_mode", None) == "off":
            if vault is not None and vault.is_dir():
                with self._lock:
                    config = self._load_config(vault)
                    victims = [
                        r for r in config.get("jobs", []) if r.get("source_path") == source
                    ]
                    if victims:
                        for record in victims:
                            self._remove_repo(Job(record, vault=vault))
                        config["jobs"] = [
                            r for r in config.get("jobs", []) if r.get("source_path") != source
                        ]
                        self._save_config(vault, config)
            return
        if vault is None or not vault.is_dir() or not source:
            return

        with self._lock:
            config = self._load_config(vault)
            existing = next(
                (r for r in config.get("jobs", []) if r.get("source_path") == source),
                None,
            )
            if existing is not None:
                job = Job(existing, vault=vault)
                job["enabled"] = True
                job["retention_count"] = max(
                    1, int(getattr(folder, "backup_retention", None) or job.get("retention_count") or 7)
                )
                job["folder_id"] = getattr(folder, "id", None)
            else:
                record = dict(_default_job())
                record.update({
                    "id": self._next_global_job_id(),
                    "name": f"folder-{getattr(folder, 'id', '')}-{getattr(folder, 'name', '')}",
                    "source_path": source,
                    "enabled": True,
                    "folder_id": getattr(folder, "id", None),
                    "retention_count": max(1, int(getattr(folder, "backup_retention", None) or 7)),
                })
                if getattr(folder, "backup_mode", None) == "on_change":
                    record["schedule_mode"] = "on_change"
                    record["interval_minutes"] = None
                else:
                    record["schedule_mode"] = "interval"
                    times = max(1, min(24, int(getattr(folder, "backup_times_per_day", None) or 1)))
                    record["interval_minutes"] = max(15, 1440 // times)
                config["next_job_id"] = int(record["id"]) + 1
                config.setdefault("jobs", []).append(record)
                job = Job(record, vault=vault)

            config["jobs"] = [
                dict(r) for r in config.get("jobs", []) if int(r.get("id") or 0) != int(job.get("id") or 0)
            ]
            config["jobs"].append(dict(job))
            self._save_config(vault, config)

        self._dedupe_by_source(vault, source, job)
        self._sync_folder_policy(db, job)

    # ------------------------------------------------------------------
    # protección antiransomware durante respaldos "por horario"
    # ------------------------------------------------------------------

    def has_active_protected_backup(self) -> bool:
        """
        True mientras haya al menos un respaldo "por horario" (daily o
        interval) en ejecución. `share_integrity_watch_service` consulta
        esto para saltarse su escaneo mientras dure -- así el propio
        respaldo (lectura masiva del árbol de origen) nunca puede disparar
        el bloqueo antiransomware por error, y la ventana sin vigilancia
        dura exactamente lo que dura el respaldo, ni un segundo más.

        Deliberadamente NO cubre "on_change": ese modo queda pendiente de
        revisión por su propio riesgo de evasión y no debe ganar además
        una ventana de protección.
        """
        with self._lock:
            return self._active_protected_backups > 0

    def has_active_restore(self) -> bool:
        """True mientras haya una RESTAURACIÓN en curso (escritura masiva
        legítima del propio sistema hacia una unidad destino). El watchdog
        antiransomware consulta esto para saltarse su escaneo mientras dure,
        igual que ya hace con los respaldos por horario: restaurar miles de
        archivos de golpe NO debe disparar el bloqueo (es actividad del
        sistema, no ransomware)."""
        try:
            for _job_id, st in (self._restore_status or {}).items():
                if st and st.get("running"):
                    return True
            return False
        except Exception as error:
            logger.debug("share_backup_service.has_active_restore: %s", error)
            return False

    # ------------------------------------------------------------------
    # Bitácora persistente de RESTAURACIONES
    # ------------------------------------------------------------------

    def _restore_ledger_path(self) -> Path:
        return Path(
            os.environ.get("RESTORE_STATE_PATH", str(RESTORE_STATE_PATH))
        )

    def _load_restore_ledger(self) -> dict:
        return restore_ledger.load(self._restore_ledger_path())

    def _save_restore_ledger(self, ledger: dict) -> None:
        restore_ledger.save(self._restore_ledger_path(), ledger)

    def _upsert_restore_ledger(self, job_id: int, **fields) -> None:
        restore_ledger.upsert(
            self._restore_ledger_path(),
            job_id,
            now_ecuador().isoformat(),
            **fields,
        )

    @staticmethod
    def _process_alive(pid) -> bool:
        return restore_ledger.process_alive(pid)

    def reconcile_restores(self) -> list[dict]:
        """Marca como 'interrumpida' toda restauración registrada como
        'running' cuyo proceso restic ya no esté vivo (corte de red, reinicio
        del servicio, apagón). Tras un reinicio el estado en memoria se perdió;
        esta reconciliación reconstruye la verdad desde la bitácora en disco."""
        self._restore_status = self._restore_status or {}
        ledger = self._load_restore_ledger()
        changed = False
        for key, entry in list(ledger["restores"].items()):
            if entry.get("status") != "running":
                continue
            jid = int(key)
            active = self._restore_status.get(jid) or {}
            if active.get("running"):
                continue
            if self._process_alive(entry.get("pid")):
                continue
            entry["status"] = "interrupted"
            entry["error"] = (
                entry.get("error")
                or "Restauración interrumpida (el proceso no está activo)."
            )
            entry["finished_at"] = now_ecuador().isoformat()
            changed = True
        if changed:
            self._save_restore_ledger(ledger)
        return list(ledger["restores"].values())

    def list_restores(self) -> list[dict]:
        self.reconcile_restores()
        ledger = self._load_restore_ledger()
        rows = []
        for key, entry in ledger["restores"].items():
            row = dict(entry)
            jid = int(key)
            active = (self._restore_status or {}).get(jid) or {}
            if active.get("running"):
                row["status"] = "running"
            dest = str(entry.get("destination") or "")
            row["staging_left"] = bool(
                dest and (Path(dest) / ".stepad-restore.tmp").exists()
            )
            rows.append(row)
        rows.sort(key=lambda r: r.get("started_at") or "", reverse=True)
        return rows

    def cleanup_restore(self, job_id: int) -> dict:
        """Borra los restos de una restauración (staging `.stepad-restore.tmp`)
        dejados por una interrupción, sin tocar lo ya restaurado a la raíz."""
        entry = self._load_restore_ledger()["restores"].get(str(job_id)) or {}
        dest = Path(str(entry.get("destination") or ""))
        staging = dest / ".stepad-restore.tmp"
        removed = False
        try:
            if staging.exists():
                shutil.rmtree(staging, ignore_errors=True)
                removed = not staging.exists()
        except Exception as error:
            raise HTTPException(500, f"No se pudo limpiar restos: {error}")
        self._upsert_restore_ledger(job_id, staging_cleaned=True)
        return {
            "success": True,
            "cleaned": removed,
            "destination": str(dest) if str(dest) else None,
            "message": (
                "Restos de la restauración eliminados."
                if removed
                else "No había restos que limpiar."
            ),
        }

    def cancel_restore(self, job_id: int) -> dict:
        self.reconcile_restores()
        job_id = int(job_id)
        active = (self._restore_status or {}).get(job_id) or {}
        was_running = bool(active.get("running"))
        killed = False
        if was_running:
            job = self._find_job(job_id)
            if job is not None:
                try:
                    repo = str(self._repo_path(job))
                    proc = subprocess.run(
                        ["pkill", "-f", f"{repo} restore "],
                        capture_output=True,
                    )
                    killed = proc.returncode == 0
                except Exception as error:
                    logger.warning("cancel_restore: no pude matar restic: %s", error)
            self._restore_status[job_id] = {
                "running": False,
                "error": "Restauración cancelada por el usuario.",
                "result": None,
            }
            self._upsert_restore_ledger(
                job_id,
                status="interrupted",
                error="Restauración cancelada por el usuario.",
                finished_at=now_ecuador().isoformat(),
            )
        return {"success": True, "was_running": was_running, "cancelled": killed}

    def retry_restore(self, job_id: int) -> dict:
        self.reconcile_restores()
        job_id = int(job_id)
        entry = self._load_restore_ledger()["restores"].get(str(job_id)) or {}
        snapshot_id = str(entry.get("snapshot_id") or "")
        destination = entry.get("destination") or None
        if not snapshot_id:
            raise HTTPException(400, "La restauración registrada no tiene versión para reintentar.")
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(404, "No se encontró el respaldo para reintentar.")
        logger.info(
            "Reintentando restauración del job %s (snapshot %s) en «%s».",
            job_id, snapshot_id[:12], destination,
        )
        return self.restore_snapshot(job_id, snapshot_id, target=destination)

    def _begin_protected_backup(self) -> None:
        with self._lock:
            self._active_protected_backups += 1
    def _end_protected_backup(self) -> None:
        with self._lock:
            self._active_protected_backups = max(
                0, self._active_protected_backups - 1
            )

    # ------------------------------------------------------------------
    # bitácora de corridas (éxito/fallo, con logging del sistema)
    # ------------------------------------------------------------------

    def _append_history(
        self,
        job: Job,
        *,
        success: bool,
        message: str,
        bytes_added: int = 0,
        duration_seconds: float | None = None,
        trigger: str = "scheduled",
        snapshot_id: str | None = None,
    ) -> None:
        entry = {
            "at": now_ecuador().isoformat(),
            "success": bool(success),
            "message": (message or "")[:500],
            "bytes_added": int(bytes_added or 0),
            "duration_seconds": (
                round(duration_seconds, 1)
                if duration_seconds is not None
                else None
            ),
            # "scheduled" (horario) | "manual" (botón Ejecutar ahora) |
            # "on_change" (pendiente/desactivado hoy).
            "trigger": trigger,
        }
        if snapshot_id:
            entry["snapshot_id"] = (snapshot_id or "")[:64]
        history = list(job.get("history") or [])
        history.append(entry)
        job["history"] = history[-HISTORY_LIMIT:]

        log_line = "Respaldo '%s' (job %s, %s): %s"
        if success:
            logger.info(log_line, job.get("name"), job.get("id"), trigger, entry["message"])
        else:
            logger.warning(log_line, job.get("name"), job.get("id"), trigger, entry["message"])

    def _finish_run(
        self,
        job: Job,
        *,
        success: bool,
        message: str,
        started_at: float,
        trigger: str,
        snapshot_id: str | None = None,
        bytes_added: int = 0,
        update_backup_time: bool = True,
    ) -> None:
        """Registra el resultado de una corrida (bitácora + log + guardado).

        `update_backup_time` preserva el comportamiento previo: un timeout,
        un error de restic o un fallo de montaje NO adelantan
        `last_backup_at`, así el job sigue "vencido" y se reintenta -- pero
        ahora con backoff (ver is_due/_backoff_elapsed) en vez de cada
        POLL_SECONDS sin límite.
        """
        duration = time.monotonic() - started_at
        job["last_result"] = (message or "")[:500]
        job["last_attempt_at"] = now_ecuador().isoformat()
        if update_backup_time:
            job["last_backup_at"] = now_ecuador().isoformat()
        if snapshot_id is not None:
            job["last_snapshot_id"] = (snapshot_id or "")[:64]
        if success:
            job["last_bytes"] = bytes_added
            job["consecutive_failures"] = 0
            job["overdue_alerted"] = False
            if job.get("failure_alert_active"):
                job["failure_alert_active"] = False
                logger.info(
                    "Respaldo '%s' se recuperó tras fallos consecutivos.",
                    job.get("name"),
                )
        else:
            job["consecutive_failures"] = int(job.get("consecutive_failures") or 0) + 1
            if (
                job["consecutive_failures"] >= FAILURE_ALERT_THRESHOLD
                and not job.get("failure_alert_active")
            ):
                job["failure_alert_active"] = True
                self._raise_failure_alert(job, message)
        self._append_history(
            job,
            success=success,
            message=message,
            bytes_added=bytes_added,
            duration_seconds=duration,
            trigger=trigger,
            snapshot_id=snapshot_id,
        )
        self._save_job(job)

    def _raise_failure_alert(self, job: Job, message: str) -> None:
        """Alerta cuando un job acumula FAILURE_ALERT_THRESHOLD fallos
        consecutivos. Antes de esto, un respaldo roto por cualquier motivo
        que no fuera "la carpeta desapareció" fallaba en silencio -- nadie
        se enteraba a menos que abriera manualmente el historial de ESE
        job en particular.
        """
        try:
            db = SessionLocal()
            try:
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type=BACKUP_FAILING_ALERT,
                    severity="warning",
                    title=f"Respaldo fallando: {job.get('name')}",
                    message=(
                        f"El respaldo «{job.get('name')}» lleva "
                        f"{job.get('consecutive_failures')} intentos "
                        f"fallidos consecutivos. Último error: {message}"
                    )[:500],
                )
                db.commit()
                logger.warning(
                    "Alerta: respaldo '%s' fallando repetidamente (%s intentos).",
                    job.get("name"), job.get("consecutive_failures"),
                )
            finally:
                db.close()
        except Exception as error:
            logger.warning("No se pudo crear alerta de respaldo fallido: %s", error)

    def job_history(self, job_id: int) -> list[dict]:
        """Bitácora del job, más reciente primero."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        return list(reversed(job.get("history") or []))

    # ------------------------------------------------------------------
    # run / snapshots / files / download
    # ------------------------------------------------------------------

    def run_backup(self, job_id: int, *, trigger: str = "manual") -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        return self.run_backup_job(job, trigger=trigger)

    def run_backup_job(self, job: Job, *, trigger: str = "manual") -> dict:
        """Igual que run_backup pero sobre un job YA resuelto (con su bóveda).

        El scheduler la usa para ejecutar EXACTAMENTE el job cuyo is_due()
        evaluó: re-resolver por id con _find_job() podría devolver un job
        distinto con el mismo id en otra bóveda (ids por-bóveda)."""
        started_at = time.monotonic()

        # Retomar tras un corte: restic es tolerante a interrupciones — si la
        # corrida anterior se cortó (corte de red, reinicio del servicio,
        # timeout), los datos ya subidos quedan en el repo y restic continúa
        # desde donde quedó (no vuelve a subir lo subido). Aquí se detecta e
        # informa, y si el repo queda sospechoso se hace `restic check`
        # (sin bloquear la corrida) para detectar daño.
        prev_ok = job.get("last_result") or ""
        prev_failed = not (
            prev_ok.startswith("Sin cambios") or prev_ok.startswith("Respaldo ejecutado") or prev_ok.startswith("Éxito")
            or prev_ok.startswith("OK") or ("restaurado" in prev_ok) or (prev_ok == "")
        )
        if prev_failed:
            logger.info(
                "Respaldo '%s' (%s): la corrida anterior quedó interrumpida "
                "(%s). restic retomará desde donde quedó (no re-subirá lo ya "
                "subido).",
                job.get("name"), trigger, prev_ok[:80] or "sin registro",
            )

        # Omitir si nada cambió desde el último respaldo real: así un horario o
        # un «Ejecutar ahora» sin modificaciones no crea versiones vacías.
        source = Path(job.get("source_path") or "")
        baseline = job.get("tree_hash")
        # OJO (v2.5.283): para orígenes de red YA NO se omite comparando el
        # ID del último snapshot del repo contra el baseline "snap:<id>".
        # Ese approach era INCORRECTO: detectó que "el último snapshot NO ha
        # cambiado" (siempre es el mismo dd46de72) y por eso ignoraba cambios
        # FUTUROS en M (el respaldo decía "sin cambios" aunque hubieras
        # modificado archivos). Ahora el respaldo de red SIEMPRE corre
        # `restic backup --json`: restic escanea el árbol por stat (rápido en
        # red, sin leer contenido) y emite summary con bytes_added. Si dio
        # +0 bytes, el bloque posterior (bytes_added == 0) marca el nuevo
        # baseline snap:<id>; si hubo cambios, crea la versión y actualiza.
        # Así se versionan SÍ los cambios, sin crear versiones vacías por
        # cada horario.
        if self._dir_live(source) and baseline:
            current = self._tree_signature(source)
            if current and current == baseline:
                detail = "Sin cambios desde el último respaldo. No se creó versión."
                dur = time.monotonic() - started_at
                logger.info(
                    "Respaldo '%s' (%s): no se hizo nada por no haber cambios; "
                    "demoró %.1f s. No se creó versión.",
                    job.get("name"),
                    trigger,
                    dur,
                )
                self._finish_run(
                    job,
                    success=True,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                )
                return {
                    "success": True,
                    "skipped": True,
                    "message": detail,
                    "bytes_added": 0,
                    "bytes_added_human": "0 B",
                }

        return self._launch_run_thread(
            job,
            started_at=started_at,
            trigger=trigger,
        )

    def _launch_run_thread(
        self,
        job: Job,
        *,
        started_at: float,
        trigger: str,
    ) -> dict:
        """Lanza el respaldo en segundo plano y vuelve al toque.

        El respaldo puede tardar mucho (especialmente desde un share de red):
        bloqueando la petición el usuario ve «Ejecutando respaldo…» para
        siempre. En su lugar se devuelve enseguida y el progreso/estado se
        consulta por el endpoint de progress y el listado de jobs."""
        worker = threading.Thread(
            target=self._run_backup_in_thread,
            args=(job,),
            kwargs={"started_at": started_at, "trigger": trigger},
            name=f"share-backup-{job.get('id')}",
            daemon=True,
        )
        worker.start()
        return {
            "success": True,
            "running": True,
            "message": "Respaldo en curso…",
            "job_id": job.get("id"),
        }

    def _backup_volume_for_path(
        self,
        vault: Path | str | None,
    ):
        """
        Si la bóveda de destino vive dentro de una partición registrada
        con rol "backup", devuelve el NetworkShareVolume. Los roles
        "shared" / "private" no aplican aquí (los primeros quedan
        siempre montados; las privadas las gestiona la web).
        """
        if not vault:
            return None
        try:
            vault_str = str(vault).strip()
            db = SessionLocal()
            try:
                for volume in db.query(NetworkShareVolume).all():
                    purpose = getattr(volume, "purpose", "shared") or "shared"
                    if purpose != "backup":
                        continue
                    mp = str(volume.mountpoint or "").rstrip("/")
                    if mp and vault_str.startswith(mp + "/"):
                        return volume
                return None
            finally:
                db.close()
        except Exception as error:
            logger.warning("_backup_volume_for_path: %s", error)
            return None

    def _mount_backup_dest(self, job: Job) -> dict | None:
        """
        Monta por demanda la partición "backup" que contiene la bóveda
        destino de este job. Devuelve {"volume": name, "mounted_now": bool}
        o None si no aplica (no es backup).
        """
        vault = job.vault or self._dest_folder(job.get("source_path") or "")
        volume = self._backup_volume_for_path(vault)
        if volume is None:
            return None
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        provider = ShareDiskMountProvider()
        if not provider.is_mounted_at(volume.mountpoint):
            result = provider.mount_now(
                uuid=volume.device_uuid,
                mountpoint=volume.mountpoint,
            )
            if not result.get("success"):
                raise HTTPException(
                    status_code=500,
                    detail=(
                        f"No se pudo montar la partición de respaldo "
                        f"«{volume.name}»: {result.get('message', '')}"
                    ),
                )
            return {
                "volume": volume.name,
                "mounted_now": True,
                "mountpoint": volume.mountpoint,
            }
        return {
            "volume": volume.name,
            "mounted_now": False,
            "mountpoint": volume.mountpoint,
        }

    def _unmount_backup_dest(self, job: Job) -> None:
        """Desmonta la partición "backup" destino tras el respaldo."""
        vault = job.vault or self._dest_folder(job.get("source_path") or "")
        volume = self._backup_volume_for_path(vault)
        if volume is None:
            return
        from backend.shares.providers.share_disk_mount_provider import (
            ShareDiskMountProvider,
        )

        provider = ShareDiskMountProvider()
        if provider.is_mounted_at(volume.mountpoint):
            provider.unmount_now(volume.mountpoint)

    def _run_backup_in_thread(
        self,
        job: Job,
        *,
        started_at: float,
        trigger: str,
    ) -> None:
        with self._lock:
            if job.get("id") in self._running_jobs:
                return
            self._running_jobs.add(job.get("id"))
            self._running_since[job.get("id")] = now_ecuador().isoformat()

        protected = job.get("schedule_mode") != "on_change"
        if protected:
            self._begin_protected_backup()

        # Cola anti-solapamiento: si otro respaldo programado/manual está
        # corriendo, éste ESPERA su turno (se encola) en vez de correr en
        # paralelo y competir por disco/red. Se libera solo.
        if protected:
            waited = 0
            while True:
                with self._lock:
                    other_running = any(
                        other != job.get("id")
                        for other in self._running_jobs
                    )
                    self_job_running = job.get("id") in self._running_jobs
                if not self_job_running:
                    # El job fue cancelado/eliminado mientras esperaba.
                    return
                if not other_running:
                    break
                if waited >= 60 * 60:
                    logger.warning(
                        "Respaldo %s esperó 60 min por otro respaldo; "
                        "arranca de todos modos.",
                        job.get("name"),
                    )
                    break
                time.sleep(5)
                waited += 5

        shaper = None
        # Limitar el ancho de banda del respaldo de red (QoS): restic lee el
        # origen a plena velocidad y satura el enlace. Best-effort: si no se
        # puede, el respaldo corre sin límite (nunca se rompe).
        if self._is_network_source(str(job.get("source_path") or "")):
            try:
                ip = self._network_source_ip(job)
                if ip:
                    iface = net_rate_shaper.interface_for(ip)
                    link = net_rate_shaper.link_speed_mbps(iface) if iface else 0
                    mbps = net_rate_shaper.effective_limit_mbps(
                        job.get("rate_limit_mbps"), link,
                    )
                    if mbps and iface:
                        shaper = net_rate_shaper.apply(iface, ip, mbps, link)
            except Exception as error:
                logger.warning("No se pudo aplicar límite de red del respaldo: %s", error)

        mounted_dest = None
        try:
            mounted_dest = self._mount_backup_dest(job)
            try:
                self._run_backup_locked(
                    job,
                    started_at=started_at,
                    trigger=trigger,
                )
            except HTTPException as error:
                self._finish_run(
                    job,
                    success=False,
                    message=error.detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
            except Exception as error:
                logger.exception(
                    "Respaldo %s falló inesperadamente: %s",
                    job.get("name"), error,
                )
                self._finish_run(
                    job,
                    success=False,
                    message=f"Error inesperado: {error}",
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
        finally:
            # La partición "backup" solo está montada durante la corrida:
            # se desmonta al terminar (éxito o fallo) para que quede
            # inaccesible al resto del tiempo (anti-ransomware).
            if mounted_dest:
                try:
                    self._unmount_backup_dest(job)
                except Exception as error:
                    logger.warning(
                        "No se pudo desmontar partición de respaldo: %s",
                        error,
                    )
            with self._lock:
                self._running_jobs.discard(job.get("id"))
                self._running_since.pop(job.get("id"), None)
            if protected:
                self._end_protected_backup()
            # Quitar el límite de ancho de banda aplicado a este respaldo
            # (si se llegó a aplicar), para volver a plena velocidad.
            if shaper:
                try:
                    net_rate_shaper.remove(shaper.get("iface"), shaper.get("ip"))
                except Exception as error:
                    logger.warning("No se pudo quitar límite de red del respaldo: %s", error)

    def _run_backup_locked(self, job: Job, *, started_at: float, trigger: str) -> dict:
        if not self.installed():
            raise HTTPException(
                status_code=400,
                detail="restic no está instalado. Instala el paquete: apt-get install -y restic",
            )
        source = Path(job.get("source_path") or "")
        mounted = None

        # Mount network share if needed (only for SMB paths, not local mounts)
        if self._is_network_source(str(source)) and not str(source).startswith("/mnt/"):
            mounted = self._mount_share(job, str(source))
            if not mounted:
                detail = "No se pudo montar el share de red. Verifique credenciales y conectividad."
                self._finish_run(
                    job,
                    success=False,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
                return {"success": False, "message": detail}
            source = Path(mounted)
        elif "/stepad-network/" in str(source):
            # Unidad de red registrada (p. ej. /mnt/stepad-network/M). Se
            # ASEGURA el montaje siempre: un share puede quedar "fantasma"
            # (dir vacío sin acceso real) y restic correría contra una
            # carpeta vacía sin terminar bien el respaldo programado.
            needs_mount = not self._dir_live(source)
            if not needs_mount:
                try:
                    has_children = any(Path(source).iterdir())
                except OSError:
                    has_children = False
                if not has_children:
                    # Dir vacío: o el share no está montado de verdad o el
                    # equipo origen no lo expone. Forzamos (re)montaje.
                    needs_mount = True
            if needs_mount:
                if not self._ensure_network_unit_mounted(str(source)):
                    detail = (
                        f"La unidad de red del origen no está disponible "
                        f"({source}). Verifique que el equipo origen esté "
                        "encendido y conectado, y vuelva a intentar."
                    )
                    self._finish_run(
                        job,
                        success=False,
                        message=detail,
                        started_at=started_at,
                        trigger=trigger,
                        update_backup_time=False,
                    )
                    return {"success": False, "message": detail}
                source = Path(job.get("source_path") or "")

            # Tras montar, el origen DEBE traer datos: si sigue vacío, el
            # share no responde y un respaldo programado quedaría colgado.
            try:
                origin_empty = not any(Path(source).iterdir())
            except OSError:
                origin_empty = True
            if origin_empty:
                detail = (
                    f"El origen {source} está vacío o sin acceso al share "
                    "de red. Verifique que el equipo origen esté encendido "
                    "y vuelva a intentar."
                )
                self._finish_run(
                    job,
                    success=False,
                    message=detail,
                    started_at=started_at,
                    trigger=trigger,
                    update_backup_time=False,
                )
                return {"success": False, "message": detail}

        if not self._dir_live(source):
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        # Crear directorio del repo antes de verificar
        try:
            self._ensure_repo(job)
        except HTTPException:
            if mounted:
                self._unmount_share(job)
            raise

        # Verificar que el destino esté disponible
        repo = self._repo_path(job)
        dest_parent = repo.parent
        if not dest_parent.exists():
            detail = f"El destino del respaldo no está disponible ({dest_parent}). Verifique que el disco/USB esté conectado."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        # Verificar que se pueda escribir en el destino
        try:
            test_file = dest_parent / ".stepad_write_test"
            test_file.write_text("test")
            test_file.unlink()
        except (OSError, PermissionError) as e:
            detail = f"No se puede escribir en el destino ({dest_parent}): {e}. Verifique permisos y que el disco no esté en solo lectura."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}
        except HTTPException:
            if mounted:
                self._unmount_share(job)
            raise

        # Skip system/temp files that cause "device or resource busy"
        # on SMB mounts (hidden files, windows system files, etc.)
        args = [
            "backup",
            str(source),
            "--host", "stepad",
            "--tag", f"job:{job.get('id')}",
            "--exclude-caches",
            "--exclude", "desktop.ini",
            "--exclude", "Thumbs.db",
            "--exclude", ".DS_Store",
            "--exclude", "System Volume Information",
            "--exclude", "$RECYCLE.BIN",
            "--exclude", ".*",
            "--json",
        ]
        try:
            # 48 h de tope: un respaldo inicial grande (cientos de GB desde
            # una unidad de red lenta, decenas de miles de archivos) no debe
            # cortarse por el reloj. El respaldo corre en segundo plano y el
            # usuario puede cancelarlo con «Parar» cuando quiera.
            result = self._restic(job, args, timeout=172800, track=True, stall_timeout=BACKUP_STALL_SECONDS)
        except subprocess.TimeoutExpired:
            detail = "El respaldo tardó demasiado y se canceló."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}
        except Exception as error:
            logger.debug("share_backup_service._run_backup_locked: %s", error)
            detail = f"Error ejecutando restic: {error}"
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            if mounted:
                self._unmount_share(job)
            return {"success": False, "message": detail}

        if mounted:
            self._unmount_share(job)

        if job.get("id") in self._cancel_requested:
            self._cancel_requested.discard(job.get("id"))
            # La ejecución se detuvo por desactivar/pausar la programación.
            # No es una cancelación "del usuario" (nadie la cancela): es una
            # detención controlada. Lo ya respaldado se conserva y, al
            # reactivar, restic retoma sin resubir.
            detail = "Pausado (se desactivó o pausó la programación)."
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            return {"success": False, "paused": True, "message": detail}

        if result.returncode != 0:
            if result.returncode == -15:
                detail = (
                    "Interrumpido: el origen no respondió (posible caída de red). "
                    "Se retomará en el próximo horario."
                )
            else:
                detail = f"restic falló: {result.stderr.strip()[:400]}"
            self._finish_run(
                job,
                success=False,
                message=detail,
                started_at=started_at,
                trigger=trigger,
                update_backup_time=False,
            )
            return {"success": False, "message": detail}

        snapshot_id = None
        bytes_processed = 0
        bytes_added = 0
        files_new = 0
        files_changed = 0
        for line in (result.stdout or "").splitlines():
            try:
                payload = json.loads(line)
            except Exception as error:
                logger.debug("share_backup_service._run_backup_locked: %s", error)
                continue
            if payload.get("message_type") == "summary":
                snapshot_id = payload.get("snapshot_id")
                bytes_processed = int(payload.get("total_bytes_processed") or 0)
                # Mismo criterio que la lista de VERSIONES (list_snapshots):
                # 'data_added' = datos nuevos (dedup). Así el HISTORIAL y las
                # VERSIONES muestran el MISMO tamaño (antes el historial leía
                # "packed" y por eso salía 0 mientras la versión mostraba X).
                bytes_added = int(
                    payload.get("data_added")
                    or payload.get("total_bytes_added_packed")
                    or payload.get("total_bytes_added")
                    or 0
                )
                files_new = int(payload.get("files_new") or 0)
                files_changed = int(payload.get("files_changed") or 0)
            elif payload.get("message_type") == "snapshot":
                snapshot_id = payload.get("snapshot_id") or payload.get("id") or snapshot_id

        fresh_hash = None
        if not self._is_network_source(str(source)):
            try:
                fresh_hash = self._tree_signature(source)
            except Exception as error:
                logger.debug("share_backup_service._run_backup_locked: %s", error)
                fresh_hash = None
        if fresh_hash is not None:
            job["tree_hash"] = fresh_hash
        elif "tree_hash" in job:
            # Keep previous baseline if any, so the early "sin cambios"
            # skip still works without rescanning.
            job.setdefault("tree_hash", job.get("tree_hash"))

        # Para orígenes de red no se puede escanear el árbol barato; se usa
        # el snapshot id como baseline. Si restic reporta +0 bytes nuevos,
        # NO hubo cambios reales: se descarta la copia vacía recién creada
        # (ver bloque siguiente) para NO generar versiones sin cambios.
        # Solo se descarta el snapshot si el árbol es IDÉNTICO al anterior
        # (sin bytes nuevos Y sin archivos nuevos ni cambiados). Si hubiera
        # archivos nuevos/cambiados, es una versión REAL aunque restic reporte
        # +0 B (los datos pudieron subirse antes / deduplicarse): en ese caso
        # se CONSERVA la versión.
        if (
            bytes_added == 0
            and files_new == 0
            and files_changed == 0
            and snapshot_id
            and self._is_network_source(str(source))
        ):
            # Los orígenes de red no se pueden omitir escaneando el árbol
            # (restic backup --json corre siempre). Pero un snapshot "+0 B"
            # significa que el árbol NO cambió: restic creó un snapshot
            # redundante. Si ya existía una copia previa, se descarta esa
            # copia vacía y NO se crea versión (solo queda el registro en la
            # bitácora). Si es la primera copia del repo se conserva.
            prev_baseline = job.get("tree_hash") or ""
            if prev_baseline.startswith("snap:"):
                prev_id = prev_baseline.split(":", 1)[1]
                dropped = False
                try:
                    drop = self._restic(job, ["forget", snapshot_id], timeout=300)
                    dropped = drop.returncode == 0
                except Exception as error:
                    logger.warning(
                        "No se pudo descartar snapshot vacío %s: %s",
                        snapshot_id, error,
                    )
                if dropped:
                    job["tree_hash"] = f"snap:{prev_id}"
                    detail = "Respaldo ejecutado correctamente: sin cambios desde el último respaldo. No se creó versión."
                    self._finish_run(
                        job,
                        success=True,
                        message=detail,
                        started_at=started_at,
                        trigger=trigger,
                        snapshot_id=prev_id,
                        bytes_added=0,
                    )
                    self._enforce_retention_count(job)
                    return {
                        "success": True,
                        "skipped": True,
                        "message": detail,
                        "snapshot_id": prev_id,
                        "snapshot_short": prev_id[:12],
                        "bytes_processed": bytes_processed,
                        "bytes_human": _human_bytes(bytes_processed),
                        "bytes_added": 0,
                        "bytes_added_human": "0 B",
                        "pruned": False,
                    }
            else:
                job["tree_hash"] = f"snap:{snapshot_id}"
        elif snapshot_id and self._is_network_source(str(source)):
            # Versión real conservada (hubo archivos nuevos/cambiados aunque
            # restic reporte +0 B por deduplicación): fijar el baseline de red
            # al snapshot nuevo.
            job["tree_hash"] = f"snap:{snapshot_id}"

        job["source_missing_alerted"] = False

        detail = (
            f"OK  snapshot {snapshot_id[:12] if snapshot_id else 'n/a'} "
            f"+{_human_bytes(bytes_added)} nuevos · "
            f"{files_new} nuevos, {files_changed} modificados · "
            f"{_human_bytes(bytes_processed)} escaneados"
        )
        self._finish_run(
            job,
            success=True,
            message=detail,
            started_at=started_at,
            trigger=trigger,
            snapshot_id=snapshot_id,
            bytes_added=bytes_added,
        )

        self._enforce_retention_count(job)
        pruned = self._maybe_prune(job)

        return {
            "success": True,
            "snapshot_id": snapshot_id,
            "snapshot_short": snapshot_id[:12] if snapshot_id else None,
            "bytes_processed": bytes_processed,
            "bytes_human": _human_bytes(bytes_processed),
            "bytes_added": bytes_added,
            "bytes_added_human": _human_bytes(bytes_added),
            "pruned": pruned,
        }

    def list_snapshots(self, job_id: int) -> list[dict]:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            return []
        try:
            self._ensure_repo(job)
        except HTTPException:
            return []
        result = self._restic(job, ["snapshots", "--json"], timeout=120)
        if result.returncode != 0 and "lock" in (result.stderr or "").lower():
            # El repo puede estar bloqueado por otra operación en curso
            # (p. ej. `restic check` de mantenimiento). Reintentar una vez
            # para no mostrar "sin versiones" de forma falsa.
            time.sleep(3)
            result = self._restic(job, ["snapshots", "--json"], timeout=120)
        if result.returncode != 0:
            logger.warning(
                "list_snapshots: restic snapshots falló (job %s): %s",
                job_id, (result.stderr or "").strip()[:200],
            )
            return []
        try:
            rows = json.loads(result.stdout or "[]")
        except Exception as error:
            logger.debug("share_backup_service.list_snapshots: %s", error)
            rows = []
        snapshots = []
        for row in rows:
            summary = row.get("summary") or {}
            data_added = summary.get("data_added") or summary.get("total_bytes_added_packed") or 0
            snapshots.append({
                "id": row.get("id", ""),
                "short_id": row.get("short_id", ""),
                "time_iso": to_iso_utc(self._parse_restic_time(row.get("time"))),
                "time": (row.get("time") or "")[:19].replace("T", " "),
                "hostname": row.get("hostname"),
                "tags": row.get("tags") or [],
                "paths": row.get("paths") or [],
                "files_new": summary.get("files_new"),
                "files_changed": summary.get("files_changed"),
                "files_unmodified": summary.get("files_unmodified"),
                "data_added": data_added,
                "data_added_human": _human_bytes(data_added),
                "total_bytes_processed": summary.get("total_bytes_processed"),
                "total_bytes_human": _human_bytes(summary.get("total_bytes_processed")),
            })
        snapshots.sort(key=lambda s: s.get("time") or "", reverse=True)
        return snapshots

    def _parse_restic_time(self, value) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except Exception as error:
            logger.debug("share_backup_service._parse_restic_time: %s", error)
            try:
                return datetime.fromtimestamp(value)
            except Exception as error:
                logger.debug("share_backup_service._parse_restic_time: %s", error)
                return None

    def _normalize_times(self, value) -> str | None:
        """Acepta list[str] ['HH:MM','HH:MM'] o str 'HH:MM,HH:MM'.
        Normaliza y valida horas 00-23 y minutos 00-59. Devuelve
        None si no hay horas validas."""
        if value is None:
            return None
        if isinstance(value, str):
            raw = [t.strip() for t in (value or "").split(",")]
        else:
            raw = [str(t).strip() for t in value]
        hours = []
        for part in raw:
            if not part:
                continue
            try:
                hh, mm = part.split(":")
                hh = int(hh)
                mm = int(mm)
            except Exception as error:
                logger.debug("share_backup_service._normalize_times: %s", error)
                continue
            if 0 <= hh <= 23 and 0 <= mm <= 59:
                hours.append(f"{hh:02d}:{mm:02d}")
        hours = sorted(set(hours))
        return ",".join(hours) if hours else None

    def _times_list(self, job: Job) -> list:
        return schedule_time.times_list(job)

    def _parse_job_time(self, value) -> datetime | None:
        return schedule_time.parse_job_time(value)

    def _backoff_minutes(self, consecutive_failures: int) -> int:
        return schedule_time.backoff_minutes(
            consecutive_failures, FAILURE_BACKOFF_MINUTES
        )

    def _backoff_elapsed(self, job: Job, now: datetime) -> bool:
        return schedule_time.backoff_elapsed(
            job, now, FAILURE_BACKOFF_MINUTES
        )

    def is_due(self, job: Job, now: datetime) -> bool:
        return schedule_time.is_due(
            job,
            now,
            SCHEDULE_SLOT_TOLERANCE_MINUTES,
            FAILURE_BACKOFF_MINUTES,
        )

    def _tree_signature(self, root: Path) -> str | None:
        """Snapshot of (path, mtime, size) so on-change backups can detect edits.

        For network mounts (slow SMB/CIFS) this would rglob the whole tree
        and hang on D-state, so it returns None instead."""
        if self._is_network_source(str(root)):
            return None
        try:
            entries = []
            for path in sorted(root.rglob("*")):
                if path.is_dir():
                    continue
                stat = path.stat()
                rel = path.relative_to(root).as_posix()
                entries.append(f"{rel}:{stat.st_mtime_ns}:{stat.st_size}")
            return hashlib.sha256(
                "\n".join(entries).encode("utf-8", "replace")
            ).hexdigest()
        except OSError:
            return None

    def _maybe_run_on_change(self, job: Job) -> None:
        """Backup the source only when files changed since the last successful run."""
        if job.get("schedule_mode") != "on_change" or not job.get("enabled"):
            return
        source = Path(job.get("source_path") or "")
        if not source.is_dir():
            detail = "La ruta de origen no existe. No se pudo ejecutar el respaldo."
            if job.get("last_result") != detail:
                job["last_result"] = detail
                self._save_job(job)
            return

        signature = self._tree_signature(source)
        if signature is None:
            return
        if job.get("change_hash") is None:
            # First baseline: we don't run an unsolicited backup, we just
            # record the current state. From the next change on, we back up.
            job["change_hash"] = signature
            self._save_job(job)
            return
        if signature == job.get("change_hash"):
            return
        try:
            result = self.run_backup_job(job, trigger="on_change")
            # Solo adelantar el baseline si el respaldo REALMENTE se hizo:
            # antes esto corría sin mirar result["success"], así que un
            # fallo (mount roto, restic caído) igual "marcaba como
            # respaldado" el estado actual del árbol -- si después no
            # cambiaba nada más, esos cambios sin respaldar quedaban
            # huérfanos para siempre, sin que el sistema volviera a
            # intentarlo.
            if not result.get("success"):
                logger.warning(
                    "On-change backup %s failed, baseline not advanced: %s",
                    job.get("name"), result.get("message"),
                )
                return
            # Refresh the baseline right after a successful run so the same
            # tree is not backed up again on the next tick.
            fresh = self._tree_signature(source)
            if fresh is not None:
                job["change_hash"] = fresh
                self._save_job(job)
            state = result.get("message", result)
            logger.info("On-change backup %s: %s", job.get("name"), state)
        except HTTPException as error:
            logger.warning(
                "On-change backup %s failed: %s", job.get("name"), error.detail
            )

    def _enforce_retention_count(self, job: Job) -> None:
        """Recorta el listado de versiones a `retention_count` después de
        CADA respaldo exitoso -- no solo cuando el disco se queda sin
        espacio (eso lo sigue haciendo _maybe_prune, ver abajo).

        Antes, "conserva N versiones" solo se cumplía de forma reactiva:
        con disco de sobra, se podían acumular muchas más versiones de
        las que el usuario configuró, porque nada las recortaba hasta que
        el espacio libre bajara de prune_free_pct. `forget --keep-last`
        SIN `--prune` es barato (solo quita snapshots del listado, no
        reclama espacio en disco todavía) así que hacerlo tras cada
        corrida no tiene el costo de I/O de una poda completa.
        """
        retention = max(1, int(job.get("retention_count") or 7))
        try:
            result = self._restic(
                job, ["forget", "--keep-last", str(retention)], timeout=120
            )
            if result.returncode != 0 and "already locked" in (result.stderr or ""):
                # Lock restante del respaldo que recién terminó: se libera y
                # se reintenta una vez (robusto contra locks residuales).
                try:
                    self._restic(job, ["unlock"], timeout=60)
                except Exception as error:
                    logger.debug("share_backup_service._enforce_retention_count: %s", error)
                result = self._restic(
                    job, ["forget", "--keep-last", str(retention)], timeout=120
                )
            if result.returncode != 0:
                logger.warning(
                    "No se pudo aplicar la retención de %s versiones para "
                    "'%s': %s",
                    retention, job.get("name"), result.stderr.strip()[:300],
                )
        except Exception as error:
            logger.warning(
                "Error aplicando retención para '%s': %s", job.get("name"), error
            )

    def _maybe_prune(self, job: Job) -> dict | None:
        repo = self._repo_path(job)
        if not repo.parent.exists():
            return None
        usage = shutil.disk_usage(repo.parent)
        if not usage.total:
            return None
        free_pct = 100 * usage.free / usage.total
        if free_pct >= float(job.get("prune_free_pct") or 15):
            return None
        return self.prune(job.get("id"))

    def prune(self, job_id: int) -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        retention = max(1, int(job.get("retention_count") or 7))
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        forget = self._restic(job, ["forget", "--keep-last", str(retention), "--prune"], timeout=7200)
        if forget.returncode != 0:
            logger.error("restic forget/prune failed: %s", forget.stderr)
        usage = shutil.disk_usage(self._repo_path(job).parent)
        free_pct = round(100 * usage.free / usage.total, 1) if usage.total else 100.0
        detail = (
            f"Se conservan las {retention} versiones más recientes y se "
            f"compactó el repositorio. Espacio libre: {free_pct}%."
            if forget.returncode == 0
            else f"La limpieza no terminó bien: {forget.stderr.strip()[:300]}"
        )
        job["last_result"] = detail[:500]
        self._save_job(job)
        return {"success": forget.returncode == 0, "message": detail, "free_pct": free_pct}

    def list_files(self, job_id: int, snapshot_id: str, prefix: str = "") -> dict:
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"restic ls falló: {result.stderr.strip()[:300]}",
            )
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception as error:
            logger.debug("share_backup_service.list_files: %s", error)
            entries = []

        root = (job.get("source_path") or "/").rstrip("/")
        root_key = root.lstrip("/")
        prefix = (prefix or "").strip("/")
        base = prefix.split("/") if prefix else []
        folders: set[str] = set()
        files: list[dict] = []
        for entry in entries:
            rel = (entry.get("path") or "").lstrip("/")
            if root != "/":
                if rel == root_key:
                    continue
                if not rel.startswith(root_key + "/"):
                    continue
                rel = rel[len(root_key) + 1:]
            if not rel:
                continue
            parts = rel.split("/")
            if len(parts) != len(base) + 1:
                continue
            if parts[:len(base)] != base:
                continue
            item = parts[len(base)]
            full = f"{prefix}/{item}" if prefix else item
            if entry.get("type") == "dir":
                folders.add(item)
            else:
                files.append({
                    "name": item,
                    "path": full,
                    "size": entry.get("size"),
                    "size_human": _human_bytes(entry.get("size")),
                    "type": "file",
                })
            if len(folders) + len(files) > 3000:
                break

        def sort_key(item):
            return (item.get("name") or "").lower()

        return {
            "snapshot": snapshot_id,
            "prefix": prefix,
            "directories": sorted(folders, key=str.lower),
            "files": sorted(files, key=sort_key),
        }

    def _entry_is_dir(self, job: Job, snapshot_id: str, path: str) -> bool:
        result = self._restic(job, ["ls", "--json", snapshot_id], timeout=600)
        if result.returncode != 0:
            return False
        try:
            entries = self._parse_ndjson(result.stdout)
        except Exception as error:
            logger.debug("share_backup_service._entry_is_dir: %s", error)
            return False
        root = (job.get("source_path") or "/").rstrip("/")
        wanted = "/".join([
            seg for seg in [root, path.strip("/")] if seg.strip("/")
        ])
        for entry in entries:
            if (entry.get("path") or "").rstrip("/") == wanted.rstrip("/"):
                return entry.get("type") == "dir"
        return False

    @staticmethod
    def _parse_ndjson(stdout: str) -> list[dict]:
        rows = []
        for line in (stdout or "").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as error:
                logger.debug("share_backup_service._parse_ndjson: %s", error)
                continue
        return rows

    def _latest_snapshot_id(self, job: Job) -> str | None:
        """Id del snapshot más reciente del repo (para omitir sin cambios)."""
        try:
            result = self._restic(job, ["snapshots", "--json"], timeout=60)
            if result.returncode != 0:
                logger.warning(
                    "_latest_snapshot_id: restic snapshots falló (job %s): %s",
                    job.get("id"), (result.stderr or "").strip()[:200],
                )
                return None
            data = json.loads(result.stdout or "[]")
            if isinstance(data, list) and data:
                ids = [
                    s.get("id") or s.get("short_id")
                    for s in data
                    if isinstance(s, dict) and (s.get("id") or s.get("short_id"))
                ]
                return ids[-1] if ids else None
            return None
        except Exception as error:
            logger.debug("share_backup_service._latest_snapshot_id: %s", error)
            return None

    def _snapshot_restore_size(self, job: Job, snapshot_id: str) -> int | None:
        """Tamaño de restauración (descomprimido) de un snapshot, en bytes.

        Se usa para verificar que el destino tenga espacio antes de
        restaurar. Devuelve None si no se pudo calcular (no bloquea).
        """
        if not snapshot_id:
            return None
        try:
            result = self._restic(
                job,
                ["stats", "--mode", "restore-size", snapshot_id],
                timeout=300,
            )
            if result.returncode != 0:
                return None
            import re as _re
            m = _re.search(r"Total Size:\s*([\d.]+)\s*([TGMK]?i?B)", result.stdout or "")
            if not m:
                return None
            val = float(m.group(1))
            unit = m.group(2).upper()
            mult = {
                "TIB": 1024**4, "TI": 1024**4, "TB": 10**12,
                "GIB": 1024**3, "GI": 1024**3, "GB": 10**9,
                "MIB": 1024**2, "MI": 1024**2, "MB": 10**6,
                "KIB": 1024, "KI": 1024, "KB": 10**3,
                "B": 1,
            }
            return int(val * mult.get(unit, 1024**3))
        except Exception as error:
            logger.debug("share_backup_service._snapshot_restore_size: %s", error)
            return None

    def _find_restored_root(self, staging: Path, source: str) -> Path | None:
        """Localiza la raíz real del contenido restaurado dentro de `staging`.

        restic restaura cuelga la ruta absoluta del snapshot bajo `--target`,
        por lo que dentro del staging puede aparecer
        `mnt/stepad-network/M/...`. Para dejar los archivos PLANOS en el
        destino, se busca la subcarpeta que corresponde al `source` original
        (o la más profunda con contenido) y se devuelve esa raíz."""
        if not staging.exists():
            return None
        try:
            wanted = str(Path(source)).rstrip("/").lstrip("/")
            parts = [p for p in wanted.split("/") if p]
        except Exception as error:
            logger.debug("share_backup_service._find_restored_root: %s", error)
            parts = []
        # Buscar el nodo staging/.../source
        cur = staging
        for part in parts:
            nxt = cur / part
            if not nxt.exists():
                break
            cur = nxt
        if cur != staging and cur != Path(staging) and cur.exists():
            return cur
        # Fallback: la subcarpeta de staging que tenga contenido.
        try:
            children = [c for c in staging.iterdir()]
            inner = [c for c in children if c.is_dir()]
            if len(inner) == 1:
                cand2 = inner[0]
                # si la subcarpeta interna es el arbol real (tiene files)
                if any(f.is_file() for f in cand2.iterdir()):
                    return cand2
        except Exception as error:
            logger.debug("share_backup_service._find_restored_root: %s", error)
        return None

    def restore_snapshot(
        self,
        job_id: int,
        snapshot_id: str,
        *,
        target: str | None = None,
        clean: bool = False,
    ) -> dict:
        """
        Restaura COMPLETA una versión (snapshot) del respaldo a su
        carpeta origen (o a un `target` que el usuario elija), con la
        estructura de carpetas tal cual quedó en esa foto.

        En desastre, la restauración se hace por la vía más rápida:
          - target vacío → restic escribe DIRECTAMENTE en la ruta
            absoluta original (`--target /`); una sola copia, sin
            staging intermedio.
          - target dado → restaura a staging y copia/mueve ahí (por si
            el árbol debe ir a otra raíz).

        `clean=True` vacía el destino ANTES de restaurar (restauración
        "limpia": el destino queda idéntico a la foto, sin archivos
        sobrantes). Por seguridad solo se aplica al destino elegido,
        nunca a rutas del sistema.
        """
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        if not snapshot_id:
            raise HTTPException(status_code=400, detail="Indica el snapshot a restaurar.")

        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))

        source = (job.get("source_path") or "").strip()
        if not source:
            raise HTTPException(status_code=400, detail="El respaldo no tiene origen.")

        # Destino final: el indicado o la carpeta origen del respaldo.
        destination = Path((target or source).strip() or source).resolve()
        if not str(destination).startswith(("/mnt/", "/media/", "/tmp/")):
            raise HTTPException(
                status_code=400,
                detail="El destino de restauración debe estar bajo /mnt, /media o /tmp.",
            )

        # Montar el destino por demanda: puede ser una partición privada,
        # compartida, de respaldo o una unidad remota/USB, que esté
        # DESMONTADA. Sin esto, restic escribiría en un path sin monte y la
        # restauración no deja nada. Se monta el volumen cuyo mountpoint
        # contiene al destino; si no está registrado, se intenta igual (el
        # directorio debe ser escribible).
        try:
            from backend.shares.models.network_share_volume import NetworkShareVolume
            db_vol = SessionLocal()
            try:
                dest_vol = None
                dest_str = str(destination).rstrip("/")
                for volume in db_vol.query(NetworkShareVolume).all():
                    mp = str(getattr(volume, "mountpoint", "") or "").rstrip("/")
                    if mp and (dest_str == mp or dest_str.startswith(mp + "/")):
                        dest_vol = volume
                        break
            finally:
                db_vol.close()
            if dest_vol is not None:
                # Regla: el destino puede ser CUALQUIER unidad disponible
                # (privada, compartida, USB, red) EXCEPTO una partición de
                # respaldo (donde viven los repos) ni el disco del sistema.
                if (getattr(dest_vol, "purpose", "") or "") == "backup":
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            f"«{dest_vol.name}» es una partición de RESPALDO; "
                            "no puede usarse como destino de restauración. "
                            "Elige otra unidad (privada, USB, compartida o red)."
                        ),
                    )
                from backend.shares.providers.share_disk_mount_provider import (
                    ShareDiskMountProvider,
                )
                provider = ShareDiskMountProvider()
                if not provider.is_mounted_at(dest_vol.mountpoint):
                    mr = provider.mount_now(
                        uuid=dest_vol.device_uuid,
                        device_path=getattr(dest_vol, "device_path", None),
                        mountpoint=dest_vol.mountpoint,
                    )
                    if not mr.get("success"):
                        raise HTTPException(
                            status_code=400,
                            detail=(
                                f"No se pudo montar la unidad destino "
                                f"«{dest_vol.name}» para restaurar: "
                                f"{mr.get('message')}"
                            ),
                        )
        except HTTPException:
            raise
        except Exception as error:
            logger.warning("restore_snapshot: no pude montar destino: %s", error)

        # Invariante: la restauración NUNCA toca el disco del sistema. Se
        # evalúa DESPUÉS del montaje por demanda (una partición registrada
        # desmontada vive como directorio sobre la raíz hasta montarse; con
        # ella ya montada el destino resuelve a su dispositivo real). Si el
        # destino sigue siendo un directorio suelto sobre el disco del sistema
        # (partición no registrada / no montada), se cancela en vez de escribir
        # silenciosamente al disco del sistema.
        from backend.shares.services.disk_guard import ensure_restore_destination_safe
        ensure_restore_destination_safe(str(destination))

        # Verificar que el destino tenga espacio suficiente para el tamaño de
        # restauración del snapshot (descomprimido). El destino puede ser una
        # unidad privada, compartida, remota montada o un USB.
        try:
            needed = self._snapshot_restore_size(job, snapshot_id)
        except Exception as error:
            logger.debug("share_backup_service.restore_snapshot: %s", error)
            needed = None
        if needed is not None and needed > 0:
            try:
                free = shutil.disk_usage(destination).free
            except OSError:
                free = None
            if free is not None and needed > free:
                import humanize as _hu  # noqa
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"El destino «{destination}» no tiene espacio suficiente. "
                        f"Se necesitan {_human_bytes(int(needed))} para restaurar "
                        f"la versión {snapshot_id[:12]} y el destino tiene "
                        f"{_human_bytes(int(free))} libres."
                    ),
                )

        # Seguridad sobre el destino. Dos casos:
        #  - Restaurar AL ORIGEN del respaldo (mismo punto de montaje): es el
        #    escenario de DESASTRE (disco origen dañado y reemplazado por uno
        #    vacío). Permitido si el origen está VACÍO (disco nuevo) o con
        #    `clean=True` (reescritura explícita de los originales).
        source_root = str(Path(source).resolve()).rstrip("/")
        dest_root = str(destination.resolve()).rstrip("/")
        is_origin = bool(
            source_root
            and (
                dest_root == source_root
                or dest_root.startswith(source_root + "/")
                or source_root.startswith(dest_root + "/")
            )
        )
        if is_origin:
            # `lost+found` no es dato del usuario (viene con el formateo ext4):
            # una unidad recién creada está VACÍA aunque tenga lost+found.
            if not clean and destination.exists() and any(
                x for x in destination.iterdir() if x.name != "lost+found"
            ):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"El destino «{destination}» es el ORIGEN del respaldo "
                        "y aún contiene archivos. Restaurar ahí sobrescribiría "
                        "los originales. Si reemplazaste el disco origen por uno "
                        "vacío, elige ESE origen; si querés reescribirlo igual, "
                        "usa la restauración limpia (clean)."
                    ),
                )
        else:
            # Destino distinto del origen: debe estar vacío (o clean).
            if not clean and destination.exists() and any(
                x for x in destination.iterdir() if x.name != "lost+found"
            ):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"El destino «{destination}» no está vacío. Para restaurar "
                        "elige una unidad/carpeta vacía (o usa la restauración "
                        "limpia si ya lo confirmaste)."
                    ),
                )

        if clean and destination.exists():
            # Vacía el destino (mantiene la carpeta raíz) ANTES de restaurar.
            for item in destination.iterdir():
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                else:
                    try:
                        item.unlink()
                    except OSError:
                        pass


        # Ejecutar en BACKGROUND: la restauración de decenas/cientos de GB
        # puede tardar mucho; la UI consulta el progreso (restic --json
        # reporta message_type "restore") y el resultado cuando termina.
        self._restore_status[job_id] = {
            "running": True,
            "error": None,
            "result": {
                "restore_to": str(destination),
            },
        }
        # Bitácora persistente: si el proceso muere (reinicio/apagón), esto
        # permite al sistema marcar la restauración como 'interrumpida' y
        # ofrecer Reintentar/Limpiar.
        self._upsert_restore_ledger(
            job_id,
            status="running",
            snapshot_id=str(snapshot_id),
            destination=str(destination),
            started_at=now_ecuador().isoformat(),
            finished_at=None,
            error=None,
            staging_cleaned=False,
        )

        def _run():
            try:
                # Vía rápida (desastre): origen original -> escribir en la
                # ruta exacta. restic cuelga la ruta absoluta bajo target;
                # con "/" queda tal cual era.
                if not target:
                    result = self._restic(
                        job,
                        ["restore", snapshot_id, "--target", "/", "--json"],
                        timeout=86400,
                    )
                    message = (
                        f"Versión {snapshot_id[:12]} restaurada directamente "
                        f"en «{destination}» con su estructura original."
                    )
                else:
                    # Restauración a un destino ELEGIDO: los archivos deben
                    # quedar PLANOS en la raíz de ese destino (sin el prefijo
                    # anidado /mnt/.../<origen>/). restic siempre cuelga la
                    # ruta absoluta del snapshot bajo `--target`. Para
                    # evitarlo se restaura a un staging TEMPORAL DENTRO del
                    # propio destino (mismo filesystem) y al terminar se
                    # mueve (rename) el contenido real a la RAÍZ del destino.
                    # El staging es oculto, no queda a la vista como "mnt".
                    destination.mkdir(parents=True, exist_ok=True)
                    staging = destination / ".stepad-restore.tmp"
                    try:
                        if staging.exists():
                            shutil.rmtree(staging, ignore_errors=True)
                        staging.mkdir(parents=True, exist_ok=True)
                        result = self._restic(
                            job,
                            [
                                "restore", snapshot_id,
                                "--target", str(staging),
                                "--json",
                            ],
                            timeout=86400,
                        )
                        if result.returncode != 0:
                            err = (result.stderr or "").strip()[:500]
                            self._restore_status[job_id] = {
                                "running": False,
                                "error": f"restic restore falló: {err}",
                                "result": None,
                            }
                            return

                        # Aplanar a la RAÍZ: mover el contenido real del
                        # staging (bajo staging/mnt/.../<origen>/) a
                        # destination/. Rename (mismo FS) => instantáneo.
                        source_tree = self._find_restored_root(staging, source)
                        base = source_tree if source_tree is not None else staging
                        restored_any = False
                        for item in list(base.iterdir()):
                            dst = destination / item.name
                            if dst.exists():
                                if dst.is_dir() and not dst.is_symlink():
                                    shutil.rmtree(dst, ignore_errors=True)
                                else:
                                    try:
                                        dst.unlink()
                                    except OSError:
                                        pass
                            try:
                                os.replace(item, dst)
                            except OSError:
                                if item.is_dir():
                                    shutil.copytree(item, dst, dirs_exist_ok=True)
                                    shutil.rmtree(item, ignore_errors=True)
                                else:
                                    shutil.copy2(item, dst)
                                    try:
                                        item.unlink()
                                    except OSError:
                                        pass
                            restored_any = True
                        if not restored_any:
                            self._restore_status[job_id] = {
                                "running": False,
                                "error": "El snapshot no contenía archivos para restaurar.",
                                "result": None,
                            }
                            return
                        message = (
                            f"Versión {snapshot_id[:12]} restaurada en "
                            f"«{destination}» (archivos en la raíz del destino)."
                        )
                    except Exception as error:
                        logger.debug("share_backup_service._run: %s", error)
                        self._restore_status[job_id] = {
                            "running": False,
                            "error": str(error),
                            "result": None,
                        }
                        return
                    finally:
                        # Limpiar el staging temporal (oculto) del destino.
                        try:
                            shutil.rmtree(staging, ignore_errors=True)
                        except Exception as error:
                            logger.debug("share_backup_service._run: %s", error)
                if result.returncode != 0:
                    err = (result.stderr or "").strip()[:500]
                    self._restore_status[job_id] = {
                        "running": False,
                        "error": f"restic restore falló: {err}",
                        "result": None,
                    }
                    return
                self._restore_status[job_id] = {
                    "running": False,
                    "error": None,
                    "result": {
                        "success": True,
                        "job_id": job_id,
                        "snapshot_id": snapshot_id,
                        "restore_to": str(destination),
                        "message": message,
                    },
                }
            except Exception as error:
                logger.debug("share_backup_service._run: %s", error)
                self._restore_status[job_id] = {
                    "running": False,
                    "error": str(error),
                    "result": None,
                }
            finally:
                self._progress.pop(job_id, None)
                # Cerrar la bitácora persistente según el resultado real.
                final = (self._restore_status or {}).get(job_id) or {}
                if not final.get("running"):
                    result = final.get("result") or {}
                    if final.get("error"):
                        status = "failed"
                    elif result.get("success"):
                        status = "completed"
                    else:
                        status = "interrupted"
                    self._upsert_restore_ledger(
                        job_id,
                        status=status,
                        error=final.get("error"),
                        message=result.get("message"),
                        pid=None,
                        finished_at=now_ecuador().isoformat(),
                    )
                    # La restauración también entra al HISTORIAL CRONOLÓGICO del
                    # job (junto a los respaldos), con su estado y destino.
                    try:
                        hmsg = (
                            result.get("message")
                            or final.get("error")
                            or "Restauración interrumpida."
                        )
                        self._append_history(
                            job,
                            success=(status == "completed"),
                            message=hmsg,
                            bytes_added=0,
                            trigger="restore",
                            snapshot_id=snapshot_id,
                        )
                        self._save_job(job)
                    except Exception as error:
                        logger.warning(
                            "No se pudo registrar la restauración en el historial: %s",
                            error,
                        )

        import threading as _th2
        t = _th2.Thread(target=_run, daemon=True)
        t.start()

        return {
            "success": True,
            "running": True,
            "job_id": job_id,
            "snapshot_id": snapshot_id,
            "restore_to": str(destination),
            "message": (
                f"Restauración de la versión {snapshot_id[:12]} iniciada "
                f"en «{destination}». Se está ejecutando en segundo plano."
            ),
        }

    def restore_status(self, job_id: int) -> dict:
        """Estado de la restauración en curso/reciente (para polling de la UI)."""
        st = self._restore_status.get(int(job_id or 0)) or {
            "running": False, "error": None, "result": None,
        }
        st = dict(st)
        prog = dict(self._progress.get(int(job_id or 0)) or {})
        # restic NO emite files_done/bytes_done durante `restore --json`
        # (solo percent_done). Para que la barra muestre datos reales se
        # usa el espacio ocupado del filesystem destino (statvfs, inmediato;
        # NO hay que recorrer el árbol de archivos, eso colgaba el backend).
        if st.get("running"):
            dest = str((st.get("result") or {}).get("restore_to") or "")
            if dest:
                try:
                    p = Path(dest)
                    if p.exists():
                        stv = os.statvfs(dest)
                        used = (stv.f_blocks - stv.f_bfree) * stv.f_frsize
                        if used:
                            prog["bytes_done"] = used
                except Exception as error:
                    logger.debug("share_backup_service.restore_status: %s", error)
        # Progreso REAL: la barra muestra bytes escritos del destino vs el
        # tamaño total de esa versión (restic restore no emite % confiable);
        # así nunca queda en 0% mientras avanza.
        if st.get("running") and prog.get("bytes_done"):
            needed = None
            try:
                led = (self._load_restore_ledger().get("restores") or {}).get(
                    str(int(job_id or 0))
                ) or {}
                snapshot_id = led.get("snapshot_id") or None
                job = self._find_job(int(job_id or 0))
                if job is not None and snapshot_id:
                    needed = self._snapshot_restore_size(job, snapshot_id)
            except Exception as error:
                logger.debug("share_backup_service.restore_status: %s", error)
                needed = None
            if needed and needed > 0:
                prog["bytes_total"] = needed
                prog["percent"] = round(
                    min(100.0, 100.0 * prog["bytes_done"] / needed), 1
                )
        st["progress"] = prog
        # Enriquecer con la bitácora persistente: permite mostrar estado tras
        # un reinicio (interrumpida) y datos para Reintentar/Limpiar.
        try:
            self.reconcile_restores()
            entry = self._load_restore_ledger()["restores"].get(
                str(int(job_id or 0))
            ) or {}
        except Exception as error:
            logger.debug("share_backup_service.restore_status: %s", error)
            entry = {}
        if entry:
            st.setdefault("status", entry.get("status"))
            for key in (
                "snapshot_id", "destination", "started_at", "updated_at",
                "finished_at", "message",
            ):
                if entry.get(key) is not None and not st.get(key):
                    st[key] = entry.get(key)
            if not st.get("error"):
                st["error"] = entry.get("error")
            st["interrupted"] = entry.get("status") == "interrupted"
            dest = str(entry.get("destination") or "")
            st["staging_left"] = bool(
                dest and (Path(dest) / ".stepad-restore.tmp").exists()
            )
        else:
            st["interrupted"] = False
            st["staging_left"] = False
        st.setdefault("status", "running" if st.get("running") else "idle")
        return st

    def active_restore(self) -> dict | None:
        """Devuelve la restauración en curso globalmente (para el indicador
        persistente de la UI), o None si no hay ninguna. Incluye el progreso
        real (con bytes escritos en el destino)."""
        try:
            for job_id, st in (self._restore_status or {}).items():
                if st and st.get("running"):
                    status = self.restore_status(job_id)
                    return {"job_id": int(job_id or 0), "status": status}
            return None
        except Exception as error:
            logger.debug("share_backup_service.active_restore: %s", error)
            return None

    def download_whole(self, job_id: int, snapshot_id: str):
        """Devuelve un GENERATOR que transmite el .tar del snapshot completo
        por chunks (streaming), de modo que el navegador recibe la descarga
        mientras restic la genera — sin cargar todo el tar en memoria.

        Evita saturar: si hay un respaldo/restauración en curso, NO arranca
        (la descarga compite por CPU/disco con el backup y puede ahogar la
        máquina — fue lo que pasó). Devuelve 409 para que la UI avise."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        # Anti-solapamiento: no generar el tar mientras hay un respaldo o
        # restauración en curso (evita el ahogo con el backup).
        try:
            if getattr(self, "_running_jobs", None):
                for other in self._running_jobs:
                    if int(other or 0) != int(job_id or 0):
                        raise HTTPException(
                            status_code=409,
                            detail=(
                                "Hay un respaldo en curso. Espera a que "
                                "termine para descargar el archivo (compiten "
                                "por disco/CPU y pueden ahogar el sistema)."
                            ),
                        )
            if getattr(self, "_restore_status", None):
                for _rid, rst in self._restore_status.items():
                    if rst and rst.get("running"):
                        raise HTTPException(
                            status_code=409,
                            detail=(
                                "Hay una restauración en curso. Espera a "
                                "que termine para descargar el archivo."
                            ),
                        )
        except HTTPException:
            raise
        except Exception as error:
            logger.debug("share_backup_service.download_whole: %s", error)
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        root = (job.get("source_path") or "/").rstrip("/")
        repo = str(self._repo_path(job))

        def _stream():
            proc = subprocess.Popen(
                self._restic_cmd(repo, [
                    "dump", "--archive=tar", snapshot_id, root]),
                env=self._env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=1024 * 1024,
            )
            yield from self._tar_strip_stream(proc.stdout, root)
            proc.stdout.close()
            proc.wait()
            if proc.returncode != 0:
                err = (proc.stderr.read() or b"")[:300]
                logger.error("restic dump(stream) falló: %s", err.decode(errors="replace"))
            if proc.stderr:
                proc.stderr.close()

        return _stream()

    def download(self, job_id: int, snapshot_id: str, path: str):
        """Devuelve (is_dir, generador) para STREAMING de una entrada del
        snapshot (archivo o carpeta). Las carpetas se bajan como .tar con la
        raíz APLANADA: el tar NO lleva los paths absolutos del origen
        (mnt/stepad-network/M/...), sino solo el contenido relativo a la
        carpeta elegida — tal como quedaría en tu disco sin carpetas extra.
        Se transmite en vivo (sin cargar el tar completo en memoria)."""
        job = self._find_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Respaldo no encontrado.")
        if not self.installed():
            raise HTTPException(status_code=400, detail="restic no está instalado.")
        try:
            self._ensure_repo(job)
        except HTTPException as error:
            raise HTTPException(status_code=500, detail=str(error.detail))
        root = (job.get("source_path") or "/").rstrip("/")
        rel = path.strip("/")
        if not rel:
            # Descargar la RAÍZ (todo el snapshot) está deshabilitado: satura
            # CPU/disco/memoria y fue causa de bloqueos. Se usa un archivo o
            # una carpeta específica.
            raise HTTPException(
                status_code=403,
                detail=(
                    "Descargar la raíz completa del snapshot fue deshabilitado. "
                    "Elegí un archivo o una carpeta específica en «Explorar y descargar»."
                ),
            )
        abs_path = f"{root}/{rel}" if rel else root
        is_dir = self._entry_is_dir(job, snapshot_id, path)
        repo = str(self._repo_path(job))

        def _stream():
            if not is_dir:
                args = ["dump", snapshot_id, abs_path]
                proc = subprocess.Popen(
                    self._restic_cmd(repo, args),
                    env=self._env(),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    bufsize=1024 * 1024,
                )
                while True:
                    chunk = proc.stdout.read(1024 * 1024)
                    if not chunk:
                        break
                    yield chunk
                proc.stdout.close()
                proc.wait()
                if proc.returncode != 0:
                    err = (proc.stderr.read() or b"").decode(errors="replace")[:300]
                    logger.error("restic dump(entry) falló: %s", err)
                return

            # CARPETA: restic dump genera el .tar rápido (streaming del repo, sin
            # restaurar de más). Los nombres van con la ruta absolute del
            # origen (mnt/...). Se reescribe sobre el MISMO archivo temporal
            # en DISCO REAL (tarfile maneja PAX/GNU y acentos), quitando la
            # raíz: la carpeta elegida queda como raíz del .tar.
            # NO se usa /tmp (tmpfs RAM chica): staging en la primera bóveda
            # local (ej. sda1) que tiene espacio real.
            try:
                local_vaults = [
                    v for v in self._vaults() if "/stepad-network/" not in str(v)
                ]
                staging_base = local_vaults[0] if local_vaults else None
            except Exception as error:
                logger.debug("share_backup_service._stream: %s", error)
                staging_base = None
            if staging_base is None:
                logger.error("download(dir): sin bóveda local para staging")
                return
            staging_base.mkdir(parents=True, exist_ok=True)
            tmp_path = Path(staging_base) / f".stepad-dl-{snapshot_id[:8]}-{time.time_ns()}.tar"
            try:
                dump = subprocess.run(
                    self._restic_cmd(repo, ["dump", "--archive=tar",
                                            snapshot_id, abs_path]),
                    env=self._env(),
                    capture_output=True,
                    timeout=86400,
                )
                if dump.returncode != 0:
                    err = (dump.stderr or b"").decode(errors="replace")[:300]
                    logger.error("dump(dir) falló: %s", err)
                    return
                raw = dump.stdout
                if not raw:
                    return
                # Reescribir el tar quitando la raíz (mnt/stepad-network/M)
                import tarfile as _tarfile2
                root_key = root.lstrip("/")
                reader = _tarfile2.open(fileobj=io.BytesIO(raw), mode="r")
                writer = _tarfile2.open(tmp_path, mode="w:")
                try:
                    for member in reader:
                        name = member.name.lstrip("/")
                        if name == root_key:
                            newname = "."
                        elif name.startswith(root_key + "/"):
                            newname = name[len(root_key) + 1:]
                        else:
                            continue
                        if not newname:
                            newname = "."
                        member.name = newname
                        # Limpiar el path del PAX header (nombres largos con
                        # acentos): si queda, tarfile reescribe el path
                        # ORIGINAL (con mnt/...) y sobrescribe el nuevo.
                        _pax = getattr(member, "pax_headers", None)
                        if _pax:
                            _pax.pop("path", None)
                            _pax.pop("linkpath", None)
                        data = reader.extractfile(member)
                        writer.addfile(member, data)
                finally:
                    reader.close()
                    writer.close()
                # Reemitir el resultado en chunks
                with open(tmp_path, "rb") as fh:
                    while True:
                        chunk = fh.read(1024 * 1024)
                        if not chunk:
                            break
                        yield chunk
            except Exception as error:
                logger.error("download(dir) falló: %s", error)
            finally:
                try:
                    Path(tmp_path).unlink(missing_ok=True)
                except Exception as error:
                    logger.debug("share_backup_service._stream: %s", error)
        return is_dir, _stream()

    @staticmethod
    def _tar_strip_stream(src, root):
        """Re-emite el TAR de `src` (file-like binario) con nombres APLANADOS:
        sin el prefijo del origen (mnt/stepad-network/M), de modo que la
        carpeta descargada queda como raíz del .tar. Streaming real: un hilo
        lee/reescribe (tarfile maneja PAX/GNU/xattrs) y un pipe alimenta al
        generador — el navegador recibe mientras se arma, sin cargar nada en
        memoria."""
        import tarfile as _tarfile
        read_fd, write_fd = os.pipe()

        def _producer():
            try:
                with os.fdopen(write_fd, "wb", 0) as sink:
                    with _tarfile.open(fileobj=src, mode="r|") as tin:
                        with _tarfile.open(fileobj=sink, mode="w|") as tout:
                            for member in tin:
                                name = member.name
                                if name == root:
                                    newname = ""
                                elif name.startswith(root + "/"):
                                    newname = name[len(root) + 1:]
                                else:
                                    # directorios intermedios (mnt/,
                                    # mnt/stepad-network/): descartar
                                    continue
                                newname = newname.lstrip("/")
                                if not newname and member.isdir():
                                    newname = "."
                                member.name = newname or "."
                                data = tin.extractfile(member)
                                tout.addfile(member, data)
            except Exception as error:  # noqa: BLE001
                logger.warning("_tar_strip_stream: %s", error)
            finally:
                try:
                    os.close(write_fd)
                except OSError:
                    pass

        thread = threading.Thread(target=_producer, daemon=True)
        thread.start()

        try:
            with os.fdopen(read_fd, "rb", 0) as reader:
                while True:
                    chunk = reader.read(1024 * 1024)
                    if not chunk:
                        break
                    yield chunk
        finally:
            thread.join(timeout=5)

    # ------------------------------------------------------------------
    # reconciliation (config file is the source of truth; raise alert when
    # the source folder disappears)
    # ------------------------------------------------------------------

    def _reconcile(self, db: Session) -> None:
        for job in self._all_jobs():
            self._reconcile_job_source(db, job)
            self._reconcile_job_destination(db, job)
        self._gc_orphan_repos()

    def _reconcile_job_source(self, db: Session, job: Job) -> None:
        """Levanta una alerta cuando la carpeta origen ya no existe y la
        resuelve cuando vuelve a estar disponible."""
        source = Path(job.get("source_path") or "")
        missing = not self._dir_live(source)
        flagged = bool(job.get("source_missing_alerted"))

        if missing and not flagged:
            job["source_missing_alerted"] = True
            self._save_job(job)
            title = f"Origen de respaldo no encontrado: {job.get('name')}"
            message = (
                f"El respaldo «{job.get('name')}» no pudo comprobar su carpeta "
                f"de origen ({job.get('source_path')}). La carpeta o unidad no "
                f"está montada; el respaldo queda a la espera hasta que el "
                f"origen vuelva a estar disponible."
            )
            try:
                db.rollback()
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type=SOURCE_MISSING_ALERT,
                    severity="warning",
                    title=title,
                    message=message[:500],
                )
                db.commit()
                logger.warning("Alerta: %s", title)
            except Exception as error:
                logger.warning("Could not create source-missing alert: %s", error)
            return

        if not missing and flagged:
            job["source_missing_alerted"] = False
            self._save_job(job)
            logger.info("Origen de respaldo restaurado: %s", job.get("name"))

    def _reconcile_job_destination(self, db: Session, job: Job) -> None:
        """Levanta una alerta cuando el destino del respaldo no está disponible
        (ej: USB desconectado) y la resuelve cuando vuelve a estar disponible."""
        dest = Path(str(job.vault or self._dest_folder(job.get("source_path") or "")))
        dest_parent = dest.parent
        missing = not self._dir_live(dest_parent)
        flagged = bool(job.get("dest_missing_alerted"))

        if missing and not flagged:
            job["dest_missing_alerted"] = True
            self._save_job(job)
            title = f"Destino de respaldo no disponible: {job.get('name')}"
            message = (
                f"El respaldo «{job.get('name')}» no puede ejecutarse porque "
                f"el destino ({dest_parent}) no está disponible. "
                f"Verifique que el disco/USB esté conectado y montado."
            )
            try:
                db.rollback()
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type="BACKUP_DEST_MISSING",
                    severity="warning",
                    title=title,
                    message=message[:500],
                )
                db.commit()
                logger.warning("Alerta: %s", title)
            except Exception as error:
                logger.warning("Could not create dest-missing alert: %s", error)
            return

        if not missing and flagged:
            job["dest_missing_alerted"] = False
            self._save_job(job)
            logger.info("Destino de respaldo restaurado: %s", job.get("name"))

    def _gc_orphan_repos(self) -> None:
        """Elimina repositorios que ya no pertenecen a ningún job."""
        expected = {self._repo_path(job) for job in self._all_jobs()}
        for repo in self._repositories():
            if repo in expected:
                continue
            try:
                shutil.rmtree(repo)
                logger.info("Se eliminó un repositorio huérfano: %s", repo)
            except OSError as error:
                logger.warning(
                    "No se pudo eliminar el repositorio huérfano %s: %s",
                    repo,
                    error,
                )

    # ------------------------------------------------------------------
    # scheduler
    # ------------------------------------------------------------------

    def start_scheduler(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop = False
            self._thread = threading.Thread(
                target=self._loop,
                name="share-backup-scheduler",
                daemon=True,
            )
            self._thread.start()
            logger.info("Share backup scheduler started.")
        # Limpieza de QoS residual al arrancar: si un respaldo fue cortado a la
        # fuerza (reboot/kill) el shaper pudo quedar aplicado; se quita acá
        # (best-effort, firmado para no tocar configs ajenas).
        try:
            net_rate_shaper.cleanup_stale()
        except Exception as error:
            logger.warning("net_rate_shaper.cleanup_stale: %s", error)

    def stop_scheduler(self) -> None:
        self._stop = True
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=5)
        self._thread = None
        logger.info("Share backup scheduler stopped.")

    def _loop(self) -> None:
        for _ in range(4):
            if self._stop:
                return
            time.sleep(1)
        try:
            # Migración one-shot de ids duplicados (véase _ensure_unique_job_ids).
            self._ensure_unique_job_ids()
        except Exception:
            logger.exception("share-backup-scheduler: renumeración de ids falló")
        try:
            self._backfill_network_baselines()
        except Exception:
            logger.exception("share-backup-scheduler: backfill baselines falló")
        while not self._stop:
            try:
                self._tick()
            except Exception as error:
                logger.exception("Share backup tick failed: %s", error)
            for _ in range(POLL_SECONDS):
                if self._stop:
                    return
                time.sleep(1)

    def _backfill_network_baselines(self) -> None:
        """Auto-baseline para orígenes de red.

        Si un job de red quedó con tree_hash = None (p. ej. por una versión
        anterior que no lo fijaba) pero el repo ya tiene un snapshot previo,
        se fija \"snap:<id>\" como baseline. Así el primer horario sin
        cambios se omite y NO se crea una versión vacía, sin intervención
        manual (esto aplica al arrancar cada máquina tras actualizar)."""
        try:
            for job in self._all_jobs():
                src = str(job.get("source_path") or "")
                if not self._is_network_source(src):
                    continue
                if (job.get("tree_hash") or "").startswith("snap:"):
                    continue
                latest = self._latest_snapshot_id(job)
                if latest:
                    job["tree_hash"] = f"snap:{latest}"
                    self._save_job(job)
                    logger.info(
                        "Baseline de red auto-fijado para '%s' (snap:%s) — "
                        "el próximo horario sin cambios se omitirá.",
                        job.get("name"), latest[:12],
                    )
        except Exception as error:
            logger.warning("_backfill_network_baselines: %s", error)

    # ------------------------------------------------------------------
    # Mantenimiento dinámico por job (check integridad + test restauración)
    # ------------------------------------------------------------------

    def _maintenance_due(self, job: Job, kind: str, now: datetime) -> bool:
        """¿Corres ejecutar hoy el mantenimiento `kind` (check/test_restore)?

        Dinámico por job: cada job define su intervalo (días) y guarda su
        última ejecución. No hay valores fijos ni por-máquina. La primera
        vez se espera a que el job YA tenga al menos un snapshot (no se
        verifica un repo vacío ni se restaura algo inexistente)."""
        if kind == "test_restore" and not (job.get("test_restore_scratch") or "").strip():
            return False
        enabled = bool(job.get(f"{kind}_enabled"))
        if not enabled:
            return False
        at_key = "last_check_at" if kind == "check" else "last_test_restore_at"
        interval_days = max(1, int(job.get(f"{kind}_interval_days") or (7 if kind == "check" else 30)))
        last = self._parse_job_time(job.get(at_key))
        if last is not None:
            return (now - last).total_seconds() >= interval_days * 86400
        baseline = job.get("last_snapshot_id")
        return bool(baseline)

    def _launch_maintenance(self, job: Job, kind: str) -> None:
        active = getattr(self, "_maintenance_active", None)
        if active is None:
            return
        mlock = getattr(self, "_maintenance_lock", None)
        if mlock is not None and not mlock.acquire(blocking=False):
            # otro job ya está en mantenimiento; se retoma en el próximo tick.
            return
        key = (kind, int(job.get("id") or 0))
        if key in active:
            if mlock is not None:
                mlock.release()
            return
        active.add(key)
        threading.Thread(
            target=self._run_maintenance_in_thread,
            args=(job, kind, key),
            name=f"share-{kind}-{job.get('id')}",
            daemon=True,
        ).start()

    def _run_maintenance_in_thread(self, job: Job, kind: str, key) -> None:
        try:
            if kind == "check":
                self._run_integrity_check(job)
            else:
                self._run_test_restore(job)
        except Exception as error:
            logger.exception("Mantenimiento %s de '%s' falló: %s", kind, job.get("name"), error)
        finally:
            active = getattr(self, "_maintenance_active", None)
            if active is not None:
                active.discard(key)
            mlock = getattr(self, "_maintenance_lock", None)
            if mlock is not None:
                try:
                    mlock.release()
                except RuntimeError:
                    pass

    def _run_integrity_check(self, job: Job) -> None:
        started = now_ecuador()
        ok = False
        detail = ""
        try:
            result = self._restic(job, ["check"], timeout=7200)
            ok = result.returncode == 0
            detail = "" if ok else (result.stderr or result.stdout or "")[:400]
        except Exception as error:
            logger.debug("share_backup_service._run_integrity_check: %s", error)
            detail = str(error)[:400]
        job["last_check_at"] = started.isoformat()
        job["last_check_result"] = ("OK" if ok else f"FALLO: {detail}")[:500]
        self._save_job(job)
        if ok:
            logger.info("Check de integridad OK para '%s'.", job.get("name"))
        else:
            logger.warning("Check de integridad FALLÓ para '%s': %s", job.get("name"), detail)
            self._raise_alert(
                BACKUP_CHECK_FAILED_ALERT,
                f"Check de integridad falló: {job.get('name')}",
                f"El repositorio del respaldo «{job.get('name')}» no pasó "
                f"restic check. Revisa el origen/disco: {detail or 'sin detalle'}",
            )

    def _run_test_restore(self, job: Job) -> None:
        started = now_ecuador()
        target = (job.get("test_restore_scratch") or "").strip()
        snapshot_id = job.get("last_snapshot_id") or self._latest_snapshot_id(job)
        ok = False
        detail = "sin snapshot disponible"
        if target and snapshot_id:
            import shutil as _sh
            tmp = Path(target) / f".test-restore-{snapshot_id[:12]}"
            try:
                if tmp.exists():
                    _sh.rmtree(tmp, ignore_errors=True)
                tmp.mkdir(parents=True, exist_ok=True)
                result = self._restic(
                    job,
                    ["restore", snapshot_id, "--target", str(tmp)],
                    timeout=7200,
                )
                ok = result.returncode == 0
                detail = "" if ok else (result.stderr or result.stdout or "")[:400]
                # El fin es PROBAR que se puede restaurar: se limpia lo
                # restaurado para no llenar el scratch.
                _sh.rmtree(tmp, ignore_errors=True)
            except Exception as error:
                logger.debug("share_backup_service._run_test_restore: %s", error)
                detail = str(error)[:400]
        job["last_test_restore_at"] = started.isoformat()
        job["last_test_restore_result"] = ("OK" if ok else f"FALLO: {detail}")[:500]
        self._save_job(job)
        if ok:
            logger.info(
                "Test-restore OK para '%s' (snap %s).",
                job.get("name"), (snapshot_id or "")[:12],
            )
        else:
            logger.warning("Test-restore FALLÓ para '%s': %s", job.get("name"), detail)
            self._raise_alert(
                BACKUP_TEST_RESTORE_FAILED_ALERT,
                f"Test de restauración falló: {job.get('name')}",
                f"No se pudo restaurar el snapshot del respaldo «{job.get('name')}»: "
                f"{detail or 'sin detalle'}",
            )

    def _raise_alert(self, alert_type: str, title: str, message: str) -> None:
        """Crea una alerta en la DB (genérica, reutilizada por mantenimiento
        y watchdog). Nunca propaga errores: una alerta que falla no derriba
        el scheduler."""
        try:
            db = SessionLocal()
            try:
                from backend.alerts.services.alert_service import AlertService
                AlertService().create(
                    db,
                    alert_type=alert_type,
                    severity="warning",
                    title=title[:120],
                    message=message[:500],
                )
                db.commit()
            finally:
                db.close()
        except Exception as error:
            logger.warning("No se pudo crear alerta %s: %s", alert_type, error)

    # ------------------------------------------------------------------
    # Watchdog de ventana perdida (genérico por job, sin configuración)
    # ------------------------------------------------------------------

    def _check_overdue_backup(self, job: Job, now: datetime) -> None:
        """Avisa (una sola vez por evento) cuando un job programado no corrió
        su ventana. Usa las marcas del propio job (horario/intervalo vs
        last_backup_at), por lo que funciona igual en cualquier máquina y
        con cualquier cantidad de jobs."""
        if not job.get("enabled"):
            return
        mode = job.get("schedule_mode")
        if mode == "on_change":
            return
        # La ventana de ejecucion (SCHEDULE_SLOT_TOLERANCE_MINUTES, 30 min)
        # es mas amplia que la gracia de aviso (OVERDUE_GRACE_MINUTES, 15):
        # si el job todavia esta dentro de su ventana (un reinicio o una
        # actualizacion puede retrasar la corrida), la ventana NO esta
        # perdida y el scheduler lo ejecuta en este mismo tick.
        if mode == "daily":
            # Solo en horario fijo hay una ventana acotada; en modo
            # "interval" estar "due" es el estado normal, no un aviso.
            try:
                if self.is_due(job, now):
                    return
            except Exception as error:
                logger.debug("share_backup_service._check_overdue_backup: %s", error)
                pass
        last = self._parse_job_time(job.get("last_backup_at"))
        overdue = False
        if mode == "daily":
            slots = []
            for raw in self._times_list(job):
                try:
                    hh, mm = (int(x) for x in raw.split(":"))
                    slots.append(hh * 60 + mm)
                except Exception as error:
                    logger.debug("share_backup_service._check_overdue_backup: %s", error)
                    continue
            mo = now.hour * 60 + now.minute
            passed = [t for t in slots if t <= mo - OVERDUE_GRACE_MINUTES]
            if passed and last is None:
                overdue = True
            elif passed:
                latest = max(passed)
                if last.date() < now.date():
                    overdue = True
                elif last.date() == now.date() and last.hour * 60 + last.minute < latest:
                    overdue = True
        elif mode == "interval":
            interval = max(1, int(job.get("interval_minutes") or 60))
            if last is not None and (now - last).total_seconds() > 2 * interval * 60:
                overdue = True
        if overdue and not job.get("overdue_alerted"):
            job["overdue_alerted"] = True
            self._save_job(job)
            self._raise_alert(
                BACKUP_OVERDUE_ALERT,
                f"Respaldo sin correr: {job.get('name')}",
                f"El respaldo «{job.get('name')}» no corrió su ventana programada "
                f"(última corrida: {job.get('last_backup_at') or 'nunca'}).",
            )
            logger.warning("Alerta: respaldo '%s' no corrió su ventana.", job.get("name"))
        elif not overdue and job.get("overdue_alerted"):
            job["overdue_alerted"] = False
            self._save_job(job)

    def _tick(self) -> None:
        db = SessionLocal()
        try:
            if time.monotonic() - self._last_reconcile >= RECONCILE_SECONDS:
                self._reconcile(db)
                self._last_reconcile = time.monotonic()
            for job in self._all_jobs():
                if not job.get("enabled"):
                    continue
                now = now_ecuador()
                # Mantenimiento dinámico (políticas por job): integridad y test
                # de restauración. NUNCA mientras el job está respaldando (evita
                # choque de locks del repo y competencia por disco/red).
                if int(job.get("id") or 0) not in self._running_jobs:
                    if self._maintenance_due(job, "check", now):
                        self._launch_maintenance(job, "check")
                    if self._maintenance_due(job, "test_restore", now):
                        self._launch_maintenance(job, "test_restore")
                # Watchdog de ventana perdida (se omite si está corriendo).
                if int(job.get("id") or 0) not in self._running_jobs:
                    try:
                        self._check_overdue_backup(job, now)
                    except Exception as error:
                        logger.warning("overdue check %s: %s", job.get("id"), error)
                if job.get("schedule_mode") == "on_change":
                    # Deshabilitado por seguridad (riesgo de ransomware):
                    # solo se respalda por horario.
                    continue
                if not self.is_due(job, now):
                    continue
                try:
                    result = self.run_backup_job(job, trigger="scheduled")
                    logger.info("Scheduled backup %s: %s", job.get("name"), result.get("message", result))
                except HTTPException as error:
                    logger.warning("Scheduled backup %s failed: %s", job.get("name"), error.detail)
        finally:
            db.close()
