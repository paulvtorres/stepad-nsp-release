"""Configurable data retention per record type.

Each record type (DNS queries, SNI, egress, alerts, attacks and malware)
has its own retention age. Cleanup runs hourly from ``RetentionComponent``
and the ingestion loops ask this service for the value, so the
``data_retention_settings`` table is the single source of truth.

``retention_days == 0`` means "keep forever".
"""

from dataclasses import dataclass
from datetime import datetime, timedelta

from sqlalchemy import delete, func, or_, select, text, update
from sqlalchemy.orm import Session

from backend.alerts.models.alert import Alert
from backend.core.database.connection import engine
from backend.core.database.session import SessionLocal
from backend.dns.logging.models.dns_query_log import DnsQueryLog
from backend.dns.logging.models.sni_log import SniLog
from backend.ips.models.egress_flow_stat import EgressFlowStat
from backend.ips.models.inbound_attack_event import InboundAttackEvent
from backend.ips.models.malware_event import MalwareEvent
from backend.network.devices.models.network_device import NetworkDevice
from backend.rules.models.device_access_rule import DeviceAccessRule
from backend.retention.models.retention_setting import RetentionSetting
from backend.shared.logging.logger import logger


# 0 = keep forever; other values are months expressed in days.
RETENTION_PRESETS: tuple[int, ...] = (30, 60, 90, 120, 150, 180, 270, 365, 0)

# Batch size: never delete in a single huge transaction.
BATCH_SIZE = 20000


@dataclass(frozen=True)
class RetentionKind:

    key: str
    label: str
    description: str
    model: type
    column: str
    default_days: int
    keep_unread: bool = False
    guard: str | None = None


KINDS: tuple[RetentionKind, ...] = (
    RetentionKind(
        "dns_logs",
        "Consultas DNS",
        "Historial de dominios consultados por los equipos.",
        DnsQueryLog,
        "queried_at",
        90,
    ),
    RetentionKind(
        "sni_logs",
        "SNI / navegacion",
        "Nombres de host observados en el trafico TLS.",
        SniLog,
        "created_at",
        90,
    ),
    RetentionKind(
        "egress_flows",
        "Flujos de salida",
        "Agregados de conexiones hacia Internet.",
        EgressFlowStat,
        "bucket_hour",
        60,
    ),
    RetentionKind(
        "alerts",
        "Alertas",
        "Alertas ya leidas; las pendientes nunca se borran.",
        Alert,
        "created_at",
        180,
        keep_unread=True,
    ),
    RetentionKind(
        "attack_events",
        "Eventos de ataque",
        "Ataques entrantes y sondeos WAN detectados por Suricata.",
        InboundAttackEvent,
        "last_seen",
        90,
    ),
    RetentionKind(
        "malware_events",
        "Eventos de malware",
        "Detecciones del modulo de malware/phishing.",
        MalwareEvent,
        "created_at",
        90,
    ),
    RetentionKind(
        "inactive_devices",
        "Dispositivos inactivos",
        "Equipos apagados que no se ven hace tiempo. Nunca borra "
        "equipos fijos, de la empresa ni con reglas propias.",
        NetworkDevice,
        "last_seen",
        30,
        guard="device",
    ),
)

KINDS_BY_KEY: dict[str, RetentionKind] = {k.key: k for k in KINDS}


def cutoff_for(days: int, now: datetime | None = None) -> datetime | None:

    """Cutoff date, or ``None`` when nothing has to be deleted."""

    if not days or days <= 0:

        return None

    return (now or datetime.utcnow()) - timedelta(days=int(days))


def validate_days(days: int) -> int:

    value = int(days)

    if value not in RETENTION_PRESETS:

        raise ValueError(
            f"Retencion invalida: {days}. Opciones: {RETENTION_PRESETS}"
        )

    return value


class RetentionService:

    # -- ajustes -----------------------------------------------------

    def _get_setting(self, db: Session, key: str) -> RetentionSetting | None:

        return (
            db.query(RetentionSetting)
            .filter(RetentionSetting.data_type == key)
            .first()
        )

    def _legacy_dns_days(self, db: Session) -> int:

        """Previous value (a single global retention) to migrate without loss."""

        try:

            from backend.siem.models.compliance_settings import ComplianceSettings

            legacy = db.query(ComplianceSettings).first()

            if legacy and legacy.log_retention_days:

                return int(legacy.log_retention_days)

        except Exception as error:

            logger.debug("retention_service._legacy_dns_days: %s", error)

        return 90

    def _ensure_setting(self, db: Session, kind: RetentionKind) -> RetentionSetting:

        setting = self._get_setting(db, kind.key)

        if setting:

            return setting

        days = kind.default_days

        if kind.key == "dns_logs":

            days = self._legacy_dns_days(db)

        setting = RetentionSetting(
            data_type=kind.key,
            retention_days=days,
            enabled=True,
        )

        db.add(setting)

        db.commit()

        db.refresh(setting)

        return setting

    def seed(self, db: Session) -> None:

        for kind in KINDS:

            self._ensure_setting(db, kind)

    def days_for(self, db: Session, key: str, fallback: int | None = None) -> int:

        kind = KINDS_BY_KEY.get(key)

        if not kind:

            return int(fallback or 0)

        try:

            setting = self._ensure_setting(db, kind)

            return int(setting.retention_days)

        except Exception as error:

            logger.debug("retention_service.days_for: %s", error)

            return int(fallback if fallback is not None else kind.default_days)

    # -- API ---------------------------------------------------------

    def _stats(self, db: Session, kind: RetentionKind) -> dict:

        column = getattr(kind.model, kind.column)

        try:

            rows, oldest = (
                db.query(func.count(kind.model.id), func.min(column)).one()
            )

            return {"rows": int(rows or 0), "oldest": oldest}

        except Exception as error:

            logger.debug("retention_service._stats: %s", error)

            return {"rows": 0, "oldest": None}

    def list_settings(self, db: Session) -> list[dict]:

        result = []

        for kind in KINDS:

            setting = self._ensure_setting(db, kind)

            stats = self._stats(db, kind)

            result.append({
                "key": kind.key,
                "label": kind.label,
                "description": kind.description,
                "retention_days": int(setting.retention_days),
                "default_days": kind.default_days,
                "enabled": bool(setting.enabled),
                "keep_unread": kind.keep_unread,
                "options_days": list(RETENTION_PRESETS),
                "rows": stats["rows"],
                "oldest": stats["oldest"],
                "last_run_at": setting.last_run_at,
                "last_deleted": int(setting.last_deleted or 0),
            })

        return result

    def set_retention(
        self,
        db: Session,
        key: str,
        days: int,
        enabled: bool | None = None,
    ) -> dict:

        kind = KINDS_BY_KEY.get(key)

        if not kind:

            raise ValueError(f"Tipo de dato desconocido: {key}")

        value = validate_days(days)

        setting = self._ensure_setting(db, kind)

        setting.retention_days = value

        if enabled is not None:

            setting.enabled = bool(enabled)

        db.commit()

        for item in self.list_settings(db):

            if item["key"] == key:

                return item

        return {"key": key, "retention_days": value}

    # -- limpieza ----------------------------------------------------

    def guard_conditions(self, kind: RetentionKind) -> list:

        """Extra safety filters for a data type."""

        if kind.guard != "device":

            return []

        return [
            NetworkDevice.status == "OFFLINE",
            func.coalesce(NetworkDevice.is_permanent, False).is_(False),
            func.coalesce(NetworkDevice.is_company_asset, False).is_(False),
            or_(
                NetworkDevice.permanent_ip.is_(None),
                NetworkDevice.permanent_ip == "",
            ),
            ~(
                select(DeviceAccessRule.id)
                .where(DeviceAccessRule.device_id == NetworkDevice.id)
                .exists()
            ),
        ]

    def _purge_kind(self, db: Session, kind: RetentionKind, cutoff: datetime) -> int:

        column = getattr(kind.model, kind.column)

        deleted_total = 0

        while True:

            query = select(kind.model.id).where(column < cutoff)

            if kind.keep_unread:

                query = query.where(kind.model.read.is_(True))

            for condition in self.guard_conditions(kind):

                query = query.where(condition)

            ids = db.execute(query.limit(BATCH_SIZE)).scalars().all()

            if not ids:

                break

            if kind.guard == "device":

                # Preserve history: DNS logs lose the link and no device
                # keeps pointing to a deleted row. Without this, the foreign
                # keys (NO ACTION) abort the delete.
                db.execute(
                    update(DnsQueryLog)
                    .where(DnsQueryLog.device_id.in_(ids))
                    .values(device_id=None)
                )

                db.execute(
                    update(NetworkDevice)
                    .where(NetworkDevice.linked_to_id.in_(ids))
                    .values(linked_to_id=None)
                )

            db.execute(
                delete(kind.model).where(kind.model.id.in_(ids))
            )

            db.commit()

            deleted_total += len(ids)

            if len(ids) < BATCH_SIZE:

                break

        if deleted_total:

            self.vacuum(kind.model.__tablename__)

        return deleted_total

    def vacuum(self, table: str) -> None:

        """Refresh statistics and reclaim space after a delete.

        Autovacuum lags on large tables (dns_query_logs exceeded 130,000
        dead tuples). VACUUM (ANALYZE) does not lock the table and needs
        its own AUTOCOMMIT connection.
        """

        if table not in {
            kind.model.__tablename__ for kind in KINDS
        }:

            return

        try:

            with engine.connect().execution_options(
                isolation_level="AUTOCOMMIT"
            ) as connection:

                connection.execute(
                    text(f"VACUUM (ANALYZE) {table}")
                )

        except Exception as error:

            logger.debug("retention_service.vacuum: %s", error)

    def run(self, db: Session, only: list[str] | None = None) -> dict:

        summary: dict[str, int] = {}

        for kind in KINDS:

            if only and kind.key not in only:

                continue

            setting = self._ensure_setting(db, kind)

            if not setting.enabled:

                continue

            cutoff = cutoff_for(setting.retention_days)

            if cutoff is None:

                continue

            try:

                deleted = self._purge_kind(db, kind, cutoff)

            except Exception as error:

                db.rollback()

                logger.warning(
                    "Retention %s: cleanup failed: %s", kind.key, error
                )

                continue

            setting.last_run_at = datetime.utcnow()

            setting.last_deleted = deleted

            db.commit()

            summary[kind.key] = deleted

            if deleted:

                logger.info(
                    "Retention %s: %d record(s) older than %d days deleted.",
                    kind.key,
                    deleted,
                    setting.retention_days,
                )

        return summary

    def run_all_safe(self) -> dict:

        """Component entry point: own session and never raises errors."""

        db = SessionLocal()

        try:

            return self.run(db)

        except Exception as error:

            logger.warning("Retention: scheduled cleanup failed: %s", error)

            return {}

        finally:

            db.close()
