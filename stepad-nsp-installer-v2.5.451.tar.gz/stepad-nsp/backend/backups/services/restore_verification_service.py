"""Periodic verification that the latest backup is actually restorable.

Decrypts the newest encrypted backup, restores its database dump into a
temporary database, runs sanity counts, and drops it. Never touches the
live database. The result is stored as JSON and surfaced as a critical
alert when it fails.
"""

import json
import os
import subprocess
import tempfile
import threading

from datetime import datetime, timedelta
from pathlib import Path

from backend.backups.services.backup_service import BACKUP_DIR, BackupService
from backend.core.database.session import SessionLocal
from backend.shared.logging.logger import logger


STATE_PATH = Path(
    os.environ.get(
        "STEPAD_RESTORE_VERIFY_STATE",
        "/etc/stepad/backup_verify.json",
    )
)

CHECK_DB = "stepad_restore_check"
MIN_TABLES = 20


class RestoreVerificationService:

    INTERVAL_DAYS = 30

    def __init__(self, state_path: Path | None = None):

        self.state_path = Path(state_path or STATE_PATH)

        self._lock = threading.Lock()

    def status(self) -> dict:

        try:

            if self.state_path.is_file():

                data = json.loads(self.state_path.read_text("utf-8"))

                if isinstance(data, dict):

                    return data

        except Exception as error:

            logger.debug("restore_verification.status: %s", error)

        return {"success": False, "message": "sin verificaciones"}

    def _save(self, data: dict) -> None:

        try:

            self.state_path.parent.mkdir(parents=True, exist_ok=True)

            tmp = self.state_path.with_suffix(".tmp")

            tmp.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

            os.replace(tmp, self.state_path)

            try:

                os.chmod(self.state_path, 0o600)

            except OSError:

                pass

        except Exception as error:

            logger.warning("restore_verification._save: %s", error)

    def should_run(self, interval_days: int | None = None) -> bool:

        interval = int(interval_days or self.INTERVAL_DAYS)

        last_raw = self.status().get("last_run_at")

        if not last_raw:

            return True

        try:

            last = datetime.fromisoformat(last_raw)

        except ValueError:

            return True

        return datetime.utcnow() - last > timedelta(days=interval)

    def _latest_backup(self) -> Path | None:

        try:

            files = sorted(
                BACKUP_DIR.glob("stepad-backup-*.tar.gz.enc"),
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )

            return files[0] if files else None

        except OSError:

            return None

    def run(self, force: bool = False) -> dict:

        if not self._lock.acquire(blocking=False):

            return {"success": False, "message": "verificación en curso"}

        try:

            return self._run_locked(force)

        finally:

            self._lock.release()

    def _run_locked(self, force: bool) -> dict:

        backup = self._latest_backup()

        if backup is None:

            result = {
                "success": False,
                "message": "no hay respaldos para verificar",
                "last_run_at": datetime.utcnow().isoformat(),
            }

            self._save(result)

            return result

        started = datetime.utcnow()

        try:

            key = BackupService()._get_backup_key()

            if not key:

                raise RuntimeError("clave de respaldo no disponible")

            with tempfile.TemporaryDirectory() as staging:

                stage = Path(staging)

                archive = stage / "backup.tar.gz"

                decrypted = subprocess.run(
                    [
                        "openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2",
                        "-pass", f"pass:{key}",
                        "-in", str(backup), "-out", str(archive),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=300,
                )

                if decrypted.returncode != 0:

                    raise RuntimeError(
                        (decrypted.stderr or "no se pudo descifrar").strip()[:300]
                    )

                dump = stage / "database.sql.gz"

                extracted = subprocess.run(
                    ["tar", "xzf", str(archive), "-C", str(stage), "./database.sql.gz"],
                    capture_output=True,
                    text=True,
                    timeout=300,
                )

                if extracted.returncode != 0 or not dump.exists():

                    raise RuntimeError("el respaldo no contiene database.sql.gz")

                subprocess.run(
                    ["sudo", "-u", "postgres", "dropdb", "--if-exists", CHECK_DB],
                    capture_output=True,
                    timeout=60,
                )

                created = subprocess.run(
                    ["sudo", "-u", "postgres", "createdb", CHECK_DB],
                    capture_output=True,
                    text=True,
                    timeout=60,
                )

                if created.returncode != 0:

                    raise RuntimeError(
                        (created.stderr or "no se pudo crear la BD temporal").strip()[:300]
                    )

                try:

                    restored = subprocess.run(
                        [
                            "bash", "-c",
                            f"gunzip -c {dump} | sudo -u postgres psql -d {CHECK_DB} -q",
                        ],
                        capture_output=True,
                        text=True,
                        timeout=1800,
                    )

                    if restored.returncode != 0:

                        raise RuntimeError(
                            (restored.stderr or "restauración fallida").strip()[:300]
                        )

                    tables = self._scalar(
                        "SELECT count(*) FROM information_schema.tables "
                        "WHERE table_schema = 'public'"
                    )

                    if tables < MIN_TABLES:

                        raise RuntimeError(
                            f"tablas insuficientes tras restaurar: {tables}"
                        )

                    devices = self._scalar("SELECT count(*) FROM network_devices")

                    alerts = self._scalar("SELECT count(*) FROM alerts")

                finally:

                    subprocess.run(
                        ["sudo", "-u", "postgres", "dropdb", "--if-exists", CHECK_DB],
                        capture_output=True,
                        timeout=60,
                    )

            duration = (datetime.utcnow() - started).total_seconds()

            result = {
                "success": True,
                "message": "respaldo restaurado y verificado",
                "backup": backup.name,
                "last_run_at": datetime.utcnow().isoformat(),
                "duration_seconds": round(duration, 1),
                "tables": tables,
                "devices": devices,
                "alerts": alerts,
            }

            self._save(result)

            logger.info(
                "Verificación de respaldo OK (%s): %s tablas, %s equipos, %.1fs",
                backup.name, tables, devices, duration,
            )

            return result

        except Exception as error:

            result = {
                "success": False,
                "message": str(error)[:500],
                "backup": backup.name,
                "last_run_at": datetime.utcnow().isoformat(),
                "duration_seconds": round(
                    (datetime.utcnow() - started).total_seconds(), 1
                ),
            }

            self._save(result)

            logger.warning("Verificación de respaldo FALLÓ: %s", error)

            self._alert(result)

            return result

    def _scalar(self, sql: str) -> int:

        output = subprocess.run(
            [
                "sudo", "-u", "postgres", "psql",
                "-d", CHECK_DB, "-tAc", sql,
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )

        try:

            return int((output.stdout or "0").strip() or 0)

        except ValueError:

            return 0

    def _alert(self, result: dict) -> None:

        db = SessionLocal()

        try:

            from backend.alerts.services.alert_service import AlertService

            AlertService().create(
                db,
                "BACKUP_RESTORE_CHECK",
                "critical",
                "Verificación de respaldo falló",
                f"No se pudo restaurar {result.get('backup') or 'el respaldo'}: "
                f"{result.get('message')}",
            )

        except Exception as error:

            logger.warning("restore_verification._alert: %s", error)

        finally:

            db.close()
