"""Standard health and Prometheus metrics endpoints."""

import hmac
import ipaddress
import os
import shutil
import subprocess
import threading
import time

from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse

from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from backend.core.config.paths import DNSMASQ_LEASES_FILE
from backend.core.database.dependency import get_db
from backend.shared.constants.app_version import APP_VERSION
from backend.shared.logging.logger import logger


router = APIRouter(tags=["observability"])

_STARTED_AT = time.time()

METRICS_TOKEN_FILE = Path("/etc/stepad/metrics_token")

PRIVATE_NETWORKS = tuple(
    ipaddress.ip_network(net)
    for net in (
        "127.0.0.0/8",
        "::1/128",
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
        "100.64.0.0/10",
    )
)

_JOBS_CACHE: dict = {"at": 0.0, "items": []}
_JOBS_LOCK = threading.Lock()
_JOBS_TTL_SECONDS = 60


def is_private_client(host: str) -> bool:

    """True for loopback, LAN, Tailscale and other private ranges."""

    try:

        address = ipaddress.ip_address((host or "").strip())

    except ValueError:

        return False

    return any(address in network for network in PRIVATE_NETWORKS)


def _expected_token() -> str:

    token = os.environ.get("STEPAD_METRICS_TOKEN", "").strip()

    if token:

        return token

    try:

        return METRICS_TOKEN_FILE.read_text("utf-8").strip()

    except OSError:

        return ""


def _provided_token(request: Request) -> str:

    header = request.headers.get("x-metrics-token", "")

    if header:

        return header.strip()

    authorization = request.headers.get("authorization", "")

    if authorization.lower().startswith("bearer "):

        return authorization[7:].strip()

    return (request.query_params.get("token") or "").strip()


def metrics_allowed(provided: str, expected: str, private: bool) -> bool:

    """A configured token always wins; otherwise only private clients."""

    if expected:

        return bool(provided) and hmac.compare_digest(provided, expected)

    return private


def naive_utc(value) -> datetime | None:

    """Normalize datetimes to naive UTC so subtractions never fail."""

    if value is None:

        return None

    if isinstance(value, str):

        try:

            value = datetime.fromisoformat(value.replace("Z", "+00:00"))

        except ValueError:

            return None

    if not isinstance(value, datetime):

        return None

    if value.tzinfo is not None:

        value = value.astimezone(timezone.utc).replace(tzinfo=None)

    return value


def label_value(value) -> str:

    text = str(value if value is not None else "")

    return (
        text.replace("\\", "\\\\")
        .replace("\n", "\\n")
        .replace('"', '\\"')
    )


def _format_value(value) -> str:

    if isinstance(value, bool):

        return "1" if value else "0"

    if isinstance(value, float) and value.is_integer():

        return str(int(value))

    return str(value)


def render_metrics(samples: dict) -> str:

    """Prometheus text format: one # TYPE per metric name, then samples."""

    lines: list[str] = []

    for name, (kind, points) in samples.items():

        lines.append(f"# TYPE {name} {kind}")

        for labels, value in points:

            lines.append(f"{name}{labels} {value}")

    return "\n".join(lines) + "\n"


def _lease_count() -> int:

    try:

        with open(DNSMASQ_LEASES_FILE, encoding="utf-8") as handle:

            return sum(1 for line in handle if line.strip())

    except OSError:

        return 0


def _process_running(pattern: str) -> int:

    try:

        result = subprocess.run(
            ["pgrep", "-f", pattern],
            capture_output=True,
            timeout=5,
        )

        return 1 if result.returncode == 0 else 0

    except (OSError, subprocess.SubprocessError):

        return 0


def _installed_version() -> str:

    try:

        return Path("/etc/stepad/version").read_text("utf-8").strip()

    except OSError:

        return APP_VERSION


def _job_statuses() -> list:

    now = time.monotonic()

    with _JOBS_LOCK:

        if now - _JOBS_CACHE["at"] < _JOBS_TTL_SECONDS:

            return _JOBS_CACHE["items"]

    items: list = []

    try:

        from backend.shares.services.share_backup_service import ShareBackupService

        items = ShareBackupService().job_statuses()

    except (ImportError, OSError, ValueError, KeyError, TypeError) as error:

        logger.debug("metrics: job statuses failed: %s", error)

    with _JOBS_LOCK:

        _JOBS_CACHE["at"] = now
        _JOBS_CACHE["items"] = items

    return items


@router.get("/healthz")
def healthz(db: Session = Depends(get_db)):

    database_ok = True

    try:

        db.execute(text("SELECT 1"))

    except (SQLAlchemyError, OSError, ValueError, TypeError) as error:

        logger.debug("healthz: database check failed: %s", error)

        database_ok = False

    return JSONResponse(
        {
            "status": "ok" if database_ok else "degraded",
            "version": _installed_version(),
            "uptime_seconds": int(time.time() - _STARTED_AT),
            "database": database_ok,
        },
        status_code=200 if database_ok else 503,
    )


@router.get("/metrics", response_class=PlainTextResponse)
def metrics(request: Request, db: Session = Depends(get_db)):

    client = request.client.host if request.client else ""

    if not metrics_allowed(
        _provided_token(request),
        _expected_token(),
        is_private_client(client),
    ):

        raise HTTPException(status_code=403, detail="Forbidden")

    samples: dict = {}

    def metric(name: str, value, labels: str = "", kind: str = "gauge"):

        kind_of_name, points = samples.setdefault(name, (kind, []))

        points.append((labels, _format_value(value)))

    now = datetime.now(timezone.utc).replace(tzinfo=None)

    try:

        usage = shutil.disk_usage("/")

        metric("stepad_up", 1)
        metric("stepad_uptime_seconds", int(time.time() - _STARTED_AT))
        metric("stepad_disk_free_bytes", usage.free)
        metric("stepad_disk_total_bytes", usage.total)
        metric(
            "stepad_disk_used_percent",
            round(usage.used * 100 / usage.total, 2),
        )

        database_ok = 1

        try:

            db_size = db.execute(
                text("SELECT pg_database_size(current_database())")
            ).scalar()

            metric("stepad_database_size_bytes", int(db_size or 0))

            unread = db.execute(
                text("SELECT count(*) FROM alerts WHERE read = false")
            ).scalar()

            metric("stepad_alerts_unread", int(unread or 0))

            last_backup = naive_utc(
                db.execute(
                    text("SELECT last_backup_at FROM backup_settings LIMIT 1")
                ).scalar()
            )

            if last_backup is not None:

                age = (now - last_backup).total_seconds()

                metric("stepad_backup_age_seconds", int(max(0, age)))

                metric("stepad_backup_ok", 1 if age < 36 * 3600 else 0)

            else:

                metric("stepad_backup_ok", 0)

        except (SQLAlchemyError, OSError, ValueError, TypeError, KeyError) as error:

            logger.debug("metrics: database metrics failed: %s", error)

            database_ok = 0

        metric("stepad_database_ok", database_ok)

        metric("stepad_dhcp_leases", _lease_count())
        metric(
            "stepad_service_up",
            _process_running("dnsmasq"),
            '{service="dnsmasq"}',
        )
        metric(
            "stepad_service_up",
            _process_running("pdns_recursor"),
            '{service="pdns"}',
        )

        try:

            active = subprocess.run(
                ["systemctl", "is-active", "suricata"],
                capture_output=True,
                text=True,
                timeout=5,
            ).stdout.strip()

            metric(
                "stepad_service_up",
                1 if active == "active" else 0,
                '{service="suricata"}',
            )

        except (OSError, subprocess.SubprocessError, ValueError):

            metric("stepad_service_up", 0, '{service="suricata"}')

        for item in _job_statuses():

            vault = Path(str(item.get("vault") or "")).name or "?"
            job_id = item.get("id")
            labels = (
                f'{{vault="{label_value(vault)}",'
                f'job="{label_value(job_id)}"}}'
            )
            failures = int(item.get("consecutive_failures") or 0)
            last = naive_utc(item.get("last_backup_at"))

            if last is not None:

                metric(
                    "stepad_backup_job_age_seconds",
                    int(max(0, (now - last).total_seconds())),
                    labels,
                )
                metric(
                    "stepad_backup_job_ok",
                    1 if failures == 0 else 0,
                    labels,
                )

            else:

                metric("stepad_backup_job_ok", 0, labels)

        try:

            from backend.backups.services.restore_verification_service import (
                RestoreVerificationService,
            )

            state = RestoreVerificationService().status()

            metric(
                "stepad_backup_restore_verified",
                1 if state.get("success") else 0,
            )

        except (ImportError, OSError, ValueError, KeyError, TypeError):

            pass

        try:

            from backend.audit.services.audit_chain_check_service import (
                AuditChainCheckService,
            )

            audit_state = AuditChainCheckService().status()

            if audit_state.get("last_run_at"):

                metric("stepad_audit_chain_verified", 1)

                metric(
                    "stepad_audit_chain_ok",
                    1 if audit_state.get("ok") else 0,
                )

                metric(
                    "stepad_audit_chain_checked",
                    int(audit_state.get("checked") or 0),
                )

        except (ImportError, OSError, ValueError, KeyError, TypeError):

            pass

        try:

            from backend.backups.services.system_restore_verification_service import (
                SystemRestoreVerificationService,
            )

            sys_state = SystemRestoreVerificationService().status()

            if sys_state.get("last_run_at"):

                metric(
                    "stepad_system_restore_verified",
                    1 if sys_state.get("success") else 0,
                )

        except (ImportError, OSError, ValueError, KeyError, TypeError):

            pass

    except Exception as error:

        logger.warning("metrics: unexpected failure: %s", error)

        samples = {
            "stepad_up": ("gauge", [("", "0")]),
        }

    return PlainTextResponse(render_metrics(samples))
