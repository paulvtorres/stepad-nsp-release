"""Helper: aplica cambios de configuracion DHCP por el reconciliador.

Los modulos que escriben sus propios archivos incluidos (zonas, grupos)
deben pedir el reinicio al reconciliador, no reiniciar dnsmasq a mano:
asi hay un solo punto de validacion y de reinicio.
"""

from __future__ import annotations


def apply_dhcp_change(force: bool = True) -> dict:

    try:

        from backend.dhcp.reconciler import get_dhcp_reconciler

        return get_dhcp_reconciler().apply(force=force)

    except Exception as error:

        from backend.shared.logging.logger import logger

        logger.warning(
            "No se pudo aplicar el cambio DHCP via reconciliador: %s", error
        )

        return {"success": False, "error": str(error)}
