"""Aviso por correo del pool DHCP con destinatarios PROPIOS.

Independiente de los destinatarios globales de Alertas: se configuran en
Red -> DHCP y solo reciben este aviso (pool por agotarse y su
recuperación). El SMTP es el global de la plataforma.

Config (config.yaml, seccion dhcp):
    pool_low_alert_enabled: true|false
    pool_low_alert_emails: "a@x.com, b@y.com"
"""

from __future__ import annotations

import re

from sqlalchemy.orm import Session

from backend.shared.logging.logger import logger


SPLIT_RE = re.compile(r"[,;\s]+")


def parse_recipients(value) -> list[str]:
    """Acepta lista o texto separado por comas/puntos y coma/espacios."""

    if not value:

        return []

    if isinstance(value, (list, tuple)):

        items = [str(item) for item in value]

    else:

        items = SPLIT_RE.split(str(value))

    seen = set()

    result = []

    for item in items:

        email = item.strip()

        if not email or "@" not in email or email in seen:

            continue

        seen.add(email)

        result.append(email)

    return result


class DhcpPoolEmailService:

    def __init__(self, config_service=None):

        self._config_service = config_service

    def _config(self) -> dict:

        try:

            if self._config_service is None:

                from backend.shared.config.config_service import ConfigService

                self._config_service = ConfigService()

            return self._config_service.get_dhcp_config() or {}

        except Exception as error:

            logger.debug("DhcpPoolEmailService: config ilegible: %s", error)

            return {}

    def recipients(self) -> list[str]:

        config = self._config()

        if not config.get("pool_low_alert_enabled", False):

            return []

        return parse_recipients(config.get("pool_low_alert_emails"))

    def notify(self, kind: str, free: int, threshold: int) -> bool:

        recipients = self.recipients()

        if not recipients:

            return False

        if kind == "low":

            title = "DHCP: pool de IPs casi agotado"

            body = (
                f"<p>Quedan <strong>{free}</strong> direcciones libres "
                f"(umbral {threshold}). Los equipos nuevos pueden quedarse "
                "sin IP.</p><p>Ampliá el pool (pool_end), liberá reservas "
                "sin uso o reducí el lease_time.</p>"
            )

        else:

            title = "DHCP: el pool de IPs tiene espacio nuevamente"

            body = (
                f"<p>Direcciones libres: <strong>{free}</strong> "
                f"(umbral {threshold}).</p>"
            )

        return self._send(recipients, title, body)

    def _send(self, recipients: list[str], title: str, body: str) -> bool:

        """Envio real (aislado para poder testear sin SMTP)."""

        try:

            from backend.core.database.session import SessionLocal
            from backend.notifications.services.email_service import EmailService
            from backend.notifications.services.email_settings_service import (
                build_delivery_context,
            )
            from backend.notifications.services.email_subject_service import (
                build_alert_subject,
            )
            from backend.notifications.repositories.notification_settings_repository import (
                NotificationSettingsRepository,
            )

            db: Session = SessionLocal()

            try:

                delivery = build_delivery_context(
                    db,
                    to_emails=", ".join(recipients),
                )

                if delivery is None:

                    logger.warning(
                        "DHCP pool: SMTP sin configurar, no se envía el aviso."
                    )

                    return False

                settings = NotificationSettingsRepository().get(db)

                subject = build_alert_subject(
                    db,
                    getattr(settings, "alert_subject", None),
                    title=title,
                )

                result = EmailService().send_html(delivery, subject, body)

                if not result.get("success"):

                    logger.warning(
                        "DHCP pool: correo no enviado (%s): %s",
                        title,
                        result.get("message"),
                    )

                    return False

                return True

            finally:

                db.close()

        except Exception as error:

            logger.warning("DHCP pool: error enviando correo: %s", error)

            return False
