import os
import stat
import subprocess
import time

import psutil
import yaml
from pathlib import Path

from backend.core.config.paths import (
    RPZ_ZONE_FILE
)

from backend.dns.logging.dns_query_log_listener import (
    LISTEN_HOST,
    LISTEN_PORT,
)

from backend.shared.logging.logger import logger


REC_CONTROL_BIN = "/usr/bin/rec_control"

RPZ_ZONE_NAME = "stepad-blocklist"

RPZ_SOA_HOSTNAME = "localhost."

RPZ_SOA_CONTACT = "root.localhost."

RPZ_TTL_SECONDS = 300

# Default PowerDNS Recursor socket-dir on Debian -- matches what
# rec_control reports in "Unable to connect to remote '...'" errors.
RECURSOR_CONTROL_SOCKET = Path(
    "/var/run/pdns-recursor/pdns_recursor.controlsocket"
)

# The recursor's own main config -- NOT something STEPAD writes from
# scratch (it has dnssec/hint-file/security-poll settings that are
# none of STEPAD's business), only patches. See
# ensure_listen_address() for why this one field matters so much.
RECURSOR_CONF_PATH = Path("/etc/powerdns/recursor.conf")

# How long to wait for pdns-recursor.service to finish starting
# before giving up on a reload -- see reload()'s docstring for why
# this exists.
SOCKET_WAIT_TIMEOUT_SECONDS = 20

SOCKET_WAIT_POLL_SECONDS = 0.5

# STEPAD's own DNS query-log pipeline: the recursor streams every
# DNS response it answers (protobuf, length-framed) to the in-process
# listener on LISTEN_HOST:LISTEN_PORT, which decodes and stores it in
# dns_query_logs (see dns_query_log_listener.py). Without this block
# the recursor never sends anything and the protection dashboard has
# no DNS activity to show -- the exact "everything logged as zero"
# failure we hit.
#
# This is the YAML-native `logging.protobuf_servers` setting (added in
# 5.1.0). A top-level `protobuf:` key is NOT part of the 5.2 YAML
# schema and makes pdns-recursor fail to start ("unknown field
# `protobuf`") -- it has to live under `logging`. Field names are the
# 5.2 camelCase ones (asyncConnect/exportTypes; the snake_case aliases
# only arrived in 5.3.0). The client IP mask defaults to full
# (maskV4/32, maskV6/128) with no setProtobufMasks call, which is
# exactly what we need to map queries back to registered devices.
PROTOBUF_QUERY_LOG_CONFIG = [
    {
        "servers": [f"{LISTEN_HOST}:{LISTEN_PORT}"],
        "timeout": 2,
        "reconnectWaitTime": 1,
        "maxQueuedEntries": 100,
        "asyncConnect": False,
        "logQueries": False,
        "logResponses": True,
        "exportTypes": ["A", "AAAA", "CNAME"],
    }
]


class PowerDnsRpzProvider:
    """
    DnsProviderInterface implementation backed by PowerDNS Recursor
    and a locally-generated RPZ zone.

    Why this exists (vs. dnsmasq's address=/domain/IP):
    RPZ is the open, vendor-neutral mechanism enterprise DNS
    firewalls (Infoblox, BIND, PowerDNS, Knot) actually use for
    exactly this use case -- domain blocking that updates live.
    Regenerating the zone file and asking the recursor to re-read it
    NEVER requires killing the process, unlike dnsmasq's
    conf-file-loaded address= directives.

    Confirmed against PowerDNS's own docs/mailing list: `rec_control
    reload-zones` does NOT reload RPZ files loaded via rpzFile() --
    only `rec_control reload-lua-config` does. Using the wrong
    command here would silently fail to apply changes, which is
    exactly the class of bug this provider replaces.

    Requires PowerDNS Recursor installed and running (systemd
    service, typically pdns-recursor.service) with its lua-config-file
    pointing at RPZ_LUA_CONFIG, which in turn loads RPZ_ZONE_FILE via
    rpzFile(). See bootstrap() for the one-time setup of that lua file.

    IMPORTANT -- boot ordering: pdns-recursor.service is managed by
    systemd, independently of STEPAD's own process. There is no
    guarantee it has finished starting (and created its control
    socket) by the time STEPAD's own components run at boot --
    reload() accounts for this, see its docstring. bootstrap() also
    actively starts the service if it's found stopped (its packaged
    unit has no Restart=on-failure of its own, so if it ever exits
    -- OOM, a manual `systemctl stop`, whatever -- nothing brings it
    back except the next full reboot, unless something CHECKS. On an
    appliance where this is core functionality, "something checks"
    should be STEPAD itself, not an operator SSH-ing in.
    """

    def bootstrap(self):
        """
        Makes sure the recursor is running and configured to load our
        RPZ zone from RPZ_ZONE_FILE, and that it is reachable from
        every LAN. Only needs to run once (component startup / install
        time) -- domain changes only ever touch RPZ_ZONE_FILE via
        generate_domains_config(), never the recursor's own config.

        RPZ loading is configured through recursor.conf's YAML-native
        `recursor.rpzs` setting (see _ensure_recursor_config for why
        not lua_config_file) -- WITHOUT it the RPZ zone is written but
        never loaded, which is exactly the "SERVFAIL / rpz-hit
        UNKNOWN" failure seen on a fresh appliance.
        """

        if not RPZ_ZONE_FILE.exists():

            self.generate_domains_config([])

        self._ensure_recursor_readable()

        self._ensure_recursor_config()

        self.ensure_service_running()


    def _ensure_recursor_readable(self):
        """
        Makes RPZ_ZONE_FILE readable by the recursor, which runs as the
        unprivileged `pdns` user.

        The recursor loads RPZ zones from disk (no AXFR here) and
        silently drops a zone it cannot read -- a 0700 home directory
        up the path shows up only as "Permission denied" chatter in
        pdns-recursor.log, leaving the blocklist dead with no app-level
        error. Two things make this real on a stock appliance:

          - the recursor's Debian systemd unit runs with
            ProtectHome=true, so /home is off-limits to it NO MATTER
            the permissions; the zone must live under /etc (or /var).
            In production STEPAD_DIR is /etc/stepad, which is exactly
            why powerdns files must stay under STEPAD_DIR and why the
            service must run with STEPAD_ENV=production (never pointed
            at a directory under a user's home).

          - a dev/under-home install would still hit the 0700 problem.

        Fix: walk from the zone file's parent up to the filesystem
        root and make every directory that is not world-traversable
        executable by others, then drop the zone file to 0644. This is
        the app's own config tree, so opening it up for traversal is
        safe and is what lets the recursor read only the file it needs.
        Combined with a production STEPAD_DIR under /etc this is
        belt-and-braces.
        """

        if RPZ_ZONE_FILE.exists():
            os.chmod(RPZ_ZONE_FILE, 0o644)

        directory = RPZ_ZONE_FILE.parent
        chain = []
        while directory != Path(directory.anchor):
            chain.append(directory)
            directory = directory.parent

        for directory in reversed(chain):
            mode = stat.S_IMODE(directory.stat().st_mode)
            if not mode & stat.S_IXOTH:
                os.chmod(directory, mode | stat.S_IXOTH)


    def _ensure_recursor_config(self):
        """
        Writes the DNS-relevant parts of recursor.conf as YAML and
        restarts pdns-recursor when anything changed.

        Why a full-YAML rewrite instead of pointing
        recursor.lua_config_file at a .lua file: Recursor >= 5.2
        (Debian 13 ships 5.2.12) refuses lua_config_file in YAML mode
        -- "YAML settings include values originally in Lua but also
        sets `recursor.lua_config_file`. This is unsupported" -- and
        old-style flat config needs --enable-old-settings, which the
        Debian unit doesn't pass. The supported path is the YAML
        setting recursor.rpzs (the equivalent of rpzFile(), added in
        5.1.0).

        STEPAD owns exactly four bits of recursor.conf:

          - recursor.rpzs: load RPZ_ZONE_FILE with an NXDOMAIN default
            policy. This is the RPZ blocklist itself.

          - dnssec.validation: forced to "off". The recursor's DNSSEC
            validation SERVFAILs legitimate lookups on a real-world
            quirk: Verisign answers `google.com DS` with an aa=0 NSEC3
            NODATA denial, which the recursor discards as "Removing
            irrelevant record (AA not set)", so zones that are unsigned
            at the registry (google.com has no DS right now) fail to
            resolve AT ALL. Validation is not what the box is for; RPZ
            blocking is, and it is independent of DNSSEC.

          - incoming.listen / incoming.allow_from: every LAN gateway
            IP and network, so clients on any LAN can reach the
            recursor (multi-LAN aware). See ensure_listen_address().

          - logging.protobuf_servers: stream every DNS response to
            STEPAD's in-process query-log listener so the protection
            dashboard has data (see PROTOBUF_QUERY_LOG_CONFIG).

        Everything else in the file (hint_file, security_poll_suffix,
        operator extras) is preserved, never clobbered.
        """

        from backend.network.configuration.services.network_configuration_service import (
            NetworkConfigurationService
        )

        lans = NetworkConfigurationService().get_lan_configurations()

        lans = [lan for lan in lans if lan.get("ip")]

        lan_ips = sorted({lan["ip"] for lan in lans})

        lan_networks = sorted(
            {lan["network"] for lan in lans if lan.get("network")}
        )

        if not RECURSOR_CONF_PATH.exists():

            logger.warning(
                f"{RECURSOR_CONF_PATH} not found -- can't configure RPZ "
                f"or listen addresses. Is pdns-recursor installed?"
            )

            return {"success": False, "message": "recursor.conf not found"}

        try:

            raw = yaml.safe_load(RECURSOR_CONF_PATH.read_text()) or {}

        except yaml.YAMLError as error:

            logger.error(
                f"Could not parse {RECURSOR_CONF_PATH}: {error}"
            )

            return {"success": False, "error": str(error)}

        changed = False

        # pdns-recursor rechaza secciones con valor null (p. ej.
        # "outgoing: null"): eliminarlas SIEMPRE y forzar reescritura
        # si había alguna, para que el recursor use los valores por
        # defecto.
        before = set(raw.keys())
        raw = {k: v for k, v in raw.items() if v is not None}
        if set(raw.keys()) != before:
            changed = True

        recursor = raw.setdefault("recursor", {})

        if "lua_config_file" in recursor:

            del recursor["lua_config_file"]

            changed = True

        rpz_entry = {
            "name": str(RPZ_ZONE_FILE),
            "defpol": "NXDOMAIN",
            "policyName": RPZ_ZONE_NAME,
        }

        if recursor.get("rpzs") != [rpz_entry]:

            recursor["rpzs"] = [rpz_entry]

            changed = True

        dnssec = raw.setdefault("dnssec", {})
        if dnssec is None:
            raw["dnssec"] = dnssec = {}

        if dnssec.get("validation") != "off":

            dnssec["validation"] = "off"

            changed = True

        incoming = raw.setdefault("incoming", {})
        if incoming is None:
            raw["incoming"] = incoming = {}

        required_listen = {"127.0.0.1"} | set(lan_ips)

        current_listen = set(incoming.get("listen") or [])

        # REEMPLAZAR el listen (no unir): los alias de DNS por grupos
        # (192.168.50.10/11...) pertenecen a los recursor de grupo y no
        # deben quedar en el recursor principal (si no, el de grupo no
        # puede enlazar su IP y el bloqueo por grupo no funciona).
        if sorted(current_listen) != sorted(required_listen):

            incoming["listen"] = sorted(required_listen)

            changed = True

        required_allow = {"127.0.0.1"} | set(lan_networks)

        current_allow = set(incoming.get("allow_from") or [])

        # Replace (do not union): an overly broad allow_from such as
        # 0.0.0.0/0 would turn the recursor into an open resolver.
        if sorted(current_allow) != sorted(required_allow):

            incoming["allow_from"] = sorted(required_allow)

            changed = True

        protobuf = raw.setdefault("logging", {})
        if protobuf is None:
            raw["logging"] = protobuf = {}

        if protobuf.get("protobuf_servers") != PROTOBUF_QUERY_LOG_CONFIG:

            protobuf["protobuf_servers"] = PROTOBUF_QUERY_LOG_CONFIG

            changed = True

        if not changed:

            return {
                "success": True,
                "message": "recursor.conf already correct"
            }

        RECURSOR_CONF_PATH.write_text(
            yaml.safe_dump(raw, default_flow_style=False, sort_keys=False)
        )

        logger.warning(
            f"pdns-recursor was not serving STEPAD's DNS/RPZ config -- "
            f"updated {RECURSOR_CONF_PATH} (rpzs={RPZ_ZONE_FILE}, "
            f"dnssec.validation=off, listen={incoming.get('listen')}, "
            f"allow_from={incoming.get('allow_from')}) and restarting "
            f"it to apply."
        )

        restart = subprocess.run(
            ["systemctl", "restart", "pdns-recursor"],
            capture_output=True,
            text=True
        )

        if restart.returncode != 0:

            logger.error(
                f"Failed to restart pdns-recursor after updating "
                f"recursor.conf: {restart.stderr.strip()}"
            )

        return {
            "success": restart.returncode == 0,
            "rpzs": str(RPZ_ZONE_FILE),
            "listen": incoming.get("listen"),
            "allow_from": incoming.get("allow_from"),
            "restarted": restart.returncode == 0
        }


    def ensure_listen_address(self):
        """
        Makes sure PowerDNS Recursor listens on every LAN gateway IP,
        not just 127.0.0.1 -- found the hard way: a LAN client could
        get a DHCP lease and ping the gateway fine, but never
        actually resolve anything, because the recursor was only
        reachable from localhost. dnsmasq is deliberately DHCP-only
        here (port=0, see LinuxDhcpProvider) specifically because the
        recursor is supposed to be the thing LAN clients talk to
        directly for DNS -- so it has to be reachable from every LAN
        subnet, not just from the box itself.

        Multi-LAN aware: EVERY assigned LAN interface is added to
        incoming.listen (its gateway IP) and incoming.allow_from (its
        whole network), so a second LAN's clients are neither refused
        nor accidentally answered by a resolver bound to the wrong
        subnet.

        This was previously a manual edit to recursor.conf, which
        means it silently breaks again on the next hardware move or
        LAN subnet change (see NetworkSettingsService) unless
        something keeps it in sync automatically. This is that
        something -- called at every boot (bootstrap()) and, for the
        live case, wherever the LAN IP actually changes (see
        InterfaceRegistryService._sync_config_cache).

        Implements the whole STEPAD-owned recursor.conf (RPZ, listen,
        allow_from, dnssec.validation) -- see _ensure_recursor_config.
        """

        return self._ensure_recursor_config()


    def ensure_service_running(self):
        """
        Starts pdns-recursor.service if it isn't active. Safe to call
        every boot: `systemctl start` on an already-running service
        is a documented no-op, so this never disrupts a healthy
        instance -- it only ever recovers a stopped one.

        Distinguishes "service exists but is stopped" (recoverable by
        starting it) from "the unit doesn't exist at all" (the
        pdns-recursor package was never installed on this machine --
        e.g. after moving STEPAD to new hardware -- no amount of
        `systemctl start` retries fixes that).
        """

        unit_check = subprocess.run(
            ["systemctl", "list-unit-files", "pdns-recursor.service"],
            capture_output=True,
            text=True
        )

        if "pdns-recursor.service" not in unit_check.stdout:

            message = (
                "pdns-recursor.service isn't installed on this machine "
                "-- domain blocking cannot work without it. Install it "
                "with: apt install pdns-recursor"
            )

            logger.error(message)

            return {"success": False, "error": message}

        status = subprocess.run(
            ["systemctl", "is-active", "pdns-recursor"],
            capture_output=True,
            text=True
        )

        if status.stdout.strip() == "active":

            return {"success": True, "message": "pdns-recursor already active"}

        logger.warning(
            "pdns-recursor.service is not active -- starting it "
            "(STEPAD's domain blocking depends on it)."
        )

        result = subprocess.run(
            ["systemctl", "start", "pdns-recursor"],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:

            logger.info("pdns-recursor.service started.")

            return {"success": True, "message": "pdns-recursor started"}

        logger.error(
            f"Failed to start pdns-recursor.service: {result.stderr.strip()}"
        )

        return {"success": False, "error": result.stderr.strip()}


    def generate_domains_config(
        self,
        domains: list[str]
    ):

        RPZ_ZONE_FILE.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        # Serial must increase on every write for the zone to be
        # recognised as updated. Wall-clock time is monotonic enough
        # here and avoids having to parse the previous file's serial.
        serial = int(time.time())

        lines = [
            "$TTL " + str(RPZ_TTL_SECONDS),
            f"@ SOA {RPZ_SOA_HOSTNAME} {RPZ_SOA_CONTACT} ({serial} 3600 600 604800 {RPZ_TTL_SECONDS})",
            "  NS " + RPZ_SOA_HOSTNAME,
            ""
        ]

        # Normalize before dedup: bare names, leading/trailing dots and
        # case are all the same domain. Without this, a blocklist
        # carrying both "fb.com" and "fb.com." emits two IDENTICAL
        # records ("*.fb.com. CNAME ." twice), and the recursor refuses
        # to load an RPZ zone with duplicate records (ignoreDuplicates
        # defaults to false) -- silently disabling the whole blocklist.
        normalized = sorted({
            domain.strip().lower().strip(".")
            for domain in domains
            if domain and domain.strip()
        })

        for domain in normalized:

            # CNAME to "." is the RPZ idiom for NXDOMAIN. Both the
            # bare domain and the wildcard are needed: RPZ wildcard
            # matching covers subdomains but NOT the domain itself.
            lines.append(f"{domain}. CNAME .")
            lines.append(f"*.{domain}. CNAME .")

        # Final belt-and-braces: a blocklist can also carry explicit
        # wildcard entries ("*.fb.com", "*.*.fb.com") whose normalized
        # forms collide with the records generated above. Dedupe the
        # actual records so the zone never contains two identical
        # CNAME lines (which would make the recursor refuse to load it).
        lines = list(dict.fromkeys(lines))

        RPZ_ZONE_FILE.write_text(
            "\n".join(lines) + "\n"
        )


    def _wait_for_control_socket(self):
        """
        Blocks (briefly, bounded) until pdns-recursor's control
        socket exists, or the timeout elapses.

        Why this exists: STEPAD starts very early in the boot
        sequence, and pdns-recursor.service is a separate systemd
        unit STEPAD doesn't manage or start itself -- there's no
        guaranteed ordering between the two unless one is configured
        (systemd After=/Wants=), which isn't something this code can
        set up (that WOULD require editing a systemd unit file).
        What this CAN do without touching any system file: not treat
        "not ready yet" as a permanent failure -- wait a bounded
        amount of time for the socket to appear, the same way a
        well-behaved client retries a dependency during startup.

        Without this, every DOMAIN rule active at boot logged an
        identical "Unable to connect to remote ... No such file or
        directory" error (one per rule, see RuleBootstrapService) in
        the first couple of seconds after start, even though the
        recursor came up completely normally moments later.
        """

        if RECURSOR_CONTROL_SOCKET.exists():

            return True

        waited = 0.0

        while waited < SOCKET_WAIT_TIMEOUT_SECONDS:

            time.sleep(SOCKET_WAIT_POLL_SECONDS)

            waited += SOCKET_WAIT_POLL_SECONDS

            if RECURSOR_CONTROL_SOCKET.exists():

                return True

        return False


    def reload(self):
        """
        Applies the current RPZ zone file live via
        `rec_control reload-lua-config` -- no recursor restart, so
        an in-flight resolution is never dropped.

        Waits (bounded) for the control socket first -- see
        _wait_for_control_socket for why. If the socket still
        doesn't exist after the wait, pdns-recursor genuinely isn't
        running (not just "still starting"), and the error message
        below points at the actual thing to check instead of the
        raw, uninformative rec_control stderr.
        """

        if not self._wait_for_control_socket():

            message = (
                "pdns-recursor's control socket never appeared "
                f"({RECURSOR_CONTROL_SOCKET}) -- the service is "
                "likely not running. Check: systemctl status "
                "pdns-recursor"
            )

            logger.error(message)

            return {
                "success": False,
                "error": message
            }

        result = subprocess.run(
            [REC_CONTROL_BIN, "reload-lua-config"],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:

            return {
                "success": True,
                "message": "RPZ zone reloaded (no process restart)"
            }

        logger.error(
            f"rec_control reload-lua-config failed: {result.stderr.strip()}"
        )

        return {
            "success": False,
            "error": result.stderr.strip() or "rec_control reload-lua-config failed"
        }


    def get_status(self):

        for process in psutil.process_iter(["pid", "name"]):

            if process.info["name"] == "pdns_recursor":

                return {
                    "running": True,
                    "pid": process.info["pid"]
                }

        return {
            "running": False,
            "pid": None
        }


    def clear(self):

        self.generate_domains_config([])


    def get_configuration_path(self) -> Path:

        return RPZ_ZONE_FILE


    def get_domains_count(self) -> int:

        if not RPZ_ZONE_FILE.exists():

            return 0

        count = 0

        with RPZ_ZONE_FILE.open("r") as file:

            for line in file:

                line = line.strip()

                if not line:

                    continue

                if line.startswith("$"):

                    continue

                if line.startswith("@"):

                    continue

                if line.startswith("NS"):

                    continue

                if " CNAME ." in line:

                    count += 1

        #
        # Cada dominio genera dos reglas:
        #
        #   facebook.com.
        #   *.facebook.com.
        #
        return count // 2