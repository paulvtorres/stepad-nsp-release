import re
import subprocess

from backend.firewall.dns_security.resolvers.known_resolvers import (
    KNOWN_DOH_DOT_IPV4,
    KNOWN_DOH_DOT_IPV6,
)

from backend.firewall.dns_security.ranges.blocked_service_ranges import (
    META_FACEBOOK_IPV4,
    META_FACEBOOK_IPV6,
)

from backend.shared.logging.logger import logger


NFT_BIN = "/usr/sbin/nft"

# Filter rules live in the SAME chain LinuxFirewallProvider already
# creates and uses for MAC blocking -- no need for a second base
# chain hooked at forward. Every rule this provider adds carries a
# `comment`, so enable()/disable() can find and remove exactly its
# own rules without touching MAC-block entries living in that chain.
FILTER_FAMILY = "inet"
FILTER_TABLE = "stepad"
FILTER_CHAIN = "forward"

SET_V4 = "doh_dot_resolvers"
SET_V6 = "doh_dot_resolvers_v6"

# Direct IP ranges of blocked services (Meta/Facebook) whose
# connections are dropped outright so cached-DNS devices can't reach
# them by IP (see blocked_service_ranges.py for the why).
SERVICE_SET_V4 = "blocked_service_ranges_v4"
SERVICE_SET_V6 = "blocked_service_ranges_v6"

# Every WAN interface currently assigned, as an nftables ifname set.
# All three mechanisms below are scoped to traffic NOT arriving on a
# WAN ("iifname != @stepad_wan_ifaces"), so a box with multiple
# uplinks never has to enumerate them in each rule -- the set is
# repopulated on every enable()/reapply. This is what keeps the
# rules dynamic under multi-WAN: add a second WAN, and it is simply
# one more element in the set, not another rule to write.
WAN_SET = "stepad_wan_ifaces"

# The plaintext-DNS redirect needs a nat hook, which "forward" can't
# provide -- gets its own chain, still inside the SAME `inet stepad`
# table as the WAN set so the redirect rules can reference
# @stepad_wan_ifaces without a cross-table set lookup. Restricted to
# IPv4 (meta nfproto ipv4) to match the box's IPv4 DNS listener.
NAT_FAMILY = "inet"
NAT_TABLE = "stepad"
NAT_CHAIN = "dns_redirect"

DOT_UDP_COMMENT = "stepad-dot-udp"
DOT_TCP_COMMENT = "stepad-dot-tcp"
DOH_V4_COMMENT = "stepad-doh-v4"
DOH_V6_COMMENT = "stepad-doh-v6"
DOH_V4_QUIC_COMMENT = "stepad-doh-v4-quic"
DOH_V6_QUIC_COMMENT = "stepad-doh-v6-quic"
QUIC_BLOCK_COMMENT = "stepad-block-quic"
REDIRECT_UDP_COMMENT = "stepad-dns-redirect-udp"
REDIRECT_TCP_COMMENT = "stepad-dns-redirect-tcp"
SERVICE_BLOCK_V4_COMMENT = "stepad-service-block-v4"
SERVICE_BLOCK_V6_COMMENT = "stepad-service-block-v6"


COUNTER_RULES = {
    "dot_udp": DOT_UDP_COMMENT,
    "dot_tcp": DOT_TCP_COMMENT,
    "doh_v4": DOH_V4_COMMENT,
    "doh_v6": DOH_V6_COMMENT,
    "doh_v4_quic": DOH_V4_QUIC_COMMENT,
    "doh_v6_quic": DOH_V6_QUIC_COMMENT,
    "service_block_v4": SERVICE_BLOCK_V4_COMMENT,
    "service_block_v6": SERVICE_BLOCK_V6_COMMENT,
}


class LinuxEncryptedDnsProvider:
    """
    Blocks DNS-over-TLS (DoT) and DNS-over-HTTPS (DoH) so LAN devices
    cannot bypass STEPAD's RPZ-based domain blocking by pointing at
    an external encrypted resolver, redirects any remaining
    plaintext DNS (port 53) that isn't already going to STEPAD, and
    drops LAN traffic to the direct IP ranges of blocked services
    (currently Meta/Facebook) so apps with cached DNS can't reach
    them by IP.

    Four mechanisms, all scoped to routed LAN->WAN traffic (the
    router's own outbound queries never pass through forward/
    prerouting, so they're untouched regardless):

      1. Drop ALL outbound tcp/udp port 853 (DoT). No legitimate LAN
         use for 853 once STEPAD is the resolver -- port alone is a
         reliable signal, no IP list needed.

      2. Drop outbound tcp/443 AND udp/443 (the latter covers DoH
         negotiated over HTTP/3/QUIC, which several modern browsers
         now use by default and which a TCP-only rule would miss
         entirely) to a curated set of known public DoH resolver
         IPs (see resolvers/known_resolvers.py). Necessarily
         incomplete -- see that module's docstring for the limitation.

      3. NAT-redirect any tcp/udp port 53 NOT already destined for
         this box to STEPAD's own resolver. Closes the "just set
         8.8.8.8 as my DNS server" bypass so RPZ still applies.

      4. Drop LAN->WAN traffic to blocked-service IP ranges (see
         ranges/blocked_service_ranges.py). DNS-based blocking is
         useless against a device that already holds valid cached
         DNS answers from another network -- it connects by IP
         without ever querying the LAN's resolver. Cutting the
         connections themselves is the only thing that stops the app
         in that case.

    All four are restricted to traffic NOT arriving on a WAN
    interface (iifname != @stepad_wan_ifaces, a set holding every
    currently-assigned WAN), so this can never turn the box into an
    open resolver reachable from the internet -- regardless of how
    many uplinks are in play.
    """

    def run(self, command):

        result = subprocess.run(
            command,
            capture_output=True,
            text=True
        )

        return {

            "success": result.returncode == 0,

            "stdout": result.stdout.strip(),

            "stderr": result.stderr.strip()

        }


    # ---- one-time setup -------------------------------------------

    def _ensure_filter_chain(self):

        self.run(
            [NFT_BIN, "add", "table", FILTER_FAMILY, FILTER_TABLE]
        )

        self.run(
            [NFT_BIN, "add", "chain", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN]
        )


    def _ensure_sets(self):

        self.run([
            NFT_BIN, "add", "set", FILTER_FAMILY, FILTER_TABLE, SET_V4,
            "{", "type", "ipv4_addr", ";", "flags", "interval", ";", "}"
        ])

        self.run([
            NFT_BIN, "add", "set", FILTER_FAMILY, FILTER_TABLE, SET_V6,
            "{", "type", "ipv6_addr", ";", "flags", "interval", ";", "}"
        ])

        self.run([
            NFT_BIN, "add", "set", FILTER_FAMILY, FILTER_TABLE, SERVICE_SET_V4,
            "{", "type", "ipv4_addr", ";", "flags", "interval", ";", "}"
        ])

        self.run([
            NFT_BIN, "add", "set", FILTER_FAMILY, FILTER_TABLE, SERVICE_SET_V6,
            "{", "type", "ipv6_addr", ";", "flags", "interval", ";", "}"
        ])

        self.run([
            NFT_BIN, "add", "set", FILTER_FAMILY, FILTER_TABLE, WAN_SET,
            "{", "type", "ifname", ";", "}"
        ])


    def _populate_wan_set(self, wan_interfaces: list[str]):

        self.run([
            NFT_BIN, "flush", "set", FILTER_FAMILY, FILTER_TABLE, WAN_SET
        ])

        if not wan_interfaces:

            return {"success": True, "message": "No WAN interfaces to load"}

        elements = ", ".join(wan_interfaces)

        return self.run([
            NFT_BIN, "add", "element", FILTER_FAMILY, FILTER_TABLE, WAN_SET,
            "{", elements, "}"
        ])


    def _ensure_nat_chain(self):

        self.run(
            [NFT_BIN, "add", "table", NAT_FAMILY, NAT_TABLE]
        )

        self.run([
            NFT_BIN, "add", "chain", NAT_FAMILY, NAT_TABLE, NAT_CHAIN,
            "{", "type", "nat", "hook", "prerouting", "priority", "-100", ";", "}"
        ])


    # ---- comment-tagged rule bookkeeping ----------------------------

    def _chain_lines(self, family, table, chain):

        result = subprocess.run(
            [NFT_BIN, "-a", "list", "chain", family, table, chain],
            capture_output=True,
            text=True
        )

        return result.stdout.splitlines()


    def _rule_exists(self, family, table, chain, comment):

        return any(
            comment in line
            for line in self._chain_lines(family, table, chain)
        )


    def _delete_rules_by_comment(self, family, table, chain, comment):

        removed = 0

        for line in self._chain_lines(family, table, chain):

            if comment not in line or "handle" not in line:

                continue

            handle = line.split("handle")[1].strip()

            self.run(
                [NFT_BIN, "delete", "rule", family, table, chain, "handle", handle]
            )

            removed += 1

        return removed


    # ---- resolver blocklist -----------------------------------------

    # ---- stats ------------------------------------------------------

    def get_counters(self):

        """
        Per-rule packet/byte counters for every drop rule this
        provider manages, read straight from nftables. Used by the
        protection dashboard to surface real blocked-attempt numbers
        (DoT/DoH evasion tries, direct-IP attempts to blocked
        services) instead of only DNS-level events.
        """

        lines = self._chain_lines(
            FILTER_FAMILY,
            FILTER_TABLE,
            FILTER_CHAIN
        )

        counters = {}

        for line in lines:

            for key, comment in COUNTER_RULES.items():

                if comment not in line:

                    continue

                match = re.search(
                    r"counter packets (\d+) bytes (\d+)",
                    line
                )

                if match:

                    counters[key] = {
                        "packets": int(match.group(1)),
                        "bytes": int(match.group(2))
                    }

        return counters


    def _populate_set(self, set_name, ips):

        if not ips:

            return {"success": True, "message": "No addresses to load"}

        self.run(
            [NFT_BIN, "flush", "set", FILTER_FAMILY, FILTER_TABLE, set_name]
        )

        elements = ", ".join(ips)

        return self.run([
            NFT_BIN, "add", "element", FILTER_FAMILY, FILTER_TABLE, set_name,
            "{", elements, "}"
        ])


    def refresh_blocklist(self):

        self._ensure_filter_chain()

        self._ensure_sets()

        v4 = self._populate_set(SET_V4, KNOWN_DOH_DOT_IPV4)

        v6 = self._populate_set(SET_V6, KNOWN_DOH_DOT_IPV6)

        svc_v4 = self._populate_set(SERVICE_SET_V4, META_FACEBOOK_IPV4)

        svc_v6 = self._populate_set(SERVICE_SET_V6, META_FACEBOOK_IPV6)

        failures = [
            result for result in (v4, v6, svc_v4, svc_v6)
            if not result.get("success", True)
        ]

        if failures:

            logger.error(
                f"Failed to refresh DoH resolver/service blocklists: {failures}"
            )

        return {

            "ipv4": v4,

            "ipv6": v6,

            "service_ipv4": svc_v4,

            "service_ipv6": svc_v6,

            "total_ips": len(KNOWN_DOH_DOT_IPV4) + len(KNOWN_DOH_DOT_IPV6),

            "total_service_ranges": len(META_FACEBOOK_IPV4) + len(META_FACEBOOK_IPV6),

        }


    # ---- enable / disable --------------------------------------------

    def enable(self, wan_interfaces: list[str]):

        if not wan_interfaces:

            logger.error(
                "Encrypted DNS blocking enable() called with no WAN "
                "interfaces -- refusing (rules would match LAN traffic "
                "with no uplink to exclude)."
            )

            return {
                "success": False,
                "applied": {"wan_set": {"success": False, "error": "No WAN interfaces"}}
            }

        self._ensure_filter_chain()

        self._ensure_sets()

        self._ensure_nat_chain()

        self.refresh_blocklist()

        wan_set = self._populate_wan_set(wan_interfaces)

        if not wan_set["success"]:

            logger.error(
                f"Failed to populate WAN interface set: {wan_set}"
            )

            return {"success": False, "applied": {"wan_set": wan_set}}

        #
        # Delete-then-add instead of "add if missing": it makes
        # enable() fully idempotent AND self-heals rules written in
        # the old single-WAN format (iifname != ethX), which would
        # otherwise shadow the new set-based rules for good. There is
        # never a gap between the two -- the rules only match LAN-side
        # traffic, and a re-enable is the only path that deletes them.
        #
        for comment in (
            DOT_UDP_COMMENT,
            DOT_TCP_COMMENT,
            DOH_V4_COMMENT,
            DOH_V4_QUIC_COMMENT,
            DOH_V6_COMMENT,
            DOH_V6_QUIC_COMMENT,
            QUIC_BLOCK_COMMENT,
            SERVICE_BLOCK_V4_COMMENT,
            SERVICE_BLOCK_V6_COMMENT,
            REDIRECT_UDP_COMMENT,
            REDIRECT_TCP_COMMENT,
        ):

            family, table, chain = self._chain_for_comment(comment)

            self._delete_rules_by_comment(family, table, chain, comment)

        applied = {}

        applied["dot_udp"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "udp", "dport", "853", "counter", "drop",
            "comment", DOT_UDP_COMMENT
        ])

        applied["dot_tcp"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "tcp", "dport", "853", "counter", "drop",
            "comment", DOT_TCP_COMMENT
        ])

        applied["doh_v4"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip", "daddr", f"@{SET_V4}", "tcp", "dport", "443",
            "counter", "drop",
            "comment", DOH_V4_COMMENT
        ])

        applied["doh_v4_quic"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip", "daddr", f"@{SET_V4}", "udp", "dport", "443",
            "counter", "drop",
            "comment", DOH_V4_QUIC_COMMENT
        ])

        applied["doh_v6"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip6", "daddr", f"@{SET_V6}", "tcp", "dport", "443",
            "counter", "drop",
            "comment", DOH_V6_COMMENT
        ])

        applied["doh_v6_quic"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip6", "daddr", f"@{SET_V6}", "udp", "dport", "443",
            "counter", "drop",
            "comment", DOH_V6_QUIC_COMMENT
        ])

        # Bloquear QUIC (UDP 443) de TODA la LAN: el video de youtube cae
        # por HTTP/3 (QUIC) y evade el bloqueo por SNI/DNS. Al forzar
        # HTTPS a TCP, Suricata puede ver el SNI y cortar googlevideo.
        applied["block_quic"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "udp", "dport", "443", "counter", "drop",
            "comment", QUIC_BLOCK_COMMENT
        ])

        applied["service_block_v4"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip", "daddr", f"@{SERVICE_SET_V4}",
            "counter", "drop",
            "comment", SERVICE_BLOCK_V4_COMMENT
        ])

        applied["service_block_v6"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip6", "daddr", f"@{SERVICE_SET_V6}",
            "counter", "drop",
            "comment", SERVICE_BLOCK_V6_COMMENT
        ])

        # Redirect plaintext DNS not already destined for this box so
        # clients cannot bypass RPZ by hardcoding 8.8.8.8 / 1.1.1.1.
        applied["redirect_udp"] = self.run([
            NFT_BIN, "add", "rule", NAT_FAMILY, NAT_TABLE, NAT_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "meta", "nfproto", "ipv4",
            "udp", "dport", "53", "redirect", "to", ":53",
            "comment", REDIRECT_UDP_COMMENT
        ])

        applied["redirect_tcp"] = self.run([
            NFT_BIN, "add", "rule", NAT_FAMILY, NAT_TABLE, NAT_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "meta", "nfproto", "ipv4",
            "tcp", "dport", "53", "redirect", "to", ":53",
            "comment", REDIRECT_TCP_COMMENT
        ])

        # La cola NFQ debe quedar SIEMPRE despues de todas las reglas de
        # drop (QUIC, DoH/DoT, service): si va antes, Suricata acepta el
        # paquete (p. ej. QUIC de youtube) y las reglas posteriores nunca
        # lo ven (contadores en 0) -> el video evade el bloqueo.
        self._ensure_queue_last()

        success = all(
            result.get("success", True)
            for result in applied.values()
        )

        if not success:

            logger.error(
                f"Encrypted DNS blocking enable() had failures: {applied}"
            )

        return {"success": success, "applied": applied}

    def _ensure_queue_last(self):
        """Borra la cola NFQ existente y la re-agrega al final de la
        cadena forward, de modo que los drops corran primero."""

        result = self.run([NFT_BIN, "-a", "list", "chain",
                           FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN])

        if result and result.get("success"):

            for line in result.get("stdout", "").splitlines():

                if "queue" not in line or "handle" not in line:

                    continue

                handle = line.split("handle")[1].strip().split()[0]

                self.run([NFT_BIN, "delete", "rule",
                          FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
                          "handle", handle])

        self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "queue", "num", "0", "bypass"
        ])


    def _chain_for_comment(self, comment):

        if comment in (REDIRECT_UDP_COMMENT, REDIRECT_TCP_COMMENT):

            return NAT_FAMILY, NAT_TABLE, NAT_CHAIN

        return FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN


    def disable(self):

        removed = {

            "dot_udp": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, DOT_UDP_COMMENT
            ),

            "dot_tcp": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, DOT_TCP_COMMENT
            ),

            "doh_v4": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, DOH_V4_COMMENT
            ),

            "doh_v4_quic": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, DOH_V4_QUIC_COMMENT
            ),

            "doh_v6": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, DOH_V6_COMMENT
            ),

            "doh_v6_quic": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, DOH_V6_QUIC_COMMENT
            ),

            "block_quic": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, QUIC_BLOCK_COMMENT
            ),

            "redirect_udp": self._delete_rules_by_comment(
                NAT_FAMILY, NAT_TABLE, NAT_CHAIN, REDIRECT_UDP_COMMENT
            ),

            "redirect_tcp": self._delete_rules_by_comment(
                NAT_FAMILY, NAT_TABLE, NAT_CHAIN, REDIRECT_TCP_COMMENT
            ),

            "service_block_v4": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, SERVICE_BLOCK_V4_COMMENT
            ),

            "service_block_v6": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, SERVICE_BLOCK_V6_COMMENT
            ),

        }

        return {"success": True, "removed": removed}


    def enable_service_block(self, wan_interfaces: list[str]):
        """
        Applies ONLY the service-IP drop rules (Meta/Facebook),
        independently of the DoT/DoH rules. Used when an admin wants
        to block a service by IP without enabling the full encrypted
        DNS layer.
        """

        if not wan_interfaces:

            logger.error(
                "Service block enable() called with no WAN interfaces -- "
                "refusing (rules need a WAN set to exclude)."
            )

            return {
                "success": False,
                "applied": {"wan_set": {"success": False, "error": "No WAN interfaces"}}
            }

        self._ensure_filter_chain()

        self._ensure_sets()

        wan_set = self._populate_wan_set(wan_interfaces)

        if not wan_set["success"]:

            logger.error(
                f"Failed to populate WAN interface set for service block: {wan_set}"
            )

            return {"success": False, "applied": {"wan_set": wan_set}}

        for comment in (SERVICE_BLOCK_V4_COMMENT, SERVICE_BLOCK_V6_COMMENT):

            self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, comment
            )

        applied = {}

        applied["service_block_v4"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip", "daddr", f"@{SERVICE_SET_V4}",
            "counter", "drop",
            "comment", SERVICE_BLOCK_V4_COMMENT
        ])

        applied["service_block_v6"] = self.run([
            NFT_BIN, "add", "rule", FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN,
            "iifname", "!=", f"@{WAN_SET}",
            "ip6", "daddr", f"@{SERVICE_SET_V6}",
            "counter", "drop",
            "comment", SERVICE_BLOCK_V6_COMMENT
        ])

        success = all(
            result.get("success", True)
            for result in applied.values()
        )

        if not success:

            logger.error(
                f"Service block enable() had failures: {applied}"
            )

        return {"success": success, "applied": applied}


    def disable_service_block(self):

        removed = {

            "service_block_v4": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, SERVICE_BLOCK_V4_COMMENT
            ),

            "service_block_v6": self._delete_rules_by_comment(
                FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, SERVICE_BLOCK_V6_COMMENT
            ),

        }

        return {"success": True, "removed": removed}


    def is_active(self):

        return self._rule_exists(
            FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, DOT_UDP_COMMENT
        )


    def get_blocklist_size(self):

        return len(KNOWN_DOH_DOT_IPV4) + len(KNOWN_DOH_DOT_IPV6)


    def get_service_block_status(self):

        return {
            "ipv4_ranges": len(META_FACEBOOK_IPV4),
            "ipv6_ranges": len(META_FACEBOOK_IPV6),
            "active": (
                self._rule_exists(
                    FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, SERVICE_BLOCK_V4_COMMENT
                )
                and self._rule_exists(
                    FILTER_FAMILY, FILTER_TABLE, FILTER_CHAIN, SERVICE_BLOCK_V6_COMMENT
                )
            ),
        }
