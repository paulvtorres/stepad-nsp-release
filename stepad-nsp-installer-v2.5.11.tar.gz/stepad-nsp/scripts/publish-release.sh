#!/usr/bin/env bash
#
# Publica una versión de STEPAD NSP en paulvtorres/stepad-nsp-release.
#
# Flujo:
#   1. Tag en stepad-nsp (repo de desarrollo)
#   2. make-installer.sh -> stepad-nsp-installer-<tag>.tar.gz
#   3. Copia a stepad-nsp-release como stepad-nsp-installer.tar.gz
#   4. Commit + push en stepad-nsp-release
#   5. (Opcional) gh release create con el asset versionado
#
# Uso:
#   bash scripts/publish-release.sh v2.5.11 "Mejoras de seguridad de red"
#
set -euo pipefail

VERSION="${1:-}"
NOTES="${2:-Release ${VERSION}}"

if [ -z "${VERSION}" ]; then
    echo "Uso: bash scripts/publish-release.sh <tag> [notas]"
    echo "Ejemplo: bash scripts/publish-release.sh v2.5.11 \"Seguridad de red\""
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEV_REPO="$(cd "${SCRIPT_DIR}/.." && pwd)"
RELEASE_REPO="${STEPAD_RELEASE_DIR:-/home/paulan/stepad-nsp-release}"
RELEASE_REMOTE="paulvtorres/stepad-nsp-release"

cd "${DEV_REPO}"

if ! git diff-index --quiet HEAD --; then
    echo "ERROR: stepad-nsp tiene cambios sin commitear. Commitea primero."
    git status --short
    exit 1
fi

echo "==> Versión: ${VERSION}"
echo "${VERSION}" > "${DEV_REPO}/VERSION"

git add VERSION
git commit -m "chore: bump version to ${VERSION}" || true

if git rev-parse "${VERSION}" >/dev/null 2>&1; then
    echo "==> Tag ${VERSION} ya existe"
else
    git tag -a "${VERSION}" -m "${NOTES}"
fi

echo "==> Empujando stepad-nsp..."
git push origin main
git push origin "${VERSION}"

echo "==> Construyendo instalador..."
bash "${DEV_REPO}/make-installer.sh"

INSTALLER="stepad-nsp-installer-${VERSION}.tar.gz"

if [ ! -f "${DEV_REPO}/${INSTALLER}" ]; then
    echo "ERROR: no se generó ${INSTALLER}"
    exit 1
fi

if [ ! -d "${RELEASE_REPO}/.git" ]; then
    echo "ERROR: no existe ${RELEASE_REPO}. Clona stepad-nsp-release ahí."
    exit 1
fi

echo "==> Publicando en ${RELEASE_REPO}..."
cp "${DEV_REPO}/get-stepad.sh" "${RELEASE_REPO}/get-stepad.sh"
cp "${DEV_REPO}/${INSTALLER}" "${RELEASE_REPO}/stepad-nsp-installer.tar.gz"
cp "${DEV_REPO}/${INSTALLER}" "${RELEASE_REPO}/${INSTALLER}"

cd "${RELEASE_REPO}"

git add get-stepad.sh stepad-nsp-installer.tar.gz "${INSTALLER}"
git commit -m "release ${VERSION}: ${NOTES}"

git push origin main

echo ""
echo "Instalador publicado en stepad-nsp-release (main)."
echo "  ${RELEASE_REPO}/stepad-nsp-installer.tar.gz"
echo ""
echo "Para crear el GitHub Release (asset versionado):"
echo "  gh release create ${VERSION} \\"
echo "    --repo ${RELEASE_REMOTE} \\"
echo "    --title \"STEPAD NSP ${VERSION}\" \\"
echo "    --notes \"${NOTES}\" \\"
echo "    ${INSTALLER} stepad-nsp-installer.tar.gz"
echo ""
echo "Instalación remota:"
echo "  curl -fsSL https://raw.githubusercontent.com/${RELEASE_REMOTE}/main/get-stepad.sh | sudo bash"
