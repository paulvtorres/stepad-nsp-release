from types import SimpleNamespace

from backend.backups.services.cloud_storage_service import (
    CloudStorageService,
)


def test_select_prunable_keeps_newest():

    service = CloudStorageService()

    names = [
        "stepad-backup-20261027-033000.tar.gz.enc",
        "stepad-backup-20261029-033000.tar.gz.enc",
        "otro.txt",
        "stepad-backup-20261028-033000.tar.gz.enc",
    ]

    assert service.select_prunable(names, 2) == [
        "stepad-backup-20261027-033000.tar.gz.enc"
    ]


def test_select_prunable_ignores_other_files():

    service = CloudStorageService()

    assert service.select_prunable(["nota.txt", "x.tar.gz"], 1) == []


def test_backup_target_s3_uses_bucket_and_folder():

    service = CloudStorageService()

    settings = SimpleNamespace(
        provider="s3",
        bucket="mi-bucket",
        backup_remote_path="backups",
    )

    assert service.backup_target(settings).endswith(":mi-bucket/backups")


def test_backup_target_defaults_to_backups_folder():

    service = CloudStorageService()

    settings = SimpleNamespace(
        provider="sftp",
        bucket=None,
        backup_remote_path=None,
    )

    assert service.backup_target(settings).endswith(":backups")
