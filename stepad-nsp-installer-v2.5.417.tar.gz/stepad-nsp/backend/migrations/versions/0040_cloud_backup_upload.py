"""Subida del respaldo de configuracion a la nube

Revision ID: 0040
Revises: 0039
Create Date: 2026-10-30 00:30:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "0040"
down_revision = "0039"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "cloud_storage_settings",
        sa.Column(
            "backup_upload_enabled", sa.Boolean(), nullable=False,
            server_default=sa.false(),
        ),
    )
    op.add_column(
        "cloud_storage_settings",
        sa.Column("backup_remote_path", sa.String(length=255), nullable=True),
    )
    op.add_column(
        "cloud_storage_settings",
        sa.Column(
            "backup_retention_count", sa.Integer(), nullable=False,
            server_default="7",
        ),
    )
    op.add_column(
        "cloud_storage_settings",
        sa.Column("backup_last_upload_at", sa.DateTime(), nullable=True),
    )
    op.add_column(
        "cloud_storage_settings",
        sa.Column("backup_last_result", sa.String(length=255), nullable=True),
    )


def downgrade() -> None:
    for column in (
        "backup_last_result",
        "backup_last_upload_at",
        "backup_retention_count",
        "backup_remote_path",
        "backup_upload_enabled",
    ):
        op.drop_column("cloud_storage_settings", column)
