import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import { getBandwidthLive, getDhcpPoolStats } from "../../../services/api";

import {
    formatMbps,
    getBottlenecks,
    getFlowSeconds,
    getServices,
    getTopConsumers,
} from "./liveOperationsUtils";

import "./liveOperations.css";

const POLL_MS = 5000;

export default function LiveOperations({
    system,
    operationalHealth,
    monitoring,
}) {
    const [bandwidth, setBandwidth] = useState(null);
    const [pool, setPool] = useState(null);
    const [bandwidthError, setBandwidthError] = useState("");
    const [paused, setPaused] = useState(false);

    useEffect(() => {
        let active = true;

        async function load() {
            const [trafficResult, poolResult] = await Promise.allSettled([
                getBandwidthLive(false),
                getDhcpPoolStats(),
            ]);

            if (!active) return;

            if (trafficResult.status === "fulfilled") {
                setBandwidth(trafficResult.value || null);
                setBandwidthError("");
            } else {
                setBandwidthError(
                    trafficResult.reason?.message
                    || "No se pudo leer el tráfico."
                );
            }

            if (poolResult.status === "fulfilled") {
                setPool(poolResult.value || null);
            }
        }

        load();

        const timer = window.setInterval(() => {
            const visible = document.visibilityState === "visible";

            setPaused(!visible);

            if (visible) load();
        }, POLL_MS);

        const onVisibility = () => {
            const visible = document.visibilityState === "visible";

            setPaused(!visible);

            if (visible) load();
        };

        document.addEventListener("visibilitychange", onVisibility);

        return () => {
            active = false;
            window.clearInterval(timer);
            document.removeEventListener("visibilitychange", onVisibility);
        };
    }, []);

    const wan = bandwidth?.wan || {};
    const rx = Number(wan.rx_mbps || 0);
    const tx = Number(wan.tx_mbps || 0);
    const total = rx + tx;
    const flowSeconds = getFlowSeconds(
        total,
        Math.max(
            Number(wan.peak_rx_mbps || 0),
            Number(wan.peak_tx_mbps || 0),
            10,
        )
    );
    const consumers = getTopConsumers(bandwidth);
    const issues = getBottlenecks({
        system,
        operationalHealth,
        monitoring,
        pool,
        bandwidthError,
    });
    const services = getServices(system);
    const flowState = bandwidthError ? "error" : total > 0.01 ? "flowing" : "idle";

    return (
        <section className="live-ops">

            <header className="live-ops-head">
                <div>
                    <span className="live-ops-kicker">
                        <span className="live-ops-live-dot" />
                        EN VIVO
                    </span>
                    <h3>Operación en vivo</h3>
                    <p>
                        Lo que está pasando ahora: consumo, flujo y puntos que
                        pueden frenar la red.
                    </p>
                </div>

                <Link className="live-ops-link" to="/performance">
                    Ver desempeño →
                </Link>
            </header>

            <div className="live-ops-grid">

                <article className="live-card live-flow-card">
                    <header className="live-card-head">
                        <h4>Flujo de Internet</h4>
                        <span className={`live-card-state ${flowState}`}>
                            {bandwidthError
                                ? "Sin datos"
                                : total > 0.01
                                    ? "Tráfico activo"
                                    : "Sin tráfico"}
                        </span>
                    </header>

                    <div
                        className={`live-flow ${flowState} ${paused ? "paused" : ""}`}
                        style={{ "--live-speed": `${flowSeconds || 2.4}s` }}
                    >
                        <span className="live-flow-node">
                            <b>◎</b>
                            Internet
                        </span>

                        <span className="live-flow-pipe" aria-hidden="true">
                            <i className="live-packet rx p1" />
                            <i className="live-packet rx p2" />
                            <i className="live-packet tx p1" />
                            <i className="live-packet tx p2" />
                        </span>

                        <span className="live-flow-node nsp">
                            <b>▣</b>
                            NSP
                        </span>

                        <span className="live-flow-pipe" aria-hidden="true">
                            <i className="live-packet rx p2" />
                            <i className="live-packet rx p3" />
                            <i className="live-packet tx p2" />
                            <i className="live-packet tx p3" />
                        </span>

                        <span className="live-flow-node">
                            <b>⬡</b>
                            LAN
                        </span>
                    </div>

                    <div className="live-flow-metrics">
                        <div>
                            <span>Bajada</span>
                            <strong>{formatMbps(rx)}</strong>
                        </div>
                        <div>
                            <span>Subida</span>
                            <strong>{formatMbps(tx)}</strong>
                        </div>
                        <div>
                            <span>Ahora</span>
                            <strong>{formatMbps(total)}</strong>
                        </div>
                    </div>

                    {bandwidth?.acct_enabled === false && (
                        <p className="live-card-note">
                            La contabilidad por equipo no está activa.
                        </p>
                    )}
                </article>

                <article className="live-card live-consumers-card">
                    <header className="live-card-head">
                        <h4>Quién consume más</h4>
                        <Link to="/bandwidth">Ver todos →</Link>
                    </header>

                    {consumers.length === 0 ? (
                        <p className="live-card-empty">
                            {bandwidthError
                                ? "Sin telemetría de consumo ahora."
                                : "Ningún equipo está usando el enlace ahora."}
                        </p>
                    ) : (
                        <div className="live-consumers">
                            {consumers.map((device, index) => (
                                <div
                                    className={`live-consumer ${index === 0 ? "leader" : ""}`}
                                    key={device.ip || device.name || index}
                                >
                                    <div className="live-consumer-top">
                                        <strong>
                                            {device.name || device.ip || "Equipo"}
                                        </strong>
                                        <span>{formatMbps(device.total)}</span>
                                    </div>
                                    <div className="live-consumer-bar">
                                        <span style={{ width: `${device.width}%` }} />
                                    </div>
                                    <small>
                                        {device.ip || "sin IP"} · {device.share.toFixed(1)}% del tráfico
                                    </small>
                                </div>
                            ))}
                        </div>
                    )}
                </article>

                <article className="live-card live-issues-card">
                    <header className="live-card-head">
                        <h4>Cuellos de botella</h4>
                        <span className={`live-count ${issues.length ? "warn" : "ok"}`}>
                            {issues.length}
                        </span>
                    </header>

                    {issues.length === 0 ? (
                        <div className="live-issues-clear">
                            <span>✓</span>
                            <div>
                                <strong>Todo fluye</strong>
                                <small>Sin servicios caídos ni recursos al límite.</small>
                            </div>
                        </div>
                    ) : (
                        <div className="live-issues">
                            {issues.map((issue, index) => (
                                <div
                                    className={`live-issue ${issue.severity}`}
                                    key={`${issue.title}-${index}`}
                                >
                                    <span className="live-issue-dot" />
                                    <div>
                                        <strong>{issue.title}</strong>
                                        <small>{issue.detail}</small>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </article>
            </div>

            <div className="live-services" aria-label="Estado de servicios">
                {services.map((service) => (
                    <div
                        className={`live-service ${service.state === "running" ? "ok" : "bad"}`}
                        key={service.name}
                    >
                        <span className="live-service-icon">{service.icon}</span>
                        <div>
                            <strong>{service.label}</strong>
                            <small>
                                {service.state === "running"
                                    ? "Operativo"
                                    : service.state === "starting"
                                        ? "Iniciando"
                                        : "Revisar"}
                            </small>
                        </div>
                        <span className="live-service-dot" />
                    </div>
                ))}
            </div>
        </section>
    );
}
