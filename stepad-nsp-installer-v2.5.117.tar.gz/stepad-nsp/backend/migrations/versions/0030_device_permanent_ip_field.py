"""Add permanent_ip field to network_devices

Revision ID: 0030
Revises: 0029
Create Date: 2026-09-10 12:00:00.000000
"""
from alembic import op
import sqlalchemy as sa

revision = "0030"
down_revision = "0029"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Idempotent: the column may already exist if it was added before Alembic
    # recorded revision 0030 (e.g. legacy stub that created it inline).
    from sqlalchemy import inspect
    with op.get_context().autocommit_block():
        conn = op.get_bind()
        inspector = inspect(conn)
        if "permanent_ip" not in [c["name"] for c in inspector.get_columns("network_devices")]:
            op.add_column(
                "network_devices",
                sa.Column("permanent_ip", sa.String(45), nullable=True),
            )


def downgrade() -> None:
    op.drop_column("network_devices", "permanent_ip")
