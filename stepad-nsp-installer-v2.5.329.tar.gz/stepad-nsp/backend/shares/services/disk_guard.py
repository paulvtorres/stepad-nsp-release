"""Custodias de seguridad del stock de discos.

Invariante central: la NSP NUNCA toca el disco del sistema. Toda
operación sobre particiones, monturas y restauraciones debe validar
que su objetivo resida en un disco de datos, nunca en el disco que
sostiene el sistema operativo.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

from fastapi import HTTPException


def _run(command: list[str]) -> str:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=10)
        return (result.stdout or "").strip()
    except Exception:
        return ""


def whole_disk_for(device: str) -> str | None:
    """Devuelve el nombre del disco físico (PK) que contiene a `device`.

    /dev/sdb2 -> "sdb"; /dev/nvme0n1p2 -> "nvme0n1"; /dev/mmcblk0p1 -> "mmcblk0".
    Para el propio nodo de disco devuelve None (es él mismo).
    """
    if not (device or "").strip():
        return None
    pk = _run(["lsblk", "-no", "PKNAME", device.strip()])
    if pk:
        return pk.splitlines()[0].strip()
    return None


def system_disk_names() -> set[str]:
    """Nombres de discos físicos que sostienen piezas del sistema operativo."""
    names: set[str] = set()

    for target in ("/", "/boot", "/boot/efi"):
        source = _run(["findmnt", "-n", "-o", "SOURCE", target])
        if not source:
            continue
        device = source.splitlines()[0].strip()
        pk = whole_disk_for(device)
        names.add(pk or Path(device).name)

    try:
        for line in Path("/proc/swaps").read_text().splitlines():
            parts = line.split()
            if parts and parts[0].startswith("/dev/"):
                pk = whole_disk_for(parts[0])
                names.add(pk or Path(parts[0]).name)
    except OSError:
        pass

    names.discard("")
    return names


def is_system_disk(device: str) -> bool:
    disk = Path(device.strip()).name if (device or "").strip() else ""
    if not disk:
        return False
    pk = whole_disk_for(device)
    system = system_disk_names()
    return bool(pk and pk in system) or disk in system


def ensure_not_system_disk(device: str, action: str) -> None:
    if is_system_disk(device):
        raise HTTPException(
            400,
            f"No se puede {action} sobre «{device}»: es el disco del sistema.",
        )


def mount_source_for(path: str | Path) -> str | None:
    """Dispositivo que respalda a `path` (ancestro existente más cercano)."""
    p = Path(path).absolute()
    while p and not p.exists():
        parent = p.parent
        if parent == p:
            p = None
            break
        p = parent
    if p is None:
        return None
    out = _run(["df", "-P", str(p)])
    lines = out.splitlines()[1:]
    if not lines:
        return None
    return lines[0].split()[0] or None


def ensure_restore_destination_safe(destination: str) -> None:
    """`destination` jamás puede residir sobre el disco del sistema."""
    source = mount_source_for(destination)
    if not source:
        raise HTTPException(
            400,
            "No se pudo determinar el dispositivo del destino elegido. "
            "La restauración se cancela por seguridad.",
        )
    if source in ("tmpfs", "devtmpfs", "sysfs", "proc", "overlay"):
        raise HTTPException(
            400,
            "El destino «%s» está sobre un filesystem del sistema (%s); "
            "la restauración no debe tocar el disco del sistema."
            % (destination, source),
        )
    if source.startswith("/dev/"):
        if is_system_disk(source):
            raise HTTPException(
                400,
                "El destino «%s» está sobre el disco del sistema (%s). "
                "Elige una unidad de datos (partición privada, de respaldo, "
                "USB u otra) para restaurar." % (destination, source),
            )