# STEPAD NSP

**Network Security Platform** — Appliance de red desarrollado sobre Debian.

Backend **Python / FastAPI** + Frontend **React (Vite)** + **PostgreSQL/Alembic**,
con dnsmasq (DHCP+DNS), pdns-recursor (filtrado), Suricata (IPS), Samba
(archivos), restic (respaldos versionados), Tailscale (acceso remoto) y
WireGuard (VPN).

> Este README es el mapa para **tomar las riendas del software**: estructura,
> flujo de trabajo, y dónde mirar cada cosa. Léelo junto con `AGENTS.md`
> (guía de contexto y reglas del proyecto).

---

## 1. Arquitectura en una línea

```
[ Browser / API clients ]  →  FastAPI (backend)  →  PostgreSQL
                                    │ componentes (threads/daemons)
                                    ├ dnsmasq / pdns / Suricata / Samba / restic / tailscale / wg
                                    └ particiones (shared / backup / private) montadas por demanda
```

- Backend y frontend viven en **un solo deploy** (una máquina = un NSP).
- La **fuente de verdad** de config/backend está en el repo `backend/`; el
  frontend compilado (`frontend/dist`) se sirve junto a la API.
- Cada máquina guarda sus secretos en `/etc/stepad/stepad.env` (0600); nada de
  passwords en el repo.

---

## 2. Estructura del repositorio

```
stepad-nsp/
├── backend/
│   ├── main.py                      # punto de entrada (bootstrap + single_instance)
│   └── core/
│   │   ├── bootstrap.py             # arranca componentes en orden
│   │   ├── component_manager.py     # lifecycle de componentes
│   │   └── config/settings.py, secret_manager.py   # config + secretos
│   ├── api/
│   │   ├── app.py                   # crea la app FastAPI e incluye routers
│   │   └── v1/routes/*.py           # endpoints REST (uno por dominio)
│   ├── <dominio>/                   # cada dominio con su layering:
│   │   ├── routes/   schemas/   models/
│   │   ├── services/  repositories/  providers/
│   │   └── components/             # background threads/daemons del dominio
│   ├── migrations/                  # migraciones Alembic (versión SQL)
│   ├── scripts/                     # utilidades (migrar, configurar suricata…)
│   ├── shared/                      # config, logging, utils
│   └── tests/                       # pytest (conftest fuerza modo dev)
├── frontend/
│   ├── src/pages/                   # pantallas (Security, Protection, Shares…)
│   ├── src/services/api.js          # cliente de la API (por dominio)
│   └── vite.config.js, package.json
├── scripts/
│   ├── publish-release.sh           # publica una versión a stepad-nsp-release
│   └── configure_suricata.py, pre-update-backup.sh, restore-backup.sh
├── install.sh / uninstall.sh / update.sh / make-installer.sh / get-stepad.sh
├── AGENTS.md                        # guía de contexto y reglas de trabajo
└── VERSION
```

---

## 3. Backend: los dominios

Cada dominio tiene el mismo patrón (`routes + schemas + models + services +
repositories + providers`). Los principales:

| Dominio | Qué hace |
|---|---|
| `auth`, `users` | Login JWT, roles (OPERATOR/ADMIN), usuarios, MFA |
| `network` (+ `devices`, `interfaces`, `zones`, `configuration`) | Tarjetas WAN/LAN, dispositivos, zonas/segmentos, DHCP (dnsmasq) |
| `dhcp` | Reservas de IP, pools, diagnóstico, alertas |
| `dns` (+ `content`, `groups`) | Filtrado de dominios, categorías, grupos, RPZ |
| `firewall` (+ `rules`, `ips`) | Reglas, Suricata (IPS), respuesta ante amenazas |
| `shares` | Particiones y carpetas compartidas, respaldo (restic), web files |
| `storage` | Discos/particiones (shared/backup/private), montaje por demanda |
| `backups` | Respaldo del sistema (config + DB + secretos) a USB/cloud |
| `monitoring`, `notifications`, `reports` | Monitoreo WAN, alertas por email, reportes |
| `vpn`, `rustdesk`, `bandwidth`, `audit`, `organization` | VPN/WG, escritorio remoto, uso de ancho, auditoría, datos de la empresa |

**Componentes**: los procesos de fondo (scheduler de respaldos, capturas de
logs, monitoreo…) son componentes que el `component_manager` arranca/detiene
con el ciclo de vida de la app.

---

## 4. Cómo funciona el respaldo (restic) — clave

- Cada **partición de respaldo** crea su **programación** al crearse; al
  eliminar la partición se elimina la programación.
- Cada job tiene su **repo restic**: `<particion>/Respaldo/.backups/job-<id>`.
- **Solo corre en su ventana de horario** (una vez por horario; sin
  "ponerse al día" horas después del horario perdido).
- **Solo versiona si hubo cambios**:
  - Origen local: firma de árbol (ruta/mtime/tamaño); sin cambios → no corre.
  - Origen de red: corre restic `--json`; si `+0 B` → descarta el snapshot
    vacío y registra "Sin cambios… No se creó versión".
- **No satura la red**: el respaldo de red se limita por QoS
  (`rate_limit_mbps`; default **50% del enlace**; nunca >80%).
- **Mantenimiento por job**: `restic check` (integridad) y test-restore,
  con intervalos configurables.
- **Watchdog** de "ventana perdida": alerta si un job no corrió su horario.
- IDs de job **únicos globales**; retención `keep-last N` + prune por espacio;
  restic es **resumible** (una corrida cortada se retoma en la siguiente).

Las programaciones quedan visibles aunque la partición esté desmontada:
**caché multi-bóveda** (`/etc/stepad/backup_schedule.json`, mirror completo)
+ bóvedas registradas siempre listadas.

---

## 5. Modelo de particiones

- **compartir** (shared): expuesta por SMB a la red.
- **respaldar** (backup): privada, **desmontada por defecto** (solo se monta
  durante la corrida) → anti-ransomware; no expuesta por SMB; montada con
  `noexec,nodev,nosuid`.
- **privada** (private): guarda información elegida; también montada por demanda.

---

## 6. Release / publicación

```
DEV (192.168.100.194)  →  tag + bash scripts/publish-release.sh vX.Y.Z
       └─► stepad-nsp-release (GitHub) ──► usuarios: curl ... get-stepad.sh | sudo bash
```

1. Se desarrolla y prueba **solo en DEV**.
2. Se versiona **solo con aprobación**: bump `VERSION`, commit, `git tag`, push.
3. `publish-release.sh` → `make-installer.sh` (valida shell+python+heredocs,
   compila el frontend, **excluye credenciales/AGENTS/.env**) y sube el
   instalador + `get-stepad.sh` + `VERSION` al repo release.
4. Actualización en cada máquina: `get-stepad.sh` (preserva secretos en
   `/etc/stepad/stepad.env`, respalda env por cada update).

> El instalador **no** incluye `AGENTS.md`, `.env*` ni credenciales (ver
> `make-installer.sh`).

---

## 7. Máquinas (sin credenciales en el repo)

| Rol | LAN | Tailscale | Uso |
|---|---|---|---|
| **Dev** | 192.168.100.194 | 100.92.205.99 | fuente del código, pruebas, releases |
| **Prod (respaldos/discos)** | 192.168.100.11 | 100.97.46.90 | producción, particiones y respaldos |
| **Router de sitio** | 192.168.100.141 | 100.116.102.19 | gateway LAN usuarios + NSP |

Credenciales de acceso/UI → en cada máquina (`/etc/stepad/stepad.env` y
usuarios de la UI); **no se versionan**.

---

## 8. Para tomar las riendas (guía de arranque)

1. Leé **`AGENTS.md`** (reglas: todo se hace en DEV, no versionar sin
   aprobación, decisiones de diseño ya tomadas).
2. Seguí el **ciclo de un endpoint**: `api/v1/routes/<dominio>.py` →
   `services/<dominio>.py` → `models/` (SQLAlchemy) → `migrations/`.
3. Entendé el **respaldo** leyendo `backend/shares/services/share_backup_service.py`
   (es el módulo más grande) y `backend/shares/services/net_rate_shaper.py`.
4. Frontend: `frontend/src/pages/` por pantalla; `services/api.js` es el
   cliente usado por todas.
5. Testing: `backend/tests/` (pytest); los tests corren en modo dev sin DB real.
6. Publicación: `bash scripts/publish-release.sh v2.5.301 "nota"` (ver §6).

---

## 9. Estado actual

Versión en curso: **v2.5.314** (con límite de red por respaldo, foco UI y
robustez de historial/scheduling).