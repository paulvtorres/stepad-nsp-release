from backend.core.components.base_component import BaseComponent
from backend.core.lifecycle.component_criticality import ComponentCriticality

from backend.dhcp.services.dhcp_service import DhcpService
from backend.dhcp.providers.linux_dhcp_provider import LinuxDhcpProvider

from backend.shared.logging.logger import logger

from backend.dhcp.services.dhcp_reservation_service import (
    DhcpReservationService
)

from backend.dhcp.services.dhcp_reservation_cleanup_service import (
    DhcpReservationCleanupService
)

from backend.dhcp.services.dhcp_alert_service import (
    DhcpAlertService
)


class DhcpComponent(BaseComponent):

    name = "dhcp"

    criticality = ComponentCriticality.IMPORTANT


    def __init__(self):

        self.service = DhcpService()

        self.provider = LinuxDhcpProvider()
        self.reservation_service = DhcpReservationService()
        self.cleanup_service = DhcpReservationCleanupService()
        self.alert_service = DhcpAlertService()

        self.process = None
        self._sync_stop = False
        self._sync_thread = None
        self._lease_monitor_stop = False
        self._lease_monitor_thread = None

    def _sync_ip_loop(self) -> None:
        """Sincroniza periódicamente ip_address desde ARP/leases.

        Cuando un equipo con IP reservada renueva y toma la reservada,
        ip_address se actualiza aquí y las referencias (Samba, ancho de
        banda, grupos) cambian automáticamente a la IP nueva."""
        import time
        # Cada 60 s sincroniza IPs; cada 5 min reconcilia el estado
        # deseado (idempotente: solo reinicia si algo cambió). Asi el
        # DHCP converge solo aunque algun cambio se haya aplicado a
        # medias o alguien haya editado un archivo a mano.
        cycle = 0
        while not self._sync_stop:
            cycle += 1
            try:
                self.service.sync_device_ips()
            except Exception as error:
                logger.warning(
                    "DHCP sync de IPs (periodico) falló: %s",
                    error,
                )
            if cycle % 5 == 0:
                try:
                    from backend.dhcp.reconciler import get_dhcp_reconciler
                    get_dhcp_reconciler().apply()
                except Exception as error:
                    logger.warning(
                        "DHCP reconciliación periódica falló: %s", error
                    )
                try:
                    self.service.auto_expand_pool_if_enabled()
                except Exception as error:
                    logger.warning(
                        "DHCP ampliación automática falló: %s", error
                    )
            for _ in range(60):
                if self._sync_stop:
                    return
                time.sleep(1)


    def start(self):

        logger.info(
            "DhcpComponent started."
        )

        current = self.provider.status()

        if current.get("running"):

            # dnsmasq es independiente del panel: una actualización o
            # reinicio de STEPAD no debe cortar DHCP. Se reconcilia sin
            # forzar reinicio: si la configuración en disco ya coincide,
            # no se toca; si quedó vieja, se corrige una vez.
            self.process = current.get("pid")

            result = self.service.apply_config(force=False)

            if result.get("success"):

                self.process = result.get("service", {}).get("pid")

            logger.info(
                "DhcpComponent: dnsmasq ya está activo (pid %s); "
                "configuración reconciliada sin reinicio forzado.",
                self.process,
            )

        else:

            result = self.service.apply_config()

            if result.get("success"):

                self.process = result.get("service", {}).get("pid")

        self.cleanup_service.start_scheduler()
        self.alert_service.start_scheduler()

        if self._sync_thread is None:
            self._sync_stop = False
            import threading
            self._sync_thread = threading.Thread(
                target=self._sync_ip_loop,
                daemon=True,
                name="dhcp-sync-ips",
            )
            self._sync_thread.start()

        if self._lease_monitor_thread is None:
            import threading
            self._lease_monitor_stop = False
            self._lease_monitor_thread = threading.Thread(
                target=self._lease_monitor_loop,
                daemon=True,
                name="dhcp-lease-monitor",
            )
            self._lease_monitor_thread.start()

    def _lease_monitor_loop(self) -> None:
        """Detecta falta de IP en el log de dnsmasq y reacciona en segundos."""

        import time
        from pathlib import Path

        from backend.core.config.paths import DNSMASQ_LOG_FILE

        path = Path(DNSMASQ_LOG_FILE)

        try:
            offset = path.stat().st_size
        except OSError:
            offset = 0

        last_trigger = 0.0

        while not self._lease_monitor_stop:
            try:
                if path.exists():
                    size = path.stat().st_size
                    if size < offset:
                        offset = 0
                    if size > offset:
                        with path.open("rb") as handle:
                            handle.seek(offset)
                            chunk = handle.read(200_000)
                            offset = handle.tell()
                        text = chunk.decode("utf-8", errors="replace").lower()
                        if (
                            "no address available" in text
                            or "ninguna dirección disponible" in text
                        ):
                            import re

                            match = re.search(
                                r"([0-9a-f]{2}(?::[0-9a-f]{2}){5})",
                                chunk.decode("utf-8", errors="replace"),
                                re.IGNORECASE,
                            )

                            now = time.monotonic()
                            if now - last_trigger >= 30:
                                last_trigger = now
                                self._notify_no_address(
                                    match.group(1) if match else ""
                                )
                                self.service.trigger_lease_reclaim()
            except Exception as error:
                logger.warning("DHCP lease monitor: %s", error)
            for _ in range(20):
                if self._lease_monitor_stop:
                    return
                time.sleep(0.1)

    def _notify_no_address(self, mac: str = "") -> None:
        try:
            from backend.alerts.services.alert_service import AlertService
            from backend.core.database.session import SessionLocal

            db = SessionLocal()
            try:
                AlertService().create(
                    db,
                    alert_type="DHCP_NO_ADDRESS",
                    severity="critical",
                    title="DHCP: no hay IPs disponibles para asignar",
                    message=(
                        "Un equipo pidió IP y dnsmasq no pudo asignarla. "
                        + (f"MAC solicitante: {mac}. " if mac else "")
                        + "STEPAD intenta liberar leases retenidos; las reservas "
                        "y equipos en uso no se tocan."
                    ),
                )
                db.commit()
            finally:
                db.close()
        except Exception as error:
            logger.warning("DHCP no-address alert: %s", error)

    def health_check(self) -> bool:
        try:
            from backend.dhcp.services.dhcp_health_service import (
                DhcpHealthService,
            )

            return bool(DhcpHealthService().inspect().get("healthy"))

        except Exception as error:
            logger.warning("DhcpComponent health_check: %s", error)
            return False

    def stop(self):

        logger.info(
            "Stopping DHCP service."
        )

        self._sync_stop = True
        thread = self._sync_thread
        if thread and thread.is_alive():
            thread.join(timeout=3)
        self._sync_thread = None

        self._lease_monitor_stop = True
        monitor = self._lease_monitor_thread
        if monitor and monitor.is_alive():
            monitor.join(timeout=3)
        self._lease_monitor_thread = None

        self.cleanup_service.stop_scheduler()
        self.alert_service.stop_scheduler()

        # dnsmasq NO se detiene al parar el panel. Si se detuviera, cada
        # actualización/restart de STEPAD dejaría a los equipos sin DHCP.
        # Para un reinicio controlado se usa process_manager desde el
        # reconciliador.
        logger.info(
            "DhcpComponent: dnsmasq se mantiene activo al detener el panel."
        )
